/**
 * Red Shark POS — Production Client Packager & Hardener
 * Generates a clean, enterprise-protected, obfuscated release package for customer PCs.
 * Strips developer tools, license generators, temp files, and test profiles.
 * Obfuscates application source code to prevent tampering and reverse engineering.
 * Automatically increments version and packages distribution ZIP ready for in-app updates.
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const JavaScriptObfuscator = require('javascript-obfuscator');

const ROOT_DIR = __dirname;
const DIST_PARENT = path.join(ROOT_DIR, 'dist');
const DIST_DIR = path.join(DIST_PARENT, 'RedSharkPOS_Client_Release');

console.log('===============================================================');
console.log('🚀 Red Shark POS — Building Hardened Client Release Package');
console.log('===============================================================\n');

// ── Step 0: Version Management & Auto-Increment ───────────────
console.log('🏷️ Step 0: Managing Release Version...');
const versionFilePath = path.join(ROOT_DIR, 'version.json');
let verData = {
  name: "Red Shark POS",
  version: "1.2.0",
  build: 16,
  releaseDate: new Date().toISOString().split('T')[0]
};

if (fs.existsSync(versionFilePath)) {
  try {
    verData = JSON.parse(fs.readFileSync(versionFilePath, 'utf8'));
  } catch (e) {}
}

const args = process.argv.slice(2);
const shouldNotBump = args.includes('--no-bump');

if (!shouldNotBump) {
  verData.build = (parseInt(verData.build) || 16) + 1;
  const vParts = (verData.version || '1.2.0').split('.').map(Number);
  if (vParts.length === 3) {
    vParts[2] += 1;
    verData.version = vParts.join('.');
  } else {
    verData.version = '1.2.1';
  }
  verData.releaseDate = new Date().toISOString().split('T')[0];
  fs.writeFileSync(versionFilePath, JSON.stringify(verData, null, 2), 'utf8');
  console.log(`  ✓ Auto-incremented to Version ${verData.version} (Build ${verData.build})`);

  // Sync with package.json
  const pkgPath = path.join(ROOT_DIR, 'package.json');
  if (fs.existsSync(pkgPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
      pkg.version = verData.version;
      fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2), 'utf8');
      console.log(`  ✓ Synced package.json version: ${verData.version}`);
    } catch (e) {}
  }

  // Sync with js/modules/license.js
  const licPath = path.join(ROOT_DIR, 'js', 'modules', 'license.js');
  if (fs.existsSync(licPath)) {
    try {
      let licContent = fs.readFileSync(licPath, 'utf8');
      licContent = licContent.replace(/const APP_VERSION = "[^"]+";/, `const APP_VERSION = "${verData.version}";`);
      licContent = licContent.replace(/const APP_BUILD = \d+;/, `const APP_BUILD = ${verData.build};`);
      fs.writeFileSync(licPath, licContent, 'utf8');
      console.log(`  ✓ Synced license.js APP_VERSION: ${verData.version}, APP_BUILD: ${verData.build}`);
    } catch (e) {}
  }

  // Sync with index.html sidebar footer
  const indexHtmlPath = path.join(ROOT_DIR, 'index.html');
  if (fs.existsSync(indexHtmlPath)) {
    try {
      let indexHtml = fs.readFileSync(indexHtmlPath, 'utf8');
      indexHtml = indexHtml.replace(/<span id="sidebar-app-version">[^<]*<\/span>/, `<span id="sidebar-app-version">${verData.version}</span>`);
      indexHtml = indexHtml.replace(/id="sidebar-app-build">[^<]*<\/span>/, `id="sidebar-app-build">Build ${verData.build}</span>`);
      indexHtml = indexHtml.replace(/\?v=\d+/g, `?v=${verData.build}`);
      fs.writeFileSync(indexHtmlPath, indexHtml, 'utf8');
      console.log(`  ✓ Synced index.html sidebar version and cache-buster scripts to ?v=${verData.build}`);
    } catch (e) {}
  }
} else {
  console.log(`  ✓ Keeping current Version ${verData.version} (Build ${verData.build})`);
}

if (!fs.existsSync(DIST_PARENT)) {
  fs.mkdirSync(DIST_PARENT, { recursive: true });
}
if (fs.existsSync(DIST_DIR)) {
  fs.rmSync(DIST_DIR, { recursive: true, force: true });
}
fs.mkdirSync(DIST_DIR, { recursive: true });

const BLACKLIST = new Set([
  'developer_generator.html',
  'developer_decryptor.html',
  'license_generator.html',
  'generate_license.js',
  'scratch',
  '.git',
  '.agents',
  '.gemini',
  'dist',
  'Backup',
  'Build_Client_Release.js',
  'RedSharkPOS_Deployment.zip',
  'New folder',
  'inputs.txt',
  'website_index.html',
  'website_assets',
  'restaurant.js',
  'video',
  'Start_Cloudflare_Tunnel.bat'
]);

function shouldExclude(itemName) {
  if (BLACKLIST.has(itemName)) return true;
  if (itemName.startsWith('temp_edge_profile')) return true;
  if (itemName.startsWith('print-script_')) return true;
  if (itemName.startsWith('temp-print_')) return true;
  if (itemName.endsWith('.req') || itemName.endsWith('.lic')) return true;
  if (itemName.endsWith('.png') && !['red_shark_logo.png', 'red_shark_icon.png', 'favicon.png'].includes(itemName)) return true;
  return false;
}

// 1. Copy Files
console.log('\n📦 Step 1: Copying clean distribution assets...');
const items = fs.readdirSync(ROOT_DIR);
for (const item of items) {
  if (shouldExclude(item)) {
    console.log(`  🔒 Excluded dev tool / temporary: ${item}`);
    continue;
  }

  const srcPath = path.join(ROOT_DIR, item);
  const destPath = path.join(DIST_DIR, item);
  const stat = fs.statSync(srcPath);

  if (stat.isDirectory()) {
    if (item === 'data') {
      fs.mkdirSync(destPath, { recursive: true });
    } else {
      fs.cpSync(srcPath, destPath, { recursive: true });
    }
  } else {
    fs.copyFileSync(srcPath, destPath);
  }
}

// 2. Obfuscate JavaScript files
console.log('\n🛡️ Step 2: Encrypting and obfuscating JavaScript source code...');

function getAllJsFiles(dirPath, arrayOfFiles = []) {
  const files = fs.readdirSync(dirPath);

  for (const file of files) {
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isDirectory()) {
      if (file !== 'node_modules') {
        getAllJsFiles(fullPath, arrayOfFiles);
      }
    } else if (file.endsWith('.js') && !file.endsWith('.min.js')) {
      arrayOfFiles.push(fullPath);
    }
  }

  return arrayOfFiles;
}

const jsFiles = getAllJsFiles(DIST_DIR);
let obfuscatedCount = 0;

for (const filePath of jsFiles) {
  const relPath = path.relative(DIST_DIR, filePath);
  try {
    const originalCode = fs.readFileSync(filePath, 'utf8');
    
    // Obfuscate with Antivirus-safe settings (avoids Heuristic JS/Obfuse false-positives on Windows Defender)
    const obfuscated = JavaScriptObfuscator.obfuscate(originalCode, {
      compact: true,
      controlFlowFlattening: false,
      numbersToExpressions: false,
      simplify: true,
      stringArray: false,
      splitStrings: false,
      identifierNamesGenerator: 'hexadecimal',
      renameGlobals: false,
      transformObjectKeys: false
    });

    fs.writeFileSync(filePath, obfuscated.getObfuscatedCode(), 'utf8');
    console.log(`  ✓ Obfuscated: ${relPath}`);
    obfuscatedCount++;
  } catch (err) {
    console.warn(`  ⚠️ Warning: Could not obfuscate ${relPath}: ${err.message}`);
  }
}

// 3. Automatically Compress into In-App Update ZIP Package
console.log('\n🗜️ Step 3: Generating ready-to-upload Update ZIP packages...');
const zipVersionName = `RedSharkPOS_Update_v${verData.version}.zip`;
const zipLatestName = `RedSharkPOS_Latest_Update.zip`;
const zipVersionPath = path.join(DIST_PARENT, zipVersionName);
const zipLatestPath = path.join(DIST_PARENT, zipLatestName);

try {
  if (fs.existsSync(zipVersionPath)) fs.unlinkSync(zipVersionPath);
  if (fs.existsSync(zipLatestPath)) fs.unlinkSync(zipLatestPath);

  // Use fast Windows native bsdtar (or PowerShell fallback)
  // Exclude node_modules, data, heavy .exe binaries so update zip is clean (~9 MB) and includes bin/*.ps1 scripts
  const excludeArgs = '--exclude="node_modules" --exclude="node_modules/*" --exclude="data" --exclude="data/*" --exclude="bin/*.exe" --exclude="RedSharkPOS.exe" --exclude="Start_Cloudflare_Tunnel.bat"';
  try {
    execSync(`tar ${excludeArgs} -a -cf "${zipVersionPath}" *`, { cwd: DIST_DIR, stdio: 'inherit' });
  } catch(tarErr) {
    const psCmd = `powershell -NoProfile -Command "Compress-Archive -Path '${DIST_DIR}\\*' -DestinationPath '${zipVersionPath}' -Force"`;
    execSync(psCmd, { stdio: 'inherit' });
  }
  fs.copyFileSync(zipVersionPath, zipLatestPath);

  const zipSizeMB = (fs.statSync(zipVersionPath).size / (1024 * 1024)).toFixed(2);
  console.log(`  ✓ Created Update ZIP: ${zipVersionName} (${zipSizeMB} MB)`);
  console.log(`  ✓ Created Latest ZIP: ${zipLatestName}`);

  // Automatically deploy/sync to RedSharkStorefront for Cloudflare OTA delivery
  const storefrontDir = 'D:\\GravityProject\\RedSharkStorefront';
  if (fs.existsSync(storefrontDir)) {
    try {
      const sfDist = path.join(storefrontDir, 'dist');
      if (!fs.existsSync(sfDist)) fs.mkdirSync(sfDist, { recursive: true });
      fs.copyFileSync(zipLatestPath, path.join(sfDist, 'update.zip'));
      fs.copyFileSync(zipLatestPath, path.join(storefrontDir, 'update.zip'));
      fs.copyFileSync(versionFilePath, path.join(storefrontDir, 'version.json'));
      fs.copyFileSync(versionFilePath, path.join(sfDist, 'version.json'));
      console.log(`  ✓ Successfully synced update.zip (${zipSizeMB} MB) & version.json to RedSharkStorefront!`);

      // Automatically commit and push to storefront git for instant Cloudflare Pages OTA delivery
      try {
        console.log(`  🚀 Auto-publishing OTA update to Cloudflare via Git...`);
        execSync('git add dist/update.zip dist/version.json version.json update.zip', { cwd: storefrontDir, stdio: 'ignore' });
        execSync(`git commit -m "chore(release): publish POS v${verData.version} build ${verData.build} OTA update package"`, { cwd: storefrontDir, stdio: 'ignore' });
        execSync('git push origin main', { cwd: storefrontDir, stdio: 'ignore' });
        console.log(`  ✓ OTA Update successfully published and deployed to Cloudflare!`);
      } catch (gitErr) {
        console.warn(`  ⚠️ Notice: Could not auto-push to storefront git (${gitErr.message}). Run git push manually in RedSharkStorefront.`);
      }
    } catch(sfErr) {
      console.warn(`  ⚠️ Could not auto-sync to storefront: ${sfErr.message}`);
    }
  }
} catch (e) {
  console.warn(`  ⚠️ Notice: Could not automatically package zip: ${e.message}`);
}

console.log(`\n===============================================================`);
console.log(`✅ [SUCCESS] Hardened Client Release & Update Package Created!`);
console.log(`   🏷️ Release Version: v${verData.version} (Build ${verData.build})`);
console.log(`   📂 Client Folder:   ${DIST_DIR}`);
console.log(`   📦 In-App ZIP File: ${zipVersionPath}`);
console.log(`   🛡️ ${obfuscatedCount} JavaScript files successfully encrypted.`);
console.log(`   🔒 All license generators and dev backdoors removed.`);
console.log(`===============================================================\n`);
