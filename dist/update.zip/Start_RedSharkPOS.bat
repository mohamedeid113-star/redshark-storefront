@echo off
title Red Shark POS Launcher
set APP_DIR=%~dp0
cd /d "%APP_DIR%"

:: 1. Restart backend server with fresh code (kills any stale process holding old code in RAM)
taskkill /f /im node.exe >nul 2>nul
timeout /t 1 >nul
powershell -NoProfile -Command "Start-Process 'node.exe' -ArgumentList 'server.js' -WorkingDirectory '%APP_DIR%' -WindowStyle Hidden" 2>nul
timeout /t 2 >nul

:: 2. Find Chrome or Edge for Kiosk Direct Printing (No Preview Dialog)
set BROWSER_EXE=""
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" set BROWSER_EXE="C:\Program Files\Google\Chrome\Application\chrome.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" set BROWSER_EXE="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set BROWSER_EXE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" set BROWSER_EXE="C:\Program Files\Microsoft\Edge\Application\msedge.exe"

set PROFILE_DIR=%LOCALAPPDATA%\RedSharkPOS\BrowserPOS
if not exist "%PROFILE_DIR%" mkdir "%PROFILE_DIR%"

:: Purge any stale cache and service workers from browser profile (preserves IndexedDB & settings)
if exist "%PROFILE_DIR%\Default\Service Worker" rmdir /s /q "%PROFILE_DIR%\Default\Service Worker" 2>nul
if exist "%PROFILE_DIR%\Default\Cache" rmdir /s /q "%PROFILE_DIR%\Default\Cache" 2>nul
if exist "%PROFILE_DIR%\Default\Code Cache" rmdir /s /q "%PROFILE_DIR%\Default\Code Cache" 2>nul
if exist "%PROFILE_DIR%\Default\Web Applications" rmdir /s /q "%PROFILE_DIR%\Default\Web Applications" 2>nul

if not %BROWSER_EXE%=="" (
  start "" %BROWSER_EXE% --kiosk-printing --user-data-dir="%PROFILE_DIR%" --app="http://127.0.0.1:3000/login.html"
) else (
  start "" "http://127.0.0.1:3000/login.html"
)
exit
