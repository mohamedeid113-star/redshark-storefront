/* ================================================================
   NexPOS — Sales Module (Quotation, Order, Delivery, Invoice, Return)
   ================================================================ */

const SalesModule = (() => {  async function renderSalesDoc(container, store, titleEn, titleAr, prefix, statusOptions) {
    let docs = await DB.getAll(store);
    if (store === 'sales_invoice') {
      const posSales = await DB.getAll('sales');
      const formattedPosSales = posSales.map(s => ({
        ...s,
        store: 'sales',
        ref: s.receipt_no || s.ref || `POS-${String(s.id).padStart(5,'0')}`,
        status: s.status || 'paid'
      }));
      docs = [...docs.map(d => ({ ...d, store: 'sales_invoice' })), ...formattedPosSales];
      docs.sort((a,b) => new Date(b.created_at || b.doc_date || 0) - new Date(a.created_at || a.doc_date || 0));
    }

    // Branch Isolation: if running on a branch station, restrict docs to own branch
    let syncCfg = { role: 'server', branchId: 'main' };
    try {
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        syncCfg = await BranchSync.getConfig();
      }
    } catch(e) {}
    if (syncCfg.role !== 'server') {
      const myBranch = (syncCfg.branchId || 'main').toLowerCase();
      docs = docs.filter(d => {
        const b = String(d.branch_id || d.syncBranchId || '').trim().toLowerCase();
        return b === myBranch || (!b && myBranch === 'main');
      });
    }

    const customers = await DB.getAll('customers');
    const isAR      = i18n.getLang() === 'ar';
    const title     = isAR ? titleAr : titleEn;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${title}</h1>
          <p>${isAR ? `${docs.length} وثيقة` : `${docs.length} documents`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="SalesModule.exportSales('${store}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير' : 'Export'}
          </button>
          <button class="btn btn-primary" onclick="SalesModule.openSalesDoc('${store}', null)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'جديد' : 'New'}
          </button>
        </div>
      </div>

      <div class="toolbar">
        <div class="search-bar flex-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" placeholder="${isAR ? 'بحث بالرقم أو العميل...' : 'Search by ref or customer...'}"
            id="sal-search" onfocus="this.select()" onclick="this.select()" oninput="SalesModule.searchSales()" style="padding-left:34px">
        </div>
        <input type="date" class="form-control" id="sal-from" style="width:150px" onchange="SalesModule.searchSales()">
        <input type="date" class="form-control" id="sal-to" style="width:150px" onchange="SalesModule.searchSales()">
        <select class="form-control" id="sal-status-filter" style="width:140px" onchange="SalesModule.searchSales()">
          <option value="">${isAR ? 'كل الحالات' : 'All Statuses'}</option>
          ${statusOptions.map(s => `<option value="${s.v}">${isAR ? s.ar : s.en}</option>`).join('')}
        </select>
      </div>

      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR ? 'الرقم' : 'Ref'}</th>
            <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
            <th>${isAR ? 'طريقة الدفع' : 'Payment'}</th>
            <th>${isAR ? 'العميل' : 'Customer'}</th>
            <th>${isAR ? 'الإجمالي' : 'Total'}</th>
            <th>${isAR ? 'الحالة' : 'Status'}</th>
            <th>${isAR ? 'إجراءات' : 'Actions'}</th>
          </tr></thead>
          <tbody id="sal-tbody">
            ${renderSalesRows(docs, customers, isAR, store)}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Sales Doc Modal -->
    <div class="modal-overlay" id="sal-modal">
      <div class="modal" style="max-width:820px">
        <div class="modal-header">
          <div class="modal-title" id="sal-modal-title">${title}</div>
          <button class="btn-icon" onclick="Utils.closeModal('sal-modal')">✕</button>
        </div>
        <div class="modal-body" id="sal-doc-body"></div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('sal-modal')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-secondary" onclick="SalesModule.saveAndPrintSales('${store}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'حفظ وطباعة' : 'Save & Print'}
          </button>
          <button class="btn btn-primary" onclick="SalesModule.saveSalesDoc('${store}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
            ${isAR ? 'حفظ' : 'Save'}
          </button>
        </div>
      </div>
    </div>`;

    window._salStore     = store;
    window._salCustomers = customers;
    window._salPrefix    = prefix;
  }

  function renderSalesRows(docs, customers, isAR, defaultStore) {
    if (!docs.length) return `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد وثائق' : 'No documents found'}</td></tr>`;
    const colors = { draft:'secondary', pending:'warning', confirmed:'info', delivered:'success', invoiced:'primary', cancelled:'danger', paid:'success', partial:'warning', returned:'danger' };
    
    const payLabels = {
      cash:     { en: '💵 Cash',     ar: '💵 نقدي' },
      card:     { en: '💳 Card',     ar: '💳 بطاقة' },
      credit:   { en: '⏳ On Credit', ar: '⏳ آجل' },
      transfer: { en: '🏦 Transfer', ar: '🏦 تحويل' },
      cheque:   { en: '📝 Cheque',   ar: '📝 شيك' },
      split:    { en: '🔀 Split',    ar: '🔀 متعدد' },
      lbp_cash: { en: '💵 LBP Cash', ar: '💵 ليرة نقداً' },
      usd_cash: { en: '💵 USD Cash', ar: '💵 دولار نقداً' },
    };

    return docs.map((d, idx) => {
      const cust = customers.find(c => c.id === d.customer_id);
      const custName = cust ? (isAR ? (cust.name_ar||cust.name_en) : (cust.name_en||cust.name_ar)) : (d.customer_name || (isAR ? 'عميل عابر' : 'Walk-in'));
      const itemStore = d.store || defaultStore;
      const posBadge = d.store === 'sales' ? '<span class="badge badge-info" style="margin-left:6px">POS</span>' : '';
      
      const rawDate = d.created_at || d.doc_date || d.date;
      const dt = rawDate ? new Date(rawDate) : null;
      const dateFormatted = dt && !isNaN(dt.getTime()) ? dt.toLocaleDateString('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit' }) : (rawDate || '-');
      const timeFormatted = dt && !isNaN(dt.getTime()) ? dt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }) : '';

      const payMethod = (d.payment_method || d.pay_method || d.payment_type || 'cash').toLowerCase();
      const pInfo = payLabels[payMethod] || { en: payMethod.toUpperCase(), ar: payMethod };

      let parsedItems = [];
      try {
        const raw = d.items_json || d.items || '[]';
        parsedItems = typeof raw === 'string' ? JSON.parse(raw) : (Array.isArray(raw) ? raw : []);
      } catch(e){}
      const rowId = `sal-row-exp-${itemStore}-${d.id || idx}`;

      return `
      <tr style="cursor:pointer;transition:background 0.15s" onclick="SalesModule.toggleRowDetail('${rowId}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
        <td>
          <div style="display:flex;align-items:center;gap:6px">
            <button class="btn btn-ghost btn-sm" id="btn-${rowId}" style="padding:2px 6px;font-size:0.75rem;line-height:1;border-radius:4px" onclick="event.stopPropagation(); SalesModule.toggleRowDetail('${rowId}')" title="${isAR ? 'توسيع / طي بنود الفاتورة' : 'Expand / Collapse line items'}">▶</button>
            <span style="font-weight:700;color:var(--primary)">${d.ref||'-'}</span>
            ${posBadge}
            <span class="badge badge-secondary" style="font-size:0.65rem;padding:2px 5px" title="${isAR ? 'عدد الأصناف' : 'Item count'}">${parsedItems.length} 📦</span>
          </div>
        </td>
        <td>
          <div style="font-weight:700;font-size:0.8rem;color:var(--text-primary)">${dateFormatted}</div>
          ${timeFormatted ? `<div style="font-size:0.7rem;color:var(--text-muted);margin-top:2px">🕒 ${timeFormatted}</div>` : ''}
        </td>
        <td>
          <span class="badge badge-secondary" style="font-weight:700;font-size:0.74rem;padding:3px 8px">${isAR ? pInfo.ar : pInfo.en}</span>
        </td>
        <td>${Utils.truncate(custName, 28)}</td>
        <td>
          <div style="font-weight:700;color:var(--success)">${Utils.formatMoney(d.grand_total||0)}</div>
          ${(payMethod === 'credit' || parseFloat(d.credit_amount) > 0) ? `
          <div style="font-size:0.68rem;margin-top:2px;display:flex;gap:4px;flex-wrap:wrap">
            ${parseFloat(d.paid_amount || 0) > 0 ? `<span style="color:var(--info);font-weight:600">${isAR ? 'مدفوع: ' : 'Paid: '}${Utils.formatMoney(d.paid_amount)}</span>` : ''}
            <span style="color:var(--warning);font-weight:700">${isAR ? 'آجل: ' : 'Due: '}${Utils.formatMoney(d.credit_amount !== undefined ? d.credit_amount : Math.max(0, (d.grand_total || 0) - (parseFloat(d.paid_amount) || 0)))}</span>
          </div>` : ''}
        </td>
        <td><span class="badge badge-${colors[d.status]||'secondary'}">${d.status||'draft'}</span></td>
        <td>
          <div style="display:flex;gap:4px" onclick="event.stopPropagation()">
            <button class="btn btn-ghost btn-sm" onclick="SalesModule.openSalesDoc('${itemStore}', ${d.id})" title="${isAR?'عرض':'View/Edit'}">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="SalesModule.printSalesDoc(${d.id}, '${itemStore}')" title="${isAR?'طباعة':'Print'}">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="SalesModule.deleteDoc('${itemStore}', ${d.id})" style="color:var(--danger)" title="${isAR?'حذف':'Delete'}">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            </button>
          </div>
        </td>
      </tr>
      <!-- Expandable Invoice Items Breakdown -->
      <tr id="${rowId}" style="display:none;background:var(--surface-2)">
        <td colspan="7" style="padding:12px 16px">
          <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px;box-shadow:0 4px 12px rgba(0,0,0,0.1)">
            <div style="font-weight:700;font-size:0.84rem;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:6px">
              <span style="display:flex;align-items:center;gap:6px">
                <span>📦</span> ${isAR ? 'تفاصيل بنود الفاتورة' : 'Invoice Line Items'}: <strong style="color:var(--primary)">${d.ref || '-'}</strong>
              </span>
              <span style="font-size:0.75rem;color:var(--text-muted)">${parsedItems.length} ${isAR ? 'أصناف مدرجة' : 'items'}</span>
            </div>
            ${parsedItems.length === 0 ? `<div style="text-align:center;color:var(--text-muted);padding:10px;font-size:0.78rem">${isAR ? 'لا توجد بنود أصناف مسجلة' : 'No line items recorded for this invoice'}</div>` : `
            <table style="width:100%;font-size:0.78rem;border-collapse:collapse">
              <thead>
                <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted);text-align:left">
                  <th style="padding:6px">#</th>
                  <th style="padding:6px">${isAR ? 'الصنف' : 'Item'}</th>
                  <th style="padding:6px">${isAR ? 'الحالة' : 'Status'}</th>
                  <th style="padding:6px">${isAR ? 'الكمية' : 'Qty'}</th>
                  <th style="padding:6px">${isAR ? 'السعر' : 'Price'}</th>
                  <th style="padding:6px">${isAR ? 'الخصم%' : 'Disc%'}</th>
                  <th style="padding:6px">${isAR ? 'الإجمالي' : 'Total'}</th>
                </tr>
              </thead>
              <tbody>
                ${parsedItems.map((item, itemIdx) => {
                  const iName = isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name_ar || item.name);
                  const iType = item.line_type || (parseFloat(item.total || item.price) < 0 ? 'return' : 'sale');
                  const isRet = iType === 'return' || parseFloat(item.total || item.price) < 0;
                  const itemTotal = item.total !== undefined ? item.total : (isRet ? -((item.qty || 1) * (item.price || 0)) : ((item.qty || 1) * (item.price || 0)));
                  return `
                  <tr style="border-bottom:1px solid rgba(255,255,255,0.05);${isRet ? 'background:rgba(239,68,68,0.08)' : ''}">
                    <td style="padding:6px;width:30px;color:var(--text-muted)">${itemIdx + 1}</td>
                    <td style="padding:6px;font-weight:600">
                      <div>${Utils.sanitize(iName || '-')}</div>
                      ${item.item_code ? `<span style="font-size:0.7rem;color:var(--text-muted)">[${item.item_code}]</span>` : ''}
                    </td>
                    <td style="padding:6px">
                      <span class="badge ${isRet ? 'badge-danger' : iType === 'damage' ? 'badge-warning' : iType === 'gift' ? 'badge-primary' : 'badge-success'}" style="font-size:0.7rem">
                        ${isRet ? (isAR ? '🔴 مرتجع' : '🔴 Return') : iType === 'damage' ? (isAR ? '🟠 تالف' : '🟠 Damaged') : iType === 'gift' ? (isAR ? '🎁 هدية' : '🎁 Gift') : (isAR ? '🟢 مبيع' : '🟢 Sale')}
                      </span>
                    </td>
                    <td style="padding:6px;font-weight:700">${item.qty || item.quantity || 1}</td>
                    <td style="padding:6px">${Utils.formatMoney(Math.abs(item.price || item.unit_price || 0))}</td>
                    <td style="padding:6px">${item.disc || item.disc_pct || 0}%</td>
                    <td style="padding:6px;font-weight:800;color:${isRet ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(itemTotal)}</td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>`}
          </div>
        </td>
      </tr>`;
    }).join('');
  }

  async function openSalesDoc(store, id) {
    const isAR   = i18n.getLang() === 'ar';
    const customers = window._salCustomers || await DB.getAll('customers');
    const items  = await DB.getAll('items');
    const users  = await DB.getAll('users');

    let doc = null;
    let lines = [];
    if (id) {
      doc   = await DB.get(store, id);
      const rawLines = doc?.items_json || doc?.items || '[]';
      lines = typeof rawLines === 'string' ? JSON.parse(rawLines) : (Array.isArray(rawLines) ? rawLines : []);
    }

    const labels = {
      sales:          { en: 'POS Sale / Order', ar: 'مبيعات نقاط البيع' },
      quotation:      { en: 'Quotation',          ar: 'عرض سعر' },
      delivery_order: { en: 'Delivery Order',     ar: 'أمر التسليم' },
      sales_invoice:  { en: 'Sales Invoice',      ar: 'فاتورة مبيعات' },
      sales_returns:  { en: 'Sales Return',       ar: 'مرتجع مبيعات' },
    };
    const lbl = labels[store] || { en: store, ar: store };

    document.getElementById('sal-modal-title').textContent = (id ? (isAR?'تعديل ':'Edit ') : (isAR?'جديد ':'New ')) + (isAR ? lbl.ar : lbl.en);

    window._salCurrentStore = store;
    window._salDocId        = id;
    window._salDocLines     = [...lines];
    window._salItems        = items;

    const vatRate = await DB.getSetting('vat_rate', 11);
    const vatEnabled = await DB.getSetting('vat_enabled', false);

    document.getElementById('sal-doc-body').innerHTML = `
    <div class="grid grid-3 mb-3">
      <div class="form-group">
        <label class="form-label">${isAR ? 'رقم الوثيقة' : 'Reference'}</label>
        <input type="text" class="form-control" id="sal-ref" value="${doc?.ref||doc?.receipt_no||''}" placeholder="${isAR?'تلقائي':'Auto'}">
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'التاريخ' : 'Date'}</label>
        <input type="date" class="form-control" id="sal-date" value="${(doc?.doc_date||doc?.created_at||'').substring(0,10) || Utils.today()}">
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'تاريخ الاستحقاق' : 'Due Date'}</label>
        <input type="date" class="form-control" id="sal-due-date" value="${(doc?.due_date||'').substring(0,10)}">
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'العميل' : 'Customer'}</label>
        <select class="form-control" id="sal-customer">
          <option value="">${isAR ? '-- عميل عابر --' : '-- Walk-in --'}</option>
          ${customers.map(c => `<option value="${c.id}" ${doc?.customer_id===c.id?'selected':''}>${isAR?(c.name_ar||c.name_en):(c.name_en||c.name_ar)}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'البائع' : 'Salesperson'}</label>
        <select class="form-control" id="sal-salesperson">
          <option value="">--</option>
          ${users.map(u => `<option value="${u.id}" ${doc?.salesperson_id===u.id?'selected':''}>${u.full_name||u.username}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'الحالة' : 'Status'}</label>
        <select class="form-control" id="sal-status">
          <option value="draft">Draft</option>
          <option value="confirmed">Confirmed</option>
          <option value="delivered">Delivered</option>
          <option value="invoiced">Invoiced</option>
          <option value="paid">Paid</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'العملة' : 'Currency'}</label>
        <select class="form-control" id="sal-currency">
          <option value="USD">USD</option>
          <option value="LBP">LBP</option>
          <option value="EUR">EUR</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
        <select class="form-control" id="sal-pay-method">
          <option value="cash" ${doc?.payment_method==='cash'?'selected':''}>${isAR?'نقداً':'Cash'}</option>
          <option value="credit" ${doc?.payment_method==='credit'?'selected':''}>${isAR?'آجل':'Credit'}</option>
          <option value="card" ${doc?.payment_method==='card'?'selected':''}>${isAR?'بطاقة':'Card'}</option>
          <option value="mixed" ${doc?.payment_method==='mixed'?'selected':''}>${isAR?'مختلط':'Mixed'}</option>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">${isAR ? 'شروط الدفع' : 'Payment Terms'}</label>
        <input type="text" class="form-control" id="sal-pay-terms" value="${doc?.payment_terms||''}" placeholder="${isAR?'مثال: 30 يوم':'e.g. 30 days'}">
      </div>
    </div>

    <div style="margin-bottom:12px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;gap:10px;flex-wrap:wrap">
        <strong style="font-size:0.85rem;display:flex;align-items:center;gap:6px">
          ${isAR ? 'الأصناف' : 'Line Items'}
          <span class="badge badge-primary" id="sal-lines-count">0</span>
        </strong>
        
        <div style="display:flex;gap:8px;align-items:center;flex:1;max-width:550px">
          <!-- Search Barcode / Name with Autocomplete & Scanner Enter Support -->
          <div style="position:relative;flex:1">
            <input type="text" class="form-control" id="sal-barcode-search" 
              placeholder="${isAR ? '🔍 امسح الباركود أو ابحث بالاسم / الكود...' : '🔍 Scan barcode or search item by name / SKU...'}"
              autocomplete="off"
              style="font-size:0.82rem;padding-left:32px"
              oninput="SalesModule.handleItemSearchInput(this.value)"
              onkeydown="if(event.key==='Enter'){ SalesModule.handleBarcodeEnter(this.value); event.preventDefault(); }">
            <svg style="position:absolute;left:10px;top:50%;transform:translateY(-50%);width:14px;height:14px;color:var(--text-muted);pointer-events:none" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 5v14M8 5v14M12 5v14M17 5v14M21 5v14"/>
            </svg>
            <!-- Dropdown Results -->
            <div id="sal-item-search-results" style="display:none;position:absolute;top:100%;left:0;right:0;max-height:240px;overflow-y:auto;background:var(--surface);border:1px solid var(--border-color);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.3);z-index:1050;margin-top:4px"></div>
          </div>

          <select class="form-control" id="sal-add-item" style="width:160px;font-size:0.78rem" onchange="if(this.value){SalesModule.addSalesLine();}">
            <option value="">${isAR ? '-- القائمة --' : '-- From List --'}</option>
            ${items.map(i => `<option value="${i.id}">[${i.item_code||''}] ${isAR?(i.name_ar||i.name_en):(i.name_en||i.name_ar)}</option>`).join('')}
          </select>
        </div>
      </div>

      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>#</th>
            <th>${isAR?'الصنف':'Item'}</th>
            <th>${isAR?'النوع / الحالة':'Type / Status'}</th>
            <th>${isAR?'الكمية':'Qty'}</th>
            <th>${isAR?'السعر':'Price'} ${(typeof Auth !== 'undefined' && Auth.isAdmin()) ? '<span title="' + (isAR?'متاح تعديله للمشرف':'Admin Editable') + '" style="cursor:help;font-size:0.75rem">✏️</span>' : '<span title="' + (isAR?'محمي - للمشرف فقط':'Protected - Admin only') + '" style="cursor:help;font-size:0.75rem">🔒</span>'}</th>
            <th>${isAR?'الخصم%':'Disc%'}</th>
            <th>${isAR?'الإجمالي':'Total'}</th>
            <th></th>
          </tr></thead>
          <tbody id="sal-lines-body"></tbody>
        </table>
      </div>
    </div>

    <div style="display:flex;justify-content:space-between;align-items:flex-end">
      <div class="form-group" style="flex:1;margin-right:20px">
        <label class="form-label">${isAR ? 'ملاحظات' : 'Notes'}</label>
        <textarea class="form-control" id="sal-notes" rows="2" placeholder="${isAR?'ملاحظات...':'Notes...'}">${doc?.notes||''}</textarea>
      </div>
      <div style="width:280px;font-size:0.82rem">
        <div style="display:flex;justify-content:space-between;margin-bottom:5px">
          <span style="color:var(--text-secondary)">${isAR?'المجموع الفرعي':'Subtotal'}</span>
          <span id="sal-subtotal" style="font-weight:600">$0.00</span>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:5px;align-items:center">
          <span style="color:var(--text-secondary)">${isAR?'خصم إجمالي%':'Overall Disc%'}</span>
          <input type="number" id="sal-disc" value="${doc?.discount_pct||doc?.discount||0}" min="0" max="100"
            style="width:60px;padding:3px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--text-primary);font-size:0.78rem;text-align:right"
            oninput="SalesModule.recalcSalesTotals()">
        </div>
        ${vatEnabled ? `<div style="display:flex;justify-content:space-between;margin-bottom:5px">
          <span style="color:var(--text-secondary)">VAT (${vatRate}%)</span>
          <span id="sal-vat" style="font-weight:600">$0.00</span>
        </div>` : ''}
        <div style="display:flex;justify-content:space-between;font-size:1rem;font-weight:900;border-top:2px solid var(--border-color);padding-top:6px;margin-top:6px">
          <span>${isAR?'الإجمالي':'Grand Total'}</span>
          <span id="sal-grand-total" style="color:var(--primary)">$0.00</span>
        </div>
      </div>
    </div>`;

    window._salVatRate    = vatRate;
    window._salVatEnabled = vatEnabled;
    if (doc?.status) document.getElementById('sal-status').value = doc.status;
    renderSalesLines();
    Utils.openModal('sal-modal');

    // Auto-focus search field
    setTimeout(() => {
      document.getElementById('sal-barcode-search')?.focus();
    }, 150);
  }

  function handleItemSearchInput(query) {
    const isAR = i18n.getLang() === 'ar';
    const resBox = document.getElementById('sal-item-search-results');
    if (!resBox) return;
    const q = (query || '').toLowerCase().trim();
    if (!q) {
      resBox.style.display = 'none';
      resBox.innerHTML = '';
      return;
    }

    const items = window._salItems || [];
    const matches = items.filter(i => {
      const nameEn = (i.name_en || '').toLowerCase();
      const nameAr = (i.name_ar || '').toLowerCase();
      const code   = (i.item_code || '').toLowerCase();
      const barcode = (i.barcode || '').toLowerCase();
      return nameEn.includes(q) || nameAr.includes(q) || code.includes(q) || barcode.includes(q);
    }).slice(0, 15);

    if (!matches.length) {
      resBox.innerHTML = `<div style="padding:12px;text-align:center;color:var(--text-muted);font-size:0.8rem">${isAR ? 'لا توجد نتائج مطابقة' : 'No matching items found'}</div>`;
      resBox.style.display = 'block';
      return;
    }

    resBox.innerHTML = matches.map(i => {
      const name = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
      const stock = i.stock_qty !== undefined ? i.stock_qty : '-';
      const stockColor = stock > 0 ? 'var(--success)' : 'var(--danger)';
      return `
      <div class="sal-search-row" style="padding:8px 12px;border-bottom:1px solid var(--border-color);cursor:pointer;display:flex;justify-content:space-between;align-items:center;transition:background 0.15s"
        onmouseover="this.style.background='var(--surface-2)'" 
        onmouseout="this.style.background='transparent'"
        onclick="SalesModule.selectSearchItem(${i.id})">
        <div>
          <div style="font-weight:700;font-size:0.84rem;color:var(--text-primary)">${Utils.sanitize(name)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);display:flex;gap:8px;margin-top:2px">
            ${i.item_code ? `<span>Code: <strong>${i.item_code}</strong></span>` : ''}
            ${i.barcode ? `<span>Barcode: <strong>${i.barcode}</strong></span>` : ''}
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-weight:800;font-size:0.9rem;color:var(--primary)">${Utils.formatMoney(i.selling_price || 0)}</div>
          <div style="font-size:0.72rem;color:${stockColor}">${isAR ? 'المخزون:' : 'Stock:'} ${stock}</div>
        </div>
      </div>`;
    }).join('');
    resBox.style.display = 'block';
  }

  function handleBarcodeEnter(query) {
    const q = (query || '').toLowerCase().trim();
    if (!q) return;
    const items = window._salItems || [];
    let item = items.find(i => (i.barcode || '').toLowerCase() === q);
    if (!item) item = items.find(i => (i.item_code || '').toLowerCase() === q);
    if (!item) item = items.find(i => (i.name_en || '').toLowerCase().includes(q) || (i.name_ar || '').toLowerCase().includes(q));

    if (item) {
      addItemToLines(item);
      const searchInput = document.getElementById('sal-barcode-search');
      if (searchInput) searchInput.value = '';
      const resBox = document.getElementById('sal-item-search-results');
      if (resBox) { resBox.style.display = 'none'; resBox.innerHTML = ''; }
      Utils.toast(i18n.t('common.saved'), 'success');
    } else {
      const isAR = i18n.getLang() === 'ar';
      Utils.toast(isAR ? 'لم يتم العثور على الصنف' : 'Item not found', 'warning');
    }
  }

  function selectSearchItem(itemId) {
    const item = (window._salItems || []).find(i => i.id === itemId);
    if (!item) return;
    addItemToLines(item);
    const searchInput = document.getElementById('sal-barcode-search');
    if (searchInput) { searchInput.value = ''; searchInput.focus(); }
    const resBox = document.getElementById('sal-item-search-results');
    if (resBox) { resBox.style.display = 'none'; resBox.innerHTML = ''; }
  }

  function addItemToLines(item) {
    window._salDocLines = window._salDocLines || [];
    const existing = window._salDocLines.find(l => l.item_id === item.id && (l.line_type||'sale') === 'sale');
    if (existing) {
      existing.qty = (parseFloat(existing.qty) || 1) + 1;
      const price = parseFloat(existing.price || existing.unit_price || item.selling_price || 0);
      const disc = parseFloat(existing.disc || 0);
      existing.total = Utils.round(existing.qty * price * (1 - disc / 100));
    } else {
      const price = parseFloat(item.selling_price) || 0;
      window._salDocLines.push({
        item_id: item.id,
        item_code: item.item_code,
        barcode: item.barcode,
        name_en: item.name_en,
        name_ar: item.name_ar,
        vat_type: item.vat_type || 'none',
        vat_rate: item.vat_rate || 0,
        qty: 1,
        price: price,
        disc: 0,
        line_type: 'sale',
        total: price
      });
    }
    renderSalesLines();
  }

  function renderSalesLines() {
    const isAR = i18n.getLang() === 'ar';
    const tbody = document.getElementById('sal-lines-body');
    if (!tbody) return;
    const lines = window._salDocLines || [];
    const isAdmin = (typeof Auth !== 'undefined' && Auth.isAdmin) ? Auth.isAdmin() : true;

    const countEl = document.getElementById('sal-lines-count');
    if (countEl) countEl.textContent = lines.length;

    tbody.innerHTML = lines.map((l, idx) => {
      const itemName = isAR ? (l.name_ar || l.name_en || l.title || l.name) : (l.name_en || l.name_ar || l.title || l.name);
      const itemCode = l.item_code || '';
      const lineType = l.line_type || ((parseFloat(l.total) < 0 || parseFloat(l.price) < 0) ? 'return' : 'sale');
      const isNegative = lineType === 'return' || parseFloat(l.total) < 0;

      return `
      <tr style="${lineType === 'return' ? 'background:rgba(239,68,68,0.06)' : lineType === 'damage' ? 'background:rgba(249,115,22,0.06)' : lineType === 'gift' ? 'background:rgba(236,72,153,0.06)' : ''}">
        <td style="width:30px">${idx+1}</td>
        <td style="font-weight:600;font-size:0.8rem">
          <div>${Utils.truncate(itemName, 28)}</div>
          ${itemCode ? `<span style="font-size:0.7rem;color:var(--text-muted)">[${itemCode}]</span>` : ''}
        </td>
        <td>
          <select class="form-control" style="font-size:0.75rem;padding:3px 6px;width:110px;font-weight:700" 
            onchange="SalesModule.updateSalesLine(${idx},'line_type',this.value)">
            <option value="sale" ${lineType==='sale'?'selected':''}>🟢 ${isAR?'مبيع (Sale)':'Sale'}</option>
            <option value="return" ${lineType==='return'?'selected':''}>🔴 ${isAR?'مرتجع (Return)':'Return'}</option>
            <option value="damage" ${lineType==='damage'?'selected':''}>🟠 ${isAR?'تالف (Damage)':'Damaged'}</option>
            <option value="gift" ${lineType==='gift'?'selected':''}>🎁 ${isAR?'هدية (Gift)':'Gift'}</option>
          </select>
        </td>
        <td>
          <input type="number" value="${l.qty||l.quantity||1}" min="0.001" step="0.001" 
            style="width:70px;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--text-primary);font-size:0.82rem" 
            onchange="SalesModule.updateSalesLine(${idx},'qty',this.value)">
        </td>
        <td>
          ${isAdmin ? `
          <input type="number" value="${Math.abs(l.price !== undefined ? l.price : (l.unit_price || 0))}" min="0" step="0.01" 
            title="${isAR ? 'سعر الوحدة (صلاحية المشرف)' : 'Unit Price (Admin Editable)'}"
            style="width:85px;padding:4px 6px;background:var(--input-bg);border:1px solid var(--primary);border-radius:6px;color:var(--text-primary);font-size:0.82rem;font-weight:700" 
            onchange="SalesModule.updateSalesLine(${idx},'price',this.value)">
          ` : `
          <input type="number" value="${Math.abs(l.price !== undefined ? l.price : (l.unit_price || 0))}" readonly 
            title="${isAR ? 'تعديل السعر محمي للمشرف فقط' : 'Price editing restricted to Admin'}"
            style="width:85px;padding:4px 6px;background:var(--surface-2);border:1px solid var(--border-color);border-radius:6px;color:var(--text-secondary);font-size:0.82rem;cursor:not-allowed;opacity:0.85">
          `}
        </td>
        <td>
          <input type="number" value="${l.disc||0}" min="0" max="100" 
            style="width:55px;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--text-primary);font-size:0.82rem" 
            onchange="SalesModule.updateSalesLine(${idx},'disc',this.value)">
        </td>
        <td style="font-weight:800;color:${isNegative ? 'var(--danger)' : 'var(--text-primary)'}">${Utils.formatMoney(l.total !== undefined ? l.total : (isNegative ? -((l.qty||1)*(l.price||0)) : ((l.qty||1)*(l.price||0))))}</td>
        <td><button class="btn-icon" onclick="SalesModule.removeSalesLine(${idx})" style="color:var(--danger)" title="${isAR?'حذف':'Remove'}">✕</button></td>
      </tr>`;
    }).join('') || `<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR?'لا توجد أصناف مضافة بعد. امسح الباركود أو ابحث أعلاه.':'No items added yet. Scan barcode or search above.'}</td></tr>`;
    recalcSalesTotals();
  }

  function addSalesLine() {
    const sel    = document.getElementById('sal-add-item');
    const itemId = parseInt(sel?.value);
    if (!itemId) return;
    const item = (window._salItems||[]).find(i => i.id === itemId);
    if (!item) return;
    addItemToLines(item);
    if (sel) sel.value = '';
  }

  function removeSalesLine(idx) { window._salDocLines.splice(idx, 1); renderSalesLines(); }

  function updateSalesLine(idx, field, val) {
    const l = window._salDocLines[idx];
    if (!l) return;
    if (field === 'line_type') {
      l.line_type = val;
    } else {
      l[field] = parseFloat(val) || 0;
    }
    const qty = parseFloat(l.qty || l.quantity || 1);
    const price = Math.abs(parseFloat(l.price || l.unit_price || 0));
    const disc = parseFloat(l.disc || 0);
    const type = l.line_type || 'sale';

    if (type === 'sale') {
      l.total = Utils.round(qty * price * (1 - disc / 100));
    } else if (type === 'return') {
      l.total = -Utils.round(qty * price * (1 - disc / 100));
    } else if (type === 'damage' || type === 'gift') {
      l.total = 0;
    }

    renderSalesLines();
  }

  function isLineTaxable(l) {
    if (!l) return false;
    const vt = String(l.vat_type || '').toLowerCase().trim();
    if (vt === 'none' || vt === 'exempt' || vt === 'zero') return false;
    if (vt === 'standard' || vt === 'taxable' || vt === 'vat') return true;
    if (l.is_taxable === false || l.taxable === false) return false;
    if (l.is_taxable === true || l.taxable === true || l.is_vat_taxable === true) return true;
    if (parseFloat(l.vat_rate) > 0) return true;
    return false;
  }

  function recalcSalesTotals() {
    const lines   = window._salDocLines || [];
    const sub     = lines.reduce((s, l) => s + (l.total !== undefined ? l.total : ((l.qty||1)*(l.price||0))), 0);
    const discPct = parseFloat(document.getElementById('sal-disc')?.value) || 0;
    const disc    = Utils.round(Math.max(0, sub) * discPct / 100);
    const after   = Math.max(0, sub - disc);

    let vat = 0;
    if (window._salVatEnabled) {
      const discountRatio = sub > 0 ? (after / sub) : 1;
      let totalVat = 0;
      for (const l of lines) {
        if (l.line_type === 'damage' || l.line_type === 'gift') continue;
        if (!isLineTaxable(l)) continue;
        const lineNet = (l.total !== undefined ? l.total : ((l.qty||1)*(l.price||0))) * discountRatio;
        const rate = (parseFloat(l.vat_rate) > 0) ? parseFloat(l.vat_rate) : (parseFloat(window._salVatRate) || 11);
        totalVat += lineNet * (rate / 100);
      }
      vat = Utils.round(totalVat);
    }

    const total   = Utils.round(after + vat);
    Utils.setHTML('#sal-subtotal',   Utils.formatMoney(sub));
    Utils.setHTML('#sal-vat',        Utils.formatMoney(vat));
    Utils.setHTML('#sal-grand-total',Utils.formatMoney(total));
    window._salGrandTotal = total;
    window._salSubtotal   = sub;
    window._salVatAmt     = vat;
    window._salDiscAmt    = disc;
  }

  async function saveSalesDoc(storeParam) {
    const store = window._salCurrentStore || window._salStore || storeParam;
    const isAR = i18n.getLang() === 'ar';
    if (store === 'sales_returns') {
      Utils.promptPassword(
        isAR ? '🔒 تأكيد كلمة المرور للمرتجع' : '🔒 Authorization Required',
        isAR ? 'يرجى إدخال كلمة مرور المشرف لإعتماد وتمرير مرتجع المبيعات:' : 'Enter Manager PIN to authorize Sales Return:',
        async () => {
          await _executeSaveSalesDoc(store);
        }
      );
    } else {
      await _executeSaveSalesDoc(store);
    }
  }

  async function _executeSaveSalesDoc(store) {
    const lines = window._salDocLines || [];
    const ref   = document.getElementById('sal-ref')?.value.trim() || await DB.nextSeq(store, window._salPrefix||'INV-', 5);
    const data  = {
      ref,
      receipt_no:     ref,
      doc_date:       document.getElementById('sal-date')?.value || Utils.today(),
      due_date:       document.getElementById('sal-due-date')?.value || '',
      customer_id:    parseInt(document.getElementById('sal-customer')?.value) || null,
      salesperson_id: parseInt(document.getElementById('sal-salesperson')?.value) || null,
      status:         document.getElementById('sal-status')?.value || 'draft',
      currency:       document.getElementById('sal-currency')?.value || 'USD',
      payment_method: document.getElementById('sal-pay-method')?.value || 'cash',
      payment_terms:  document.getElementById('sal-pay-terms')?.value || '',
      notes:          document.getElementById('sal-notes')?.value || '',
      items_json:     JSON.stringify(lines),
      items:          JSON.stringify(lines),
      subtotal:       window._salSubtotal || 0,
      discount_pct:   parseFloat(document.getElementById('sal-disc')?.value)||0,
      discount_amt:   window._salDiscAmt || 0,
      vat_amount:     window._salVatAmt || 0,
      grand_total:    window._salGrandTotal || 0,
      terminal_id:    localStorage.getItem('sync_node_id') || 'POS-1',
      branch_id:      localStorage.getItem('sync_branch_id') || 'main',
      branch_name:    (localStorage.getItem('sync_branch_id') === 'main' || !localStorage.getItem('sync_branch_id'))
        ? 'الفرع الرئيسي (Main Branch)'
        : (localStorage.getItem('sync_node_name') || localStorage.getItem('sync_branch_id')),
      uuid:           (typeof Utils !== 'undefined' && Utils.uid) ? Utils.uid() : `${localStorage.getItem('sync_branch_id') || 'main'}-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
    };

    let savedId = window._salDocId || null;
    try {
      if (window._salDocId) {
        const existing = await DB.get(store, window._salDocId);
        await DB.update(store, { ...(existing||{}), ...data, id: window._salDocId });
      } else {
        if (store === 'sales_invoice' && data.payment_method === 'credit' && data.customer_id) {
          data.credit_amount = data.grand_total;
          const cust = await DB.get('customers', data.customer_id);
          if (cust) {
            cust.balance = (parseFloat(cust.balance) || 0) + data.grand_total;
            await DB.update('customers', cust);
          }
        } else if (store === 'sales_returns' && data.customer_id) {
          const cust = await DB.get('customers', data.customer_id);
          if (cust) {
            cust.balance = (parseFloat(cust.balance) || 0) - (data.grand_total || 0);
            await DB.update('customers', cust);
          }
        }
        savedId = await DB.add(store, data);
        // Stock management
        const whId = 1; // Default warehouse ID
        if (store === 'sales_invoice' || store === 'delivery_order' || store === 'sales') {
          for (const l of lines) {
            const item = await DB.get('items', l.item_id);
            if (item) {
              if (!item.warehouse_stocks) item.warehouse_stocks = {};
              if (item.warehouse_stocks[whId] === undefined) item.warehouse_stocks[whId] = item.stock_qty || 0;
              
              const qty = l.qty || 1;
              item.warehouse_stocks[whId] = Math.max(0, (item.warehouse_stocks[whId] || 0) - qty);
              item.stock_qty = Math.max(0, (item.stock_qty || 0) - qty);
              
              // Box Link Logic
              if (item.selling_unit === 'box' && item.linked_item_id && item.pieces_per_box > 1) {
                const linked = await DB.get('items', item.linked_item_id);
                if (linked) {
                  if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
                  if (linked.warehouse_stocks[whId] === undefined) linked.warehouse_stocks[whId] = linked.stock_qty || 0;
                  
                  const linkedDelta = qty * item.pieces_per_box;
                  linked.warehouse_stocks[whId] = Math.max(0, (linked.warehouse_stocks[whId] || 0) - linkedDelta);
                  linked.stock_qty = Math.max(0, (linked.stock_qty || 0) - linkedDelta);
                  await DB.update('items', linked);
                }
              }
              
              await DB.update('items', item);
              await DB.add('stock_movements', {
                item_id: l.item_id,
                type: 'sale',
                ref,
                qty: -qty,
                notes: `Invoice Sale ${ref}`
              });
            }
          }
        } else if (store === 'sales_returns') {
          for (const l of lines) {
            const item = await DB.get('items', l.item_id);
            if (item) {
              if (!item.warehouse_stocks) item.warehouse_stocks = {};
              if (item.warehouse_stocks[whId] === undefined) item.warehouse_stocks[whId] = item.stock_qty || 0;
              
              const qty = l.qty || 1;
              item.warehouse_stocks[whId] = (item.warehouse_stocks[whId] || 0) + qty;
              item.stock_qty = (item.stock_qty || 0) + qty;
              
              // Box Link Logic
              if (item.selling_unit === 'box' && item.linked_item_id && item.pieces_per_box > 1) {
                const linked = await DB.get('items', item.linked_item_id);
                if (linked) {
                  if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
                  if (linked.warehouse_stocks[whId] === undefined) linked.warehouse_stocks[whId] = linked.stock_qty || 0;
                  
                  const linkedDelta = qty * item.pieces_per_box;
                  linked.warehouse_stocks[whId] = (linked.warehouse_stocks[whId] || 0) + linkedDelta;
                  linked.stock_qty = (linked.stock_qty || 0) + linkedDelta;
                  await DB.update('items', linked);
                }
              }
              
              await DB.update('items', item);
            }
            await DB.add('stock_movements', {
              item_id: l.item_id, type: 'return', ref, qty: l.qty||1,
              notes: `Sales Return ${ref}`
            });
          }
        }
      }
      if (window.BranchSync && typeof BranchSync.pushLocalTransactions === 'function') {
        try { BranchSync.pushLocalTransactions(); } catch(e) {}
      }
      Utils.closeModal('sal-modal');
      Utils.toast(i18n.t('common.saved'), 'success');
      await App.renderPage(App.getCurrentPage());
      return savedId;
    } catch(e) { Utils.toast('Error: ' + e.message, 'error'); return null; }
  }

  async function saveAndPrintSales(store) {
    const savedId = await saveSalesDoc(store);
    if (savedId) {
      await printSalesDoc(savedId, store);
    }
  }

  async function printSalesDoc(id, store) {
    const doc = await DB.get(store, id);
    if (!doc) return;
    const rawLines = doc.items_json || doc.items || '[]';
    const lines = typeof rawLines === 'string' ? JSON.parse(rawLines) : (Array.isArray(rawLines) ? rawLines : []);
    const isAR  = i18n.getLang() === 'ar';
    const invSize = await DB.getSetting('invoice_size', 'A4');
    const customers = await DB.getAll('customers');
    const cust  = customers.find(c => c.id === doc.customer_id) || (doc.customer_name ? { name_ar: doc.customer_name, name_en: doc.customer_name } : null);

    const docTitle = store === 'quotation' ? (isAR ? 'عرض سعر' : 'QUOTATION') : (isAR ? 'فاتورة ضريبية' : 'TAX INVOICE');

    if (invSize === '80mm' || invSize === '58mm') {
      if (window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
        return window.PrintEngine.printReceipt(doc, lines, cust, { doc_title: docTitle });
      }
    } else {
      if (window.PrintEngine && typeof window.PrintEngine.printInvoice === 'function') {
        return window.PrintEngine.printInvoice(doc, lines, cust, { doc_title: docTitle });
      }
    }

    const cur   = await DB.getSetting('currency_1', 'USD');
    const co    = await DB.getSetting('company_name', 'Store');
    const phone = await DB.getSetting('company_phone', '');
    const address = await DB.getSetting('company_address', '');
    const email = await DB.getSetting('company_email', '');
    const vatNumber = await DB.getSetting('vat_number', '');
    const logo = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    const custName = cust ? (isAR ? (cust.name_ar||cust.name_en) : (cust.name_en||cust.name_ar)) : (doc.customer_name || (isAR ? 'عميل عابر' : 'Walk-in'));
    const showLogo = printLogo && logo;

    let html = '';
    if (invSize === '80mm' || invSize === '58mm') {
      html = `
      <div class="receipt-80mm" dir="${isAR?'rtl':'ltr'}" style="text-align:center;font-family:'Cairo','Inter',sans-serif;padding:4px">
        ${showLogo ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain;margin-bottom:6px">` : ''}
        <h2 style="font-size:1.1rem;font-weight:800;margin:0 0 2px">${Utils.sanitize(co)}</h2>
        ${address ? `<p style="margin:2px 0;font-size:0.75rem;color:#444">${Utils.sanitize(address)}</p>` : ''}
        ${phone ? `<p style="margin:2px 0;font-size:0.75rem;color:#444">${isAR ? 'الهاتف: ' : 'Phone: '}<bdi>${Utils.sanitize(phone)}</bdi></p>` : ''}
        ${vatNumber ? `<p style="margin:2px 0;font-size:0.75rem;color:#444"><strong>${isAR ? 'الرقم المالي: ' : 'Tax ID: '}<bdi>${Utils.sanitize(vatNumber)}</bdi></strong></p>` : ''}
        <div style="border-top:1px dashed #000;margin:8px 0"></div>
        <div style="font-weight:800;font-size:0.9rem">${docTitle}</div>
        <div style="font-size:0.8rem"># <bdi>${doc.ref || doc.receipt_no || ('INV-' + doc.id)}</bdi></div>
        <div style="font-size:0.75rem;color:#555"><bdi>${Utils.formatDateTime(doc.created_at || doc.doc_date)}</bdi></div>
        <div style="font-size:0.8rem;margin-top:4px"><strong>${isAR ? 'العميل: ' : 'Customer: '}</strong>${custName}</div>
        <div style="border-top:1px dashed #000;margin:8px 0"></div>
        <table style="width:100%;font-size:0.75rem;border-collapse:collapse;text-align:${isAR?'right':'left'}">
          <thead>
            <tr style="border-bottom:1px dashed #000">
              <th>${isAR?'الصنف':'Item'}</th>
              <th style="text-align:center">${isAR?'الكمية':'Qty'}</th>
              <th style="text-align:${isAR?'left':'right'}">${isAR?'الإجمالي':'Total'}</th>
            </tr>
          </thead>
          <tbody>
            ${lines.map(l => `
              <tr>
                <td>${isAR?(l.name_ar||l.name_en||l.title||l.name):(l.name_en||l.name_ar||l.title||l.name)}</td>
                <td style="text-align:center">${l.qty||l.quantity||1}</td>
                <td style="text-align:${isAR?'left':'right'}"><bdi>${cur} ${Utils.formatCurrency(l.total||((l.qty||1)*(l.price||0))||0)}</bdi></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        <div style="border-top:1px dashed #000;margin:8px 0"></div>
        <div style="display:flex;justify-content:space-between;font-size:0.8rem;margin:2px 0">
          <span>${isAR?'المجموع:':'Subtotal:'}</span>
          <span><bdi>${cur} ${Utils.formatCurrency(doc.subtotal||doc.grand_total||0)}</bdi></span>
        </div>
        ${doc.discount_amt>0?`<div style="display:flex;justify-content:space-between;font-size:0.8rem;margin:2px 0;color:#dc2626"><span>${isAR?'الخصم:':'Discount:'}</span><span><bdi>-${cur} ${Utils.formatCurrency(doc.discount_amt)}</bdi></span></div>`:''}
        ${doc.vat_amount>0?`<div style="display:flex;justify-content:space-between;font-size:0.8rem;margin:2px 0"><span>VAT:</span><span><bdi>${cur} ${Utils.formatCurrency(doc.vat_amount)}</bdi></span></div>`:''}
        <div style="display:flex;justify-content:space-between;font-size:1rem;font-weight:900;margin:6px 0;border-top:1px dashed #000;padding-top:4px">
          <span>${isAR?`الإجمالي (<bdi>${cur}</bdi>):`:`TOTAL (${cur}):`}</span>
          <span><bdi>${cur} ${Utils.formatCurrency(doc.grand_total)}</bdi></span>
        </div>
        ${doc.notes ? `<div style="font-size:0.75rem;margin-top:6px;border-top:1px dashed #ccc;padding-top:4px">${doc.notes}</div>` : ''}
        <div style="font-size:0.75rem;margin-top:8px;color:#555">${isAR?'شكراً لزيارتكم!':'Thank you for your visit!'}</div>
      </div>`;
    } else {
      html = `
      <div class="doc-a4" dir="${isAR?'rtl':'ltr'}" style="padding:10px">
        <div class="doc-header" style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;border-bottom:2px solid #cbd5e1;padding-bottom:15px">
          <div class="doc-company-info" style="display:flex;gap:15px;align-items:center">
            ${showLogo ? `<img src="${logo}" style="max-width:80px;max-height:80px;object-fit:contain">` : ''}
            <div>
              <h2 style="font-size:1.6rem;font-weight:800;margin:0 0 5px">${Utils.sanitize(co)}</h2>
              ${address ? `<p style="margin:2px 0;font-size:0.85rem;color:#475569">${Utils.sanitize(address)}</p>` : ''}
              ${phone ? `<p style="margin:2px 0;font-size:0.85rem;color:#475569">${isAR ? 'الهاتف: ' : 'Phone: '}<bdi>${Utils.sanitize(phone)}</bdi></p>` : ''}
              ${email ? `<p style="margin:2px 0;font-size:0.85rem;color:#475569">${isAR ? 'البريد: ' : 'Email: '}${Utils.sanitize(email)}</p>` : ''}
              ${vatNumber ? `<p style="margin:2px 0;font-size:0.85rem;color:#475569"><strong>${isAR ? 'الرقم المالي: ' : 'Tax ID: '}<bdi>${Utils.sanitize(vatNumber)}</bdi></strong></p>` : ''}
            </div>
          </div>
          <div class="doc-title-block" style="text-align:${isAR?'left':'right'}">
            <h1 style="font-size:2rem;color:#3b82f6;margin:0 0 5px">${docTitle}</h1>
            <div class="doc-number" style="font-weight:700;font-size:1.1rem"># <bdi>${doc.ref || doc.receipt_no || ('INV-' + doc.id)}</bdi></div>
            <div class="doc-date"><strong>${isAR ? 'التاريخ والوقت: ' : 'Date & Time: '}</strong><bdi>${Utils.formatDateTime(doc.created_at || doc.doc_date)}</bdi></div>
            ${doc.due_date ? `<div class="doc-date"><strong>${isAR ? 'الاستحقاق: ' : 'Due Date: '}</strong><bdi>${Utils.formatDate(doc.due_date)}</bdi></div>` : ''}
          </div>
        </div>
        <div class="doc-parties">
          <div class="doc-party"><h3>${isAR ? 'إلى / العميل' : 'Bill To'}</h3><p style="font-weight:700">${custName}</p></div>
          <div class="doc-party" style="text-align:${isAR?'left':'right'}"><h3>${isAR ? 'طريقة الدفع' : 'Payment Method'}</h3><p style="font-weight:700;color:#2563eb">${(doc.payment_method || 'CASH').toUpperCase()}</p><span>${doc.payment_terms||''}</span></div>
        </div>
        <table class="doc-table">
          <thead><tr>
            <th style="text-align:center">#</th><th style="text-align:${isAR?'right':'left'}">${isAR?'الصنف':'Item'}</th>
            <th style="text-align:center">${isAR?'الكمية':'Qty'}</th><th style="text-align:${isAR?'left':'right'}">${isAR?'السعر':'Price'}</th>
            <th style="text-align:${isAR?'left':'right'}">${isAR?'الخصم':'Disc%'}</th><th style="text-align:${isAR?'left':'right'}">${isAR?'الإجمالي':'Total'}</th>
          </tr></thead>
          <tbody>
            ${lines.map((l,i) => `<tr>
              <td style="text-align:center">${i+1}</td>
              <td style="text-align:${isAR?'right':'left'}">${isAR?(l.name_ar||l.name_en||l.title||l.name):(l.name_en||l.name_ar||l.title||l.name)}</td>
              <td style="text-align:center">${l.qty||l.quantity||1}</td>
              <td style="text-align:${isAR?'left':'right'}"><bdi>${cur} ${Utils.formatCurrency(l.price||l.unit_price||0)}</bdi></td>
              <td style="text-align:${isAR?'left':'right'}">${l.disc||0}%</td>
              <td style="text-align:${isAR?'left':'right'}"><bdi>${cur} ${Utils.formatCurrency(l.total||((l.qty||1)*(l.price||0))||0)}</bdi></td>
            </tr>`).join('')}
          </tbody>
        </table>
        <div class="doc-totals">
          <table>
            <tr><td>${isAR?'المجموع':'Subtotal'}</td><td style="text-align:${isAR?'left':'right'}"><bdi>${cur} ${Utils.formatCurrency(doc.subtotal||doc.grand_total||0)}</bdi></td></tr>
            ${doc.discount_amt>0?`<tr><td>${isAR?'الخصم':'Discount'}</td><td style="text-align:${isAR?'left':'right'};color:#e74c3c"><bdi>-${cur} ${Utils.formatCurrency(doc.discount_amt)}</bdi></td></tr>`:''}
            ${doc.vat_amount>0?`<tr><td>VAT</td><td style="text-align:${isAR?'left':'right'}"><bdi>${cur} ${Utils.formatCurrency(doc.vat_amount)}</bdi></td></tr>`:''}
            <tr class="total-row"><td>${isAR?`الإجمالي (<bdi>${cur}</bdi>)`:`TOTAL (${cur})`}</td><td style="text-align:${isAR?'left':'right'}"><bdi>${cur} ${Utils.formatCurrency(doc.grand_total)}</bdi></td></tr>
          </table>
        </div>
        <div class="doc-footer" style="margin-top:60px">
          <div class="doc-footer-section"><h4>${isAR?'ملاحظات':'Notes'}</h4><p>${doc.notes||'-'}</p></div>
          <div class="doc-signature">${isAR?'توقيع العميل':'Customer Signature'}</div>
          <div class="doc-signature">${isAR?'توقيع المسؤول':'Authorized Signature'}</div>
        </div>
      </div>`;
    }

    Utils.printElement(html, doc.ref || doc.receipt_no || (`INV-${doc.id}`), invSize);
  }

  function searchSales() {
    const q = (document.getElementById('sal-search')?.value || '').toLowerCase().trim();
    const statusFilter = (document.getElementById('sal-status-filter')?.value || '').toLowerCase().trim();
    const dateFrom = document.getElementById('sal-from')?.value || '';
    const dateTo   = document.getElementById('sal-to')?.value || '';

    const tbody = document.getElementById('sal-tbody');
    if (!tbody) return;

    tbody.querySelectorAll('tr').forEach(r => {
      if (r.cells.length < 5) return;
      const rowText = r.textContent.toLowerCase();
      const matchQuery = !q || rowText.includes(q);

      const statusText = r.cells[4]?.textContent.toLowerCase().trim() || '';
      const matchStatus = !statusFilter || statusText === statusFilter || statusText.includes(statusFilter);

      let matchDate = true;
      const rowDateStr = r.cells[1]?.textContent.trim();
      if (rowDateStr && (dateFrom || dateTo)) {
        const rowDate = new Date(rowDateStr);
        if (dateFrom && rowDate < new Date(dateFrom)) matchDate = false;
        if (dateTo && rowDate > new Date(dateTo + 'T23:59:59')) matchDate = false;
      }

      r.style.display = (matchQuery && matchStatus && matchDate) ? '' : 'none';
    });
  }

  async function deleteDoc(store, id) {
    const isAR = i18n.getLang() === 'ar';
    Utils.confirm(isAR ? 'هل أنت متأكد من حذف هذه الوثيقة / الفاتورة؟' : 'Are you sure you want to delete this invoice/document?', async () => {
      await DB.remove(store, id);
      Utils.toast(i18n.t('common.saved'), 'success');
      await App.renderPage(App.getCurrentPage());
    });
  }

  async function exportSales(store) {
    const docs = await DB.getAll(store);
    Utils.exportCSV(docs.map(d => ({ Ref: d.ref, Date: d.doc_date, Customer: d.customer_id, Total: d.grand_total, Status: d.status })), store);
  }

  async function exportSales(store) {
    const docs = await DB.getAll(store);
    Utils.exportCSV(docs.map(d => ({ Ref: d.ref, Date: d.doc_date, Customer: d.customer_id, Total: d.grand_total, Status: d.status })), store);
  }

  const STD_STATUSES = [
    { v: 'draft', en: 'Draft', ar: 'مسودة' },
    { v: 'confirmed', en: 'Confirmed', ar: 'مؤكد' },
    { v: 'delivered', en: 'Delivered', ar: 'تم التسليم' },
    { v: 'invoiced', en: 'Invoiced', ar: 'فاتورة' },
    { v: 'cancelled', en: 'Cancelled', ar: 'ملغى' },
  ];

  return {
    renderQuotation: (c) => renderSalesDoc(c, 'quotation',      'Quotations',       'عروض الأسعار',     'QUO-', STD_STATUSES),
    renderOrder:     (c) => renderSalesDoc(c, 'sales_orders',   'Sales Orders',     'أوامر البيع',      'SO-',  STD_STATUSES),
    renderDelivery:  (c) => renderSalesDoc(c, 'delivery_order', 'Delivery Orders',  'أوامر التسليم',    'DO-',  STD_STATUSES),
    renderInvoice:   (c) => renderSalesDoc(c, 'sales_invoice',  'Sales Invoices',   'فواتير المبيعات',  'INV-', STD_STATUSES),
    renderReturn:    (c) => renderSalesDoc(c, 'sales_returns',  'Sales Returns',    'مرتجعات المبيعات', 'RET-', [
      { v: 'pending', en: 'Pending', ar: 'معلق' },
      { v: 'approved', en: 'Approved', ar: 'معتمد' },
      { v: 'completed', en: 'Completed', ar: 'مكتمل' },
    ]),
    openSalesDoc, addSalesLine, removeSalesLine, updateSalesLine, recalcSalesTotals,
    handleItemSearchInput, handleBarcodeEnter, selectSearchItem, addItemToLines,
    saveSalesDoc, saveAndPrintSales, printSalesDoc, deleteDoc, exportSales, searchSales,
    toggleRowDetail: (rowId) => {
      const el = document.getElementById(rowId);
      const btn = document.getElementById(`btn-${rowId}`);
      if (!el) return;
      if (el.style.display === 'none' || !el.style.display) {
        el.style.display = 'table-row';
        if (btn) btn.textContent = '▼';
      } else {
        el.style.display = 'none';
        if (btn) btn.textContent = '▶';
      }
    }
  };
})();

window.SalesModule = SalesModule;
