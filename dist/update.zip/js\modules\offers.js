/* ================================================================
   Red Shark POS — Offers & Deals Management Module
   ================================================================ */

const Offers = (() => {
  let _offers = [];
  let _items = [];
  let _editingId = null;

  async function render(container) {
    _offers = await DB.getAll('offers');
    _items  = await DB.getAll('items');
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const cur1 = await DB.getSetting('currency_1', 'USD');

    container.innerHTML = `
    <div class="animate-slide">
      <!-- Page Header -->
      <div class="page-header">
        <div class="page-header-left">
          <h1>🏷️ ${isAR ? 'إدارة العروض والخصومات الخاصة' : 'Offers & Special Deals Management'}</h1>
          <p>${isAR ? 'حدد عروض الحزم (مثال: اشتري 3 بـ 5$)، واشتري X واحصل على Y مجاناً' : 'Setup quantity breaks (e.g. Buy 3 for $5), Buy-X-Get-Y free, & item discounts'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Offers.openModal()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'إضافة عرض جديد' : 'New Offer / Deal'}
          </button>
        </div>
      </div>

      <!-- Quick Summary KPI Stats -->
      <div class="grid grid-3 mb-4">
        <div class="card" style="padding:16px;background:linear-gradient(135deg,rgba(239,68,68,0.1),rgba(168,85,247,0.1));border:1px solid rgba(168,85,247,0.2)">
          <div style="font-size:0.78rem;color:var(--text-muted);font-weight:600">${isAR ? 'إجمالي العروض' : 'Total Offers'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:var(--text-primary);margin-top:4px">${_offers.length}</div>
        </div>
        <div class="card" style="padding:16px;background:linear-gradient(135deg,rgba(16,185,129,0.1),rgba(6,182,212,0.1));border:1px solid rgba(16,185,129,0.2)">
          <div style="font-size:0.78rem;color:var(--text-muted);font-weight:600">${isAR ? 'العروض النشطة' : 'Active Offers'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:var(--success);margin-top:4px">${_offers.filter(o => o.status !== 'inactive').length}</div>
        </div>
        <div class="card" style="padding:16px;background:linear-gradient(135deg,rgba(245,158,11,0.1),rgba(239,68,68,0.1));border:1px solid rgba(245,158,11,0.2)">
          <div style="font-size:0.78rem;color:var(--text-muted);font-weight:600">${isAR ? 'عروض الحزم (3 بـ 5$)' : 'Quantity Bundle Deals'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:#c084fc;margin-top:4px">${_offers.filter(o => o.type === 'bundle_price').length}</div>
        </div>
      </div>

      <!-- Offers Grid -->
      <div id="offers-list-container">
        ${renderOffersGrid(_offers, isAR, cur1)}
      </div>
    </div>

    <!-- Modal Form -->
    <div class="modal-overlay" id="offer-modal">
      <div class="modal" style="max-width:540px">
        <div class="modal-header" style="background:linear-gradient(135deg,rgba(239,68,68,0.15),rgba(168,85,247,0.15))">
          <div class="modal-title" id="offer-modal-title">
            🏷️ ${isAR ? 'إضافة عرض جديد' : 'New Offer / Deal'}
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('offer-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-2">
            
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label">${isAR ? 'عنوان العرض / الوصف' : 'Offer Title / Name'}</label>
              <input type="text" class="form-control" id="offer-name" placeholder="${isAR ? 'مثال: اشتري 3 بـ 5$ فقط' : 'e.g. Buy 3 for $5.00 Special'}">
            </div>

            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label">${isAR ? 'اختر الصنف' : 'Target Item'}</label>
              <select class="form-control" id="offer-item-id" onchange="Offers.onItemSelect(this.value)">
                <option value="">${isAR ? '— اختر الصنف —' : '— Select Item —'}</option>
                ${_items.map(i => {
                  const n = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
                  return `<option value="${i.id}">${Utils.sanitize(n)} (${cur1} ${Utils.formatCurrency(i.selling_price)})</option>`;
                }).join('')}
              </select>
            </div>

            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label">${isAR ? 'نوع العرض' : 'Offer Type'}</label>
              <select class="form-control" id="offer-type" onchange="Offers.onTypeChange(this.value)">
                <option value="bundle_price">📦 ${isAR ? 'حزمة كميات بسعر مخفض (مثال: اشتري 3 بـ 5$)' : 'Quantity Bundle Price (e.g. Buy 3 for $5.00)'}</option>
                <option value="buy_x_get_y">🎁 ${isAR ? 'اشتري X واحصل على Y مجاناً (Buy X Get Y Free)' : 'Buy X Get Y Free (e.g. Buy 2 Get 1 Free)'}</option>
                <option value="discount_pct">🏷️ ${isAR ? 'نسبة خصم مئوية على الصنف %' : 'Percentage Discount on Item %'}</option>
              </select>
            </div>

            <!-- Bundle Price Fields -->
            <div class="form-group" id="field-min-qty">
              <label class="form-label">${isAR ? 'الكمية المطلوبة (X)' : 'Required Quantity (X)'}</label>
              <input type="number" class="form-control" id="offer-min-qty" value="3" min="1" step="1">
            </div>

            <div class="form-group" id="field-bundle-price">
              <label class="form-label" id="lbl-bundle-val">${isAR ? `سعر الحزمة الإجمالي (${cur1})` : `Bundle Total Price (${cur1})`}</label>
              <input type="number" class="form-control" id="offer-bundle-price" value="5.00" min="0.01" step="0.01">
            </div>

            <div class="form-group" id="field-free-qty" style="display:none">
              <label class="form-label">${isAR ? 'الكمية المجانية الممنوحة (Y)' : 'Free Quantity Given (Y)'}</label>
              <input type="number" class="form-control" id="offer-free-qty" value="1" min="1" step="1">
            </div>

            <!-- Start & End Date -->
            <div class="form-group">
              <label class="form-label">${isAR ? 'تاريخ البدء (اختياري)' : 'Start Date (Optional)'}</label>
              <input type="date" class="form-control" id="offer-start-date">
            </div>

            <div class="form-group">
              <label class="form-label">${isAR ? 'تاريخ الانتهاء (اختياري)' : 'End Date (Optional)'}</label>
              <input type="date" class="form-control" id="offer-end-date">
            </div>

            <div class="form-group" style="grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:8px">
              <div>
                <div style="font-weight:700;font-size:0.85rem">${isAR ? 'تفعيل العرض في الكاشير' : 'Active in POS'}</div>
                <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'يطبق الخصم تلقائياً عند مسح الصنف في سلة المبيعات' : 'Applies automatically when item is scanned in POS cart'}</div>
              </div>
              <label class="toggle"><input type="checkbox" id="offer-status" checked><span class="toggle-slider"></span></label>
            </div>

          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('offer-modal')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Offers.save()">${isAR ? 'حفظ العرض' : 'Save Offer'}</button>
        </div>
      </div>
    </div>`;
  }

  function renderOffersGrid(offers, isAR, cur1) {
    if (!offers || !offers.length) {
      return `
      <div class="empty-state">
        <div style="font-size:42px;margin-bottom:10px">🏷️</div>
        <h3>${isAR ? 'لا توجد عروض حالياً' : 'No Active Offers Yet'}</h3>
        <p>${isAR ? 'قم بإنشاء عروض خاصة مثل اشتري 3 بـ 5$ لزيادة مبيعاتك' : 'Create quantity bundles or Buy-X-Get-Y deals to boost store sales'}</p>
        <button class="btn btn-primary" onclick="Offers.openModal()" style="margin-top:12px">
          + ${isAR ? 'إضافة أول عرض' : 'Add First Offer'}
        </button>
      </div>`;
    }

    return `
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px">
      ${offers.map(o => {
        const item = _items.find(i => i.id === o.item_id) || {};
        const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar) || 'Deleted Item';
        const isActive = o.status !== 'inactive';
        
        let typeBadge = '';
        let formulaText = '';

        if (o.type === 'bundle_price') {
          typeBadge = `<span class="badge" style="background:rgba(168,85,247,0.15);color:#c084fc;font-weight:700">📦 ${isAR ? 'حزمة كميات' : 'Bundle Price'}</span>`;
          formulaText = isAR 
            ? `اشتري <strong>${o.min_qty}</strong> حبات بسعر <strong>${cur1} ${Utils.formatCurrency(o.bundle_price)}</strong> (بدل ${cur1} ${Utils.formatCurrency((item.selling_price||0) * o.min_qty)})`
            : `Buy <strong>${o.min_qty}</strong> units for <strong>${cur1} ${Utils.formatCurrency(o.bundle_price)}</strong> (reg. ${cur1} ${Utils.formatCurrency((item.selling_price||0) * o.min_qty)})`;
        } else if (o.type === 'buy_x_get_y') {
          typeBadge = `<span class="badge" style="background:rgba(16,185,129,0.15);color:#10b981;font-weight:700">🎁 ${isAR ? 'مجاني' : 'Buy X Get Y'}</span>`;
          formulaText = isAR 
            ? `اشتري <strong>${o.min_qty}</strong> واحصل على <strong>${o.free_qty || 1}</strong> مجاناً!`
            : `Buy <strong>${o.min_qty}</strong>, get <strong>${o.free_qty || 1}</strong> Free!`;
        } else {
          typeBadge = `<span class="badge" style="background:rgba(239,68,68,0.15);color:#ef4444;font-weight:700">🏷️ ${isAR ? 'خصم مئوي' : 'Discount %'}</span>`;
          formulaText = isAR ? `خصم <strong>${o.discount_pct}%</strong> على سعر الحبة` : `<strong>${o.discount_pct}% OFF</strong> item price`;
        }

        return `
        <div class="card" style="padding:16px;border:1px solid ${isActive ? 'rgba(168,85,247,0.3)' : 'var(--border-color)'};opacity:${isActive?1:0.65};position:relative;display:flex;flex-direction:column;justify-content:space-between">
          <div>
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
              ${typeBadge}
              <span class="badge ${isActive ? 'badge-success' : 'badge-secondary'}">${isActive ? (isAR ? 'نشط' : 'Active') : (isAR ? 'معطل' : 'Disabled')}</span>
            </div>

            <div style="font-size:1.05rem;font-weight:800;color:var(--text-primary);margin-bottom:4px">
              ${Utils.sanitize(o.name || itemName)}
            </div>
            <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:10px">
              📦 ${Utils.sanitize(itemName)} (${cur1} ${Utils.formatCurrency(item.selling_price || 0)})
            </div>

            <div style="padding:10px;background:var(--surface-2);border-radius:8px;font-size:0.82rem;line-height:1.4;margin-bottom:12px">
              ${formulaText}
            </div>

            ${(o.start_date || o.end_date) ? `
              <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:10px">
                📅 ${o.start_date || 'Anytime'} ➔ ${o.end_date || 'Unlimited'}
              </div>` : ''}
          </div>

          <div style="display:flex;gap:6px;border-top:1px solid var(--border-color);padding-top:12px;margin-top:6px">
            <button class="btn btn-secondary btn-sm flex-1" onclick="Offers.edit(${o.id})">
              ✏️ ${isAR ? 'تعديل' : 'Edit'}
            </button>
            <button class="btn btn-ghost btn-sm" onclick="Offers.toggleStatus(${o.id})" title="${isActive ? 'Disable' : 'Enable'}">
              ${isActive ? '⏸️' : '▶️'}
            </button>
            <button class="btn btn-danger btn-sm" onclick="Offers.deleteOffer(${o.id})">
              🗑️
            </button>
          </div>
        </div>`;
      }).join('')}
    </div>`;
  }

  function onTypeChange(type) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const cur1 = window._primaryCurrency || 'USD';
    const fieldBundlePrice = document.getElementById('field-bundle-price');
    const fieldFreeQty = document.getElementById('field-free-qty');
    const lblBundleVal = document.getElementById('lbl-bundle-val');

    if (type === 'bundle_price') {
      fieldBundlePrice.style.display = 'block';
      fieldFreeQty.style.display = 'none';
      if (lblBundleVal) lblBundleVal.textContent = isAR ? `سعر الحزمة الإجمالي (${cur1})` : `Bundle Total Price (${cur1})`;
    } else if (type === 'buy_x_get_y') {
      fieldBundlePrice.style.display = 'none';
      fieldFreeQty.style.display = 'block';
    } else { // discount_pct
      fieldBundlePrice.style.display = 'block';
      fieldFreeQty.style.display = 'none';
      if (lblBundleVal) lblBundleVal.textContent = isAR ? 'نسبة الخصم (%)' : 'Discount Percentage (%)';
    }
  }

  function onItemSelect(itemId) {
    const item = _items.find(i => i.id == itemId);
    if (!item) return;
    const nameInput = document.getElementById('offer-name');
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const n = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    if (nameInput && !nameInput.value) {
      nameInput.value = isAR ? `عرض خاص على ${n}` : `Special Offer on ${n}`;
    }
  }

  async function openModal(id = null) {
    _editingId = id;
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const titleEl = document.getElementById('offer-modal-title');
    if (titleEl) {
      titleEl.textContent = (id ? (isAR ? 'تعديل العرض' : 'Edit Offer') : (isAR ? 'إضافة عرض جديد' : 'New Offer / Deal'));
    }

    if (id) {
      const o = await DB.get('offers', id);
      if (o) {
        document.getElementById('offer-name').value = o.name || '';
        document.getElementById('offer-item-id').value = o.item_id || '';
        document.getElementById('offer-type').value = o.type || 'bundle_price';
        document.getElementById('offer-min-qty').value = o.min_qty || 3;
        document.getElementById('offer-bundle-price').value = (o.type === 'discount_pct' ? o.discount_pct : o.bundle_price) || 5;
        document.getElementById('offer-free-qty').value = o.free_qty || 1;
        document.getElementById('offer-start-date').value = o.start_date || '';
        document.getElementById('offer-end-date').value = o.end_date || '';
        document.getElementById('offer-status').checked = o.status !== 'inactive';
        onTypeChange(o.type || 'bundle_price');
      }
    } else {
      document.getElementById('offer-name').value = '';
      document.getElementById('offer-item-id').value = _items[0]?.id || '';
      document.getElementById('offer-type').value = 'bundle_price';
      document.getElementById('offer-min-qty').value = 3;
      document.getElementById('offer-bundle-price').value = 5.00;
      document.getElementById('offer-free-qty').value = 1;
      document.getElementById('offer-start-date').value = '';
      document.getElementById('offer-end-date').value = '';
      document.getElementById('offer-status').checked = true;
      onTypeChange('bundle_price');
    }

    Utils.openModal('offer-modal');
  }

  async function save() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const name = document.getElementById('offer-name')?.value?.trim() || '';
    const itemId = parseInt(document.getElementById('offer-item-id')?.value);
    const type = document.getElementById('offer-type')?.value || 'bundle_price';
    const minQty = parseInt(document.getElementById('offer-min-qty')?.value) || 1;
    const bundleVal = parseFloat(document.getElementById('offer-bundle-price')?.value) || 0;
    const freeQty = parseInt(document.getElementById('offer-free-qty')?.value) || 1;
    const startDate = document.getElementById('offer-start-date')?.value || null;
    const endDate = document.getElementById('offer-end-date')?.value || null;
    const isActive = document.getElementById('offer-status')?.checked;

    if (!itemId) {
      Utils.toast(isAR ? 'يرجى اختيار الصنف' : 'Please select an item', 'warning');
      return;
    }

    const data = {
      name,
      item_id: itemId,
      type,
      min_qty: minQty,
      bundle_price: type === 'bundle_price' ? bundleVal : null,
      discount_pct: type === 'discount_pct' ? bundleVal : null,
      free_qty: type === 'buy_x_get_y' ? freeQty : null,
      start_date: startDate,
      end_date: endDate,
      status: isActive ? 'active' : 'inactive',
      updated_at: new Date().toISOString()
    };

    try {
      if (_editingId) {
        await DB.update('offers', { ...data, id: _editingId });
        Utils.toast(isAR ? 'تم تحديث العرض بنجاح' : 'Offer updated successfully!', 'success');
      } else {
        await DB.add('offers', data);
        Utils.toast(isAR ? 'تم إنشاء العرض بنجاح' : 'Offer created successfully!', 'success');
      }

      Utils.closeModal('offer-modal');
      if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
        BranchSync.notifyChange('offers', data);
      }
      if (window.OnlineOrders && typeof OnlineOrders.syncCloudTables === 'function') {
        try { await OnlineOrders.syncCloudTables(); } catch(e){}
      }
      const container = document.getElementById('page-content');
      if (container) render(container);
    } catch (e) {
      Utils.toast('Error: ' + e.message, 'error');
    }
  }

  async function edit(id) {
    await openModal(id);
  }

  async function toggleStatus(id) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const o = await DB.get('offers', id);
    if (!o) return;
    o.status = o.status === 'inactive' ? 'active' : 'inactive';
    await DB.update('offers', o);
    if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
      BranchSync.notifyChange('offers', o);
    }
    if (window.OnlineOrders && typeof OnlineOrders.syncCloudTables === 'function') {
      try { await OnlineOrders.syncCloudTables(); } catch(e){}
    }
    Utils.toast(isAR ? (o.status === 'active' ? 'تم تفعيل العرض' : 'تم تعطيل العرض') : `Offer ${o.status}`, 'info');
    const container = document.getElementById('page-content');
    if (container) render(container);
  }

  async function deleteOffer(id) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    Utils.confirm(isAR ? 'هل أنت متأكد من حذف هذا العرض؟' : 'Are you sure you want to delete this offer?', async () => {
      await DB.remove('offers', id);
      if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
        BranchSync.notifyChange('offers', { id, deleted: true });
      }
      if (window.OnlineOrders && typeof OnlineOrders.syncCloudTables === 'function') {
        try { await OnlineOrders.syncCloudTables(); } catch(e){}
      }
      Utils.toast(isAR ? 'تم حذف العرض' : 'Offer deleted', 'success');
      const container = document.getElementById('page-content');
      if (container) render(container);
    });
  }

  return {
    render,
    openModal,
    save,
    edit,
    deleteOffer,
    toggleStatus,
    onTypeChange,
    onItemSelect
  };
})();

window.Offers = Offers;

// Auto-refresh offers screen when sync receives updated offers from server/cloud
window.addEventListener('redshark_sync_complete', async (e) => {
  const tbl = e.detail?.table;
  if (!tbl || tbl === 'offers' || tbl === 'all') {
    const container = document.getElementById('page-content');
    if (container && (document.getElementById('offers-list-container') || document.getElementById('offer-modal'))) {
      try {
        await Offers.render(container);
      } catch (err) {}
    }
  }
});
