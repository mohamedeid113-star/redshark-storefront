  function recordDeletedItemLocally(item) {
    if (!item) return;
    try {
      let list = JSON.parse(localStorage.getItem('rs_branch_deleted_items') || '[]');
      const id = item.id != null ? String(item.id) : null;
      const barcode = item.barcode ? String(item.barcode).trim() : null;
      list = list.filter(x => !(id && String(x.id) === id) && !(barcode && x.barcode === barcode));
      list.push({ id, barcode, deleted_at: new Date().toISOString() });
      if (list.length > 5000) list = list.slice(-5000);
      localStorage.setItem('rs_branch_deleted_items', JSON.stringify(list));
    } catch(e) {}
  }

/* ================================================================
   NexPOS — Items Module
   ================================================================ */

const Items = (() => {
  let _items = [];
  let _cats = [];
  let _page = 1;
  let _cur1 = 'USD';
  let _filterNeedsDef = false;
  const _perPage = 20;

  function _fmtItemPrice(amt) {
    const cur = _cur1 || 'USD';
    const isLbp = (Utils.isLbp && Utils.isLbp(cur)) || cur === 'LBP' || cur === 'LL';
    const dec = (isLbp || cur === 'IQD') ? 0 : 2;
    const formatted = Utils.formatCurrency(amt, cur, dec);
    const symMap = { USD: '$', EUR: '€', GBP: '£' };
    return symMap[cur] ? `${symMap[cur]}${formatted}` : `${formatted} ${cur}`;
  }

  const ALL_COLUMNS = [
    { id: 'img', label_en: 'Photo', label_ar: 'الصورة', def: true },
    { id: 'code', label_en: 'Item Code', label_ar: 'رمز الصنف', def: true },
    { id: 'barcode', label_en: 'Barcode', label_ar: 'الباركود', def: true },
    { id: 'name', label_en: 'Item Name', label_ar: 'اسم الصنف', def: true },
    { id: 'category', label_en: 'Category', label_ar: 'التصنيف', def: true },
    { id: 'unit', label_en: 'Unit', label_ar: 'الوحدة', def: false },
    { id: 'cost', label_en: 'Cost Price', label_ar: 'سعر التكلفة', def: true },
    { id: 'price', label_en: 'Retail Price', label_ar: 'سعر البيع', def: true },
    { id: 'wholesale', label_en: 'Wholesale Price', label_ar: 'سعر الجملة', def: false },
    { id: 'min_price', label_en: 'Min Price', label_ar: 'أدنى سعر', def: false },
    { id: 'profit', label_en: 'Margin / Profit', label_ar: 'الربح والهامش', def: false },
    { id: 'stock', label_en: 'Stock Qty', label_ar: 'المخزون', def: true },
    { id: 'min_qty', label_en: 'Low Stock Limit', label_ar: 'حد الطلب', def: false },
    { id: 'tax', label_en: 'Tax / VAT %', label_ar: 'الضريبة %', def: false },
    { id: 'supplier', label_en: 'Supplier', label_ar: 'المورد', def: false },
    { id: 'location', label_en: 'Shelf Location', label_ar: 'موقع الرف', def: false },
    { id: 'status', label_en: 'Status', label_ar: 'الحالة', def: true },
    { id: 'actions', label_en: 'Actions', label_ar: 'إجراءات', def: true }
  ];

  function getVisibleColumns() {
    try {
      const saved = localStorage.getItem('redshark_items_columns');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed === 'object' && parsed !== null) return parsed;
      }
    } catch (e) { }
    const defaultCols = {};
    ALL_COLUMNS.forEach(c => defaultCols[c.id] = c.def);
    return defaultCols;
  }

  function setColumnVisibility(colId, isVisible) {
    const cols = getVisibleColumns();
    cols[colId] = isVisible;
    localStorage.setItem('redshark_items_columns', JSON.stringify(cols));
    renderItems(getFiltered());
  }

  function toggleColumnPicker(e) {
    if (e) e.stopPropagation();
    const menu = document.getElementById('items-col-picker-menu');
    if (menu) menu.classList.toggle('open');
  }

  function resetColumns() {
    localStorage.removeItem('redshark_items_columns');
    render(document.getElementById('page-content'));
  }

  async function render(container) {
    _items = await DB.getAll('items');
    _cats = await DB.getAll('categories');
    _cur1 = await DB.getSetting('currency_1', 'USD');
    const isAR = i18n.getLang() === 'ar';
    const visibleCols = getVisibleColumns();
    _page = 1;
    const isAdmin = (typeof Auth !== 'undefined' && typeof Auth.isAdmin === 'function') ? Auth.isAdmin() : true;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'الأصناف والمخزون' : 'Items & Inventory'}</h1>
          <p>${isAR ? `إجمالي ${_items.length} صنف` : `${_items.length} total items`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Items.exportItems()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير' : 'Export'}
          </button>
          ${isAdmin ? `
          <button class="btn btn-secondary" onclick="Items.openImportExcelModal()" style="font-weight:700">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'استيراد إكسل' : 'Import Excel'}
          </button>
          <button class="btn btn-outline" onclick="Items.openDeleteExcelModal()" style="font-weight:700;color:#ef4444;border-color:rgba(239,68,68,0.4)" title="${isAR ? 'رفع ملف إكسل لحذف الأصناف الموجودة بداخله من النظام' : 'Upload Excel file to delete matching items'}">
            <span>🗑️</span>
            <span>${isAR ? 'حذف بواسطة إكسل' : 'Delete via Excel'}</span>
          </button>
          <button class="btn btn-outline" onclick="Items.wipeAllItemsCatalog()" style="font-weight:700;color:#f59e0b;border-color:rgba(245,158,11,0.4)" title="${isAR ? 'تفريغ دليل الأصناف فقط لإعادة استيراد ملف جديد (يحافظ بالكامل على ديون العملاء والمعاملات)' : 'Wipe only items catalog to re-import fresh list (preserves customer debts and sales)'}">
            <span>🏷️</span>
            <span>${isAR ? 'تفريغ دليل الأصناف' : 'Clear Items Only'}</span>
          </button>
          <button class="btn btn-outline" onclick="Items.restoreMissingFromPurchasing()" style="font-weight:800;color:#3b82f6;border-color:rgba(59,130,246,0.4);display:inline-flex;align-items:center;gap:6px" title="${isAR ? 'فحص فواتير الشراء واستعادة أي أصناف مفقودة من المخزون بنقرة واحدة' : 'Scan purchase invoices and restore any missing items into catalog'}">
            <span>🔄</span>
            <span>${isAR ? 'استعادة من فواتير الشراء' : 'Restore from Purchases'}</span>
          </button>
          ` : ''}
          <button class="btn" onclick="Items.openQuickStockAndCostModal()" style="font-weight:800;background:linear-gradient(135deg,#10b981,#059669);border:none;color:#fff;display:inline-flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(16,185,129,0.3)">
            <span>⚡</span>
            <span>${isAR ? 'فاحص السعر والكلفة / زيادة ستوك سريع' : 'Owner Price & Cost / Quick Stock +'}</span>
          </button>
          <button class="btn btn-primary" onclick="Items.openForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'صنف جديد' : 'New Item'}
          </button>
        </div>
      </div>

      <!-- Toolbar -->
      <div class="toolbar">
        <div class="search-bar flex-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" id="items-search"
            placeholder="${isAR ? 'بحث بالاسم، الرمز، الباركود، المورد...' : 'Search by name, code, barcode, supplier...'}"
            oninput="Items.search(this.value)" style="padding-left:34px">
        </div>
        <select class="form-control" id="items-cat-filter" style="width:160px" onchange="Items.applyFilters()">
          <option value="">${isAR ? 'كل التصنيفات' : 'All Categories'}</option>
          <option value="none">🏷️ ${isAR ? 'بدون تصنيف' : 'No Category'}</option>
          ${_cats.map(c => `<option value="${c.id}">${isAR ? (c.name_ar || c.name) : (c.name || c.name_ar)}</option>`).join('')}
        </select>
        <select class="form-control" id="items-status-filter" style="width:120px" onchange="Items.applyFilters()">
          <option value="">${isAR ? 'كل الحالات' : 'All Status'}</option>
          <option value="active">${isAR ? 'نشط' : 'Active'}</option>
          <option value="inactive">${isAR ? 'غير نشط' : 'Inactive'}</option>
        </select>

        <!-- Filter items needing definition badge button -->
        <button class="btn ${_filterNeedsDef ? 'btn-danger' : 'btn-secondary'}" id="items-needs-def-btn" type="button" onclick="Items.toggleNeedsDefFilter()" style="font-weight:700;display:flex;align-items:center;gap:6px" title="${isAR ? 'تصفية الأصناف المضافة سريعاً وتحتاج استكمال بياناتها' : 'Filter items added quickly needing definition'}">
          <span>⚠️</span> <span>${isAR ? 'تحتاج تعريف' : 'Needs Definition'}</span>
          <span class="badge" id="items-needs-def-badge" style="background:#dc2626;color:#fff;font-size:0.75rem;padding:2px 6px;border-radius:10px;display:${_items.filter(i => i.needs_definition || i.is_temporary).length > 0 ? 'inline-block' : 'none'}">${_items.filter(i => i.needs_definition || i.is_temporary).length}</span>
        </button>

        <!-- DataGridView Column Picker Dropdown -->
        <div class="dropdown" id="items-col-picker-dropdown" style="position:relative">
          <button class="btn btn-secondary" type="button" onclick="Items.toggleColumnPicker(event)" style="display:flex;align-items:center;gap:6px;font-weight:700">
            <span>👁️</span> <span>${isAR ? 'تخصيص الأعمدة' : 'Columns'}</span> <span style="font-size:0.7rem">▼</span>
          </button>
          <div class="dropdown-menu col-picker-menu" id="items-col-picker-menu" onclick="event.stopPropagation()">
            <div style="font-weight:800;font-size:0.82rem;margin-bottom:8px;padding-bottom:6px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
              <span>${isAR ? 'الأعمدة المعروضة' : 'Visible Columns'}</span>
              <button class="btn btn-ghost btn-sm" onclick="Items.resetColumns()" style="font-size:0.7rem;padding:2px 6px">${isAR ? 'استعادة الافتراضي' : 'Reset'}</button>
            </div>
            ${ALL_COLUMNS.filter(c => c.id !== 'actions').map(c => `
              <label class="col-picker-item">
                <input type="checkbox" ${visibleCols[c.id] ? 'checked' : ''} onchange="Items.setColumnVisibility('${c.id}', this.checked)">
                <span>${isAR ? c.label_ar : c.label_en}</span>
              </label>
            `).join('')}
          </div>
        </div>

        <select class="form-control" id="items-view" style="width:100px" onchange="Items.switchView(this.value)">
          <option value="table">${isAR ? 'جدول' : 'Table'}</option>
          <option value="grid">${isAR ? 'شبكة' : 'Grid'}</option>
        </select>
      </div>

      <div id="items-content"></div>
      <div class="pagination" id="items-pagination"></div>
    </div>

    <!-- Item Form Modal -->
    <div class="modal-overlay" id="item-modal">
      <div class="modal modal-xl">
        <div class="modal-header">
          <div class="modal-title" id="item-modal-title">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
            ${isAR ? 'صنف جديد' : 'New Item'}
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('item-modal')">✕</button>
        </div>
        <div class="modal-body" style="padding:20px 24px">
          
          <!-- TABS HEADER (At the very top of the modal body) -->
          <div class="tabs" id="item-tabs" style="margin-bottom:20px;border-bottom:1px solid var(--border-color);padding-bottom:10px">
            <div class="tab-item active" data-tab="tab-basic" onclick="Items.switchTab('tab-basic')" style="font-size:0.92rem;font-weight:700;padding:8px 16px;cursor:pointer">🏷️ ${isAR ? 'معلومات الصنف والباركود' : 'General & Barcode'}</div>
            <div class="tab-item" data-tab="tab-pricing" onclick="Items.switchTab('tab-pricing')" style="font-size:0.92rem;font-weight:700;padding:8px 16px;cursor:pointer">💵 ${isAR ? 'الأسعار والتكاليف' : 'Pricing & Cost'}</div>
            <div class="tab-item" data-tab="tab-stock" onclick="Items.switchTab('tab-stock')" style="font-size:0.92rem;font-weight:700;padding:8px 16px;cursor:pointer">📦 ${isAR ? 'المخزون والمستودعات' : 'Stock & Inventory'}</div>
            <div class="tab-item" data-tab="tab-details" onclick="Items.switchTab('tab-details')" style="font-size:0.92rem;font-weight:700;padding:8px 16px;cursor:pointer">⚙️ ${isAR ? 'المواصفات والشركة والمورد' : 'Specs & Supplier'}</div>
          </div>

          <!-- TAB 1: GENERAL & BARCODE (Full Space) -->
          <div class="tab-content active" id="tab-basic" style="display:block">
            
            <!-- Photo & Names Section -->
            <div style="display:flex;gap:18px;align-items:flex-start;background:rgba(255,255,255,0.02);border:1px solid var(--border-color);border-radius:14px;padding:16px;margin-bottom:16px">
              
              <!-- Image Upload Card -->
              <div class="image-upload" onclick="document.getElementById('item-image-input').click()" style="width:110px;height:110px;min-width:110px;border-radius:12px;border:2px dashed var(--border-color);background:rgba(255,255,255,0.03);display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;cursor:pointer">
                <input type="file" id="item-image-input" accept="image/*" style="display:none" onchange="Items.previewImage(this)">
                <div id="item-image-preview" style="display:none;width:100%;height:100%;position:relative">
                  <img id="item-image-thumb" style="width:100%;height:100%;object-fit:cover;border-radius:10px">
                  <button onclick="event.stopPropagation();Items.clearImage()" style="position:absolute;top:-6px;right:-6px;background:var(--danger);color:white;border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:11px;font-weight:bold;box-shadow:0 2px 6px rgba(0,0,0,0.4)">✕</button>
                </div>
                <div id="item-image-placeholder" style="text-align:center;padding:6px">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:32px;height:32px;margin:0 auto 4px;color:var(--text-muted)"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                  <p style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'رفع صورة' : 'Photo'}</p>
                </div>
              </div>

              <!-- Names Grid -->
              <div style="flex:1;display:grid;grid-template-columns:1fr 1fr;gap:14px">
                <div class="form-group" style="margin:0">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                    <label class="form-label" style="margin:0;font-size:0.82rem;font-weight:700">${isAR ? 'اسم الصنف (عربي)' : 'Name (Arabic)'} <span style="color:#ef4444;font-weight:900">*</span></label>
                    <button type="button" class="btn btn-ghost btn-sm" onclick="Items.aiTranslateName()" style="font-size:0.72rem;padding:2px 8px;color:#c084fc;font-weight:700">
                      ✨ ${isAR ? 'ترجمة بالذكاء الاصطناعي' : 'AI Translate'}
                    </button>
                  </div>
                  <input type="text" class="form-control" id="item-name-ar" placeholder="${isAR ? 'مثال: قهوة سبيشالتي 250g' : 'e.g. Specialty Coffee 250g'}" dir="rtl" style="font-size:1rem;font-weight:600;padding:10px 14px">
                </div>

                <div class="form-group" style="margin:0">
                  <label class="form-label" style="margin-bottom:6px;font-size:0.82rem;font-weight:700">${isAR ? 'اسم الصنف (إنجليزي)' : 'Name (English)'} <span style="color:#ef4444;font-weight:900">*</span></label>
                  <input type="text" class="form-control" id="item-name-en" placeholder="e.g. Specialty Coffee 250g" onblur="if(!document.getElementById('item-name-ar').value) Items.aiTranslateName()" style="font-size:1rem;font-weight:600;padding:10px 14px">
                </div>
              </div>
            </div>

            <!-- Barcode & Item Code Row -->
            <div class="grid grid-2" style="gap:16px;margin-bottom:16px">
              <div class="form-group" style="margin:0">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                  <label class="form-label" style="margin:0;font-size:0.82rem;font-weight:700">${isAR ? 'الباركود' : 'Barcode'} <span style="color:#ef4444;font-weight:900">*</span></label>
                  <button type="button" class="btn btn-ghost btn-sm" onclick="Items.generateRandomBarcode()" style="font-size:0.72rem;padding:2px 8px;color:#06b6d4;font-weight:800">
                    ⚡ ${isAR ? 'توليد تلقائي' : 'Auto Generate'}
                  </button>
                </div>
                <div style="display:flex;gap:8px;align-items:center">
                  <input type="text" class="form-control" id="item-barcode" placeholder="${isAR ? 'مسح أو إدخال الباركود' : 'Scan or type barcode'}" required style="font-family:monospace;font-weight:800;font-size:1.05rem;letter-spacing:1px;color:#38bdf8;padding:10px 14px">
                  <button type="button" class="btn btn-outline btn-sm" onclick="Items.generateRandomBarcode()" title="${isAR ? 'توليد باركود عشوائي فريد' : 'Generate Random Unique Barcode'}" style="padding:10px 14px;white-space:nowrap;border-radius:8px;font-size:1rem">
                    🎲
                  </button>
                </div>
              </div>

              <div class="form-group" style="margin:0">
                <label class="form-label" style="margin-bottom:6px;font-size:0.82rem;font-weight:700">${isAR ? 'رمز الصنف' : 'Item Code'}</label>
                <input type="text" class="form-control" id="item-code" placeholder="${isAR ? 'تلقائي إذا تُرك فارغاً' : 'Auto-generated if empty'}" style="font-family:monospace;font-weight:600;padding:10px 14px">
              </div>
            </div>

            <!-- Category, Unit & Status Row -->
            <div class="grid grid-3" style="gap:16px;margin-bottom:16px">
              <div class="form-group" style="margin:0">
                <label class="form-label" style="margin-bottom:6px;font-size:0.82rem;font-weight:700">${isAR ? 'التصنيف' : 'Category'} <span style="color:#ef4444;font-weight:900">*</span></label>
                <div style="display:flex;gap:6px;align-items:center">
                  <select class="form-control" id="item-category" style="flex:1;font-weight:600;padding:10px 12px">
                    <option value="">-- ${isAR ? 'اختر التصنيف' : 'Select Category'} --</option>
                    ${_cats.map(c => `<option value="${c.id}">${isAR ? (c.name_ar || c.name) : (c.name || c.name_ar)}</option>`).join('')}
                  </select>
                  <button type="button" class="btn btn-primary btn-sm" onclick="Items.quickAddCategory()"
                    title="${isAR ? 'إضافة تصنيف جديد' : 'Add New Category'}"
                    style="padding:10px 14px;min-width:40px;white-space:nowrap;border-radius:8px">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                  </button>
                </div>
              </div>

              <div class="form-group" style="margin:0">
                <label class="form-label" style="margin-bottom:6px;font-size:0.82rem;font-weight:700">${isAR ? 'الوحدة الأساسية' : 'Unit'} <span style="color:#ef4444;font-weight:900">*</span></label>
                <select class="form-control" id="item-unit" style="font-weight:600;padding:10px 12px">
                  <option value="pc">${isAR ? 'قطعة (Piece)' : 'Piece (pc)'}</option>
                  <option value="kg">${isAR ? 'كيلوغرام (kg)' : 'Kilogram (kg)'}</option>
                  <option value="g">${isAR ? 'غرام (g)' : 'Gram (g)'}</option>
                  <option value="ltr">${isAR ? 'ليتر (Liter)' : 'Liter (ltr)'}</option>
                  <option value="box">${isAR ? 'صندوق (Box)' : 'Box'}</option>
                  <option value="crt">${isAR ? 'كرتون (Carton)' : 'Carton'}</option>
                  <option value="m">${isAR ? 'متر (Meter)' : 'Meter (m)'}</option>
                </select>
              </div>

              <div class="form-group" style="margin:0">
                <label class="form-label" style="margin-bottom:6px;font-size:0.82rem;font-weight:700">${isAR ? 'حالة الصنف' : 'Status'}</label>
                <select class="form-control" id="item-status" style="font-weight:700;padding:10px 12px">
                  <option value="active">${isAR ? '🟢 نشط (Active)' : '🟢 Active'}</option>
                  <option value="inactive">${isAR ? '⚪ غير نشط (Inactive)' : '⚪ Inactive'}</option>
                  <option value="discontinued">${isAR ? '🔴 متوقف (Discontinued)' : '🔴 Discontinued'}</option>
                </select>
              </div>
            </div>

            <!-- Electronic Scale / Balance Section (Dairy, Cheeses, Fruits, Vegetables, Meat, Deli) -->
            <div style="background:rgba(2,132,199,0.05);border:1.5px solid rgba(2,132,199,0.25);border-radius:12px;padding:14px;margin-bottom:16px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px">
                <div style="display:flex;align-items:center;gap:10px">
                  <span style="font-size:1.5rem">⚖️</span>
                  <div>
                    <div style="font-weight:800;font-size:0.92rem;color:#0284c7">
                      ${isAR ? 'إعدادات ميزان الباركود الإلكتروني TM-A (ألبان، أجبان، خضار وفواكه، لحوم)' : 'Electronic Scale Configuration (TM-A Bar Code Printing Scale)'}
                    </div>
                    <div style="font-size:0.72rem;color:var(--text-muted)">
                      ${isAR ? 'سعة 30 كغ | دقة 5غ — لقراءة باركود ملصقات الميزان آلياً وتحديد سعر الكيلو مباشرة' : 'Cap 30kg | d=5g — Auto-read scale barcode sticker and configure KG price right here'}
                    </div>
                  </div>
                </div>
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;background:var(--surface);border:1px solid var(--border-color);padding:6px 12px;border-radius:8px">
                  <input type="checkbox" id="item-is-scale" onchange="Items.toggleScaleFields(this.checked)" style="width:17px;height:17px;accent-color:#0284c7">
                  <span style="font-weight:800;font-size:0.85rem;color:var(--text-primary)">${isAR ? 'صنف ميزان / وزن' : 'Scale / Weighed Item'}</span>
                </label>
              </div>

              <!-- Quick Department Presets for Scale -->
              <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:12px">
                <span style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'تجهيز سريع:' : 'Quick Presets:'}</span>
                <button type="button" class="btn btn-ghost btn-sm" onclick="Items.applyScalePreset('dairy')" style="font-size:0.72rem;padding:3px 8px;border:1px solid rgba(255,255,255,0.1)">🧀 ${isAR ? 'ألبان وأجبان' : 'Dairy & Cheese'}</button>
                <button type="button" class="btn btn-ghost btn-sm" onclick="Items.applyScalePreset('produce')" style="font-size:0.72rem;padding:3px 8px;border:1px solid rgba(255,255,255,0.1)">🍎 ${isAR ? 'خضار وفواكه' : 'Fruits & Veg'}</button>
                <button type="button" class="btn btn-ghost btn-sm" onclick="Items.applyScalePreset('meat')" style="font-size:0.72rem;padding:3px 8px;border:1px solid rgba(255,255,255,0.1)">🥩 ${isAR ? 'لحوم ودواجن' : 'Meat & Poultry'}</button>
                <button type="button" class="btn btn-ghost btn-sm" onclick="Items.applyScalePreset('deli')" style="font-size:0.72rem;padding:3px 8px;border:1px solid rgba(255,255,255,0.1)">🫒 ${isAR ? 'مقبلات ومخللات' : 'Deli & Pickles'}</button>
                <button type="button" class="btn btn-ghost btn-sm" onclick="Items.applyScalePreset('roastery')" style="font-size:0.72rem;padding:3px 8px;border:1px solid rgba(255,255,255,0.1)">🥜 ${isAR ? 'محامص ومكسرات' : 'Nuts & Roastery'}</button>
              </div>

              <!-- Expanded Scale Fields (Shown when is-scale is checked) -->
              <div id="item-scale-fields-container" style="display:none;background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:14px">
                
                <!-- 1. DIRECT KG PRICING & TVA ROW (Set directly right here) -->
                <div style="background:rgba(16,185,129,0.06);border:1.5px solid rgba(16,185,129,0.3);border-radius:10px;padding:12px 14px;margin-bottom:14px">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:6px">
                    <div style="font-weight:900;font-size:0.86rem;color:#059669;display:flex;align-items:center;gap:6px">
                      <span>💰</span>
                      <span>${isAR ? 'تسعير الكيلوغرام والضريبة (TVA) لميزان TM-A' : 'KG Pricing & TVA Tax for TM-A Scale'}</span>
                    </div>
                    <span style="font-size:0.7rem;color:var(--text-muted);font-weight:600">
                      ${isAR ? '💡 يتم تحديد السعر والتكلفة والضريبة هنا مباشرة وترتبط تلقائياً بالصنف' : '💡 Set KG price, cost & tax right here, synced with the item'}
                    </span>
                  </div>

                  <div class="grid grid-3" style="gap:12px;align-items:flex-start">
                    <!-- 1. Scale Selling Price per KG -->
                    <div class="form-group" style="margin:0">
                      <label class="form-label" style="font-size:0.8rem;font-weight:800;color:#059669;margin-bottom:4px">
                        ${isAR ? 'سعر بيع الكيلو (سعر الميزان)' : 'Selling Price / KG'} <span style="color:#ef4444;font-weight:900">*</span>
                      </label>
                      <div class="input-group">
                        <input type="number" class="form-control" id="item-scale-price" placeholder="0.00" step="any" min="0"
                          oninput="Items.syncScalePrice(this.value)"
                          style="font-size:1.15rem;font-weight:900;color:#059669;padding:8px 10px;border-color:#10b981">
                        <div class="input-group-addon item-cur-addon" style="font-weight:800;font-size:0.82rem">USD</div>
                      </div>
                      <div style="font-size:0.67rem;color:var(--text-muted);margin-top:3px">
                        ${isAR ? 'سعر الكيلو في نقطة البيع وميزان TM-A' : 'Price per 1 kg for POS & Scale'}
                      </div>
                    </div>

                    <!-- 2. Scale Cost Price per KG -->
                    <div class="form-group" style="margin:0">
                      <label class="form-label" style="font-size:0.8rem;font-weight:800;margin-bottom:4px">
                        ${isAR ? 'سعر تكلفة الكيلو (الشراء)' : 'Cost Price / KG'}
                      </label>
                      <div class="input-group">
                        <input type="number" class="form-control" id="item-scale-cost" placeholder="0.00" step="any" min="0"
                          oninput="Items.syncScaleCost(this.value)"
                          style="font-size:1.1rem;font-weight:800;padding:8px 10px">
                        <div class="input-group-addon item-cur-addon" style="font-weight:800;font-size:0.82rem">USD</div>
                      </div>
                      <div style="font-size:0.67rem;color:var(--text-muted);margin-top:3px">
                        ${isAR ? 'تكلفة شراء الكيلو لحساب الأرباح' : 'Purchase cost per 1 kg'}
                      </div>
                    </div>

                    <!-- 3. Scale TVA Tax Status -->
                    <div class="form-group" style="margin:0">
                      <label class="form-label" style="font-size:0.8rem;font-weight:800;margin-bottom:4px">
                        ${isAR ? 'الضريبة على القيمة المضافة (TVA)' : 'TVA Tax Status'}
                      </label>
                      <select class="form-control" id="item-scale-vat-type" onchange="Items.syncScaleVat(this.value)" style="font-size:0.82rem;font-weight:800;padding:8px 10px">
                        <option value="none">${isAR ? 'لا ضريبة (None)' : 'No Tax (None)'}</option>
                        <option value="standard">${isAR ? '⭐ خاضع لـ TVA (تظهر علامة * بالفاتورة)' : '⭐ TVA Taxable (Shows * on invoice)'}</option>
                        <option value="exempt">${isAR ? 'معفى من الضريبة (Exempt - لا تظهر *)' : 'Tax-Exempt (No * on invoice)'}</option>
                        <option value="zero">${isAR ? 'معدل صفري (Zero-Rated)' : 'Zero-Rated'}</option>
                      </select>
                      <div style="font-size:0.67rem;color:var(--text-muted);margin-top:3px">
                        ${isAR ? 'الأصناف الخاضعة تُميز بعلامة * بالفاتورة والإيصال' : 'Taxable items get * on receipts/invoices'}
                      </div>
                    </div>
                  </div>
                </div>

                <!-- 2. PLU, Barcode Type & Tare -->
                <div class="grid grid-3" style="gap:12px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700;margin-bottom:4px">
                      ${isAR ? 'رقم الصنف في الميزان (PLU Code)' : 'Scale PLU / Short Code'} <span style="color:#0284c7;font-weight:900">*</span>
                    </label>
                    <input type="text" class="form-control" id="item-scale-plu" placeholder="e.g. 101 or 205" style="font-family:monospace;font-weight:800;font-size:0.95rem;color:#0284c7;padding:8px 10px" oninput="Items.onScalePluInput(this.value)">
                    <div style="font-size:0.68rem;color:var(--text-muted);margin-top:2px">${isAR ? 'الرقم المبرمج داخل لوحة مفاتيح ميزان TM-A' : 'Hot key / PLU on TM-A scale'}</div>
                  </div>

                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700;margin-bottom:4px">
                      ${isAR ? 'نوع تشفير باركود الميزان' : 'Scale Barcode Format'}
                    </label>
                    <select class="form-control" id="item-scale-type" style="font-size:0.82rem;font-weight:700;padding:8px 10px">
                      <option value="weight">${isAR ? 'مشفر بالوزن (Weight: 20/21)' : 'Weight-Embedded (20/21)'}</option>
                      <option value="price">${isAR ? 'مشفر بالسعر (Price: 22/23/24)' : 'Price-Embedded (22/23/24)'}</option>
                    </select>
                    <div style="font-size:0.68rem;color:var(--text-muted);margin-top:2px">${isAR ? 'الأكثر شيوعاً هو المشفر بالوزن كغ' : 'Most common is Weight-embedded'}</div>
                  </div>

                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700;margin-bottom:4px">
                      ${isAR ? 'وزن الإناء / الفارغ (Tare in kg)' : 'Tare Weight (kg)'}
                    </label>
                    <div class="input-group">
                      <input type="number" class="form-control" id="item-scale-tare" placeholder="0.000" step="0.001" min="0" style="font-weight:700;padding:8px 10px">
                      <div class="input-group-addon" style="font-size:0.75rem;font-weight:700">kg</div>
                    </div>
                    <div style="font-size:0.68rem;color:var(--text-muted);margin-top:2px">${isAR ? 'يُخصم وزن العلبة/الكيس تلقائياً' : 'Auto-deducted container weight'}</div>
                  </div>
                </div>

                <div style="margin-top:10px;padding:8px 10px;background:rgba(2,132,199,0.06);border-radius:6px;font-size:0.73rem;color:#0284c7;display:flex;align-items:center;justify-content:space-between">
                  <span>💡 ${isAR ? 'مثال باركود ملصق ميزان TM-A لهذا الصنف:' : 'Sample TM-A Scale Barcode for this item:'} <strong id="item-scale-sample-bc" style="font-family:monospace;font-size:0.85rem">2000101015004</strong> (1.500 kg)</span>
                  <button type="button" class="btn btn-outline btn-sm" onclick="Items.syncScaleBarcodeToMain()" style="font-size:0.7rem;padding:2px 8px">
                    ${isAR ? 'استخدام كباركود رئيسي' : 'Use as Base Barcode'}
                  </button>
                </div>
              </div>
            </div>

            <!-- Description Field -->
            <div class="form-group" style="margin:0">
              <label class="form-label" style="margin-bottom:6px;font-size:0.82rem;font-weight:700">${isAR ? 'الوصف والملاحظات العامة' : 'Description & Notes'}</label>
              <textarea class="form-control" id="item-desc" rows="3" placeholder="${isAR ? 'وصف الصنف، المكونات، أو أي تفاصيل هامة...' : 'Item description, ingredients, or important info...'}" style="padding:10px 14px"></textarea>
            </div>

            <!-- Online Storefront Publishing Controls -->
            <div style="margin-top:14px;background:rgba(16,185,129,0.05);border:1.5px solid rgba(16,185,129,0.25);border-radius:10px;padding:12px 14px">
              <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
                <div style="display:flex;align-items:center;gap:10px">
                  <input type="checkbox" id="item-show-online" checked style="width:18px;height:18px;cursor:pointer">
                  <label for="item-show-online" style="font-weight:800;font-size:0.85rem;color:#047857;cursor:pointer;margin:0">
                    🛍️ ${isAR ? 'عرض الصنف في المتجر الإلكتروني (Show on Online Store)' : 'Publish on Online Store'}
                  </label>
                </div>
                <div style="display:flex;align-items:center;gap:8px">
                  <label for="item-online-price" style="font-size:0.75rem;font-weight:700;color:var(--text-muted);margin:0">
                    ${isAR ? 'سعر خاص للمتجر (اختياري):' : 'Online Special Price (Optional):'}
                  </label>
                  <div class="input-group" style="width:110px">
                    <input type="number" class="form-control" id="item-online-price" placeholder="0.00" step="any" min="0" style="padding:4px 8px;font-size:0.85rem;font-weight:700">
                    <div class="input-group-addon" style="font-size:0.7rem;padding:0 6px">USD</div>
                  </div>
                </div>
              </div>
              <div style="font-size:0.68rem;color:var(--text-muted);margin-top:4px">
                ${isAR ? 'إذا تم إلغاء التحديد، لن يظهر هذا الصنف لزبائن المتجر على الويب وتطبيق الهاتف نهائياً' : 'If unchecked, this item will be hidden from the online storefront website & mobile app.'}
              </div>
            </div>

          </div>

          <!-- TAB 2: PRICING & COST (Full Space) -->
          <div class="tab-content" id="tab-pricing">
            
            <!-- Core Selling, Cost & Profit Percentage Card -->
            <div style="background:rgba(239,68,68,0.04);border:1px solid rgba(239,68,68,0.2);border-radius:14px;padding:18px;margin-bottom:18px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px">
                <div style="font-size:12.5px;font-weight:900;color:#ef4444;text-transform:uppercase;letter-spacing:0.6px">
                  💵 ${isAR ? 'الأسعار، التكلفة، ونسبة الربح' : 'Selling Price, Cost & Profit Percentage'}
                </div>
                <div style="font-size:0.75rem;color:var(--text-muted);font-weight:600">
                  ${isAR ? '💡 حساب تلقائي لسعر البيع بناءً على نسبة الربح من التكلفة' : '💡 Auto-calculates selling price based on profit % from cost'}
                </div>
              </div>

              <div class="grid grid-3" style="gap:16px;align-items:flex-start">
                <!-- 1. Cost Price -->
                <div class="form-group" style="margin:0">
                  <label class="form-label" style="font-size:0.85rem;font-weight:800;margin-bottom:6px">
                    ${isAR ? 'سعر التكلفة (الشراء)' : 'Cost Price'}
                  </label>
                  <div class="input-group">
                    <input type="number" class="form-control" id="item-cost" placeholder="0.00" step="any" min="0" 
                      oninput="Items.recalcPricing('cost')"
                      style="font-size:1.15rem;font-weight:800;padding:10px 12px">
                    <div class="input-group-addon item-cur-addon" style="font-weight:800;font-size:0.9rem">USD</div>
                  </div>
                  <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">
                    ${isAR ? 'سعر شراء القطعة من المورد' : 'Unit purchase cost from supplier'}
                  </div>
                </div>

                <!-- 2. Profit Percentage % -->
                <div class="form-group" style="margin:0">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                    <label class="form-label" style="font-size:0.85rem;font-weight:800;margin:0;color:var(--primary)">
                      📈 ${isAR ? 'نسبة الربح %' : 'Profit % (Markup)'}
                    </label>
                    <span style="font-size:0.68rem;color:var(--text-muted);font-weight:700">% من التكلفة</span>
                  </div>
                  <div class="input-group">
                    <input type="number" class="form-control" id="item-profit-pct" placeholder="0.0" step="any" min="0"
                      oninput="Items.recalcPricing('profit')"
                      style="font-size:1.15rem;font-weight:900;color:var(--primary);padding:10px 12px;background:rgba(37,99,235,0.04);border-color:var(--primary)">
                    <div class="input-group-addon" style="font-weight:900;font-size:1rem;color:var(--primary);background:rgba(37,99,235,0.08)">%</div>
                  </div>
                  <!-- Quick Preset Chips -->
                  <div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:6px">
                    ${[10, 15, 20, 25, 30, 40, 50, 100].map(p => `
                      <button type="button" class="btn btn-ghost btn-sm" onclick="Items.setProfitPreset(${p})" style="font-size:0.68rem;padding:1px 6px;height:22px;border-radius:6px;border:1px solid var(--border-color);background:var(--surface);cursor:pointer">
                        +${p}%
                      </button>
                    `).join('')}
                  </div>
                </div>

                <!-- 3. Selling Price 1 -->
                <div class="form-group" style="margin:0">
                  <label class="form-label" style="font-size:0.85rem;font-weight:800;margin-bottom:6px">
                    ${isAR ? 'سعر البيع الأساسي (1)' : 'Selling Price 1'} <span style="color:#ef4444;font-weight:900">*</span>
                  </label>
                  <div class="input-group">
                    <input type="number" class="form-control" id="item-price1" placeholder="0.00" step="any" min="0"
                      oninput="Items.recalcPricing('price')"
                      style="font-size:1.2rem;font-weight:900;color:#10b981;padding:10px 12px;border-color:#10b981">
                    <div class="input-group-addon item-cur-addon" style="font-weight:800;font-size:0.9rem">USD</div>
                  </div>
                  <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">
                    ${isAR ? 'السعر النهائي للبيع بالمتجر' : 'Final retail price for customer'}
                  </div>
                </div>
              </div>

              <!-- Live Profit & Margin Summary Badge -->
              <div id="item-profit-summary-badge" style="margin-top:14px"></div>
            </div>

            <!-- Price Tiers & Tax Grid -->
            <div class="grid grid-2" style="gap:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'سعر البيع 2 (سعر الجملة)' : 'Selling Price 2 (Wholesale)'}</label>
                <div class="input-group">
                  <input type="number" class="form-control" id="item-price2" placeholder="0.00" step="0.01" min="0" style="font-size:1.05rem;font-weight:700">
                  <div class="input-group-addon item-cur-addon">USD</div>
                </div>
              </div>

              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'سعر البيع 3 (VIP / عملاء مميزين)' : 'Selling Price 3 (VIP)'}</label>
                <div class="input-group">
                  <input type="number" class="form-control" id="item-price3" placeholder="0.00" step="0.01" min="0" style="font-size:1.05rem;font-weight:700">
                  <div class="input-group-addon item-cur-addon">USD</div>
                </div>
              </div>

              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'الحد الأقصى للخصم المسموح به %' : 'Max Discount %'}</label>
                <input type="number" class="form-control" id="item-max-disc" placeholder="0" min="0" max="100" value="0" style="font-size:1.05rem;font-weight:700">
              </div>

              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'نوع الضريبة (VAT)' : 'VAT Type'}</label>
                <select class="form-control" id="item-vat-type" style="font-weight:700">
                  <option value="none">${isAR ? 'لا ضريبة' : 'None'}</option>
                  <option value="standard">${isAR ? 'معدل قياسي (Standard Rate)' : 'Standard Rate'}</option>
                  <option value="zero">${isAR ? 'معدل صفري (Zero-Rated)' : 'Zero-Rated'}</option>
                  <option value="exempt">${isAR ? 'معفى من الضريبة (Exempt)' : 'Exempt'}</option>
                </select>
              </div>
            </div>

          </div>

          <!-- TAB 3: STOCK & WAREHOUSES (Full Space) -->
          <div class="tab-content" id="tab-stock">
            <div class="grid grid-3" style="gap:16px;margin-bottom:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'إجمالي المخزون الحالي (هذا الفرع)' : 'Current Stock (This Store)'}</label>
                <input type="number" class="form-control" id="item-stock-qty" placeholder="0" step="any" value="0" oninput="Items.onMainStockInput(this.value)" style="background:var(--surface-2);font-weight:800;font-size:1.1rem;color:#38bdf8">
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'الحد الأدنى للتنبيه (نقص المخزون)' : 'Min Alert Qty'}</label>
                <input type="number" class="form-control" id="item-min-qty" placeholder="0" min="0" value="0" style="font-weight:700">
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'الحد الأقصى للمخزون' : 'Max Qty'}</label>
                <input type="number" class="form-control" id="item-max-qty" placeholder="0" min="0" value="0" style="font-weight:700">
              </div>
            </div>

            <!-- Packaging: Box to Piece Link -->
            <div class="grid grid-3" style="border-top:1px solid var(--border-color);padding-top:16px;margin-top:16px;gap:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'تعبئة وحدة البيع' : 'Selling Packaging'}</label>
                <select class="form-control" id="item-sell-unit" onchange="Items.handleUnitChange(this.value)">
                  <option value="piece">${isAR ? 'قطعة فردية (Piece)' : 'Piece (Single)'}</option>
                  <option value="box">${isAR ? 'صندوق / كرتون (Box)' : 'Box'}</option>
                </select>
              </div>
              <div class="form-group" id="item-pieces-per-box-group" style="display:none">
                <label class="form-label" style="font-weight:700">${isAR ? 'عدد القطع في الصندوق' : 'Pieces per Box'}</label>
                <input type="number" class="form-control" id="item-pieces-per-box" value="1" min="1" style="font-weight:700">
              </div>
              <div class="form-group" id="item-linked-item-group" style="display:none;position:relative">
                <label class="form-label" style="font-weight:700">${isAR ? 'ربط بقطعة فردية' : 'Link to Piece Item'}</label>
                <div class="searchable-select" id="linked-item-container" style="position:relative">
                  <div class="searchable-select-trigger" onclick="Items.toggleLinkedItemDropdown(event)" style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border:1px solid var(--border-color);border-radius:6px;background:var(--input-bg);font-size:0.85rem;cursor:pointer;min-height:38px;box-sizing:border-box">
                    <span id="linked-item-display">${isAR ? 'اختر الصنف الفردي...' : 'Select piece item...'}</span>
                    <span style="font-size:0.65rem;color:var(--text-muted)">▼</span>
                  </div>
                  <div class="searchable-select-dropdown" id="linked-item-dropdown" style="display:none;position:absolute;top:100%;left:0;right:0;background:var(--surface);border:1px solid var(--border-color);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.3);z-index:1000;margin-top:4px;padding:8px;box-sizing:border-box">
                    <input type="text" class="form-control searchable-select-search" id="linked-item-search" placeholder="${isAR ? 'ابحث بالاسم أو الرمز أو الباركود...' : 'Search by name, code or barcode...'}" oninput="Items.filterLinkedItemDropdown(this.value)" onclick="event.stopPropagation()" style="font-size:0.82rem;padding:6px 10px;margin-bottom:8px;width:100%;box-sizing:border-box">
                    <div class="searchable-select-options" id="linked-item-options" style="max-height:180px;overflow-y:auto;display:flex;flex-direction:column;gap:2px">
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div id="item-stock-warehouses-section" style="margin-top:16px;border-top:1px solid var(--border-color);padding-top:16px"></div>
            
            <div class="grid grid-2" style="gap:16px;margin-top:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'نقطة إعادة الطلب' : 'Reorder Point'}</label>
                <input type="number" class="form-control" id="item-reorder" placeholder="0" min="0" value="0">
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'طريقة حساب التكلفة' : 'Costing Method'}</label>
                <select class="form-control" id="item-costing">
                  <option value="avg">${isAR ? 'متوسط مرجح (Weighted Average)' : 'Weighted Average'}</option>
                  <option value="fifo">FIFO (الأول دخولاً الأول خروجاً)</option>
                </select>
              </div>
            </div>

            <div class="grid grid-3" style="gap:16px;margin-top:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'تتبع الرقم التسلسلي' : 'Serial Number Tracking'}</label>
                <label class="toggle" style="margin-top:8px"><input type="checkbox" id="item-serial"><span class="toggle-slider"></span></label>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'تتبع الدفعة (Batch)' : 'Batch Tracking'}</label>
                <label class="toggle" style="margin-top:8px"><input type="checkbox" id="item-batch"><span class="toggle-slider"></span></label>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'تتبع انتهاء الصلاحية' : 'Expiry Tracking'}</label>
                <label class="toggle" style="margin-top:8px">
                  <input type="checkbox" id="item-expiry" onchange="Items._toggleExpiryField(this.checked)">
                  <span class="toggle-slider"></span>
                </label>
              </div>
              <div class="form-group" id="item-expiry-date-group" style="display:none;grid-column:1/-1">
                <label class="form-label" style="color:var(--warning);font-weight:700">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                  ${isAR ? 'تاريخ انتهاء الصلاحية' : 'Expiry Date'}
                </label>
                <input type="date" class="form-control" id="item-expiry-date" style="max-width:240px;font-size:1rem;color:var(--warning)">
              </div>
            </div>
          </div>

          <!-- TAB 4: SPECS, BRAND & SUPPLIER (Full Space) -->
          <div class="tab-content" id="tab-details">
            <div class="grid grid-3" style="gap:16px;margin-bottom:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'الماركة / الشركة' : 'Brand'}</label>
                <input type="text" class="form-control" id="item-brand" list="dl-brands" placeholder="${isAR ? 'اكتب أو اختر من القائمة' : 'Type or select from list'}">
                <datalist id="dl-brands">
                  ${[...new Set(_items.map(i => i.brand).filter(Boolean))].map(v => `<option value="${Utils.sanitize(v)}">`).join('')}
                </datalist>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'النوع / الصنف الفرعي' : 'Type'}</label>
                <input type="text" class="form-control" id="item-type" list="dl-types" placeholder="${isAR ? 'اكتب أو اختر من القائمة' : 'Type or select from list'}">
                <datalist id="dl-types">
                  ${[...new Set(_items.map(i => i.item_type || i.type).filter(Boolean))].map(v => `<option value="${Utils.sanitize(v)}">`).join('')}
                </datalist>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'الطراز / الموديل' : 'Model'}</label>
                <input type="text" class="form-control" id="item-model" list="dl-models" placeholder="${isAR ? 'اكتب أو اختر من القائمة' : 'Type or select from list'}">
                <datalist id="dl-models">
                  ${[...new Set(_items.map(i => i.model).filter(Boolean))].map(v => `<option value="${Utils.sanitize(v)}">`).join('')}
                </datalist>
              </div>
            </div>

            <!-- Color & Country of Origin (Searchable with Flags) -->
            <div class="grid grid-2" style="gap:16px;margin-bottom:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'اللون' : 'Color'}</label>
                <div style="display:flex;gap:8px;align-items:center">
                  <input type="text" class="form-control" id="item-color" list="dl-colors" placeholder="${isAR ? 'اكتب أو اختر اللون (مثال: أسود / فضي)' : 'e.g. Black / Silver'}" style="flex:1">
                  <input type="color" id="item-color-picker" style="width:40px;height:38px;padding:2px;border-radius:8px;border:1px solid var(--border-color);cursor:pointer;background:transparent" onchange="Items.onColorPickerChange(this.value)">
                </div>
                <datalist id="dl-colors">
                  <option value="${isAR ? 'أسود' : 'Black'}">
                  <option value="${isAR ? 'أبيض' : 'White'}">
                  <option value="${isAR ? 'فضي' : 'Silver'}">
                  <option value="${isAR ? 'رمادي' : 'Grey'}">
                  <option value="${isAR ? 'أزرق' : 'Blue'}">
                  <option value="${isAR ? 'أحمر' : 'Red'}">
                  <option value="${isAR ? 'ذهبي' : 'Gold'}">
                  <option value="${isAR ? 'أخضر' : 'Green'}">
                  <option value="${isAR ? 'أصفر' : 'Yellow'}">
                  <option value="${isAR ? 'بني' : 'Brown'}">
                  <option value="${isAR ? 'بيج' : 'Beige'}">
                  <option value="${isAR ? 'كحلي' : 'Navy'}">
                  <option value="${isAR ? 'برتقالي' : 'Orange'}">
                  <option value="${isAR ? 'شفاف' : 'Transparent'}">
                </datalist>
              </div>

              <div class="form-group" style="position:relative">
                <label class="form-label" style="font-weight:700">${isAR ? 'بلد الصنع / المنشأ' : 'Country of Origin (Made in)'}</label>
                <div class="searchable-select" id="country-origin-container" style="position:relative">
                  <div class="searchable-select-trigger" onclick="Items.toggleCountryDropdown(event)" style="display:flex;align-items:center;justify-content:space-between;padding:9px 12px;border:1px solid var(--border-color);border-radius:8px;background:var(--input-bg);font-size:0.9rem;cursor:pointer;min-height:40px;box-sizing:border-box">
                    <span id="country-origin-display">${isAR ? '🏳️ اختر أو ابحث عن بلد الصنع...' : '🏳️ Select or search country...'}</span>
                    <span style="font-size:0.65rem;color:var(--text-muted)">▼</span>
                  </div>
                  <div class="searchable-select-dropdown" id="country-origin-dropdown" style="display:none;position:absolute;top:100%;left:0;right:0;background:var(--surface);border:1px solid var(--border-color);border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.35);z-index:1100;margin-top:4px;padding:8px;box-sizing:border-box">
                    <input type="text" class="form-control searchable-select-search" id="country-origin-search" placeholder="${isAR ? 'ابحث باسم البلد أو العلم...' : 'Search country or flag...'}" oninput="Items.filterCountryDropdown(this.value)" onclick="event.stopPropagation()" style="font-size:0.85rem;padding:7px 10px;margin-bottom:8px;width:100%;box-sizing:border-box">
                    <div class="searchable-select-options" id="country-origin-options" style="max-height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:2px">
                    </div>
                  </div>
                </div>
                <input type="hidden" id="item-origin-code" value="">
                <input type="hidden" id="item-origin-name" value="">
                <input type="hidden" id="item-origin-flag" value="">
              </div>
            </div>

            <div class="grid grid-2" style="gap:16px;margin-bottom:16px">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'المورد المعتمد' : 'Supplier'}</label>
                <select class="form-control" id="item-supplier">
                  <option value="">-- ${isAR ? 'اختر مورداً' : 'Select Supplier'} --</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'رمز الصنف لدى المورد' : 'Supplier Item Code'}</label>
                <input type="text" class="form-control" id="item-supplier-code" placeholder="${isAR ? 'رمز المورد' : 'Supplier code'}">
              </div>
            </div>

            <div class="grid grid-4" style="gap:14px;margin-bottom:16px">
              <div class="form-group">
                <label class="form-label">${isAR ? 'الوزن الإجمالي (كغ)' : 'Gross Wt (kg)'}</label>
                <input type="number" class="form-control" id="item-gross-wt" placeholder="0.000" step="0.001">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR ? 'الوزن الصافي (كغ)' : 'Net Wt (kg)'}</label>
                <input type="number" class="form-control" id="item-net-wt" placeholder="0.000" step="0.001">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR ? 'الطول (سم)' : 'Size 1 (cm)'}</label>
                <input type="number" class="form-control" id="item-size1" placeholder="0">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR ? 'العرض (سم)' : 'Size 2 (cm)'}</label>
                <input type="number" class="form-control" id="item-size2" placeholder="0">
              </div>
            </div>

            <div class="form-group" style="margin:0">
              <label class="form-label" style="font-weight:700">${isAR ? 'ملاحظات داخلية للموظفين' : 'Internal Staff Notes'}</label>
              <textarea class="form-control" id="item-notes" rows="2" placeholder="${isAR ? 'ملاحظات خاصة بالإدارة أو الموظفين...' : 'Internal notes for staff...'}"></textarea>
            </div>
          </div>

        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('item-modal')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Items.saveItem()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            ${isAR ? 'حفظ' : 'Save'}
          </button>
        </div>
      </div>
    </div>`;

    Utils.initTabs('#item-tabs');
    renderItems(getFiltered());
    loadSuppliers(isAR);
  }

  function getFiltered() {
    const q = (document.getElementById('items-search')?.value || '').toLowerCase();
    const cat = document.getElementById('items-cat-filter')?.value || '';
    const stat = document.getElementById('items-status-filter')?.value || '';
    return _items.filter(i => {
      const matchQ = (!q || (i.name_en || '').toLowerCase().includes(q) || (i.name_ar || '').toLowerCase().includes(q) || (i.item_code || '').toLowerCase().includes(q) || (i.barcode || '').toLowerCase().includes(q));
      let matchCat = true;
      if (cat === 'none') {
        const cid = (i.category_id !== null && i.category_id !== undefined && i.category_id !== '') ? String(i.category_id).trim() : '';
        const cname = (i.category || '').toLowerCase().trim();
        const hasValidCat = cid && _cats.some(c => String(c.id) === cid);
        const hasValidName = cname && _cats.some(c => (c.name || '').toLowerCase().trim() === cname || (c.name_en || '').toLowerCase().trim() === cname || (c.name_ar || '').toLowerCase().trim() === cname);
        matchCat = !hasValidCat && !hasValidName;
      } else if (cat) {
        matchCat = String(i.category_id) === cat || (i.category && String(i.category) === cat);
      }
      return matchQ && matchCat && (!stat || i.status === stat) && (!_filterNeedsDef || (i.needs_definition || i.is_temporary));
    });
  }

  function toggleNeedsDefFilter() {
    _filterNeedsDef = !_filterNeedsDef;
    const btn = document.getElementById('items-needs-def-btn');
    if (btn) {
      btn.className = _filterNeedsDef ? 'btn btn-danger' : 'btn btn-secondary';
    }
    _page = 1;
    renderItems(getFiltered());
  }

  function search() { _page = 1; renderItems(getFiltered()); }
  function applyFilters() { _page = 1; renderItems(getFiltered()); }

  function renderItems(items) {
    const isAR = i18n.getLang() === 'ar';
    const isAdmin = (typeof Auth !== 'undefined' && typeof Auth.isAdmin === 'function') ? Auth.isAdmin() : true;
    const view = document.getElementById('items-view')?.value || 'table';
    const start = (_page - 1) * _perPage;
    const paged = items.slice(start, start + _perPage);

    const content = document.getElementById('items-content');
    if (!content) return;

    if (view === 'grid') {
      content.innerHTML = `<div class="grid grid-4" style="margin-bottom:8px">
        ${paged.map(i => `
          <div class="card" style="padding:14px;cursor:pointer" onclick="Items.openForm(${i.id})">
            <div style="width:100%;height:80px;background:var(--surface-2);border-radius:8px;margin-bottom:10px;display:flex;align-items:center;justify-content:center;overflow:hidden">
              ${i.image ? `<img src="${i.image}" style="width:100%;height:100%;object-fit:cover;border-radius:8px">` : `<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1.5"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>`}
            </div>
            <div style="font-size:0.78rem;font-weight:600;margin-bottom:3px;line-height:1.3">${Utils.truncate(isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar), 30)}</div>
            <div style="font-size:0.7rem;color:var(--text-muted);margin-bottom:4px">${i.item_code || ''}</div>
            <div style="font-size:0.88rem;font-weight:800;color:var(--primary)">${_fmtItemPrice(i.selling_price || 0)}</div>
            <div style="font-size:0.7rem;margin-top:3px;display:flex;justify-content:space-between">
              <span class="badge ${i.status === 'active' ? 'badge-success' : 'badge-secondary'}">${i.status || 'active'}</span>
              <span style="color:${(i.stock_qty || 0) <= (i.min_qty || 0) ? 'var(--danger)' : 'var(--success)'}">📦 ${i.stock_qty || 0}</span>
            </div>
          </div>`).join('')}
      </div>`;
    } else {
      const visibleCols = getVisibleColumns();
      const activeCols = ALL_COLUMNS.filter(c => visibleCols[c.id]);

      content.innerHTML = `
      <div class="table-wrapper">
        <table id="items-table">
          <thead><tr>
            ${activeCols.map(c => {
        if (c.id === 'img') return `<th style="width:50px" class="no-sort">${isAR ? c.label_ar : c.label_en}</th>`;
        if (c.id === 'actions') return `<th class="no-sort" style="width:110px">${isAR ? c.label_ar : c.label_en}</th>`;
        return `<th>${isAR ? c.label_ar : c.label_en}</th>`;
      }).join('')}
          </tr></thead>
          <tbody>
            ${paged.map(i => {
        const cat = _cats.find(c => c.id === i.category_id);
        const name = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
        const low = (i.stock_qty || 0) <= (i.min_qty || 0);
        const cost = parseFloat(i.cost_price) || 0;
        const price = parseFloat(i.selling_price) || 0;
        const profitAmt = price - cost;
        const marginPct = price > 0 ? ((profitAmt / price) * 100).toFixed(1) : '0';

        return `
              <tr style="cursor:pointer" onclick="Items.openForm(${i.id})">
                ${activeCols.map(c => {
          switch (c.id) {
            case 'img':
              return `<td onclick="event.stopPropagation()">
                        ${i.image
                  ? `<img src="${i.image}" style="width:36px;height:36px;border-radius:6px;object-fit:cover">`
                  : `<div style="width:36px;height:36px;border-radius:6px;background:var(--surface-2);display:flex;align-items:center;justify-content:center;font-size:0.65rem;color:var(--text-muted)">IMG</div>`}
                      </td>`;
            case 'code':
              return `<td style="font-weight:700;color:var(--primary);font-size:0.8rem">
                        <div>${Utils.sanitize(i.item_code || '-')}</div>
                        ${(i.is_scale && i.scale_plu) ? `<div style="font-size:0.68rem;color:#0284c7;font-weight:800">PLU: ${i.scale_plu}</div>` : ''}
                      </td>`;
            case 'barcode':
              return `<td style="font-family:monospace;font-size:0.75rem;color:var(--text-secondary)">${Utils.sanitize(i.barcode || '-')}</td>`;
            case 'name':
              return `<td>
                        <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                          <span style="font-weight:700;font-size:0.84rem">${Utils.truncate(name, 35)}</span>
                          ${(i.needs_definition || i.is_temporary) ? `<span class="badge" style="background:#fee2e2;color:#dc2626;border:1px solid #f87171;font-size:0.68rem;padding:1px 6px;border-radius:4px;font-weight:800">⚠️ ${isAR ? 'يحتاج استكمال التعريف' : 'Needs Definition'}</span>` : ''}
                          ${i.is_scale ? `<span class="badge" style="background:rgba(2,132,199,0.15);color:#0284c7;border:1px solid rgba(2,132,199,0.3);font-size:0.68rem;padding:1px 5px;border-radius:4px;font-weight:800">⚖️ ${isAR ? 'ميزان' : 'Scale'}${i.scale_plu ? ` #${i.scale_plu}` : ''}</span>` : ''}
                        </div>
                        ${(i.name_en && i.name_ar) ? `<div style="font-size:0.72rem;color:var(--text-muted)">${Utils.truncate(isAR ? i.name_en : i.name_ar, 30)}</div>` : ''}
                      </td>`;
            case 'category':
              return `<td style="font-size:0.78rem"><span class="badge badge-secondary">${cat ? Utils.sanitize(isAR ? (cat.name_ar || cat.name) : (cat.name || cat.name_ar)) : '-'}</span></td>`;
            case 'unit':
              return `<td style="font-size:0.78rem">${Utils.sanitize(i.unit_name || i.unit || 'Piece')}</td>`;
            case 'cost':
              return `<td style="font-size:0.82rem;color:var(--text-secondary)">${_fmtItemPrice(cost)}</td>`;
            case 'price':
              return `<td style="font-weight:800;color:var(--success);font-size:0.85rem">${_fmtItemPrice(price)}</td>`;
            case 'wholesale':
              return `<td style="font-size:0.82rem;color:#38bdf8">${_fmtItemPrice(i.wholesale_price || 0)}</td>`;
            case 'min_price':
              return `<td style="font-size:0.82rem;color:var(--text-muted)">${_fmtItemPrice(i.min_selling_price || 0)}</td>`;
            case 'profit':
              return `<td style="font-size:0.78rem;font-weight:700;color:${profitAmt >= 0 ? '#10b981' : '#ef4444'}">${_fmtItemPrice(profitAmt)} (${marginPct}%)</td>`;
            case 'stock':
              return `<td>
                        <span style="font-weight:800;font-size:0.85rem;color:${low ? 'var(--danger)' : 'var(--text-primary)'}">${i.stock_qty || 0}</span>
                        ${low ? `<span class="badge badge-danger" style="margin-left:4px">${isAR ? 'منخفض' : 'Low'}</span>` : ''}
                      </td>`;
            case 'min_qty':
              return `<td style="font-size:0.78rem;color:var(--text-muted)">${i.min_qty || 0}</td>`;
            case 'tax':
              return `<td style="font-size:0.78rem">${i.tax_rate ? `${i.tax_rate}%` : '0%'}</td>`;
            case 'supplier':
              return `<td style="font-size:0.78rem;color:var(--text-secondary)">${Utils.sanitize(i.supplier_name || i.supplier || '-')}</td>`;
            case 'location':
              return `<td style="font-size:0.78rem;color:var(--text-muted)">${Utils.sanitize(i.shelf_location || i.location || '-')}</td>`;
            case 'status':
              return `<td><span class="badge ${i.status === 'active' ? 'badge-success' : i.status === 'inactive' ? 'badge-secondary' : 'badge-warning'}">${i.status || 'active'}</span></td>`;
            case 'actions':
              return `<td onclick="event.stopPropagation()">
                        <div style="display:flex;gap:4px">
                          <button class="btn btn-ghost btn-sm" onclick="Items.openQuickStockAndCostModal(${i.id})" title="${isAR ? 'زيادة ستوك سريع / السعر والكلفة' : 'Quick Add Stock / Price & Cost'}" style="color:#10b981;font-weight:900">
                            ➕
                          </button>
                          <button class="btn btn-ghost btn-sm" onclick="Items.openBarcodeModal(${i.id})" title="${isAR ? 'طباعة باركود' : 'Print Barcode'}" style="color:var(--primary)">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 5v14"/><path d="M8 5v14"/><path d="M12 5v14"/><path d="M17 5v14"/><path d="M21 5v14"/></svg>
                          </button>
                          <button class="btn btn-ghost btn-sm" onclick="Items.openForm(${i.id})" title="${isAR ? 'تعديل' : 'Edit'}">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                          </button>
                          ${isAdmin ? `
                          <button class="btn btn-ghost btn-sm" onclick="Items.deleteItem(${i.id})" title="${isAR ? 'حذف' : 'Delete'}" style="color:var(--danger)">
                            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                          </button>
                          ` : ''}
                        </div>
                      </td>`;
            default:
              return `<td>-</td>`;
          }
        }).join('')}
              </tr>`;
      }).join('')}
            ${paged.length === 0 ? `<tr><td colspan="${activeCols.length}" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد أصناف' : 'No items found'}</td></tr>` : ''}
          </tbody>
        </table>
      </div>`;

      Utils.makeTableSortable('#items-table');
    }

    renderPagination(items.length);
  }

  function renderPagination(total) {
    const pages = Math.ceil(total / _perPage);
    const pgEl = document.getElementById('items-pagination');
    if (!pgEl || pages <= 1) { if (pgEl) pgEl.innerHTML = ''; return; }

    let html = `<span style="font-size:0.78rem;color:var(--text-muted);margin-right:8px">
      ${(_page - 1) * _perPage + 1}–${Math.min(_page * _perPage, total)} / ${total}</span>`;
    if (_page > 1) html += `<button class="page-btn" onclick="Items.goPage(${_page - 1})">‹</button>`;
    for (let p = Math.max(1, _page - 2); p <= Math.min(pages, _page + 2); p++) {
      html += `<button class="page-btn ${p === _page ? 'active' : ''}" onclick="Items.goPage(${p})">${p}</button>`;
    }
    if (_page < pages) html += `<button class="page-btn" onclick="Items.goPage(${_page + 1})">›</button>`;
    pgEl.innerHTML = html;
  }

  function goPage(p) { _page = p; renderItems(getFiltered()); }
  function switchView() { renderItems(getFiltered()); }

  function handleUnitChange(unitValue) {
    const isBox = unitValue === 'box';
    const linkGroup = document.getElementById('item-linked-item-group');
    const piecesGroup = document.getElementById('item-pieces-per-box-group');
    if (linkGroup) linkGroup.style.display = isBox ? '' : 'none';
    if (piecesGroup) piecesGroup.style.display = isBox ? '' : 'none';
  }

  function recalcTotalStock() {
    const localInput = document.querySelector('.item-wh-stock[data-is-local-wh="1"]') || document.querySelector('.item-wh-stock');
    const stockQtyInput = document.getElementById('item-stock-qty');
    if (localInput && stockQtyInput) {
      stockQtyInput.value = parseFloat(localInput.value) || 0;
    }
  }

  function onMainStockInput(val) {
    const numVal = parseFloat(val) || 0;
    const localInput = document.querySelector('.item-wh-stock[data-is-local-wh="1"]') || document.querySelector('.item-wh-stock');
    if (localInput) {
      localInput.value = numVal;
    }
  }

  function renderLinkedItemOptions(items, selectedId = null) {
    const isAR = i18n.getLang() === 'ar';
    const container = document.getElementById('linked-item-options');
    if (!container) return;

    let html = `<div class="searchable-select-option ${!selectedId ? 'selected' : ''}" onclick="Items.selectLinkedItemOption(null)" style="padding:6px 10px;border-radius:4px;cursor:pointer;font-size:0.78rem;display:flex;justify-content:space-between;align-items:center;transition:background 0.15s">
      <span>-- ${isAR ? 'بلا تحديد' : 'None'} --</span>
    </div>`;

    items.forEach(i => {
      const isSelected = selectedId === i.id || (window._selectedLinkedItemId === i.id);
      const name = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
      const codeAndBc = [i.item_code, i.barcode].filter(Boolean).join(' | ');

      html += `<div class="searchable-select-option ${isSelected ? 'selected' : ''}" onclick="Items.selectLinkedItemOption(${i.id})" style="padding:6px 10px;border-radius:4px;cursor:pointer;font-size:0.78rem;display:flex;justify-content:space-between;align-items:center;transition:background 0.15s">
        <span style="font-weight:600">${Utils.sanitize(name)}</span>
        <span class="option-details" style="font-size:0.72rem;color:var(--text-secondary);opacity:0.8">${Utils.sanitize(codeAndBc)}</span>
      </div>`;
      if (isSelected) {
        const displayEl = document.getElementById('linked-item-display');
        if (displayEl) displayEl.textContent = `[${i.item_code || ''}] ${name}`;
      }
    });

    container.innerHTML = html;

    // Highlight selected item with CSS styles
    container.querySelectorAll('.searchable-select-option').forEach(el => {
      if (el.classList.contains('selected')) {
        el.style.background = 'var(--primary)';
        el.style.color = 'white';
        const detailSpan = el.querySelector('.option-details');
        if (detailSpan) detailSpan.style.color = 'rgba(255,255,255,0.8)';
      } else {
        el.style.background = '';
        el.style.color = '';
        const detailSpan = el.querySelector('.option-details');
        if (detailSpan) detailSpan.style.color = 'var(--text-secondary)';
      }
    });
  }

  function toggleLinkedItemDropdown(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('linked-item-dropdown');
    if (!dropdown) return;
    const isVisible = dropdown.style.display === 'block';

    // Close other dropdowns
    document.querySelectorAll('.searchable-select-dropdown').forEach(d => d.style.display = 'none');

    dropdown.style.display = isVisible ? 'none' : 'block';
    if (!isVisible) {
      const searchInput = document.getElementById('linked-item-search');
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      const currentItemId = window._editItemId;
      const filteredItems = (window._allItemsList || []).filter(i => !currentItemId || i.id !== currentItemId);
      renderLinkedItemOptions(filteredItems, window._selectedLinkedItemId);
    }
  }

  function filterLinkedItemDropdown(val) {
    const isAR = i18n.getLang() === 'ar';
    const query = val.toLowerCase().trim();
    const currentItemId = window._editItemId;
    const items = (window._allItemsList || []).filter(i => !currentItemId || i.id !== currentItemId);
    const filtered = items.filter(i => {
      const name = (isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar)) || '';
      const code = i.item_code || '';
      const barcode = i.barcode || '';
      return name.toLowerCase().includes(query) || code.toLowerCase().includes(query) || barcode.toLowerCase().includes(query);
    });
    renderLinkedItemOptions(filtered, window._selectedLinkedItemId);
  }

  const WORLD_COUNTRIES = [
    { code: 'LB', name_ar: 'لبنان', name_en: 'Lebanon', flag: '🇱🇧' },
    { code: 'CN', name_ar: 'الصين', name_en: 'China', flag: '🇨🇳' },
    { code: 'US', name_ar: 'الولايات المتحدة', name_en: 'USA', flag: '🇺🇸' },
    { code: 'DE', name_ar: 'ألمانيا', name_en: 'Germany', flag: '🇩🇪' },
    { code: 'IT', name_ar: 'إيطاليا', name_en: 'Italy', flag: '🇮🇹' },
    { code: 'FR', name_ar: 'فرنسا', name_en: 'France', flag: '🇫🇷' },
    { code: 'TR', name_ar: 'تركيا', name_en: 'Turkey', flag: '🇹🇷' },
    { code: 'AE', name_ar: 'الإمارات', name_en: 'UAE', flag: '🇦🇪' },
    { code: 'SA', name_ar: 'السعودية', name_en: 'Saudi Arabia', flag: '🇸🇦' },
    { code: 'JP', name_ar: 'اليابان', name_en: 'Japan', flag: '🇯🇵' },
    { code: 'KR', name_ar: 'كوريا الجنوبية', name_en: 'South Korea', flag: '🇰🇷' },
    { code: 'GB', name_ar: 'المملكة المتحدة', name_en: 'United Kingdom', flag: '🇬🇧' },
    { code: 'ES', name_ar: 'إسبانيا', name_en: 'Spain', flag: '🇪🇸' },
    { code: 'IN', name_ar: 'الهند', name_en: 'India', flag: '🇮🇳' },
    { code: 'VN', name_ar: 'فيتنام', name_en: 'Vietnam', flag: '🇻🇳' },
    { code: 'TW', name_ar: 'تايوان', name_en: 'Taiwan', flag: '🇹🇼' },
    { code: 'MY', name_ar: 'ماليزيا', name_en: 'Malaysia', flag: '🇲🇾' },
    { code: 'TH', name_ar: 'تايلاند', name_en: 'Thailand', flag: '🇹🇭' },
    { code: 'EG', name_ar: 'مصر', name_en: 'Egypt', flag: '🇪🇬' },
    { code: 'JO', name_ar: 'الأردن', name_en: 'Jordan', flag: '🇯🇴' },
    { code: 'SY', name_ar: 'سوريا', name_en: 'Syria', flag: '🇸🇾' },
    { code: 'KW', name_ar: 'الكويت', name_en: 'Kuwait', flag: '🇰🇼' },
    { code: 'QA', name_ar: 'قطر', name_en: 'Qatar', flag: '🇶🇦' },
    { code: 'BH', name_ar: 'البحرين', name_en: 'Bahrain', flag: '🇧🇭' },
    { code: 'OM', name_ar: 'عُمان', name_en: 'Oman', flag: '🇴🇲' },
    { code: 'IQ', name_ar: 'العراق', name_en: 'Iraq', flag: '🇮🇶' },
    { code: 'CA', name_ar: 'كندا', name_en: 'Canada', flag: '🇨🇦' },
    { code: 'BR', name_ar: 'البرازيل', name_en: 'Brazil', flag: '🇧🇷' },
    { code: 'MX', name_ar: 'المكسيك', name_en: 'Mexico', flag: '🇲🇽' },
    { code: 'CH', name_ar: 'سويسرا', name_en: 'Switzerland', flag: '🇨🇭' },
    { code: 'NL', name_ar: 'هولندا', name_en: 'Netherlands', flag: '🇳🇱' },
    { code: 'BE', name_ar: 'بلجيكا', name_en: 'Belgium', flag: '🇧🇪' },
    { code: 'SE', name_ar: 'السويد', name_en: 'Sweden', flag: '🇸🇪' },
    { code: 'PL', name_ar: 'بولندا', name_en: 'Poland', flag: '🇵🇱' },
    { code: 'GR', name_ar: 'اليونان', name_en: 'Greece', flag: '🇬🇷' },
    { code: 'AU', name_ar: 'أستراليا', name_en: 'Australia', flag: '🇦🇺' },
    { code: 'PT', name_ar: 'البرتغال', name_en: 'Portugal', flag: '🇵🇹' },
    { code: 'AT', name_ar: 'النمسا', name_en: 'Austria', flag: '🇦🇹' },
    { code: 'DK', name_ar: 'الدنمارك', name_en: 'Denmark', flag: '🇩🇰' },
    { code: 'CZ', name_ar: 'التشيك', name_en: 'Czech Republic', flag: '🇨🇿' },
    { code: 'HU', name_ar: 'المجر', name_en: 'Hungary', flag: '🇭🇺' },
    { code: 'RO', name_ar: 'رومانيا', name_en: 'Romania', flag: '🇷🇴' },
    { code: 'BG', name_ar: 'بلغاريا', name_en: 'Bulgaria', flag: '🇧🇬' },
    { code: 'RU', name_ar: 'روسيا', name_en: 'Russia', flag: '🇷🇺' },
    { code: 'UA', name_ar: 'أوكرانيا', name_en: 'Ukraine', flag: '🇺🇦' },
    { code: 'ID', name_ar: 'إندونيسيا', name_en: 'Indonesia', flag: '🇮🇩' },
    { code: 'PH', name_ar: 'الفلبين', name_en: 'Philippines', flag: '🇵🇭' },
    { code: 'PK', name_ar: 'باكستان', name_en: 'Pakistan', flag: '🇵🇰' },
    { code: 'BD', name_ar: 'بنغلاديش', name_en: 'Bangladesh', flag: '🇧🇩' },
    { code: 'ZA', name_ar: 'جنوب أفريقيا', name_en: 'South Africa', flag: '🇿🇦' },
    { code: 'MA', name_ar: 'المغرب', name_en: 'Morocco', flag: '🇲🇦' },
    { code: 'TN', name_ar: 'تونس', name_en: 'Tunisia', flag: '🇹🇳' },
    { code: 'DZ', name_ar: 'الجزائر', name_en: 'Algeria', flag: '🇩🇿' },
  ];

  function renderCountryOptions(list, selectedCode = null) {
    const isAR = i18n.getLang() === 'ar';
    const container = document.getElementById('country-origin-options');
    if (!container) return;

    let html = `<div class="searchable-select-option ${!selectedCode ? 'selected' : ''}" onclick="Items.selectCountryOption(null)" style="padding:7px 10px;border-radius:6px;cursor:pointer;font-size:0.85rem;display:flex;align-items:center;gap:8px;transition:background 0.15s">
      <span>🏳️</span>
      <span>-- ${isAR ? 'غير محدد' : 'None / Not Specified'} --</span>
    </div>`;

    list.forEach(c => {
      const isSel = (selectedCode && (c.code === selectedCode || c.name_en === selectedCode || c.name_ar === selectedCode));
      const displayName = isAR ? `${c.flag} ${c.name_ar} (${c.name_en})` : `${c.flag} ${c.name_en} (${c.name_ar})`;
      html += `<div class="searchable-select-option ${isSel ? 'selected' : ''}" onclick="Items.selectCountryOption('${c.code}')" style="padding:7px 10px;border-radius:6px;cursor:pointer;font-size:0.85rem;display:flex;align-items:center;justify-content:space-between;transition:background 0.15s">
        <span style="font-weight:600">${displayName}</span>
        <span style="font-family:monospace;font-size:0.75rem;opacity:0.75">${c.code}</span>
      </div>`;
    });

    container.innerHTML = html;

    container.querySelectorAll('.searchable-select-option').forEach(el => {
      if (el.classList.contains('selected')) {
        el.style.background = 'var(--primary)';
        el.style.color = 'white';
      } else {
        el.style.background = '';
        el.style.color = '';
      }
    });
  }

  function toggleCountryDropdown(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('country-origin-dropdown');
    if (!dropdown) return;
    const isVisible = dropdown.style.display === 'block';

    // Close other dropdowns
    document.querySelectorAll('.searchable-select-dropdown').forEach(d => d.style.display = 'none');

    dropdown.style.display = isVisible ? 'none' : 'block';
    if (!isVisible) {
      const searchInput = document.getElementById('country-origin-search');
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      renderCountryOptions(WORLD_COUNTRIES, document.getElementById('item-origin-code')?.value);
    }
  }

  function filterCountryDropdown(val) {
    const isAR = i18n.getLang() === 'ar';
    const query = val.toLowerCase().trim();
    const filtered = WORLD_COUNTRIES.filter(c =>
      c.name_en.toLowerCase().includes(query) ||
      c.name_ar.toLowerCase().includes(query) ||
      c.code.toLowerCase().includes(query) ||
      c.flag.includes(query)
    );
    renderCountryOptions(filtered, document.getElementById('item-origin-code')?.value);
  }

  function selectCountryOption(code) {
    const isAR = i18n.getLang() === 'ar';
    const dropdown = document.getElementById('country-origin-dropdown');
    if (dropdown) dropdown.style.display = 'none';

    const codeInput = document.getElementById('item-origin-code');
    const nameInput = document.getElementById('item-origin-name');
    const flagInput = document.getElementById('item-origin-flag');
    const displayEl = document.getElementById('country-origin-display');

    if (!code) {
      if (codeInput) codeInput.value = '';
      if (nameInput) nameInput.value = '';
      if (flagInput) flagInput.value = '';
      if (displayEl) displayEl.innerHTML = isAR ? '🏳️ اختر أو ابحث عن بلد الصنع...' : '🏳️ Select or search country...';
      return;
    }

    const found = WORLD_COUNTRIES.find(c => c.code === code || c.name_en === code || c.name_ar === code);
    if (found) {
      if (codeInput) codeInput.value = found.code;
      if (nameInput) nameInput.value = isAR ? found.name_ar : found.name_en;
      if (flagInput) flagInput.value = found.flag;
      if (displayEl) displayEl.innerHTML = `<b>${found.flag}</b> ${isAR ? found.name_ar : found.name_en} <span style="font-size:0.75rem;color:var(--text-muted)">(${found.code})</span>`;
    }
  }

  function onColorPickerChange(hex) {
    const input = document.getElementById('item-color');
    if (input) input.value = hex;
  }

  function selectLinkedItemOption(id) {
    window._selectedLinkedItemId = id ? parseInt(id) : null;
    const dropdown = document.getElementById('linked-item-dropdown');
    if (dropdown) dropdown.style.display = 'none';

    const displayEl = document.getElementById('linked-item-display');
    if (displayEl) {
      if (!id) {
        displayEl.textContent = i18n.getLang() === 'ar' ? 'اختر الصنف الفردي...' : 'Select piece item...';
      } else {
        const i = (window._allItemsList || []).find(itm => itm.id === id);
        if (i) {
          const name = i18n.getLang() === 'ar' ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
          displayEl.textContent = `[${i.item_code || ''}] ${name}`;
        }
      }
    }
  }

  async function openForm(id = null) {
    if (Auth.getUser()?.role === 'owner') return;
    window._editItemId = id;
    const isAR = i18n.getLang() === 'ar';
    const cur1 = await DB.getSetting('currency_1', 'USD');

    document.querySelectorAll('.item-cur-addon').forEach(el => el.textContent = cur1);

    document.getElementById('item-modal-title').innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
      ${id ? (isAR ? 'تعديل الصنف' : 'Edit Item') : (isAR ? 'صنف جديد' : 'New Item')}`;

    // Reset form
    ['item-code', 'item-barcode', 'item-name-ar', 'item-name-en', 'item-brand', 'item-type', 'item-model',
      'item-color', 'item-desc', 'item-cost', 'item-profit-pct', 'item-price1', 'item-price2', 'item-price3', 'item-max-disc',
      'item-stock-qty', 'item-min-qty', 'item-max-qty', 'item-reorder', 'item-gross-wt',
      'item-net-wt', 'item-size1', 'item-size2', 'item-supplier-code', 'item-notes'].forEach(fid => {
        const el = document.getElementById(fid);
        if (el) el.value = '';
      });
    const summaryBadge = document.getElementById('item-profit-summary-badge');
    if (summaryBadge) summaryBadge.innerHTML = '';
    selectCountryOption(null);

    // Populate linked items dropdown
    const allItems = await DB.getAll('items');
    window._allItemsList = allItems;

    // Populate warehouses inputs
    let warehouses = await DB.getAll('warehouses');
    if (!warehouses || !warehouses.length) {
      const defaultWh = { name: 'Main Store', name_ar: 'المستودع الرئيسي', code: 'WH-01', is_default: true, location: 'HQ' };
      const newId = await DB.add('warehouses', defaultWh);
      defaultWh.id = newId;
      warehouses = [defaultWh];
    }
    const syncCfg = (typeof window !== 'undefined' && window.BranchSync && typeof BranchSync.getConfig === 'function')
      ? await BranchSync.getConfig()
      : {};
    const isServer = !syncCfg.role || syncCfg.role === 'server';
    const myBranchId = (syncCfg.branchId || syncCfg.nodeId || '').trim().toLowerCase();
    const myNodeName = (syncCfg.nodeName || '').trim().toLowerCase();
    const isMainWh = (w) => {
      const c = (w.code || '').trim().toUpperCase();
      const n = (w.name || '').trim().toLowerCase();
      const nar = (w.name_ar || '').trim();
      return w.id === 1 || c === 'WH-01' || n.includes('main') || nar.includes('رئيسي');
    };

    let localWh = null;
    if (isServer) {
      localWh = warehouses.find(w => isMainWh(w)) || warehouses.find(w => w.is_default) || warehouses[0];
    } else {
      if (typeof window !== 'undefined' && window._posWarehouseId) {
        localWh = warehouses.find(w => String(w.id) === String(window._posWarehouseId));
      }
      if (!localWh) {
        localWh = warehouses.find(w => {
          const c = (w.code || '').trim().toLowerCase();
          const n = (w.name || w.name_ar || '').trim().toLowerCase();
          return (c && (c === myBranchId || c === myNodeName)) || (n && (n === myBranchId || n === myNodeName));
        });
      }
      if (!localWh) {
        localWh = warehouses.find(w => !isMainWh(w)) || warehouses[0];
      }
    }
    window._activeStationWhId = localWh ? localWh.id : (warehouses[0]?.id || 1);

    const whSection = document.getElementById('item-stock-warehouses-section');
    let itemObj = null;
    if (id) {
      itemObj = await DB.get('items', id);
    }
    if (whSection) {
      let whHtml = `<h4 style="font-size:0.85rem;margin-bottom:10px;font-weight:700">${isAR ? 'توزيع المخزون في المستودعات والفروع' : 'Warehouse / Store Stock Distribution'}</h4>
      <div class="grid grid-3">`;
      warehouses.forEach((w) => {
        const isThisStationWh = (localWh && String(w.id) === String(localWh.id));
        let qty = 0;
        if (itemObj) {
          if (isThisStationWh) {
            qty = (itemObj.stock_qty !== undefined && itemObj.stock_qty !== null)
              ? (parseFloat(itemObj.stock_qty) || 0)
              : ((itemObj.warehouse_stocks && itemObj.warehouse_stocks[w.id] !== undefined) ? (parseFloat(itemObj.warehouse_stocks[w.id]) || 0) : 0);
          } else {
            qty = (itemObj.warehouse_stocks && itemObj.warehouse_stocks[w.id] !== undefined)
              ? (parseFloat(itemObj.warehouse_stocks[w.id]) || 0)
              : 0;
          }
        } else if (isThisStationWh) {
          qty = parseFloat(document.getElementById('item-stock-qty')?.value) || 0;
        }
        whHtml += `
        <div class="form-group">
          <label class="form-label">${Utils.sanitize(isAR ? (w.name_ar || w.name) : (w.name || w.name_ar))} ${isThisStationWh ? '<span class="badge badge-primary" style="font-size:0.65rem">' + (isAR ? 'هذا الفرع' : 'This Store') + '</span>' : '<span class="badge badge-secondary" style="font-size:0.6rem">' + (isAR ? 'فرع آخر (للعرض)' : 'Other Branch') + '</span>'}</label>
          <input type="number" class="form-control item-wh-stock" data-wh-id="${w.id}" data-is-local-wh="${isThisStationWh ? '1' : '0'}" value="${qty}" step="any" ${isThisStationWh ? 'oninput="Items.recalcTotalStock()"' : 'readonly style="opacity:0.75;background:var(--surface-2)"'}>
        </div>`;
      });
      whHtml += `</div>`;
      whSection.innerHTML = whHtml;
    }

    // Reset Packaging Selects
    document.getElementById('item-sell-unit').value = 'piece';
    document.getElementById('item-pieces-per-box').value = '1';
    window._selectedLinkedItemId = null;

    const displayEl = document.getElementById('linked-item-display');
    if (displayEl) displayEl.textContent = isAR ? 'اختر الصنف الفردي...' : 'Select piece item...';

    handleUnitChange('piece');

    if (itemObj) {
      if (itemObj.selling_unit) document.getElementById('item-sell-unit').value = itemObj.selling_unit;
      if (itemObj.pieces_per_box) document.getElementById('item-pieces-per-box').value = itemObj.pieces_per_box;
      if (itemObj.linked_item_id) {
        selectLinkedItemOption(itemObj.linked_item_id);
      }
      handleUnitChange(itemObj.selling_unit || 'piece');
    }

    const currentItemId = id;
    const filteredItems = allItems.filter(i => !currentItemId || i.id !== currentItemId);
    renderLinkedItemOptions(filteredItems, window._selectedLinkedItemId);

    const prev = document.getElementById('item-image-preview');
    const ph = document.getElementById('item-image-placeholder');
    if (prev) prev.style.display = 'none';
    if (ph) ph.style.display = '';
    window._itemImageData = null;

    if (id) {
      const item = await DB.get('items', id);
      if (item) {
        const fields = {
          'item-code': item.item_code, 'item-barcode': item.barcode,
          'item-name-ar': item.name_ar, 'item-name-en': item.name_en,
          'item-brand': item.brand, 'item-type': item.type,
          'item-model': item.model, 'item-color': item.color, 'item-desc': item.description,
          'item-cost': item.cost_price, 'item-profit-pct': item.profit_pct, 'item-price1': item.selling_price,
          'item-price2': item.selling_price_2, 'item-price3': item.selling_price_3,
          'item-max-disc': item.max_disc, 'item-stock-qty': item.stock_qty,
          'item-min-qty': item.min_qty, 'item-max-qty': item.max_qty,
          'item-reorder': item.reorder_point, 'item-gross-wt': item.gross_weight,
          'item-net-wt': item.net_weight, 'item-size1': item.size1, 'item-size2': item.size2,
          'item-supplier-code': item.supplier_code, 'item-notes': item.notes,
        };
        Object.entries(fields).forEach(([fid, val]) => {
          const el = document.getElementById(fid);
          if (el && val !== undefined && val !== null) el.value = val;
        });
        // Select country of origin
        if (item.origin_country_code || item.origin_country) {
          selectCountryOption(item.origin_country_code || item.origin_country);
        } else {
          selectCountryOption(null);
        }
        // Selects
        if (item.unit) document.getElementById('item-unit').value = item.unit;
        if (item.status) document.getElementById('item-status').value = item.status;
        if (item.category_id) document.getElementById('item-category').value = item.category_id;
        // Online Store publish settings
        const showOnlineEl = document.getElementById('item-show-online');
        if (showOnlineEl) showOnlineEl.checked = (typeof item.show_online !== 'undefined') ? Boolean(item.show_online) : true;
        const onlinePriceEl = document.getElementById('item-online-price');
        if (onlinePriceEl) {
          const itemSellingPrice = parseFloat(item.selling_price) || 0;
          const itemOnlinePrice = (item.online_price !== undefined && item.online_price !== null && item.online_price !== '') ? parseFloat(item.online_price) : null;
          // If online price is missing or matches selling price, leave blank so selling price changes auto-propagate
          if (itemOnlinePrice === null || isNaN(itemOnlinePrice) || itemOnlinePrice === itemSellingPrice) {
            onlinePriceEl.value = '';
          } else {
            onlinePriceEl.value = itemOnlinePrice;
          }
          onlinePriceEl.placeholder = itemSellingPrice > 0 ? itemSellingPrice.toFixed(2) : '0.00';
        }
        if (item.vat_type) document.getElementById('item-vat-type').value = item.vat_type;
        if (item.costing) document.getElementById('item-costing').value = item.costing;
        if (item.supplier_id) document.getElementById('item-supplier').value = item.supplier_id;
        if (item.serial_tracking) document.getElementById('item-serial').checked = true;
        if (item.batch_tracking) document.getElementById('item-batch').checked = true;
        if (item.expiry_tracking) {
          document.getElementById('item-expiry').checked = true;
          document.getElementById('item-expiry-date-group').style.display = 'block';
        }
        if (item.expiry_date) document.getElementById('item-expiry-date').value = item.expiry_date;
        if (item.image) {
          document.getElementById('item-image-thumb').src = item.image;
          if (prev) prev.style.display = '';
          if (ph) ph.style.display = 'none';
          window._itemImageData = item.image;
        }
        if (document.getElementById('item-is-scale')) document.getElementById('item-is-scale').checked = !!item.is_scale;
        if (document.getElementById('item-scale-plu')) document.getElementById('item-scale-plu').value = item.scale_plu || '';
        if (document.getElementById('item-scale-type')) document.getElementById('item-scale-type').value = item.scale_type || 'weight';
        if (document.getElementById('item-scale-tare')) document.getElementById('item-scale-tare').value = item.tare_weight || '';
        if (document.getElementById('item-scale-price')) document.getElementById('item-scale-price').value = item.selling_price || '';
        if (document.getElementById('item-scale-cost')) document.getElementById('item-scale-cost').value = item.cost_price || '';
        if (document.getElementById('item-scale-vat-type')) document.getElementById('item-scale-vat-type').value = item.vat_type || 'none';
        toggleScaleFields(!!item.is_scale);
        recalcPricing('init');
      }
    } else {
      if (document.getElementById('item-is-scale')) document.getElementById('item-is-scale').checked = false;
      if (document.getElementById('item-scale-plu')) document.getElementById('item-scale-plu').value = '';
      if (document.getElementById('item-scale-type')) document.getElementById('item-scale-type').value = 'weight';
      if (document.getElementById('item-scale-tare')) document.getElementById('item-scale-tare').value = '';
      if (document.getElementById('item-scale-price')) document.getElementById('item-scale-price').value = '';
      if (document.getElementById('item-scale-cost')) document.getElementById('item-scale-cost').value = '';
      if (document.getElementById('item-scale-vat-type')) document.getElementById('item-scale-vat-type').value = 'none';
      toggleScaleFields(false);
    }

    Utils.openModal('item-modal');
    switchTab('tab-basic');
  }

  async function previewImage(input) {
    if (!input.files?.[0]) return;
    const b64 = await Utils.fileToBase64(input.files[0]);
    window._itemImageData = b64;
    document.getElementById('item-image-thumb').src = b64;
    document.getElementById('item-image-preview').style.display = '';
    document.getElementById('item-image-placeholder').style.display = 'none';
  }

  function clearImage() {
    window._itemImageData = null;
    document.getElementById('item-image-thumb').src = '';
    document.getElementById('item-image-preview').style.display = 'none';
    document.getElementById('item-image-placeholder').style.display = '';
    document.getElementById('item-image-input').value = '';
  }

  function generateRandomBarcode() {
    let bc = '';
    let attempts = 0;
    const existing = new Set((_items || []).map(i => String(i.barcode || '').trim().toLowerCase()));

    do {
      const prefix = '200';
      const randomPart = Math.floor(10000000 + Math.random() * 90000000).toString();
      const raw = prefix + randomPart;

      let sum = 0;
      for (let i = 0; i < 11; i++) {
        sum += parseInt(raw[i]) * (i % 2 === 0 ? 1 : 3);
      }
      const checkDigit = (10 - (sum % 10)) % 10;
      bc = raw + checkDigit;
      attempts++;
    } while (existing.has(bc.toLowerCase()) && attempts < 100);

    const input = document.getElementById('item-barcode');
    if (input) {
      input.value = bc;
      input.style.borderColor = '#10b981';
      setTimeout(() => { if (input) input.style.borderColor = ''; }, 1400);
    }
    return bc;
  }

  async function saveItem() {
    const isAR = i18n.getLang() === 'ar';
    const nameAr = document.getElementById('item-name-ar').value.trim();
    const nameEn = document.getElementById('item-name-en').value.trim();
    const catId = parseInt(document.getElementById('item-category').value) || null;
    const isScaleItem = document.getElementById('item-is-scale')?.checked || false;

    let price1 = parseFloat(document.getElementById('item-price1')?.value);
    if (isNaN(price1) || price1 <= 0) {
      const scalePr = parseFloat(document.getElementById('item-scale-price')?.value);
      if (!isNaN(scalePr) && scalePr > 0) {
        price1 = scalePr;
        if (document.getElementById('item-price1')) document.getElementById('item-price1').value = scalePr;
      } else {
        price1 = 0;
      }
    }

    let costPrice = parseFloat(document.getElementById('item-cost')?.value) || 0;
    if (costPrice <= 0) {
      const scaleCost = parseFloat(document.getElementById('item-scale-cost')?.value) || 0;
      if (scaleCost > 0) {
        costPrice = scaleCost;
        if (document.getElementById('item-cost')) document.getElementById('item-cost').value = scaleCost;
      }
    }

    // Auto-detect and guard against entering Lebanese LBP in USD fields (Default: OFF, enabled via Settings -> General)
    const currencyGuardEnabled = await DB.getSetting('currency_guard_enabled', false);
    const cur1 = _cur1 || 'USD';
    if (currencyGuardEnabled && cur1 === 'USD') {
      const exRate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
      if (price1 >= 1000) {
        const converted = Math.round((price1 / exRate) * 100) / 100;
        Utils.toast(isAR 
          ? `⚠️ تم تحويل السعر من اللبناني (${price1.toLocaleString()} L.L.) إلى الدولار ($${converted}) تلقائياً لتفادي الخطأ.` 
          : `⚠️ Converted price from LBP (${price1.toLocaleString()} L.L.) to USD ($${converted}) automatically.`, 'info', 6000);
        price1 = converted;
        if (document.getElementById('item-price1')) document.getElementById('item-price1').value = converted;
      }
      if (costPrice >= 1000) {
        const convertedCost = Math.round((costPrice / exRate) * 100) / 100;
        costPrice = convertedCost;
        if (document.getElementById('item-cost')) document.getElementById('item-cost').value = convertedCost;
      }
    }

    const vatType = (document.getElementById('item-scale-vat-type')?.value && document.getElementById('item-scale-vat-type').value !== 'none')
      ? document.getElementById('item-scale-vat-type').value
      : (document.getElementById('item-vat-type')?.value || 'none');

    const barcode = document.getElementById('item-barcode').value.trim();

    // Reset error borders
    ['item-name-ar', 'item-name-en', 'item-category', 'item-price1', 'item-scale-price', 'item-barcode'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.borderColor = '';
    });

    if (!nameAr && !nameEn) {
      switchTab('tab-basic');
      const el = document.getElementById(isAR ? 'item-name-ar' : 'item-name-en');
      if (el) { el.style.borderColor = '#ef4444'; el.focus(); }
      Utils.toast(isAR ? '⚠️ يرجى إدخال اسم الصنف (عربي أو إنجليزي)' : '⚠️ Please enter item name (Arabic or English)', 'warning');
      return;
    }

    if (!catId) {
      switchTab('tab-basic');
      const catEl = document.getElementById('item-category');
      if (catEl) { catEl.style.borderColor = '#ef4444'; catEl.focus(); }
      Utils.toast(isAR ? '⚠️ يرجى اختيار تصنيف الصنف' : '⚠️ Please select a category', 'warning');
      return;
    }

    if (!barcode) {
      switchTab('tab-basic');
      const el = document.getElementById('item-barcode');
      if (el) { el.style.borderColor = '#ef4444'; el.focus(); }
      Utils.toast(isAR ? '⚠️ الباركود إلزامي. يرجى مسح أو توليد باركود للصنف' : '⚠️ Barcode is required. Please scan or generate a barcode', 'warning');
      return;
    }

    // Check Barcode Uniqueness (must be distinct across all items)
    const duplicate = (_items || []).find(i =>
      String(i.barcode || '').trim().toLowerCase() === barcode.toLowerCase() &&
      (!window._editItemId || i.id !== window._editItemId)
    );
    if (duplicate) {
      switchTab('tab-basic');
      const el = document.getElementById('item-barcode');
      if (el) { el.style.borderColor = '#ef4444'; el.focus(); }
      const dupName = isAR ? (duplicate.name_ar || duplicate.name_en) : (duplicate.name_en || duplicate.name_ar);
      Utils.toast(isAR
        ? `⚠️ هذا الباركود (${barcode}) مستخدم مسبقاً للصنف: "${dupName}". الباركود يجب أن يكون فريداً.`
        : `⚠️ Barcode (${barcode}) is already used for item: "${dupName}". Barcodes must be unique.`,
        'warning'
      );
      return;
    }

    if (barcode.length < 3 && !isNaN(Number(barcode))) {
      Utils.toast(isAR
        ? '💡 نصيحة: يُفضل استخدام باركود من 3 أرقام أو أكثر (مثل 1001) لتفادي الأخطاء أثناء المسح السريع.'
        : '💡 Tip: Barcodes with 3+ digits (e.g. 1001) are recommended for reliable barcode scanner reads.',
        'info', 4000
      );
    }

    if (price1 <= 0) {
      if (isScaleItem) {
        switchTab('tab-basic');
        const scEl = document.getElementById('item-scale-price');
        if (scEl) { scEl.style.borderColor = '#ef4444'; scEl.focus(); }
      } else {
        switchTab('tab-pricing');
        const prEl = document.getElementById('item-price1');
        if (prEl) { prEl.style.borderColor = '#ef4444'; prEl.focus(); }
      }
      Utils.toast(isAR ? '⚠️ يرجى تحديد سعر البيع الأساسي (أكبر من 0)' : '⚠️ Please set a selling price (greater than 0)', 'warning');
      return;
    }

    const data = {
      item_code: document.getElementById('item-code').value.trim() || await DB.nextSeq('items', 'ITM-', 5),
      barcode: document.getElementById('item-barcode').value.trim(),
      name_ar: nameAr,
      name_en: nameEn,
      category_id: parseInt(document.getElementById('item-category').value) || null,
      brand: document.getElementById('item-brand').value.trim(),
      type: document.getElementById('item-type').value.trim(),
      model: document.getElementById('item-model').value.trim(),
      color: document.getElementById('item-color').value.trim(),
      origin_country: document.getElementById('item-origin-name').value.trim(),
      origin_country_code: document.getElementById('item-origin-code').value.trim(),
      origin_flag: document.getElementById('item-origin-flag').value.trim(),
      description: document.getElementById('item-desc').value.trim(),
      unit: document.getElementById('item-unit').value,
      status: document.getElementById('item-status').value,
      vat_type: vatType,
      cost_price: costPrice,
      profit_pct: parseFloat(document.getElementById('item-profit-pct')?.value) || 0,
      selling_price: price1,
      selling_price_2: parseFloat(document.getElementById('item-price2').value) || 0,
      selling_price_3: parseFloat(document.getElementById('item-price3').value) || 0,
      max_disc: parseFloat(document.getElementById('item-max-disc').value) || 0,
      stock_qty: (() => {
        const localWhInput = document.querySelector('.item-wh-stock[data-is-local-wh="1"]');
        if (localWhInput && localWhInput.value !== '') {
          return parseFloat(localWhInput.value) || 0;
        }
        return parseFloat(document.getElementById('item-stock-qty')?.value) || 0;
      })(),
      stock: (() => {
        const localWhInput = document.querySelector('.item-wh-stock[data-is-local-wh="1"]');
        if (localWhInput && localWhInput.value !== '') {
          return parseFloat(localWhInput.value) || 0;
        }
        return parseFloat(document.getElementById('item-stock-qty')?.value) || 0;
      })(),
      min_qty: parseFloat(document.getElementById('item-min-qty').value) || 0,
      max_qty: parseFloat(document.getElementById('item-max-qty').value) || 0,
      reorder_point: parseFloat(document.getElementById('item-reorder').value) || 0,
      costing: document.getElementById('item-costing').value,
      serial_tracking: document.getElementById('item-serial').checked,
      batch_tracking: document.getElementById('item-batch').checked,
      expiry_tracking: document.getElementById('item-expiry').checked,
      expiry_date: document.getElementById('item-expiry-date').value || null,
      gross_weight: parseFloat(document.getElementById('item-gross-wt').value) || 0,
      net_weight: parseFloat(document.getElementById('item-net-wt').value) || 0,
      size1: parseFloat(document.getElementById('item-size1').value) || 0,
      size2: parseFloat(document.getElementById('item-size2').value) || 0,
      supplier_id: parseInt(document.getElementById('item-supplier').value) || null,
      notes: document.getElementById('item-notes').value.trim(),
      show_online: document.getElementById('item-show-online') ? document.getElementById('item-show-online').checked : true,
      online_price: (() => {
        const opVal = document.getElementById('item-online-price')?.value?.trim();
        return (opVal !== '' && !isNaN(parseFloat(opVal)) && parseFloat(opVal) > 0) ? parseFloat(opVal) : price1;
      })(),
      image: window._itemImageData || null,
      is_scale: document.getElementById('item-is-scale')?.checked || false,
      scale_plu: document.getElementById('item-scale-plu')?.value.trim() || '',
      scale_type: document.getElementById('item-scale-type')?.value || 'weight',
      tare_weight: parseFloat(document.getElementById('item-scale-tare')?.value) || 0,
      selling_unit: document.getElementById('item-sell-unit').value,
      pieces_per_box: parseInt(document.getElementById('item-pieces-per-box').value) || 1,
      linked_item_id: window._selectedLinkedItemId || null,
      needs_definition: 0,
      is_temporary: 0,
      updated_at: new Date().toISOString(),
      warehouse_stocks: await (async () => {
        const whStocks = {};
        document.querySelectorAll('.item-wh-stock').forEach(input => {
          const val = parseFloat(input.value) || 0;
          if (input.dataset.whId) {
            whStocks[input.dataset.whId] = val;
          }
        });
        const localWhInput = document.querySelector('.item-wh-stock[data-is-local-wh="1"]');
        const localStock = (localWhInput && localWhInput.value !== '')
          ? (parseFloat(localWhInput.value) || 0)
          : (parseFloat(document.getElementById('item-stock-qty')?.value) || 0);
        const activeWhId = window._activeStationWhId || 1;
        whStocks[activeWhId] = localStock;
        whStocks['1'] = localStock;
        if (typeof window !== 'undefined' && window._posWarehouseId) {
          whStocks[window._posWarehouseId] = localStock;
        }
        return whStocks;
      })()
    };

    try {
      let finalItemId = window._editItemId;
      if (window._editItemId) {
        const oldItem = await DB.get('items', window._editItemId);
        await DB.update('items', { ...data, id: window._editItemId });

        // Update linked piece stock if warehouse distribution was edited in Item Form
        if (oldItem && data.selling_unit === 'box' && data.linked_item_id && data.pieces_per_box > 1) {
          const linked = await DB.get('items', data.linked_item_id);
          if (linked) {
            if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
            const oldLocalQty = parseFloat(oldItem.stock_qty) || 0;
            const newLocalQty = parseFloat(data.stock_qty) || 0;
            const delta = newLocalQty - oldLocalQty;
            if (delta !== 0) {
              const linkedDelta = delta * data.pieces_per_box;
              const newLinkedStock = Math.max(0, (parseFloat(linked.stock_qty) || 0) + linkedDelta);
              linked.stock_qty = newLinkedStock;
              linked.stock = newLinkedStock;
              const activeWhId = window._activeStationWhId || 1;
              linked.warehouse_stocks[activeWhId] = newLinkedStock;
              linked.warehouse_stocks['1'] = newLinkedStock;
              if (typeof window !== 'undefined' && window._posWarehouseId) {
                linked.warehouse_stocks[window._posWarehouseId] = newLinkedStock;
              }
              await DB.update('items', linked);
            }
          }
        }

        Utils.toast(i18n.t('common.updated'), 'success');
      } else {
        finalItemId = await DB.add('items', data);
        data.id = finalItemId;
        Utils.toast(i18n.t('common.saved'), 'success');
      }

      const savedItem = { ...data, id: finalItemId, selling_price: price1, price: price1, stock_qty: data.stock_qty, stock: data.stock_qty };
      const syncCfg = (typeof window !== 'undefined' && window.BranchSync && typeof BranchSync.getConfig === 'function')
        ? await BranchSync.getConfig()
        : {};
      const isServer = !syncCfg.role || syncCfg.role === 'server';

      if (isServer && typeof CloudSync !== 'undefined') {
        CloudSync.pushItem(savedItem);
      }
      if (typeof BranchSync !== 'undefined' && typeof BranchSync.notifyChange === 'function') {
        BranchSync.notifyChange('items', savedItem);
      }
      if (isServer && typeof OnlineOrders !== 'undefined' && typeof OnlineOrders.syncSingleProductToCloud === 'function') {
        await OnlineOrders.syncSingleProductToCloud(savedItem);
      }

      Utils.closeModal('item-modal');
      _items = await DB.getAll('items');
      renderItems(getFiltered());
    } catch (e) {
      Utils.toast('Error: ' + e.message, 'error');
    }
  }

  function deleteItem(id) {
    const isAR = i18n.getLang() === 'ar';
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'حذف الأصناف مخصص للمدير والمسؤول فقط' : 'Deleting items is restricted to Administrators only', 'warning');
    }
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      const itemToDelete = (_items || []).find(i => i.id === id) || (await DB.get('items', id));
      await DB.remove('items', id);
      recordDeletedItemLocally(itemToDelete || { id });
      if (typeof BranchSync !== 'undefined' && typeof BranchSync.notifyChange === 'function') {
        BranchSync.notifyChange('items', { ...(itemToDelete || {}), id, deleted: true });
      }
      if (typeof OnlineOrders !== 'undefined' && typeof OnlineOrders.deleteProductFromCloud === 'function') {
        OnlineOrders.deleteProductFromCloud(id, itemToDelete?.barcode);
      }
      _items = _items.filter(i => i.id !== id);
      renderItems(getFiltered());
      Utils.toast(i18n.t('common.deleted'), 'success');
    });
  }

  function exportItems() {
    const isAR = i18n.getLang() === 'ar';
    const catMap = new Map((_cats || []).map(c => [c.id, isAR ? (c.name_ar || c.name) : (c.name || c.name_ar)]));
    const dataRows = getFiltered().map(i => {
      const isTaxable = (i.vat_type === 'standard' || i.vat_type === 'taxable');
      return {
        'Item Code': i.item_code || '',
        'Barcode': i.barcode || '',
        'Name English': i.name_en || '',
        'Name Arabic': i.name_ar || '',
        'Category Name': catMap.get(i.category_id) || '',
        'Brand': i.brand || '',
        'Cost Price': i.cost_price || 0,
        'Profit %': i.profit_pct || 0,
        'Selling Price': i.selling_price || 0,
        'Selling Price 2 (Wholesale)': i.selling_price_2 || 0,
        'Selling Price 3 (VIP)': i.selling_price_3 || 0,
        'Stock Qty': i.stock_qty || 0,
        'Min Qty (Reorder)': i.min_qty || 0,
        'Unit': i.unit || 'pc',
        'Selling Unit (piece/box)': i.selling_unit || 'piece',
        'Pieces per Box': i.pieces_per_box || 1,
        'TVA Status': i.vat_type || 'none',
        'TVA Taxable (yes/no)': isTaxable ? 'yes' : 'no',
        'Is Scale Item (yes/no)': i.is_scale ? 'yes' : 'no',
        'Scale PLU Code': i.scale_plu || '',
        'Scale Type': i.scale_type || 'weight',
        'Tare Weight (kg)': i.tare_weight || 0,
        'Status': i.status || 'active'
      };
    });

    if (window.XLSX) {
      try {
        const ws = XLSX.utils.json_to_sheet(dataRows);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Items");
        XLSX.writeFile(wb, `items_export_${new Date().toISOString().slice(0, 10)}.xlsx`);
        Utils.toast(isAR ? '✅ تم تصدير الأصناف إلى ملف إكسل بنجاح' : '✅ Exported items to Excel successfully', 'success');
        return;
      } catch (e) {
        console.warn('XLSX export fallback to CSV:', e);
      }
    }
    Utils.exportCSV(dataRows, 'items');
  }

  async function loadSuppliers(isAR) {
    const suppliers = await DB.getAll('suppliers');
    const sel = document.getElementById('item-supplier');
    if (!sel) return;
    suppliers.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.id;
      opt.textContent = isAR ? (s.name_ar || s.name_en) : (s.name_en || s.name_ar);
      sel.appendChild(opt);
    });
  }

  // ── Quick-Add Category (opens inline overlay, refreshes dropdown) ──
  function quickAddCategory() {
    const isAR = i18n.getLang() === 'ar';
    let _catImageData = null;

    // Remove any existing overlay
    document.getElementById('quick-cat-overlay')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'quick-cat-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;display:flex;align-items:center;justify-content:center';
    overlay.innerHTML = `
      <div style="background:var(--surface);border-radius:14px;padding:24px;width:420px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,0.5)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
          <h3 style="margin:0;font-size:1rem">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16" style="margin-right:6px;vertical-align:middle"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
            ${isAR ? 'إضافة تصنيف جديد' : 'New Category'}
          </h3>
          <button onclick="document.getElementById('quick-cat-overlay').remove()" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:1.2rem;padding:4px">✕</button>
        </div>

        <!-- Image upload -->
        <div id="qcat-img-zone" onclick="document.getElementById('qcat-img-input').click()"
          style="width:100%;height:110px;border:2px dashed var(--border-color);border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;margin-bottom:16px;overflow:hidden;transition:border-color 0.2s"
          onmouseenter="this.style.borderColor='var(--primary)'" onmouseleave="this.style.borderColor='var(--border-color)'">
          <div id="qcat-img-preview" style="display:none;width:100%;height:100%">
            <img id="qcat-img-thumb" style="width:100%;height:100%;object-fit:cover;border-radius:8px">
          </div>
          <div id="qcat-img-placeholder" style="text-align:center;color:var(--text-muted)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="32" height="32"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
            <div style="font-size:0.78rem;margin-top:4px">${isAR ? 'انقر لإضافة صورة' : 'Click to add image'}</div>
          </div>
          <input type="file" id="qcat-img-input" accept="image/*" style="display:none">
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
          <div class="form-group" style="margin:0">
            <label class="form-label">${isAR ? 'الاسم (عربي)' : 'Name (Arabic)'}</label>
            <input type="text" class="form-control" id="qcat-name-ar" placeholder="${isAR ? 'اسم التصنيف' : 'اسم التصنيف'}" dir="rtl">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">${isAR ? 'الاسم (إنجليزي)' : 'Name (English)'}</label>
            <input type="text" class="form-control" id="qcat-name-en" placeholder="Category name">
          </div>
        </div>
        <div class="form-group" style="margin-bottom:16px">
          <label class="form-label">${isAR ? 'الوصف (اختياري)' : 'Description (optional)'}</label>
          <input type="text" class="form-control" id="qcat-desc" placeholder="${isAR ? '...' : '...'}">
        </div>

        <div style="display:flex;gap:10px;justify-content:flex-end">
          <button class="btn btn-secondary" onclick="document.getElementById('quick-cat-overlay').remove()">
            ${isAR ? 'إلغاء' : 'Cancel'}
          </button>
          <button class="btn btn-primary" id="qcat-save-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            ${isAR ? 'حفظ التصنيف' : 'Save Category'}
          </button>
        </div>
      </div>`;

    document.body.appendChild(overlay);

    // Image preview
    document.getElementById('qcat-img-input').onchange = function () {
      const file = this.files[0]; if (!file) return;
      const reader = new FileReader();
      reader.onload = e => {
        _catImageData = e.target.result;
        document.getElementById('qcat-img-thumb').src = _catImageData;
        document.getElementById('qcat-img-preview').style.display = 'block';
        document.getElementById('qcat-img-placeholder').style.display = 'none';
      };
      reader.readAsDataURL(file);
    };

    // Save
    document.getElementById('qcat-save-btn').onclick = async () => {
      const nameAR = document.getElementById('qcat-name-ar').value.trim();
      const nameEN = document.getElementById('qcat-name-en').value.trim();
      const desc = document.getElementById('qcat-desc').value.trim();
      if (!nameEN && !nameAR) {
        Utils.toast(isAR ? 'أدخل اسم التصنيف' : 'Enter category name', 'error'); return;
      }
      const newCat = { name: nameEN || nameAR, name_ar: nameAR, name_en: nameEN, description: desc, image: _catImageData || null };
      const newId = await DB.add('categories', newCat);
      newCat.id = newId;
      _cats.push(newCat);
      // Refresh dropdown in open item form
      const sel = document.getElementById('item-category');
      if (sel) {
        const opt = document.createElement('option');
        opt.value = newId; opt.selected = true;
        opt.textContent = isAR ? (nameAR || nameEN) : (nameEN || nameAR);
        sel.appendChild(opt);
      }
      document.getElementById('quick-cat-overlay').remove();
      Utils.toast(isAR ? 'تم إضافة التصنيف!' : 'Category added!', 'success');
    };
  }

  function _toggleExpiryField(show) {
    const g = document.getElementById('item-expiry-date-group');
    if (g) g.style.display = show ? 'block' : 'none';
    if (!show) {
      const d = document.getElementById('item-expiry-date');
      if (d) d.value = '';
    }
  }

  // ── Barcode Label Printing ──────────────────────────────────────
  async function openBarcodeModal(itemId) {
    const isAR = i18n.getLang() === 'ar';
    const numId = typeof itemId === 'number' ? itemId : (parseInt(itemId) || itemId);
    let item = (_items || []).find(i => String(i.id) === String(itemId) || i.id === numId);
    if (!item && typeof numId === 'number' && !isNaN(numId)) {
      item = await DB.get('items', numId);
    }
    if (!item) {
      item = await DB.get('items', itemId);
    }
    if (!item) {
      Utils.toast(isAR ? 'لم يتم العثور على الصنف' : 'Item not found', 'warning');
      return;
    }

    const labelSize = await DB.getSetting('po_size', '50x30mm');
    const labelPrinter = await DB.getSetting('label_printer', '');
    const labelOrientation = await DB.getSetting('label_orientation', 'portrait');
    const showName = await DB.getSetting('label_show_name', true);
    const showCode = await DB.getSetting('label_show_code', true);
    const showBarcode = await DB.getSetting('label_show_barcode', true);
    const showDigits = await DB.getSetting('label_show_digits', true);
    const showPrice = await DB.getSetting('label_show_price', true);
    const showCompany = await DB.getSetting('label_show_company', false);
    const customW = await DB.getSetting('label_custom_width', 50);
    const customH = await DB.getSetting('label_custom_height', 30);
    const companyName = await DB.getSetting('company_name', 'Red Shark POS');

    const name = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    const code = item.item_code || '';
    const barcodeVal = item.barcode || item.item_code || String(item.id);
    const priceStr = Utils.formatMoney(item.selling_price || 0);

    document.getElementById('barcode-modal')?.remove();

    const svgBarcode = Utils.generateBarcodeSVG(barcodeVal, { height: 34, barWidth: 1.5 });

    const modalHtml = `
    <div class="modal-overlay open" id="barcode-modal">
      <div class="modal" style="max-width:520px">
        <div class="modal-header">
          <div class="modal-title">🏷️ ${isAR ? 'طباعة ملصق باركود' : 'Print Barcode Label'}</div>
          <button class="modal-close" onclick="document.getElementById('barcode-modal').remove()">✕</button>
        </div>
        <div class="modal-body">

          <!-- LIVE PREVIEW BOX -->
          <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;padding:16px;margin-bottom:16px;text-align:center;min-height:160px;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden">
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);margin-bottom:8px;text-transform:uppercase;letter-spacing:1px">
              ${isAR ? 'معاينة الملصق المطبوع' : 'Live Label Preview'}
            </div>
            <div id="bc-preview-card" style="background:white;color:black;padding:8px 12px;border-radius:6px;display:inline-flex;flex-direction:column;justify-content:space-between;align-items:center;width:180px;height:110px;border:1px dashed #64748b;margin:0 auto;box-shadow:0 2px 8px rgba(0,0,0,0.1);transition:all 0.25s ease">
              <div id="bc-pv-company" style="font-size:9px;font-weight:700;color:#475569;margin-bottom:1px;display:${showCompany ? 'block' : 'none'}">${Utils.sanitize(companyName)}</div>
              <div id="bc-pv-name" style="font-weight:800;font-size:11px;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;display:${showName ? 'block' : 'none'}">${Utils.sanitize(name)}</div>
              <div id="bc-pv-code" style="font-size:9px;color:#64748b;display:${showCode ? 'block' : 'none'}">${Utils.sanitize(code)}</div>
              <div id="bc-pv-barcode" style="width:100%;max-width:160px;margin:2px 0;display:${showBarcode ? 'block' : 'none'}">${svgBarcode}</div>
              <div id="bc-pv-digits" style="font-family:monospace;font-size:10px;letter-spacing:1px;display:${showDigits ? 'block' : 'none'}">${barcodeVal}</div>
              <div id="bc-pv-price" style="font-weight:900;font-size:13px;color:#000;display:${showPrice ? 'block' : 'none'}">${priceStr}</div>
            </div>
          </div>

          <!-- SETUP CONTROLS -->
          <div class="grid grid-3" style="gap:10px;margin-bottom:10px">
            <div class="form-group">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'حجم الملصق' : 'Label Size'}</label>
              <select class="form-control" id="bc-modal-size" onchange="Items._onBarcodeSizeChange()">
                <option value="40x24mm" ${labelSize === '40x24mm' ? 'selected' : ''}>🏷️ 40 × 24 mm (2 × 4)</option>
                <option value="40x30mm" ${labelSize === '40x30mm' ? 'selected' : ''}>🏷️ 40 × 30 mm</option>
                <option value="50x30mm" ${labelSize === '50x30mm' ? 'selected' : ''}>🏷️ 50 × 30 mm</option>
                <option value="58x40mm" ${labelSize === '58x40mm' ? 'selected' : ''}>🏷️ 58 × 40 mm</option>
                <option value="100x50mm" ${labelSize === '100x50mm' ? 'selected' : ''}>🏷️ 100 × 50 mm</option>
                <option value="A4" ${labelSize === 'A4' ? 'selected' : ''}>📄 A4 Sheet</option>
                <option value="custom" ${labelSize === 'custom' ? 'selected' : ''}>✏️ ${isAR ? 'حجم مخصص (Custom mm)' : 'Custom (mm)'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'اتجاه الطباعة' : 'Print Direction'}</label>
              <select class="form-control" id="bc-modal-orientation" onchange="Items._updateBarcodeModalPreview()">
                <option value="horizontal" ${(!labelOrientation || labelOrientation === 'horizontal' || labelOrientation === '0' || labelOrientation === 'landscape') ? 'selected' : ''}>↔️ ${isAR ? 'عرضي / أفقي (الوضع الطبيعي)' : 'Horizontal (Standard)'}</option>
                <option value="vertical" ${(labelOrientation === 'vertical' || labelOrientation === 'portrait') ? 'selected' : ''}>↕️ ${isAR ? 'طولي / عمودي' : 'Vertical (Swapped)'}</option>
                <option value="90" ${(labelOrientation === '90' || labelOrientation === 'rotate90') ? 'selected' : ''}>🔄 ${isAR ? 'تدوير 90 درجة' : 'Rotated 90°'}</option>
                <option value="180" ${(labelOrientation === '180' || labelOrientation === 'rotate180') ? 'selected' : ''}>🔄 ${isAR ? 'مقلوب 180 درجة' : 'Inverted 180°'}</option>
                <option value="270" ${(labelOrientation === '270' || labelOrientation === 'rotate270') ? 'selected' : ''}>🔄 ${isAR ? 'تدوير 270 درجة' : 'Rotated 270°'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'الكمية' : 'Quantity'}</label>
              <input type="number" class="form-control" id="bc-modal-qty" value="1" min="1" max="500">
            </div>
          </div>

          <!-- Custom Size Inputs -->
          <div id="bc-custom-size-row" class="grid grid-2" style="gap:10px;margin-bottom:12px;display:${labelSize === 'custom' ? 'grid' : 'none'}">
            <div class="form-group">
              <label class="form-label" style="font-size:0.72rem">${isAR ? 'العرض (Width mm)' : 'Width (mm)'}</label>
              <input type="number" class="form-control" id="bc-custom-w" value="${customW}" min="15" max="250" oninput="Items._updateBarcodeModalPreview()">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.72rem">${isAR ? 'الارتفاع (Height mm)' : 'Height (mm)'}</label>
              <input type="number" class="form-control" id="bc-custom-h" value="${customH}" min="10" max="250" oninput="Items._updateBarcodeModalPreview()">
            </div>
          </div>

          <!-- WHAT TO PRINT TOGGLES -->
          <div style="background:var(--surface-2);border-radius:8px;padding:12px;margin-bottom:12px">
            <div style="font-size:0.78rem;font-weight:700;margin-bottom:8px;color:var(--text-secondary)">
              ${isAR ? 'العناصر المطبوعة على الملصق:' : 'Items to Print on Label:'}
            </div>
            <div class="grid grid-3" style="gap:8px">
              <label style="display:flex;align-items:center;gap:6px;font-size:0.78rem;cursor:pointer">
                <input type="checkbox" id="bc-show-name" ${showName ? 'checked' : ''} onchange="Items._updateBarcodeModalPreview()">
                ${isAR ? 'الاسم' : 'Name'}
              </label>
              <label style="display:flex;align-items:center;gap:6px;font-size:0.78rem;cursor:pointer">
                <input type="checkbox" id="bc-show-code" ${showCode ? 'checked' : ''} onchange="Items._updateBarcodeModalPreview()">
                ${isAR ? 'الكود' : 'Code'}
              </label>
              <label style="display:flex;align-items:center;gap:6px;font-size:0.78rem;cursor:pointer">
                <input type="checkbox" id="bc-show-barcode" ${showBarcode ? 'checked' : ''} onchange="Items._updateBarcodeModalPreview()">
                ${isAR ? 'الباركود' : 'Barcode'}
              </label>
              <label style="display:flex;align-items:center;gap:6px;font-size:0.78rem;cursor:pointer">
                <input type="checkbox" id="bc-show-digits" ${showDigits ? 'checked' : ''} onchange="Items._updateBarcodeModalPreview()">
                ${isAR ? 'الأرقام' : 'Digits'}
              </label>
              <label style="display:flex;align-items:center;gap:6px;font-size:0.78rem;cursor:pointer">
                <input type="checkbox" id="bc-show-price" ${showPrice ? 'checked' : ''} onchange="Items._updateBarcodeModalPreview()">
                ${isAR ? 'السعر' : 'Price'}
              </label>
              <label style="display:flex;align-items:center;gap:6px;font-size:0.78rem;cursor:pointer">
                <input type="checkbox" id="bc-show-company" ${showCompany ? 'checked' : ''} onchange="Items._updateBarcodeModalPreview()">
                ${isAR ? 'المتجر' : 'Store'}
              </label>
            </div>
          </div>

          ${labelPrinter ? `<div style="font-size:0.75rem;color:var(--text-muted)">🖨️ ${isAR ? 'الطابعة المحددة في الإعدادات' : 'Configured Printer'}: <strong style="color:var(--primary)">${Utils.sanitize(labelPrinter)}</strong></div>` : ''}
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary" onclick="document.getElementById('barcode-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Items.execPrintBarcode(${item.id})">🖨️ ${isAR ? 'طباعة الملصق الآن' : 'Print Label Now'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    _updateBarcodeModalPreview();
  }

  function _onBarcodeSizeChange() {
    const size = document.getElementById('bc-modal-size')?.value;
    const customRow = document.getElementById('bc-custom-size-row');
    if (customRow) customRow.style.display = size === 'custom' ? 'grid' : 'none';
    _updateBarcodeModalPreview();
  }

  function _updateBarcodeModalPreview() {
    const showName = document.getElementById('bc-show-name')?.checked ?? true;
    const showCode = document.getElementById('bc-show-code')?.checked ?? true;
    const showBarcode = document.getElementById('bc-show-barcode')?.checked ?? true;
    const showDigits = document.getElementById('bc-show-digits')?.checked ?? true;
    const showPrice = document.getElementById('bc-show-price')?.checked ?? true;
    const showCompany = document.getElementById('bc-show-company')?.checked ?? false;
    const size = document.getElementById('bc-modal-size')?.value || '50x30mm';
    const orient = document.getElementById('bc-modal-orientation')?.value || 'horizontal';

    const elName = document.getElementById('bc-pv-name');
    const elCode = document.getElementById('bc-pv-code');
    const elBc = document.getElementById('bc-pv-barcode');
    const elDigits = document.getElementById('bc-pv-digits');
    const elPrice = document.getElementById('bc-pv-price');
    const elCompany = document.getElementById('bc-pv-company');
    const card = document.getElementById('bc-preview-card');

    if (elName) elName.style.display = showName ? 'block' : 'none';
    if (elCode) elCode.style.display = showCode ? 'block' : 'none';
    if (elBc) elBc.style.display = showBarcode ? 'block' : 'none';
    if (elDigits) elDigits.style.display = showDigits ? 'block' : 'none';
    if (elPrice) elPrice.style.display = showPrice ? 'block' : 'none';
    if (elCompany) elCompany.style.display = showCompany ? 'block' : 'none';

    let previewW = 180;
    let previewH = 110;
    if (size === 'custom') {
      const w = parseInt(document.getElementById('bc-custom-w')?.value) || 50;
      const h = parseInt(document.getElementById('bc-custom-h')?.value) || 30;
      const ratio = w / h;
      if (ratio > 1) {
        previewW = 180;
        previewH = Math.max(70, Math.round(180 / ratio));
      } else {
        previewH = 160;
        previewW = Math.max(70, Math.round(160 * ratio));
      }
    } else if (size === '40x24mm') {
      previewW = 160; previewH = 96;
    } else if (size === '40x30mm') {
      previewW = 160; previewH = 120;
    } else if (size === '58x40mm') {
      previewW = 190; previewH = 130;
    } else if (size === '100x50mm') {
      previewW = 220; previewH = 110;
    }

    if (card) {
      if (orient === 'vertical') {
        card.style.width = `${previewH}px`;
        card.style.height = `${previewW}px`;
        card.style.transform = 'none';
      } else if (orient === '90') {
        card.style.width = `${previewW}px`;
        card.style.height = `${previewH}px`;
        card.style.transform = 'rotate(90deg)';
      } else if (orient === '180') {
        card.style.width = `${previewW}px`;
        card.style.height = `${previewH}px`;
        card.style.transform = 'rotate(180deg)';
      } else if (orient === '270') {
        card.style.width = `${previewW}px`;
        card.style.height = `${previewH}px`;
        card.style.transform = 'rotate(270deg)';
      } else {
        card.style.width = `${previewW}px`;
        card.style.height = `${previewH}px`;
        card.style.transform = 'none';
      }
    }
  }

  async function execPrintBarcode(itemId) {
    const isAR = i18n.getLang() === 'ar';
    const numId = typeof itemId === 'number' ? itemId : (parseInt(itemId) || itemId);
    let item = (_items || []).find(i => String(i.id) === String(itemId) || i.id === numId);
    if (!item && typeof numId === 'number' && !isNaN(numId)) item = await DB.get('items', numId);
    if (!item) item = await DB.get('items', itemId);
    if (!item) return;

    const size = document.getElementById('bc-modal-size')?.value || '50x30mm';
    const orientation = document.getElementById('bc-modal-orientation')?.value || 'horizontal';
    const qty = parseInt(document.getElementById('bc-modal-qty')?.value) || 1;

    const customInputW = parseInt(document.getElementById('bc-custom-w')?.value) || 50;
    const customInputH = parseInt(document.getElementById('bc-custom-h')?.value) || 30;

    const showName = document.getElementById('bc-show-name')?.checked ?? true;
    const showCode = document.getElementById('bc-show-code')?.checked ?? true;
    const showBarcode = document.getElementById('bc-show-barcode')?.checked ?? true;
    const showDigits = document.getElementById('bc-show-digits')?.checked ?? true;
    const showPrice = document.getElementById('bc-show-price')?.checked ?? true;
    const showCompany = document.getElementById('bc-show-company')?.checked ?? false;
    const companyName = await DB.getSetting('company_name', 'Red Shark POS');

    document.getElementById('barcode-modal')?.remove();

    const name = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    const barcodeVal = item.barcode || item.item_code || String(item.id);
    const priceStr = Utils.formatMoney(item.selling_price || 0);

    let finalW, finalH, finalCardW, finalCardH, barH, barW;
    if (size === 'custom') {
      finalW = customInputW;
      finalH = customInputH;
      finalCardW = Math.max(10, finalW - 2);
      finalCardH = Math.max(8, finalH - 2);
      barH = Math.min(24, Math.max(8, Math.round(finalH * 0.38)));
      barW = finalW >= 80 ? 1.6 : finalW >= 50 ? 1.3 : 1.1;
    } else {
      const sizeDims = {
        '40x24mm': { w: 40, h: 24, cardW: 38, cardH: 21, barH: 9, barW: 1.15 },
        '40x30mm': { w: 40, h: 30, cardW: 38, cardH: 27, barH: 10, barW: 1.2 },
        '50x30mm': { w: 50, h: 30, cardW: 48, cardH: 27, barH: 11, barW: 1.3 },
        '58x40mm': { w: 58, h: 40, cardW: 56, cardH: 37, barH: 15, barW: 1.4 },
        '100x50mm': { w: 100, h: 50, cardW: 96, cardH: 47, barH: 20, barW: 1.6 },
        'A4': { w: 210, h: 297, cardW: 65, cardH: 35, barH: 14, barW: 1.4 }
      };
      const dims = sizeDims[size] || { w: 40, h: 24, cardW: 38, cardH: 21, barH: 9, barW: 1.15 };
      finalW = dims.w;
      finalH = dims.h;
      finalCardW = dims.cardW;
      finalCardH = dims.cardH;
      barH = dims.barH;
      barW = dims.barW;
    }

    let pageW = finalW;
    let pageH = finalH;
    let cardW = finalCardW;
    let cardH = finalCardH;
    let transformCSS = '';

    if (orientation === 'vertical' || orientation === 'portrait') {
      pageW = finalH;
      pageH = finalW;
      cardW = finalCardH;
      cardH = finalCardW;
    } else if (orientation === '90' || orientation === 'rotate90') {
      transformCSS = 'transform: rotate(90deg); transform-origin: center center;';
    } else if (orientation === '180' || orientation === 'rotate180') {
      transformCSS = 'transform: rotate(180deg); transform-origin: center center;';
    } else if (orientation === '270' || orientation === 'rotate270') {
      transformCSS = 'transform: rotate(270deg); transform-origin: center center;';
    }

    const barcodeSvg = Utils.generateBarcodeSVG(barcodeVal, {
      height: barH,
      barWidth: barW
    });

    let labelHtmlList = [];
    if (size === 'A4') {
      for (let k = 0; k < qty; k++) {
        labelHtmlList.push(`
        <div class="a4-label-card">
          ${showCompany ? `<div class="lbl-company">${Utils.sanitize(companyName)}</div>` : ''}
          ${showName ? `<div class="lbl-name">${Utils.truncate(name, 26)}</div>` : ''}
          ${showCode ? `<div class="lbl-code">${item.item_code || ''}</div>` : ''}
          ${showBarcode ? `<div class="lbl-barcode-box">${barcodeSvg}</div>` : ''}
          ${showDigits ? `<div class="lbl-val">${barcodeVal}</div>` : ''}
          ${showPrice ? `<div class="lbl-price">${priceStr}</div>` : ''}
        </div>`);
      }
    } else {
      for (let k = 0; k < qty; k++) {
        labelHtmlList.push(`
        <div class="label-page">
          <div class="barcode-label-card">
            ${showCompany ? `<div class="lbl-company">${Utils.sanitize(companyName)}</div>` : ''}
            ${showName ? `<div class="lbl-name">${Utils.truncate(name, 24)}</div>` : ''}
            ${showCode ? `<div class="lbl-code">${item.item_code || ''}</div>` : ''}
            ${showBarcode ? `<div class="lbl-barcode-box">${barcodeSvg}</div>` : ''}
            ${showDigits ? `<div class="lbl-val">${barcodeVal}</div>` : ''}
            ${showPrice ? `<div class="lbl-price">${priceStr}</div>` : ''}
          </div>
        </div>`);
      }
    }

    const html = `
    <style>
      @page { size: ${pageW}mm ${pageH}mm; margin: 0mm; }
      * { box-sizing: border-box; margin: 0; padding: 0; }
      html, body { background: #fff; color: #000; font-family: 'Cairo', 'Inter', sans-serif; margin: 0; padding: 0; }
      
      ${size === 'A4' ? `
        body { padding: 8mm; }
        .labels-wrapper { display: flex; flex-wrap: wrap; gap: 3mm; justify-content: center; }
        .a4-label-card {
          width: 65mm; height: 35mm; border: 1px dashed #cbd5e1; border-radius: 4px; padding: 1.5mm;
          display: flex; flex-direction: column; justify-content: center; align-items: center; gap: 0.8mm;
          page-break-inside: avoid; overflow: hidden; text-align: center;
        }
      ` : `
        .label-page {
          width: ${pageW}mm;
          height: ${pageH}mm;
          max-height: ${pageH}mm;
          page-break-after: always;
          page-break-inside: avoid;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          background: #fff;
          margin: 0;
          padding: 0;
        }
        .barcode-label-card {
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 0.6mm;
          overflow: hidden;
          padding: 0.5mm 1mm;
          width: ${cardW}mm;
          height: ${cardH}mm;
          max-width: ${cardW}mm;
          max-height: ${cardH}mm;
          ${transformCSS}
        }
      `}

      .lbl-company { font-size: 5.5pt; font-weight: 700; color: #475569; line-height: 1; }
      .lbl-name { font-size: 7pt; font-weight: 800; line-height: 1.1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
      .lbl-code { font-size: 5.5pt; color: #475569; line-height: 1; }
      .lbl-barcode-box { width: 100%; display: flex; justify-content: center; margin: 0.3mm auto; line-height: 1; }
      .lbl-val { font-size: 5.5pt; font-family: monospace; letter-spacing: 0.5px; line-height: 1; }
      .lbl-price { font-size: 7.5pt; font-weight: 900; color: #000; line-height: 1; }
    </style>
    <div class="labels-wrapper">
      ${labelHtmlList.join('')}
    </div>`;

    const itemLabelData = {
      printer: (await DB.getSetting('label_printer', '')) || '',
      item_name: showName ? (isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar)) : '',
      barcode: barcodeVal,
      item_code: showCode ? (item.item_code || '') : '',
      price: showPrice ? priceStr : '',
      company_name: showCompany ? companyName : '',
      width_mm: finalW || 40,
      height_mm: finalH || 30,
      qty: qty,
      show_name: showName,
      show_barcode: showBarcode,
      show_digits: showDigits,
      show_price: showPrice,
      show_company: showCompany
    };
    await Utils.printElement(html, `Barcode-${item.id}`, size, itemLabelData);
  }

  function aiTranslateName() {
    const isAR = i18n.getLang() === 'ar';
    const enEl = document.getElementById('item-name-en');
    const arEl = document.getElementById('item-name-ar');
    if (!enEl || !arEl) return;

    if (enEl.value.trim() && !arEl.value.trim()) {
      if (window.AICopilot && typeof AICopilot.translateItemBilingual === 'function') {
        arEl.value = AICopilot.translateItemBilingual(enEl.value);
        Utils.toast(isAR ? 'تمت الترجمة التلقائية إلى العربية' : 'Auto-translated to Arabic', 'success');
      }
    } else if (arEl.value.trim() && !enEl.value.trim()) {
      enEl.value = arEl.value;
      Utils.toast(isAR ? 'تم نسخ الاسم' : 'Name copied', 'info');
    } else if (enEl.value.trim()) {
      if (window.AICopilot && typeof AICopilot.translateItemBilingual === 'function') {
        arEl.value = AICopilot.translateItemBilingual(enEl.value);
        Utils.toast(isAR ? 'تم تحديث الترجمة' : 'Translation refreshed', 'success');
      }
    }
  }

  function recalcPricing(source = 'profit') {
    const costInput = document.getElementById('item-cost');
    const profitPctInput = document.getElementById('item-profit-pct');
    const priceInput = document.getElementById('item-price1');
    const badgeEl = document.getElementById('item-profit-summary-badge');

    const cost = parseFloat(costInput?.value) || 0;
    let profitPct = parseFloat(profitPctInput?.value) || 0;
    let price = parseFloat(priceInput?.value) || 0;

    if (source === 'profit' || source === 'cost') {
      // When profit % is set, calculate price from cost
      if (cost > 0 && profitPctInput && profitPctInput.value !== '') {
        price = cost + (cost * (profitPct / 100));
        if (priceInput) priceInput.value = (Math.round(price * 100) / 100).toFixed(2);
      } else if (source === 'cost' && cost > 0 && price > 0) {
        profitPct = ((price - cost) / cost) * 100;
        if (profitPctInput) profitPctInput.value = (Math.round(profitPct * 10) / 10).toFixed(1);
      }
    } else if (source === 'price' || source === 'init') {
      // When selling price is typed or initialized, calculate profit % from cost
      if (cost > 0 && price >= 0) {
        if (!profitPctInput?.value || source === 'price') {
          profitPct = ((price - cost) / cost) * 100;
          if (profitPctInput) profitPctInput.value = (Math.round(profitPct * 10) / 10).toFixed(1);
        }
      }
    }

    // Update summary display
    const profitAmt = price - cost;
    const margin = price > 0 ? ((profitAmt / price) * 100).toFixed(1) : 0;
    const markup = cost > 0 ? ((profitAmt / cost) * 100).toFixed(1) : 0;
    const isAR = i18n.getLang() === 'ar';

    if (badgeEl) {
      if (cost > 0 || price > 0) {
        const color = profitAmt > 0 ? '#10b981' : (profitAmt === 0 ? '#64748b' : '#ef4444');
        const sign = profitAmt > 0 ? '+' : '';
        badgeEl.innerHTML = `
          <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;background:var(--surface-2);border-radius:10px;padding:10px 14px;border:1px solid var(--border-color)">
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:1.1rem">${profitAmt >= 0 ? '📈' : '📉'}</span>
              <div>
                <div style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'صافي الربح للقطعة:' : 'Net Profit per Unit:'}</div>
                <div style="font-size:1rem;font-weight:900;color:${color}">${sign}${Utils.formatMoney(profitAmt)}</div>
              </div>
            </div>
            <div style="display:flex;gap:14px;font-size:0.78rem">
              <div>
                <span style="color:var(--text-muted)">${isAR ? 'نسبة الربح (Markup):' : 'Markup on Cost:'}</span>
                <strong style="color:${color};margin-left:4px">${sign}${markup}%</strong>
              </div>
              <div>
                <span style="color:var(--text-muted)">${isAR ? 'هامش الربح (Margin):' : 'Profit Margin:'}</span>
                <strong style="color:${color};margin-left:4px">${margin}%</strong>
              </div>
            </div>
          </div>`;
      } else {
        badgeEl.innerHTML = '';
      }
    }

    // Keep scale price and cost inputs synchronized
    const scalePriceInput = document.getElementById('item-scale-price');
    if (scalePriceInput && document.activeElement !== scalePriceInput) {
      scalePriceInput.value = priceInput?.value || '';
    }
    const scaleCostInput = document.getElementById('item-scale-cost');
    if (scaleCostInput && document.activeElement !== scaleCostInput) {
      scaleCostInput.value = costInput?.value || '';
    }
  }

  function setProfitPreset(pct) {
    const input = document.getElementById('item-profit-pct');
    if (input) {
      input.value = pct;
      recalcPricing('profit');
    }
  }

  // ── Import from Excel & Download Sample Template ────────────
  function downloadExcelSample() {
    const isAR = i18n.getLang() === 'ar';
    try {
      if (window.XLSX) {
        const sampleRows = [
          {
            'Item Code': 'ITM-00001',
            'Barcode': '6901234567890',
            'Name English': 'Specialty Coffee 250g',
            'Name Arabic': 'قهوة سبيشالتي 250 غرام',
            'Category Name': 'Beverages',
            'Brand': 'Lavazza',
            'Cost Price': 6.00,
            'Profit %': 33.3,
            'Selling Price': 8.00,
            'Selling Price 2 (Wholesale)': 7.00,
            'Selling Price 3 (VIP)': 7.50,
            'Stock Qty': 50,
            'Min Qty (Reorder)': 10,
            'Unit': 'pc',
            'Selling Unit (piece/box)': 'piece',
            'Pieces per Box': 1,
            'TVA Status': 'standard',
            'TVA Taxable (yes/no)': 'yes',
            'Is Scale Item (yes/no)': 'no',
            'Scale PLU Code': '',
            'Scale Type': 'weight',
            'Tare Weight (kg)': 0,
            'Linked Item Code': ''
          },
          {
            'Item Code': 'ITM-00002',
            'Barcode': '2000101000000',
            'Name English': 'Fresh Halloumi Cheese',
            'Name Arabic': 'جبنة حلوم بلدية طازجة',
            'Category Name': 'Dairy & Cheeses',
            'Brand': 'Local Fresh',
            'Cost Price': 5.50,
            'Profit %': 36.4,
            'Selling Price': 7.50,
            'Selling Price 2 (Wholesale)': 7.00,
            'Selling Price 3 (VIP)': 7.20,
            'Stock Qty': 40,
            'Min Qty (Reorder)': 5,
            'Unit': 'kg',
            'Selling Unit (piece/box)': 'piece',
            'Pieces per Box': 1,
            'TVA Status': 'exempt',
            'TVA Taxable (yes/no)': 'no',
            'Is Scale Item (yes/no)': 'yes',
            'Scale PLU Code': '101',
            'Scale Type': 'weight',
            'Tare Weight (kg)': 0.015,
            'Linked Item Code': ''
          },
          {
            'Item Code': 'ITM-00003',
            'Barcode': '2000102000000',
            'Name English': 'Red Lebanese Apples',
            'Name Arabic': 'تفاح لبناني أحمر ممتاز',
            'Category Name': 'Fruits & Vegetables',
            'Brand': 'Local',
            'Cost Price': 0.80,
            'Profit %': 50.0,
            'Selling Price': 1.20,
            'Selling Price 2 (Wholesale)': 1.10,
            'Selling Price 3 (VIP)': 1.15,
            'Stock Qty': 100,
            'Min Qty (Reorder)': 15,
            'Unit': 'kg',
            'Selling Unit (piece/box)': 'piece',
            'Pieces per Box': 1,
            'TVA Status': 'exempt',
            'TVA Taxable (yes/no)': 'no',
            'Is Scale Item (yes/no)': 'yes',
            'Scale PLU Code': '102',
            'Scale Type': 'weight',
            'Tare Weight (kg)': 0.005,
            'Linked Item Code': ''
          },
          {
            'Item Code': 'ITM-00004',
            'Barcode': '8000500123456',
            'Name English': 'Kinder Bueno 43g',
            'Name Arabic': 'شوكولاتة كيندر بوينو 43 غرام',
            'Category Name': 'Confectionery',
            'Brand': 'Ferrero',
            'Cost Price': 0.85,
            'Profit %': 41.2,
            'Selling Price': 1.20,
            'Selling Price 2 (Wholesale)': 1.05,
            'Selling Price 3 (VIP)': 1.10,
            'Stock Qty': 80,
            'Min Qty (Reorder)': 10,
            'Unit': 'pc',
            'Selling Unit (piece/box)': 'piece',
            'Pieces per Box': 1,
            'TVA Status': 'standard',
            'TVA Taxable (yes/no)': 'yes',
            'Is Scale Item (yes/no)': 'no',
            'Scale PLU Code': '',
            'Scale Type': 'weight',
            'Tare Weight (kg)': 0,
            'Linked Item Code': ''
          }
        ];
        const ws = XLSX.utils.json_to_sheet(sampleRows);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Items Template");
        XLSX.writeFile(wb, "redshark_items_sample.xlsx");
        Utils.toast(isAR ? '✅ تم تنزيل ملف عينة إكسل بنجاح' : '✅ Sample Excel file downloaded successfully', 'success');
        return;
      }
    } catch (e) {
      console.warn('Client-side XLSX download fallback to API:', e);
    }
    window.open("/api/download-sample", "_blank");
  }

  function openImportExcelModal() {
    const isAR = i18n.getLang() === 'ar';
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'هذه الصلاحية مخصصة للمدير والمسؤول فقط' : 'This action is restricted to Administrators only', 'warning');
    }
    const modalId = 'items-import-excel-modal';
    document.getElementById(modalId)?.remove();

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9995">
      <div class="modal" style="max-width:580px;border-radius:16px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,0.35)">
        <div class="modal-header" style="background:var(--surface);border-bottom:1px solid var(--border-color);padding:14px 20px">
          <div class="modal-title" style="font-size:1.1rem;font-weight:800;display:flex;align-items:center;gap:8px">
            <span>📥</span>
            <span>${isAR ? 'استيراد الأصناف من ملف إكسل (Excel / CSV)' : 'Import Items from Excel / CSV'}</span>
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
        </div>

        <div class="modal-body" style="padding:18px 20px;display:flex;flex-direction:column;gap:16px;background:var(--background)">
          
          <!-- Step 1: Download Sample -->
          <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:14px;display:flex;justify-content:space-between;align-items:center;gap:12px;box-shadow:0 2px 6px rgba(0,0,0,0.04)">
            <div>
              <div style="font-weight:800;font-size:0.88rem;color:var(--text-primary)">
                ${isAR ? '1. تنزيل نموذج إكسل الجاهز (Sample Template)' : '1. Download Sample Excel Template'}
              </div>
              <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                ${isAR ? 'نموذج مرتب يحتوي على كافة الأعمدة (الاسم، الباركود، التكلفة، نسبة الربح %، وسعر البيع)' : 'Pre-formatted template with all columns (Barcode, Cost, Profit %, Selling Price)'}
              </div>
            </div>
            <button class="btn btn-secondary btn-sm" onclick="Items.downloadExcelSample()" style="font-weight:800;white-space:nowrap;padding:8px 16px;border-radius:8px">
              ⬇️ ${isAR ? 'تنزيل العينة' : 'Download Sample'}
            </button>
          </div>

          <!-- Step 2: Upload Excel File -->
          <div style="border:2px dashed var(--primary);background:var(--surface);border-radius:12px;padding:20px;text-align:center">
            <div style="font-size:2rem;margin-bottom:6px">📊</div>
            <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary);margin-bottom:4px">
              ${isAR ? '2. اختيار ملف الإكسل للاستيراد' : '2. Select Your Filled Excel File'}
            </div>
            <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:14px">
              ${isAR ? 'يدعم الملفات بصيغة (.xlsx, .xls, .csv)' : 'Supports files in (.xlsx, .xls, .csv)'}
            </div>

            <input type="file" id="items-excel-file-modal" accept=".xlsx, .xls, .csv" class="form-control" style="margin:0 auto;max-width:340px;font-size:0.85rem">

            <label style="display:flex;align-items:center;justify-content:center;gap:6px;margin-top:14px;font-size:0.8rem;cursor:pointer;font-weight:600">
              <input type="checkbox" id="items-import-update-existing" checked>
              <span>${isAR ? 'تحديث الأصناف والأسعار في حال وجود باركود أو كود مطابق' : 'Update existing items & prices if barcode or code matches'}</span>
            </label>
          </div>

          <div id="items-import-status-msg"></div>

        </div>

        <div class="modal-footer" style="background:var(--surface);border-top:1px solid var(--border-color);padding:12px 20px;display:flex;justify-content:flex-end;gap:10px">
          <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Items.importItemsExcel()" style="font-weight:800;padding:8px 24px;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
            🚀 ${isAR ? 'بدء استيراد الأصناف' : 'Start Import'}
          </button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
    Utils.openModal(modalId);
  }

  async function importItemsExcel(fileInputId = 'items-excel-file-modal') {
    const isAR = i18n.getLang() === 'ar';
    const file = document.getElementById(fileInputId)?.files[0];
    if (!file) return Utils.toast(isAR ? 'يرجى اختيار ملف إكسل أو CSV أولاً' : 'Please select an Excel or CSV file first', 'warning');

    if (!window.XLSX) {
      return Utils.toast('XLSX parser library not loaded', 'error');
    }

    const updateExisting = document.getElementById('items-import-update-existing')?.checked ?? true;
    const statusMsgEl = document.getElementById('items-import-status-msg');

    if (statusMsgEl) {
      statusMsgEl.innerHTML = `<div style="color:var(--primary);font-weight:700;font-size:0.85rem">⏳ ${isAR ? 'جاري قراءة واستيراد الأصناف...' : 'Reading and importing items...'}</div>`;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json(sheet);

        if (!rows.length) {
          if (statusMsgEl) statusMsgEl.innerHTML = `<div style="color:var(--danger)">❌ ${isAR ? 'الملف فارغ أو لا يحتوي على بيانات' : 'The file is empty or contains no data'}</div>`;
          return Utils.toast(isAR ? 'الملف فارغ أو لا يحتوي على بيانات' : 'File is empty or contains no rows', 'error');
        }

        // Fetch categories to match names
        const categories = await DB.getAll('categories');
        const catMap = new Map();
        categories.forEach(c => {
          if (c.name) catMap.set(c.name.toLowerCase().trim(), c.id);
          if (c.name_ar) catMap.set(c.name_ar.toLowerCase().trim(), c.id);
        });

        // Fetch existing items to match barcode / code
        const existingItems = await DB.getAll('items');
        const barcodeMap = new Map();
        const codeMap = new Map();
        existingItems.forEach(i => {
          if (i.barcode) barcodeMap.set(String(i.barcode).toLowerCase().trim(), i);
          if (i.item_code) codeMap.set(String(i.item_code).toLowerCase().trim(), i);
        });

        let insertedCount = 0;
        let updatedCount = 0;
        let skippedCount = 0;
        const itemsToPersist = [];

        let seqNum = 1;
        try {
          const lastSeq = await DB.peekSeq('items', 'ITM-', 5);
          const digits = String(lastSeq || '').replace(/\D/g, '');
          seqNum = digits ? parseInt(digits, 10) : 1;
        } catch (e) {
          seqNum = 1;
        }

        const targetWhId = (typeof window !== 'undefined' && window._posWarehouseId) ? window._posWarehouseId : (await DB.getSetting('pos_warehouse_id', 1));

        for (const rawRow of rows) {
          // Normalize row keys (trim whitespace and allow case-insensitive lookup)
          const row = {};
          for (const [k, v] of Object.entries(rawRow || {})) {
            if (k != null) {
              const trimmed = String(k).trim();
              row[trimmed] = v;
              row[trimmed.toLowerCase()] = v;
            }
          }
          const getVal = (...keys) => {
            for (const k of keys) {
              if (row[k] !== undefined && row[k] !== null && row[k] !== '') return row[k];
              const kLower = String(k).toLowerCase();
              if (row[kLower] !== undefined && row[kLower] !== null && row[kLower] !== '') return row[kLower];
            }
            return '';
          };
          const getNum = (...keys) => {
            const v = getVal(...keys);
            const n = parseFloat(v);
            return isNaN(n) ? 0 : n;
          };

          const itemCode = String(getVal('Item Code', 'Code', 'رمز الصنف', 'item_code')).trim();
          const barcode = String(getVal('Barcode', 'الباركود', 'barcode')).trim();
          const nameEn = String(getVal('Name English', 'Item Name', 'Name', 'الاسم انجليزي', 'name_en')).trim();
          const nameAr = String(getVal('Name Arabic', 'اسم الصنف', 'الاسم عربي', 'name_ar')).trim();
          const catName = String(getVal('Category Name', 'Category', 'التصنيف', 'القسم', 'category')).trim();
          const brand = String(getVal('Brand', 'الماركة', 'brand')).trim();
          const costPrice = getNum('Cost Price', 'Cost', 'التكلفة', 'سعر التكلفة', 'cost_price');
          let profitPct = getNum('Profit %', 'Markup %', 'نسبة الربح', 'الربح %', 'profit_pct');
          let sellingPrice = getNum('Selling Price', 'Price', 'سعر البيع', 'سعر البيع 1', 'selling_price');

          // If profit % is provided but price is 0, calculate price:
          if (costPrice > 0 && profitPct > 0 && sellingPrice === 0) {
            sellingPrice = costPrice + (costPrice * (profitPct / 100));
          } else if (costPrice > 0 && sellingPrice > 0 && profitPct === 0) {
            profitPct = ((sellingPrice - costPrice) / costPrice) * 100;
          }

          const price2 = getNum('Selling Price 2 (Wholesale)', 'Selling Price 2', 'Wholesale Price', 'سعر الجملة');
          const price3 = getNum('Selling Price 3 (VIP)', 'Selling Price 3', 'VIP Price', 'سعر خاص');
          const stockQty = getNum('Stock Qty', 'Stock', 'المخزون', 'الكمية', 'stock_qty');
          const minQty = getNum('Min Qty (Reorder)', 'Min Qty', 'حد الطلب', 'min_qty');
          const sellingUnit = String(getVal('Selling Unit (piece/box)', 'Selling Unit', 'selling_unit') || 'piece').trim().toLowerCase();
          const piecesPerBox = parseInt(getVal('Pieces per Box', 'Pieces Per Box', 'القطع في الصندوق')) || 1;

          // Scale & TVA fields
          const isScaleVal = String(getVal('Is Scale Item (yes/no)', 'Is Scale Item', 'Is Scale', 'صنف ميزان', 'ميزان')).trim().toLowerCase();
          const isScale = isScaleVal === 'yes' || isScaleVal === '1' || isScaleVal === 'true' || isScaleVal === 'نعم';
          const scalePlu = String(getVal('Scale PLU Code', 'Scale PLU', 'PLU', 'رمز الميزان')).trim();
          const scaleType = String(getVal('Scale Type', 'نوع الميزان') || 'weight').toLowerCase().includes('price') ? 'price' : 'weight';
          const tareWeight = getNum('Tare Weight (kg)', 'Tare Weight', 'فارغ الميزان', 'وزن الفارغ');

          const tvaVal = String(getVal('TVA Status', 'TVA Taxable (yes/no)', 'TVA Taxable', 'TVA', 'VAT', 'خاضع للضريبة', 'الضريبة')).trim().toLowerCase();
          let vatType = 'none';
          if (tvaVal === 'standard' || tvaVal === 'yes' || tvaVal === 'نعم' || tvaVal === 'taxable' || tvaVal === '1' || tvaVal === 'true') {
            vatType = 'standard';
          } else if (tvaVal === 'exempt' || tvaVal === 'معفى' || tvaVal === 'no' || tvaVal === 'لا') {
            vatType = 'exempt';
          } else if (tvaVal === 'zero' || tvaVal === 'صفري') {
            vatType = 'zero';
          }

          const unitRaw = String(getVal('Unit', 'الوحدة') || (isScale ? 'kg' : (sellingUnit === 'box' ? 'box' : 'pc'))).trim().toLowerCase();
          const unit = unitRaw.includes('kg') || unitRaw.includes('كيلو') ? 'kg' : (unitRaw.includes('g') || unitRaw.includes('غرام') ? 'g' : (unitRaw.includes('box') || unitRaw.includes('صندوق') ? 'box' : (unitRaw.includes('ltr') || unitRaw.includes('ليتر') ? 'ltr' : 'pc')));

          if (!nameEn && !nameAr) {
            skippedCount++;
            continue;
          }

          // Resolve Category
          let categoryId = null;
          if (catName) {
            const normalizedCat = catName.toLowerCase();
            if (catMap.has(normalizedCat)) {
              categoryId = catMap.get(normalizedCat);
            } else {
              const newCat = {
                name: catName,
                name_ar: catName,
                description: 'Imported via Excel'
              };
              categoryId = await DB.add('categories', newCat);
              catMap.set(normalizedCat, categoryId);
            }
          }

          // Check for existing item
          let matchedItem = null;
          if (barcode && barcodeMap.has(barcode.toLowerCase())) {
            matchedItem = barcodeMap.get(barcode.toLowerCase());
          } else if (itemCode && codeMap.has(itemCode.toLowerCase())) {
            matchedItem = codeMap.get(itemCode.toLowerCase());
          }

          if (matchedItem && updateExisting) {
            // Update existing item
            matchedItem.name_ar = nameAr || matchedItem.name_ar;
            matchedItem.name_en = nameEn || matchedItem.name_en;
            if (categoryId) matchedItem.category_id = categoryId;
            if (brand) matchedItem.brand = brand;
            if (costPrice > 0) matchedItem.cost_price = costPrice;
            if (profitPct > 0) matchedItem.profit_pct = Math.round(profitPct * 10) / 10;
            if (sellingPrice > 0) matchedItem.selling_price = sellingPrice;
            if (price2 > 0) matchedItem.selling_price_2 = price2;
            if (price3 > 0) matchedItem.selling_price_3 = price3;
            if (stockQty > 0 || (row['stock qty'] !== undefined && row['stock qty'] !== '')) {
              matchedItem.stock_qty = stockQty;
              if (!matchedItem.warehouse_stocks) matchedItem.warehouse_stocks = {};
              matchedItem.warehouse_stocks['1'] = stockQty;
              matchedItem.warehouse_stocks[String(targetWhId)] = stockQty;
            }
            if (minQty > 0) matchedItem.min_qty = minQty;
            if (isScaleVal) matchedItem.is_scale = isScale;
            if (scalePlu) matchedItem.scale_plu = scalePlu;
            if (scaleType) matchedItem.scale_type = scaleType;
            if (tareWeight > 0) matchedItem.tare_weight = tareWeight;
            if (vatType !== 'none') matchedItem.vat_type = vatType;
            if (row['Unit'] || row['الوحدة'] || row['unit']) matchedItem.unit = unit;
            matchedItem.updated_at = new Date().toISOString();

            itemsToPersist.push(matchedItem);
            updatedCount++;
          } else if (!matchedItem) {
            // Insert new item
            const generatedCode = itemCode || `ITM-${String(seqNum++).padStart(5, '0')}`;
            const newItem = {
              item_code: generatedCode,
              barcode: barcode,
              name_en: nameEn || nameAr,
              name_ar: nameAr || nameEn,
              category_id: categoryId,
              brand: brand,
              cost_price: costPrice,
              profit_pct: Math.round(profitPct * 10) / 10,
              selling_price: sellingPrice,
              selling_price_2: price2,
              selling_price_3: price3,
              stock_qty: stockQty,
              min_qty: minQty,
              warehouse_stocks: { 1: stockQty, [String(targetWhId)]: stockQty },
              selling_unit: sellingUnit === 'box' ? 'box' : 'piece',
              pieces_per_box: piecesPerBox,
              unit: unit,
              vat_type: vatType,
              is_scale: isScale,
              scale_plu: scalePlu,
              scale_type: scaleType,
              tare_weight: tareWeight,
              status: 'active',
              created_at: new Date().toISOString()
            };

            itemsToPersist.push(newItem);
            if (newItem.barcode) barcodeMap.set(newItem.barcode.toLowerCase(), newItem);
            if (newItem.item_code) codeMap.set(newItem.item_code.toLowerCase(), newItem);
            insertedCount++;
          } else {
            skippedCount++;
          }
        }

        if (statusMsgEl) {
          statusMsgEl.innerHTML = `<div style="color:var(--primary);font-weight:700">💾 ${isAR ? `جاري حفظ ${itemsToPersist.length} صنف بأمان وبسرعة...` : `Saving ${itemsToPersist.length} items securely...`}</div>`;
        }

        // High-performance batch persistence (No race conditions, no dropped items)
        if (itemsToPersist.length) {
          await DB.bulkAdd('items', itemsToPersist);
          try {
            await DB.setSetting('seq_items', `ITM-${String(seqNum).padStart(5, '0')}`);
          } catch (e) { }

          if (typeof BranchSync !== 'undefined' && BranchSync.notifyChange) {
            BranchSync.notifyChange('items').catch(() => {});
          }
          if (typeof OnlineOrders !== 'undefined' && OnlineOrders.syncCatalogToCloud) {
            OnlineOrders.syncCatalogToCloud(true).catch(() => {});
          }
        }

        if (statusMsgEl) {
          statusMsgEl.innerHTML = `
            <div style="background:rgba(16,185,129,0.1);border:1px solid var(--success);border-radius:8px;padding:12px;color:var(--success);font-weight:700;font-size:0.85rem">
              ✅ ${isAR ? `تم الاستيراد بنجاح! (إضافة: ${insertedCount} صنف جديد، تحديث: ${updatedCount} صنف، تم تخطي: ${skippedCount})` : `Import completed! (Added: ${insertedCount} new items, Updated: ${updatedCount}, Skipped: ${skippedCount})`}
            </div>`;
        }

        Utils.toast(isAR ? `✅ تم الاستيراد بنجاح (${insertedCount} جديد, ${updatedCount} تم تحديثه)` : `✅ Import completed (${insertedCount} new, ${updatedCount} updated)`, 'success');

        // Refresh items table in background
        _items = await DB.getAll('items');
        renderItems(getFiltered());

        setTimeout(() => {
          Utils.closeModal('items-import-excel-modal');
        }, 1800);
      } catch (err) {
        if (statusMsgEl) {
          statusMsgEl.innerHTML = `<div style="color:var(--danger);font-weight:700;font-size:0.85rem">❌ ${err.message}</div>`;
        }
        Utils.toast('Import failed: ' + err.message, 'error');
      }
    };
    reader.readAsArrayBuffer(file);
  }

  // ── Delete Items by Uploading Mistaken Excel File ─────────────
  function openDeleteExcelModal(triggerBrowse = true) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'هذه الصلاحية مخصصة للمدير والمسؤول فقط' : 'This action is restricted to Administrators only', 'warning');
    }
    const modalId = 'items-delete-excel-modal';
    let el = document.getElementById(modalId);
    if (el) el.remove();

    const html = `
    <div class="modal-overlay open active" id="${modalId}" style="display:flex !important; opacity:1 !important; visibility:visible !important; pointer-events:auto !important; z-index:99999 !important;">
      <div class="modal" style="max-width:640px;border-radius:14px;overflow:hidden;box-shadow:0 20px 40px rgba(0,0,0,0.35);margin:auto">
        <div class="modal-header" style="background:rgba(239,68,68,0.08);border-bottom:1px solid rgba(239,68,68,0.25);padding:16px 20px">
          <div class="modal-title" style="color:#ef4444;font-weight:900;font-size:1.15rem;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.4rem">🗑️</span>
            <span>${isAR ? 'حذف الأصناف المستوردة بالخطأ بواسطة ملف إكسل' : 'Delete Mistaken Items via Excel File'}</span>
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('${modalId}')" style="font-size:1.2rem">✕</button>
        </div>
        <div class="modal-body" style="padding:22px">
          
          <div style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:12px 14px;margin-bottom:14px;font-size:0.85rem;line-height:1.6">
            <div style="font-weight:900;color:#ef4444;margin-bottom:3px">
              ⚠️ ${isAR ? 'كيف تعمل هذه الميزة بأمان؟' : 'How does this work safely?'}
            </div>
            <div style="color:var(--text-secondary)">
              ${isAR
                ? 'اختر نفس ملف الإكسل الذي تم استيراده بالخطأ. سيقوم النظام بمطابقة الباركود أو رمز الصنف أو الاسم، وحذف الأصناف الموجودة في هذا الملف <strong>فقط</strong>، مع الحفاظ الكامل على بقية أصنافك ومبيعاتك القديمة.'
                : 'Upload the Excel file that was imported by mistake. The system will match barcodes, codes, or names and delete <strong>only</strong> the items in that file, keeping your existing items safe.'}
            </div>
          </div>

          <!-- Quick Safety Backup Download -->
          <div style="background:rgba(59,130,246,0.08);border:1.5px solid rgba(59,130,246,0.3);border-radius:10px;padding:12px 14px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div>
              <div style="font-weight:900;font-size:0.88rem;color:var(--primary)">💾 ${isAR ? 'نسخة احتياطية للأمان (مستحسن)' : 'Safety Backup (Recommended)'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'تنزيل نسخة احتياطية كاملة من قاعدة البيانات بنقرة واحدة قبل الحذف' : 'Download a full system backup before proceeding'}</div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.Admin && Admin.exportBackup) Admin.exportBackup()" style="font-weight:800;white-space:nowrap;padding:7px 14px;display:flex;align-items:center;gap:6px">
              <span>📥</span> <span>${isAR ? 'تنزيل نسخة الآن' : 'Download Backup'}</span>
            </button>
          </div>

          <!-- Large Clickable Browse & Drop Box -->
          <div id="items-delete-dropzone" onclick="document.getElementById('items-delete-excel-input').click()"
            style="border:2.5px dashed #ef4444;background:var(--surface);border-radius:12px;padding:26px 20px;text-align:center;margin-bottom:16px;cursor:pointer;transition:all 0.2s ease"
            onmouseover="this.style.background='rgba(239,68,68,0.04)'"
            onmouseout="this.style.background='var(--surface)'">
            <div style="font-size:2.8rem;margin-bottom:8px">📂</div>
            
            <button type="button" class="btn btn-danger" onclick="event.stopPropagation();document.getElementById('items-delete-excel-input').click()"
              style="font-size:1.02rem;font-weight:900;padding:12px 26px;border-radius:10px;box-shadow:0 4px 14px rgba(239,68,68,0.35);cursor:pointer;display:inline-flex;align-items:center;gap:8px;margin-bottom:10px">
              <span>📂</span>
              <span>${isAR ? 'اضغط هنا لاستعراض واختيار ملف الإكسل (Browse)' : 'Click to Browse & Select Excel File'}</span>
            </button>

            <div id="items-delete-selected-file" style="font-weight:800;font-size:0.85rem;color:var(--text-muted);margin-top:4px">
              ${isAR ? 'أو انقر في أي مكان داخل هذا المربع / اسحب الملف هنا (.xlsx, .xls, .csv)' : 'Or click anywhere in this box / drag & drop file here (.xlsx, .xls, .csv)'}
            </div>

            <input type="file" id="items-delete-excel-input" accept=".xlsx, .xls, .csv" style="display:none" onchange="Items.handleDeleteExcelFile(this)">
          </div>

          <div id="items-delete-excel-status"></div>
          <div id="items-delete-excel-preview" style="display:none;margin-top:14px"></div>

        </div>
        <div class="modal-footer" style="background:var(--surface);border-top:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;padding:14px 20px">
          <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-danger" id="btn-confirm-excel-delete" disabled onclick="Items.executeDeleteExcelMatched()" style="font-weight:900;padding:10px 22px;box-shadow:0 4px 14px rgba(239,68,68,0.3);font-size:0.95rem">
            🗑️ ${isAR ? 'تأكيد الحذف النهائي' : 'Confirm Delete'}
          </button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
    Utils.openModal(modalId);

    // Setup drag and drop
    const dropzone = document.getElementById('items-delete-dropzone');
    if (dropzone) {
      dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.style.background = 'rgba(239,68,68,0.08)';
      });
      dropzone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropzone.style.background = 'var(--surface)';
      });
      dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.style.background = 'var(--surface)';
        const files = e.dataTransfer?.files;
        if (files && files.length > 0) {
          handleDeleteExcelFile({ files: files });
        }
      });
    }

    // Automatically trigger browse dialog on opening
    if (triggerBrowse) {
      const fileInput = document.getElementById('items-delete-excel-input');
      if (fileInput) {
        try { fileInput.click(); } catch(e) {}
      }
    }
  }

  async function handleDeleteExcelFile(input) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    const file = input.files?.[0];
    if (!file) return;

    const fileLabelEl = document.getElementById('items-delete-selected-file');
    if (fileLabelEl) {
      fileLabelEl.innerHTML = `📄 <strong style="color:var(--text-primary);font-size:0.95rem">${file.name}</strong> <span style="color:var(--text-muted)">(${(file.size / 1024).toFixed(1)} KB)</span>`;
    }

    const statusEl = document.getElementById('items-delete-excel-status');
    const previewEl = document.getElementById('items-delete-excel-preview');
    const confirmBtn = document.getElementById('btn-confirm-excel-delete');
    if (confirmBtn) confirmBtn.disabled = true;

    if (!window.XLSX) {
      if (statusEl) statusEl.innerHTML = `<div style="color:var(--danger)">XLSX library not loaded</div>`;
      return;
    }

    if (statusEl) {
      statusEl.innerHTML = `<div style="color:var(--primary);font-weight:700">⏳ ${isAR ? 'جاري فحص الملف ومطابقة الأصناف مع قاعدة البيانات...' : 'Analyzing Excel file and matching items...'}</div>`;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet);

        if (!rows.length) {
          if (statusEl) statusEl.innerHTML = `<div style="color:var(--danger)">❌ ${isAR ? 'الملف فارغ' : 'File is empty'}</div>`;
          return;
        }

        const localItems = (await DB.getAll('items')) || [];
        const barcodeMap = new Map();
        const codeMap = new Map();
        const nameMap = new Map();

        localItems.forEach(i => {
          if (i.barcode) barcodeMap.set(String(i.barcode).trim().toLowerCase(), i);
          if (i.item_code) codeMap.set(String(i.item_code).trim().toLowerCase(), i);
          const nmEn = String(i.name_en || '').trim().toLowerCase();
          const nmAr = String(i.name_ar || '').trim().toLowerCase();
          const nm = String(i.name || '').trim().toLowerCase();
          if (nmEn) nameMap.set(nmEn, i);
          if (nmAr) nameMap.set(nmAr, i);
          if (nm) nameMap.set(nm, i);
        });

        const matchedIds = new Set();
        const matchedItems = [];

        for (const rawRow of rows) {
          const row = {};
          for (const [k, v] of Object.entries(rawRow || {})) {
            if (k != null) {
              row[String(k).trim().toLowerCase()] = v;
            }
          }

          const bc = String(row['barcode'] || row['باركود'] || row['الباركود'] || row['bar code'] || row['upc'] || row['ean'] || '').trim().toLowerCase();
          const code = String(row['item_code'] || row['item code'] || row['كود'] || row['رمز الصنف'] || row['code'] || row['كود الصنف'] || row['item id'] || '').trim().toLowerCase();
          const name = String(row['name'] || row['item name'] || row['اسم الصنف'] || row['name_ar'] || row['name_en'] || row['name arabic'] || row['name english'] || row['الاسم'] || row['الاسم عربي'] || row['الاسم انجليزي'] || row['description'] || row['الوصف'] || '').trim().toLowerCase();

          let match = null;
          if (bc && barcodeMap.has(bc)) match = barcodeMap.get(bc);
          else if (code && codeMap.has(code)) match = codeMap.get(code);
          else if (name && nameMap.has(name)) match = nameMap.get(name);

          if (match && !matchedIds.has(match.id)) {
            matchedIds.add(match.id);
            matchedItems.push(match);
          }
        }

        window._excelDeleteMatchedIds = Array.from(matchedIds);

        if (statusEl) {
          if (matchedItems.length > 0) {
            statusEl.innerHTML = `
              <div style="background:rgba(239,68,68,0.1);border:2px solid #ef4444;border-radius:12px;padding:16px;color:var(--text-main);text-align:center">
                <div style="font-weight:900;font-size:1.15rem;color:#ef4444;margin-bottom:6px">
                  🎯 ${isAR ? `تم العثور على ${matchedItems.length} صنف مطابق في قاعدة البيانات` : `Found ${matchedItems.length} matched items in your database`}
                </div>
                <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:14px">
                  ${isAR ? `إجمالي الأسطر في ملف الإكسل: ${rows.length} سطر` : `Total rows in Excel file: ${rows.length}`}
                </div>
                <button type="button" class="btn btn-danger" onclick="Items.executeDeleteExcelMatched()"
                  style="font-size:1.1rem;font-weight:900;padding:12px 28px;border-radius:10px;box-shadow:0 6px 20px rgba(239,68,68,0.45);cursor:pointer;display:inline-flex;align-items:center;gap:8px">
                  <span>🗑️</span>
                  <span>${isAR ? `اضغط هنا لتأكيد حذف الـ ${matchedItems.length} صنف الآن` : `Click Here to Delete ${matchedItems.length} Items Now`}</span>
                </button>
              </div>`;
          } else {
            statusEl.innerHTML = `
              <div style="background:rgba(245,158,11,0.1);border:1.5px solid #f59e0b;border-radius:10px;padding:14px;color:var(--text-main);text-align:center">
                <div style="font-weight:900;font-size:1.05rem;color:#f59e0b;margin-bottom:4px">
                  ⚠️ ${isAR ? 'لم يتم العثور على أي صنف مطابق في قاعدة البيانات' : 'No matching items found in your database'}
                </div>
                <div style="font-size:0.8rem;color:var(--text-muted)">
                  ${isAR ? 'تأكد من أن ملف الإكسل يحتوي على عمود الباركود (Barcode) أو رمز الصنف (Item Code) أو اسم الصنف (Name).' : 'Ensure the Excel file contains Barcode, Item Code, or Name columns.'}
                </div>
              </div>`;
          }
        }

        if (previewEl && matchedItems.length > 0) {
          previewEl.style.display = 'block';
          previewEl.innerHTML = `
            <div style="font-weight:800;font-size:0.82rem;margin-bottom:6px;color:var(--text-muted)">
              ${isAR ? 'معاينة عينة من الأصناف التي سيتم حذفها:' : 'Preview of items to be deleted:'}
            </div>
            <div style="max-height:160px;overflow-y:auto;border:1px solid var(--border-color);border-radius:8px;font-size:0.75rem">
              <table style="width:100%;border-collapse:collapse;text-align:${isAR ? 'right' : 'left'}">
                <thead style="background:var(--surface-2);position:sticky;top:0">
                  <tr>
                    <th style="padding:6px 10px">${isAR ? 'الرمز' : 'Code'}</th>
                    <th style="padding:6px 10px">${isAR ? 'الباركود' : 'Barcode'}</th>
                    <th style="padding:6px 10px">${isAR ? 'اسم الصنف' : 'Name'}</th>
                    <th style="padding:6px 10px">${isAR ? 'السعر' : 'Price'}</th>
                  </tr>
                </thead>
                <tbody>
                  ${matchedItems.slice(0, 15).map(m => `
                    <tr style="border-bottom:1px solid var(--border-color)">
                      <td style="padding:6px 10px;font-family:monospace">${m.item_code || '-'}</td>
                      <td style="padding:6px 10px;font-family:monospace">${m.barcode || '-'}</td>
                      <td style="padding:6px 10px;font-weight:700">${m.name_ar || m.name_en || m.name || '-'}</td>
                      <td style="padding:6px 10px">$${parseFloat(m.selling_price || 0).toFixed(2)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
            ${matchedItems.length > 15 ? `<div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px;text-align:center">${isAR ? `... وغيرها (${matchedItems.length - 15} صنف إضافي)` : `... and ${matchedItems.length - 15} more`}</div>` : ''}
          `;
        }

        if (confirmBtn && matchedItems.length > 0) {
          confirmBtn.disabled = false;
          confirmBtn.innerHTML = `🗑️ ${isAR ? `تأكيد حذف الـ ${matchedItems.length} صنف المطابق` : `Confirm Delete (${matchedItems.length} items)`}`;
        }
      } catch (err) {
        if (statusEl) statusEl.innerHTML = `<div style="color:var(--danger)">❌ ${err.message}</div>`;
      }
    };
    reader.readAsArrayBuffer(file);
  }

  async function executeDeleteExcelMatched() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'هذه الصلاحية مخصصة للمدير والمسؤول فقط' : 'This action is restricted to Administrators only', 'warning');
    }
    const ids = window._excelDeleteMatchedIds || [];
    if (!ids.length) return;

    const count = ids.length;

    try {
      const btn1 = document.getElementById('btn-confirm-excel-delete');
      const btn2 = document.getElementById('btn-inline-delete-now');
      if (btn1) {
        btn1.disabled = true;
        btn1.innerHTML = `⏳ ${isAR ? 'جاري الحذف...' : 'Deleting...'}`;
      }
      if (btn2) {
        btn2.disabled = true;
        btn2.innerHTML = `⏳ ${isAR ? 'جاري الحذف...' : 'Deleting...'}`;
      }

      const statusEl = document.getElementById('items-delete-excel-status');
      if (statusEl) {
        statusEl.innerHTML = `
          <div style="background:rgba(239,68,68,0.15);border:2px solid #ef4444;border-radius:12px;padding:20px;text-align:center">
            <div style="font-size:2rem;margin-bottom:8px">⏳</div>
            <div style="font-weight:900;font-size:1.2rem;color:#ef4444;margin-bottom:4px">
              ${isAR ? `جاري حذف ${count} صنف من قاعدة البيانات...` : `Deleting ${count} items from database...`}
            </div>
            <div style="font-size:0.85rem;color:var(--text-muted)">
              ${isAR ? 'يرجى الانتظار ثوانٍ قليلة...' : 'Please wait a few seconds...'}
            </div>
          </div>`;
      }
      Utils.toast(isAR ? `⏳ جاري حذف ${count} صنف بأمان...` : `⏳ Deleting ${count} items securely...`, 'info');

      // Small delay so UI renders the loading state
      await new Promise(r => setTimeout(r, 60));

      if (window.DB && typeof DB.bulkDelete === 'function') {
        await DB.bulkDelete('items', ids);
      } else {
        for (const id of ids) {
          try { await DB.remove('items', id); } catch(e) {}
        }
      }

      // Record all deleted items locally so branch sync never revives them
      for (const itm of (matchedItems || [])) {
        recordDeletedItemLocally(itm);
      }
      // Notify server and sync engine
      if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
        try { await BranchSync.notifyChange('items', { deleted_ids: ids, deleted: true }); } catch(e) {}
      }

      // Sync with Cloud
      if (window.OnlineOrders && typeof OnlineOrders.syncCatalogToCloud === 'function') {
        try { OnlineOrders.syncCatalogToCloud(true); } catch(e) {}
      }

      Utils.closeModal('items-delete-excel-modal');
      const modalEl = document.getElementById('items-delete-excel-modal');
      if (modalEl) modalEl.remove();

      Utils.toast(isAR ? `✅ تم حذف ${count} صنف بنجاح! قاعدة بياناتك نظيفة الآن.` : `✅ Successfully deleted ${count} items! Your database is clean now.`, 'success', 5000);

      _items = await DB.getAll('items');
      renderItems(getFiltered());
    } catch (err) {
      console.error('Delete excel matched items error:', err);
      Utils.toast('Delete failed: ' + err.message, 'error');
    }
  }

  // ── Wipe Items Catalog Only (Preserve Customer Debts & Balances) ─
  async function wipeAllItemsCatalog() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'هذه الصلاحية مخصصة للمدير والمسؤول فقط' : 'This action is restricted to Administrators only', 'warning');
    }

    Utils.confirm(isAR 
      ? '⚠️ هل أنت متأكد من تفريغ دليل الأصناف بالكامل لإعادة رفعه من جديد؟\n\n✅ سيتم الحفاظ 100% على ديون وحسابات الزبائن، الموردين، فواتير المبيعات، والترخيص.'
      : '⚠️ Are you sure you want to clear the items catalog to re-upload it?\n\n✅ Customer debts, suppliers, sales invoices, and license will be 100% preserved.',
      async () => {
        if (typeof Admin !== 'undefined' && typeof Admin.executeSelectiveReset === 'function') {
          await Admin.executeSelectiveReset('delete_items_only');
        } else {
          await DB.clear('items');
          try {
            await DB.put('sequences', { key: 'items', current: 0 });
            await DB.setSetting('seq_items', 'ITM-00000');
          } catch(e) {}
          localStorage.removeItem('rs_last_items_sync_time');
          localStorage.removeItem('rs_branch_deleted_items');
          Utils.toast(isAR ? 'تم تفريغ دليل الأصناف بنجاح!' : 'Items catalog cleared successfully!', 'success');
          render(document.getElementById('page-content'));
        }
      }
    );
  }

  // ── Restore Missing Items from Purchase Invoices ──────────────
  async function restoreMissingFromPurchasing() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'هذه الصلاحية مخصصة للمدير والمسؤول فقط' : 'This action is restricted to Administrators only', 'warning');
    }
    Utils.toast(isAR ? '⏳ جاري فحص فواتير الشراء والبحث عن الأصناف المفقودة...' : 'Scanning purchase invoices for missing items...', 'info');

    try {
      const currentItems = (await DB.getAll('items')) || [];
      const existingBarcodeSet = new Set();
      const existingCodeSet = new Set();
      const existingNameSet = new Set();

      currentItems.forEach(item => {
        if (item.barcode) existingBarcodeSet.add(String(item.barcode).trim().toLowerCase());
        if (item.item_code) existingCodeSet.add(String(item.item_code).trim().toLowerCase());
        if (item.code) existingCodeSet.add(String(item.code).trim().toLowerCase());
        const nEn = String(item.name_en || '').trim().toLowerCase();
        const nAr = String(item.name_ar || '').trim().toLowerCase();
        const n = String(item.name || '').trim().toLowerCase();
        if (nEn) existingNameSet.add(nEn);
        if (nAr) existingNameSet.add(nAr);
        if (n) existingNameSet.add(n);
      });

      const pInvoices = (await DB.getAll('purchase_invoices')) || [];
      const pOrders = (await DB.getAll('purchase_orders')) || [];
      const pReceipts = (await DB.getAll('goods_receipts')) || [];
      const allDocs = [...pInvoices, ...pOrders, ...pReceipts];

      if (!allDocs.length) {
        Utils.toast(isAR ? '⚠️ لم يتم العثور على أي فواتير شراء في النظام.' : '⚠️ No purchase invoices found.', 'warning');
        return;
      }

      const defaultWhId = (typeof window !== 'undefined' && window._posWarehouseId) ? window._posWarehouseId : (await DB.getSetting('pos_warehouse_id', 1));
      const missingItemsMap = new Map();

      for (const doc of allDocs) {
        let lines = [];
        if (typeof doc.items_json === 'string' && doc.items_json.trim()) {
          try { lines = JSON.parse(doc.items_json); } catch (e) {}
        }
        if (!lines.length && Array.isArray(doc.items)) {
          lines = doc.items;
        }

        const docWhId = doc.warehouse_id || defaultWhId;

        for (const line of lines) {
          if (!line) continue;
          const bc = String(line.barcode || '').trim().toLowerCase();
          const code = String(line.item_code || line.code || '').trim().toLowerCase();
          const nameEn = String(line.name_en || line.name || '').trim();
          const nameAr = String(line.name_ar || line.name || '').trim();
          const name = nameAr || nameEn;
          const nameKey = name.toLowerCase();

          // If already present in current catalog, skip!
          if ((bc && existingBarcodeSet.has(bc)) || (code && existingCodeSet.has(code)) || (nameKey && existingNameSet.has(nameKey))) {
            continue;
          }

          const uniqueKey = bc || code || nameKey;
          if (!uniqueKey) continue;

          const lineQty = parseFloat(line.qty) || 0;
          const costPrice = parseFloat(line.price || line.cost || line.cost_price) || 0;
          const sellPrice = parseFloat(line.selling_price || line.price2 || line.sell_price) || (costPrice > 0 ? Utils.round(costPrice * 1.25, 2) : 0);

          if (missingItemsMap.has(uniqueKey)) {
            const agg = missingItemsMap.get(uniqueKey);
            agg.stock_qty = (agg.stock_qty || 0) + lineQty;
            if (!agg.warehouse_stocks) agg.warehouse_stocks = {};
            agg.warehouse_stocks[String(docWhId)] = (agg.warehouse_stocks[String(docWhId)] || 0) + lineQty;
            agg.warehouse_stocks['1'] = (agg.warehouse_stocks['1'] || 0) + lineQty;
            if (costPrice > 0) agg.cost_price = costPrice;
            if (sellPrice > 0) agg.selling_price = sellPrice;
          } else {
            missingItemsMap.set(uniqueKey, {
              name_en: nameEn || nameAr,
              name_ar: nameAr || nameEn,
              name: name,
              barcode: line.barcode ? String(line.barcode).trim() : '',
              item_code: line.item_code ? String(line.item_code).trim() : '',
              category_id: line.category_id || 1,
              cost_price: costPrice,
              selling_price: sellPrice,
              stock_qty: lineQty,
              warehouse_stocks: {
                [String(docWhId)]: lineQty,
                '1': lineQty
              },
              unit: line.unit || 'piece',
              selling_unit: line.unit || 'piece',
              vat_type: line.vat_type || (line.is_taxable ? 'standard' : 'none'),
              vat_rate: line.tax_pct || (line.is_taxable ? 11 : 0),
              is_taxable: !!line.is_taxable,
              expiry_date: line.expiry_date || '',
              status: 'active',
              created_at: new Date().toISOString()
            });
          }
        }
      }

      const itemsToRestore = Array.from(missingItemsMap.values());
      if (itemsToRestore.length === 0) {
        Utils.toast(isAR ? '✅ جميع الأصناف من فواتير الشراء موجودة بالفعل في قاعدة بياناتك (لا توجد أصناف مفقودة).' : '✅ All items from purchase invoices already exist in catalog (0 missing).', 'success', 4000);
        return;
      }

      // Assign sequential codes if missing
      let seqNum = 1;
      try {
        const lastSeq = await DB.peekSeq('items', 'ITM-', 4);
        const digits = String(lastSeq || '').replace(/\D/g, '');
        seqNum = digits ? parseInt(digits, 10) : 1;
      } catch (e) {
        seqNum = 1;
      }

      for (const it of itemsToRestore) {
        if (!it.item_code) {
          it.item_code = `ITM-${String(seqNum++).padStart(4, '0')}`;
        }
      }

      window._itemsToRestoreFromPurchasing = itemsToRestore;
      openRestorePreviewModal(itemsToRestore);
    } catch (err) {
      console.error('Restore missing items error:', err);
      Utils.toast('Scan failed: ' + err.message, 'error');
    }
  }

  function openRestorePreviewModal(itemsList) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    const modalId = 'items-restore-purchasing-modal';
    const old = document.getElementById(modalId);
    if (old) old.remove();

    const count = itemsList.length;
    const totalQty = itemsList.reduce((s, it) => s + (parseFloat(it.stock_qty) || 0), 0);

    const html = `
    <div class="modal-overlay open active" id="${modalId}" style="display:flex !important; opacity:1 !important; visibility:visible !important; pointer-events:auto !important; z-index:99999 !important;">
      <div class="modal" style="max-width:680px;border-radius:16px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,0.4);margin:auto">
        <div class="modal-header" style="background:rgba(59,130,246,0.08);border-bottom:1px solid rgba(59,130,246,0.25);padding:16px 20px">
          <div class="modal-title" style="color:var(--primary);font-weight:900;font-size:1.15rem;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.4rem">🔄</span>
            <span>${isAR ? 'استعادة الأصناف المفقودة من فواتير الشراء' : 'Restore Missing Items from Purchase Invoices'}</span>
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('${modalId}')" style="font-size:1.2rem">✕</button>
        </div>
        <div class="modal-body" style="padding:22px">
          
          <div style="background:rgba(59,130,246,0.06);border:1.5px solid rgba(59,130,246,0.3);border-radius:12px;padding:16px;margin-bottom:16px;text-align:center">
            <div style="font-weight:900;font-size:1.2rem;color:var(--primary);margin-bottom:4px">
              🎯 ${isAR ? `تم العثور على ${count} صنف مفقود في فواتير الشراء!` : `Found ${count} missing items in purchase invoices!`}
            </div>
            <div style="font-size:0.85rem;color:var(--text-muted)">
              ${isAR ? `إجمالي كميات المخزون المشتراة لهذه الأصناف: ${totalQty} قطعة / وحدة` : `Total purchased stock qty for these items: ${totalQty}`}
            </div>
            <div style="margin-top:12px">
              <button type="button" class="btn btn-primary" id="btn-confirm-restore-purchasing" onclick="Items.executeRestoreFromPurchasing()"
                style="font-size:1.05rem;font-weight:900;padding:12px 28px;border-radius:10px;box-shadow:0 6px 20px rgba(37,99,235,0.4);display:inline-flex;align-items:center;gap:8px">
                <span>✅</span>
                <span>${isAR ? `اضغط هنا لتأكيد استعادة الـ ${count} صنف الآن` : `Click Here to Restore ${count} Items Now`}</span>
              </button>
            </div>
          </div>

          <div style="font-weight:800;font-size:0.85rem;margin-bottom:8px;color:var(--text-muted)">
            ${isAR ? 'معاينة عينة من الأصناف التي سيتم استعادتها إلى المخزون:' : 'Preview of items to be restored to inventory:'}
          </div>
          <div style="max-height:220px;overflow-y:auto;border:1px solid var(--border-color);border-radius:10px;font-size:0.78rem">
            <table style="width:100%;border-collapse:collapse;text-align:${isAR ? 'right' : 'left'}">
              <thead style="background:var(--surface-2);position:sticky;top:0;z-index:2">
                <tr>
                  <th style="padding:8px 12px">${isAR ? 'الرمز' : 'Code'}</th>
                  <th style="padding:8px 12px">${isAR ? 'الباركود' : 'Barcode'}</th>
                  <th style="padding:8px 12px">${isAR ? 'اسم الصنف' : 'Name'}</th>
                  <th style="padding:8px 12px">${isAR ? 'سعر التكلفة' : 'Cost'}</th>
                  <th style="padding:8px 12px">${isAR ? 'سعر البيع' : 'Sell'}</th>
                  <th style="padding:8px 12px">${isAR ? 'المخزون' : 'Stock'}</th>
                </tr>
              </thead>
              <tbody>
                ${itemsList.slice(0, 30).map(it => `
                  <tr style="border-bottom:1px solid var(--border-color)">
                    <td style="padding:8px 12px;font-family:monospace">${it.item_code || '-'}</td>
                    <td style="padding:8px 12px;font-family:monospace">${it.barcode || '-'}</td>
                    <td style="padding:8px 12px;font-weight:700">${it.name_ar || it.name_en || '-'}</td>
                    <td style="padding:8px 12px">$${parseFloat(it.cost_price || 0).toFixed(2)}</td>
                    <td style="padding:8px 12px">$${parseFloat(it.selling_price || 0).toFixed(2)}</td>
                    <td style="padding:8px 12px;font-weight:800;color:var(--success)">${it.stock_qty || 0}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          ${count > 30 ? `<div style="font-size:0.75rem;color:var(--text-muted);margin-top:6px;text-align:center">${isAR ? `... وغيرها (${count - 30} صنف إضافي)` : `... and ${count - 30} more items`}</div>` : ''}

        </div>
        <div class="modal-footer" style="background:var(--surface);border-top:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;padding:14px 20px">
          <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Items.executeRestoreFromPurchasing()" style="font-weight:900;padding:10px 22px">
            ✅ ${isAR ? 'تأكيد الاستعادة' : 'Confirm Restore'}
          </button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
    Utils.openModal(modalId);
  }

  async function executeRestoreFromPurchasing() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
    if (typeof Auth !== 'undefined' && !Auth.isAdmin()) {
      return Utils.toast(isAR ? 'هذه الصلاحية مخصصة للمدير والمسؤول فقط' : 'This action is restricted to Administrators only', 'warning');
    }
    const itemsList = window._itemsToRestoreFromPurchasing || [];
    if (!itemsList.length) return;

    const count = itemsList.length;
    const btn = document.getElementById('btn-confirm-restore-purchasing');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `⏳ ${isAR ? 'جاري الاستعادة...' : 'Restoring...'}`;
    }

    Utils.toast(isAR ? `⏳ جاري استعادة ${count} صنف إلى المخزون...` : `⏳ Restoring ${count} items to inventory...`, 'info');

    try {
      if (window.DB && typeof DB.bulkAdd === 'function') {
        await DB.bulkAdd('items', itemsList);
      } else {
        for (const it of itemsList) {
          try { await DB.add('items', it); } catch(e) {}
        }
      }

      if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
        try { await BranchSync.notifyChange('items'); } catch(e) {}
      }
      if (window.OnlineOrders && typeof OnlineOrders.syncCatalogToCloud === 'function') {
        try { OnlineOrders.syncCatalogToCloud(true); } catch(e) {}
      }

      Utils.closeModal('items-restore-purchasing-modal');
      const modalEl = document.getElementById('items-restore-purchasing-modal');
      if (modalEl) modalEl.remove();

      Utils.toast(isAR ? `🎉 تم بنجاح استعادة ${count} صنف من فواتير الشراء إلى المخزون!` : `🎉 Successfully restored ${count} items from purchase invoices to inventory!`, 'success', 5000);

      _items = await DB.getAll('items');
      renderItems(getFiltered());
    } catch (err) {
      console.error('Execute restore error:', err);
      Utils.toast('Restore failed: ' + err.message, 'error');
    }
  }

  function toggleScaleFields(isScale) {
    const container = document.getElementById('item-scale-fields-container');
    if (container) container.style.display = isScale ? 'block' : 'none';
    if (isScale) {
      const unitEl = document.getElementById('item-unit');
      if (unitEl && unitEl.value === 'pc') {
        unitEl.value = 'kg';
      }
      _updateSampleScaleBarcode();
    }
  }

  function applyScalePreset(preset) {
    const isAR = i18n.getLang() === 'ar';
    const isScaleCheck = document.getElementById('item-is-scale');
    if (isScaleCheck) isScaleCheck.checked = true;
    toggleScaleFields(true);

    const unitEl = document.getElementById('item-unit');
    if (unitEl) unitEl.value = 'kg';

    const tareEl = document.getElementById('item-scale-tare');
    const pluEl = document.getElementById('item-scale-plu');
    const typeEl = document.getElementById('item-scale-type');
    const catEl = document.getElementById('item-category');

    // Auto-match category dropdown if available
    if (catEl && _cats && _cats.length) {
      const matchCat = _cats.find(c => {
        const cName = ((c.name || '') + ' ' + (c.name_ar || '')).toLowerCase();
        if (preset === 'dairy') return cName.includes('dairy') || cName.includes('cheese') || cName.includes('ألبان') || cName.includes('أجبان');
        if (preset === 'produce') return cName.includes('fruit') || cName.includes('veg') || cName.includes('خضار') || cName.includes('فواكه');
        if (preset === 'meat') return cName.includes('meat') || cName.includes('لحوم') || cName.includes('دواجن');
        if (preset === 'deli') return cName.includes('deli') || cName.includes('مقبلات') || cName.includes('مخللات');
        if (preset === 'roastery') return cName.includes('nut') || cName.includes('roast') || cName.includes('محامص') || cName.includes('مكسرات');
        return false;
      });
      if (matchCat) catEl.value = matchCat.id;
    }

    if (preset === 'dairy') {
      if (tareEl && !tareEl.value) tareEl.value = '0.015';
      if (typeEl) typeEl.value = 'weight';
      Utils.toast(isAR ? '🧀 تم ضبط إعدادات ميزان الألبان والأجبان (الوحدة: كغ، فارغ الإناء: 15g)' : '🧀 Dairy & Cheese scale preset applied (Unit: kg, Tare: 15g)', 'info');
    } else if (preset === 'produce') {
      if (tareEl && !tareEl.value) tareEl.value = '0.005';
      if (typeEl) typeEl.value = 'weight';
      Utils.toast(isAR ? '🍎 تم ضبط إعدادات ميزان الخضار والفواكه (الوحدة: كغ)' : '🍎 Fruits & Vegetables scale preset applied (Unit: kg)', 'info');
    } else if (preset === 'meat') {
      if (tareEl && !tareEl.value) tareEl.value = '0.020';
      if (typeEl) typeEl.value = 'weight';
      Utils.toast(isAR ? '🥩 تم ضبط إعدادات ميزان اللحوم والدواجن (الوحدة: كغ، فارغ: 20g)' : '🥩 Meat & Poultry scale preset applied', 'info');
    } else if (preset === 'deli') {
      if (tareEl && !tareEl.value) tareEl.value = '0.015';
      if (typeEl) typeEl.value = 'weight';
      Utils.toast(isAR ? '🫒 تم ضبط إعدادات ميزان المقبلات والمخللات' : '🫒 Deli & Pickles scale preset applied', 'info');
    } else if (preset === 'roastery') {
      if (tareEl && !tareEl.value) tareEl.value = '0.010';
      if (typeEl) typeEl.value = 'weight';
      Utils.toast(isAR ? '🥜 تم ضبط إعدادات ميزان المحامص والمكسرات' : '🥜 Roastery scale preset applied', 'info');
    }
    _updateSampleScaleBarcode();
  }

  function _updateSampleScaleBarcode() {
    const pluVal = (document.getElementById('item-scale-plu')?.value || '101').replace(/\D/g, '') || '101';
    const plu5 = pluVal.padStart(5, '0').slice(-5);
    const type = document.getElementById('item-scale-type')?.value || 'weight';
    const prefix = type === 'price' ? '22' : '20';
    const sampleRaw = `${prefix}${plu5}01500`;
    let sum = 0;
    for (let i = 0; i < 12; i++) {
      sum += parseInt(sampleRaw[i], 10) * (i % 2 === 0 ? 1 : 3);
    }
    const checkDigit = (10 - (sum % 10)) % 10;
    const fullBarcode = `${sampleRaw}${checkDigit}`;

    const sampleEl = document.getElementById('item-scale-sample-bc');
    if (sampleEl) sampleEl.textContent = fullBarcode;
    return fullBarcode;
  }

  function onScalePluInput(val) {
    _updateSampleScaleBarcode();
  }

  function syncScaleBarcodeToMain() {
    const isAR = i18n.getLang() === 'ar';
    const bc = _updateSampleScaleBarcode();
    const barcodeInput = document.getElementById('item-barcode');
    if (barcodeInput) {
      barcodeInput.value = bc;
      Utils.toast(isAR ? `✅ تم نسخ باركود الميزان (${bc}) إلى حقل الباركود الرئيسي` : `✅ Copied scale barcode (${bc}) to main barcode`, 'success');
    }
  }

  function switchTab(tabId) {
    const tabs = document.querySelectorAll('#item-tabs .tab-item');
    tabs.forEach(t => {
      if (t.dataset.tab === tabId) {
        t.classList.add('active');
      } else {
        t.classList.remove('active');
      }
    });

    const tabIds = ['tab-basic', 'tab-pricing', 'tab-stock', 'tab-details'];
    tabIds.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        if (id === tabId) {
          el.classList.add('active');
          el.style.display = 'block';
        } else {
          el.classList.remove('active');
          el.style.display = 'none';
        }
      }
    });
  }

  function syncScalePrice(val) {
    const p1 = document.getElementById('item-price1');
    if (p1) {
      p1.value = val;
      recalcPricing('price');
    }
  }

  function syncScaleCost(val) {
    const c = document.getElementById('item-cost');
    if (c) {
      c.value = val;
      recalcPricing('cost');
    }
  }

  function syncScaleVat(val) {
    const v = document.getElementById('item-vat-type');
    if (v) {
      v.value = val;
    }
  }

  // Auto-refresh items list in management screen when background sync updates items
  window.addEventListener('redshark_sync_complete', async (e) => {
    const tbl = e.detail?.table;
    if (!tbl || tbl === 'items' || tbl === 'categories' || tbl === 'warehouses' || tbl === 'stock_transfers' || tbl === 'all') {
      if (typeof DB !== 'undefined') {
        try {
          _items = (await DB.getAll('items')) || [];
          _cats = (await DB.getAll('categories')) || [];
          const totalP = document.querySelector('.page-header-left p');
          if (totalP) {
            const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
            totalP.textContent = isAR ? `إجمالي ${_items.length} صنف` : `${_items.length} total items`;
          }
          const contentEl = document.getElementById('items-content') || document.getElementById('items-table');
          if (contentEl) renderItems(getFiltered());
        } catch (err) { }
      }
    }
  });

  // ── Owner Price & Cost Checker + Rapid Stock Addition Modal ──
  let _qscSelectedItem = null;
  let _qscSessionLog = [];
  let _qscExchRate = 89500;
  let _qscCur1 = 'USD';
  let _qscCur2 = 'LBP';

  async function openQuickStockAndCostModal(initialItemId = null) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    _items = (await DB.getAll('items')) || [];
    _qscCur1 = await DB.getSetting('currency_1', 'USD');
    _qscCur2 = await DB.getSetting('currency_2', 'LBP');
    _qscExchRate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;

    let modal = document.getElementById('quick-stock-cost-modal');
    if (modal) modal.remove();

    modal = document.createElement('div');
    modal.id = 'quick-stock-cost-modal';
    modal.className = 'modal-overlay open';
    modal.style.zIndex = '10005';
    modal.onclick = (e) => { if (e.target === modal) modal.remove(); };

    modal.innerHTML = `
      <div class="modal modal-lg" style="max-width:760px;width:95%;max-height:92vh;overflow-y:auto;border-radius:16px;border:1.5px solid rgba(16,185,129,0.4)">
        <div class="modal-header" style="background:linear-gradient(135deg,rgba(16,185,129,0.14),rgba(5,150,105,0.05));border-bottom:1px solid var(--border-color)">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:1.5rem">⚡</span>
            <div>
              <h3 class="modal-title" style="margin:0;font-weight:900">${isAR ? 'فاحص السعر والكلفة للمالك + إدخال مخزون سريع' : 'Owner Price & Cost Checker + Rapid Stock Entry'}</h3>
              <div style="font-size:0.76rem;color:var(--text-muted);margin-top:2px">
                ${isAR ? 'امسح الباركود أو ابحث بالاسم لعرض السعر والكلفة والربح وزيادة الستوك فوراً بضغطة Enter' : 'Scan barcode or search by name to view Selling Price, Cost, Profit, and add stock immediately'}
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button type="button" class="btn btn-secondary btn-sm" onclick="window.open('mobile.html', '_blank')" title="${isAR ? 'فتح تطبيق الموبايل للمالك' : 'Open Owner Mobile App'}" style="font-weight:800">
              📱 ${isAR ? 'تطبيق الموبايل' : 'Mobile App'}
            </button>
            <button class="modal-close" onclick="document.getElementById('quick-stock-cost-modal')?.remove()">✕</button>
          </div>
        </div>

        <div class="modal-body" style="padding:18px;display:flex;flex-direction:column;gap:14px">
          <!-- Barcode / Search Input -->
          <div style="position:relative">
            <label style="font-size:0.78rem;font-weight:800;color:var(--text-muted);display:block;margin-bottom:5px">
              🔍 ${isAR ? 'امسح الباركود الآن أو اكتب اسم/رمز الصنف:' : 'Scan Barcode Now or Type Item Name / Code:'}
            </label>
            <input type="text" id="qsc-search-input" class="form-control"
              placeholder="${isAR ? 'امسح الباركود هنا أو ابحث بالاسم...' : 'Scan barcode here or search item name...'}"
              oninput="Items._onQscSearch(this.value)"
              onkeydown="Items._onQscKeydown(event)"
              style="font-size:1.05rem;font-weight:800;padding:11px 14px;border:2px solid #10b981;border-radius:10px;background:var(--bg-surface)">
            <div id="qsc-suggestions" style="display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;background:var(--bg-card);border:1.5px solid var(--border-color);border-radius:10px;max-height:240px;overflow-y:auto;z-index:9999;box-shadow:0 12px 30px rgba(0,0,0,0.45)"></div>
          </div>

          <!-- Selected Item Owner Details & Quick Stock Box -->
          <div id="qsc-selected-card" style="display:none;background:var(--bg-surface);border:1.5px solid var(--border-color);border-radius:14px;padding:16px">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:14px;flex-wrap:wrap">
              <div>
                <div id="qsc-item-name" style="font-size:1.25rem;font-weight:900;color:var(--text-primary)">-</div>
                <div id="qsc-item-code" style="font-size:0.82rem;color:var(--text-muted);font-family:monospace;margin-top:2px">-</div>
              </div>
              <div style="display:flex;align-items:center;gap:8px">
                <div style="background:rgba(59,130,246,0.12);border:1px solid rgba(59,130,246,0.35);padding:6px 14px;border-radius:20px;font-weight:900;color:#3b82f6;font-size:0.95rem">
                  📦 ${isAR ? 'المخزون الحالي:' : 'Current Stock:'} <span id="qsc-curr-stock">0</span>
                </div>
                <button type="button" class="btn btn-secondary btn-sm" onclick="if(window._qscCurrentId){ document.getElementById('quick-stock-cost-modal')?.remove(); Items.openForm(window._qscCurrentId); }" style="font-weight:700">
                  ✏️ ${isAR ? 'فتح البطاقة الكاملة' : 'Full Edit'}
                </button>
              </div>
            </div>

            <!-- Owner Price & Cost 4-Card Grid -->
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:10px;margin-bottom:16px">
              <div style="background:rgba(16,185,129,0.08);border:1.5px solid rgba(16,185,129,0.35);border-radius:12px;padding:12px;text-align:center">
                <div style="font-size:0.74rem;font-weight:800;color:var(--text-muted);margin-bottom:4px">${isAR ? 'سعر البيع (USD)' : 'SELL PRICE (USD)'}</div>
                <div id="qsc-sell-usd" style="font-size:1.45rem;font-weight:900;color:#10b981">$0.00</div>
              </div>
              <div style="background:rgba(245,158,11,0.08);border:1.5px solid rgba(245,158,11,0.35);border-radius:12px;padding:12px;text-align:center">
                <div style="font-size:0.74rem;font-weight:800;color:var(--text-muted);margin-bottom:4px">${isAR ? 'سعر البيع (بالليرة)' : 'SELL PRICE (LBP)'}</div>
                <div id="qsc-sell-lbp" style="font-size:1.25rem;font-weight:900;color:#f59e0b">0 L.L.</div>
              </div>
              <div style="background:rgba(239,68,68,0.08);border:1.5px solid rgba(239,68,68,0.35);border-radius:12px;padding:12px;text-align:center">
                <div style="font-size:0.74rem;font-weight:800;color:var(--text-muted);margin-bottom:4px">${isAR ? 'سعر التكلفة / الكلفة' : 'COST PRICE'}</div>
                <div id="qsc-cost-usd" style="font-size:1.45rem;font-weight:900;color:#ef4444">$0.00</div>
                <div id="qsc-cost-lbp" style="font-size:0.76rem;font-weight:800;color:var(--text-muted);margin-top:2px">0 L.L.</div>
              </div>
              <div style="background:rgba(59,130,246,0.08);border:1.5px solid rgba(59,130,246,0.35);border-radius:12px;padding:12px;text-align:center">
                <div style="font-size:0.74rem;font-weight:800;color:var(--text-muted);margin-bottom:4px">${isAR ? 'الربح الصافي بالقطعة' : 'UNIT PROFIT'}</div>
                <div id="qsc-profit-usd" style="font-size:1.35rem;font-weight:900;color:#3b82f6">$0.00</div>
                <div id="qsc-profit-pct" style="font-size:0.76rem;font-weight:800;color:var(--text-muted);margin-top:2px">0%</div>
              </div>
            </div>

            <!-- Rapid Stock Addition Form -->
            <div style="background:rgba(16,185,129,0.06);border:1.5px dashed rgba(16,185,129,0.45);border-radius:12px;padding:14px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px">
                <span style="font-weight:900;font-size:0.92rem;color:#10b981">➕ ${isAR ? 'زيادة سريعة على المخزون (اضغط Enter للحفظ الفوري):' : 'Quick Add to Stock (Press Enter to Save Immediately):'}</span>
                <div style="display:flex;gap:5px;flex-wrap:wrap">
                  ${[1, 5, 10, 12, 24, 50, 100].map(n => `
                    <button type="button" class="btn btn-secondary btn-sm" onclick="Items.setQscPresetQty(${n})" style="padding:3px 9px;font-weight:800;font-size:0.78rem">+${n}</button>
                  `).join('')}
                </div>
              </div>

              <div style="display:grid;grid-template-columns:1.2fr 1fr 1fr auto;gap:10px;align-items:end">
                <div>
                  <label style="font-size:0.75rem;font-weight:800;color:var(--text-muted);display:block;margin-bottom:4px">${isAR ? 'الكمية المضافة (+)' : 'Qty to Add (+)'}</label>
                  <input type="number" id="qsc-add-qty" class="form-control" value="1" step="any" min="0.001"
                    oninput="Items.recalcQscTotals()"
                    onkeydown="if(event.key==='Enter'){ event.preventDefault(); Items.saveQuickStockAddition(); }"
                    style="font-size:1.3rem;font-weight:900;text-align:center;border:2px solid #10b981;color:#10b981">
                </div>
                <div>
                  <label style="font-size:0.75rem;font-weight:800;color:var(--text-muted);display:block;margin-bottom:4px">${isAR ? 'تعديل الكلفة ($)' : 'Cost Price ($)'}</label>
                  <input type="number" id="qsc-edit-cost" class="form-control" step="any" min="0"
                    oninput="Items.recalcQscTotals()"
                    onkeydown="if(event.key==='Enter'){ event.preventDefault(); Items.saveQuickStockAddition(); }"
                    style="font-weight:800">
                </div>
                <div>
                  <label style="font-size:0.75rem;font-weight:800;color:var(--text-muted);display:block;margin-bottom:4px">${isAR ? 'تعديل سعر البيع ($)' : 'Selling Price ($)'}</label>
                  <input type="number" id="qsc-edit-price" class="form-control" step="any" min="0"
                    oninput="Items.recalcQscTotals()"
                    onkeydown="if(event.key==='Enter'){ event.preventDefault(); Items.saveQuickStockAddition(); }"
                    style="font-weight:800">
                </div>
                <div>
                  <button type="button" class="btn btn-primary" onclick="Items.saveQuickStockAddition()" style="height:42px;padding:0 20px;font-weight:900;background:linear-gradient(135deg,#10b981,#059669);border:none;display:flex;align-items:center;gap:6px">
                    <span>💾</span> <span>${isAR ? 'إضافة للمخزون (Enter)' : 'Add to Stock (Enter)'}</span>
                  </button>
                </div>
              </div>

              <div style="margin-top:10px;display:flex;justify-content:space-between;align-items:center;font-size:0.84rem;padding-top:8px;border-top:1px solid rgba(16,185,129,0.2)">
                <span style="color:var(--text-muted)">${isAR ? 'المخزون الجديد بعد الإضافة:' : 'New Stock After Addition:'}</span>
                <span id="qsc-new-stock-preview" style="font-size:1.15rem;font-weight:900;color:#10b981">0</span>
              </div>
            </div>
          </div>

          <!-- Session Recent Additions Log -->
          <div id="qsc-session-log-wrap" style="display:${_qscSessionLog.length > 0 ? 'block' : 'none'}">
            <div style="font-size:0.78rem;font-weight:800;color:var(--text-muted);margin-bottom:6px">
              ✅ ${isAR ? 'الأصناف التي تمت زيادتها في هذه الجلسة:' : 'Items Added in This Session:'}
            </div>
            <div id="qsc-session-log" style="max-height:140px;overflow-y:auto;display:flex;flex-direction:column;gap:4px"></div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    _renderQscSessionLog();

    if (initialItemId) {
      selectQscItem(initialItemId);
    } else {
      setTimeout(() => document.getElementById('qsc-search-input')?.focus(), 60);
    }
  }

  function _onQscSearch(query) {
    const sugBox = document.getElementById('qsc-suggestions');
    if (!sugBox) return;
    const clean = String(query || '').trim().toLowerCase();
    if (!clean) {
      sugBox.style.display = 'none';
      return;
    }

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const matches = (_items || []).filter(i =>
      (i.name && String(i.name).toLowerCase().includes(clean)) ||
      (i.name_ar && String(i.name_ar).toLowerCase().includes(clean)) ||
      (i.name_en && String(i.name_en).toLowerCase().includes(clean)) ||
      (i.barcode && String(i.barcode).toLowerCase().includes(clean)) ||
      (i.item_code && String(i.item_code).toLowerCase().includes(clean))
    ).slice(0, 15);

    if (matches.length === 0) {
      sugBox.innerHTML = `<div style="padding:10px 14px;color:var(--text-muted);font-size:0.84rem">${isAR ? 'لا يوجد صنف مطابق' : 'No matching item found'}</div>`;
      sugBox.style.display = 'block';
      return;
    }

    sugBox.innerHTML = matches.map(m => {
      const mName = isAR ? (m.name_ar || m.name || m.name_en) : (m.name_en || m.name || m.name_ar);
      const sell = parseFloat(m.selling_price ?? m.price) || 0;
      const cost = parseFloat(m.cost_price) || 0;
      const stk = m.stock_qty ?? m.stock ?? 0;
      return `
        <div onclick="Items.selectQscItem('${m.id}')" style="padding:10px 14px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;cursor:pointer" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background='transparent'">
          <div>
            <div style="font-weight:800;font-size:0.92rem">${Utils.sanitize(mName || '')}</div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-family:monospace">${m.barcode || m.item_code || '-'} • ${isAR ? 'المخزون:' : 'Stock:'} <strong>${stk}</strong></div>
          </div>
          <div style="text-align:right;display:flex;gap:12px;align-items:center">
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'الكلفة' : 'Cost'}</div>
              <div style="font-weight:800;color:#ef4444">$${cost.toFixed(2)}</div>
            </div>
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'البيع' : 'Sell'}</div>
              <div style="font-weight:900;color:#10b981">$${sell.toFixed(2)}</div>
            </div>
          </div>
        </div>
      `;
    }).join('');
    sugBox.style.display = 'block';
  }

  function _onQscKeydown(e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const val = String(e.target.value || '').trim().toLowerCase();
    if (!val) return;
    const cleanNoZero = val.replace(/^0+/, '');

    let match = (_items || []).find(i => {
      const b = String(i.barcode || '').trim().toLowerCase();
      const ic = String(i.item_code || '').trim().toLowerCase();
      return b === val || ic === val || (b && b.replace(/^0+/, '') === cleanNoZero) || (ic && ic.replace(/^0+/, '') === cleanNoZero);
    });
    if (!match) {
      match = (_items || []).find(i =>
        (i.name && String(i.name).toLowerCase().includes(val)) ||
        (i.name_ar && String(i.name_ar).toLowerCase().includes(val)) ||
        (i.name_en && String(i.name_en).toLowerCase().includes(val))
      );
    }
    if (match) {
      selectQscItem(match.id);
    } else {
      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
      Utils.toast(isAR ? `⚠️ لم يتم العثور على الصنف: ${e.target.value}` : `⚠️ Item not found: ${e.target.value}`, 'warning');
    }
  }

  function selectQscItem(id) {
    const sugBox = document.getElementById('qsc-suggestions');
    if (sugBox) sugBox.style.display = 'none';
    const item = (_items || []).find(i => String(i.id) === String(id));
    if (!item) return;

    _qscSelectedItem = item;
    window._qscCurrentId = item.id;
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;

    const card = document.getElementById('qsc-selected-card');
    if (card) card.style.display = 'block';

    const name = isAR ? (item.name_ar || item.name || item.name_en) : (item.name_en || item.name || item.name_ar);
    const sell = parseFloat(item.selling_price ?? item.price) || 0;
    const cost = parseFloat(item.cost_price) || 0;
    const stock = parseFloat(item.stock_qty ?? item.stock) || 0;

    document.getElementById('qsc-item-name').textContent = name || '-';
    document.getElementById('qsc-item-code').textContent = `${isAR ? 'الباركود:' : 'Barcode:'} ${item.barcode || '-'} | ${isAR ? 'الرمز:' : 'Code:'} ${item.item_code || '-'}`;
    document.getElementById('qsc-curr-stock').textContent = `${stock} ${item.unit || ''}`;

    const addInp = document.getElementById('qsc-add-qty');
    const costInp = document.getElementById('qsc-edit-cost');
    const priceInp = document.getElementById('qsc-edit-price');
    if (addInp) addInp.value = 1;
    if (costInp) costInp.value = cost;
    if (priceInp) priceInp.value = sell;

    recalcQscTotals();

    setTimeout(() => {
      if (addInp) {
        addInp.focus();
        addInp.select();
      }
    }, 40);
  }

  function setQscPresetQty(val) {
    const addInp = document.getElementById('qsc-add-qty');
    if (addInp) {
      addInp.value = val;
      recalcQscTotals();
      addInp.focus();
      addInp.select();
    }
  }

  function recalcQscTotals() {
    if (!_qscSelectedItem) return;
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const currStock = parseFloat(_qscSelectedItem.stock_qty ?? _qscSelectedItem.stock) || 0;
    const addQty = parseFloat(document.getElementById('qsc-add-qty')?.value) || 0;
    const cost = parseFloat(document.getElementById('qsc-edit-cost')?.value) || 0;
    const sell = parseFloat(document.getElementById('qsc-edit-price')?.value) || 0;

    const sellLbp = Utils.calcSecondaryPrice ? Utils.calcSecondaryPrice(sell, _qscCur1, _qscCur2, _qscExchRate) : Math.round(sell * _qscExchRate);
    const costLbp = Utils.calcSecondaryPrice ? Utils.calcSecondaryPrice(cost, _qscCur1, _qscCur2, _qscExchRate) : Math.round(cost * _qscExchRate);
    const profit = sell - cost;
    const margin = sell > 0 ? ((profit / sell) * 100).toFixed(1) : '0.0';

    const sellUsdEl = document.getElementById('qsc-sell-usd');
    const sellLbpEl = document.getElementById('qsc-sell-lbp');
    const costUsdEl = document.getElementById('qsc-cost-usd');
    const costLbpEl = document.getElementById('qsc-cost-lbp');
    const profUsdEl = document.getElementById('qsc-profit-usd');
    const profPctEl = document.getElementById('qsc-profit-pct');
    const newStkEl = document.getElementById('qsc-new-stock-preview');

    if (sellUsdEl) sellUsdEl.textContent = Utils.formatMoney ? Utils.formatMoney(sell, _qscCur1) : `$${sell.toFixed(2)}`;
    if (sellLbpEl) sellLbpEl.textContent = Utils.formatMoney ? Utils.formatMoney(sellLbp, _qscCur2) : `${sellLbp.toLocaleString()} L.L.`;
    if (costUsdEl) costUsdEl.textContent = Utils.formatMoney ? Utils.formatMoney(cost, _qscCur1) : `$${cost.toFixed(2)}`;
    if (costLbpEl) costLbpEl.textContent = Utils.formatMoney ? Utils.formatMoney(costLbp, _qscCur2) : `${costLbp.toLocaleString()} L.L.`;
    if (profUsdEl) {
      profUsdEl.textContent = Utils.formatMoney ? Utils.formatMoney(profit, _qscCur1) : `$${profit.toFixed(2)}`;
      profUsdEl.style.color = profit >= 0 ? '#3b82f6' : '#ef4444';
    }
    if (profPctEl) profPctEl.textContent = `${isAR ? 'هامش الربح:' : 'Margin:'} ${margin}%`;
    if (newStkEl) newStkEl.textContent = `${currStock} + ${addQty} = ${currStock + addQty} ${_qscSelectedItem.unit || ''}`;
  }

  function _renderQscSessionLog() {
    const wrap = document.getElementById('qsc-session-log-wrap');
    const logEl = document.getElementById('qsc-session-log');
    if (!wrap || !logEl) return;
    if (_qscSessionLog.length === 0) {
      wrap.style.display = 'none';
      return;
    }
    wrap.style.display = 'block';
    logEl.innerHTML = _qscSessionLog.slice(0, 15).map(entry => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 10px;background:var(--bg-surface);border:1px solid var(--border-color);border-radius:8px;font-size:0.8rem">
        <div><strong>${Utils.sanitize(entry.name)}</strong> <span style="color:var(--text-muted);font-family:monospace">(${entry.barcode || '-'})</span></div>
        <div style="display:flex;gap:10px;align-items:center">
          <span style="color:#10b981;font-weight:900">+${entry.added}</span>
          <span style="color:var(--text-muted)">➔ <strong>${entry.newStock}</strong></span>
        </div>
      </div>
    `).join('');
  }

  async function saveQuickStockAddition() {
    if (!_qscSelectedItem) return;
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const addQty = parseFloat(document.getElementById('qsc-add-qty')?.value) || 0;
    if (addQty <= 0) {
      Utils.toast(isAR ? 'الكمية المضافة يجب أن تكون أكبر من صفر' : 'Added quantity must be greater than zero', 'warning');
      return;
    }

    const liveItem = (await DB.get('items', _qscSelectedItem.id)) || _qscSelectedItem;
    const oldQty = parseFloat(liveItem.stock_qty ?? liveItem.stock) || 0;
    const newQty = oldQty + addQty;

    const newCost = parseFloat(document.getElementById('qsc-edit-cost')?.value);
    const newPrice = parseFloat(document.getElementById('qsc-edit-price')?.value);

    liveItem.stock_qty = newQty;
    liveItem.stock = newQty;
    if (!isNaN(newCost) && newCost >= 0) liveItem.cost_price = newCost;
    if (!isNaN(newPrice) && newPrice > 0) {
      liveItem.selling_price = newPrice;
      liveItem.price = newPrice;
    }
    liveItem.updated_at = new Date().toISOString();

    if (!liveItem.warehouse_stocks) liveItem.warehouse_stocks = {};
    const activeWhId = window._activeStationWhId || 1;
    liveItem.warehouse_stocks[activeWhId] = newQty;
    liveItem.warehouse_stocks['1'] = newQty;
    if (typeof window !== 'undefined' && window._posWarehouseId) {
      liveItem.warehouse_stocks[window._posWarehouseId] = newQty;
    }

    await DB.update('items', liveItem);

    // Record stock adjustment and movement
    try {
      const ref = await DB.nextSeq('stock_adjustments', 'ADJ-', 5);
      await DB.add('stock_adjustments', {
        ref,
        item_id: liveItem.id,
        item_name: liveItem.name || liveItem.name_ar || liveItem.name_en,
        type: 'in',
        qty: addQty,
        old_qty: oldQty,
        new_qty: newQty,
        date: new Date().toISOString(),
        notes: 'Quick Stock In (Owner Fast Entry)'
      });
      await DB.add('stock_movements', {
        item_id: liveItem.id,
        type: 'in',
        qty: addQty,
        balance_after: newQty,
        created_at: new Date().toISOString(),
        notes: 'Quick Stock In'
      });
    } catch (mErr) { }

    // Sync to Server / Cloud
    try {
      const syncCfg = (typeof window !== 'undefined' && window.BranchSync && typeof BranchSync.getConfig === 'function')
        ? await BranchSync.getConfig()
        : {};
      const isServer = !syncCfg.role || syncCfg.role === 'server';
      if (isServer && typeof CloudSync !== 'undefined') {
        CloudSync.pushItem(liveItem);
      }
      if (typeof BranchSync !== 'undefined' && typeof BranchSync.notifyChange === 'function') {
        BranchSync.notifyChange('items', liveItem);
      }
      if (isServer && typeof OnlineOrders !== 'undefined' && typeof OnlineOrders.syncSingleProductToCloud === 'function') {
        OnlineOrders.syncSingleProductToCloud(liveItem).catch(() => { });
      }
    } catch (sErr) { }

    _qscSessionLog.unshift({
      name: liveItem.name_ar || liveItem.name || liveItem.name_en,
      barcode: liveItem.barcode || liveItem.item_code || '',
      added: addQty,
      newStock: newQty
    });
    _renderQscSessionLog();

    _items = (await DB.getAll('items')) || [];
    _qscSelectedItem = liveItem;
    document.getElementById('qsc-curr-stock').textContent = `${newQty} ${liveItem.unit || ''}`;
    recalcQscTotals();

    const contentEl = document.getElementById('items-content') || document.getElementById('items-table');
    if (contentEl) {
      renderItems(getFiltered());
    }

    Utils.toast(
      isAR
        ? `✅ تمت زيادة +${addQty} إلى (${liveItem.name_ar || liveItem.name}) • المخزون الجديد: ${newQty}`
        : `✅ Added +${addQty} to (${liveItem.name || liveItem.name_en}) • New Stock: ${newQty}`,
      'success'
    );

    const searchInp = document.getElementById('qsc-search-input');
    if (searchInp) {
      searchInp.value = '';
      searchInp.focus();
    }
  }

  return {
    render, search, applyFilters, switchView, goPage, openForm, previewImage, clearImage,
    saveItem, deleteItem, exportItems, _toggleExpiryField, quickAddCategory,
    openBarcodeModal, execPrintBarcode, _updateBarcodeModalPreview, _onBarcodeSizeChange,
    aiTranslateName, handleUnitChange, recalcTotalStock, onMainStockInput,
    toggleLinkedItemDropdown, filterLinkedItemDropdown, selectLinkedItemOption, generateRandomBarcode,
    toggleCountryDropdown, filterCountryDropdown, selectCountryOption, onColorPickerChange,
    toggleColumnPicker, setColumnVisibility, resetColumns,
    recalcPricing, setProfitPreset,
    downloadExcelSample, openImportExcelModal, importItemsExcel,
    openDeleteExcelModal, handleDeleteExcelFile, executeDeleteExcelMatched,
    wipeAllItemsCatalog,
    restoreMissingFromPurchasing, openRestorePreviewModal, executeRestoreFromPurchasing,
    toggleScaleFields, applyScalePreset, onScalePluInput, syncScaleBarcodeToMain,
    switchTab, syncScalePrice, syncScaleCost, syncScaleVat,
    toggleNeedsDefFilter,
    openQuickStockAndCostModal, _onQscSearch, _onQscKeydown, selectQscItem, setQscPresetQty, recalcQscTotals, saveQuickStockAddition
  };
})();

window.Items = Items;

document.addEventListener('click', (e) => {
  const container = document.getElementById('linked-item-container');
  if (container && !container.contains(e.target)) {
    const dropdown = document.getElementById('linked-item-dropdown');
    if (dropdown) dropdown.style.display = 'none';
  }

  const countryContainer = document.getElementById('country-origin-container');
  if (countryContainer && !countryContainer.contains(e.target)) {
    const countryDropdown = document.getElementById('country-origin-dropdown');
    if (countryDropdown) countryDropdown.style.display = 'none';
  }

  const colPicker = document.getElementById('items-col-picker-dropdown');
  if (colPicker && !colPicker.contains(e.target)) {
    const menu = document.getElementById('items-col-picker-menu');
    if (menu) menu.classList.remove('open');
  }
});
