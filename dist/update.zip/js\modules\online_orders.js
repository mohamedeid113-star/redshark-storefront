/**
 * Red Shark POS — Online Orders & Storefront Bridge Module
 * Integrates with Supabase Multi-Tenant E-Commerce Storefront
 * - Real-time incoming order sound notifications (Talabat/UberEats style chime)
 * - Complete lifecycle: Received -> Preparing -> Out for Delivery -> Completed / Cancelled
 * - 1-Click Print Thermal Packing Slip & Invoice for delivery bag attachment
 * - Full POS Integration: Converts to Sale, deducts inventory, records in CashBox, updates Customer & Reports
 * - Catalog & Stock Sync from Red Shark POS to Supabase
 */

const OnlineOrders = (() => {
  // Default connection credentials matching Supabase CloudSync
  const DEFAULT_SUPABASE_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
  const DEFAULT_SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";

  let _orders = [];
  let _activeFilter = 'all'; // 'all', 'received', 'preparing', 'out_for_delivery', 'completed', 'cancelled'
  let _pollInterval = null;
  let _chimeInterval = null;
  let _audioCtx = null;
  let _isMuted = false;
  let _lastNotifiedOrderId = null;
  let _resolvedShopId = null;

  // ── 1. Settings & Config Helpers ──────────────────────────────────────────
  async function getConfig() {
    let url = DEFAULT_SUPABASE_URL;
    let key = DEFAULT_SUPABASE_KEY;
    let slug = '';
    let autoPrint = false;
    let savedPin = null;
    let provider = 'direct';

    if (typeof DB !== 'undefined') {
      try {
        provider = await DB.getSetting('online_store_provider', 'direct');
        const savedUrl = await DB.getSetting('online_store_url', null);
        const savedKey = await DB.getSetting('online_store_key', null);
        const savedSlug = await DB.getSetting('online_store_shop_slug', null);
        savedPin = await DB.getSetting('online_store_cloud_pin', null);
        const savedAutoPrint = await DB.getSetting('online_store_autoprint', false);

        if (provider === 'direct') {
          url = (typeof window !== 'undefined' && window.location.origin && window.location.origin.startsWith('http')) 
            ? window.location.origin 
            : 'http://127.0.0.1:3000';
        } else {
          if (savedUrl) url = savedUrl.trim();
          if (savedKey) key = savedKey.trim();
        }
        if (savedSlug) slug = savedSlug.trim();
        autoPrint = savedAutoPrint === true || savedAutoPrint === 'true';
      } catch (e) {}
    }

    if (!slug) {
      slug = (localStorage.getItem('redshark_shop_slug') || localStorage.getItem('sync_cloud_slug') || '').trim();
    }
    // No default fallback if intentionally blank

    const pin = savedPin || localStorage.getItem('redshark_cloud_pin') || '';
    return { url, key, slug, autoPrint, pin, provider };
  }

  function getHeaders(key) {
    return {
      "apikey": key,
      "Authorization": `Bearer ${key}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation"
    };
  }

  let _resolvedShopSlug = '';

  // Resolves the Shop UUID from the slug (e.g. 'bobmarket')
  async function resolveShopId(cfg, forceFresh = false, allowAutoCreate = false) {
    if (!cfg || !cfg.slug || !cfg.slug.trim()) return null;
    const cleanSlug = cfg.slug.trim().toLowerCase();

    // 1. If in-memory already verified during this session and not forced fresh
    if (!forceFresh && _resolvedShopId && _resolvedShopSlug === cleanSlug) {
      return _resolvedShopId;
    }

    // 2. ALWAYS query Supabase directly first to get the authoritative, current tenant UUID
    try {
      const resTenant = await fetch(`${cfg.url}/rest/v1/tenants?slug=eq.${encodeURIComponent(cleanSlug)}&select=id,shop_name,is_active`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(4500)
      });
      if (resTenant.ok) {
        const tenants = await resTenant.json();
        if (tenants && tenants.length > 0) {
          const t = tenants[0];
          _resolvedShopId = t.id;
          _resolvedShopSlug = cleanSlug;
          try { localStorage.setItem('rs_resolved_shop_id_' + cleanSlug, t.id); } catch(e) {}
          return _resolvedShopId;
        } else if (allowAutoCreate && cleanSlug.length >= 2) {
          // Only auto-provision tenant in Supabase when explicitly saving settings (never on background poll keystrokes)
          try {
            const createRes = await fetch(`${cfg.url}/rest/v1/tenants`, {
              method: 'POST',
              headers: getHeaders(cfg.key),
              body: JSON.stringify({
                shop_name: cleanSlug,
                slug: cleanSlug,
                is_active: true,
                link_pos_stock: true,
                currency: 'USD',
                currency_lbp_rate: 89500
              })
            });
            if (createRes.ok) {
              const created = await createRes.json();
              if (created && created[0]) {
                _resolvedShopId = created[0].id;
                _resolvedShopSlug = cleanSlug;
                try { localStorage.setItem('rs_resolved_shop_id_' + cleanSlug, created[0].id); } catch(e) {}
                console.log('[OnlineOrders] Auto-provisioned new tenant in cloud for slug:', cleanSlug);
                return _resolvedShopId;
              }
            }
          } catch(err) {}
        }
      }

      // Fallback to shops view/table
      const res = await fetch(`${cfg.url}/rest/v1/shops?slug=eq.${encodeURIComponent(cleanSlug)}&select=id,name,is_active`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(4500)
      });
      if (res.ok) {
        const shops = await res.json();
        if (shops && shops.length > 0) {
          _resolvedShopId = shops[0].id;
          _resolvedShopSlug = cleanSlug;
          try { localStorage.setItem('rs_resolved_shop_id_' + cleanSlug, shops[0].id); } catch(e) {}
          return _resolvedShopId;
        }
      }
    } catch (e) {
      console.warn('[OnlineOrders] Could not resolve shop UUID by slug over network, trying cache:', e);
    }

    // 3. Fallback to cache ONLY if network is down
    const cached = localStorage.getItem('rs_resolved_shop_id_' + cleanSlug);
    if (cached) {
      _resolvedShopId = cached;
      _resolvedShopSlug = cleanSlug;
      return _resolvedShopId;
    }
    return null;
  }

  // ── 2. Audio Chime (Synthesized Alert Sound) ───────────────────────────────
  function playAlertChime() {
    if (_isMuted) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      if (!_audioCtx) _audioCtx = new AudioContext();
      if (_audioCtx.state === 'suspended') _audioCtx.resume();

      const now = _audioCtx.currentTime;
      // High-energy 2-tone chime
      const tones = [
        { freq: 880, start: 0.0, dur: 0.15 },
        { freq: 1174.66, start: 0.18, dur: 0.22 },
        { freq: 880, start: 0.45, dur: 0.15 },
        { freq: 1318.51, start: 0.63, dur: 0.35 }
      ];

      tones.forEach(t => {
        const osc = _audioCtx.createOscillator();
        const gain = _audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(t.freq, now + t.start);

        gain.gain.setValueAtTime(0.01, now + t.start);
        gain.gain.exponentialRampToValueAtTime(0.35, now + t.start + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + t.start + t.dur);

        osc.connect(gain);
        gain.connect(_audioCtx.destination);

        osc.start(now + t.start);
        osc.stop(now + t.start + t.dur);
      });
    } catch (err) {
      console.warn('[OnlineOrders] Audio chime warning:', err);
    }
  }

  function startChimeLoop() {
    if (_chimeInterval) return;
    playAlertChime();
    _chimeInterval = setInterval(() => {
      const hasPending = _orders.some(o => o.order_status === 'received');
      if (hasPending) {
        playAlertChime();
      } else {
        stopChimeLoop();
      }
    }, 4500);
  }

  function stopChimeLoop() {
    if (_chimeInterval) {
      clearInterval(_chimeInterval);
      _chimeInterval = null;
    }
  }

  // ── 3. Real-Time Fetch & State Sync ────────────────────────────────────────
  async function fetchOrders(silent = false) {
    try {
      const cfg = await getConfig();
      if (!cfg || !cfg.slug || !cfg.slug.trim()) return;
      const shopId = await resolveShopId(cfg);

      let query = `${cfg.url}/rest/v1/orders?select=*,order_items(*)&order=created_at.desc&limit=60`;
      if (shopId) {
        query += `&shop_id=eq.${shopId}`;
      }

      const res = await fetch(query, { headers: getHeaders(cfg.key) });
      if (!res.ok) {
        if (!silent) console.warn('[OnlineOrders] Orders fetch returned status:', res.status);
        return;
      }

      const incoming = await res.json();
      if (!Array.isArray(incoming)) return;

      // Filter to ONLY genuine online store orders (exclude in-store POS walk-in sales)
      const genuineOnlineOrders = incoming.filter(o => {
        if (o.pos_synced === true) return false;
        if (o.order_number && (o.order_number.startsWith('INV-') || o.order_number.includes('-INV-'))) return false;
        try {
          const n = typeof o.notes === 'string' ? JSON.parse(o.notes) : (o.notes || {});
          if (n.source === 'pos') return false;
        } catch(e) {}
        return true;
      });

      const previousPending = _orders.filter(o => o.order_status === 'received').map(o => o.id);
      _orders = genuineOnlineOrders;

      // Check for brand new received orders
      const currentPending = _orders.filter(o => o.order_status === 'received');
      const newOrders = currentPending.filter(o => !previousPending.includes(o.id));

      if (newOrders.length > 0 && currentPending.length > 0) {
        const latest = newOrders[0];
        if (latest.id !== _lastNotifiedOrderId) {
          _lastNotifiedOrderId = latest.id;
          startChimeLoop();

          const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
          const msg = isAR
            ? `🛍️ طلب أونلاين جديد #${latest.order_number || ''} من ${latest.customer_name} (${latest.total || 0} ${latest.currency_code || 'USD'})`
            : `🛍️ New Online Order #${latest.order_number || ''} from ${latest.customer_name} (${latest.total || 0} ${latest.currency_code || 'USD'})`;

          if (typeof Utils !== 'undefined' && Utils.toast) {
            Utils.toast(msg, 'warning', 8000);
          }

          // Browser Desktop Notification if granted
          if ('Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification('Red Shark POS — New Online Order', {
                body: `${latest.customer_name} placed order #${latest.order_number} for ${latest.total} ${latest.currency_code || 'USD'}`,
                icon: 'favicon.png'
              });
            } catch (e) {}
          }

          // Auto-print receipt if enabled
          if (cfg.autoPrint) {
            printOrderSlip(latest, true);
          }
        }
      } else if (currentPending.length === 0) {
        stopChimeLoop();
      }

      updateBadges();

      // Refresh UI if online-orders page is currently active
      const container = document.getElementById('online-orders-container');
      if (container) {
        renderOrderList();
      }
    } catch (e) {
      if (!silent) console.warn('[OnlineOrders] Error fetching orders:', e);
    }
  }

  function updateBadges() {
    const receivedCount = _orders.filter(o => o.order_status === 'received').length;

    // Topbar live count badge
    const topBadge = document.getElementById('online-orders-count-badge');
    if (topBadge) {
      if (receivedCount > 0) {
        topBadge.textContent = receivedCount;
        topBadge.style.display = 'inline-block';
      } else {
        topBadge.style.display = 'none';
      }
    }

    // Sidebar badge
    const sideBadge = document.getElementById('sidebar-online-orders-badge');
    if (sideBadge) {
      if (receivedCount > 0) {
        sideBadge.textContent = receivedCount;
        sideBadge.style.display = 'inline-block';
      } else {
        sideBadge.style.display = 'none';
      }
    }
  }

  // ── 4. Order Status Lifecycle Management ───────────────────────────────────
  async function updateOrderStatus(orderId, newStatus, extraData = {}) {
    // 1. Instantly update local in-memory order and UI so cashier is never blocked
    const local = _orders.find(o => o.id === orderId);
    if (local) {
      local.order_status = newStatus;
      Object.assign(local, extraData);
    }
    updateBadges();
    renderOrderList();

    // 2. Persist to Supabase in background
    try {
      const cfg = await getConfig();
      if (cfg && cfg.url && cfg.key) {
        let payload = {
          order_status: newStatus,
          updated_at: new Date().toISOString(),
          ...extraData
        };

        let res = await fetch(`${cfg.url}/rest/v1/orders?id=eq.${encodeURIComponent(orderId)}`, {
          method: 'PATCH',
          headers: getHeaders(cfg.key),
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(8000)
        });

        // If failed due to unknown extra columns or schema mismatch, fallback to pure status update
        if (!res.ok) {
          console.warn('[OnlineOrders] Extended payload rejected by Supabase, retrying with clean status update...');
          await fetch(`${cfg.url}/rest/v1/orders?id=eq.${encodeURIComponent(orderId)}`, {
            method: 'PATCH',
            headers: getHeaders(cfg.key),
            body: JSON.stringify({
              order_status: newStatus,
              updated_at: new Date().toISOString()
            }),
            signal: AbortSignal.timeout(8000)
          });
        }
      }
    } catch (e) {
      console.warn('[OnlineOrders] Remote status update warning (local status saved):', e);
    }

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const statusLabels = {
      received: isAR ? 'تم نقل الطلب إلى الجديد' : 'Order marked as Received',
      preparing: isAR ? 'جاري تحضير الطلب' : 'Order marked as Preparing',
      out_for_delivery: isAR ? 'الطلب خرج للتوصيل / جاهز للاستلام' : 'Order Out for Delivery',
      completed: isAR ? 'تم تسليم وإغلاق الطلب بنجاح' : 'Order Delivered & Completed',
      cancelled: isAR ? 'تم إلغاء الطلب' : 'Order Cancelled'
    };

    if (typeof Utils !== 'undefined' && Utils.toast) {
      Utils.toast(`✅ ${statusLabels[newStatus] || newStatus}`, 'success');
    }
    return true;
  }

  // Helper to extract items from either order_items relation OR items JSONB column
  function getOrderItems(order) {
    if (!order) return [];
    if (Array.isArray(order.order_items) && order.order_items.length > 0) {
      return order.order_items;
    }
    if (Array.isArray(order.items) && order.items.length > 0) {
      return order.items;
    }
    if (typeof order.items === 'string' && order.items.trim()) {
      try {
        const p = JSON.parse(order.items);
        if (Array.isArray(p) && p.length > 0) return p;
      } catch (e) {}
    }
    return [];
  }

  // ── 4b. Load Online Order into POS Cart (Review & Customization) ───────────
  async function loadOrderIntoPos(orderId) {
    const order = _orders.find(o => o.id === orderId);
    if (!order) return;
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');

    const orderItems = getOrderItems(order);
    if (!orderItems || !orderItems.length) {
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? 'الطلب لا يحتوي على أصناف' : 'Order contains no items', 'warning');
      }
      return;
    }

    const allLocalItems = (typeof DB !== 'undefined') ? (await DB.getAll('items')) || [] : [];
    const localCart = [];

    for (const oi of orderItems) {
      const itName = oi.product_name || oi.name || oi.title || '';
      let matched = allLocalItems.find(i =>
        (i.barcode && oi.barcode && String(i.barcode).trim() === String(oi.barcode).trim()) ||
        (i.id && oi.pos_product_id && String(i.id) === String(oi.pos_product_id)) ||
        (i.id && oi.product_id && String(i.id) === String(oi.product_id)) ||
        (i.name_en && itName && i.name_en.toLowerCase() === itName.toLowerCase()) ||
        (i.name_ar && itName && i.name_ar === itName) ||
        (i.name && itName && i.name.toLowerCase() === itName.toLowerCase())
      );

      const qty = parseFloat(oi.quantity || oi.qty) || 1;
      const unitPrice = parseFloat(oi.unit_price || oi.price) || 0;
      const itemTotal = parseFloat(oi.total_price || oi.total) || (qty * unitPrice);

      if (matched) {
        localCart.push({
          item_id: matched.id,
          name_en: matched.name_en || itName,
          name_ar: matched.name_ar || itName,
          item_code: matched.item_code || '',
          barcode: matched.barcode || '',
          qty: qty,
          price: unitPrice || matched.selling_price || 0,
          cost_price: matched.cost_price || 0,
          total: itemTotal,
          disc_pct: 0,
          disc_amt: 0,
          disc_type: 'pct',
          line_type: 'sale',
          vat_type: matched.vat_type || 'none',
          vat_rate: matched.vat_rate || 0,
          unit: matched.unit || 'pc'
        });
      } else {
        localCart.push({
          item_id: null,
          name_en: itName || 'Online Item',
          name_ar: itName || 'صنف أونلاين',
          item_code: '',
          barcode: oi.barcode || '',
          qty: qty,
          price: unitPrice,
          cost_price: 0,
          total: itemTotal,
          disc_pct: 0,
          disc_amt: 0,
          disc_type: 'pct',
          line_type: 'sale',
          vat_type: 'none',
          vat_rate: 0,
          unit: 'pc'
        });
      }
    }

    if (window.App && typeof App.navigateTo === 'function') {
      App.navigateTo('pos');
    }

    setTimeout(() => {
      if (window.POS && typeof POS.loadOnlineOrder === 'function') {
        POS.loadOnlineOrder(localCart, order);
      }
    }, 180);
  }

  // ── 5. Full POS Sale Conversion & Inventory Deduction ──────────────────────
  async function convertOrderToSale(orderId, targetStatus = null) {
    const order = _orders.find(o => o.id === orderId);
    if (!order) return;

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');

    if (order.pos_synced && order.pos_invoice_ref) {
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? `⚠️ هذا الطلب تم تحويله بالفعل لفاتورة رقم ${order.pos_invoice_ref}` : `⚠️ Order already converted to sale invoice #${order.pos_invoice_ref}`, 'warning');
      }
      return order.pos_invoice_ref;
    }

    try {
      // 1. Resolve or Create Customer in Local POS Database
      let localCustId = null;
      let custName = order.customer_name || (isAR ? 'عميل أونلاين' : 'Online Customer');

      if (typeof DB !== 'undefined') {
        const customers = (await DB.getAll('customers')) || [];
        const phoneClean = (order.customer_phone || '').replace(/[^0-9]/g, '');

        let match = customers.find(c => {
          const cPhone = (c.phone || '').replace(/[^0-9]/g, '');
          return (cPhone && phoneClean && cPhone.includes(phoneClean)) ||
                 (c.name_en && c.name_en.toLowerCase() === custName.toLowerCase()) ||
                 (c.name_ar && c.name_ar === custName);
        });

        if (match) {
          localCustId = match.id;
          custName = match.name_en || match.name_ar || custName;
        } else {
          // Add new customer to local database
          const deliveryAddr = typeof order.delivery_address === 'object' && order.delivery_address
            ? `${order.delivery_address.city || ''}, ${order.delivery_address.street_address || ''} ${order.delivery_address.building || ''}`
            : (order.delivery_address || '');

          const newCust = {
            name_en: custName,
            name_ar: custName,
            phone: order.customer_phone || '',
            email: order.customer_email || '',
            address: deliveryAddr,
            balance: 0,
            points_balance: 0,
            created_at: new Date().toISOString()
          };
          localCustId = await DB.add('customers', newCust);
        }
      }

      // 2. Build Cart Items & Deduct Stock from Local DB
      const orderItems = getOrderItems(order);
      const localCart = [];
      const allLocalItems = (typeof DB !== 'undefined') ? (await DB.getAll('items')) || [] : [];
      const whId = (typeof window !== 'undefined' && window._posWarehouseId) ? window._posWarehouseId : 1;

      for (const oi of orderItems) {
        const itName = oi.product_name || oi.name || oi.title || '';
        // Try matching by barcode, sku, pos_product_id, product_id, or name
        let matched = allLocalItems.find(i =>
          (i.barcode && oi.barcode && i.barcode === oi.barcode) ||
          (i.id && oi.pos_product_id && String(i.id) === String(oi.pos_product_id)) ||
          (i.id && oi.product_id && String(i.id) === String(oi.product_id)) ||
          (i.name_en && itName && i.name_en.toLowerCase() === itName.toLowerCase()) ||
          (i.name_ar && itName && i.name_ar === itName)
        );

        const qty = parseFloat(oi.quantity || oi.qty) || 1;
        const unitPrice = parseFloat(oi.unit_price || oi.price) || 0;
        const itemTotal = parseFloat(oi.total_price || oi.total) || (qty * unitPrice);

        if (matched) {
          localCart.push({
            item_id: matched.id,
            name_en: matched.name_en || itName,
            name_ar: matched.name_ar || itName,
            barcode: matched.barcode || '',
            qty: qty,
            price: unitPrice,
            cost_price: matched.cost_price || 0,
            total: itemTotal,
            line_type: 'sale',
            selling_unit: matched.selling_unit || 'piece'
          });

          // Deduct stock from local items table
          if (typeof DB !== 'undefined') {
            if (!matched.warehouse_stocks) matched.warehouse_stocks = {};
            if (matched.warehouse_stocks[whId] === undefined) matched.warehouse_stocks[whId] = matched.stock_qty || 0;

            const newWhQty = (matched.warehouse_stocks[whId] || 0) - qty;
            const newTotalQty = (matched.stock_qty || 0) - qty;

            matched.warehouse_stocks[whId] = Math.max(0, newWhQty);
            matched.stock_qty = Math.max(0, newTotalQty);

            await DB.update('items', matched);

            // Add stock movement record
            await DB.add('stock_movements', {
              item_id: matched.id,
              type: 'sale',
              ref: order.order_number,
              qty: -qty,
              notes: `Online Order #${order.order_number} (${order.fulfillment_type || 'delivery'})`,
              date: new Date().toISOString()
            });
          }
        } else {
          // Unmatched custom product from online catalog
          localCart.push({
            item_id: null,
            name_en: itName || 'Item',
            name_ar: itName || 'صنف',
            qty: qty,
            price: unitPrice,
            cost_price: 0,
            total: itemTotal,
            line_type: 'sale'
          });
        }
      }

      // Add Delivery Fee as separate item line if applicable
      const deliveryFee = parseFloat(order.delivery_fee) || 0;
      if (deliveryFee > 0) {
        localCart.push({
          item_id: null,
          name_en: 'Delivery Fee',
          name_ar: 'أجور توصيل',
          qty: 1,
          price: deliveryFee,
          total: deliveryFee,
          line_type: 'fee'
        });
      }

      // 3. Generate Official POS Invoice Number
      let invoicePrefix = 'INV-';
      if (typeof POS !== 'undefined' && typeof POS._getInvoicePrefix === 'function') {
        invoicePrefix = POS._getInvoicePrefix();
      }
      const ref = (typeof DB !== 'undefined')
        ? await DB.nextSeq('sales', invoicePrefix, 6)
        : `INV-${Date.now().toString().slice(-6)}`;

      const grandTotalUSD = parseFloat(order.total) || 0;
      const rate = parseFloat(order.exchange_rate) || 89500;
      const grandTotalLBP = parseFloat(order.total_secondary) || Math.round(grandTotalUSD * rate);

      const payMethod = (order.payment_method === 'cod' || order.payment_method === 'cash_in_store')
        ? 'cash'
        : (order.payment_method === 'card_on_delivery' ? 'card' : 'online');

      const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;

      // 4. Construct Full POS Sale Record
      const sale = {
        ref,
        customer_id: localCustId,
        customer_name: custName,
        customer_phone: order.customer_phone || '',
        salesperson_id: user?.id || null,
        salesperson_name: user?.full_name || user?.username || 'Online Storefront',
        items: JSON.stringify(localCart),
        subtotal: parseFloat(order.subtotal) || grandTotalUSD,
        discount: parseFloat(order.discount_amount) || 0,
        discount_amount: parseFloat(order.discount_amount) || 0,
        vat: 0,
        grand_total: grandTotalUSD,
        grand_total_2: grandTotalLBP,
        payment_method: payMethod,
        amount_tendered: grandTotalUSD,
        amount_tendered_2: grandTotalLBP,
        paid_amount: grandTotalUSD,
        change_c1: 0,
        change_c2: 0,
        status: 'paid',
        source: 'online_store',
        online_order_id: order.id,
        online_order_number: order.order_number,
        fulfillment_type: order.fulfillment_type || 'delivery',
        delivery_address: order.delivery_address,
        notes: `Online Store #${order.order_number}${order.notes ? ' — ' + order.notes : ''}`,
        created_at: new Date().toISOString()
      };

      let saleId = null;
      if (typeof DB !== 'undefined') {
        saleId = await DB.add('sales', sale);
      }

      // 5. Record movement in CashBox Session
      const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
      if (cb && typeof cb.recordSale === 'function') {
        try {
          await cb.recordSale(grandTotalUSD, `Online Order #${order.order_number} (${order.fulfillment_type}) -> Invoice ${ref}`);
        } catch (errCb) {
          console.warn('[OnlineOrders] Cashbox recording note:', errCb);
        }
      }

      // 6. Update Order Status in Supabase
      const nextStatus = targetStatus || (order.order_status === 'received' ? 'preparing' : order.order_status);
      await updateOrderStatus(order.id, nextStatus, {
        pos_synced: true,
        payment_status: 'paid',
        pos_invoice_ref: ref
      });

      // 7. Auto Print Finished Invoice for Delivery Packing
      try {
        await printOrderSlip({ ...order, pos_invoice_ref: ref }, false);
      } catch(printErr) {}

      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? `✅ تم إتمام البيع بنجاح وتوليد فاتورة رقم ${ref}` : `✅ Order processed as Sale Invoice #${ref}`, 'success');
      }

      return ref;
    } catch (err) {
      console.error('[OnlineOrders] Convert to sale error:', err);
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(`⚠️ Error processing sale: ${err.message}`, 'error');
      }
    }
  }

  // ── 6. 1-Click Thermal Print Packing Slip & Invoice ─────────────────────────
  async function printOrderSlip(order, isPackingSlip = false) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const items = getOrderItems(order);
    const orderNum = order.order_number || 'N/A';
    const totalUSD = (parseFloat(order.total) || 0).toFixed(2);
    const rate = parseFloat(order.exchange_rate) || 89500;
    const totalLBP = (parseFloat(order.total_secondary) || Math.round(totalUSD * rate)).toLocaleString();

    let addressStr = '';
    if (order.delivery_address) {
      if (typeof order.delivery_address === 'object') {
        const a = order.delivery_address;
        addressStr = [a.city, a.street_address, a.building, a.floor, a.apartment, a.landmark].filter(Boolean).join(', ');
      } else {
        addressStr = String(order.delivery_address);
      }
    }

    const title = isPackingSlip ? (isAR ? 'إشعار تحضير وتغليف طلبية' : 'ONLINE ORDER PACKING SLIP') : (isAR ? 'فاتورة توصيل طلبية أونلاين' : 'DELIVERY ORDER INVOICE');

    const html = `
      <div style="font-family:'Segoe UI',Tahoma,sans-serif;width:100%;max-width:320px;margin:0 auto;color:#000;font-size:12px;padding:4px">
        <div style="text-align:center;border-bottom:2px dashed #000;padding-bottom:8px;margin-bottom:8px">
          <div style="font-size:16px;font-weight:900;text-transform:uppercase">RED SHARK POS</div>
          <div style="font-size:13px;font-weight:800;margin-top:2px;background:#000;color:#fff;padding:2px 6px;display:inline-block;border-radius:3px">${title}</div>
          <div style="font-size:18px;font-weight:900;margin-top:6px;letter-spacing:1px">#${orderNum}</div>
          <div style="font-size:10px;color:#444">${new Date(order.created_at || Date.now()).toLocaleString()}</div>
          ${order.pos_invoice_ref ? `<div style="font-size:11px;font-weight:800;margin-top:2px">POS Inv: ${order.pos_invoice_ref}</div>` : ''}
        </div>

        <div style="border-bottom:1px solid #000;padding-bottom:6px;margin-bottom:6px">
          <div style="font-weight:800;font-size:13px">👤 ${order.customer_name}</div>
          <div style="font-size:12px;font-weight:700">📞 ${order.customer_phone}</div>
          <div style="font-size:11px;margin-top:2px">🛵 <strong>${order.fulfillment_type === 'pickup' ? 'In-Store Pickup (استلام بالمحل)' : 'Home Delivery (توصيل)'}</strong></div>
          ${addressStr ? `<div style="font-size:11px;margin-top:3px;background:#f3f4f6;padding:4px;border-radius:4px">📍 ${addressStr}</div>` : ''}
          ${order.notes ? `<div style="font-size:11px;color:#b91c1c;margin-top:3px">⚠️ Note: ${order.notes}</div>` : ''}
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:8px;font-size:12px">
          <thead>
            <tr style="border-bottom:1px solid #000;text-align:left">
              <th style="padding:4px 0">${isAR ? 'الصنف' : 'Item'}</th>
              <th style="padding:4px 0;text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>
              <th style="padding:4px 0;text-align:right">${isAR ? 'المجموع' : 'Total'}</th>
            </tr>
          </thead>
          <tbody>
            ${items.map(it => `
              <tr style="border-bottom:1px dotted #ccc">
                <td style="padding:4px 0;font-weight:700">${it.product_name}${it.variant_name ? ` (${it.variant_name})` : ''}</td>
                <td style="padding:4px 0;text-align:center;font-weight:800">x${it.quantity}</td>
                <td style="padding:4px 0;text-align:right;font-weight:800">$${(parseFloat(it.total_price) || 0).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="border-top:1px solid #000;padding-top:4px;font-size:12px">
          <div style="display:flex;justify-content:space-between;margin-bottom:2px">
            <span>${isAR ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
            <span>$${(parseFloat(order.subtotal) || 0).toFixed(2)}</span>
          </div>
          ${parseFloat(order.delivery_fee) > 0 ? `
          <div style="display:flex;justify-content:space-between;margin-bottom:2px">
            <span>${isAR ? 'أجور التوصيل:' : 'Delivery Fee:'}</span>
            <span>$${(parseFloat(order.delivery_fee) || 0).toFixed(2)}</span>
          </div>` : ''}
          <div style="display:flex;justify-content:space-between;font-size:15px;font-weight:900;border-top:2px solid #000;padding-top:4px;margin-top:4px">
            <span>TOTAL:</span>
            <span>$${totalUSD} USD</span>
          </div>
          <div style="text-align:right;font-size:12px;font-weight:800;color:#1e40af">
            ≈ ${totalLBP} L.L.
          </div>
        </div>

        <div style="text-align:center;border-top:1px dashed #000;margin-top:10px;padding-top:6px;font-size:11px">
          <div>💳 Method: <strong>${(order.payment_method || 'COD').toUpperCase()}</strong></div>
          <div style="margin-top:4px;font-weight:700">Thank you for ordering with us!</div>
        </div>
      </div>
    `;

    try {
      if (window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
        const dummySale = {
          ref: order.order_number,
          customer_name: order.customer_name,
          grand_total: parseFloat(order.total) || 0,
          grand_total_2: parseFloat(order.total_secondary) || 0,
          created_at: order.created_at
        };
        const rawItems = items.map(it => ({
          name_en: it.product_name,
          name_ar: it.product_name,
          qty: it.quantity,
          price: it.unit_price,
          total: it.total_price
        }));
        await window.PrintEngine.printReceipt(dummySale, rawItems, { name_en: order.customer_name, phone: order.customer_phone }, { pageSize: '80mm' });
      } else if (typeof Utils !== 'undefined' && Utils.printElement) {
        await Utils.printElement(html, `Order-${orderNum}`, '80mm');
      }
    } catch (e) {
      console.error('[OnlineOrders] Print error:', e);
      if (typeof Utils !== 'undefined' && Utils.printElement) {
        await Utils.printElement(html, `Order-${orderNum}`, '80mm');
      }
    }
  }

  // ── 7. Catalog & Stock Sync to Supabase ────────────────────────────────────
  async function syncCatalogToCloud(silent = false) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    if (typeof DB === 'undefined') return;

    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) {
        throw new Error(`Shop with slug "${cfg.slug}" was not found in Supabase. Please check your Shop ID.`);
      }

      if (!silent && typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? '⏳ جاري مزامنة الأصناف والمخزون مع المتجر الإلكتروني...' : '⏳ Syncing catalog & stock with Online Store...', 'info');
      }

      // 1. Sync Categories
      const localCats = (await DB.getAll('categories')) || [];
      const cloudCats = [];

      for (const c of localCats) {
        const catSlug = (c.name_en || c.name || `cat-${c.id}`).toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
        cloudCats.push({
          shop_id: shopId,
          name: c.name_en || c.name_ar || c.name,
          name_ar: c.name_ar || c.name || '',
          name_en: c.name_en || c.name || '',
          slug: catSlug,
          display_order: c.sort_order || 0,
          is_active: true
        });
      }

      if (cloudCats.length > 0) {
        await fetch(`${cfg.url}/rest/v1/categories?on_conflict=shop_id,slug`, {
          method: 'POST',
          headers: { ...getHeaders(cfg.key), 'Prefer': 'resolution=merge-duplicates' },
          body: JSON.stringify(cloudCats)
        });
      }

      // Fetch cloud categories to map IDs
      const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=id,name,slug`, {
        headers: getHeaders(cfg.key)
      });
      const catMap = new Map();
      if (catRes.ok) {
        const cats = await catRes.json();
        cats.forEach(c => {
          catMap.set(c.slug, c.id);
          catMap.set((c.name || '').toLowerCase(), c.id);
        });
      }

      // Sync category images into tenant's category_images map
      try {
        const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key)
        });
        if (tenantRes.ok) {
          const tData = await tenantRes.json();
          if (tData && tData[0]) {
            let bObj = {};
            try {
              bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
            } catch(e) {}
            bObj.category_images = bObj.category_images || {};
            let hasNewCatImg = false;
            for (const c of localCats) {
              const slug = (c.name_en || c.name || `cat-${c.id}`).toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
              const cloudCatId = catMap.get(slug) || catMap.get((c.name || '').toLowerCase());
              const catImg = c.image_url || c.image || null;
              if (cloudCatId && catImg && bObj.category_images[cloudCatId] !== catImg) {
                bObj.category_images[cloudCatId] = catImg;
                hasNewCatImg = true;
              }
            }
            if (hasNewCatImg) {
              await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
                method: 'PATCH',
                headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
                body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
              });
            }
          }
        }
      } catch(catImgErr) {
        console.warn('Sync category images error:', catImgErr);
      }

      // 2. Sync Items
      const localItems = (await DB.getAll('items')) || [];
      // Include items marked for online or all active items
      const itemsToSync = localItems.filter(i => i.status !== 'inactive');

      // Fetch existing cloud products to detect deleted/inactive items in POS
      let cloudExistingIds = [];
      try {
        let fromIdx = 0;
        let hasMore = true;
        while (hasMore) {
          const checkRes = await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=pos_product_id`, {
            headers: {
              ...getHeaders(cfg.key),
              'Range': `${fromIdx}-${fromIdx + 999}`
            }
          });
          if (checkRes.ok) {
            const batch = await checkRes.json();
            if (Array.isArray(batch) && batch.length > 0) {
              cloudExistingIds.push(...batch.map(p => p.pos_product_id).filter(Boolean));
              if (batch.length < 1000) hasMore = false;
              else fromIdx += 1000;
            } else {
              hasMore = false;
            }
          } else {
            hasMore = false;
          }
        }
      } catch (err) {
        console.warn('Could not query existing cloud products for delete sync:', err);
      }

      // Identify items that were deleted or deactivated in POS
      const localActivePosIds = new Set(itemsToSync.map(i => String(i.id)));
      const posIdsToDelete = cloudExistingIds.filter(id => !localActivePosIds.has(id));

      if (posIdsToDelete.length > 0) {
        try {
          const delChunkSize = 80;
          for (let i = 0; i < posIdsToDelete.length; i += delChunkSize) {
            const chunk = posIdsToDelete.slice(i, i + delChunkSize);
            const inQuery = chunk.map(id => encodeURIComponent(String(id).trim())).join(',');
            await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&pos_product_id=in.(${inQuery})`, {
              method: 'DELETE',
              headers: getHeaders(cfg.key)
            });
          }
        } catch (delErr) {
          console.warn('[OnlineOrders] Delete sync warning:', delErr);
        }
      }

      const cloudProducts = [];
      for (const item of itemsToSync) {
        // Resolve category UUID
        let matchedCatId = null;
        if (item.category_id) {
          const lCat = localCats.find(c => c.id === item.category_id);
          if (lCat) {
            const slug = (lCat.name_en || lCat.name || '').toLowerCase().replace(/[^a-z0-9]/g, '-');
            const foundCat = catMap.get(slug) || catMap.get((lCat.name || '').toLowerCase());
            if (foundCat) matchedCatId = String(foundCat);
          }
        }

        const isPublished = (typeof item.show_online !== 'undefined') ? Boolean(item.show_online) : true;
        const itemSellingPrice = parseFloat(item.selling_price) || parseFloat(item.price) || 0;
        const effectivePrice = itemSellingPrice > 0 ? itemSellingPrice : (parseFloat(item.online_price) || 0);

        // Strict PostgREST PGRST102 compliance: ALL objects in the array must have the EXACT SAME KEYS with zero undefined values!
        const prodRecord = {
          shop_id: String(shopId),
          pos_product_id: String(item.id),
          category_id: matchedCatId ? String(matchedCatId) : null,
          name: String(item.name_en || item.name_ar || item.name || 'Product'),
          name_ar: String(item.name_ar || item.name || ''),
          name_en: String(item.name_en || item.name || ''),
          description: String(item.item_code ? ('CODE:' + item.item_code) : (item.description || '')),
          barcode: item.barcode ? String(item.barcode).trim() : null,
          price: Number(effectivePrice) || 0,
          cost_price: Number(item.cost_price) || 0,
          stock_quantity: Math.max(0, parseInt(item.stock_qty, 10) || 0),
          track_inventory: true,
          is_published: isPublished === false ? false : true,
          is_featured: Boolean(item.is_featured),
          image_url: item.image_url || item.image || null,
          updated_at: new Date().toISOString()
        };

        // Guarantee all keys are defined (never undefined):
        for (const k of Object.keys(prodRecord)) {
          if (prodRecord[k] === undefined) prodRecord[k] = null;
        }

        cloudProducts.push(prodRecord);
      }

      if (cloudProducts.length > 0) {
        // Upload in fast, robust batches of 200 items with on_conflict upsert
        const chunkSize = 200;
        for (let i = 0; i < cloudProducts.length; i += chunkSize) {
          const chunk = cloudProducts.slice(i, i + chunkSize);
          const prodRes = await fetch(`${cfg.url}/rest/v1/products?on_conflict=shop_id,pos_product_id`, {
            method: 'POST',
            headers: { ...getHeaders(cfg.key), 'Prefer': 'resolution=merge-duplicates' },
            body: JSON.stringify(chunk)
          });

          if (!prodRes.ok) {
            const err = await prodRes.text();
            if (err.includes('23503') || err.includes('tenants')) {
              try { localStorage.removeItem('rs_resolved_shop_id_' + (cfg.slug || '').toLowerCase().trim()); } catch(e) {}
              _resolvedShopId = null;
              _resolvedShopSlug = '';
            }
            throw new Error(`Product sync error at item ${i}: ${err}`);
          }
        }
      }

      await broadcastCloudUpdate('items', isAR ? `مزامنة الكتالوج: ${cloudProducts.length} صنف` : `Catalog synced: ${cloudProducts.length} items`);
      await syncPosSalesToCloud();
      await syncCashboxStatusToCloud();
      await pullCloudStockUpdates();

      if (typeof Utils !== 'undefined' && Utils.toast) {
        const delMsg = posIdsToDelete.length > 0 ? (isAR ? ` وحذف ${posIdsToDelete.length}` : ` & removed ${posIdsToDelete.length}`) : '';
        Utils.toast(isAR ? `✅ تمت مزامنة ${cloudProducts.length} صنفاً بنجاح${delMsg}!` : `✅ Synced ${cloudProducts.length} items${delMsg}!`, 'success');
      }
    } catch (err) {
      console.error('[OnlineOrders] Sync catalog error:', err);
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(`⚠️ ${err.message}`, 'error');
      }
    }
  }

  // ── 6.5 Instant Single Product Cloud Sync (Real-time Price & Info Push) ────
  async function syncSingleProductToCloud(item) {
    if (!item) return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const itemSellingPrice = parseFloat(item.selling_price) || parseFloat(item.price) || 0;
      const effectivePrice = itemSellingPrice > 0 ? itemSellingPrice : (parseFloat(item.online_price) || 0);
      const isPublished = (typeof item.show_online !== 'undefined') ? Boolean(item.show_online) : true;

      // Resolve category UUID if possible
      let matchedCatId = null;
      if (item.category_id && typeof DB !== 'undefined') {
        try {
          const lCat = await DB.get('categories', item.category_id);
          if (lCat) {
            if (lCat.cloud_id) {
              matchedCatId = lCat.cloud_id;
            }
            const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=id,name,name_en,name_ar,slug`, { headers: getHeaders(cfg.key) });
            if (catRes.ok) {
              const cloudCats = await catRes.json();
              const norm = (str) => (str || '').trim().toLowerCase();
              const catSlug = (lCat.name_en || lCat.name || `cat-${lCat.id}`).toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
              let found = cloudCats.find(c => (c.slug && c.slug === catSlug) || norm(c.name) === norm(lCat.name) || norm(c.name_en) === norm(lCat.name_en) || norm(c.name_ar) === norm(lCat.name_ar));
              if (!found) {
                // If category does not exist in Supabase yet, create it on the fly
                const newCatPayload = {
                  shop_id: shopId,
                  name: lCat.name_en || lCat.name_ar || lCat.name,
                  name_ar: lCat.name_ar || lCat.name || '',
                  name_en: lCat.name_en || lCat.name || '',
                  slug: catSlug,
                  display_order: lCat.sort_order || 0,
                  is_active: true
                };
                const createRes = await fetch(`${cfg.url}/rest/v1/categories`, {
                  method: 'POST',
                  headers: { ...getHeaders(cfg.key), 'Prefer': 'return=representation' },
                  body: JSON.stringify(newCatPayload)
                });
                if (createRes.ok) {
                  const created = await createRes.json();
                  if (created && created[0]) found = created[0];
                }
              }
              if (found) {
                matchedCatId = found.id;
                if (!lCat.cloud_id || lCat.cloud_id !== found.id) {
                  lCat.cloud_id = found.id;
                  await DB.put('categories', lCat);
                }
              }
            }
          }
        } catch(e) {}
      }

      const payload = [{
        shop_id: String(shopId),
        pos_product_id: String(item.id),
        category_id: matchedCatId ? String(matchedCatId) : null,
        name: String(item.name_en || item.name_ar || item.name || 'Product'),
        name_ar: String(item.name_ar || item.name || ''),
        name_en: String(item.name_en || item.name || ''),
        description: String(item.item_code ? ('CODE:' + item.item_code) : (item.description || '')),
        barcode: item.barcode ? String(item.barcode).trim() : null,
        price: Number(effectivePrice) || 0,
        cost_price: Number(item.cost_price) || 0,
        stock_quantity: Math.max(0, parseInt(item.stock_qty, 10) || 0),
        track_inventory: true,
        is_published: isPublished === false ? false : true,
        is_featured: Boolean(item.is_featured),
        image_url: item.image_url || item.image || null,
        updated_at: new Date().toISOString()
      }];
      for (const k of Object.keys(payload[0])) {
        if (payload[0][k] === undefined) payload[0][k] = null;
      }

      const res = await fetch(`${cfg.url}/rest/v1/products?on_conflict=shop_id,pos_product_id`, {
        method: 'POST',
        headers: { ...getHeaders(cfg.key), 'Prefer': 'resolution=merge-duplicates,return=representation' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        console.log('[OnlineOrders] Instant product sync success for barcode:', item.barcode, 'price:', onlinePrice);
        broadcastCloudUpdate('items', item.name || item.barcode || 'Item updated');
      } else {
        const errText = await res.text();
        console.warn('[OnlineOrders] syncSingleProductToCloud error response:', errText);
      }
    } catch(err) {
      console.warn('[OnlineOrders] syncSingleProductToCloud error:', err);
    }
  }

  // ── 6.6 Instant Delete Product From Cloud With Tombstone Tracking ─────────
  async function deleteProductFromCloud(posProductId, itemBarcode = null) {
    if (!posProductId && !itemBarcode) return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      // 1. Delete matching product from Supabase products table
      if (posProductId) {
        await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&pos_product_id=eq.${encodeURIComponent(String(posProductId))}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }
      if (itemBarcode) {
        await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&barcode=eq.${encodeURIComponent(String(itemBarcode).trim())}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }
      console.log('[OnlineOrders] Deleted cloud product for POS ID:', posProductId, 'Barcode:', itemBarcode);

      // 2. Fetch tenant banner_url to record tombstone and broadcast to all branches
      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        if (tData && tData[0]) {
          let bObj = {};
          try {
            bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}

          let myNodeId = 'SRV-01';
          if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
            const sc = await BranchSync.getConfig();
            if (sc && sc.nodeId) myNodeId = sc.nodeId;
          }

          let deletedList = Array.isArray(bObj.pos_deleted_products) ? bObj.pos_deleted_products : [];
          // Keep tombstones from past 30 days
          const cutoff = Date.now() - (30 * 24 * 60 * 60 * 1000);
          deletedList = deletedList.filter(d => !d.deleted_at || new Date(d.deleted_at).getTime() > cutoff);

          const exists = deletedList.some(d => 
            (posProductId && String(d.id) === String(posProductId)) ||
            (itemBarcode && d.barcode && String(d.barcode).trim() === String(itemBarcode).trim())
          );
          if (!exists) {
            deletedList.push({
              id: posProductId || null,
              barcode: itemBarcode ? String(itemBarcode).trim() : null,
              deleted_at: new Date().toISOString()
            });
          }
          if (deletedList.length > 500) deletedList = deletedList.slice(-500);

          // Also purge any matching transfers from pos_cloud_tables.stock_transfers
          if (bObj.pos_cloud_tables && Array.isArray(bObj.pos_cloud_tables.stock_transfers)) {
            bObj.pos_cloud_tables.stock_transfers = bObj.pos_cloud_tables.stock_transfers.filter(tr => {
              if (posProductId && String(tr.item_id) === String(posProductId)) return false;
              if (itemBarcode && tr.barcode && String(tr.barcode).trim() === String(itemBarcode).trim()) return false;
              return true;
            });
          }

          bObj.pos_deleted_products = deletedList;
          bObj.cloud_sync_seq = Date.now();
          bObj.last_change_type = 'items_deleted';
          bObj.last_change_desc = `Deleted item ${itemBarcode || posProductId}`;
          bObj.last_change_by = myNodeId;
          bObj.last_change_time = new Date().toISOString();

          await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
            method: 'PATCH',
            headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
            body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
          });
          console.log('[OnlineOrders] Broadcasted deletion tombstone to cloud banner_url seq:', bObj.cloud_sync_seq);
        }
      }

    } catch(e) {
      console.warn('[OnlineOrders] deleteProductFromCloud error:', e);
    }
  }

  // ── 6.6b Instant Delete Category From Cloud ────────────────────────────────
  async function deleteCategoryFromCloud(catId, catName = null) {
    if (!catId && !catName) return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      if (catId) {
        await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&id=eq.${encodeURIComponent(String(catId))}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }
      if (catName) {
        await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&name=eq.${encodeURIComponent(String(catName).trim())}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        if (tData && tData[0]) {
          let bObj = {};
          try {
            bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}

          let myNodeId = 'SRV-01';
          if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
            const sc = await BranchSync.getConfig();
            if (sc && sc.nodeId) myNodeId = sc.nodeId;
          }

          let deletedCats = Array.isArray(bObj.pos_deleted_categories) ? bObj.pos_deleted_categories : [];
          deletedCats.push({
            id: catId || null,
            name: catName || null,
            deleted_at: new Date().toISOString()
          });
          if (deletedCats.length > 200) deletedCats = deletedCats.slice(-200);

          bObj.pos_deleted_categories = deletedCats;
          bObj.cloud_sync_seq = Date.now();
          bObj.last_change_type = 'categories_deleted';
          bObj.last_change_desc = `Deleted category ${catName || catId}`;
          bObj.last_change_by = myNodeId;
          bObj.last_change_time = new Date().toISOString();

          await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
            method: 'PATCH',
            headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
            body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
          });
        }
      }
    } catch(e) {
      console.warn('[OnlineOrders] deleteCategoryFromCloud error:', e);
    }
  }

  // ── 6.6c Apply Deleted Products from Cloud (Branch Side) ────────────────────
  async function applyDeletedProducts(bObj = null) {
    if (typeof DB === 'undefined') return { success: false, count: 0 };
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      if (syncCfg.role === 'server') {
        return { success: true, count: 0, skipped: 'server_is_master' };
      }

      let bannerData = bObj;
      if (!bannerData || !bannerData.pos_deleted_products) {
        const cfg = await getConfig();
        const shopId = await resolveShopId(cfg);
        if (!shopId) return { success: false, count: 0 };
        const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key),
          signal: AbortSignal.timeout(6000)
        });
        if (!tRes.ok) return { success: false, count: 0 };
        const tData = await tRes.json();
        if (tData && tData[0]) {
          try {
            bannerData = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}
        }
      }

      const deletedList = bannerData?.pos_deleted_products;
      if (!Array.isArray(deletedList) || deletedList.length === 0) {
        return { success: true, count: 0 };
      }

      const localItems = (await DB.getAll('items')) || [];
      if (localItems.length === 0) return { success: true, count: 0 };

      const deletedIds = new Set();
      const deletedBarcodes = new Set();
      for (const d of deletedList) {
        if (d.id != null) deletedIds.add(String(d.id));
        if (d.barcode) deletedBarcodes.add(String(d.barcode).trim());
      }

      const itemsToRemove = [];
      for (const itm of localItems) {
        const idStr = String(itm.id);
        const barcodeStr = itm.barcode ? String(itm.barcode).trim() : null;
        if (deletedIds.has(idStr) || (barcodeStr && deletedBarcodes.has(barcodeStr))) {
          itemsToRemove.push(itm);
        }
      }

      if (itemsToRemove.length === 0) {
        return { success: true, count: 0 };
      }

      console.log(`[OnlineOrders] Removing ${itemsToRemove.length} deleted items from branch local database...`);

      // 1. Delete from local IndexedDB
      try {
        const rawDb = await DB.getDB();
        const tx = rawDb.transaction('items', 'readwrite');
        const store = tx.objectStore('items');
        for (const itm of itemsToRemove) {
          store.delete(itm.id);
          if (typeof itm.id === 'string' && !isNaN(Number(itm.id))) {
            try { store.delete(Number(itm.id)); } catch(e){}
          }
        }
        await new Promise((resolve, reject) => {
          tx.oncomplete = resolve;
          tx.onerror = () => reject(tx.error);
          tx.onabort = () => reject(tx.error);
        });
      } catch(dbErr) {
        console.warn('[OnlineOrders] Direct store delete error:', dbErr);
        for (const itm of itemsToRemove) {
          try { await DB.remove('items', itm.id); } catch(e){}
        }
      }

      // 2. Delete from branch local backend (localhost:3000 db.dat)
      for (const itm of itemsToRemove) {
        try {
          if (typeof DB.callApi === 'function') {
            await DB.callApi(`/api/db/items/${itm.id}`, { method: 'DELETE' });
          }
        } catch(e) {}
      }

      // 3. Dispatch sync complete and refresh views
      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', {
          detail: { table: 'items', deleted: true, count: itemsToRemove.length }
        }));
      }

      if (window.POS && typeof POS.refreshCatalog === 'function') {
        try { await POS.refreshCatalog(); } catch(e) {}
      }

      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
      if (bObj?._manual && typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? `🗑️ تم إزالة ${itemsToRemove.length} صنف تم حذفه من السيرفر!` : `🗑️ Removed ${itemsToRemove.length} deleted item(s) from server!`, 'info', 3000);
      }

      return { success: true, count: itemsToRemove.length };
    } catch(err) {
      console.warn('[OnlineOrders] applyDeletedProducts error:', err);
      return { success: false, error: err.message, count: 0 };
    }
  }

  // ── 6.6d Apply Deleted Categories from Cloud (Branch Side) ──────────────────
  async function applyDeletedCategories(bObj = null) {
    if (typeof DB === 'undefined') return { success: false, count: 0 };
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      if (syncCfg.role === 'server') return { success: true, count: 0, skipped: 'server_is_master' };

      const deletedCats = bObj?.pos_deleted_categories;
      if (!Array.isArray(deletedCats) || deletedCats.length === 0) return { success: true, count: 0 };

      const localCats = (await DB.getAll('categories')) || [];
      if (localCats.length === 0) return { success: true, count: 0 };

      const delIds = new Set(deletedCats.map(c => c.id != null ? String(c.id) : null).filter(Boolean));
      const delNames = new Set(deletedCats.map(c => c.name ? String(c.name).trim().toLowerCase() : null).filter(Boolean));

      const catsToRemove = [];
      for (const c of localCats) {
        const idStr = String(c.id);
        const cloudIdStr = c.cloud_id ? String(c.cloud_id) : null;
        const normName = (c.name || c.name_en || c.name_ar || '').trim().toLowerCase();
        if (delIds.has(idStr) || (cloudIdStr && delIds.has(cloudIdStr)) || (normName && delNames.has(normName))) {
          catsToRemove.push(c);
        }
      }

      if (catsToRemove.length === 0) return { success: true, count: 0 };

      try {
        const rawDb = await DB.getDB();
        const tx = rawDb.transaction('categories', 'readwrite');
        const store = tx.objectStore('categories');
        for (const c of catsToRemove) {
          store.delete(c.id);
        }
        await new Promise((res, rej) => {
          tx.oncomplete = res;
          tx.onerror = () => rej(tx.error);
          tx.onabort = () => rej(tx.error);
        });
      } catch(e) {}

      for (const c of catsToRemove) {
        try {
          if (typeof DB.callApi === 'function') {
            await DB.callApi(`/api/db/categories/${c.id}`, { method: 'DELETE' });
          }
        } catch(e) {}
      }

      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', {
          detail: { table: 'categories', deleted: true, count: catsToRemove.length }
        }));
      }

      return { success: true, count: catsToRemove.length };
    } catch(err) {
      console.warn('[OnlineOrders] applyDeletedCategories error:', err);
      return { success: false, count: 0 };
    }
  }

  // ── 6.7 Instant Real-Time Cloud Update Broadcaster ─────────────────────────
  async function broadcastCloudUpdate(changeType = 'items', changeDesc = '') {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tRes.ok) return;
      const tData = await tRes.json();
      if (!tData || !tData[0]) return;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      let myNodeId = 'SRV-01';
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        const sc = await BranchSync.getConfig();
        if (sc && sc.nodeId) myNodeId = sc.nodeId;
      }

      bObj.cloud_sync_seq = Date.now();
      bObj.last_change_type = changeType;
      bObj.last_change_desc = changeDesc;
      bObj.last_change_by = myNodeId;
      bObj.last_change_time = new Date().toISOString();

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
      localStorage.setItem('rs_cloud_sync_seq', String(bObj.cloud_sync_seq));
      if (window.BranchSync && typeof BranchSync.setLastSeenSeq === 'function') {
        BranchSync.setLastSeenSeq(bObj.cloud_sync_seq);
      }
      console.log(`[OnlineOrders] Broadcasted cloud update seq ${bObj.cloud_sync_seq} (${changeType}): ${changeDesc}`);
    } catch(err) {
      console.warn('[OnlineOrders] broadcastCloudUpdate error:', err);
    }
  }

  // ── 6.8 Sync Supporting Tables to Cloud (Units, Warehouses, Offers, Suppliers, Stock Transfers) ──
  async function syncCloudTables(allowedTables = null) {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      const isServer = !syncCfg.role || syncCfg.role === 'server';
      const myBranchId = (syncCfg.branchId || syncCfg.nodeId || '').trim().toLowerCase();
      const myNodeName = (syncCfg.nodeName || '').trim().toLowerCase();

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(6000)
      });
      if (!tRes.ok) return;
      const tData = await tRes.json();
      if (!tData || !tData[0]) return;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      const existingCloudTables = (bObj.pos_cloud_tables && typeof bObj.pos_cloud_tables === 'object') ? bObj.pos_cloud_tables : {};
      const tablePayload = { ...existingCloudTables };

      // 1. Merge units, offers, suppliers (Server is authoritative for catalog tables)
      if (isServer) {
        for (const t of ['units', 'offers', 'suppliers']) {
          try {
            const records = await DB.getAll(t);
            if (records && Array.isArray(records)) {
              tablePayload[t] = records;
            }
          } catch(e) {}
        }
      }

      // 2. Publish Warehouses (Server is authoritative; does not resurrect deleted stores)
      const allWarehouses = (await DB.getAll('warehouses')) || [];
      const isMainWh = (w) => {
        const c = (w?.code || '').trim().toUpperCase();
        const n = (w?.name || '').trim().toLowerCase();
        const nar = (w?.name_ar || '').trim();
        return !!(w?.is_default || w?.id === 1 || c === 'WH-01' || n.includes('main') || nar.includes('رئيسي') || n.includes('kobayath'));
      };
      try {
        if (isServer) {
          // Server is single source of truth: directly publish current warehouses so deletions are immediate
          tablePayload['warehouses'] = allWarehouses.map(w => ({ ...w, is_default: isMainWh(w) }));
        } else {
          // Branch node: NEVER overwrite or merge warehouses! Server is sole authority.
          if (Array.isArray(existingCloudTables.warehouses)) {
            tablePayload['warehouses'] = existingCloudTables.warehouses;
          }
        }
      } catch(e) {}

      // 3. Merge Stock Transfers by ref (so Branch never wipes out Server transfers & vice versa)
      try {
        const localTransfers = (await DB.getAll('stock_transfers')) || [];
        const prevTransfers = Array.isArray(existingCloudTables.stock_transfers) ? existingCloudTables.stock_transfers : [];
        const trfMap = new Map();
        for (const ct of prevTransfers) {
          if (ct && ct.ref) trfMap.set(String(ct.ref).trim(), { ...ct });
        }
        for (const lt of localTransfers) {
          if (lt && lt.ref) {
            const refKey = String(lt.ref).trim();
            const existingTrf = trfMap.get(refKey) || {};
            trfMap.set(refKey, {
              ...existingTrf,
              ...lt,
              applied_to_branch_stock: Boolean(existingTrf.applied_to_branch_stock || lt.applied_to_branch_stock)
            });
          }
        }
        tablePayload['stock_transfers'] = Array.from(trfMap.values());
      } catch(e) {}

      // 4. Identify this station's warehouse ID(s) so each station only publishes its own authoritative stock
      let myStationWh = null;
      const myStationWhIds = new Set();
      if (isServer) {
        myStationWh = allWarehouses.find(w => isMainWh(w)) || allWarehouses.find(w => w.is_default) || allWarehouses[0];
        myStationWhIds.add('1');
        if (myStationWh && myStationWh.id != null) myStationWhIds.add(String(myStationWh.id));
        const cloudWhList = Array.isArray(tablePayload['warehouses']) ? tablePayload['warehouses'] : [];
        for (const cw of cloudWhList) {
          if (cw && cw.id != null && isMainWh(cw)) myStationWhIds.add(String(cw.id));
        }
      } else {
        if (typeof window !== 'undefined' && window._posWarehouseId) {
          myStationWh = allWarehouses.find(w => String(w.id) === String(window._posWarehouseId));
        }
        if (!myStationWh) {
          myStationWh = allWarehouses.find(w => {
            const c = (w.code || '').trim().toLowerCase();
            const n = (w.name || w.name_ar || '').trim().toLowerCase();
            return (c && (c === myBranchId || c === myNodeName)) || (n && (n === myBranchId || n === myNodeName));
          }) || allWarehouses.find(w => !isMainWh(w)) || allWarehouses[0];
        }
        if (myStationWh && myStationWh.id != null && !isMainWh(myStationWh)) {
          myStationWhIds.add(String(myStationWh.id));
        }
        if (typeof window !== 'undefined' && window._posWarehouseId && String(window._posWarehouseId) !== '1') {
          myStationWhIds.add(String(window._posWarehouseId));
        }
        const cloudWhList = Array.isArray(tablePayload['warehouses']) ? tablePayload['warehouses'] : [];
        for (const cw of cloudWhList) {
          if (!cw || cw.id == null || isMainWh(cw)) continue;
          const c = (cw.code || '').trim().toLowerCase();
          const n = (cw.name || cw.name_ar || '').trim().toLowerCase();
          if ((c && (c === myBranchId || c === myNodeName)) || (n && (n === myBranchId || n === myNodeName))) {
            myStationWhIds.add(String(cw.id));
          }
        }
      }

      // Collect destination warehouse IDs of any pending unapplied transfers so Server immediately publishes transfer destination stock
      const pendingDestWhIds = new Set();
      if (isServer && Array.isArray(tablePayload['stock_transfers'])) {
        for (const trf of tablePayload['stock_transfers']) {
          if (trf && !trf.applied_to_branch_stock && trf.to_wh_id != null) {
            pendingDestWhIds.add(String(trf.to_wh_id));
          }
        }
      }

      // 5. Keep supporting tables payload compact and lightweight (under 5KB)
      // Never serialize massive items stock map into banner_url!
      delete tablePayload['_warehouse_stocks'];
      if (Array.isArray(tablePayload['stock_transfers'])) {
        // Retain only the most recent 30 stock transfers to keep cloud payload minimal
        tablePayload['stock_transfers'] = tablePayload['stock_transfers'].slice(-30);
      }

      bObj.pos_cloud_tables = tablePayload;
      bObj.tables_updated_at = new Date().toISOString();
      bObj.cloud_sync_seq = Date.now();
      bObj.last_change_type = 'tables';
      bObj.last_change_desc = 'Warehouses, Stock Transfers & Stock updated';
      bObj.last_change_by = (syncCfg.nodeId || 'SRV-01');
      bObj.last_change_time = new Date().toISOString();

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
      localStorage.setItem('rs_cloud_sync_seq', String(bObj.cloud_sync_seq));
      localStorage.setItem('rs_cloud_tables_updated_at', bObj.tables_updated_at);
      if (window.BranchSync && typeof BranchSync.setLastSeenSeq === 'function') {
        BranchSync.setLastSeenSeq(bObj.cloud_sync_seq);
      }
      console.log('[OnlineOrders] Synced supporting tables & warehouse stocks to cloud:', Object.keys(tablePayload));
    } catch(err) {
      console.warn('[OnlineOrders] syncCloudTables error:', err);
    }
  }

  // ── 6.9 Pull Supporting Tables from Cloud (Units, Warehouses, Offers, Suppliers, Stock Transfers) ──
  async function pullCloudTables(bObj = null) {
    if (typeof DB === 'undefined') return;
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      const isServer = !syncCfg.role || syncCfg.role === 'server';
      const cfg = await getConfig();

      let bannerData = (bObj && bObj.pos_cloud_tables) ? bObj : null;
      if (!bannerData || !bannerData.pos_cloud_tables) {
        const shopId = await resolveShopId(cfg);
        if (!shopId) return;
        const res = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key),
          signal: AbortSignal.timeout(6000)
        });
        if (!res.ok) return;
        const tData = await res.json();
        if (!tData || !tData[0]) return;
        try {
          bannerData = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
        } catch(e) {}
      }

      const cloudTables = bannerData?.pos_cloud_tables;
      if (!cloudTables || typeof cloudTables !== 'object') return;

      const allowedTables = ['units', 'warehouses', 'offers', 'suppliers', 'stock_transfers'];
      let tablesUpdated = false;

      const isMainWh = (w) => {
        if (!w) return false;
        const c = (w.code || '').trim().toUpperCase();
        const n = (w.name || '').trim().toLowerCase();
        const nar = (w.name_ar || '').trim();
        return w.id === 1 || c === 'WH-01' || n.includes('main') || nar.includes('رئيسي');
      };

      // 1. Pull Warehouses (Server is authoritative source; branch mirrors server warehouses and cleans deleted ones)
      if (cloudTables.warehouses && Array.isArray(cloudTables.warehouses) && !isServer) {
        try {
          const cloudCodes = new Set(cloudTables.warehouses.map(cw => (cw.code ? String(cw.code).trim().toLowerCase() : '')).filter(Boolean));
          const cloudIds = new Set(cloudTables.warehouses.map(cw => String(cw.id)).filter(Boolean));
          const localWh = (await DB.getAll('warehouses')) || [];
          const localByCode = new Map();
          const localById = new Set();
          localWh.forEach(w => {
            if (w.code) localByCode.set(String(w.code).trim().toLowerCase(), w);
            if (w.id != null) localById.add(String(w.id));
          });

          // 1a. Upsert from Cloud on Branch
          for (const cw of cloudTables.warehouses) {
            const code = (cw.code ? String(cw.code).trim().toLowerCase() : '');
            const match = code ? localByCode.get(code) : null;
            const shouldBeDefault = isMainWh(cw);
            if (match) {
              const updatedWh = { ...match, ...cw, id: match.id, is_default: shouldBeDefault };
              if (match.name !== updatedWh.name || match.name_ar !== updatedWh.name_ar || match.is_default !== updatedWh.is_default) {
                await DB.put('warehouses', updatedWh);
                tablesUpdated = true;
              }
            } else {
              const copy = { ...cw, is_default: shouldBeDefault };
              if (cw.id != null && !localById.has(String(cw.id))) {
                await DB.put('warehouses', copy);
                localById.add(String(cw.id));
              } else {
                delete copy.id;
                await DB.add('warehouses', copy);
              }
              localByCode.set(code, copy);
              tablesUpdated = true;
            }
          }

          // 1b. Delete obsolete local warehouses that were deleted on Server
          for (const lw of localWh) {
            const lCode = lw.code ? String(lw.code).trim().toLowerCase() : '';
            const lId = lw.id != null ? String(lw.id) : '';
            if (lCode && !cloudCodes.has(lCode) && (!lId || !cloudIds.has(lId))) {
              try {
                if (typeof DB.remove === 'function') await DB.remove('warehouses', lw.id);
                else if (typeof DB.delete === 'function') await DB.delete('warehouses', lw.id);
                tablesUpdated = true;
              } catch(delErr) {}
            }
          }
        } catch(whErr) {
          console.warn('[OnlineOrders] pullCloudTables warehouses error:', whErr);
        }
      }

      // 2. Identify this node's warehouse and Main Warehouse
      const allWarehouses = (await DB.getAll('warehouses')) || [];
      const myBranchId = (syncCfg.branchId || syncCfg.nodeId || '').trim().toLowerCase();
      const myNodeName = (syncCfg.nodeName || '').trim().toLowerCase();
      const mainWh = allWarehouses.find(w => isMainWh(w)) || allWarehouses.find(w => w.is_default) || allWarehouses[0] || null;

      let myWh = null;
      let myCloudWhId = null;
      if (!isServer) {
        myWh = allWarehouses.find(w => {
          const c = (w.code || '').trim().toLowerCase();
          return c && (c === myBranchId || c === myNodeName);
        });
        if (!myWh) {
          myWh = allWarehouses.find(w => {
            const n = (w.name || w.name_ar || '').trim().toLowerCase();
            return (n && (n === myBranchId || n === myNodeName));
          });
        }
        if (!myWh) {
          myWh = allWarehouses.find(w => {
            const c = (w.code || '').trim().toLowerCase();
            const n = (w.name || w.name_ar || '').trim().toLowerCase();
            return (c && (myBranchId.includes(c) || c.includes(myBranchId) || myNodeName.includes(c) || c.includes(myNodeName))) ||
                   (n && (myNodeName.includes(n) || n.includes(myBranchId) || myBranchId.includes(n)));
          });
        }
        if (!myWh && allWarehouses.length > 1) {
          myWh = allWarehouses.find(w => !isMainWh(w));
        }
        if (!myWh && allWarehouses.length > 0) {
          myWh = allWarehouses[allWarehouses.length - 1];
        }
        if (Array.isArray(cloudTables.warehouses)) {
          const matchedCloudWh = cloudTables.warehouses.find(cw => {
            if (!cw || isMainWh(cw)) return false;
            const c = (cw.code || '').trim().toLowerCase();
            const n = (cw.name || cw.name_ar || '').trim().toLowerCase();
            return (c && (c === myBranchId || c === myNodeName)) || (n && (n === myBranchId || n === myNodeName));
          }) || cloudTables.warehouses.find(cw => cw && !isMainWh(cw));
          if (matchedCloudWh && matchedCloudWh.id != null) {
            myCloudWhId = matchedCloudWh.id;
          }
        }
        if (myWh) {
          if (typeof window !== 'undefined') window._posWarehouseId = myWh.id;
          try { await DB.setSetting('pos_warehouse_id', myWh.id); } catch(e){}
        }
      } else if (mainWh) {
        if (typeof window !== 'undefined') window._activeStationWhId = mainWh.id;
      }

      const appliedStorageKey = `rs_applied_trf_${(cfg.slug || 'default').toLowerCase()}_${isServer ? 'server' : (myBranchId || 'branch')}`;
      let appliedRefs = new Set();
      try {
        const rawApplied = JSON.parse(localStorage.getItem(appliedStorageKey) || '[]');
        if (Array.isArray(rawApplied)) appliedRefs = new Set(rawApplied);
      } catch(e) {}

      // 3. Pull Stock Transfers (Merge by ref so neither side loses inter-branch transfers!)
      if (cloudTables.stock_transfers && Array.isArray(cloudTables.stock_transfers) && allowedTables.includes('stock_transfers')) {
        try {
          const localTransfers = (await DB.getAll('stock_transfers')) || [];
          const localByRef = new Map();
          localTransfers.forEach(t => {
            if (t && t.ref) localByRef.set(String(t.ref).trim(), t);
          });
          for (const ct of cloudTables.stock_transfers) {
            if (!ct || !ct.ref) continue;
            const refKey = String(ct.ref).trim();
            const existingLocal = localByRef.get(refKey);
            if (!existingLocal) {
              const copy = { ...ct };
              delete copy.id;
              if (!isServer && copy.applied_to_branch_stock) {
                appliedRefs.add(refKey);
              }
              await DB.add('stock_transfers', copy);
              localByRef.set(refKey, copy);
              tablesUpdated = true;
            } else {
              if (ct.applied_to_branch_stock && !existingLocal.applied_to_branch_stock) {
                existingLocal.applied_to_branch_stock = true;
                await DB.put('stock_transfers', existingLocal);
                if (!isServer) appliedRefs.add(refKey);
              } else if (!isServer && !ct.applied_to_branch_stock && existingLocal.applied_to_branch_stock && !appliedRefs.has(refKey) && ct.source_node_id !== syncCfg.nodeId) {
                // Recovery: if a previous build marked local transfer applied before reverting stock, allow Step 5 to apply it once
                existingLocal.applied_to_branch_stock = false;
                await DB.put('stock_transfers', existingLocal);
              }
            }
          }
        } catch(trfErr) {
          console.warn('[OnlineOrders] pullCloudTables transfers error:', trfErr);
        }
      }

      // 4. Pull Warehouse Stocks per item (preserve each station's own local stock & only write if changed!)
      const whStocks = cloudTables._warehouse_stocks || bannerData.pos_warehouse_stocks;
      if (whStocks && typeof whStocks === 'object') {
        try {
          const localItems = (await DB.getAll('items')) || [];
          const byBarcode = new Map();
          const byId = new Map();
          const byName = new Map();
          localItems.forEach(i => {
            if (i.barcode) byBarcode.set('barcode::' + String(i.barcode).trim(), i);
            if (i.id != null) byId.set('id::' + i.id, i);
            if (i.name) byName.set('name::' + String(i.name).trim().toLowerCase(), i);
            if (i.name_ar) byName.set('name::' + String(i.name_ar).trim().toLowerCase(), i);
            if (i.name_en) byName.set('name::' + String(i.name_en).trim().toLowerCase(), i);
          });

          const processedItemIds = new Set();
          for (const [k, stocks] of Object.entries(whStocks)) {
            const matched = byBarcode.get(k) || byId.get(k) || byName.get(k);
            if (!matched || matched.id == null || processedItemIds.has(matched.id)) continue;
            if (!stocks || typeof stocks !== 'object') continue;
            processedItemIds.add(matched.id);

            // Re-read live item from IndexedDB so we NEVER overwrite a concurrent user edit or transfer
            const itm = (await DB.get('items', matched.id)) || matched;
            const localQty = (itm.stock_qty !== undefined && itm.stock_qty !== null)
              ? (parseFloat(itm.stock_qty) || 0)
              : (itm.stock !== undefined && itm.stock !== null ? (parseFloat(itm.stock) || 0) : 0);

            const prevWhJson = JSON.stringify(itm.warehouse_stocks || {});
            const mergedWh = {};

            // Copy numeric warehouse IDs from remote first, then overlay local
            for (const [wk, wv] of Object.entries(stocks)) {
              if (/^\d+$/.test(String(wk))) mergedWh[wk] = parseFloat(wv) || 0;
            }
            if (itm.warehouse_stocks && typeof itm.warehouse_stocks === 'object') {
              for (const [wk, wv] of Object.entries(itm.warehouse_stocks)) {
                if (/^\d+$/.test(String(wk)) && mergedWh[wk] === undefined) {
                  mergedWh[wk] = parseFloat(wv) || 0;
                }
              }
            }

            // For branch station: adopt authoritative warehouse stock from cloud if local stock is 0 or less than transferred
            if (!isServer) {
              const myWhKey = myWh && myWh.id != null ? String(myWh.id) : (myCloudWhId ? String(myCloudWhId) : null);
              const cloudWhQty = (myWhKey && stocks && stocks[myWhKey] !== undefined)
                ? (parseFloat(stocks[myWhKey]) || 0)
                : null;

              let effectiveStock = localQty;
              if (cloudWhQty !== null && (localQty === 0 || cloudWhQty > localQty)) {
                effectiveStock = cloudWhQty;
              }

              itm.stock_qty = effectiveStock;
              itm.stock = effectiveStock;
              mergedWh['1'] = effectiveStock;
              if (myWhKey) mergedWh[myWhKey] = effectiveStock;
              if (myCloudWhId != null) mergedWh[String(myCloudWhId)] = effectiveStock;
              if (typeof window !== 'undefined' && window._posWarehouseId) {
                mergedWh[String(window._posWarehouseId)] = effectiveStock;
              }
            } else {
              itm.stock_qty = localQty;
              itm.stock = localQty;
              mergedWh['1'] = localQty;
              if (mainWh && mainWh.id != null) mergedWh[String(mainWh.id)] = localQty;
            }

            itm.warehouse_stocks = mergedWh;
            const newWhJson = JSON.stringify(mergedWh);
            if (prevWhJson !== newWhJson) {
              await DB.put('items', itm);
            }
          }
        } catch(stkErr) {
          console.warn('[OnlineOrders] pullCloudTables whStocks error:', stkErr);
        }
      }

      // 5. Automatic Transfer Reconciliation: ensure branch (and server for branch->server transfers) receives stock
      let transferApplied = false;
      try {
        const allTransfers = (await DB.getAll('stock_transfers')) || [];
        if (allTransfers.length > 0) {
          const myWhId = isServer ? (mainWh ? mainWh.id : 1) : (myWh ? myWh.id : myCloudWhId);
          const myWhCode = isServer ? (mainWh ? (mainWh.code || '').trim().toLowerCase() : 'wh-01') : (myWh ? (myWh.code || '').trim().toLowerCase() : '');
          const myWhName = isServer ? (mainWh ? (mainWh.name || mainWh.name_ar || '').trim().toLowerCase() : 'main') : (myWh ? (myWh.name || myWh.name_ar || '').trim().toLowerCase() : '');

          // Collect tombstones so deleted items are NEVER updated or resurrected
          const tombstoneIds = new Set();
          const tombstoneBarcodes = new Set();
          const bDel = bannerData?.pos_deleted_products;
          if (Array.isArray(bDel)) {
            for (const d of bDel) {
              if (d.id != null) tombstoneIds.add(String(d.id));
              if (d.barcode) tombstoneBarcodes.add(String(d.barcode).trim());
            }
          }

          const localItems = (await DB.getAll('items')) || [];
          const byBarcode = new Map();
          const byCode = new Map();
          const byName = new Map();
          const byId = new Map();
          localItems.forEach(i => {
            if (i.barcode) byBarcode.set(String(i.barcode).trim(), i);
            if (i.item_code) byCode.set(String(i.item_code).trim().toLowerCase(), i);
            if (i.name) byName.set(String(i.name).trim().toLowerCase(), i);
            if (i.name_en) byName.set(String(i.name_en).trim().toLowerCase(), i);
            if (i.name_ar) byName.set(String(i.name_ar).trim().toLowerCase(), i);
            if (i.id != null) byId.set(String(i.id), i);
          });

          const isWhMain = (wId, wName, wCode) => {
            const c = (wCode || '').trim().toUpperCase();
            const n = (wName || '').trim().toLowerCase();
            return c === 'WH-01' || n.includes('main') || n.includes('رئيسي') || (mainWh && String(wId) === String(mainWh.id)) || (!mainWh && wId == 1);
          };

          for (const t of allTransfers) {
            if (!t || !t.ref) continue;
            if (appliedRefs.has(t.ref)) continue;

            const toName = (t.to_wh_name || '').trim().toLowerCase();
            const fromName = (t.from_wh_name || '').trim().toLowerCase();
            const toCode = (t.to_wh_code || '').trim().toLowerCase();
            const fromCode = (t.from_wh_code || '').trim().toLowerCase();

            let isToMe = false;
            let isFromMe = false;

            if (isServer) {
              // On Server: transfers created on the Server were already applied in saveTransfer().
              // Only apply if a remote Branch initiated a transfer TO or FROM the Main Warehouse.
              if (t.applied_on_source || !t.source_node_id || t.source_node_id === (syncCfg.nodeId || 'SRV-01')) {
                appliedRefs.add(t.ref);
                continue;
              }
              isToMe = isWhMain(t.to_wh_id, toName, toCode);
              isFromMe = isWhMain(t.from_wh_id, fromName, fromCode);
            } else {
              // On Branch: check if this transfer was already applied locally
              if (t.applied_to_branch_stock && appliedRefs.has(t.ref)) {
                continue;
              }
              const destIsMain = isWhMain(t.to_wh_id, toName, toCode);
              const srcIsMain = isWhMain(t.from_wh_id, fromName, fromCode);
              isToMe = !destIsMain && (
                (myWhId && String(t.to_wh_id) === String(myWhId)) ||
                (myCloudWhId && String(t.to_wh_id) === String(myCloudWhId)) ||
                (myWhCode && (toCode === myWhCode || toName.includes(myWhCode))) ||
                (myWhName && (toName.includes(myWhName) || myWhName.includes(toName))) ||
                (myBranchId && toName.includes(myBranchId)) ||
                (myNodeName && toName.includes(myNodeName)) ||
                allWarehouses.length <= 2 ||
                srcIsMain
              );
              isFromMe = !srcIsMain && (
                (myWhId && String(t.from_wh_id) === String(myWhId)) ||
                (myCloudWhId && String(t.from_wh_id) === String(myCloudWhId)) ||
                (myWhCode && (fromCode === myWhCode || fromName.includes(myWhCode))) ||
                (myWhName && (fromName.includes(myWhName) || myWhName.includes(fromName))) ||
                (myBranchId && fromName.includes(myBranchId)) ||
                (myNodeName && fromName.includes(myNodeName))
              );
            }

            if (!isToMe && !isFromMe) continue;

            // Match item by Barcode -> Item Name -> Item Code -> Item ID
            const tBc = t.barcode ? String(t.barcode).trim() : '';
            const tCode = t.item_code ? String(t.item_code).trim().toLowerCase() : '';
            const tName = (t.item_name || '').trim().toLowerCase();
            const tNameEn = (t.item_name_en || '').trim().toLowerCase();
            const tNameAr = (t.item_name_ar || '').trim().toLowerCase();

            let matchedItm = (tBc && byBarcode.get(tBc))
              || (tName && byName.get(tName))
              || (tNameEn && byName.get(tNameEn))
              || (tNameAr && byName.get(tNameAr))
              || (tCode && byCode.get(tCode))
              || (t.item_id != null && byId.get(String(t.item_id)))
              || null;

            // Check if item was explicitly deleted (tombstone) before auto-creating
            const tIdStr = (t.item_id != null) ? String(t.item_id) : '';
            let localDeleted = [];
            try { localDeleted = JSON.parse(localStorage.getItem('rs_branch_deleted_items') || '[]'); } catch(e) {}
            const localDelIds = new Set(localDeleted.map(d => d.id != null ? String(d.id) : '').filter(Boolean));
            const localDelBc = new Set(localDeleted.map(d => d.barcode ? String(d.barcode).trim() : '').filter(Boolean));
            if ((tIdStr && (tombstoneIds.has(tIdStr) || localDelIds.has(tIdStr))) || 
                (tBc && (tombstoneBarcodes.has(tBc) || localDelBc.has(tBc)))) {
              continue; // Item was deleted by user! NEVER resurrect it from transfer history!
            }

            // Do NOT auto-create ghost items from transfers if they do not exist in official catalog
            if (!matchedItm && !isServer && isToMe) {
              continue; // Skip transfer line if item was not found in catalog or was deleted
            }

            if (matchedItm) {
              if (matchedItm.id != null && tombstoneIds.has(String(matchedItm.id))) continue;
              if (matchedItm.barcode && tombstoneBarcodes.has(String(matchedItm.barcode).trim())) continue;

              const trfQty = parseFloat(t.qty) || 0;
              if (trfQty > 0) {
                const liveItm = (await DB.get('items', matchedItm.id)) || matchedItm;
                const currentStock = (liveItm.stock_qty !== undefined && liveItm.stock_qty !== null)
                  ? (parseFloat(liveItm.stock_qty) || 0)
                  : (parseFloat(liveItm.stock) || 0);
                const newStock = isToMe ? (currentStock + trfQty) : Math.max(0, currentStock - trfQty);
                liveItm.stock_qty = newStock;
                liveItm.stock = newStock;
                liveItm.updated_at = new Date().toISOString();
                if (!liveItm.warehouse_stocks || typeof liveItm.warehouse_stocks !== 'object') {
                  liveItm.warehouse_stocks = {};
                }
                liveItm.warehouse_stocks['1'] = newStock;
                if (myWhId != null) liveItm.warehouse_stocks[String(myWhId)] = newStock;
                if (myCloudWhId != null) liveItm.warehouse_stocks[String(myCloudWhId)] = newStock;
                if (isToMe && t.to_wh_id != null) liveItm.warehouse_stocks[String(t.to_wh_id)] = newStock;
                if (typeof window !== 'undefined' && window._posWarehouseId) {
                  liveItm.warehouse_stocks[String(window._posWarehouseId)] = newStock;
                }
                await DB.update('items', liveItm);

                await DB.add('stock_movements', {
                  item_id: liveItm.id,
                  type: isToMe ? 'transfer_in' : 'transfer_out',
                  ref: t.ref,
                  qty: trfQty,
                  notes: isToMe ? `Transfer received from ${t.from_wh_name || 'Main Store'}` : `Transfer sent to ${t.to_wh_name}`,
                  created_at: t.created_at || new Date().toISOString()
                });

                t.applied_to_branch_stock = true;
                if (t.id != null) {
                  await DB.put('stock_transfers', t);
                }
                appliedRefs.add(t.ref);
                tablesUpdated = true;
                transferApplied = true;
              }
            }
          }

          try {
            localStorage.setItem(appliedStorageKey, JSON.stringify(Array.from(appliedRefs)));
          } catch(e) {}
        }
      } catch(trfReconcileErr) {
        console.warn('[OnlineOrders] transfer reconciliation error:', trfReconcileErr);
      }

      // Immediately publish updated branch stock and applied_to_branch_stock confirmation to Cloud
      if (transferApplied) {
        try {
          await syncCloudTables();
        } catch(syncTrfErr) {}
      }

      // 4. Other supporting tables (units, offers, suppliers) - only branch pulls from server
      if (!isServer) {
        for (const tbl of ['units', 'offers', 'suppliers']) {
          const records = cloudTables[tbl];
          if (!records || !Array.isArray(records) || !allowedTables.includes(tbl)) continue;
          try {
            const rawDb = await DB.getDB();
            if (rawDb && rawDb.objectStoreNames.contains(tbl)) {
              // Reconcile deletions: remove any local record not present in remote snapshot
              const remoteIdSet = new Set(records.map(r => (r && r.id != null) ? String(r.id) : null).filter(Boolean));
              const localRecs = (await DB.getAll(tbl)) || [];
              for (const loc of localRecs) {
                if (loc && loc.id != null && !remoteIdSet.has(String(loc.id))) {
                  try { await DB.remove(tbl, loc.id); } catch(delErr){}
                }
              }

              const tx = rawDb.transaction(tbl, 'readwrite');
              const store = tx.objectStore(tbl);
              for (const rec of records) {
                store.put(rec);
              }
              await new Promise((res, rej) => {
                tx.oncomplete = res;
                tx.onerror = () => rej(tx.error);
                tx.onabort = () => rej(tx.error);
              });
              tablesUpdated = true;
            }
          } catch(e) {}
        }
      }

      if (tablesUpdated) {
        if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'all' } }));
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'items' } }));
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'warehouses' } }));
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'stock_transfers' } }));
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'offers' } }));
        }
      }
    } catch(e) {
      console.warn('[OnlineOrders] pullCloudTables error:', e);
    }
  }

  // ── 7.0a Instant Delta Catalog Sync (Resilient to clock skew & timezone drift) ──
  let _isPullingDelta = false;

  async function pullCloudDelta(bObj = null) {
    if (_isPullingDelta || typeof DB === 'undefined') return { success: false, count: 0 };
    _isPullingDelta = true;
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      // Server is the Master Source of Truth (SSOT). It only pushes to Cloud, never pulls products!
      if (syncCfg.role === 'server') {
        return { success: true, count: 0, skipped: 'server_is_master' };
      }
      const syncTables = syncCfg.syncTables || ['items'];
      if (!syncTables.includes('items')) {
        return { success: true, count: 0, skipped: 'items_not_selected' };
      }

      // 0. Immediately apply tombstones for deleted items and categories
      try {
        await applyDeletedProducts(bObj);
        await applyDeletedCategories(bObj);
      } catch(delErr) {
        console.warn('[OnlineOrders] pullCloudDelta deletion error:', delErr);
      }

      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return { success: false, count: 0 };

      // 1. Fetch products modified since last sync (bandwidth-efficient delta query)
      const lastProdSyncKey = 'rs_cloud_prods_last_sync';
      const lastProdSync = localStorage.getItem(lastProdSyncKey) || '';
      let deltaUrl = `${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=id,barcode,name,name_ar,name_en,selling_price,cost_price,wholesale_price,category_id,unit,vat_type,vat_rate,updated_at&order=updated_at.asc&limit=150`;
      if (lastProdSync && (!bObj || !bObj._manual)) {
        deltaUrl += `&updated_at=gt.${encodeURIComponent(lastProdSync)}`;
      }
      const res = await fetch(deltaUrl, { 
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(8000)
      });
      if (!res.ok) return { success: false, count: 0 };

      const updatedProds = await res.json();
      if (!Array.isArray(updatedProds) || updatedProds.length === 0) {
        // Still pull supporting tables
        try { await pullCloudTables(bObj); } catch(tErr) {}
        return { success: true, count: 0 };
      }

      // Record latest updated_at watermark
      let maxProdTime = lastProdSync;
      for (const p of updatedProds) {
        if (p.updated_at && (!maxProdTime || p.updated_at > maxProdTime)) {
          maxProdTime = p.updated_at;
        }
      }
      if (maxProdTime) {
        localStorage.setItem(lastProdSyncKey, maxProdTime);
      }

      const localItems = (await DB.getAll('items')) || [];
      const localById = new Map();
      const localByBarcode = new Map();
      const localByName = new Map();
      for (const itm of localItems) {
        if (itm.id != null) localById.set(String(itm.id), itm);
        if (itm.barcode) localByBarcode.set(String(itm.barcode).trim(), itm);
        if (itm.name) {
          const normName = String(itm.name).trim().toLowerCase().replace(/\s+/g, ' ');
          if (normName) localByName.set(normName, itm);
        }
      }

      // 0b. Pull categories first so new or renamed categories from server exist in local DB and catMap
      try {
        const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=*`, {
          headers: getHeaders(cfg.key),
          signal: AbortSignal.timeout(6000)
        });
        if (catRes.ok) {
          const cloudCats = await catRes.json();
          if (Array.isArray(cloudCats) && cloudCats.length > 0) {
            const curCats = (await DB.getAll('categories')) || [];
            const curByName = new Map();
            curCats.forEach(c => {
              if (c.name) curByName.set(c.name.trim().toLowerCase(), c);
              if (c.name_en) curByName.set(c.name_en.trim().toLowerCase(), c);
              if (c.name_ar) curByName.set(c.name_ar.trim().toLowerCase(), c);
            });
            const catsToSave = [];
            for (const c of cloudCats) {
              const normName = (c.name || c.name_en || c.name_ar || '').trim().toLowerCase();
              const existing = curByName.get(normName);
              if (!existing || existing.name !== c.name || (c.name_ar && existing.name_ar !== c.name_ar) || existing.cloud_id !== c.id) {
                const catRecord = {
                  ...(existing || {}),
                  id: existing ? existing.id : c.id,
                  cloud_id: c.id,
                  name: c.name || c.name_en || c.name_ar,
                  name_ar: c.name_ar || '',
                  name_en: c.name_en || c.name || '',
                  sort_order: c.display_order || 0
                };
                catsToSave.push(catRecord);
                try { await DB.put('categories', catRecord); } catch(e){}
              }
            }
            if (catsToSave.length > 0 && typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
              DB.bulkSyncToServer('categories', catsToSave).catch(() => {});
            }
          }
        }
      } catch(cErr) {
        console.warn('[OnlineOrders] pullCloudDelta category sync error:', cErr);
      }

      const localCats = (await DB.getAll('categories')) || [];
      const catMap = new Map();
      localCats.forEach(c => {
        if (c.cloud_id) catMap.set(String(c.cloud_id), c.id);
        if (c.id != null) catMap.set(String(c.id), c.id);
        if (c.name) catMap.set(c.name.trim().toLowerCase(), c.id);
        if (c.name_en) catMap.set(c.name_en.trim().toLowerCase(), c.id);
        if (c.name_ar) catMap.set(c.name_ar.trim().toLowerCase(), c.id);
      });

      const syncStock = syncCfg.syncTables ? (syncCfg.syncTables.includes('stock') || syncCfg.syncTables.includes('stock_qty')) : false;

      // Collect deleted products tombstones to ensure deleted items are NEVER resurrected
      const tombstoneIds = new Set();
      const tombstoneBarcodes = new Set();
      const bannerDeleted = bObj?.pos_deleted_products;
      if (Array.isArray(bannerDeleted)) {
        for (const d of bannerDeleted) {
          if (d.id != null) tombstoneIds.add(String(d.id));
          if (d.barcode) tombstoneBarcodes.add(String(d.barcode).trim());
        }
      }

      const itemsToUpdate = [];

      for (const p of updatedProds) {
        const cleanBarcode = (p.barcode ? String(p.barcode).trim() : '');
        const cleanName = (p.name || p.name_en || p.name_ar || '').trim().toLowerCase().replace(/\s+/g, ' ');
        const pPosId = p.pos_product_id != null ? String(p.pos_product_id) : null;
        const pCloudId = p.id != null ? String(p.id) : null;

        // CRITICAL SSOT: Never resurrect a deleted/tombstoned item!
        if ((cleanBarcode && tombstoneBarcodes.has(cleanBarcode)) ||
            (pPosId && tombstoneIds.has(pPosId)) ||
            (pCloudId && tombstoneIds.has(pCloudId))) {
          continue;
        }

        // CRITICAL: Barcode is the primary universal identifier between different POS machines!
        const existing = (cleanBarcode ? localByBarcode.get(cleanBarcode) : null)
          || (cleanName ? localByName.get(cleanName) : null)
          || (p.pos_product_id ? localById.get(String(p.pos_product_id)) : null);

        if (p.is_published === false && !existing) {
          continue;
        }

        const rawId = p.pos_product_id || (existing ? existing.id : p.id);
        const numId = (!isNaN(rawId) && String(rawId).length < 10) ? Number(rawId) : rawId;
        const itemPrice = parseFloat(p.price) || 0;
        const costPrice = parseFloat(p.cost_price) || 0;
        const cloudCatId = p.category_id ? (catMap.get(String(p.category_id)) || null) : null;

        let needsUpdate = false;
        if (!existing) {
          needsUpdate = true;
        } else {
          const curPrice = parseFloat(existing.selling_price) || parseFloat(existing.price) || 0;
          const curCost = parseFloat(existing.cost_price) || 0;
          const curName = existing.name || '';
          const curBarcode = existing.barcode || '';
          const newName = p.name || p.name_en || p.name_ar || curName;
          const catDiffers = Boolean(cloudCatId && String(existing.category_id || '') !== String(cloudCatId));

          if (Math.abs(curPrice - itemPrice) > 0.001 ||
              (costPrice > 0 && Math.abs(curCost - costPrice) > 0.001) ||
              (cleanBarcode && curBarcode !== cleanBarcode) ||
              (newName && curName !== newName) ||
              catDiffers ||
              (p.updated_at && existing.updated_at && p.updated_at > existing.updated_at)) {
            needsUpdate = true;
          }
        }

        if (needsUpdate) {
          const liveExisting = existing ? ((await DB.get('items', existing.id)) || existing) : null;
          const preservedStock = liveExisting
            ? ((liveExisting.stock_qty !== undefined && liveExisting.stock_qty !== null) ? liveExisting.stock_qty : (liveExisting.stock || 0))
            : 0;
          const mergedItem = {
            ...(liveExisting || {}),
            id: liveExisting ? liveExisting.id : numId,
            name: p.name || p.name_en || p.name_ar || (liveExisting ? liveExisting.name : 'Product'),
            name_ar: p.name_ar || (liveExisting ? liveExisting.name_ar : ''),
            name_en: p.name_en || (liveExisting ? liveExisting.name_en : ''),
            barcode: cleanBarcode || (liveExisting ? liveExisting.barcode : '') || '',
            category_id: cloudCatId !== null ? cloudCatId : (liveExisting ? liveExisting.category_id : null),
            selling_price: itemPrice,
            price: itemPrice,
            online_price: itemPrice,
            cost_price: (costPrice > 0 ? costPrice : (liveExisting?.cost_price || 0)),
            stock_qty: preservedStock,
            stock: preservedStock,
            warehouse_stocks: liveExisting ? (liveExisting.warehouse_stocks || {}) : {},
            status: p.is_published !== false ? 'active' : 'inactive',
            updated_at: p.updated_at || new Date().toISOString()
          };
          itemsToUpdate.push(mergedItem);
        }
      }

      // Reconcile branch catalog against Cloud SSOT to purge any stale/old items (e.g. after offline boot)
      let purgedStaleCount = 0;
      try {
        let allCloudKeys = updatedProds;
        if (updatedProds.length >= 150) {
          const keysRes = await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=id,pos_product_id,barcode,name,name_en,name_ar&limit=5000`, {
            headers: getHeaders(cfg.key),
            signal: AbortSignal.timeout(8000)
          });
          if (keysRes.ok) {
            const keysJson = await keysRes.json();
            if (Array.isArray(keysJson) && keysJson.length > 0) {
              allCloudKeys = keysJson;
            }
          }
        }
        if (Array.isArray(allCloudKeys) && allCloudKeys.length > 0 && localItems.length > allCloudKeys.length) {
          const validBarcodes = new Set(allCloudKeys.map(p => p.barcode ? String(p.barcode).trim() : null).filter(Boolean));
          const validIds = new Set();
          const validNames = new Set();
          for (const p of allCloudKeys) {
            if (p.pos_product_id != null) validIds.add(String(p.pos_product_id));
            if (p.id != null) validIds.add(String(p.id));
            const nm = (p.name || p.name_en || p.name_ar || '').trim().toLowerCase().replace(/\s+/g, ' ');
            if (nm) validNames.add(nm);
          }
          const staleLocalItems = localItems.filter(itm => {
            const bCode = itm.barcode ? String(itm.barcode).trim() : null;
            const idStr = String(itm.id);
            const nm = String(itm.name || itm.name_en || itm.name_ar || '').trim().toLowerCase().replace(/\s+/g, ' ');
            const existsInCloud = (bCode && validBarcodes.has(bCode)) || validIds.has(idStr) || (nm && validNames.has(nm));
            return !existsInCloud;
          });
          if (staleLocalItems.length > 0) {
            console.log(`[OnlineOrders] Cloud Delta: purging ${staleLocalItems.length} stale/deleted items from branch...`);
            const rawDb = await DB.getDB();
            const txDel = rawDb.transaction('items', 'readwrite');
            const storeDel = txDel.objectStore('items');
            for (const stItm of staleLocalItems) {
              storeDel.delete(stItm.id);
              if (typeof stItm.id === 'string' && !isNaN(Number(stItm.id))) {
                try { storeDel.delete(Number(stItm.id)); } catch(e) {}
              }
            }
            await new Promise((resDel) => {
              txDel.oncomplete = resDel;
              txDel.onerror = resDel;
              txDel.onabort = resDel;
            });
            purgedStaleCount = staleLocalItems.length;
          }
        }
      } catch (reconcileErr) {
        console.warn('[OnlineOrders] Cloud Delta stale-item reconcile warning:', reconcileErr);
      }

      if (itemsToUpdate.length > 0 || purgedStaleCount > 0) {
        if (itemsToUpdate.length > 0) {
          console.log(`[OnlineOrders] Cloud Delta: applying ${itemsToUpdate.length} item updates!`);
          // Direct fast IndexedDB write bypassing localhost:3000 network hang on branches
          try {
            const rawDb = await DB.getDB();
            const tx = rawDb.transaction('items', 'readwrite');
            const store = tx.objectStore('items');
            for (const itm of itemsToUpdate) {
              store.put(itm);
            }
            await new Promise((resolve, reject) => {
              tx.oncomplete = resolve;
              tx.onerror = () => reject(tx.error);
              tx.onabort = () => reject(tx.error);
            });
          } catch (dbErr) {
            console.warn('[OnlineOrders] Direct DB put fallback:', dbErr);
            for (const itm of itemsToUpdate) {
              try { await DB.put('items', itm); } catch(e) {}
            }
          }
        }

        // Also persist to branch local backend so localhost:3000 db.dat stays synchronized (atomic replace when items were purged)
        if (typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
          if (purgedStaleCount > 0) {
            const cleanItems = (await DB.getAll('items')) || [];
            await DB.bulkSyncToServer('items', cleanItems, true).catch(() => {});
          } else {
            DB.bulkSyncToServer('items', itemsToUpdate, false).catch(() => {});
          }
        }

        if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', {
            detail: { table: 'items', count: itemsToUpdate.length + purgedStaleCount, delta: true }
          }));
        }

        const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
        if (bObj?._manual && typeof Utils !== 'undefined' && Utils.toast) {
          Utils.toast(isAR ? `⚡ تم تحديث أسعار ${itemsToUpdate.length} صنف تلقائياً من السيرفر!` : `⚡ Updated ${itemsToUpdate.length} item prices in real-time from server!`, 'success');
        }
      }

      // 3. Pull supporting tables (units, warehouses, offers, suppliers)
      try {
        await pullCloudTables(bObj);
      } catch(tErr) {}

      const nowIso = new Date().toISOString();
      localStorage.setItem('rs_last_cloud_sync', nowIso);
      localStorage.setItem('rs_last_cloud_sync_iso', nowIso);
      try { 
        await DB.setSetting('last_cloud_sync_time', nowIso);
        await DB.setSetting('last_cloud_delta_sync', nowIso);
      } catch(e) {}

      const timeEl = document.getElementById('sync-last-cloud-time');
      if (timeEl) {
        const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
        timeEl.textContent = isAR ? 'الآن (منذ لحظات)' : 'Just now';
      }

      return { success: true, count: itemsToUpdate.length };
    } catch (err) {
      console.warn('[OnlineOrders] pullCloudDelta error:', err);
      return { success: false, error: err.message, count: 0 };
    } finally {
      _isPullingDelta = false;
    }
  }

  // ── 7.0 Pull Catalog & Categories From Cloud (For Remote Branches) ─────────
  async function pullCatalogFromCloud(options = {}) {
    if (typeof DB === 'undefined') return { success: false, count: 0 };
    const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
    // Server is the Master Source of Truth: prevent accidental cloud overwrites
    if (syncCfg.role === 'server' && !options.forceServerPull) {
      console.log('[OnlineOrders] pullCatalogFromCloud skipped: this node is Server (Master Authority).');
      return { success: true, count: 0, skipped: 'server_is_master' };
    }

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const allowedTables = Array.isArray(options.syncTables) ? options.syncTables : (syncCfg.syncTables || ['items', 'categories']);
    const syncItems = allowedTables.includes('items');
    const syncCats = allowedTables.includes('categories');
    const syncStock = allowedTables.includes('stock') || allowedTables.includes('stock_qty');

    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) throw new Error(`Shop "${cfg.slug}" not found in Cloud.`);

      // 1. Fetch Cloud Categories (only if categories is in allowedTables)
      if (syncCats) {
        try {
          const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=*`, {
            headers: getHeaders(cfg.key)
          });
          if (catRes.ok) {
            const cloudCats = await catRes.json();
            if (Array.isArray(cloudCats) && cloudCats.length > 0) {
              const localCats = (await DB.getAll('categories')) || [];
              const catByName = new Map();
              localCats.forEach(c => {
                if (c.name) catByName.set(c.name.trim().toLowerCase(), c);
                if (c.name_en) catByName.set(c.name_en.trim().toLowerCase(), c);
                if (c.name_ar) catByName.set(c.name_ar.trim().toLowerCase(), c);
              });

              const allSavedCats = [];
              for (const c of cloudCats) {
                const normName = (c.name || c.name_en || c.name_ar || '').trim().toLowerCase();
                const existing = catByName.get(normName);
                const catRecord = {
                  ...(existing || {}),
                  id: existing ? existing.id : c.id,
                  cloud_id: c.id,
                  name: c.name || c.name_en || c.name_ar,
                  name_ar: c.name_ar || '',
                  name_en: c.name_en || c.name || '',
                  sort_order: c.display_order || 0
                };
                allSavedCats.push(catRecord);
                try {
                  await DB.put('categories', catRecord);
                } catch(e) {}
              }
              if (allSavedCats.length > 0 && typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
                DB.bulkSyncToServer('categories', allSavedCats).catch(() => {});
              }
            }
          }
        } catch(catErr) {
          console.warn('[OnlineOrders] pull categories error:', catErr);
        }
      }

      // 2. Fetch All Cloud Products (Chunked by 1000 - only if items is in allowedTables)
      let importedCount = 0;
      if (syncItems) {
        // Build fast lookup maps of existing local items
        const localItems = (await DB.getAll('items')) || [];
        const localById = new Map();
        const localByBarcode = new Map();
        const localByName = new Map();
        const localCats = (await DB.getAll('categories')) || [];
        const catMap = new Map();
        localCats.forEach(c => {
          if (c.cloud_id) catMap.set(String(c.cloud_id), c.id);
          if (c.id != null) catMap.set(String(c.id), c.id);
        });

        for (const itm of localItems) {
          if (itm.id != null) localById.set(String(itm.id), itm);
          if (itm.barcode) localByBarcode.set(String(itm.barcode).trim(), itm);
          if (itm.name) {
            const normName = String(itm.name).trim().toLowerCase().replace(/\s+/g, ' ');
            if (normName) localByName.set(normName, itm);
          }
        }

        let fromIdx = 0;
        let hasMore = true;
        const allCloudProducts = [];

        while (hasMore) {
          const prodRes = await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=*&limit=1000&offset=${fromIdx}&order=created_at.asc`, {
            headers: getHeaders(cfg.key),
            signal: AbortSignal.timeout(12000)
          });
          if (!prodRes.ok) break;
          const prods = await prodRes.json();
          if (!Array.isArray(prods) || prods.length === 0) {
            hasMore = false;
            break;
          }
          allCloudProducts.push(...prods);
          if (prods.length < 1000) {
            hasMore = false;
          } else {
            fromIdx += 1000;
          }
        }

        if (allCloudProducts.length === 0 && localItems.length > 0) {
          // Cloud catalog is completely empty (e.g. server wiped items) -> purge all local items!
          console.log('[OnlineOrders] Cloud catalog is empty. Purging all local branch items...');
          try {
            const rawDb = await DB.getDB();
            const tx = rawDb.transaction('items', 'readwrite');
            tx.objectStore('items').clear();
            await new Promise((res, rej) => {
              tx.oncomplete = res;
              tx.onerror = () => rej(tx.error);
            });
          } catch(e) {}
          try {
            if (typeof DB.bulkSyncToServer === 'function') {
              await DB.bulkSyncToServer('items', [], true);
            }
          } catch(e) {}
          if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
            window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'items', count: 0 } }));
          }
        } else if (allCloudProducts.length > 0) {
          // Reconcile and purge deleted items from branch
          const cloudBarcodes = new Set(allCloudProducts.map(p => p.barcode ? String(p.barcode).trim() : null).filter(Boolean));
          const cloudPosIds = new Set(allCloudProducts.map(p => String(p.pos_product_id || p.id)));
          const itemsToDelete = [];
          for (const itm of localItems) {
            const bCode = itm.barcode ? String(itm.barcode).trim() : null;
            const idStr = String(itm.id);
            const inCloud = (bCode && cloudBarcodes.has(bCode)) || cloudPosIds.has(idStr);
            if (!inCloud) {
              itemsToDelete.push(itm);
            }
          }

          if (itemsToDelete.length > 0) {
            console.log(`[OnlineOrders] Purging ${itemsToDelete.length} obsolete/deleted items on branch...`);
            try {
              const rawDb = await DB.getDB();
              const tx = rawDb.transaction('items', 'readwrite');
              const store = tx.objectStore('items');
              for (const itm of itemsToDelete) {
                store.delete(itm.id);
                if (typeof itm.id === 'string' && !isNaN(Number(itm.id))) {
                  try { store.delete(Number(itm.id)); } catch(e){}
                }
              }
              await new Promise((res, rej) => {
                tx.oncomplete = res;
                tx.onerror = () => rej(tx.error);
                tx.onabort = () => rej(tx.error);
              });
            } catch(e) {}
          }

          const itemsToSave = [];
          // Load tombstones and locally deleted items
          let cloudDelItems = [];
          try { cloudDelItems = JSON.parse(localStorage.getItem('rs_branch_deleted_items') || '[]'); } catch(e) {}
          const cDelIds = new Set(cloudDelItems.map(d => d.id != null ? String(d.id) : '').filter(Boolean));
          const cDelBc = new Set(cloudDelItems.map(d => d.barcode ? String(d.barcode).trim() : '').filter(Boolean));

          for (const p of allCloudProducts) {
            const rawId = p.pos_product_id || p.id;
            const numId = (!isNaN(rawId) && String(rawId).length < 10) ? Number(rawId) : rawId;
            const itemPrice = parseFloat(p.price) || 0;
            const costPrice = parseFloat(p.cost_price) || 0;
            const cleanBarcode = (p.barcode ? String(p.barcode).trim() : '');
            const cleanName = (p.name || p.name_en || p.name_ar || '').trim().toLowerCase().replace(/\s+/g, ' ');

            // If item was deleted, skip it! Do not revive it on branch!
            const rawIdStr = String(rawId);
            if ((rawIdStr && cDelIds.has(rawIdStr)) || (cleanBarcode && cDelBc.has(cleanBarcode))) {
              continue;
            }

            // Match existing item by Barcode (Primary), then by Name, then by POS ID, then raw ID
            const existing = (cleanBarcode ? localByBarcode.get(cleanBarcode) : null)
              || (cleanName ? localByName.get(cleanName) : null)
              || (p.pos_product_id ? localById.get(String(p.pos_product_id)) : null)
              || localById.get(String(numId));

            const liveExisting = existing ? ((await DB.get('items', existing.id)) || existing) : null;
            const itemCode = liveExisting?.item_code || (p.description && p.description.startsWith('CODE:') ? p.description.replace('CODE:', '') : String(numId));
            const cloudCatId = p.category_id ? (catMap.get(String(p.category_id)) || p.category_id) : (liveExisting ? liveExisting.category_id : null);

            const preservedStock = liveExisting
              ? ((liveExisting.stock_qty !== undefined && liveExisting.stock_qty !== null) ? liveExisting.stock_qty : (liveExisting.stock || 0))
              : 0;

            const finalItem = {
              ...(liveExisting || {}),
              id: liveExisting ? liveExisting.id : numId,
              item_code: itemCode,
              name: p.name || p.name_en || p.name_ar || 'Product',
              name_ar: p.name_ar || (liveExisting ? liveExisting.name_ar : ''),
              name_en: p.name_en || p.name || (liveExisting ? liveExisting.name_en : ''),
              barcode: cleanBarcode || (liveExisting ? liveExisting.barcode : '') || '',
              selling_price: itemPrice,
              price: itemPrice,
              cost_price: (costPrice > 0 ? costPrice : (liveExisting?.cost_price || 0)),
              stock_qty: preservedStock,
              stock: preservedStock,
              warehouse_stocks: liveExisting ? (liveExisting.warehouse_stocks || {}) : {},
              category_id: cloudCatId,
              status: p.is_published !== false ? 'active' : 'inactive',
              updated_at: new Date().toISOString()
            };

            itemsToSave.push(finalItem);
            importedCount++;
          }

          // Ultra-fast bulk write into IndexedDB (bypassing localhost:3000 network hang)
          if (itemsToSave.length > 0) {
            try {
              const rawDb = await DB.getDB();
              const tx = rawDb.transaction('items', 'readwrite');
              const store = tx.objectStore('items');
              for (const itm of itemsToSave) {
                store.put(itm);
              }
              await new Promise((resolve, reject) => {
                tx.oncomplete = resolve;
                tx.onerror = () => reject(tx.error);
                tx.onabort = () => reject(tx.error);
              });
            } catch (dbErr) {
              for (const itm of itemsToSave) {
                try { await DB.put('items', itm); } catch(e) {}
              }
            }

            // Also persist to branch local backend with replace=true so localhost:3000 db.dat is 100% purged of deleted items
            if (typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
              await DB.bulkSyncToServer('items', itemsToSave, true).catch(() => {});
            }
          }
        } else if (fromIdx === 0 && !hasMore && localItems.length > 0) {
          // Cloud has 0 items: clear branch items to match server
          console.log('[OnlineOrders] Cloud catalog has 0 products. Clearing branch items...');
          try {
            const rawDb = await DB.getDB();
            const tx = rawDb.transaction('items', 'readwrite');
            tx.objectStore('items').clear();
            await new Promise(r => { tx.oncomplete = r; });
          } catch(e) {}
          try {
            if (typeof DB.callApi === 'function') {
              await DB.callApi('/api/db-clear/items', { method: 'POST' });
            }
          } catch(e) {}
        }
      } // end if (syncItems)

      // 3. Pull Supporting Tables (units, warehouses, offers, suppliers)
      try {
        await pullCloudTables();
      } catch(stErr) {}

      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'all', count: importedCount } }));
      }
      return { success: true, count: importedCount };
    } catch (err) {
      console.error('[OnlineOrders] pullCatalogFromCloud error:', err);
      return { success: false, error: err.message, count: 0 };
    }
  }

  // ── 7.0b Register / Heartbeat Branch Node in Cloud ──────────────────────────
  async function heartbeatBranchToCloud(nodeInfo) {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(6000)
      });
      if (!tenantRes.ok) return;
      const tData = await tenantRes.json();
      if (!tData || !tData[0]) return;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      bObj.connected_branches = bObj.connected_branches || [];
      const nodeId = nodeInfo.nodeId || 'main';
      const existingIdx = bObj.connected_branches.findIndex(b => b.nodeId === nodeId);

      const branchEntry = {
        nodeId: nodeId,
        name: nodeInfo.name || nodeInfo.nodeName || nodeId,
        branchId: nodeInfo.branchId || nodeId,
        role: nodeInfo.role || 'branch',
        lastSeen: new Date().toISOString(),
        isOnline: true,
        appBuild: (typeof window !== 'undefined' && window.License && License.APP_BUILD) ? License.APP_BUILD : 106
      };

      if (existingIdx >= 0) {
        bObj.connected_branches[existingIdx] = branchEntry;
      } else {
        bObj.connected_branches.push(branchEntry);
      }

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
    } catch(err) {
      console.warn('[OnlineOrders] heartbeatBranchToCloud error:', err);
    }
  }

  // ── 7.0c Fetch Cloud Connected Branches (for Server Table) ───────────────────
  async function fetchCloudConnectedBranches() {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return [];

      const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tenantRes.ok) return [];
      const tData = await tenantRes.json();
      if (!tData || !tData[0]) return [];

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      const branches = bObj.connected_branches || [];
      const now = Date.now();
      return branches.map(b => ({
        ...b,
        ip: 'Cloud Supabase (Internet)',
        isOnline: b.lastSeen ? (now - new Date(b.lastSeen).getTime() < 300000) : false
      }));
    } catch(err) {
      return [];
    }
  }

  // ── 7.0d Remove Cloud Connected Branch (Delete from Supabase) ─────────────────
  async function removeCloudConnectedBranch(nodeId) {
    if (!nodeId) return false;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return false;

      const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tenantRes.ok) return false;
      const tData = await tenantRes.json();
      if (!tData || !tData[0]) return false;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      if (Array.isArray(bObj.connected_branches)) {
        bObj.connected_branches = bObj.connected_branches.filter(b => b.nodeId !== nodeId);
        await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
          method: 'PATCH',
          headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
          body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
        });
        return true;
      }
    } catch(err) {
      console.warn('[OnlineOrders] removeCloudConnectedBranch error:', err);
    }
    return false;
  }

  // ── 7.0e Fetch Remote Cloud POS Sales (for Central Server Reports) ────────────
  async function fetchCloudSales() {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return [];

      const res = await fetch(`${cfg.url}/rest/v1/orders?shop_id=eq.${shopId}&pos_synced=eq.true&order=created_at.desc&limit=1000`, {
        headers: getHeaders(cfg.key)
      });
      if (!res.ok) return [];
      const cloudOrders = await res.json();
      if (!Array.isArray(cloudOrders)) return [];

      // Deduplicate orders by normalized reference to prevent duplicate rows from cloud
      const seenRefs = new Set();
      const uniqueOrders = [];
      for (const o of cloudOrders) {
        const refKey = String(o.order_number || o.pos_invoice_ref || o.id || '').trim().toUpperCase();
        if (refKey && seenRefs.has(refKey)) continue;
        if (refKey) seenRefs.add(refKey);
        uniqueOrders.push(o);
      }

      return uniqueOrders.map(o => {
        let meta = {};
        try { meta = typeof o.notes === 'string' ? JSON.parse(o.notes) : (o.notes || {}); } catch(e) {}

        const branchId = meta.branch_id || o.delivery_address || 'branch';
        const terminalId = meta.terminal_id || branchId;
        const cashier = meta.cashier || 'Administrator';
        const cost = parseFloat(meta.cost) || 0;
        const profit = parseFloat(meta.profit) || 0;

        let cartItems = [];
        if (Array.isArray(o.items)) {
          cartItems = o.items.map((it, idx) => ({
            id: it.id || idx + 1,
            item_id: it.item_id || null,
            name_en: it.product_name || 'Item',
            name_ar: it.product_name || 'صنف',
            qty: parseFloat(it.quantity) || 1,
            price: parseFloat(it.unit_price) || 0,
            cost_price: parseFloat(it.cost_price) || 0,
            total: parseFloat(it.total_price) || 0,
            line_type: 'sale'
          }));
        }

        const grandTotal = parseFloat(o.total) || 0;
        const subtotal = parseFloat(o.subtotal || o.total) || 0;

        return {
          id: o.id,
          uuid: o.id,
          ref: o.order_number || o.pos_invoice_ref,
          invoice_no: o.order_number || o.pos_invoice_ref,
          receipt_no: o.order_number || o.pos_invoice_ref,
          branch_id: branchId,
          syncBranchId: branchId,
          terminal_id: terminalId,
          syncNodeId: terminalId,
          customer_name: o.customer_name || 'Walk-in',
          customer_phone: o.customer_phone || '',
          cashier: cashier,
          salesperson_name: cashier,
          grand_total: grandTotal,
          subtotal: subtotal,
          total_discount: Math.max(0, subtotal - grandTotal),
          payment_method: o.payment_method || 'cash',
          payment_status: o.payment_status || 'paid',
          items: cartItems,
          total_cost: cost,
          net_profit: profit,
          created_at: o.created_at,
          date: (o.created_at || '').slice(0, 10),
          _fromCloud: true
        };
      });
    } catch(err) {
      console.warn('[OnlineOrders] fetchCloudSales error:', err);
      return [];
    }
  }

  // ── 7.0f Wipe Synced Cloud POS Sales (Used during System Reset) ────────────
  async function clearCloudPosSales() {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return { success: false, count: 0 };

      // Delete all POS-synced sales for this shop from Supabase orders table
      const res = await fetch(`${cfg.url}/rest/v1/orders?shop_id=eq.${shopId}&pos_synced=eq.true`, {
        method: 'DELETE',
        headers: getHeaders(cfg.key)
      });
      console.log('[OnlineOrders] Cleared POS synced sales from Cloud:', res.status);
      return { success: res.ok };
    } catch(err) {
      console.warn('[OnlineOrders] clearCloudPosSales error:', err);
      return { success: false, error: err.message };
    }
  }

  // ── 7.0g Wipe Synced Cloud Catalog (Used during System Reset) ──────────────
  async function clearCloudCatalog() {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return { success: false };

      // 1. Delete all products from Supabase
      await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}`, {
        method: 'DELETE',
        headers: getHeaders(cfg.key)
      });

      // 2. Clear banner_url stale transfers, stocks, and tombstones
      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        if (tData && tData[0]) {
          let bObj = {};
          try {
            bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}
          bObj.pos_deleted_products = [];
          if (!bObj.pos_cloud_tables) bObj.pos_cloud_tables = {};
          bObj.pos_cloud_tables.stock_transfers = [];
          bObj.pos_cloud_tables._warehouse_stocks = {};
          bObj.cloud_sync_seq = Date.now();
          bObj.last_change_type = 'catalog_reset';
          bObj.last_change_desc = 'Wiped catalog and reset stock transfers';
          bObj.last_change_time = new Date().toISOString();

          await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
            method: 'PATCH',
            headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
            body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
          });
        }
      }
      console.log('[OnlineOrders] Cleared all cloud products and transfers for shop:', shopId);
      return { success: true };
    } catch(err) {
      console.warn('[OnlineOrders] clearCloudCatalog error:', err);
      return { success: false, error: err.message };
    }
  }

  // ── 7.1 Sync POS Sales To Supabase Cloud ──────────────────────────────────
  async function syncPosSalesToCloud() {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      // 1. Get existing order numbers from Supabase to prevent duplicates
      const oRes = await fetch(`${cfg.url}/rest/v1/orders?shop_id=eq.${shopId}&select=order_number`, {
        headers: getHeaders(cfg.key)
      });
      if (!oRes.ok) return;
      const existing = await oRes.json();
      const existingRefs = new Set((existing || []).map(o => o.order_number));

      // 2. Fetch local POS sales
      let sales = (await DB.getAll('sales')) || [];
      // Also fetch from sync transactions if available
      try {
        const trRes = await fetch('/api/db/sales');
        if (trRes.ok) {
          const sData = await trRes.json();
          const serverSales = sData.data || sData || [];
          if (Array.isArray(serverSales) && serverSales.length > sales.length) {
            sales = serverSales;
          }
        }
      } catch(e) {}

      // Identify sales that are missing from cloud
      const missingSales = sales.filter(s => s.ref && !existingRefs.has(s.ref));
      if (missingSales.length === 0) return;

      // Batch upload in chunks of 40
      const chunkSize = 40;
      for (let i = 0; i < missingSales.length; i += chunkSize) {
        const chunk = missingSales.slice(i, i + chunkSize);
        const formatted = chunk.map(s => {
          let items = [];
          try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
          
          let cost = 0;
          items.forEach(it => { cost += (parseFloat(it.cost_price || 0) * (parseFloat(it.qty) || 1)); });
          const total = parseFloat(s.grand_total) || 0;
          const profit = total - cost;

          return {
            shop_id: shopId,
            order_number: s.ref,
            customer_name: s.customer_name || 'عميل عابر',
            customer_phone: s.customer_phone || '',
            delivery_address: s.branch_id || 'main',
            subtotal: parseFloat(s.subtotal || s.grand_total) || 0,
            total: total,
            currency_code: 'USD',
            payment_method: s.payment_method || 'cash',
            payment_status: 'paid',
            order_status: 'completed',
            items: items.map(it => ({
              product_name: it.name_ar || it.name_en || 'Product',
              quantity: parseFloat(it.qty) || 1,
              unit_price: parseFloat(it.price) || 0,
              total_price: parseFloat(it.total) || 0,
              cost_price: parseFloat(it.cost_price) || 0
            })),
            pos_synced: true,
            pos_invoice_ref: s.ref,
            notes: JSON.stringify({
              source: 'pos',
              branch_id: s.branch_id || 'main',
              terminal_id: s.terminal_id || 'POS-2',
              cashier: s.cashier || s.salesperson_name || 'Administrator',
              cost: cost,
              profit: profit
            }),
            created_at: s.created_at,
            updated_at: s.updated_at || s.created_at
          };
        });

        await fetch(`${cfg.url}/rest/v1/orders`, {
          method: 'POST',
          headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
          body: JSON.stringify(formatted)
        });
      }
      console.log('[OnlineOrders] Synced ' + missingSales.length + ' POS sales to Cloud.');
    } catch (err) {
      console.warn('[OnlineOrders] Sales cloud sync note:', err);
    }
  }

  // ── 7.2 Sync Branch Cashbox Drawers To Supabase Cloud ─────────────────────
  async function syncCashboxStatusToCloud() {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const sessions = (await DB.getAll('cashbox_sessions')) || [];
      const movements = (await DB.getAll('cashbox_movements')) || [];
      const activeSession = sessions.find(s => s.status === 'open') || sessions[sessions.length - 1];

      let salesCash = 0;
      let cashIn = 0;
      let cashOut = 0;
      if (activeSession) {
        const sMov = movements.filter(m => m.session_id === activeSession.id);
        salesCash = sMov.filter(m => m.type === 'sale').reduce((sum, m) => sum + (parseFloat(m.amount) || 0), 0);
        cashIn = sMov.filter(m => m.type === 'in').reduce((sum, m) => sum + (parseFloat(m.amount) || 0), 0);
        cashOut = sMov.filter(m => m.type === 'out').reduce((sum, m) => sum + (parseFloat(m.amount) || 0), 0);
      }

      // Also calculate from today's sales if movements empty
      const sales = (await DB.getAll('sales')) || [];
      const todayCashSales = sales.filter(s => {
        const isToday = s.created_at && new Date(s.created_at).toDateString() === new Date().toDateString();
        return isToday && (s.payment_method === 'cash' || !s.payment_method);
      }).reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);

      const openingAmount = activeSession ? (parseFloat(activeSession.opening_amount) || 0) : 0;
      const actualSalesCash = salesCash > 0 ? salesCash : todayCashSales;
      const currentBalance = openingAmount + actualSalesCash + cashIn - cashOut;

      let myBranchId = 'main';
      let myBranchName = 'الفرع الرئيسي (Main Branch)';
      let myNodeId = (activeSession && activeSession.terminal_id) || localStorage.getItem('redshark_pos_terminal') || 'POS-1';

      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        try {
          const syncCfg = await BranchSync.getConfig();
          if (syncCfg.branchId) myBranchId = syncCfg.branchId;
          if (syncCfg.nodeId) myNodeId = syncCfg.nodeId;
          myBranchName = (myBranchId === 'main') ? 'الفرع الرئيسي (Main Branch)' : (syncCfg.nodeName || myBranchId);
        } catch(e) {}
      }

      const boxEntry = {
        terminal_id: myNodeId,
        branch_id: myBranchId,
        branch_name: myBranchName,
        cashier_name: (activeSession && activeSession.cashier_name) || (window.Auth && typeof Auth.getUser === 'function' ? (Auth.getUser()?.full_name || Auth.getUser()?.username) : 'Administrator'),
        status: activeSession ? activeSession.status : 'open',
        opening_amount: openingAmount,
        cash_sales: actualSalesCash,
        cash_in: cashIn,
        cash_out: cashOut,
        balance_usd: currentBalance,
        balance_lbp: Math.round(currentBalance * 89500),
        opened_at: activeSession ? activeSession.opened_at : new Date().toISOString(),
        last_updated: new Date().toISOString()
      };

      // Update tenant banner_url JSON
      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        let bObj = {};
        try {
          bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
        } catch(e) {}

        let existingBoxes = Array.isArray(bObj.pos_cashboxes) ? bObj.pos_cashboxes : [];
        const existingIdx = existingBoxes.findIndex(b => b.branch_id === myBranchId || b.terminal_id === myNodeId);
        if (existingIdx >= 0) {
          existingBoxes[existingIdx] = boxEntry;
        } else {
          existingBoxes.push(boxEntry);
        }

        bObj.pos_cashboxes = existingBoxes;

        await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
          method: 'PATCH',
          headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
          body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
        });
      }
    } catch(err) {
      console.warn('[OnlineOrders] Cashbox cloud sync note:', err);
    }
  }

  // ── 7.3 Pull Cloud Stock Updates Down To POS ──────────────────────────────
  async function pullCloudStockUpdates() {
    // Each station (Server or Branch) maintains its own authoritative local stock.
    // Stock changes between Server and Branches are handled exclusively via Stock Transfers.
    return;
  }

  // ── Universal Customer Matching Key Helper ─────────────────────────────────
  function getCustomerKey(c) {
    if (!c) return null;
    const cleanPhone = (c.phone ? String(c.phone).replace(/\D/g, '') : '');
    if (cleanPhone && cleanPhone.length >= 6) return 'phone::' + cleanPhone;
    const normName = (c.name_ar || c.name_en || c.name || '').trim().toLowerCase().replace(/\s+/g, ' ');
    if (normName) return 'name::' + normName;
    if (c.code) return 'code::' + String(c.code).trim().toLowerCase();
    return (c.id != null) ? ('id::' + c.id) : null;
  }

  // ── 7.2b Fetch Remote Branch Cashboxes from Cloud (for Central Server) ────
  async function fetchCloudCashboxes() {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return [];

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tRes.ok) return [];
      const tData = await tRes.json();
      if (!tData || !tData[0]) return [];

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      return Array.isArray(bObj.pos_cashboxes) ? bObj.pos_cashboxes : [];
    } catch(err) {
      console.warn('[OnlineOrders] fetchCloudCashboxes error:', err);
      return [];
    }
  }

  // ── 7.4 Standalone Customer Balances (Option A: 100% Local Protection) ───────
  async function syncCustomersToCloud() {
    // OPTION A: Standalone customer balances per branch.
    // Balances and debits are strictly local to each station to guarantee 100% data integrity.
    return { success: true, count: 0, skipped: 'standalone_mode' };
  }

  // ── 7.5 Standalone Customer Balances (Option A: 100% Local Protection) ───────
  async function pullCustomersFromCloud() {
    // OPTION A: Standalone customer balances per branch.
    // Balances and debits are strictly local to each station to guarantee 100% data integrity.
    return { success: true, count: 0, skipped: 'standalone_mode' };
  }

  // ── 8. Settings Modal ──────────────────────────────────────────────────────
  async function openSettingsModal() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const cfg = await getConfig();

    const modalHtml = `
      <div class="modal-overlay" id="online-orders-settings-modal" style="display:flex;align-items:center;justify-content:center;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;backdrop-filter:blur(4px)">
        <div style="background:var(--surface,#fff);border:1px solid var(--border-color,#e5e7eb);border-radius:16px;width:90%;max-width:520px;padding:24px;box-shadow:0 20px 40px rgba(0,0,0,0.3);position:relative">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;border-bottom:1px solid var(--border-color,#eee);padding-bottom:12px">
            <h3 style="margin:0;font-size:1.15rem;font-weight:800;display:flex;align-items:center;gap:8px">
              <span>⚙️</span>
              <span>${isAR ? 'إعدادات ربط المتجر الإلكتروني (Supabase)' : 'Online Storefront & Supabase Settings'}</span>
            </h3>
            <button class="btn-icon" onclick="document.getElementById('online-orders-settings-modal').remove()" style="cursor:pointer;border:none;background:none;font-size:1.2rem">✕</button>
          </div>

          <div style="display:flex;flex-direction:column;gap:14px">
            <div>
              <label style="font-size:0.82rem;font-weight:700;display:block;margin-bottom:4px">
                ${isAR ? 'معرف المتجر (Shop Slug / ID)' : 'Shop Identifier (Slug / Subdomain)'}
              </label>
              <input type="text" id="setting-shop-slug" value="${cfg.slug}" class="form-control" placeholder="e.g. shop101" style="width:100%;padding:9px 12px;border-radius:8px;font-weight:700;font-family:monospace">
              <div style="font-size:0.7rem;color:var(--text-muted,#6b7280);margin-top:3px">${isAR ? 'نفس المعرف المحدد في نفق Cloudflare أو رابط المتجر' : 'Matches your unique Cloudflare tunnel subdomain (e.g. shop101.yourdomain.com)'}</div>
            </div>

            <div>
              <label style="font-size:0.82rem;font-weight:700;display:block;margin-bottom:4px">Supabase Project URL</label>
              <input type="text" id="setting-supabase-url" value="${cfg.url}" class="form-control" placeholder="https://xyz.supabase.co" style="width:100%;padding:9px 12px;border-radius:8px;font-size:0.85rem">
            </div>

            <div>
              <label style="font-size:0.82rem;font-weight:700;display:block;margin-bottom:4px">Supabase Anon Key</label>
              <textarea id="setting-supabase-key" class="form-control" rows="2" style="width:100%;padding:9px 12px;border-radius:8px;font-size:0.75rem;font-family:monospace">${cfg.key}</textarea>
            </div>

            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:rgba(16,185,129,0.08);border-radius:8px;border:1px solid rgba(16,185,129,0.2)">
              <input type="checkbox" id="setting-auto-print" ${cfg.autoPrint ? 'checked' : ''} style="width:18px;height:18px;cursor:pointer">
              <label for="setting-auto-print" style="font-size:0.85rem;font-weight:700;cursor:pointer;margin:0">
                ${isAR ? '🖨️ طباعة إيصال التحضير تلقائياً فور وصول طلبية جديدة' : '🖨️ Automatically print packing slip when new order arrives'}
              </label>
            </div>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;border-top:1px solid var(--border-color,#eee);padding-top:14px">
            <button class="btn btn-ghost" onclick="document.getElementById('online-orders-settings-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button class="btn btn-primary" onclick="OnlineOrders.saveSettings()">${isAR ? 'حفظ الإعدادات' : 'Save Settings'}</button>
          </div>
        </div>
      </div>
    `;

    const existing = document.getElementById('online-orders-settings-modal');
    if (existing) existing.remove();
    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  async function saveSettings() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const slug = document.getElementById('setting-shop-slug')?.value.trim() || '';
    const url = document.getElementById('setting-supabase-url')?.value.trim() || DEFAULT_SUPABASE_URL;
    const key = document.getElementById('setting-supabase-key')?.value.trim() || DEFAULT_SUPABASE_KEY;
    const autoPrint = document.getElementById('setting-auto-print')?.checked || false;

    if (typeof DB !== 'undefined') {
      await DB.setSetting('online_store_shop_slug', slug);
      await DB.setSetting('online_store_url', url);
      await DB.setSetting('online_store_key', key);
      await DB.setSetting('online_store_autoprint', autoPrint);
    }
    if (slug) { localStorage.setItem('redshark_shop_slug', slug); } else { localStorage.removeItem('redshark_shop_slug'); localStorage.removeItem('sync_cloud_slug'); }

    _resolvedShopId = null;
    await resolveShopId({ url, key, slug }, true, true);
    document.getElementById('online-orders-settings-modal')?.remove();

    if (typeof Utils !== 'undefined' && Utils.toast) {
      Utils.toast(isAR ? '✅ تم حفظ إعدادات المتجر بنجاح' : '✅ Online store settings saved successfully', 'success');
    }

    await fetchOrders();
  }

  // ── 9. Main UI View Rendering ──────────────────────────────────────────────
  async function render(container) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    stopChimeLoop(); // Cashier opened the screen, stop audio alert

    container.innerHTML = `
      <div id="online-orders-container" style="padding:16px 20px;max-width:1400px;margin:0 auto">
        <!-- Header Bar -->
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px">
          <div>
            <h1 style="margin:0;font-size:1.6rem;font-weight:900;display:flex;align-items:center;gap:10px">
              <span>🛍️</span>
              <span>${isAR ? 'طلبات المتجر الإلكتروني (Online Orders)' : 'Online Store Orders'}</span>
              <span class="badge badge-success" id="oo-active-count" style="font-size:0.75rem;padding:3px 8px">Live</span>
            </h1>
            <p style="margin:4px 0 0;font-size:0.82rem;color:var(--text-muted,#6b7280)">
              ${isAR ? 'استقبال وإدارة الطلبات الواردة مباشرة من المتجر الإلكتروني وتحويلها إلى فواتير بيع مع طباعة فورية' : 'Live incoming order management, thermal kitchen packing slips, and 1-click POS sale conversion.'}
            </p>
          </div>

          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-outline" onclick="OnlineOrders.toggleMute()" id="btn-toggle-mute" title="Toggle Sound Alerts" style="display:flex;align-items:center;gap:6px">
              <span>${_isMuted ? '🔇' : '🔔'}</span>
              <span>${_isMuted ? (isAR ? 'تشغيل الصوت' : 'Unmute') : (isAR ? 'كتم الصوت' : 'Mute')}</span>
            </button>

            <button class="btn btn-outline" onclick="OnlineOrders.syncCatalogToCloud()" title="Push POS Items & Stock to Online Store" style="display:flex;align-items:center;gap:6px">
              <span>🔄</span>
              <span>${isAR ? 'مزامنة الأصناف مع المتجر' : 'Sync Catalog & Stock'}</span>
            </button>

            <button class="btn btn-outline" onclick="OnlineOrders.openSettingsModal()" title="Supabase & Shop Settings" style="display:flex;align-items:center;gap:6px">
              <span>⚙️</span>
              <span>${isAR ? 'الإعدادات' : 'Settings'}</span>
            </button>

            <button class="btn btn-primary" onclick="OnlineOrders.fetchOrders()" style="display:flex;align-items:center;gap:6px">
              <span>↻</span>
              <span>${isAR ? 'تحديث' : 'Refresh'}</span>
            </button>
          </div>
        </div>

        <!-- Filter Tabs & Search -->
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;background:var(--surface,#fff);border:1px solid var(--border-color,#e5e7eb);padding:12px 16px;border-radius:12px;margin-bottom:20px">
          <div style="display:flex;gap:6px;flex-wrap:wrap" id="oo-filter-tabs">
            <button class="btn btn-sm ${(!_activeFilter || _activeFilter === 'all') ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('all')">
              ${isAR ? 'الكل' : 'All'} (<span id="count-all">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'received' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('received')" style="position:relative">
              🔔 ${isAR ? 'جديد بانتظار التأكيد' : 'Received'} (<span id="count-received">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'preparing' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('preparing')">
              👨‍🍳 ${isAR ? 'جاري التحضير' : 'Preparing'} (<span id="count-preparing">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'out_for_delivery' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('out_for_delivery')">
              🛵 ${isAR ? 'خرج للتوصيل' : 'Out for Delivery'} (<span id="count-out_for_delivery">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'completed' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('completed')">
              ✅ ${isAR ? 'مكتمل' : 'Completed'} (<span id="count-completed">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'cancelled' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('cancelled')">
              ❌ ${isAR ? 'ملغي' : 'Cancelled'} (<span id="count-cancelled">0</span>)
            </button>
          </div>

          <div style="min-width:260px">
            <input type="text" id="oo-search-input" oninput="OnlineOrders.renderOrderList()" placeholder="${isAR ? '🔍 ابحث برقم الطلب، الاسم، أو الهاتف...' : '🔍 Search by Order #, Name, Phone...'}" class="form-control" style="font-size:0.85rem;padding:7px 12px;border-radius:8px;width:100%;box-sizing:border-box">
          </div>
        </div>

        <!-- Orders Grid Container -->
        <div id="oo-orders-grid" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(360px, 1fr));gap:16px">
          <!-- Populated by renderOrderList() -->
        </div>
      </div>
    `;

    await fetchOrders(true);
      syncPosSalesToCloud();
      syncCashboxStatusToCloud();
      pullCloudStockUpdates();
    renderOrderList();
  }

  function renderOrderList() {
    const grid = document.getElementById('oo-orders-grid');
    if (!grid) return;

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const search = (document.getElementById('oo-search-input')?.value || '').toLowerCase().trim();

    // Update Counts
    const counts = {
      all: _orders.length,
      received: _orders.filter(o => o.order_status === 'received').length,
      preparing: _orders.filter(o => o.order_status === 'preparing').length,
      out_for_delivery: _orders.filter(o => o.order_status === 'out_for_delivery').length,
      completed: _orders.filter(o => o.order_status === 'completed').length,
      cancelled: _orders.filter(o => o.order_status === 'cancelled').length
    };

    Object.keys(counts).forEach(k => {
      const el = document.getElementById(`count-${k}`);
      if (el) el.textContent = counts[k];
    });

    let filtered = _orders;
    if (_activeFilter && _activeFilter !== 'all') {
      filtered = filtered.filter(o => o.order_status === _activeFilter);
    }

    if (search) {
      filtered = filtered.filter(o =>
        (o.order_number && o.order_number.toLowerCase().includes(search)) ||
        (o.customer_name && o.customer_name.toLowerCase().includes(search)) ||
        (o.customer_phone && o.customer_phone.includes(search)) ||
        (o.pos_invoice_ref && o.pos_invoice_ref.toLowerCase().includes(search))
      );
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;padding:60px 20px;background:var(--surface,#fff);border:1px dashed var(--border-color,#d1d5db);border-radius:16px">
          <div style="font-size:3rem;margin-bottom:10px">📭</div>
          <h3 style="margin:0 0 6px;font-size:1.1rem;font-weight:700">${isAR ? 'لا توجد طلبات في هذا القسم حالياً' : 'No orders found in this section'}</h3>
          <p style="margin:0;font-size:0.8rem;color:var(--text-muted,#6b7280)">${isAR ? 'أي طلبية جديدة يقوم الزبون بطلبها عبر المتجر ستظهر هنا تلقائياً مع جرس تنبيه.' : 'Any new orders placed via the online shop will appear here automatically with sound notification.'}</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(order => {
      const statusBadge = getStatusBadge(order.order_status, isAR);
      const isReceived = order.order_status === 'received';
      const isPreparing = order.order_status === 'preparing';
      const isOutForDelivery = order.order_status === 'out_for_delivery';
      const isCompleted = order.order_status === 'completed';
      const isCancelled = order.order_status === 'cancelled';

      const items = getOrderItems(order);
      const totalUSD = (parseFloat(order.total) || 0).toFixed(2);
      const rate = parseFloat(order.exchange_rate) || 89500;
      const totalLBP = (parseFloat(order.total_secondary) || Math.round(totalUSD * rate)).toLocaleString();

      let addrText = '';
      if (order.delivery_address) {
        if (typeof order.delivery_address === 'object') {
          const a = order.delivery_address;
          addrText = [a.city, a.street_address, a.building].filter(Boolean).join(', ');
        } else {
          addrText = String(order.delivery_address);
        }
      }

      return `
        <div style="background:var(--surface,#fff);border:1.5px solid ${isReceived ? '#f59e0b' : 'var(--border-color,#e5e7eb)'};border-radius:14px;padding:16px;display:flex;flex-direction:column;justify-content:space-between;box-shadow:${isReceived ? '0 8px 24px rgba(245,158,11,0.18)' : '0 2px 8px rgba(0,0,0,0.04)'};position:relative;animation:${isReceived ? 'pulseBorder 2s infinite' : 'none'}">
          <!-- Card Top Bar with Direct Status Selector -->
          <div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:8px">
              <div>
                <span style="font-family:monospace;font-weight:900;font-size:1.05rem;color:var(--primary,#2563eb)">#${order.order_number || 'RS-ORD'}</span>
                <div style="font-size:0.72rem;color:var(--text-muted,#6b7280);margin-top:2px">
                  ${new Date(order.created_at || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • ${new Date(order.created_at || Date.now()).toLocaleDateString()}
                </div>
              </div>

              <!-- Direct Status Dropdown Selector -->
              <div style="display:flex;align-items:center;gap:6px">
                <select class="form-control" style="font-size:0.76rem;font-weight:800;padding:5px 10px;border-radius:20px;border:1.5px solid ${order.order_status === 'received' ? '#f59e0b' : (order.order_status === 'preparing' ? '#0284c7' : (order.order_status === 'out_for_delivery' ? '#9333ea' : (order.order_status === 'completed' ? '#10b981' : '#ef4444')))};background:var(--surface,#fff);color:var(--text-main,#111827);cursor:pointer;outline:none"
                  onchange="OnlineOrders.updateOrderStatus('${order.id}', this.value)">
                  <option value="received" ${order.order_status === 'received' ? 'selected' : ''}>🔔 ${isAR ? 'جديد (Received)' : 'Received'}</option>
                  <option value="preparing" ${order.order_status === 'preparing' ? 'selected' : ''}>👨‍🍳 ${isAR ? 'قيد التحضير (Preparing)' : 'Preparing'}</option>
                  <option value="out_for_delivery" ${order.order_status === 'out_for_delivery' ? 'selected' : ''}>🛵 ${isAR ? 'خرج للتوصيل (Out for Delivery)' : 'Out for Delivery'}</option>
                  <option value="completed" ${order.order_status === 'completed' ? 'selected' : ''}>✅ ${isAR ? 'مكتمل (Completed)' : 'Completed'}</option>
                  <option value="cancelled" ${order.order_status === 'cancelled' ? 'selected' : ''}>❌ ${isAR ? 'ملغي (Cancelled)' : 'Cancelled'}</option>
                </select>
              </div>
            </div>

            <!-- Customer & Delivery Info -->
            <div style="background:var(--input-bg,rgba(0,0,0,0.02));border-radius:10px;padding:10px 12px;margin-bottom:12px;border:1px solid var(--border-color,#eee)">
              <div style="font-weight:800;font-size:0.95rem;display:flex;align-items:center;justify-content:space-between">
                <span>👤 ${order.customer_name}</span>
                <span style="font-size:0.75rem;font-weight:700;color:#0284c7">
                  ${order.fulfillment_type === 'pickup' ? (isAR ? '🏬 استلام بالمحل' : '🏬 Pickup') : (isAR ? '🛵 توصيل' : '🛵 Delivery')}
                </span>
              </div>
              <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
                <span style="font-size:0.85rem;font-weight:700">📞 ${order.customer_phone}</span>
                ${order.customer_phone ? `
                <a href="https://wa.me/${order.customer_phone.replace(/[^0-9]/g, '')}" target="_blank" style="text-decoration:none;font-size:0.75rem;background:#25d366;color:#fff;padding:2px 7px;border-radius:12px;font-weight:700">
                  WhatsApp
                </a>` : ''}
              </div>
              ${addrText ? `
              <div style="font-size:0.75rem;color:var(--text-muted,#4b5563);margin-top:4px;line-height:1.3">
                📍 ${addrText}
              </div>` : ''}
              ${order.notes ? `
              <div style="font-size:0.75rem;color:#b91c1c;margin-top:4px;font-weight:600">
                📝 ${order.notes}
              </div>` : ''}
            </div>

            <!-- Items List Summary -->
            <div style="margin-bottom:12px">
              <div style="font-size:0.75rem;font-weight:800;text-transform:uppercase;color:var(--text-muted,#6b7280);margin-bottom:6px;display:flex;justify-content:space-between;align-items:center">
                <span>${isAR ? 'الأصناف المطلوبة' : 'Ordered Items'} (${items.length}):</span>
                <span style="font-size:0.72rem;color:var(--text-muted,#6b7280);font-weight:600">${items.reduce((s, it) => s + (parseFloat(it.quantity || it.qty) || 1), 0)} pcs</span>
              </div>
              <div style="max-height:160px;overflow-y:auto;display:flex;flex-direction:column;gap:4px;background:var(--bg-secondary,rgba(0,0,0,0.02));padding:8px 10px;border-radius:10px;border:1px solid var(--border-color,#f1f5f9)">
                ${items.length === 0 ? `
                  <div style="text-align:center;padding:12px;color:var(--text-muted,#9ca3af);font-size:0.8rem">
                    ${isAR ? 'لا توجد أصناف في هذا الطلب' : 'No items recorded in this order'}
                  </div>
                ` : items.map(it => {
                  const itName = it.product_name || it.name || it.title || (isAR ? 'صنف' : 'Product');
                  const itQty = parseFloat(it.quantity || it.qty) || 1;
                  const itPrice = parseFloat(it.unit_price || it.price) || 0;
                  const itTotal = parseFloat(it.total_price || it.total) || (itQty * itPrice);
                  return `
                    <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.84rem;padding:4px 0;border-bottom:1px dashed var(--border-color,#e5e7eb)">
                      <div style="display:flex;align-items:center;gap:6px">
                        <span style="background:rgba(2,132,199,0.12);color:#0284c7;font-weight:900;font-size:0.76rem;padding:2px 7px;border-radius:6px">${itQty}x</span>
                        <span style="font-weight:700;color:var(--text-main,#111827)">${itName}</span>
                        ${it.variant_name ? `<span style="font-size:0.72rem;color:var(--text-muted,#6b7280)">(${it.variant_name})</span>` : ''}
                      </div>
                      <span style="font-weight:800;color:var(--text-main,#111827)">$${itTotal.toFixed(2)}</span>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- Financials Summary -->
            <div style="display:flex;justify-content:space-between;align-items:baseline;padding-top:8px;border-top:1px solid var(--border-color,#eee);margin-bottom:14px">
              <div>
                <span style="font-size:0.75rem;color:var(--text-muted,#6b7280)">${(order.payment_method || 'cod').toUpperCase()} • </span>
                <span style="font-size:0.78rem;font-weight:700;color:${order.payment_status === 'paid' ? '#10b981' : '#f59e0b'}">
                  ${order.payment_status === 'paid' ? (isAR ? 'مدفوع' : 'Paid') : (isAR ? 'الدفع عند الاستلام' : 'Pending Payment')}
                </span>
              </div>
              <div style="text-align:right">
                <div style="font-size:1.15rem;font-weight:900;color:var(--text-main,#111827)">$${totalUSD} <span style="font-size:0.8rem">USD</span></div>
                <div style="font-size:0.75rem;font-weight:700;color:#0284c7">≈ ${totalLBP} L.L.</div>
              </div>
            </div>

            ${order.pos_invoice_ref ? `
            <div style="background:rgba(16,185,129,0.1);color:#059669;padding:6px 10px;border-radius:6px;font-size:0.78rem;font-weight:800;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between">
              <span>🧾 ${isAR ? 'فاتورة نقاط البيع:' : 'POS Invoice Ref:'}</span>
              <span style="font-family:monospace">${order.pos_invoice_ref}</span>
            </div>` : ''}
          </div>

          <!-- Bottom Action Buttons: Full Order Lifecycle Management -->
          <div style="display:flex;flex-direction:column;gap:6px;padding-top:8px;border-top:1px solid var(--border-color,#eee)">
            ${isReceived ? `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-primary btn-sm" onclick="OnlineOrders.acceptAndPrepare('${order.id}')" style="font-weight:800">
                👨‍🍳 ${isAR ? 'قبول وتحضير' : 'Accept & Prepare'}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.printOrderSlipById('${order.id}', true)">
                🖨️ ${isAR ? 'طباعة التغليف' : 'Print Slip'}
              </button>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-warning btn-sm" onclick="OnlineOrders.loadOrderIntoPos('${order.id}')" style="font-weight:800;color:#000">
                🛒 ${isAR ? 'تحميل في الكاشير' : 'Load in POS'}
              </button>
              <button class="btn btn-success btn-sm" onclick="OnlineOrders.completeAndCloseOrder('${order.id}')" style="background:#10b981;border-color:#10b981;color:#fff;font-weight:800">
                ⚡ ${isAR ? 'بيع فوري وإغلاق' : 'Instant Sale & Close'}
              </button>
            </div>
            ` : ''}

            ${isPreparing ? `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-primary btn-sm" onclick="OnlineOrders.updateOrderStatus('${order.id}', 'out_for_delivery')" style="background:#0284c7;border-color:#0284c7;font-weight:800">
                🛵 ${isAR ? (order.fulfillment_type === 'pickup' ? 'جاهز للاستلام' : 'خرج للتوصيل') : (order.fulfillment_type === 'pickup' ? 'Ready for Pickup' : 'Out for Delivery')}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.printOrderSlipById('${order.id}', false)">
                🖨️ ${isAR ? 'طباعة الفاتورة' : 'Print Invoice'}
              </button>
            </div>
            <div style="display:grid;grid-template-columns:${!order.pos_synced ? '1fr 1fr' : '1fr'};gap:6px">
              <button class="btn btn-warning btn-sm" onclick="OnlineOrders.loadOrderIntoPos('${order.id}')" style="font-weight:800;color:#000">
                🛒 ${isAR ? 'تحميل في الكاشير' : 'Load in POS'}
              </button>
              ${!order.pos_synced ? `
              <button class="btn btn-success btn-sm" onclick="OnlineOrders.convertOrderToSale('${order.id}')" style="background:#10b981;border-color:#10b981;color:#fff;font-weight:800">
                💳 ${isAR ? 'إصدار فاتورة بيع' : 'Convert to Sale'}
              </button>` : ''}
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-success btn-sm" onclick="OnlineOrders.completeAndCloseOrder('${order.id}')" style="background:#059669;border-color:#059669;color:#fff;font-weight:800">
                ✅ ${isAR ? 'تسليم وإغلاق الطلب' : 'Deliver & Close'}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.updateOrderStatus('${order.id}', 'received')" style="color:#64748b;font-size:0.75rem">
                ↩️ ${isAR ? 'إرجاع إلى جديد' : 'Back to Received'}
              </button>
            </div>
            ` : ''}

            ${isOutForDelivery ? `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-success btn-sm" onclick="OnlineOrders.completeAndCloseOrder('${order.id}')" style="background:#10b981;border-color:#10b981;color:#fff;font-weight:900">
                ✅ ${isAR ? 'تم التسليم وإغلاق الطلب' : 'Delivered & Close'}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.printOrderSlipById('${order.id}', false)">
                🖨️ ${isAR ? 'طباعة الفاتورة' : 'Print Invoice'}
              </button>
            </div>
            <button class="btn btn-outline btn-sm" onclick="OnlineOrders.updateOrderStatus('${order.id}', 'preparing')" style="color:#0284c7;border-color:#0284c7;font-size:0.75rem;padding:3px">
              ↩️ ${isAR ? 'إعادة إلى قيد التحضير' : 'Back to Preparing'}
            </button>
            ` : ''}

            ${isCompleted ? `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.printOrderSlipById('${order.id}', false)">
                🖨️ ${isAR ? 'إعادة طباعة الفاتورة' : 'Reprint Invoice'}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.reopenOrder('${order.id}')" style="color:#f59e0b;border-color:#f59e0b">
                ↩️ ${isAR ? 'إعادة فتح الطلب' : 'Reopen Order'}
              </button>
            </div>
            ` : ''}

            ${isCancelled ? `
            <button class="btn btn-secondary btn-sm" onclick="OnlineOrders.reactivateOrder('${order.id}')" style="font-weight:700">
              🔄 ${isAR ? 'إعادة تنشيط الطلب كـ جديد' : 'Reactivate as New Order'}
            </button>
            ` : ''}

            ${(!isCompleted && !isCancelled) ? `
            <button class="btn btn-ghost btn-sm" onclick="OnlineOrders.cancelOrderPrompt('${order.id}')" style="color:var(--danger,#ef4444);font-size:0.75rem;padding:3px;margin-top:2px">
              ✕ ${isAR ? 'إلغاء الطلب (Cancel Order)' : 'Cancel Order'}
            </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  }

  function getStatusBadge(status, isAR) {
    switch (status) {
      case 'received':
        return `<span style="background:#fef3c7;color:#b45309;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #fde68a">🔔 ${isAR ? 'جديد بانتظار التأكيد' : 'Received'}</span>`;
      case 'preparing':
        return `<span style="background:#e0f2fe;color:#0369a1;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #bae6fd">👨‍🍳 ${isAR ? 'جاري التحضير' : 'Preparing'}</span>`;
      case 'out_for_delivery':
        return `<span style="background:#f3e8ff;color:#7e22ce;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #e9d5ff">🛵 ${isAR ? 'خرج للتوصيل' : 'Out for Delivery'}</span>`;
      case 'completed':
        return `<span style="background:#d1fae5;color:#047857;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #a7f3d0">✅ ${isAR ? 'مكتمل ومغلق' : 'Completed'}</span>`;
      case 'cancelled':
        return `<span style="background:#fee2e2;color:#b91c1c;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #fecaca">❌ ${isAR ? 'ملغي' : 'Cancelled'}</span>`;
      default:
        return `<span class="badge">${status}</span>`;
    }
  }

  // Helper actions
  async function acceptAndPrepare(orderId) {
    stopChimeLoop();
    await updateOrderStatus(orderId, 'preparing');
  }

  // Complete order: converts to POS sale if not already done, then marks completed
  async function completeAndCloseOrder(orderId) {
    const order = _orders.find(o => o.id === orderId);
    if (!order) return;
    if (!order.pos_synced) {
      await convertOrderToSale(orderId, 'completed');
    } else {
      await updateOrderStatus(orderId, 'completed');
    }
  }

  // Reopen completed order back to preparing
  async function reopenOrder(orderId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    if (typeof Utils !== 'undefined' && Utils.confirm) {
      Utils.confirm(isAR ? 'هل تريد إعادة فتح هذا الطلب وإرجاعه إلى قيد التحضير؟' : 'Reopen this order and set back to Preparing?', async () => {
        await updateOrderStatus(orderId, 'preparing');
      });
    } else {
      await updateOrderStatus(orderId, 'preparing');
    }
  }

  // Reactivate cancelled order back to received
  async function reactivateOrder(orderId) {
    await updateOrderStatus(orderId, 'received');
  }

  function printOrderSlipById(orderId, isPackingSlip) {
    const o = _orders.find(ord => ord.id === orderId);
    if (o) printOrderSlip(o, isPackingSlip);
  }

  async function cancelOrderPrompt(orderId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    if (typeof Utils !== 'undefined' && Utils.confirm) {
      Utils.confirm(
        isAR ? 'هل أنت متأكد من إلغاء هذا الطلب؟' : 'Are you sure you want to cancel this order?',
        async () => {
          await updateOrderStatus(orderId, 'cancelled', { cancel_reason: 'Cancelled by cashier' });
        }
      );
    } else {
      const reason = prompt(isAR ? 'يرجى كتابة سبب الإلغاء:' : 'Enter cancellation reason:') || 'Cancelled';
      await updateOrderStatus(orderId, 'cancelled', { cancel_reason: reason });
    }
  }

  function setFilter(filter) {
    _activeFilter = filter;
    const tabs = document.querySelectorAll('#oo-filter-tabs button');
    tabs.forEach(t => t.classList.remove('btn-primary'));
    renderOrderList();
  }

  function toggleMute() {
    _isMuted = !_isMuted;
    if (_isMuted) stopChimeLoop();
    const btn = document.getElementById('btn-toggle-mute');
    if (btn) {
      btn.innerHTML = `<span>${_isMuted ? '🔇' : '🔔'}</span><span>${_isMuted ? 'Unmute' : 'Mute'}</span>`;
    }
  }

  // ── 10. Initialization ─────────────────────────────────────────────────────
  async function init() {
    // Start background order polling every 12 seconds
    if (_pollInterval) clearInterval(_pollInterval);
    _pollInterval = setInterval(() => {
      fetchOrders(true);
    }, 12000);

    // Initial silent check
    setTimeout(() => {
      fetchOrders(true);
    }, 2000);

    // Request desktop notification permission if supported
    if ('Notification' in window && Notification.permission === 'default') {
      try { Notification.requestPermission(); } catch (e) {}
    }
  }

  return {
    getConfig,
    resolveShopId,
    init,
    render,
    fetchOrders,
    updateOrderStatus,
    acceptAndPrepare,
    completeAndCloseOrder,
    reopenOrder,
    reactivateOrder,
    cancelOrderPrompt,
    loadOrderIntoPos,
    convertOrderToSale,
    printOrderSlip,
    printOrderSlipById,
    syncCatalogToCloud,
    syncSingleProductToCloud,
    deleteProductFromCloud,
    deleteCategoryFromCloud,
    applyDeletedProducts,
    applyDeletedCategories,
    pullCatalogFromCloud,
    pullCloudDelta,
    heartbeatBranchToCloud,
    fetchCloudConnectedBranches,
    fetchCloudSales,
    removeCloudConnectedBranch,
    syncPosSalesToCloud,
    clearCloudPosSales,
    clearCloudCatalog,
    syncCashboxStatusToCloud,
    fetchCloudCashboxes,
    syncCustomersToCloud,
    pullCustomersFromCloud,
    broadcastCloudUpdate,
    syncCloudTables,
    pullCloudTables,
    pullCloudStockUpdates,
    openSettingsModal,
    saveSettings,
    setFilter,
    toggleMute,
    playAlertChime,
    stopChimeLoop
  };
})();

// Attach globally
window.OnlineOrders = OnlineOrders;
