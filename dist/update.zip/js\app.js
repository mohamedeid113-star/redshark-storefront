/* ================================================================
   NexPOS — App Router & Bootstrap
   ================================================================ */

const App = (() => {

  let _currentPage = 'dashboard';
  let _sidebarCollapsed = false;

  const pageMap = {
    'dashboard':        { title: 'Dashboard',         module: 'Dashboard',   perm: 'dashboard',           breadcrumb: 'Red Shark POS › Dashboard' },
    'pos':              { title: 'Point of Sale',      module: 'POS',         perm: 'pos',                 breadcrumb: 'Red Shark POS › POS' },
    'deliveries':       { title: 'Retail Deliveries',  module: 'POS',         perm: 'deliveries',          breadcrumb: 'Point of Sale › Deliveries' },
    'quotation':        { title: 'Sales Quotation',    module: 'Sales',       perm: 'sales.quotation',     breadcrumb: 'Sales › Quotation' },
    'online-orders':    { title: 'Online Store Orders', module: 'OnlineOrders', perm: 'sales',               breadcrumb: 'Sales › Online Orders' },
    'sales-order':      { title: 'Sales Order',        module: 'Sales',       perm: 'sales',               breadcrumb: 'Sales › Order' },
    'delivery-order':   { title: 'Delivery Order',     module: 'Sales',       perm: 'sales',               breadcrumb: 'Sales › Delivery' },
    'sales-invoice':    { title: 'Sales Invoice',      module: 'Sales',       perm: 'sales.invoice',       breadcrumb: 'Sales › Invoice' },
    'sales-return':     { title: 'Sales Return',       module: 'Sales',       perm: 'sales.returns',       breadcrumb: 'Sales › Return' },
    'items':            { title: 'Items',              module: 'Items',       perm: 'items',               breadcrumb: 'Inventory › Items' },
    'categories':       { title: 'Categories',         module: 'Categories',  perm: 'categories',          breadcrumb: 'Inventory › Categories' },
    'offers':           { title: 'Offers & Deals',     module: 'Items',       perm: 'items',               breadcrumb: 'Products › Offers & Deals' },
    'stock-adjustment': { title: 'Stock Adjustment',   module: 'Inventory',   perm: 'inventory.adjust',    breadcrumb: 'Inventory › Adjustment' },
    'stock-movements':  { title: 'Stock Movements Ledger', module: 'Inventory', perm: 'inventory',        breadcrumb: 'Inventory › Stock Movements Ledger' },
    'damage':           { title: 'Damaged Items',      module: 'Inventory',   perm: 'inventory',           breadcrumb: 'Inventory › Damage' },
    'transfer':         { title: 'Stock Transfers',    module: 'Inventory',   perm: 'inventory.transfer',  breadcrumb: 'Inventory › Transfer' },
    'warehouses':       { title: 'Stores & Warehouses', module: 'Inventory',  perm: 'inventory',           breadcrumb: 'Inventory › Stores & Warehouses' },
    'barcode':          { title: 'Barcode Labels',     module: 'Inventory',   perm: 'inventory.barcode',   breadcrumb: 'Inventory › Barcode' },
    'customers':        { title: 'Customers',          module: 'Customers',   perm: 'customers',           breadcrumb: 'Sales › Customers' },
    'suppliers':        { title: 'Suppliers',          module: 'Suppliers',   perm: 'suppliers',           breadcrumb: 'Purchasing › Suppliers' },
    'purchase-order':   { title: 'Purchase Order',     module: 'Purchasing',  perm: 'purchasing.orders',   breadcrumb: 'Purchasing › PO' },
    'goods-receipt':    { title: 'Goods Receipt',      module: 'Purchasing',  perm: 'purchasing',          breadcrumb: 'Purchasing › GRN' },
    'purchase-invoice': { title: 'Purchase Invoice',   module: 'Purchasing',  perm: 'purchasing.invoices', breadcrumb: 'Purchasing › Invoice' },
    'purchase-return':  { title: 'Purchase Return',    module: 'Purchasing',  perm: 'purchasing',          breadcrumb: 'Purchasing › Return' },
    'accounts':         { title: 'Chart of Accounts',  module: 'Finance',     perm: 'finance.accounts',    breadcrumb: 'Finance › Accounts' },
    'journals':         { title: 'Journal Entries',    module: 'Finance',     perm: 'finance',             breadcrumb: 'Finance › Journals' },
    'cash':             { title: 'Cash Management',    module: 'Finance',     perm: 'finance',             breadcrumb: 'Finance › Cash' },
    'bank':             { title: 'Bank Management',    module: 'Finance',     perm: 'finance',             breadcrumb: 'Finance › Bank' },
    'customer-receipts':{ title: 'Customer Receipts',  module: 'Finance',     perm: 'finance',             breadcrumb: 'Finance › Receipts' },
    'supplier-payments':{ title: 'Supplier Payments',  module: 'Finance',     perm: 'finance',             breadcrumb: 'Finance › Payments' },
    'vat':              { title: 'VAT Management',     module: 'Finance',     perm: 'finance',             breadcrumb: 'Finance › VAT' },
    'fiscal-years':     { title: 'Fiscal Years & Year-End Closing', module: 'Finance', perm: 'finance', breadcrumb: 'Finance › Fiscal Years' },
    'employees':        { title: 'Employees',          module: 'HR',          perm: 'hr',                  breadcrumb: 'HR › Employees' },
    'attendance':       { title: 'Attendance',         module: 'HR',          perm: 'hr',                  breadcrumb: 'HR › Attendance' },
    'leave':            { title: 'Leave Management',   module: 'HR',          perm: 'hr',                  breadcrumb: 'HR › Leave' },
    'payroll':          { title: 'Payroll',            module: 'Payroll',     perm: 'payroll',             breadcrumb: 'HR › Payroll' },
    'eosg':             { title: 'End of Service',     module: 'HR',          perm: 'hr',                  breadcrumb: 'HR › EOSG' },
    'reports':          { title: 'Reports',            module: 'Reports',     perm: 'reports',             breadcrumb: 'Red Shark POS › Reports' },
    'reports-analytics':{ title: 'Analytics & Graphs', module: 'Reports',     perm: 'reports',             breadcrumb: 'Reports › Visual Analytics' },
    'rep-sales':        { title: 'Sales Reports',      module: 'Reports',     perm: 'reports.sales',       breadcrumb: 'Reports › Sales' },
    'rep-stock':        { title: 'Stock Reports',      module: 'Reports',     perm: 'reports.stock',       breadcrumb: 'Reports › Stock' },
    'rep-pl':           { title: 'P&L Statement',      module: 'Reports',     perm: 'reports.pl',          breadcrumb: 'Reports › P&L' },
    'pos':              { title: 'Point of Sale',      module: 'POS',         perm: 'pos',                 breadcrumb: 'Sales › Point of Sale' },
    'cashbox':          { title: 'Cash Box',           module: 'CashBox',     perm: 'finance.cashbox',     breadcrumb: 'Cash Box › Current Shift' },
    'box-management':   { title: 'Box Management',     module: 'CashBox',     perm: 'finance.cashbox',     breadcrumb: 'Cash Box › Management' },
    'cashbox_management': { title: 'Box Management',   module: 'CashBox',     perm: 'finance.cashbox',     breadcrumb: 'Cash Box › Management' },
    'cash-reports':     { title: 'Cash Reports',       module: 'CashBox',     perm: 'finance.cashbox',     breadcrumb: 'Cash Box › Reports' },
    'users':            { title: 'Users',              module: 'Admin',       perm: 'admin.users',         breadcrumb: 'Admin › Users' },
    'roles':            { title: 'Roles & Privileges', module: 'Admin',       perm: 'admin.roles',         breadcrumb: 'Admin › Roles' },
    'settings':         { title: 'Settings',           module: 'Admin',       perm: 'admin.settings',      breadcrumb: 'Admin › Settings' },
    'invoice-designer': { title: 'Invoice Designer',   module: 'Admin',       perm: 'admin',               breadcrumb: 'Admin › Invoice Designer' },
    'backup':           { title: 'Backup & Restore',   module: 'Admin',       perm: 'admin',               breadcrumb: 'Admin › Backup & Maintenance' },
    'audit-log':        { title: 'Audit Log',          module: 'Admin',       perm: 'admin',               breadcrumb: 'Admin › Audit Log' },
    'multi-pos':        { title: 'Multi-POS & Branches', module: 'Admin',     perm: 'admin',               breadcrumb: 'Admin › Multi-POS & Branches' },
    'repairs':          { title: 'Repair & Workshop Tickets', module: 'Repairs', perm: 'sales',           breadcrumb: 'Services › Repairs & Workshop' },
    'customer-statement': { title: 'Customer Statement', module: 'Reports', perm: 'reports', breadcrumb: 'Reports › Customer Statement' },
    'supplier-statement': { title: 'Supplier Statement', module: 'Reports', perm: 'reports', breadcrumb: 'Reports › Supplier Statement' },
  };

  async function applyUserPermissions() {
    const user = Auth.getUser();
    if (!user) return;
    const isSuper = Auth.isAdmin();

    try {
      const bMode = (typeof License !== 'undefined' && typeof License.getBusinessMode === 'function') 
        ? await License.getBusinessMode() 
        : 'retail';


      // 1. Filter each direct leaf nav item in sidebar and submenus
      for (const item of document.querySelectorAll('.sidebar-nav .nav-item')) {
        let page = item.getAttribute('data-page');
        if (!page) {
          const onclickAttr = item.getAttribute('onclick') || '';
          const match = onclickAttr.match(/navigate\('([^']+)'\)/);
          if (match) page = match[1];
        }

        // Ignore parent toggle items for now (handled in next step)
        if (page && (page.endsWith('-parent') || page.startsWith('sub-'))) {
          continue;
        }

        if (page) {
          const info = pageMap[page];
          const perm = info?.perm || page;
          const rbacAllowed = isSuper || (page === 'dashboard' ? (Auth.can('dashboard') || Auth.can('reports')) : Auth.can(perm));
          let licAllowed = true;
          try {
            if (window.License && typeof License.checkRouteAccess === 'function') {
              licAllowed = await License.checkRouteAccess(page, info?.module);
            }
          } catch(e) {
            licAllowed = true;
          }

          const allowed = rbacAllowed && licAllowed;
          item.style.display = allowed ? '' : 'none';
        }
      }

      // 2. Filter submenus & parent toggle items
      document.querySelectorAll('.sidebar-nav .nav-submenu').forEach(submenu => {
        const subItems = Array.from(submenu.querySelectorAll('.nav-item'));
        const visibleSubItems = subItems.filter(el => el.style.display !== 'none');
        const parentToggle = submenu.previousElementSibling;

        if (visibleSubItems.length === 0) {
          submenu.style.display = 'none';
          if (parentToggle && parentToggle.classList.contains('nav-item')) {
            parentToggle.style.display = 'none';
          }
        } else {
          if (parentToggle && parentToggle.classList.contains('nav-item')) {
            parentToggle.style.display = '';
          }
        }
      });

      // 3. Filter nav groups (hide group if all its items and submenus are hidden)
      document.querySelectorAll('.sidebar-nav .nav-group').forEach(group => {
        const visibleItems = Array.from(group.querySelectorAll('.nav-item')).filter(el => el.style.display !== 'none');
        if (visibleItems.length === 0) {
          group.style.display = 'none';
        } else {
          group.style.display = '';
        }
      });

      // Topbar deliveries quick button permission check
      const topDelivBtn = document.getElementById('btn-topbar-deliveries');
      if (topDelivBtn) {
        topDelivBtn.style.display = (isSuper || Auth.can('deliveries')) ? 'flex' : 'none';
      }
    } catch(err) {
      console.warn('applyUserPermissions error:', err);
    } finally {
      // Reveal sidebar cleanly once all permission filters have executed
      document.getElementById('sidebar-nav')?.classList.add('ready');
    }
  }

  function updateDollarRateDisplay() {
    const rate = window._exchangeRate || 89500;
    const cur1 = window._primaryCurrency || 'USD';
    const cur2 = window._secondaryCurrency || 'LBP';
    const rateStr = (window.Utils && typeof Utils.formatCurrency === 'function') 
      ? Utils.formatCurrency(rate, '', 0) 
      : Number(rate).toLocaleString();
    
    const isLbp1 = window.Utils && Utils.isLbp ? Utils.isLbp(cur1) : (cur1 === 'LBP' || cur1 === 'LL' || cur1 === 'L.L.');
    const isLbp2 = window.Utils && Utils.isLbp ? Utils.isLbp(cur2) : (cur2 === 'LBP' || cur2 === 'LL' || cur2 === 'L.L.');
    const isUsd1 = window.Utils && Utils.isUsd ? Utils.isUsd(cur1) : (cur1 === 'USD' || cur1 === '$');
    const isUsd2 = window.Utils && Utils.isUsd ? Utils.isUsd(cur2) : (cur2 === 'USD' || cur2 === '$');

    let displayStr = '';
    if ((isUsd1 && isLbp2) || (isLbp1 && isUsd2)) {
      const localLabel = isLbp1 ? (cur1 === 'LL' ? 'LL' : 'L.L.') : (cur2 === 'LL' ? 'LL' : 'L.L.');
      displayStr = `$1 = ${rateStr} ${localLabel}`;
    } else if (isUsd2 && rate > 1) {
      displayStr = `$1 = ${rateStr} ${cur1}`;
    } else if (isUsd1 && rate > 1) {
      displayStr = `$1 = ${rateStr} ${cur2}`;
    } else {
      displayStr = `1 ${cur1} = ${rateStr} ${cur2}`;
    }
    
    const topbarRate = document.getElementById('topbar-rate-display');
    if (topbarRate) topbarRate.textContent = displayStr;

    const posRate = document.getElementById('pos-cockpit-rate-display');
    if (posRate) posRate.textContent = displayStr;
  }
  window.updateDollarRateDisplay = updateDollarRateDisplay;

  async function applyUIVisibility() {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await DB.getSetting('ui_visibility_settings', {
        show_ai_copilot: true,
        show_mobile_app: true,
        show_price_check: true,
        show_online_orders: true,
        show_exchange_rate: true,
        show_clock: true,
        show_card_payment: true,
        show_mobile_scan: true
      });

      const setDisplay = (id, show) => {
        const el = document.getElementById(id);
        if (el) {
          if (show !== false) {
            el.style.removeProperty('display');
            el.removeAttribute('data-ui-hidden');
            el.classList.remove('hidden-by-setting');
          } else {
            el.style.setProperty('display', 'none', 'important');
            el.setAttribute('data-ui-hidden', 'true');
            el.classList.add('hidden-by-setting');
          }
        }
      };

      setDisplay('btn-topbar-ai-copilot', cfg.show_ai_copilot);
      setDisplay('btn-topbar-mobile-app', cfg.show_mobile_app);
      setDisplay('btn-topbar-price-check', cfg.show_price_check);
      setDisplay('btn-topbar-online-orders', cfg.show_online_orders);
      setDisplay('topbar-rate-pill', cfg.show_exchange_rate);
      setDisplay('topbar-clock-pill', cfg.show_clock);
      setDisplay('pm-card', cfg.show_card_payment);

      // Camera scan buttons across app
      document.querySelectorAll('.btn-camera-scan, [data-feature="mobile-scan"]').forEach(el => {
        if (cfg.show_mobile_scan !== false) {
          el.style.removeProperty('display');
          el.classList.remove('hidden-by-setting');
        } else {
          el.style.setProperty('display', 'none', 'important');
          el.classList.add('hidden-by-setting');
        }
      });

      // Also sidebar menu item for online orders if disabled
      const onlineOrdersNav = document.querySelector('[data-page="online-orders"]');
      if (onlineOrdersNav) {
        if (cfg.show_online_orders === false) {
          onlineOrdersNav.style.setProperty('display', 'none', 'important');
          onlineOrdersNav.classList.add('hidden-by-setting');
        } else {
          onlineOrdersNav.style.removeProperty('display');
          onlineOrdersNav.classList.remove('hidden-by-setting');
        }
      }
    } catch (e) {
      console.warn('Could not apply UI visibility:', e);
    }
  }

  async function loadGlobalSettings() {
    window._primaryCurrency   = await DB.getSetting('currency_1', 'USD');
    window._secondaryCurrency = await DB.getSetting('currency_2', 'LBP');
    window._exchangeRate      = await DB.getSetting('exchange_rate', 89500);
    updateDollarRateDisplay();
  }

  async function init() {
    if (!Auth.requireAuth()) return;
    
    // 1. Initialize language and translations FIRST so UI renders in correct language immediately
    await i18n.init();

    const activeTenant = new URLSearchParams(window.location.search).get('tenant') 
      || localStorage.getItem('redshark_active_tenant') 
      || (Auth.getUser()?.tenant_slug) 
      || 'default';
    await DB.open(activeTenant);
    await DB.seed();
    await loadGlobalSettings();
    await applyUIVisibility();
    if (Auth.loadRolesCache) await Auth.loadRolesCache();

    // Clean up any legacy restaurant printers from IndexedDB to guarantee pure stable retail mode
    try {
      const legacyKPs = await DB.getAll('kitchen_printers');
      for (const kp of (legacyKPs || [])) {
        await DB.remove('kitchen_printers', kp.id);
      }
    } catch(e) {}

    // Auto-clean any duplicate zombie stores & consolidate into the two authoritative stores
    try {
      if (window.InventoryMgr && typeof InventoryMgr.cleanupDuplicateWarehouses === 'function') {
        await InventoryMgr.cleanupDuplicateWarehouses();
      }
    } catch(e) {}

    // Background Multi-Device Cloud Sync (ONLY if Supabase provider is explicitly enabled)
    if (typeof CloudSync !== 'undefined') {
      (async () => {
        try {
          const provider = (await DB.getSetting('online_store_provider', 'direct')) || 'direct';
          if (provider === 'cloud') {
            const tid = await CloudSync.getTenantId();
            if (tid) {
              await CloudSync.pullTenantData(tid, activeTenant);
              await CloudSync.syncAllLocalItems();
            }
          }
        } catch (syncErr) {
          console.warn('Auto CloudSync startup error:', syncErr);
        }
      })();
    }

    // Mount AI Copilot if enabled by License
    const hasAI = await License.hasFeature('AI_Copilot');
    if (hasAI && window.AICopilot && typeof AICopilot.mountWidget === 'function') {
      AICopilot.mountWidget();
    }

    // Apply saved theme (priority to localStorage for instant response)
    const theme = localStorage.getItem('nexpos_theme') || await DB.getSetting('theme', 'light');
    setTheme(theme);

    // Apply saved font scale (priority to localStorage for instant response)
    const fontScale = localStorage.getItem('nexpos_font_scale') || await DB.getSetting('app_font_scale', 100);
    setFontScale(fontScale);

    // Apply user info to topbar & dropdown
    const user = Auth.getUser();
    if (user) {
      const nameEl = document.getElementById('user-name-display');
      if (nameEl) nameEl.textContent = user.full_name || user.username || 'User';
      
      const roleEl = document.getElementById('user-role-display');
      if (roleEl) roleEl.textContent = (user.role || 'User').toUpperCase();
      
      const avatarEl = document.getElementById('user-avatar');
      if (avatarEl) {
        const initial = (user.full_name || user.username || 'U')[0].toUpperCase();
        avatarEl.textContent = initial;
      }

      const menuNameEl = document.getElementById('user-menu-name');
      if (menuNameEl) menuNameEl.textContent = user.full_name || user.username || 'User';

      const menuEmailEl = document.getElementById('user-menu-email');
      if (menuEmailEl) menuEmailEl.textContent = user.email || `${user.username}@redsharkpos.com`;
    }

    // Apply dynamic permission filtering to sidebar navigation
    await applyUserPermissions();

    // Check Demo Trial Expiry — ONLY show countdown pill for active demo trials, NEVER on licensed devices!
    const licStatus = await License.getStatus();
    const existingPill = document.getElementById('demo-trial-pill');

    if (licStatus.status === 'demo_trial') {
      const isDemo = await DB.getSetting('demo_trial_active', false);
      const expiresAt = await DB.getSetting('demo_expires_at', null);
      if (isDemo && expiresAt) {
        const remainingMs = new Date(expiresAt).getTime() - Date.now();
        const remainingDays = Math.max(0, Math.ceil(remainingMs / (1000 * 60 * 60 * 24)));
        const isAR = i18n.getLang() === 'ar';
        const topbarRight = document.querySelector('.topbar-right');
        if (topbarRight && !existingPill) {
          const pill = document.createElement('div');
          pill.id = 'demo-trial-pill';
          pill.style.cssText = 'background:rgba(245,158,11,0.15);border:1px solid rgba(245,158,11,0.35);color:var(--warning);padding:4px 10px;border-radius:20px;font-size:0.72rem;font-weight:800;display:flex;align-items:center;gap:4px';
          pill.innerHTML = `⏳ ${remainingDays > 0 ? (isAR ? `تجربة مجانية: متبقي ${remainingDays} يوم` : `${remainingDays} Days Demo Trial`) : (isAR ? 'انتهت التجربة' : 'Trial Expired')}`;
          topbarRight.prepend(pill);
        }
      } else if (existingPill) {
        existingPill.remove();
      }
    } else {
      // Licensed device or evaluation: hide trial pill completely
      if (existingPill) {
        existingPill.remove();
      }
    }

    // Init utils
    Utils.initDropdowns();

    // Sync App Version & Build display in sidebar footer
    try {
      const verRes = await fetch('version.json?_t=' + Date.now());
      if (verRes.ok) {
        const verData = await verRes.json();
        const verEl = document.getElementById('sidebar-app-version');
        if (verEl && verData.version) verEl.textContent = verData.version;
        const buildEl = document.getElementById('sidebar-app-build');
        if (buildEl && verData.build) buildEl.textContent = `Build ${verData.build}`;
      } else if (window.License && License.APP_VERSION) {
        const verEl = document.getElementById('sidebar-app-version');
        if (verEl) verEl.textContent = License.APP_VERSION;
      }
    } catch(e) {
      if (window.License && License.APP_VERSION) {
        const verEl = document.getElementById('sidebar-app-version');
        if (verEl) verEl.textContent = License.APP_VERSION;
      }
    }

    // Sync Live Exchange Rate to Topbar Cockpit Pill
    const topbarRateEl = document.getElementById('topbar-exch-rate');
    if (topbarRateEl && window._exchangeRate) {
      topbarRateEl.textContent = Number(window._exchangeRate).toLocaleString();
    }

    // Start continuous live English clock in topbar (Always strictly English locale)
    function _tickGlobalClock() {
      const timeEl = document.getElementById('topbar-live-time');
      const dateEl = document.getElementById('topbar-live-date');
      if (!timeEl && !dateEl) return;
      const now = new Date();
      if (timeEl) {
        timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
      }
      if (dateEl) {
        dateEl.textContent = now.toLocaleDateString('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
      }
    }
    _tickGlobalClock();
    setInterval(_tickGlobalClock, 1000);

    // Start Multi-POS & Branch Real-time Sync listener
    if (window.BranchSync && typeof BranchSync.startListener === 'function') {
      try { BranchSync.startListener(); } catch(e) {}
    }

    // Navigate to hash or mode-based starting page
    let hash = location.hash.replace('#', '') || '';
    const bMode = (typeof License !== 'undefined' && typeof License.getBusinessMode === 'function') 
      ? await License.getBusinessMode() 
      : await DB.getSetting('business_mode', 'retail');

    if (!hash || (hash === 'dashboard' && !Auth.can('dashboard') && !Auth.isAdmin())) {
      hash = Auth.getFirstAllowedPage();
    }
    navigate(hash);

    // Initialize Online Orders background listener & badge counter
    if (window.OnlineOrders && typeof OnlineOrders.init === 'function') {
      try { OnlineOrders.init(); } catch (e) { console.warn('[App] OnlineOrders init note:', e); }
    }

    // Initialize Deliveries badge counter
    if (window.Deliveries && typeof Deliveries.updateSidebarBadge === 'function') {
      try { Deliveries.updateSidebarBadge(); } catch (e) { console.warn('[App] Deliveries updateSidebarBadge note:', e); }
    }

    // Handle browser back/forward and navigation
    window.addEventListener('hashchange', () => {
      const p = location.hash.replace('#', '');
      if (p) navigate(p, false);
    });
  }

  function navigate(page, pushState = true) {
    closeSidebar();
    if (!pageMap[page]) {
      page = Auth.getFirstAllowedPage();
    }
    _currentPage = page;

    if (pushState) location.hash = page;

    // Toggle POS Cockpit distraction-free full-width mode
    const isCockpit = (page === 'pos');
    document.body.classList.toggle('pos-cockpit-mode', isCockpit);
    document.documentElement.classList.toggle('pos-cockpit-mode', isCockpit);

    // Auto-close sidebar drawer on mobile upon navigation
    if (window.innerWidth <= 992) {
      closeSidebar();
    }

    // Update topbar
    const info = pageMap[page] || { title: page, breadcrumb: page };
    document.getElementById('page-title').textContent      = info.title;
    document.getElementById('page-breadcrumb').textContent = info.breadcrumb;
    document.title = `${info.title} — Red Shark POS`;

    // Update active nav item
    document.querySelectorAll('.nav-item[data-page]').forEach(el => el.classList.remove('active'));
    const activeEl = document.querySelector(`.nav-item[data-page="${page}"]`);
    if (activeEl) activeEl.classList.add('active');

    // Update active topbar cockpit nav pill
    document.querySelectorAll('.topbar-nav-btn').forEach(el => el.classList.remove('active'));
    const activeTopBtn = document.querySelector(`.topbar-nav-btn[data-page="${page}"]`);
    if (activeTopBtn) activeTopBtn.classList.add('active');

    // Render page
    renderPage(page);
  }

  async function renderPage(page) {
    await loadGlobalSettings();
    const content = document.getElementById('page-content');
    content.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;height:200px">
      <div class="spinner"></div>
    </div>`;

    try {
      const info = pageMap[page] || { module: '', perm: page };
      const isAR = i18n.getLang() === 'ar';
      const topMenuLabel = document.getElementById('topbar-main-menu-label');
      if (topMenuLabel) topMenuLabel.textContent = isAR ? 'القائمة الرئيسية' : 'Main Menu';

      // 1. Check User RBAC Permission
      const isSuper = Auth.isAdmin();
      const hasPerm = isSuper || (info.perm === 'dashboard' ? (Auth.can('dashboard') || Auth.can('reports')) : Auth.can(info.perm));
      if (!hasPerm) {
        const allowedPage = Auth.getFirstAllowedPage();
        content.innerHTML = `
        <div class="animate-slide" style="max-width:540px;margin:60px auto;text-align:center">
          <div class="card" style="padding:40px;border-radius:15px;box-shadow:0 10px 25px rgba(0,0,0,0.15);border:1px solid var(--border-color)">
            <div style="font-size:3.5rem;margin-bottom:16px">🚫</div>
            <h2 style="font-weight:800;font-size:1.3rem;margin-bottom:10px;color:var(--danger)">
              ${isAR ? 'غير مصرح لك بالوصول لهذا القسم' : 'Access Restricted / Unauthorized'}
            </h2>
            <p style="font-size:0.86rem;color:var(--text-secondary);line-height:1.6;margin-bottom:24px">
              ${isAR ? `حسابك (${Auth.getUser()?.username}) ذو الدور (${Auth.getUser()?.role}) لا يمتلك الصلاحيات الكافية لعرض هذا القسم.` : `Your user account (${Auth.getUser()?.username}) with role (${Auth.getUser()?.role}) does not have permission to view this section.`}
            </p>
            <div style="display:flex;gap:12px;justify-content:center">
              <button class="btn btn-primary" onclick="App.navigate('${allowedPage}')">
                🔙 ${isAR ? 'الذهاب للقسم المتاح' : 'Go to Allowed Section'}
              </button>
            </div>
          </div>
        </div>`;
        return;
      }

      // 2. Check License Route Access
      const isAllowed = await License.checkRouteAccess(page, info.module);

      if (!isAllowed) {
        const allowedPage = Auth.getFirstAllowedPage();
        content.innerHTML = `
        <div class="animate-slide" style="max-width:540px;margin:60px auto;text-align:center">
          <div class="card" style="padding:40px;border-radius:15px;box-shadow:0 10px 25px rgba(0,0,0,0.15);border:1px solid var(--border-color)">
            <div style="font-size:3.5rem;margin-bottom:16px">🔒</div>
            <h2 style="font-weight:800;font-size:1.3rem;margin-bottom:10px;color:var(--warning)">
              ${isAR ? 'هذه الميزة غير مفعلة في ترخيصك' : 'Module Not Included in Current License'}
            </h2>
            <p style="font-size:0.86rem;color:var(--text-secondary);line-height:1.6;margin-bottom:24px">
              ${isAR ? `باقة ترخيصك الحالية لا تشمل قسم (${info.title}). يمكنك ترقية الترخيص ليشمل هذه الميزة.` : `Your current license plan does not include access to (${info.title}).`}
            </p>
            <div style="display:flex;gap:12px;justify-content:center">
              <button class="btn btn-primary" onclick="App.navigate('${allowedPage}')">
                🔙 ${isAR ? 'الذهاب للقسم المتاح' : 'Go to Allowed Section'}
              </button>
            </div>
          </div>
        </div>`;
        return;
      }

      switch(page) {
        case 'dashboard':        await Dashboard.render(content); break;
        case 'pos':              await POS.render(content);       break;
        case 'deliveries':       await Deliveries.render(content); break;
        case 'items':            await Items.render(content);     break;
        case 'categories':       await Categories.render(content); break;
        case 'offers':           await Offers.render(content);     break;
        case 'customers':        await Customers.render(content); break;
        case 'suppliers':        await Suppliers.render(content); break;
        case 'purchase-order':   await Purchasing.renderPO(content); break;
        case 'goods-receipt':    await Purchasing.renderGRN(content); break;
        case 'purchase-invoice': await Purchasing.renderInvoice(content); break;
        case 'purchase-return':  await Purchasing.renderReturn(content); break;
        case 'stock-adjustment': await InventoryMgr.renderAdjustment(content, 'adjustments'); break;
        case 'stock-movements':  await InventoryMgr.renderAdjustment(content, 'movements'); break;
        case 'damage':           await InventoryMgr.renderDamage(content); break;
        case 'transfer':         await InventoryMgr.renderTransfer(content); break;
        case 'warehouses':       await InventoryMgr.renderWarehouses(content); break;
        case 'barcode':          await InventoryMgr.renderBarcode(content); break;
        case 'quotation':        await SalesModule.renderQuotation(content); break;
        case 'sales-order':      await SalesModule.renderOrder(content); break;
        case 'delivery-order':   await SalesModule.renderDelivery(content); break;
        case 'online-orders':    await OnlineOrders.render(content); break;
        case 'sales-invoice':    await SalesModule.renderInvoice(content); break;
        case 'sales-return':     await SalesModule.renderReturn(content); break;
        case 'accounts':         await Finance.renderAccounts(content); break;
        case 'journals':         await Finance.renderJournals(content); break;
        case 'cash':             await Finance.renderCash(content); break;
        case 'bank':             await Finance.renderBank(content); break;
        case 'customer-receipts':await Finance.renderCustomerReceipts(content); break;
        case 'supplier-payments':await Finance.renderSupplierPayments(content); break;
        case 'vat':              await Finance.renderVAT(content); break;
        case 'fiscal-years':     await Finance.renderFiscalYears(content); break;
        case 'employees':        await HR.renderEmployees(content); break;
        case 'attendance':       await HR.renderAttendance(content); break;
        case 'leave':            await HR.renderLeave(content); break;
        case 'payroll':          await Payroll.render(content); break;
        case 'eosg':             await HR.renderEOSG(content); break;
        case 'reports':          await Reports.render(content); break;
        case 'reports-analytics':await Reports.renderAnalyticsGraphs(content); break;
        case 'rep-sales':        await Reports.renderSalesReport(content); break;
        case 'rep-stock':        await Reports.renderStockReport(content); break;
        case 'rep-pl':           await Reports.renderPLReport(content); break;
        case 'cashbox':          await CashBox.render(content); break;
        case 'box-management':   await CashBox.renderManagement(content); break;
        case 'cashbox_management': await CashBox.renderManagement(content); break;
        case 'cash-reports':     await CashBox.renderReports(content); break;
        case 'users':            await Admin.renderUsers(content); break;
        case 'roles':            await Admin.renderRoles(content); break;
        case 'settings':         await Admin.renderSettings(content); break;
        case 'invoice-designer': await Admin.renderInvoiceDesigner(content); break;
        case 'backup':           await Admin.renderBackup(content); break;
        case 'audit-log':        await Admin.renderAuditLog(content); break;
        case 'multi-pos':        await BranchSync.render(content); break;
        case 'repairs':          await RepairsModule.render(content); break;
        case 'customer-statement': await Reports.renderCustomerLedger(content); break;
        case 'supplier-statement': await Reports.renderSupplierLedger(content); break;
        default:
          content.innerHTML = `<div class="empty-state"><p>Page not found: ${page}</p></div>`;
      }

      // Auto-enable universal DataGrid column sorting for all tables on the page
      setTimeout(() => {
        try {
          if (window.Utils && typeof Utils.makeTableSortable === 'function') {
            document.querySelectorAll('.table-wrapper table, table').forEach(tbl => {
              if (tbl && !tbl.dataset.sortInitialized) {
                Utils.makeTableSortable(tbl);
                tbl.dataset.sortInitialized = 'true';
              }
            });
          }
        } catch(e) {
          console.warn('Table sort initializer error:', e);
        }
      }, 100);
    } catch(err) {
      console.error('Page render error:', err);
      content.innerHTML = `<div class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>
        </svg>
        <h3>Error loading page</h3>
        <p>${err.message}</p>
      </div>`;
    }
  }

  function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    if (!sidebar) return;

    if (window.innerWidth <= 992) {
      const isOpen = sidebar.classList.contains('open');
      sidebar.classList.toggle('open', !isOpen);
      if (backdrop) backdrop.classList.toggle('active', !isOpen);
    } else {
      _sidebarCollapsed = !_sidebarCollapsed;
      sidebar.classList.toggle('collapsed', _sidebarCollapsed);
    }
  }

  function goToMainMenu() {
    const user = Auth.getUser();
    if (!user) {
      location.href = 'login.html';
      return;
    }
    closeSidebar();
    navigate('dashboard');
  }

  function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    if (sidebar) sidebar.classList.remove('open');
    if (backdrop) backdrop.classList.remove('active');
  }

  function toggleSubmenu(id, navItem) {
    const submenu = document.getElementById(id);
    if (!submenu) return;
    const isOpen = submenu.classList.contains('open');
    // Close all other submenus
    document.querySelectorAll('.nav-submenu.open').forEach(s => { if (s.id !== id) s.classList.remove('open'); });
    document.querySelectorAll('.nav-item.open').forEach(n => { if (n !== navItem) n.classList.remove('open'); });
    submenu.classList.toggle('open', !isOpen);
    navItem.classList.toggle('open', !isOpen);
  }

  const THEMES_LIST = ['dark', 'light', 'gray', 'ocean', 'emerald', 'warm'];

  const THEME_NAMES = {
    dark:    { icon: '🌙', ar: 'داكن ملكي (Obsidian)', en: 'Dark Obsidian' },
    light:   { icon: '☀️', ar: 'فاتح ناصع (Pure White)', en: 'Pure White Light' },
    gray:    { icon: '🏢', ar: 'رمادي هادئ (Slate Gray)', en: 'Slate Gray Anti-Glare' },
    ocean:   { icon: '🌊', ar: 'سماوي نهاري (Sky Blue)', en: 'Sky Blue Ocean' },
    emerald: { icon: '🌿', ar: 'أخضر زمردي منعش (Sage Mint)', en: 'Sage Mint Fresh' },
    warm:    { icon: '🏜️', ar: 'بيج كشمير دافئ (Warm Sand)', en: 'Warm Sand Ivory' }
  };

  function setTheme(theme) {
    if (theme === 'white-gray') theme = 'gray';
    if (!THEMES_LIST.includes(theme)) theme = 'dark';

    document.documentElement.setAttribute('data-theme', theme);
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('nexpos_theme', theme);

    const darkIcons = document.querySelectorAll('#theme-icon-dark, .theme-icon-dark');
    const grayIcons = document.querySelectorAll('#theme-icon-gray, .theme-icon-gray');
    const lightIcons = document.querySelectorAll('#theme-icon-light, .theme-icon-light');

    darkIcons.forEach(el => el.style.display = theme === 'dark' ? '' : 'none');
    grayIcons.forEach(el => el.style.display = theme === 'gray' ? '' : 'none');
    lightIcons.forEach(el => el.style.display = (theme !== 'dark' && theme !== 'gray') ? '' : 'none');

    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const info = THEME_NAMES[theme] || THEME_NAMES.dark;

    const cockpitBtn = document.getElementById('pos-cockpit-theme-btn');
    if (cockpitBtn) {
      cockpitBtn.textContent = info.icon;
      cockpitBtn.title = isAR 
        ? `المظهر الحالي: ${info.ar} (انقر للتغيير)` 
        : `Theme: ${info.en} (Click to change)`;
    }

    const topbarBtn = document.getElementById('btn-theme-toggle');
    if (topbarBtn) {
      topbarBtn.title = isAR 
        ? `مظهر النظام: ${info.icon} ${info.ar} (انقر للتبديل)` 
        : `System Theme: ${info.icon} ${info.en} (Click to switch)`;
    }
  }

  function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || localStorage.getItem('nexpos_theme') || 'dark';
    const norm = (current === 'white-gray') ? 'gray' : current;
    const idx = THEMES_LIST.indexOf(norm);
    const next = THEMES_LIST[(idx + 1) % THEMES_LIST.length];

    setTheme(next);
    DB.setSetting('theme', next);

    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const info = THEME_NAMES[next] || THEME_NAMES.dark;
    const toastMsg = isAR 
      ? `${info.icon} تم تفعيل المظهر: ${info.ar}` 
      : `${info.icon} Theme activated: ${info.en}`;
    Utils.toast(toastMsg, 'info');
  }

  function setFontScale(percent) {
    let val = parseInt(percent, 10);
    if (isNaN(val) || val < 75 || val > 150) val = 100;

    // Base root font-size in main.css is 14px
    const basePx = 14;
    const computedPx = (basePx * (val / 100)).toFixed(2);
    document.documentElement.style.fontSize = `${computedPx}px`;
    document.documentElement.style.setProperty('--app-font-scale', `${val}%`);

    localStorage.setItem('nexpos_font_scale', val);
    if (typeof DB !== 'undefined' && typeof DB.setSetting === 'function') {
      DB.setSetting('app_font_scale', val);
    }
  }

  function getFontScale() {
    const saved = localStorage.getItem('nexpos_font_scale');
    if (saved) return parseInt(saved, 10) || 100;
    return 100;
  }

  async function toggleLang() {
    const current = i18n.getLang();
    const next    = current === 'en' ? 'ar' : 'en';
    await i18n.setLang(next);
    DB.setSetting('lang', next);
    Utils.toast(next === 'ar' ? 'تم التبديل إلى العربية' : 'Switched to English', 'info');
    // Re-render current page
    renderPage(_currentPage);
  }

  function toggleUserMenu(e) {
    if (e) {
      if (typeof e.preventDefault === 'function') e.preventDefault();
      if (typeof e.stopPropagation === 'function') e.stopPropagation();
    }
    const dropdown = document.getElementById('user-dropdown');
    const menu = document.getElementById('user-menu');
    if (!dropdown || !menu) return;
    const isCurrentlyOpen = dropdown.classList.contains('open') || menu.classList.contains('open') || menu.style.display === 'block';
    
    // Close other dropdowns
    document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('open'));
    document.querySelectorAll('.dropdown-menu').forEach(m => {
      m.classList.remove('open');
      m.style.display = 'none';
    });

    if (!isCurrentlyOpen) {
      dropdown.classList.add('open');
      menu.classList.add('open');
      menu.style.display = 'block';
    }
  }

  function toggleNotif(e) {
    if (e) {
      if (typeof e.preventDefault === 'function') e.preventDefault();
      if (typeof e.stopPropagation === 'function') e.stopPropagation();
    }
    const dropdown = document.getElementById('notif-dropdown');
    const menu = document.getElementById('notif-menu');
    if (!dropdown || !menu) return;
    const isCurrentlyOpen = dropdown.classList.contains('open') || menu.classList.contains('open') || menu.style.display === 'block';
    
    // Close other dropdowns
    document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('open'));
    document.querySelectorAll('.dropdown-menu').forEach(m => {
      m.classList.remove('open');
      m.style.display = 'none';
    });

    if (!isCurrentlyOpen) {
      dropdown.classList.add('open');
      menu.classList.add('open');
      menu.style.display = 'block';
    }
  }

  async function showAboutModal() {
    const isAR = i18n.getLang() === 'ar';
    const status = await License.getStatus();
    const machineId = await License.getMachineId();
    
    let licInfoHTML = '';
    if (status.status === 'active' && status.data) {
      licInfoHTML = `
        <div style="background:rgba(16,185,129,0.1);border:1px solid var(--success);border-radius:10px;padding:12px;margin-top:10px;text-align:left">
          <div style="font-weight:700;color:var(--success);margin-bottom:4px">✓ ${isAR?'مرخص ونشط':'Licensed & Active'}</div>
          <div style="font-size:0.75rem;color:var(--text-secondary)">${isAR?'مرخص لـ:':'Licensed To:'} <strong>${Utils.sanitize(status.data.client_name)}</strong></div>
          <div style="font-size:0.75rem;color:var(--text-secondary)">${isAR?'تاريخ الانتهاء:':'Expires On:'} <strong>${status.data.expiry_date}</strong></div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px;display:flex;flex-wrap:wrap;gap:4px">
            ${(status.data.allowed_modules || []).map(m => `<span class="badge badge-secondary">${m}</span>`).join('')}
          </div>
        </div>
      `;
    } else {
      let label = isAR ? 'غير مرخص / تجريبي' : 'Unlicensed / Trial';
      let color = 'var(--danger)';
      if (status.status === 'expired') {
        label = isAR ? 'منتهي الصلاحية' : 'Expired';
      }
      licInfoHTML = `
        <div style="background:rgba(239,68,68,0.1);border:1px solid ${color};border-radius:10px;padding:12px;margin-top:10px;text-align:left">
          <div style="font-weight:700;color:${color};margin-bottom:4px">⚠️ ${label}</div>
          <p style="font-size:0.75rem;color:var(--text-secondary);margin:0">${isAR?'يرجى التوجه إلى شاشة إعدادات الترخيص لتنشيط النظام.':'Please go to License settings to activate the software.'}</p>
        </div>
      `;
    }

    const modalId = 'about-system-modal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const modalEl = document.createElement('div');
    modalEl.className = 'modal-overlay';
    modalEl.id = modalId;
    modalEl.style.display = 'flex';
    
    modalEl.innerHTML = `
      <div class="modal" style="max-width:440px;text-align:center;padding:24px">
        <div class="modal-header" style="justify-content:center;position:relative">
          <div style="display:flex;align-items:center;justify-content:center;margin:10px auto 0">
            <img src="assets/red_shark_icon.png" style="width:72px;height:72px;object-fit:contain;filter:drop-shadow(0 6px 16px rgba(239,68,68,0.4))">
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('${modalId}')" style="position:absolute;top:0;right:0">✕</button>
        </div>
        <div style="margin-top:15px">
          <h3 style="font-size:1.3rem;font-weight:800;margin:0"><span style="color:#ef4444">Red Shark</span> POS</h3>
          <p style="font-size:0.75rem;color:var(--text-muted);margin:4px 0 12px">${isAR ? 'نظام إدارة المبيعات والمخازن المتكامل' : 'Enterprise POS & Inventory Suite'}</p>
          
          <div style="font-size:0.8rem;background:var(--surface-2);border-radius:8px;padding:8px 12px;display:inline-block;font-weight:700;color:var(--text-primary);margin-bottom:12px">
            Version ${License.APP_VERSION}
          </div>
          
          <div style="border-top:1px solid var(--border-color);padding-top:12px;margin-top:12px">
            <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:4px">${isAR ? 'معرف الجهاز:' : 'Machine ID:'}</div>
            <div style="font-family:monospace;font-size:0.95rem;font-weight:700;color:var(--primary);letter-spacing:0.5px;user-select:all">${machineId}</div>
          </div>
          
          ${licInfoHTML}
          
          <div style="font-size:0.7rem;color:var(--text-muted);margin-top:20px;border-top:1px solid var(--border-color);padding-top:12px">
            &copy; 2026 Red Shark POS. All rights reserved.
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modalEl);
  }

  async function openPriceCheckerModal() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    let ipAddress = window.location.hostname;
    try {
      const resp = await fetch('/api/network-info', { signal: AbortSignal.timeout(3000) });
      if (resp.ok) {
        const data = await resp.json();
        if (data.ip) ipAddress = data.ip;
      }
    } catch (e) {}

    const httpKioskUrl = `http://${ipAddress}:3000/price_checker.html`;
    const httpsKioskUrl = `https://${ipAddress}:3443/price_checker.html`;

    let qrDataUrl = '';
    try {
      const qrResp = await fetch(`/api/qr-code?url=${encodeURIComponent(httpKioskUrl)}`);
      if (qrResp.ok) {
        const qrJson = await qrResp.json();
        if (qrJson.dataUrl) qrDataUrl = qrJson.dataUrl;
      }
    } catch (e) {}
    if (!qrDataUrl) {
      qrDataUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=8&data=${encodeURIComponent(httpKioskUrl)}`;
    }

    const modalId = 'customer-price-checker-modal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const modalEl = document.createElement('div');
    modalEl.className = 'modal-overlay';
    modalEl.id = modalId;
    modalEl.style.display = 'flex';
    modalEl.style.zIndex = '99999';
    modalEl.onclick = (e) => { if (e.target === modalEl) modalEl.remove(); };

    modalEl.innerHTML = `
      <div class="modal animate-fade" style="max-width:480px;text-align:center;padding:22px;border-radius:20px;border:1.5px solid rgba(59,130,246,0.45);background:var(--surface)">
        <div class="modal-header" style="justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:12px;margin-bottom:14px">
          <div style="font-weight:900;font-size:1.12rem;display:flex;align-items:center;gap:8px;color:#3b82f6">
            <span>🔍</span> <span>${isAR ? 'شاشة فاحص أسعار الزبائن (للكشك / التابلت / اللابتوب)' : 'Customer Price Checker Kiosk (Tablet / Laptop)'}</span>
          </div>
          <button class="btn-icon" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>

        <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:12px;line-height:1.45">
          ${isAR
            ? 'شاشة مخصصة للزبائن فقط تعرض اسم الصنف وسعر البيع بالدولار والليرة دون إظهار سعر التكلفة أو قوائم النظام. يمكنك فتحها على هذا الجهاز أو على أي تابلت أو لابتوب متصل بنفس الشبكة (Wi-Fi / LAN):'
            : 'Customer-only kiosk screen showing Item Name and Selling Price (USD & LBP) with zero access to Cost Price or POS menus. Open it here or on any standalone Tablet or Laptop on the same Wi-Fi/LAN:'}
        </p>

        <div style="background:#ffffff;padding:10px;border-radius:16px;display:inline-block;box-shadow:0 8px 20px rgba(0,0,0,0.2);border:2px solid #3b82f6;margin-bottom:14px">
          <img src="${qrDataUrl}" alt="Price Checker QR Code" style="width:170px;height:170px;display:block;border-radius:8px">
        </div>

        <!-- Link 1: HTTP Link for Standalone Laptop / Tablet with USB or Wireless Barcode Scanner -->
        <div style="background:var(--surface-subtle);border:1.5px solid rgba(59,130,246,0.35);border-radius:12px;padding:10px 12px;margin-bottom:10px;text-align:start">
          <div style="font-size:0.74rem;font-weight:800;color:#3b82f6;margin-bottom:4px">
            💻 ${isAR ? 'رابط للابتوب أو تابلت مع قارئ باركود (USB / Bluetooth):' : 'Link for Standalone Laptop / Tablet (with Barcode Scanner):'}
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <div style="font-family:monospace;font-size:0.82rem;color:var(--text-primary);font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;user-select:all">${httpKioskUrl}</div>
            <button class="btn btn-secondary btn-xs" onclick="navigator.clipboard.writeText('${httpKioskUrl}'); if(typeof Utils!=='undefined'&&Utils.toast) Utils.toast(isAR?'تم نسخ الرابط!':'Link copied!', 'success')" style="font-weight:800;white-space:nowrap;padding:4px 10px">
              📋 ${isAR ? 'نسخ' : 'Copy'}
            </button>
          </div>
        </div>

        <!-- Link 2: HTTPS Link for Tablet / Phone using Built-in Camera -->
        <div style="background:var(--surface-subtle);border:1.5px solid rgba(16,185,129,0.35);border-radius:12px;padding:10px 12px;margin-bottom:14px;text-align:start">
          <div style="font-size:0.74rem;font-weight:800;color:#10b981;margin-bottom:4px">
            📷 ${isAR ? 'رابط للتابلت أو الهاتف باستخدام كاميرا الجهاز (HTTPS):' : 'Link for Tablet / Phone using Built-in Camera (HTTPS):'}
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <div style="font-family:monospace;font-size:0.82rem;color:var(--text-primary);font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;user-select:all">${httpsKioskUrl}</div>
            <button class="btn btn-secondary btn-xs" onclick="navigator.clipboard.writeText('${httpsKioskUrl}'); if(typeof Utils!=='undefined'&&Utils.toast) Utils.toast(isAR?'تم نسخ الرابط!':'Link copied!', 'success')" style="font-weight:800;white-space:nowrap;padding:4px 10px">
              📋 ${isAR ? 'نسخ' : 'Copy'}
            </button>
          </div>
        </div>

        <div style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('${modalId}').remove()" style="flex:1">
            ${isAR ? 'إغلاق' : 'Close'}
          </button>
          <button class="btn btn-primary" onclick="window.open('price_checker.html', '_blank')" style="flex:1.4;font-weight:800;background:#3b82f6;border-color:#3b82f6">
            🚀 ${isAR ? 'فتح شاشة فاحص الأسعار الآن' : 'Launch Price Checker Here'}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl);
  }

  async function openMobileAppModal() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    let ipAddress = window.location.hostname;
    let mobileUrl = `http://${ipAddress}:3000/mobile.html`;
    let mobileHttpsUrl = `https://${ipAddress}:3443/mobile.html`;

    try {
      const resp = await fetch('/api/network-info', { signal: AbortSignal.timeout(3000) });
      if (resp.ok) {
        const data = await resp.json();
        if (data.ip) ipAddress = data.ip;
        if (data.mobileUrl) mobileUrl = data.mobileUrl;
        if (data.mobileHttpsUrl) mobileHttpsUrl = data.mobileHttpsUrl;
      }
    } catch(e) {}

    // Default target: HTTPS URL so the phone camera works DIRECTLY inside the browser!
    const targetUrl = mobileHttpsUrl;

    // Generate local offline QR code via server API
    let qrDataUrl = '';
    try {
      const qrResp = await fetch(`/api/qr-code?url=${encodeURIComponent(targetUrl)}`);
      if (qrResp.ok) {
        const qrJson = await qrResp.json();
        if (qrJson.dataUrl) qrDataUrl = qrJson.dataUrl;
      }
    } catch(e) {}

    if (!qrDataUrl) {
      qrDataUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent(targetUrl)}`;
    }

    const modalId = 'mobile-app-qr-modal';
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const modalEl = document.createElement('div');
    modalEl.className = 'modal-overlay';
    modalEl.id = modalId;
    modalEl.style.display = 'flex';
    modalEl.style.zIndex = '99999';

    modalEl.innerHTML = `
      <div class="modal animate-fade" style="max-width:440px;text-align:center;padding:24px;border-radius:20px;border:1.5px solid var(--border-color);background:var(--surface)">
        <div class="modal-header" style="justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:12px;margin-bottom:16px">
          <div style="font-weight:900;font-size:1.15rem;display:flex;align-items:center;gap:8px">
            <span>📱</span> <span>${isAR ? 'تطبيق الهاتف للبيع والباركود والمخزون' : 'Mobile POS & Barcode Scanner'}</span>
          </div>
          <button class="btn-icon" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>

        <div style="margin:10px 0 16px">
          <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:14px;line-height:1.4">
            ${isAR 
              ? 'امسح الرمز أدناه بكاميرا الهاتف لفتح تطبيق البيع ومسح الباركود مباشرة من الهاتف' 
              : 'Scan this QR code with your phone to open the mobile retail & stock management app'}
          </p>

          <div style="background:#ffffff;padding:12px;border-radius:16px;display:inline-block;box-shadow:0 10px 25px rgba(0,0,0,0.2);border:2px solid #ef4444">
            <img src="${qrDataUrl}" alt="Mobile App QR Code" style="width:200px;height:200px;display:block;border-radius:8px">
          </div>
        </div>

        <div style="background:var(--surface-subtle);border:1.5px solid rgba(16,185,129,0.3);border-radius:12px;padding:10px 14px;margin-bottom:12px;text-align:start">
          <div style="font-size:0.75rem;font-weight:800;color:var(--success);margin-bottom:4px">
            🔒 ${isAR ? 'رابط المسح المباشر عبر الكاميرا (HTTPS):' : 'Direct In-App Camera Link (HTTPS):'}
          </div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
            <div style="font-family:monospace;font-size:0.85rem;color:var(--primary);font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;user-select:all" id="mobile-url-txt">${targetUrl}</div>
            <button class="btn btn-secondary btn-xs" onclick="navigator.clipboard.writeText('${targetUrl}'); if(typeof Utils!=='undefined'&&Utils.toast) Utils.toast(isAR?'تم نسخ الرابط!':'Link copied to clipboard!', 'success')" style="font-weight:800;white-space:nowrap;padding:5px 10px">
              📋 ${isAR ? 'نسخ' : 'Copy'}
            </button>
          </div>
        </div>

        <div style="font-size:0.75rem;color:var(--text-muted);background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:10px;margin-bottom:14px;text-align:start;line-height:1.4">
          💡 <strong>${isAR ? 'تفعيل الكاميرا المباشرة داخل التطبيق:' : 'To Enable In-App Camera Scanning:'}</strong> ${isAR 
            ? 'عند فتح الرابط الآمن لأول مرة على الهاتف، اضغط "Advanced" ثم "Proceed to 192.168.1.49" لتبدأ الكاميرا بالمسح التلقائي والمباشر داخل التطبيق.' 
            : 'When opening the secure HTTPS link for the first time on your phone, tap "Advanced" then "Proceed to 192.168.1.49" so the camera streams live directly inside the app.'}
        </div>

        <div style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('${modalId}').remove()" style="flex:1">
            ${isAR ? 'إغلاق' : 'Close'}
          </button>
          <button class="btn btn-primary" onclick="window.open('${targetUrl}', '_blank')" style="flex:1;font-weight:800">
            🚀 ${isAR ? 'فتح التطبيق' : 'Open App'}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl);
  }

  // Global outside click listener to dismiss open dropdown menus
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#user-dropdown') && !e.target.closest('#notif-dropdown')) {
      const uMenu = document.getElementById('user-menu');
      if (uMenu) { uMenu.classList.remove('open'); uMenu.style.display = 'none'; }
      const nMenu = document.getElementById('notif-menu');
      if (nMenu) { nMenu.classList.remove('open'); nMenu.style.display = 'none'; }
    }
  });

  function getCurrentPage() {
    return _currentPage;
  }

  return { 
    init, 
    navigate, 
    renderPage, 
    toggleSidebar, 
    closeSidebar, 
    toggleSubmenu, 
    toggleTheme, 
    toggleLang, 
    toggleUserMenu, 
    toggleNotif, 
    setTheme, 
    setFontScale,
    getFontScale,
    getCurrentPage, 
    showAboutModal,
    openMobileAppModal,
    openPriceCheckerModal,
    goToMainMenu,
    updateDollarRateDisplay,
    applyUIVisibility
  };
})();

window.App = App;
document.addEventListener('DOMContentLoaded', () => App.init());
