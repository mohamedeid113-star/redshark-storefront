/* ================================================================
   Red Shark POS — Multi-POS & Branch Sync Engine
   Real-Time SSE Catalog Push & Two-Way Centralized Transactions
   ================================================================ */

const BranchSync = (() => {
  let sseEventSource = null;
  let isSyncing = false;
  let reconnectTimeout = null;
  let heartbeatInterval = null;
  let autoRefreshInterval = null;
  let autoSyncInterval = null;
  let cloudDeltaInterval = null;
  let _isOffline = false;
  let _lastSeenCloudSeq = localStorage.getItem('rs_cloud_sync_seq') || 0;
  let _sentinelChecking = false;
  let _consecutiveFailures = 0;
  const MAX_FAILURE_THRESHOLD = 5;

  function markConnectionOnline(labelText) {
    _consecutiveFailures = 0;
    _isOffline = false;
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    updateTopbarIndicator(true, labelText || (isAR ? 'متصل بالسحابة المركزية' : 'Cloud Sync Connected'));
    updateStatusBadge('online', labelText || (isAR ? 'متصل ومحدث' : 'Connected & Synced'));
  }

  function markConnectionFailure(reasonText) {
    _consecutiveFailures++;
    console.warn(`[BranchSync] Disconnect attempt ${_consecutiveFailures}/${MAX_FAILURE_THRESHOLD}:`, reasonText || '');
    // ONLY switch status to disconnected/offline if more than 5 consecutive attempts fail!
    if (_consecutiveFailures >= MAX_FAILURE_THRESHOLD) {
      _isOffline = true;
      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
      const offlineMsg = isAR ? 'غير متصل' : 'Not Connected';
      updateTopbarIndicator(false, offlineMsg);
      updateStatusBadge('offline', offlineMsg);
    }
  }

  const DEFAULT_TABLES = ['items', 'categories', 'offers', 'units', 'warehouses', 'customers', 'stock_transfers'];
  const AVAILABLE_TABLES = [
    { id: 'items', en: 'Items & Barcodes', ar: 'الأصناف والباركود' },
    { id: 'categories', en: 'Categories & Brands', ar: 'الفئات والأقسام' },
    { id: 'offers', en: 'Offers & Deals', ar: 'العروض والخصومات' },
    { id: 'units', en: 'Units & Measurements', ar: 'الوحدات والقياسات' },
    { id: 'warehouses', en: 'Stores & Branches', ar: 'المستودعات والفروع' },
    { id: 'stock_transfers', en: 'Stock Transfers', ar: 'تحويلات المخزون' },
    { id: 'customers', en: 'Customers', ar: 'العملاء' },
    { id: 'suppliers', en: 'Suppliers', ar: 'الموردون' }
  ];

  function normalizeBranchId(rawBranchId, role) {
    const value = String(rawBranchId || '').trim().toLowerCase();
    if (!value) return role === 'server' ? 'main' : 'branch-1';
    const mainAliases = new Set([
      'main', 'server', 'srv', 'srv-01', 'main-server', 'main server', 'main server (central branch)',
      'central', 'central-branch', 'central branch', 'head office', 'head-office', 'headoffice',
      'branch.main', 'branch-1', 'branch 1', 'branch.one', 'pos-1', 'pos-01', 'pos 1', 'terminal-1', 'terminal 1',
      'wh-01', 'warehouse-01', 'warehouse 01', 'warehouse-1', 'warehouse 1', 'main warehouse', 'main-warehouse'
    ]);
    if (mainAliases.has(value)) return 'main';
    if (role === 'server') return 'main';
    return value;
  }

  // ── Node Configuration ───────────────────────────────────────────
  async function getConfig() {
    const cachedRole = (typeof localStorage !== 'undefined') ? localStorage.getItem('sync_node_role') : null;
    const cachedServerIp = (typeof localStorage !== 'undefined') ? localStorage.getItem('sync_server_ip') : null;
    const cachedServerPort = (typeof localStorage !== 'undefined') ? localStorage.getItem('sync_server_port') : null;
    const cachedNodeId = (typeof localStorage !== 'undefined') ? localStorage.getItem('sync_node_id') : null;
    const cachedNodeName = (typeof localStorage !== 'undefined') ? localStorage.getItem('sync_node_name') : null;
    const cachedBranchId = (typeof localStorage !== 'undefined') ? localStorage.getItem('sync_branch_id') : null;

    const defaultRole = cachedRole || 'server';
    const role = (await DB.getSetting('sync_node_role', defaultRole)).toLowerCase(); // 'server' | 'pos' | 'branch'
    const serverIp = await DB.getSetting('sync_server_ip', cachedServerIp || '127.0.0.1');
    const serverPort = await DB.getSetting('sync_server_port', cachedServerPort ? parseInt(cachedServerPort, 10) : 3000);
    const nodeId = await DB.getSetting('sync_node_id', cachedNodeId || (role === 'server' ? 'SRV-01' : 'POS-' + Math.floor(100 + Math.random() * 900)));
    const nodeName = await DB.getSetting('sync_node_name', cachedNodeName || (role === 'server' ? 'Main Server (Central Branch)' : 'POS Workstation'));
    const branchId = normalizeBranchId(await DB.getSetting('sync_branch_id', cachedBranchId || (role === 'server' ? 'main' : 'branch-1')), role);
    let syncTables = await DB.getSetting('sync_tables', DEFAULT_TABLES);
    if (typeof syncTables === 'string') {
      try { syncTables = JSON.parse(syncTables); } catch(e) { syncTables = DEFAULT_TABLES; }
    }
    const rawAutoSync = await DB.getSetting('sync_auto_enabled', true);
    const autoSync = (rawAutoSync !== false && rawAutoSync !== 'false' && rawAutoSync !== 0 && rawAutoSync !== '0');
    try {
      localStorage.setItem('sync_node_role', role);
      localStorage.setItem('sync_server_ip', serverIp);
      localStorage.setItem('sync_server_port', String(serverPort));
      localStorage.setItem('sync_node_id', nodeId);
      localStorage.setItem('sync_node_name', nodeName);
      localStorage.setItem('sync_branch_id', branchId);
    } catch(e) {}
    return { role, serverIp, serverPort, nodeId, nodeName, branchId, syncTables, autoSync };
  }

  async function isServer() {
    const cfg = await getConfig();
    return cfg.role === 'server';
  }

  async function getEffectiveBranchId() {
    const cfg = await getConfig();
    return cfg.branchId || 'main';
  }

  async function getEffectiveNodeId() {
    const cfg = await getConfig();
    return cfg.nodeId || 'SRV-01';
  }

  function getServerBaseUrl(cfg) {
    if (!cfg) return 'http://127.0.0.1:3000';
    if (cfg.role === 'server') {
      return window.location.origin.includes('http') ? window.location.origin : 'http://127.0.0.1:3000';
    }
    let raw = (cfg.serverIp || '127.0.0.1').trim();
    if (!raw) return 'http://127.0.0.1:3000';

    // If already has https:// or http:// scheme (e.g. Cloudflare tunnel URL)
    if (raw.startsWith('https://') || raw.startsWith('http://')) {
      return raw.replace(/\/+$/, '');
    }

    // If it's a domain name (e.g. trycloudflare.com or custom domain)
    if (raw.includes('trycloudflare.com') || (raw.includes('.') && !/^\d+\.\d+\.\d+\.\d+/.test(raw))) {
      return `https://${raw.replace(/\/+$/, '')}`;
    }

    let ip = raw.replace(/^https?:\/\//, '');
    const port = cfg.serverPort || 3000;
    if (ip.includes(':')) return `http://${ip}`;
    return `http://${ip}:${port}`;
  }

  // ── Real-Time Cloud Sentinel & Reconnection Handler ──────────────
  async function handleConnectionRestored() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    markConnectionOnline(isAR ? 'الاتصال بالسيرفر متصل ومحدث' : 'Server Connected');
    await triggerCloudSentinelCheck(true);
  }

  async function triggerCloudSentinelCheck(force = false) {
    if (_sentinelChecking) return;
    _sentinelChecking = true;
    try {
      const cfg = await getConfig();
      if (cfg.role !== 'server' && cfg.serverIp && cfg.serverIp !== '127.0.0.1') {
        const baseUrl = getServerBaseUrl(cfg);
        const res = await fetch(`${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(cfg.nodeId)}&role=${encodeURIComponent(cfg.role)}`, { signal: AbortSignal.timeout(10000) });
        if (res.ok) {
          markConnectionOnline((typeof i18n !== 'undefined' && i18n.getLang && i18n.getLang() === 'ar') ? `متصل بالسيرفر (${cfg.serverIp})` : `Connected to Server (${cfg.serverIp})`);
        } else {
          markConnectionFailure(`Server HTTP ${res.status}`);
        }
      }
    } catch(e) {
      markConnectionFailure('Server ping error');
    } finally {
      _sentinelChecking = false;
    }
  }

  // ── Real-Time SSE Listener ───────────────────────────────────────
  async function startListener() {
    clearTimeout(reconnectTimeout);
    clearInterval(heartbeatInterval);
    clearInterval(cloudDeltaInterval);
    if (sseEventSource) {
      try { sseEventSource.close(); } catch(e) {}
      sseEventSource = null;
    }

    const cfg = await getConfig();
    _currentRole = cfg.role;

    if (cfg.role === 'server') {
      updateTopbarIndicator(false, null, true); // Hidden on server
      await publishAllTablesToServer();
      updateStatusBadge('online', 'Server Active (Direct Sync)');
      await importBranchTransactionsToServerDb();
      heartbeatInterval = setInterval(async () => {
        try {
          await importBranchTransactionsToServerDb();
        } catch(e) {}
      }, 15000);
      if (!window._syncServerFocusListenerAdded) {
        window._syncServerFocusListenerAdded = true;
        document.addEventListener('visibilitychange', () => {
          if (!document.hidden) {
            importBranchTransactionsToServerDb().catch(() => {});
          }
        });
        window.addEventListener('focus', () => {
          importBranchTransactionsToServerDb().catch(() => {});
        });
      }
    } else {
      // Node is a Branch or POS workstation -> Display connection circle indicator
      updateTopbarIndicator(false);

      // Connect to Server SSE stream
      connectLanSSE(cfg);

      // Periodic direct server heartbeat loop (every 3s) with persistent change tracking
      const baseUrl = getServerBaseUrl(cfg);
      let lastChangeTimestamp = parseInt(localStorage.getItem('rs_branch_last_sync_timestamp') || '0', 10);
      if (!lastChangeTimestamp || isNaN(lastChangeTimestamp)) {
        lastChangeTimestamp = Date.now() - (30 * 24 * 3600 * 1000); // 30 days catch-up fallback
      }
      let _isPushingTxns = false;
      const sendHeartbeat = async () => {
        let lanSuccess = false;
        if (cfg.serverIp) {
          try {
            const pingUrl = `${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(cfg.nodeId)}&name=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}&since=${lastChangeTimestamp}`;
            const res = await fetch(pingUrl, { signal: AbortSignal.timeout(5000) });
            if (res.ok) {
              lanSuccess = true;
              const json = await res.json();
              if (json.timestamp) {
                lastChangeTimestamp = json.timestamp;
                try { localStorage.setItem('rs_branch_last_sync_timestamp', String(json.timestamp)); } catch(e) {}
              }
              if (json.tableVersions && typeof json.tableVersions === 'object') {
                let localKnown = {};
                try {
                  localKnown = JSON.parse(localStorage.getItem('rs_branch_table_versions') || '{}');
                } catch(e) {}
                const tablesToCheck = ['warehouses', 'stock_transfers', 'items', 'customers', 'categories', 'offers'];
                for (const t of tablesToCheck) {
                  const srvVer = json.tableVersions[t];
                  const locVer = localKnown[t] || 0;
                  if (srvVer && srvVer > locVer) {
                    localKnown[t] = srvVer;
                    try { localStorage.setItem('rs_branch_table_versions', JSON.stringify(localKnown)); } catch(e) {}
                    pullTableFromServer(t).then(async (ok) => {
                      if (ok && t === 'stock_transfers') {
                        const unapplied = (await DB.getAll('stock_transfers')) || [];
                        for (const tr of unapplied) {
                          if (!tr.applied_to_branch_stock && cfg.role !== 'server') {
                            await applyTransferRecordToBranch(tr, cfg);
                          }
                        }
                      }
                    }).catch(() => {});
                  }
                }
              }
              if (Array.isArray(json.changes) && json.changes.length > 0) {
                for (const chg of json.changes) {
                  await handleIncomingSyncEvent({ event: 'record_changed', table: chg.table, action: chg.action, record: chg.record });
                }
              }
            }
          } catch(e) {}

          // Non-blocking background push of pending branch transactions
          if (lanSuccess && !_isPushingTxns) {
            _isPushingTxns = true;
            pushLocalTransactions().catch(() => {}).finally(() => { _isPushingTxns = false; });
          }
        }
        const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
        if (lanSuccess) {
          markConnectionOnline(isAR ? `متصل بالسيرفر (${cfg.serverIp})` : `Connected to Server (${cfg.serverIp})`);
        } else {
          markConnectionFailure('Server heartbeat failed');
        }
      };

      // On branch startup: catch up automatically on offline stock transfers & warehouses
      (async () => {
        try {
          if (cfg.serverIp) {
            await pullTableFromServer('warehouses', true);
            await pullTableFromServer('stock_transfers', true);
          }
          const unapplied = (await DB.getAll('stock_transfers')) || [];
          for (const tr of unapplied) {
            if (!tr.applied_to_branch_stock && cfg.role !== 'server') {
              await applyTransferRecordToBranch(tr, cfg);
            }
          }
          await pushLocalTransactions();
        } catch(e) {}
      })();

      sendHeartbeat();
      heartbeatInterval = setInterval(sendHeartbeat, 10000);
      if (!window._syncFocusListenerAdded) {
        window._syncFocusListenerAdded = true;
        document.addEventListener('visibilitychange', () => {
          if (!document.hidden && typeof sendHeartbeat === 'function') sendHeartbeat();
        });
        window.addEventListener('focus', () => {
          if (typeof sendHeartbeat === 'function') sendHeartbeat();
        });
      }
    }
  }

  function connectLanSSE(cfg) {
    if (!cfg.serverIp) return;
    if (sseEventSource) {
      try { sseEventSource.close(); } catch(e) {}
      sseEventSource = null;
    }
    clearTimeout(reconnectTimeout);
    const baseUrl = getServerBaseUrl(cfg);
    const sseUrl = `${baseUrl}/api/sync/events?nodeId=${encodeURIComponent(cfg.nodeId)}&nodeName=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}`;
    try {
      sseEventSource = new EventSource(sseUrl);

      sseEventSource.onopen = () => {
        markConnectionOnline(`Connected to Server (${cfg.serverIp})`);
        if (cfg.autoSync) {
          syncNow(true);
        }
      };

      sseEventSource.onmessage = async (e) => {
        try {
          const payload = JSON.parse(e.data);
          handleIncomingSyncEvent(payload);
        } catch(err) {
          console.warn('Error parsing SSE sync message:', err);
        }
      };

      sseEventSource.onerror = () => {
        try { sseEventSource.close(); } catch(e) {}
        sseEventSource = null;
        markConnectionFailure('LAN SSE connection closed');
        reconnectTimeout = setTimeout(() => connectLanSSE(cfg), 10000);
      };
    } catch(err) {
      markConnectionFailure('LAN SSE failed to initialize');
      reconnectTimeout = setTimeout(() => connectLanSSE(cfg), 15000);
    }
  }

  async function handleIncomingSyncEvent(payload) {
    const isAR = i18n.getLang() === 'ar';
    const cfg = await getConfig();

    if (payload.event === 'record_changed') {
      const table = payload.table;
      const rec = payload.record;
      if (!table || !rec) return;

      if (table === 'items') {
        try {
          if (rec.deleted) {
            const delId = rec.id;
            if (delId) await DB.remove('items', delId);
          } else {
            // Robust matching: check ID, item_code, and barcode
            const recCode = (rec.item_code || rec.code || '').trim().toLowerCase();
            const recBc = rec.barcode ? String(rec.barcode).trim() : '';
            let existing = null;
            if (rec.id != null) existing = await DB.get('items', rec.id);
            if (!existing || (recCode && (existing.item_code || existing.code || '').trim().toLowerCase() !== recCode)) {
              const all = (await DB.getAll('items')) || [];
              existing = all.find(i => {
                const iCode = (i.item_code || i.code || '').trim().toLowerCase();
                const iBc = i.barcode ? String(i.barcode).trim() : '';
                return (recCode && iCode === recCode) || (recBc && iBc === recBc) || (rec.id != null && String(i.id) === String(rec.id));
              });
            }
            const updated = existing ? {
              ...existing,
              ...rec,
              id: existing.id,
              stock_qty: (existing.stock_qty !== undefined ? existing.stock_qty : rec.stock_qty),
              stock: (existing.stock !== undefined ? existing.stock : rec.stock),
              warehouse_stocks: existing.warehouse_stocks || rec.warehouse_stocks
            } : rec;
            await DB.put('items', updated);
          }
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'items', record: rec } }));
          window.dispatchEvent(new CustomEvent('rs_item_updated', { detail: rec }));
          if (typeof Utils !== 'undefined' && Utils.toast) {
            Utils.toast(isAR ? `⚡ تم تحديث الصنف (${rec.name_ar || rec.name || rec.item_code || ''}) تلقائياً من السيرفر` : `⚡ Item updated in real-time from server`, 'info');
          }
        } catch(err) {
          console.warn('Error applying record_changed for items:', err);
        }
      } else if (table === 'stock_transfers') {
        try {
          const allTransfers = (await DB.getAll('stock_transfers')) || [];
          const existing = allTransfers.find(x => (rec.ref && x.ref === rec.ref) || (rec.id != null && x.id === rec.id));
          if (existing) {
            await DB.put('stock_transfers', { ...existing, ...rec, id: existing.id });
            if (cfg.role !== 'server' && !existing.applied_to_branch_stock) {
              await applyTransferRecordToBranch({ ...existing, ...rec, id: existing.id }, cfg);
            }
          } else {
            const copy = { ...rec };
            delete copy.id;
            const newId = await DB.add('stock_transfers', copy);
            copy.id = newId;
            if (cfg.role !== 'server') {
              await applyTransferRecordToBranch(copy, cfg);
            }
          }
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'stock_transfers' } }));
        } catch(e) {}
      } else if (table === 'warehouses') {
        try {
          if (rec.id != null) await DB.put('warehouses', rec);
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'warehouses' } }));
        } catch(e) {}
      } else {
        try {
          if (rec.id != null) await DB.put(table, rec);
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table } }));
        } catch(e) {}
      }
      return;
    } else if (payload.event === 'table_updated') {
      const table = payload.table;
      const autoSyncEnabled = cfg.autoSync !== false;
      const tablesToSync = cfg.syncTables || DEFAULT_TABLES;
      if (autoSyncEnabled && (tablesToSync.includes(table) || table === 'warehouses')) {
        // Pull updated table from server
        const ok = await pullTableFromServer(table);
        if (ok && typeof Utils !== 'undefined' && Utils.toast) {
          Utils.toast(isAR ? `🔄 تم تحديث جدول (${table}) تلقائياً من السيرفر` : `🔄 Table (${table}) updated in real-time from server`, 'info');
        }
      }
    } else if (payload.event === 'config_updated') {
      if (payload.config && payload.config.syncTables) {
        await DB.setSetting('sync_tables', payload.config.syncTables);
      }
    } else if (payload.event === 'nodes_updated') {
      if (typeof refreshNodesTable === 'function') {
        try { refreshNodesTable(); } catch(e) {}
      }
    }
  }

  // ── Apply Received Stock Transfer to Local Branch Inventory ──────
  async function applyTransferRecordToBranch(t, cfg) {
    if (!t || t.applied_to_branch_stock || cfg.role === 'server') return;
    try {
      const allWarehouses = (await DB.getAll('warehouses')) || [];
      const branchId = (cfg.branchId || cfg.nodeId || '').trim().toLowerCase();
      const nodeName = (cfg.nodeName || '').trim().toLowerCase();
      let myWh = allWarehouses.find(w => {
        const c = (w.code || '').trim().toLowerCase();
        return c && (c === branchId || c === nodeName);
      }) || allWarehouses.find(w => {
        const n = (w.name || w.name_ar || '').trim().toLowerCase();
        return n && (n === branchId || n === nodeName);
      }) || allWarehouses.find(w => {
        const c = (w.code || '').trim().toLowerCase();
        const n = (w.name || w.name_ar || '').trim().toLowerCase();
        return (c && (branchId.includes(c) || nodeName.includes(c))) || (n && (branchId.includes(n) || nodeName.includes(n)));
      }) || allWarehouses.find(w => w.id !== 1 && (w.code || '').toUpperCase() !== 'WH-01' && !w.is_default)
         || allWarehouses.find(w => (w.code || '').toUpperCase() !== 'WH-01');

      const myWhId = myWh ? myWh.id : null;
      const myWhCode = myWh ? (myWh.code || '').trim().toLowerCase() : '';
      const fromCode = (t.from_wh_code || '').trim().toLowerCase();
      const fromName = (t.from_wh_name || '').trim().toLowerCase();
      const toCode = (t.to_wh_code || '').trim().toLowerCase();
      const toName = (t.to_wh_name || '').trim().toLowerCase();

      // On a branch workstation, determine if transfer is incoming or outgoing
      let isToMe = true;
      let isFromMe = false;
      const isSenderMe = Boolean(
        (fromCode && (fromCode === branchId || fromCode === nodeName || (myWhCode && fromCode === myWhCode))) ||
        (fromName && (fromName === branchId || fromName === nodeName))
      );
      const isReceiverMe = Boolean(
        (toCode && (toCode === branchId || toCode === nodeName || (myWhCode && toCode === myWhCode))) ||
        (toName && (toName.includes(branchId) || toName.includes(nodeName) || toName.includes('branch') || toName.includes('فرع')))
      );

      if (isSenderMe && !isReceiverMe) {
        isFromMe = true;
        isToMe = false;
      } else {
        isToMe = true;
        isFromMe = false;
      }

      const transferItems = (Array.isArray(t.items) && t.items.length > 0)
        ? t.items
        : [{
            item_id: t.item_id,
            barcode: t.barcode,
            item_code: t.item_code,
            item_name: t.item_name || t.item_name_ar || t.item_name_en,
            qty: parseFloat(t.qty) || 0
          }];

      const allItems = (await DB.getAll('items')) || [];
      let anyItemUpdated = false;

      for (const line of transferItems) {
        const qty = parseFloat(line.qty) || 0;
        if (qty <= 0) continue;

        const lineCode = (line.item_code || line.code || '').trim().toLowerCase();
        const lineBc = line.barcode ? String(line.barcode).trim() : '';
        const lineId = line.item_id != null ? String(line.item_id) : (line.id != null ? String(line.id) : null);
        const lineName = (line.item_name || line.item_name_ar || line.item_name_en || '').trim().toLowerCase();

        const itm = allItems.find(i => {
          const iCode = (i.item_code || i.code || '').trim().toLowerCase();
          const iBc = i.barcode ? String(i.barcode).trim() : '';
          const iId = i.id != null ? String(i.id) : null;
          const iName = (i.name || i.name_ar || i.name_en || '').trim().toLowerCase();
          return (lineCode && iCode === lineCode) ||
                 (lineBc && iBc === lineBc) ||
                 (lineId && iId === lineId) ||
                 (lineName && (iName === lineName || iName.includes(lineName) || lineName.includes(iName)));
        });

        if (itm) {
          if (!itm.warehouse_stocks || typeof itm.warehouse_stocks !== 'object') itm.warehouse_stocks = {};
          const curStock = parseFloat(itm.stock_qty) || parseFloat(itm.stock) || 0;
          const newStock = isToMe ? (curStock + qty) : Math.max(0, curStock - qty);
          itm.stock_qty = newStock;
          itm.stock = newStock;
          // Set on every warehouse key so all views (POS, Items, Inventory) see the transferred stock!
          itm.warehouse_stocks['1'] = newStock;
          itm.warehouse_stocks['2'] = newStock;
          if (myWhId) itm.warehouse_stocks[String(myWhId)] = newStock;
          if (myWhCode) itm.warehouse_stocks[String(myWhCode)] = newStock;
          if (typeof window !== 'undefined' && window._posWarehouseId) {
            itm.warehouse_stocks[String(window._posWarehouseId)] = newStock;
          }
          itm.updated_at = new Date().toISOString();
          await DB.put('items', itm);

          // Update in-memory arrays if open in DOM
          if (typeof window !== 'undefined' && Array.isArray(window._items)) {
            const mIdx = window._items.findIndex(x => x.id === itm.id);
            if (mIdx >= 0) window._items[mIdx] = { ...itm };
          }
          if (typeof window !== 'undefined' && Array.isArray(window._posItems)) {
            const mIdx = window._posItems.findIndex(x => x.id === itm.id);
            if (mIdx >= 0) window._posItems[mIdx] = { ...itm };
          }

          await DB.add('stock_movements', {
            item_id: itm.id,
            type: isToMe ? 'transfer_in' : 'transfer_out',
            ref: t.ref,
            qty,
            notes: isToMe ? `Transfer received from ${t.from_wh_name || 'Main Server'}` : `Transfer sent to ${t.to_wh_name}`,
            created_at: t.created_at || new Date().toISOString()
          });

          anyItemUpdated = true;
        }
      }

      t.applied_to_branch_stock = true;
      if (t.id != null) {
        await DB.put('stock_transfers', t);
      }

      if (anyItemUpdated && typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'items' } }));
        window.dispatchEvent(new CustomEvent('rs_item_updated', { detail: { table: 'items' } }));
        if (typeof Utils !== 'undefined' && Utils.toast) {
          const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
          Utils.toast(isAR ? `📦 تم استلام سند تحويل مخزون (${t.ref}) وتعديل رصيد الصنف بنجاح!` : `📦 Received stock transfer (${t.ref}) and updated branch stock!`, 'success');
        }
      }
    } catch(err) {
      console.warn('[BranchSync] applyTransferRecordToBranch error:', err);
    }
  }

  // ── Pull Table Data from Server ──────────────────────────────────
  async function pullTableFromServer(table, forceFull = false) {
    const cfg = await getConfig();
    const baseUrl = getServerBaseUrl(cfg);
    try {
      let sinceParam = '';
      if (!forceFull && table === 'items') {
        const lastSync = localStorage.getItem('rs_last_items_sync_time');
        const localItems = (await DB.getAll('items')) || [];
        if (lastSync && localItems.length > 500) {
          sinceParam = `&since=${encodeURIComponent(lastSync)}`;
        }
      }
      const q = `?nodeId=${encodeURIComponent(cfg.nodeId)}&name=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}&branchId=${encodeURIComponent(cfg.branchId || 'main')}${sinceParam}`;
      const timeoutMs = (table === 'items' && !sinceParam) ? 180000 : 35000;
      const res = await fetch(`${baseUrl}/api/sync/table/${table}${q}`, {
        signal: AbortSignal.timeout(timeoutMs)
      });
      if (!res.ok) return false;
      const json = await res.json();
      if (json.success && Array.isArray(json.records)) {
        const TRANSACTIONAL_TABLES = [
          'sales', 'sales_invoice', 'sale_items', 'quotation', 'sales_orders', 'delivery_order', 'sales_returns',
          'purchase_invoices', 'purchase_returns', 'purchase_orders', 'goods_receipts', 'po_items', 'grn_items',
          'cash_transactions', 'bank_transactions', 
          'cashbox_sessions', 'cashbox_movements', 
          'stock_movements', 'stock_adjustments', 'stock_transfers', 'audit_log'
        ];
        const isTransactional = TRANSACTIONAL_TABLES.includes(table);

        // Reconcile deletions ONLY for catalog master tables (never touch transactions or partners)
        if (!isTransactional && table !== 'customers' && table !== 'suppliers' && table !== 'items') {
          try {
            const serverIdSet = new Set(
              json.records
                .map(r => (r && r.id != null) ? String(r.id) : null)
                .filter(Boolean)
            );
            const localRecords = await DB.getAll(table);
            if (Array.isArray(localRecords)) {
              for (const localItem of localRecords) {
                const lId = (localItem && localItem.id != null) ? String(localItem.id) : null;
                if (lId && !serverIdSet.has(lId)) {
                  try {
                    await DB.remove(table, localItem.id);
                  } catch(delErr) {}
                }
              }
            }
          } catch(cleanErr) {
            console.warn(`Error reconciling deletions for table ${table}:`, cleanErr);
          }
        }

        // Upsert into local IndexedDB safely
        if (isTransactional) {
          const localRecords = (await DB.getAll(table)) || [];
          const localUuidMap = new Map();
          const localRefMap = new Map();
          const localIdMap = new Map();

          localRecords.forEach(loc => {
            if (loc.uuid) localUuidMap.set(String(loc.uuid).trim().toUpperCase(), loc);
            const ref = String(loc.ref || loc.invoice_no || loc.receipt_no || loc.order_number || '').trim().toUpperCase();
            if (ref) {
              localRefMap.set(ref, loc);
            }
            if (loc.id != null) {
              localIdMap.set(String(loc.id), loc);
            }
          });

          for (const item of json.records) {
            try {
              const iUuid = item.uuid ? String(item.uuid).trim().toUpperCase() : null;
              const iRef = String(item.ref || item.invoice_no || item.receipt_no || item.order_number || '').trim().toUpperCase();
              const iId = (item.id != null) ? String(item.id) : null;

              // Strict identity matching: UUID, exact reference, or local ID
              const match = (iUuid && localUuidMap.get(iUuid)) ||
                            (iRef && localRefMap.get(iRef)) ||
                            (iId && localIdMap.get(iId));

              if (match) {
                await DB.put(table, { ...match, ...item, id: match.id });
                if (table === 'stock_transfers' && cfg.role !== 'server') {
                  await applyTransferRecordToBranch({ ...match, ...item }, cfg);
                }
              } else {
                const copy = { ...item };
                delete copy.id;
                const newId = await DB.add(table, copy);
                copy.id = newId;
                if (iUuid) localUuidMap.set(iUuid, copy);
                if (iRef) localRefMap.set(iRef, copy);
                localIdMap.set(String(newId), copy);
                if (table === 'stock_transfers' && cfg.role !== 'server') {
                  await applyTransferRecordToBranch(copy, cfg);
                }
              }
            } catch(e) {}
          }
        } else if (table === 'customers' || table === 'suppliers') {
          // Master data merge without wiping existing local fields
          const localRecords = (await DB.getAll(table)) || [];
          const localIdMap = new Map();
          const localPhoneMap = new Map();
          localRecords.forEach(m => {
            if (m.id != null) localIdMap.set(String(m.id), m);
            if (m.phone) localPhoneMap.set(String(m.phone).trim(), m);
          });
          for (const item of json.records) {
            try {
              const mId = (item.id != null) ? String(item.id) : null;
              const mPhone = item.phone ? String(item.phone).trim() : null;
              const match = (mId && localIdMap.get(mId)) || (mPhone && localPhoneMap.get(mPhone));
              if (match) {
                // Option A: Preserve local customer debt/balance per branch, never overwrite from server
                const preservedBalance = (table === 'customers') ? (parseFloat(match.balance) || 0) : (parseFloat(item.balance) || 0);
                await DB.put(table, {
                  ...match,
                  ...item,
                  id: match.id,
                  balance: preservedBalance,
                  updated_at: match.updated_at || new Date().toISOString()
                });
              } else {
                await DB.put(table, item);
              }
            } catch(e) {}
          }
        } else if (table === 'items') {
          // When syncing items to branch, NEVER overwrite local branch stock!
          // Branch maintains its own inventory. Items catalog syncs names, barcodes, prices, categories, units.
          const localItems = (await DB.getAll('items')) || [];
          const localById = new Map();
          const localByBarcode = new Map();
          const localByCode = new Map();
          localItems.forEach(i => {
            if (i.id != null) localById.set(String(i.id), i);
            if (i.barcode) localByBarcode.set(String(i.barcode).trim(), i);
            const c = (i.item_code || i.code || '').trim().toLowerCase();
            if (c) localByCode.set(c, i);
          });

          const itemsToSave = [];
          for (const item of json.records) {
            const itemCode = (item.item_code || item.code || '').trim().toLowerCase();
            const itemBc = item.barcode ? String(item.barcode).trim() : '';
            const match = (item.id != null && localById.get(String(item.id))) ||
                          (itemBc && localByBarcode.get(itemBc)) ||
                          (itemCode && localByCode.get(itemCode));
            if (match) {
              // Preserve local branch stock quantity and branch warehouse stock
              const preservedStock = (match.stock_qty !== undefined) ? match.stock_qty : (match.stock !== undefined ? match.stock : 0);
              const preservedWhStocks = { ...(match.warehouse_stocks || {}) };
              if (typeof window !== 'undefined' && window._posWarehouseId) {
                preservedWhStocks[window._posWarehouseId] = preservedStock;
              }
              itemsToSave.push({
                ...item,
                id: match.id,
                stock_qty: preservedStock,
                stock: preservedStock,
                warehouse_stocks: preservedWhStocks
              });
            } else {
              // Brand new catalog item from server: initialize branch stock at 0
              itemsToSave.push({
                ...item,
                stock_qty: 0,
                stock: 0,
                warehouse_stocks: { '1': 0 }
              });
            }
          }

          if (itemsToSave.length > 0) {
            try {
              if (typeof DB.bulkPut === 'function') {
                const savedCount = await DB.bulkPut('items', itemsToSave);
                console.log(`[BranchSync] Saved ${savedCount} / ${itemsToSave.length} items to local DB`);
              } else {
                for (const it of itemsToSave) {
                  try { await DB.put('items', it); } catch(e) {}
                }
              }
            } catch(bulkErr) {
              console.warn('[BranchSync] DB.bulkPut threw, running fallback:', bulkErr);
              for (const it of itemsToSave) {
                try { await DB.put('items', it); } catch(e) {}
              }
            }
          }
          localStorage.setItem('rs_last_items_sync_time', new Date().toISOString());

          // Prune Ghost Items on Branch: ONLY on a full sync (!json.delta and full list)
          if (!json.delta && !sinceParam && cfg.role !== 'server' && Array.isArray(json.records) && json.records.length > 500) {
            const serverIdSet = new Set(json.records.map(r => r.id != null ? String(r.id) : '').filter(Boolean));
            const serverBcSet = new Set(json.records.map(r => r.barcode ? String(r.barcode).trim() : '').filter(Boolean));
            const serverCodeSet = new Set(json.records.map(r => r.item_code ? String(r.item_code).trim().toLowerCase() : '').filter(Boolean));

            const toDelete = [];
            for (const loc of localItems) {
              const lId = loc.id != null ? String(loc.id) : '';
              const lBc = loc.barcode ? String(loc.barcode).trim() : '';
              const lCode = loc.item_code ? String(loc.item_code).trim().toLowerCase() : '';
              if (!serverIdSet.has(lId) && !serverBcSet.has(lBc) && !serverCodeSet.has(lCode)) {
                toDelete.push(loc.id);
              }
            }
            if (toDelete.length > 0 && typeof DB.bulkDelete === 'function') {
              await DB.bulkDelete('items', toDelete);
            }
          }
        } else {
          if (typeof DB.bulkPut === 'function') {
            await DB.bulkPut(table, json.records);
          } else {
            for (const item of json.records) {
              try { await DB.put(table, item); } catch(e) {}
            }
          }
        }

        window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table } }));
        return true;
      }
    } catch(err) {
      console.warn(`Error pulling table ${table} from server:`, err);
    }
    return false;
  }

  // ── Publish Table Data to Server (Triggered when Server saves items) ─
  async function publishTableToServer(table) {
    const cfg = await getConfig();
    if (cfg.role !== 'server') return;

    try {
      const records = (await DB.getAll(table)) || [];
      const baseUrl = getServerBaseUrl(cfg);
      await fetch(`${baseUrl}/api/sync/table/${table}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ records })
      });
    } catch(err) {
      console.warn(`Error publishing table ${table}:`, err);
    }
  }

  async function publishAllTablesToServer() {
    const cfg = await getConfig();
    if (cfg.role !== 'server') return;
    for (const tbl of (cfg.syncTables || DEFAULT_TABLES)) {
      await publishTableToServer(tbl);
    }
  }

  // Hook called anywhere in the app when catalog items, customers, or transactions are edited
  async function notifyChange(table, item) {
    const cfg = await getConfig();
    const baseUrl = getServerBaseUrl(cfg);

    // If warehouse is edited (ONLY on Central Server!), push table to server immediately
    if (table === 'warehouses') {
      if (cfg.role !== 'server') {
        // Branch nodes must NEVER overwrite warehouses on the central server!
        return;
      }
      try {
        const records = (await DB.getAll('warehouses')) || [];
        await fetch(`${baseUrl}/api/sync/table/warehouses?role=server`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-Sync-Role': 'server' },
          body: JSON.stringify({ records, role: 'server' })
        });
        if (item) {
          await fetch(`${baseUrl}/api/sync/notify?role=server`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Sync-Role': 'server' },
            body: JSON.stringify({ table: 'warehouses', action: 'update', record: item, role: 'server' })
          });
        }
      } catch(e) {
        console.warn('Error pushing warehouses to server:', e);
      }
    } else if (cfg.role === 'server') {
      if (item && (item.id != null || item.barcode || item.item_code || item.code)) {
        try {
          await fetch(`${baseUrl}/api/sync/notify`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ table, action: item.deleted ? 'delete' : 'update', record: item })
          });
        } catch(e) {
          console.warn('Error pushing notify for single record:', e);
        }
      } else {
        await publishTableToServer(table);
      }
    }
    const nowIso = new Date().toISOString();
    localStorage.setItem('rs_last_cloud_sync', nowIso);
    if (typeof DB !== 'undefined') {
      try { await DB.setSetting('last_cloud_sync_time', nowIso); } catch(e) {}
    }
    const timeEl = document.getElementById('sync-last-cloud-time');
    if (timeEl) timeEl.textContent = formatSyncTime(nowIso);
  }

  // ── Push Local Transactions to Server ────────────────────────────
  async function pushLocalTransactions() {
    const cfg = await getConfig();
    if (cfg.role === 'server') return true;

    const baseUrl = getServerBaseUrl(cfg);
    try {
      const allSales = (await DB.getAll('sales')) || [];
      const allInvoices = (await DB.getAll('sales_invoice')) || [];
      const allReturns = (await DB.getAll('sales_returns')) || [];
      const allPurchases = (await DB.getAll('purchase_invoices')) || [];
      const allPurReturns = (await DB.getAll('purchase_returns')) || [];
      const allCashbox = (await DB.getAll('cashbox_sessions')) || [];
      const allCashMovements = (await DB.getAll('cashbox_movements')) || [];
      const allCashTxns = (await DB.getAll('cash_transactions')) || [];
      const allCustomers = (await DB.getAll('customers')) || [];

      // Tag all local transactions with this station's branch ID and node identity.
      // The central server must never self-register as a branch node or fallback to branch-1.
      const effectiveBranchId = (cfg.role === 'server') ? 'main' : ((cfg.branchId && cfg.branchId !== 'main') ? cfg.branchId : (cfg.nodeId || 'branch-1'));
      const effectiveNodeName = cfg.nodeName || effectiveBranchId;

      const localSales = allSales.map(s => ({
        ...s,
        branch_id: (s.branch_id && s.branch_id !== 'main') ? s.branch_id : effectiveBranchId,
        branch_name: (s.branch_name && !s.branch_name.includes('الفرع الرئيسي')) ? s.branch_name : effectiveNodeName,
        syncBranchId: (s.syncBranchId && s.syncBranchId !== 'main') ? s.syncBranchId : effectiveBranchId,
        syncNodeId: s.syncNodeId || cfg.nodeId || effectiveBranchId
      }));

      const localInvoices = allInvoices.map(inv => ({
        ...inv,
        branch_id: (inv.branch_id && inv.branch_id !== 'main') ? inv.branch_id : effectiveBranchId,
        branch_name: (inv.branch_name && !inv.branch_name.includes('الفرع الرئيسي')) ? inv.branch_name : effectiveNodeName,
        syncBranchId: (inv.syncBranchId && inv.syncBranchId !== 'main') ? inv.syncBranchId : effectiveBranchId,
        syncNodeId: inv.syncNodeId || cfg.nodeId || effectiveBranchId
      }));

      const localReturns = allReturns.map(r => ({
        ...r,
        branch_id: (r.branch_id && r.branch_id !== 'main') ? r.branch_id : effectiveBranchId,
        branch_name: effectiveNodeName,
        syncBranchId: effectiveBranchId,
        syncNodeId: cfg.nodeId || effectiveBranchId
      }));

      const localPurchases = allPurchases;
      const localPurReturns = allPurReturns;

      const localCashbox = allCashbox.map(cb => ({
        ...cb,
        branch_id: (cb.branch_id && cb.branch_id !== 'main') ? cb.branch_id : effectiveBranchId,
        branch_name: effectiveNodeName,
        syncBranchId: effectiveBranchId,
        syncNodeId: cfg.nodeId || effectiveBranchId
      }));

      const localCashTxns = allCashTxns.map(ct => ({
        ...ct,
        branch_id: (ct.branch_id && ct.branch_id !== 'main') ? ct.branch_id : effectiveBranchId,
        branch_name: effectiveNodeName,
        syncBranchId: effectiveBranchId,
        syncNodeId: cfg.nodeId || effectiveBranchId
      }));
      const allItems = (await DB.getAll('items')) || [];
      const branchStockSnapshot = allItems
        .filter(i => (parseFloat(i.stock_qty) || 0) > 0)
        .map(i => ({
          id: i.id,
          barcode: i.barcode || '',
          item_code: i.item_code || '',
          stock_qty: parseFloat(i.stock_qty) || 0
        }));

      if (localSales.length === 0 && localInvoices.length === 0 && localReturns.length === 0 &&
          localPurchases.length === 0 && localPurReturns.length === 0 &&
          localCashbox.length === 0 && localCashTxns.length === 0 &&
          branchStockSnapshot.length === 0 &&
          allCustomers.length === 0) return true;

      let deletedRefs = [];
      try { deletedRefs = JSON.parse(localStorage.getItem('rs_deleted_txn_refs') || '[]'); } catch(e){}

      const res = await fetch(`${baseUrl}/api/sync/push-transactions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nodeId: cfg.nodeId,
          branchId: cfg.branchId,
          branchName: cfg.nodeName,
          sales: localSales,
          salesInvoices: localInvoices,
          salesReturns: localReturns,
          purchaseInvoices: localPurchases,
          purchaseReturns: localPurReturns,
          cashboxSessions: localCashbox,
          cashboxMovements: allCashMovements,
          cashTransactions: localCashTxns,
          branchStockSnapshot: branchStockSnapshot,
          customers: allCustomers,
          deletedTxnRefs: deletedRefs
        }),
        signal: AbortSignal.timeout(20000)
      });
      return res.ok;
    } catch(err) {
      console.warn('Error pushing local transactions to server:', err);
      return false;
    }
  }

  // ── Import Cross-Branch Transactions into Server IndexedDB ────────
  async function importBranchTransactionsToServerDb() {
    const cfg = await getConfig();
    if (cfg.role !== 'server') return;

    try {
      const res = await fetch('/api/sync/transactions?role=server&branchId=all', {
        headers: { 'x-sync-role': 'server', 'x-sync-branch-id': 'main' },
        signal: AbortSignal.timeout(20000)
      });
      if (!res.ok) return;
      const json = await res.json();
      if (!json.success) return;

      // Upsert sales & sales_invoice into Server IndexedDB
      const incomingSales = Array.isArray(json.sales) ? json.sales : [];
      if (incomingSales.length > 0) {
        const localSales = (await DB.getAll('sales')) || [];
        const localInvoices = (await DB.getAll('sales_invoice')) || [];
        const seenSales = new Map();
        localSales.forEach(s => {
          const k = s.uuid ? `uuid::${s.uuid}` : `${s.branch_id || s.syncBranchId || 'main'}::${s.ref || s.invoice_no || s.id}`;
          seenSales.set(k, { item: s, store: 'sales' });
        });
        localInvoices.forEach(inv => {
          const k = inv.uuid ? `uuid::${inv.uuid}` : `${inv.branch_id || inv.syncBranchId || 'main'}::${inv.ref || inv.invoice_no || inv.id}`;
          seenSales.set(k, { item: inv, store: 'sales_invoice' });
        });

        for (const s of incomingSales) {
          const targetStore = (s.store === 'sales_invoice' || s.source === 'invoice') ? 'sales_invoice' : 'sales';
          const k = s.uuid ? `uuid::${s.uuid}` : `${s.branch_id || s.syncBranchId || 'main'}::${s.ref || s.invoice_no || s.id}`;
          const existing = seenSales.get(k);
          try {
            if (existing) {
              await DB.put(existing.store, { ...s, id: existing.item.id });
            } else {
              const copy = { ...s };
              delete copy.id;
              await DB.add(targetStore, copy);
            }
          } catch(e) {}
        }
      }

      // Upsert purchases
      const incomingPurchases = Array.isArray(json.purchases) ? json.purchases : [];
      if (incomingPurchases.length > 0) {
        const localPur = (await DB.getAll('purchase_invoices')) || [];
        const seenPur = new Map();
        localPur.forEach(p => {
          const k = p.uuid ? `uuid::${p.uuid}` : `${p.branch_id || p.syncBranchId || 'main'}::${p.ref || p.supplier_invoice_no || p.id}`;
          seenPur.set(k, p);
        });
        for (const p of incomingPurchases) {
          const k = p.uuid ? `uuid::${p.uuid}` : `${p.branch_id || p.syncBranchId || 'main'}::${p.ref || p.supplier_invoice_no || p.id}`;
          const existing = seenPur.get(k);
          try {
            if (existing) {
              await DB.put('purchase_invoices', { ...p, id: existing.id });
            } else {
              const copy = { ...p };
              delete copy.id;
              await DB.add('purchase_invoices', copy);
            }
          } catch(e) {}
        }
      }

      // Upsert cashbox sessions into Server IndexedDB
      const incomingCashbox = Array.isArray(json.cashboxSessions) ? json.cashboxSessions : [];
      if (incomingCashbox.length > 0) {
        const localCb = (await DB.getAll('cashbox_sessions')) || [];
        const seenCb = new Map();
        localCb.forEach(c => {
          const k = c.uuid ? `uuid::${c.uuid}` : `${c.syncBranchId || c.branch_id || 'main'}::${c.session_id || c.id}`;
          seenCb.set(k, c);
        });
        for (const cb of incomingCashbox) {
          const k = cb.uuid ? `uuid::${cb.uuid}` : `${cb.syncBranchId || cb.branch_id || 'main'}::${cb.session_id || cb.id}`;
          const existing = seenCb.get(k);
          try {
            if (existing) {
              await DB.put('cashbox_sessions', { ...cb, id: existing.id });
            } else {
              const copy = { ...cb };
              delete copy.id;
              await DB.add('cashbox_sessions', copy);
            }
          } catch(e) {}
        }
      }

      // Upsert cashbox movements into Server IndexedDB
      const incomingMovements = Array.isArray(json.cashboxMovements) ? json.cashboxMovements : [];
      if (incomingMovements.length > 0) {
        const localMv = (await DB.getAll('cashbox_movements')) || [];
        const seenMv = new Map();
        localMv.forEach(m => {
          const k = m.uuid ? `uuid::${m.uuid}` : `${m.session_id}::${m.id || m.created_at || m.ref}`;
          seenMv.set(k, m);
        });
        for (const m of incomingMovements) {
          const k = m.uuid ? `uuid::${m.uuid}` : `${m.session_id}::${m.id || m.created_at || m.ref}`;
          const existing = seenMv.get(k);
          try {
            if (existing) {
              await DB.put('cashbox_movements', { ...m, id: existing.id });
            } else {
              const copy = { ...m };
              delete copy.id;
              await DB.add('cashbox_movements', copy);
            }
          } catch(e) {}
        }
      }

      // Upsert cash transactions, ignoring deleted ones
      let delRefs = [];
      try { delRefs = JSON.parse(localStorage.getItem('rs_deleted_txn_refs') || '[]'); } catch(e){}
      const delSet = new Set(delRefs);

      const incomingCash = Array.isArray(json.cashTransactions) ? json.cashTransactions : [];
      if (incomingCash.length > 0) {
        const localCash = (await DB.getAll('cash_transactions')) || [];
        const seenCash = new Map();
        localCash.forEach(t => {
          const k = t.uuid ? `uuid::${t.uuid}` : `${t.branch_id || t.syncBranchId || 'main'}::${t.ref || t.id}`;
          seenCash.set(k, t);
        });
        for (const t of incomingCash) {
          if (t && t.ref && delSet.has(t.ref)) continue;
          const k = t.uuid ? `uuid::${t.uuid}` : `${t.branch_id || t.syncBranchId || 'main'}::${t.ref || t.id}`;
          const existing = seenCash.get(k);
          try {
            if (existing) {
              await DB.put('cash_transactions', { ...t, id: existing.id });
            } else {
              const copy = { ...t };
              delete copy.id;
              await DB.add('cash_transactions', copy);
            }
          } catch(e) {}
        }
      }

      // Upsert consolidated customers into Server IndexedDB so server UI shows live branch debt payments
      const incomingCust = Array.isArray(json.customers) ? json.customers : [];
      if (incomingCust.length > 0) {
        const localCustomers = (await DB.getAll('customers')) || [];
        const seenCust = new Map();
        localCustomers.forEach(c => {
          if (c.id != null) seenCust.set(String(c.id), c);
          if (c.phone) seenCust.set('p::' + String(c.phone).trim(), c);
        });
        let custUpdated = false;
        for (const c of incomingCust) {
          const match = (c.id != null && seenCust.get(String(c.id))) || (c.phone && seenCust.get('p::' + String(c.phone).trim()));
          if (match) {
            const locTime = match.updated_at ? new Date(match.updated_at).getTime() : 0;
            const incTime = c.updated_at ? new Date(c.updated_at).getTime() : 0;
            const locBal = parseFloat(match.balance) || 0;
            const incBal = parseFloat(c.balance) || 0;
            // Never accept an incoming negative balance from branch if server balance is non-negative
            if (incBal < 0 && locBal >= 0) continue;
            if (incTime > locTime) {
              await DB.put('customers', {
                ...match,
                ...c,
                id: match.id,
                balance: parseFloat(c.balance) || 0,
                updated_at: c.updated_at || new Date().toISOString()
              });
              custUpdated = true;
            }
          }
        }
        if (custUpdated) {
          if (window.CustomersModule && typeof CustomersModule.refresh === 'function') {
            await CustomersModule.refresh();
          }
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'customers' } }));
        }
      }
    } catch(err) {
      console.warn('Error importing branch transactions to server DB:', err);
    }
  }

  // ── Full Sync Now Action ─────────────────────────────────────────
  let _syncStartTime = 0;

  async function syncNow(silent = false) {
    if (isSyncing) {
      if (Date.now() - _syncStartTime > 240000) {
        console.warn('[BranchSync] Previous sync exceeded 240s timeout, auto-releasing lock.');
        isSyncing = false;
      } else {
        return;
      }
    }
    isSyncing = true;
    _syncStartTime = Date.now();
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const cfg = await getConfig();
    const btn = document.getElementById('btn-sync-now');
    if (btn && !silent) {
      btn.disabled = true;
      btn.innerHTML = '<span class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px"></span> ' + (isAR ? 'جارِ المزامنة المباشرة...' : 'Direct Syncing...');
    }

    try {
      let pulledItemsCount = 0;
      if (cfg.role === 'server') {
        // Server: publish fresh snapshots of enabled tables and import branch transactions
        await publishAllTablesToServer();
        await importBranchTransactionsToServerDb();
        if (!silent) {
          Utils.toast(isAR ? '✅ تم تحديث ونشر جداول السيرفر المركزي بنجاح لجميع الفروع!' : '✅ Central server tables updated and published for all branches!', 'success');
        }
      } else {
        // Branch: push local transactions & pull catalog from Server
        let pulledSuccessfully = false;
        const hasServerAddress = Boolean(cfg.serverIp && cfg.serverIp.trim() && cfg.serverIp !== '127.0.0.1');
        if (hasServerAddress) {
          let lanReachable = false;
          try {
            const baseUrl = getServerBaseUrl(cfg);
            const pingRes = await fetch(baseUrl + '/api/sync/ping?nodeId=' + encodeURIComponent(cfg.nodeId) + '&name=' + encodeURIComponent(cfg.nodeName) + '&role=' + encodeURIComponent(cfg.role), { signal: AbortSignal.timeout(15000) });
            if (pingRes.ok) lanReachable = true;
          } catch(e) {}

          if (lanReachable) {
            // 1. Push local transactions to server first
            await pushLocalTransactions();

            // 2. Pull all selected tables from server
            for (const tbl of (cfg.syncTables || DEFAULT_TABLES)) {
              if (btn && !silent) {
                btn.innerHTML = `<span class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px"></span> ${isAR ? ('جارِ استيراد ' + (tbl === 'items' ? 'الأصناف (5781 صنف)...' : tbl + '...')) : ('Importing ' + tbl + '...')}`;
              }
              const ok = await pullTableFromServer(tbl);
              if (ok) {
                pulledSuccessfully = true;
                if (tbl === 'items') {
                  const allItems = (await DB.getAll('items')) || [];
                  pulledItemsCount = allItems.length;
                }
              }
            }
          }
        }

        if (!silent) {
          if (pulledSuccessfully) {
            Utils.toast(isAR ? ('✅ تمت المزامنة المباشرة بنجاح مع السيرفر! تم تحديث الأصناف (' + pulledItemsCount + ' صنفاً) وإرسال المبيعات.') : ('✅ Direct Sync completed with Server! Catalog updated (' + pulledItemsCount + ' items).'), 'success');
          } else {
            Utils.toast(isAR ? '⚠️ تعذر الاتصال بالسيرفر المباشر، يرجى التأكد من عنوان السيرفر والاتصال.' : '⚠️ Could not connect to direct server, check server address and connection.', 'warning');
          }
        }
      }

      const nowIso = new Date().toISOString();
      localStorage.setItem('rs_last_cloud_sync', nowIso);
      if (typeof DB !== 'undefined') {
        try { await DB.setSetting('last_cloud_sync_time', nowIso); } catch(e) {}
      }
      const timeEl = document.getElementById('sync-last-cloud-time');
      if (timeEl) timeEl.textContent = formatSyncTime(nowIso);

      // ALWAYS dispatch redshark_sync_complete to refresh POS and Items screens immediately
      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', { 
          detail: { table: 'all', count: pulledItemsCount } 
        }));
      }

      markConnectionOnline(isAR ? 'متصل ومحدث' : 'Connected & Synced');
    } catch(err) {
      console.error('Direct Sync failed:', err);
      if (!silent) Utils.toast(isAR ? ('❌ فشلت المزامنة: ' + err.message) : ('❌ Sync failed: ' + err.message), 'danger');
      markConnectionFailure(err.message || 'Sync failed');
    } finally {
      isSyncing = false;
      if (btn && !silent) {
        btn.disabled = false;
        btn.innerHTML = '🔄 ' + (isAR ? 'مزامنة شاملة الآن' : 'Sync All Now');
      }
    }
  }

  function formatSyncTime(isoStr) {
    if (!isoStr) return '—';
    try {
      const d = new Date(isoStr);
      if (isNaN(d.getTime())) return '—';
      const now = new Date();
      const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);
      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
      if (diffSec < 30) return isAR ? 'الآن (منذ لحظات)' : 'Just now';
      if (diffSec < 120) return isAR ? 'قبل دقيقة' : '1 min ago';
      if (diffSec < 3600) return isAR ? `قبل ${Math.floor(diffSec / 60)} دقيقة` : `${Math.floor(diffSec / 60)} mins ago`;
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' (' + d.toLocaleDateString() + ')';
    } catch(e) { return isoStr; }
  }

  async function updateTopbarIndicator(isConnected, labelText, forceHide = false) {
    const el = document.getElementById('topbar-branch-sync-indicator');
    if (!el) return;
    const cfg = await getConfig();

    // If POS is set up as a server: DO NOT SHOW THE CIRCLE AT ALL
    if (forceHide || cfg.role === 'server') {
      el.style.display = 'none';
      return;
    }

    // POS is set as branch or pos workstation: show circle
    el.style.display = 'inline-flex';
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    const dot = document.getElementById('topbar-branch-sync-dot');
    const txt = document.getElementById('topbar-branch-sync-text');

    if (isConnected) {
      if (dot) {
        dot.style.background = '#10b981';
        dot.style.boxShadow = '0 0 8px rgba(16, 185, 129, 0.9)';
      }
      if (txt) {
        txt.textContent = labelText || (isAR ? 'متصل بالسيرفر' : 'Connected to Server');
        txt.style.color = 'var(--text-primary)';
      }
      el.style.background = 'rgba(16, 185, 129, 0.12)';
      el.style.borderColor = 'rgba(16, 185, 129, 0.4)';
      el.title = isAR ? `متصل بالسيرفر المركزي (${cfg.serverIp})` : `Connected to Central Server (${cfg.serverIp})`;
    } else {
      if (dot) {
        dot.style.background = '#ef4444';
        dot.style.boxShadow = '0 0 8px rgba(239, 68, 68, 0.9)';
      }
      if (txt) {
        txt.textContent = labelText || (isAR ? 'غير متصل بالسيرفر' : 'Server Disconnected');
        txt.style.color = '#ef4444';
      }
      el.style.background = 'rgba(239, 68, 68, 0.12)';
      el.style.borderColor = 'rgba(239, 68, 68, 0.4)';
      el.title = isAR ? `تعذر الاتصال بالسيرفر المركزي (${cfg.serverIp})` : `Disconnected from Server (${cfg.serverIp})`;
    }
  }

  function updateStatusBadge(state, text) {
    const el = document.getElementById('sync-live-status-pill');
    if (el) {
      el.className = `status-pill ${state}`;
      el.innerHTML = `<span class="dot"></span> <span>${text}</span>`;
    }
    if (state === 'online') {
      updateTopbarIndicator(true, text);
    } else if (state === 'offline') {
      updateTopbarIndicator(false, text);
    }
  }

  // ── Render Management Page ───────────────────────────────────────
  async function render(container) {
    if (autoRefreshInterval) {
      clearInterval(autoRefreshInterval);
      autoRefreshInterval = null;
    }

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const cfg = await getConfig();

    // Fetch cloud settings & last sync timestamp
    let cloudSlug = '';
    let cloudUrl = '';
    let cloudKey = '';
    let autoPrint = false;
    let cloudPin = localStorage.getItem('redshark_cloud_pin') || '';
    let lastSyncTime = localStorage.getItem('rs_last_cloud_sync') || '';
    let cloudProvider = 'direct';
    let serverTunnel = '';

    if (typeof DB !== 'undefined') {
      try {
        cloudSlug = (await DB.getSetting('online_store_shop_slug', '')) || '';
        cloudUrl = await DB.getSetting('online_store_url', '');
        cloudKey = await DB.getSetting('online_store_key', '');
        autoPrint = await DB.getSetting('online_store_autoprint', false);
        cloudPin = await DB.getSetting('online_store_cloud_pin', cloudPin || '');
        cloudProvider = (await DB.getSetting('online_store_provider', 'direct')) || 'direct';
        serverTunnel = (await DB.getSetting('online_store_tunnel_url', '')) || '';
        const dbLastSync = await DB.getSetting('last_cloud_sync_time', null);
        if (dbLastSync) lastSyncTime = dbLastSync;
      } catch(e) {}
    }

    const activeSlug = cloudSlug || 'shop101';
    let cleanTunnel = (serverTunnel || '').trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!cleanTunnel) {
      if (activeSlug && activeSlug !== 'shop101') {
        cleanTunnel = `${activeSlug}.redshark-ai.com`;
      } else if (cfg.serverIp && cfg.serverIp !== '127.0.0.1') {
        cleanTunnel = cfg.serverIp.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      } else {
        cleanTunnel = (typeof window !== 'undefined' && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') ? window.location.hostname : `${activeSlug}.redshark-ai.com`;
      }
    }
    serverTunnel = cleanTunnel;

    let customerStoreUrl = '';
    let managerAppUrl = '';

    if (cloudProvider === 'direct') {
      const isHttps = cleanTunnel && !cleanTunnel.match(/^(\d+\.){3}\d+/) && cleanTunnel !== 'localhost';
      const baseOrigin = isHttps ? `https://${cleanTunnel}` : `http://${cleanTunnel}:3000`;
      const domainSub = cleanTunnel.split('.')[0].toLowerCase();
      if (domainSub === activeSlug.toLowerCase()) {
        customerStoreUrl = `${baseOrigin}/storefront/`;
        managerAppUrl = `${baseOrigin}/storefront/app.html`;
      } else {
        customerStoreUrl = `${baseOrigin}/storefront/?shop=${encodeURIComponent(activeSlug)}`;
        managerAppUrl = `${baseOrigin}/storefront/app.html?shop=${encodeURIComponent(activeSlug)}`;
      }
    } else {
      customerStoreUrl = `https://shop.redshark-ai.com/?shop=${encodeURIComponent(activeSlug)}`;
      managerAppUrl = `https://shop.redshark-ai.com/app?shop=${encodeURIComponent(activeSlug)}`;
    }

    // Fetch server status info
    let serverInfo = { localIp: '127.0.0.1', port: 3000, serverUrl: '', connectedClients: 0 };
    try {
      const res = await fetch('/api/sync/status', { signal: AbortSignal.timeout(1500) });
      if (res.ok) serverInfo = await res.json();
    } catch(e) {}

    // Fetch registered nodes (Local LAN nodes)
    let registeredNodes = [];
    try {
      const res = await fetch('/api/sync/nodes', { signal: AbortSignal.timeout(1500) });
      if (res.ok) {
        const j = await res.json();
        registeredNodes = j.nodes || [];
      }
    } catch(e) {}

    // Merge with Cloud-Registered Remote Branches
    if (window.OnlineOrders && typeof OnlineOrders.fetchCloudConnectedBranches === 'function') {
      try {
        const cloudBranches = await OnlineOrders.fetchCloudConnectedBranches();
        for (const cb of cloudBranches) {
          // Do not list server itself in connected stations
          if (cb.nodeId === cfg.nodeId || cb.role === 'server') continue;
          const idx = registeredNodes.findIndex(n => n.nodeId === cb.nodeId);
          if (idx >= 0) {
            registeredNodes[idx] = {
              ...registeredNodes[idx],
              ...cb,
              ip: cb.ip || 'Cloud Supabase (Internet)',
              isOnline: cb.isOnline || registeredNodes[idx].isOnline
            };
          } else {
            registeredNodes.push({
              ...cb,
              ip: cb.ip || 'Cloud Supabase (Internet)'
            });
          }
        }
      } catch(e) {}
    }

    const roleBadgeHtml = cfg.role === 'server'
      ? `<span class="badge badge-success" style="font-size:0.85rem;padding:6px 14px;font-weight:900;border-radius:10px;box-shadow:0 2px 8px rgba(16,185,129,0.3)">🖥️ ${isAR ? 'الخادم الرئيسي (Main Server / HQ)' : 'Main Server / HQ'}</span>`
      : (cfg.role === 'branch'
        ? `<span class="badge badge-warning" style="font-size:0.85rem;padding:6px 14px;font-weight:900;border-radius:10px">🏬 ${isAR ? 'فرع خارجي (Remote Branch)' : 'Remote Branch'}</span>`
        : `<span class="badge badge-info" style="font-size:0.85rem;padding:6px 14px;font-weight:900;border-radius:10px">💻 ${isAR ? 'نقطة بيع ثانية (Local POS)' : 'Secondary POS'}</span>`);

    const formattedSyncTime = formatSyncTime(lastSyncTime);

    container.innerHTML = `
      <!-- UNIFIED HEADER & STATUS BAR -->
      <div class="card mb-4" style="background:linear-gradient(135deg, rgba(37,99,235,0.08) 0%, rgba(16,185,129,0.06) 100%);border:1.5px solid rgba(37,99,235,0.25);border-radius:16px;padding:20px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px">
          <div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
              <span style="font-size:1.8rem">🌐</span>
              <h2 style="margin:0;font-size:1.35rem;font-weight:900">
                ${isAR ? 'الربط السحابي، الفروع، والمتجر الإلكتروني' : 'Cloud Sync, Branch Network & Online Storefront'}
              </h2>
              ${roleBadgeHtml}
            </div>
            <p style="margin:0;font-size:0.85rem;color:var(--text-muted);line-height:1.4">
              ${isAR 
                ? 'إدارة الربط المركزي مع Supabase والفروع المتعددة والمتجر السحابي بنفس المعرّف (Slug) لرؤية التقارير الشاملة.' 
                : 'Centralized Supabase cloud sync, multi-branch network & storefront sharing the same tenant slug.'}
            </p>
          </div>

          <!-- Quick Action Buttons -->
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <!-- Last Cloud Sync Badge -->
            <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:12px;padding:8px 14px;display:flex;align-items:center;gap:8px">
              <span style="font-size:1.1rem">🕒</span>
              <div style="text-align:start">
                <div style="font-size:0.7rem;color:var(--text-muted);font-weight:700">${isAR ? 'آخر مزامنة سحابية' : 'Last Cloud Sync'}</div>
                <div id="sync-last-cloud-time" style="font-size:0.85rem;font-weight:900;color:var(--primary)">${formattedSyncTime}</div>
              </div>
            </div>

            <!-- Sync Now Button -->
            <button id="btn-sync-now" class="btn btn-primary" onclick="BranchSync.syncNow()" style="font-weight:800;padding:9px 18px;display:flex;align-items:center;gap:8px;border-radius:12px">
              🔄 ${isAR ? 'مزامنة شاملة الآن' : 'Sync All Now'}
            </button>

            <!-- Push Catalog Button -->
            <button class="btn btn-secondary" onclick="if(window.OnlineOrders)OnlineOrders.syncCatalogToCloud()" style="font-weight:800;padding:9px 16px;display:flex;align-items:center;gap:8px;border-radius:12px" title="${isAR ? 'رفع الأصناف والأسعار الحالية للمتجر السحابي' : 'Upload POS catalog to storefront'}">
              🚀 ${isAR ? 'تحديث الكتالوج بالسحابة' : 'Push Catalog to Cloud'}
            </button>
          </div>
        </div>
      </div>

      <!-- MAIN CONFIGURATION GRID (2 COLUMNS) -->
      <div class="grid grid-2" style="gap:20px;margin-bottom:24px">
        
        <!-- CARD 1: STOREFRONT, DIRECT ZERO-COST SERVER & QR CODE -->
        <div class="card" style="padding:22px;border-radius:16px;border:1px solid var(--border-color)">
          <div class="card-header" style="padding:0 0 14px;margin-bottom:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
            <div class="card-title" style="font-size:1.05rem;font-weight:900">
              🛒 ${isAR ? 'المتجر الإلكتروني، الباركود (QR)، وتطبيق الإدارة' : 'Online Storefront, QR Code & Mobile Manager'}
            </div>
            <span class="badge ${cloudProvider === 'direct' ? 'badge-success' : 'badge-primary'}" id="badge-provider-mode" style="font-size:0.75rem;font-weight:900">
              ${cloudProvider === 'direct' ? '⚡ 100% Free / Zero-Cost' : '☁️ Supabase Cloud'}
            </span>
          </div>

          <!-- Mode Selector (Direct Server vs Supabase Cloud) -->
          <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:12px;padding:12px;margin-bottom:16px">
            <label style="font-size:0.82rem;font-weight:800;display:block;margin-bottom:8px">
              ${isAR ? 'نوع ربط المتجر وتطبيق الهاتف:' : 'Online Storefront Connection Architecture:'}
            </label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <label style="cursor:pointer;display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:10px;border:1.5px solid ${cloudProvider === 'direct' ? 'var(--success)' : 'var(--border-color)'};background:${cloudProvider === 'direct' ? 'rgba(16,185,129,0.08)' : 'transparent'}">
                <input type="radio" name="store_provider" value="direct" ${cloudProvider === 'direct' ? 'checked' : ''} onchange="BranchSync.onProviderChange('direct')">
                <div>
                  <div style="font-weight:900;font-size:0.84rem;color:var(--success)">⚡ ${isAR ? 'سيرفر المحل المباشر (مجاني)' : 'Direct POS Server (100% Free)'}</div>
                  <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'بدون اشتراك سحابي / 0$ تكلفة' : 'Zero-cost, no Supabase fees'}</div>
                </div>
              </label>
              <label style="cursor:pointer;display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:10px;border:1.5px solid ${cloudProvider === 'cloud' ? 'var(--primary)' : 'var(--border-color)'};background:${cloudProvider === 'cloud' ? 'rgba(37,99,235,0.08)' : 'transparent'}">
                <input type="radio" name="store_provider" value="cloud" ${cloudProvider === 'cloud' ? 'checked' : ''} onchange="BranchSync.onProviderChange('cloud')">
                <div>
                  <div style="font-weight:900;font-size:0.84rem">☁️ ${isAR ? 'سحابة Supabase' : 'Supabase Cloud'}</div>
                  <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'قاعدة بيانات سحابية خارجية' : 'External cloud DB'}</div>
                </div>
              </label>
            </div>
          </div>

          <!-- Shop Slug & Public Tunnel -->
          <div class="grid grid-2" style="gap:12px;margin-bottom:14px">
            <div>
              <label class="form-label" id="lbl-shop-slug" style="font-weight:800;font-size:0.85rem">
                🏷️ ${cloudProvider === 'cloud' 
                  ? (isAR ? 'معرّف المتجر السحابي (مطلوب للربط)' : 'Cloud Tenant Slug (Required)') 
                  : (isAR ? 'معرّف المتجر (اختياري في نمط السيرفر)' : 'Shop Slug (Optional in Direct Server)')}
              </label>
              <input type="text" id="cfg-shop-slug" class="form-control" value="${Utils.sanitize(activeSlug)}" placeholder="${cloudProvider === 'cloud' ? 'bobmarket' : (isAR ? 'اختياري (غير مطلوب)' : 'Optional (Not required)')}" style="font-weight:900;font-family:monospace" oninput="BranchSync.updateStorefrontLinks(this.value)">
            </div>
            <div>
              <label class="form-label" style="font-weight:800;font-size:0.85rem">
                🌐 ${isAR ? 'رابط النفق / الدومين الخارجي (Tunnel / Domain)' : 'Server Public Tunnel / Host'}
              </label>
              <input type="text" id="cfg-shop-tunnel" class="form-control" value="${Utils.sanitize(serverTunnel || 'redsharktest.redshark-ai.com')}" placeholder="redsharktest.redshark-ai.com" style="font-weight:800;font-family:monospace" oninput="BranchSync.updateStorefrontLinks(document.getElementById('cfg-shop-slug').value)">
            </div>
          </div>

          <!-- Store Cloud PIN -->
          <div class="form-group" style="margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
              <label class="form-label" style="font-weight:800;font-size:0.85rem;margin:0">
                🔒 ${isAR ? 'رمز الأمان السري للمتجر (Store PIN)' : 'Store Security PIN / Password'}
              </label>
              <span id="sync-pin-status-badge" class="badge badge-success" style="font-size:0.72rem;${cloudPin ? '' : 'display:none'}">✓ ${isAR ? 'محمي برمز سري' : 'PIN Protected'}</span>
            </div>
            <div style="position:relative">
              <input type="password" id="cfg-shop-pin" class="form-control" value="${Utils.sanitize(cloudPin)}" placeholder="1234" style="font-weight:900;font-size:1.1rem;letter-spacing:2px;padding-inline-end:44px">
              <button type="button" onclick="const i=document.getElementById('cfg-shop-pin'); i.type=i.type==='password'?'text':'password'; this.textContent=i.type==='password'?'👁️':'🔒';" style="position:absolute;inset-inline-end:8px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1.1rem;padding:4px">👁️</button>
            </div>
          </div>

          <!-- Direct Links Preview -->
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;background:var(--surface-2);border-radius:12px;padding:12px;border:1px solid var(--border-color)">
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem">
              <span style="font-weight:800">🛍️ ${isAR ? 'رابط متجر الزبائن:' : 'Customer Store:'}</span>
              <a href="${customerStoreUrl}" id="sync-link-storefront" target="_blank" style="color:var(--primary);font-weight:800;text-decoration:none;word-break:break-all">
                ${customerStoreUrl} ↗
              </a>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem">
              <span style="font-weight:800">📱 ${isAR ? 'تطبيق المدير للهاتف:' : 'Mobile Admin App:'}</span>
              <a href="${managerAppUrl}" id="sync-link-adminapp" target="_blank" style="color:var(--primary);font-weight:800;text-decoration:none;word-break:break-all">
                ${managerAppUrl} ↗
              </a>
            </div>
          </div>

          <!-- CUSTOMER QR CODE & STAND PRINT BOX -->
          <div style="background:linear-gradient(135deg, rgba(220,38,38,0.05) 0%, rgba(37,99,235,0.05) 100%);border:1.5px solid rgba(220,38,38,0.25);border-radius:14px;padding:16px;margin-bottom:16px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
              <div style="font-weight:900;font-size:0.92rem;color:var(--text)">
                📲 ${isAR ? 'رمز الاستجابة السريعة للزبائن (Customer Store & App QR Code)' : 'Customer QR Code for Instant Ordering & App'}
              </div>
              <span class="badge badge-danger" style="font-size:0.72rem;font-weight:800">Print Ready</span>
            </div>

            <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
              <!-- QR Image Preview -->
              <div style="background:#fff;border:2px solid var(--border-color);border-radius:14px;padding:6px;display:inline-flex;box-shadow:0 4px 10px rgba(0,0,0,0.06)">
                <img id="sync-qr-preview-img" src="" alt="QR" style="width:130px;height:130px;display:block;border-radius:8px">
              </div>

              <!-- Quick Action Buttons -->
              <div style="flex:1;min-width:200px;display:flex;flex-direction:column;gap:8px">
                <div style="font-size:0.78rem;color:var(--text-muted);line-height:1.4">
                  ${isAR 
                    ? 'امسح هذا الرمز بواسطة كاميرا هاتف الزبون لفتح المتجر مباشرة والطلب أونلاين أو تثبيت التطبيق على الشاشة الرئيسية.' 
                    : 'Scan with any phone camera to instantly open the online storefront, browse items, or install the app.'}
                </div>
                
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:4px">
                  <button type="button" class="btn btn-primary" onclick="BranchSync.printCustomerStand()" style="font-weight:900;font-size:0.84rem;padding:8px 14px;border-radius:10px;display:flex;align-items:center;gap:6px">
                    🖨️ ${isAR ? 'طباعة ستاند الكاونتر للزبائن' : 'Print Counter QR Stand'}
                  </button>
                  <button type="button" class="btn btn-secondary" onclick="BranchSync.copyCustomerLink()" style="font-weight:800;font-size:0.82rem;padding:8px 12px;border-radius:10px">
                    📋 ${isAR ? 'نسخ الرابط' : 'Copy Link'}
                  </button>
                  <button type="button" class="btn btn-secondary" onclick="BranchSync.downloadQR()" style="font-weight:800;font-size:0.82rem;padding:8px 12px;border-radius:10px">
                    ⬇️ ${isAR ? 'تحميل QR' : 'Save QR'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Auto-Print Toggle -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:10px;margin-bottom:14px">
            <div>
              <div style="font-weight:700;font-size:0.85rem">${isAR ? 'طباعة الطلبات تلقائياً فور وصولها' : 'Auto-Print Incoming Online Orders'}</div>
              <div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'طباعة بون التوصيل مباشرة على طابعة الفواتير' : 'Print delivery slip immediately upon arrival'}</div>
            </div>
            <label class="toggle">
              <input type="checkbox" id="cfg-shop-autoprint" ${autoPrint ? 'checked' : ''}>
              <span class="toggle-slider"></span>
            </label>
          </div>

          <!-- Advanced Supabase Connection (Collapsible) -->
          <details id="details-supabase-config" style="display:${cloudProvider === 'cloud' ? 'block' : 'none'};background:rgba(0,0,0,0.02);border:1px solid var(--border-color);border-radius:10px;padding:10px;font-size:0.8rem">
            <summary style="font-weight:800;cursor:pointer;color:var(--text-muted)">⚙️ ${isAR ? 'إعدادات الاتصال المتقدمة (Supabase API)' : 'Advanced Supabase API Credentials'}</summary>
            <div style="margin-top:10px;display:flex;flex-direction:column;gap:10px">
              <div>
                <label style="font-size:0.75rem;font-weight:700">${isAR ? 'رابط خادم Supabase:' : 'Supabase Project URL:'}</label>
                <input type="text" id="cfg-shop-url" class="form-control" value="${Utils.sanitize(cloudUrl)}" style="font-family:monospace;font-size:0.8rem">
              </div>
              <div>
                <label style="font-size:0.75rem;font-weight:700">${isAR ? 'مفتاح الوصول (Anon Key - اختياري):' : 'Anon Public API Key (Optional):'}</label>
                <input type="password" id="cfg-shop-key" class="form-control" value="${Utils.sanitize(cloudKey)}" placeholder="Default system key used" style="font-family:monospace;font-size:0.8rem">
              </div>
            </div>
          </details>
        </div>

        <!-- CARD 2: MACHINE ROLE & BRANCH IDENTITY -->
        <div class="card" style="padding:22px;border-radius:16px;border:1px solid var(--border-color)">
          <div class="card-header" style="padding:0 0 14px;margin-bottom:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
            <div class="card-title" style="font-size:1.05rem;font-weight:900">
              ⚙️ ${isAR ? 'دور هذا الجهاز وهوية الفرع' : 'This Machine Role & Station Identity'}
            </div>
            <span class="badge badge-secondary" style="font-size:0.72rem">Local Setup</span>
          </div>

          <div style="margin-bottom:16px">
            <label style="font-size:0.85rem;font-weight:800;margin-bottom:8px;display:block">
              ${isAR ? 'اختر دور هذا الجهاز في المنظومة:' : 'Select This Machine Role:'}
            </label>
            <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:10px">
              <label class="role-selector-btn ${cfg.role === 'server' ? 'active' : ''}" style="cursor:pointer;border:1.5px solid ${cfg.role === 'server' ? 'var(--primary)' : 'var(--border-color)'};border-radius:12px;padding:12px;text-align:center;background:${cfg.role === 'server' ? 'rgba(59,130,246,0.1)' : 'transparent'}">
                <input type="radio" name="node_role" value="server" ${cfg.role === 'server' ? 'checked' : ''} onchange="BranchSync.onRoleChange('server')" style="display:none">
                <div style="font-size:1.5rem;margin-bottom:4px">🖥️</div>
                <div style="font-weight:900;font-size:0.85rem">${isAR ? 'سيرفر رئيسي' : 'Main Server'}</div>
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'الفرع المركزي HQ' : 'Central HQ'}</div>
              </label>

              <label class="role-selector-btn ${cfg.role === 'pos' ? 'active' : ''}" style="cursor:pointer;border:1.5px solid ${cfg.role === 'pos' ? 'var(--primary)' : 'var(--border-color)'};border-radius:12px;padding:12px;text-align:center;background:${cfg.role === 'pos' ? 'rgba(59,130,246,0.1)' : 'transparent'}">
                <input type="radio" name="node_role" value="pos" ${cfg.role === 'pos' ? 'checked' : ''} onchange="BranchSync.onRoleChange('pos')" style="display:none">
                <div style="font-size:1.5rem;margin-bottom:4px">💻</div>
                <div style="font-weight:900;font-size:0.85rem">${isAR ? 'كاشير إضافي' : 'Secondary POS'}</div>
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'بنفس المحل' : 'Same Store'}</div>
              </label>

              <label class="role-selector-btn ${cfg.role === 'branch' ? 'active' : ''}" style="cursor:pointer;border:1.5px solid ${cfg.role === 'branch' ? 'var(--primary)' : 'var(--border-color)'};border-radius:12px;padding:12px;text-align:center;background:${cfg.role === 'branch' ? 'rgba(59,130,246,0.1)' : 'transparent'}">
                <input type="radio" name="node_role" value="branch" ${cfg.role === 'branch' ? 'checked' : ''} onchange="BranchSync.onRoleChange('branch')" style="display:none">
                <div style="font-size:1.5rem;margin-bottom:4px">🏬</div>
                <div style="font-weight:900;font-size:0.85rem">${isAR ? 'فرع خارجي' : 'Remote Branch'}</div>
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'موقع منفصل' : 'Branch Store'}</div>
              </label>
            </div>
          </div>

          <div class="grid grid-2" style="gap:12px;margin-bottom:14px">
            <div>
              <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'اسم نقطة البيع / الكاشير' : 'Station / POS Name'}</label>
              <input type="text" id="cfg-node-name" class="form-control" value="${Utils.sanitize(cfg.nodeName || 'POS-1')}" placeholder="POS-1">
            </div>
            <div>
              <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'معرّف الفرع (Branch ID)' : 'Branch ID Code'}</label>
              <input type="text" id="cfg-branch-id" class="form-control" value="${Utils.sanitize(cfg.branchId || 'main')}" placeholder="main, branch-2">
            </div>
          </div>

          <div style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'معرّف الجهاز (Node ID)' : 'Station Node ID'}</label>
            <input type="text" id="cfg-node-id" class="form-control" value="${Utils.sanitize(cfg.nodeId || 'main')}" style="font-family:monospace;font-size:0.85rem">
          </div>

          <!-- Server Network Display (if server) -->
          <div id="server-ip-box" style="display:${cfg.role === 'server' ? 'block' : 'none'};background:rgba(59,130,246,0.06);border:1.5px solid rgba(59,130,246,0.25);padding:12px 14px;border-radius:12px">
            <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:4px">${isAR ? 'عنوان هذا السيرفر في الشبكة المحلية (LAN):' : 'Main Server LAN IP:'}</div>
            <div style="font-size:1.15rem;font-weight:900;font-family:monospace;color:var(--primary)">
              http://${serverInfo.localIp}:${serverInfo.port}
            </div>
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">
              ${isAR ? 'المحطات المتصلة حالياً بالسيرفر بالوقت الفعلي:' : 'Connected live stations:'} <strong>${serverInfo.connectedClients}</strong>
            </div>
          </div>

          <!-- Client IP setup (if pos or branch) -->
          <div id="client-ip-box" style="display:${cfg.role === 'server' ? 'none' : 'block'};background:rgba(255,255,255,0.04);padding:14px;border-radius:12px;border:1px dashed var(--border-color)">
            <label class="form-label" style="font-weight:800;color:var(--text-secondary);font-size:0.8rem">
              🌐 ${isAR ? 'عنوان السيرفر (IP محلي أو رابط السيرفر المباشر / Cloudflare Tunnel):' : 'Server Address (Local IP or Direct Server URL / Cloudflare Tunnel):'}
            </label>
            <div style="display:flex;gap:8px;align-items:center">
              <input type="text" id="cfg-server-ip" class="form-control" value="${Utils.sanitize(cfg.serverIp)}" placeholder="e.g. redsharktest.redshark-ai.com or 192.168.1.50" style="font-family:monospace;font-size:0.9rem;font-weight:700">
              <input type="number" id="cfg-server-port" class="form-control" value="${cfg.serverPort || 3000}" style="width:80px;font-family:monospace">
              <button class="btn btn-secondary btn-sm" onclick="BranchSync.testServerConnection()" style="white-space:nowrap;font-weight:700">
                ⚡ ${isAR ? 'اختبار' : 'Test'}
              </button>
            </div>
            <div style="font-size:0.73rem;color:var(--text-muted);margin-top:6px;line-height:1.4">
              💡 ${isAR ? 'ضع هنا رابط سيرفرك (مثل redsharktest.redshark-ai.com) أو رقم الـ IP للاتصال اللحظي والتلقائي فور تشغيل الجهاز.' : 'Enter your server address (e.g. redsharktest.redshark-ai.com or local IP) for real-time automatic connection on boot.'}
            </div>
          </div>
        </div>

      </div>

      <!-- CARD 2.5: SELECT TABLES TO SYNC WITH BRANCHES -->
      <div class="card mb-4" style="padding:22px;border-radius:16px;border:1px solid var(--border-color);background:var(--surface)">
        <div class="card-header" style="padding:0 0 14px;margin-bottom:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <div>
            <div class="card-title" style="font-size:1.05rem;font-weight:900">
              📋 ${isAR ? 'تحديد جداول المزامنة مع الفروع (Tables to Sync)' : 'Branch Tables Synchronization Selection'}
            </div>
            <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
              ${isAR 
                ? 'على سحابة Supabase، يتم حفظ ومزامنة كافة الجداول والمبيعات. هنا يمكنك تحديد ما يحق لهذا الفرع استلامه وتحديثه.' 
                : 'Supabase cloud always syncs all sales, cashbox & tables. Here you can choose which tables this branch receives.'}
            </div>
          </div>
          <span class="badge badge-primary" style="font-size:0.75rem;font-weight:700">
            ${isAR ? 'تحكم كامل بالجداول' : 'Branch Scope'}
          </span>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:12px;margin-bottom:12px">
          ${[
            { id: 'items', icon: '🏷️', nameAr: 'الأصناف والأسعار', nameEn: 'Items & Prices', descAr: 'مزامنة كافة المنتجات، الباركودات، وأسعار البيع', descEn: 'Sync all products, barcodes & prices' },
            { id: 'categories', icon: '📂', nameAr: 'التصنيفات والمجموعات', nameEn: 'Categories', descAr: 'مزامنة شجرة التصنيفات وأقسام المنتجات', descEn: 'Sync category hierarchy & sections' },
            { id: 'warehouses', icon: '🏬', nameAr: 'الفروع والمستودعات', nameEn: 'Stores & Branches', descAr: 'مزامنة بطاقات الفروع والمستودعات والتخصيص', descEn: 'Sync branch profiles & store locations' },
            { id: 'stock_transfers', icon: '🔄', nameAr: 'تحويلات المخزون بين الفروع', nameEn: 'Stock Transfers', descAr: 'مزامنة إيصالات وسجلات تحويل البضاعة', descEn: 'Sync inter-branch stock transfers' },
            { id: 'customers', icon: '👥', nameAr: 'الزبائن والعملاء والذمم', nameEn: 'Customers & Balances', descAr: 'مزامنة حسابات العملاء، الديون، وأرقام الهواتف', descEn: 'Sync customer accounts & balances' },
            { id: 'offers', icon: '🎁', nameAr: 'العروض والخصومات', nameEn: 'Offers & Promotions', descAr: 'مزامنة حملات الخصم والأسعار الترويجية', descEn: 'Sync promotional pricing & discounts' }
          ].map(t => {
            const checked = (cfg.syncTables || DEFAULT_TABLES).includes(t.id);
            return `
              <label style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:12px;border:1.5px solid ${checked ? 'var(--primary)' : 'var(--border-color)'};background:${checked ? 'rgba(59,130,246,0.06)' : 'var(--surface-2)'};cursor:pointer">
                <input type="checkbox" class="sync-table-checkbox" value="${t.id}" ${checked ? 'checked' : ''} style="margin-top:4px;width:18px;height:18px;cursor:pointer">
                <div>
                  <div style="font-weight:900;font-size:0.88rem;color:var(--text);display:flex;align-items:center;gap:6px">
                    <span>${t.icon}</span>
                    <span>${isAR ? t.nameAr : t.nameEn}</span>
                  </div>
                  <div style="font-size:0.73rem;color:var(--text-muted);margin-top:3px;line-height:1.3">
                    ${isAR ? t.descAr : t.descEn}
                  </div>
                </div>
              </label>
            `;
          }).join('')}
        </div>
      </div>

      <!-- CARD 3: REGISTERED STATIONS & BRANCHES (SERVER ONLY) -->
      ${cfg.role === 'server' ? `
      <div class="card mb-4" style="padding:22px;border-radius:16px;border:1px solid var(--border-color)">
        <div class="card-header" style="padding:0 0 14px;margin-bottom:14px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <div>
            <div class="card-title" style="font-size:1.05rem;font-weight:900">📡 ${isAR ? 'الفروع ونقاط البيع المتصلة بالسيرفر' : 'Connected Branch Stations & POS Terminals'}</div>
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'مراقبة حالة اتصال ومزامنة المحطات في الوقت الفعلي' : 'Real-time connectivity and transactions monitor'}</div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-secondary btn-sm" onclick="BranchSync.refreshNodesTable()" style="font-weight:700">🔄 ${isAR ? 'تحديث القائمة' : 'Refresh'}</button>
            <button class="btn btn-primary btn-sm" onclick="BranchSync.openAddNodeModal()" style="font-weight:700">➕ ${isAR ? 'تسجيل محطة يدوياً' : 'Add Station'}</button>
          </div>
        </div>

        <div style="overflow-x:auto">
          <table class="table" style="width:100%;font-size:0.85rem">
            <thead>
              <tr style="background:var(--surface-2)">
                <th>${isAR ? 'معرف الجهاز' : 'Node ID'}</th>
                <th>${isAR ? 'الاسم' : 'Name'}</th>
                <th>${isAR ? 'النوع' : 'Role'}</th>
                <th>${isAR ? 'عنوان IP' : 'IP Address'}</th>
                <th>${isAR ? 'حالة الاتصال' : 'Status'}</th>
                <th>${isAR ? 'آخر ظهور' : 'Last Seen'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody id="sync-nodes-tbody">
              ${registeredNodes.length === 0 ? `
                <tr><td colspan="7" style="text-align:center;padding:26px;color:var(--text-muted)">${isAR ? 'لا توجد محطات إضافية متصلة حالياً. هذا الجهاز يعمل كسيرفر رئيسي.' : 'No additional stations connected yet.'}</td></tr>
              ` : registeredNodes.map(n => `
                <tr>
                  <td style="font-family:monospace;font-weight:800">${n.nodeId}</td>
                  <td style="font-weight:700">${n.name || '—'}</td>
                  <td><span class="badge ${n.role==='branch'?'badge-warning':'badge-info'}">${n.role==='branch'?(isAR?'فرع':'Branch'):(isAR?'نقطة بيع':'POS')}</span></td>
                  <td style="font-family:monospace;color:var(--primary)">${n.ip || '—'}</td>
                  <td>
                    <span class="badge ${n.isOnline?'badge-success':'badge-secondary'}" style="display:inline-flex;align-items:center;gap:6px">
                      <span style="width:6px;height:6px;border-radius:50%;background:${n.isOnline?'#10b981':'#6b7280'}"></span>
                      ${n.isOnline?(isAR?'متصل الآن':'Online'):(isAR?'غير متصل':'Offline')}
                    </span>
                  </td>
                  <td style="font-size:0.8rem;color:var(--text-muted)">${n.lastSeen ? new Date(n.lastSeen).toLocaleTimeString() : '—'}</td>
                  <td style="text-align:center">
                    <button class="btn btn-secondary btn-sm" onclick="BranchSync.pingNode('${n.nodeId}', '${n.ip}')" title="Refresh">🔄</button>
                    <button class="btn btn-danger btn-sm" onclick="BranchSync.deleteNode('${n.nodeId}')" title="Delete">🗑️</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
      ` : ''}

      <!-- BOTTOM UNIFIED SAVE BUTTON -->
      <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:16px;padding:18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;box-shadow:0 4px 14px rgba(0,0,0,0.05)">
        <div style="font-size:0.85rem;color:var(--text-muted)">
          ℹ️ ${isAR ? 'حفظ كافة إعدادات السيرفر، الفروع، والمتجر الإلكتروني في قاعدة البيانات بنقرة واحدة.' : 'Saves all Cloud Supabase, Storefront and Branch settings in one click.'}
        </div>
        <button class="btn btn-primary" onclick="BranchSync.saveSettings()" style="font-weight:900;padding:12px 28px;font-size:1rem;border-radius:12px;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
          💾 ${isAR ? 'حفظ كافة الإعدادات والربط السحابي' : 'Save All Cloud & Branch Settings'}
        </button>
      </div>
    `;

    // Start table refresher (Immediate + 3.5s interval)
    setTimeout(refreshNodesTable, 100);
    setTimeout(refreshNodesTable, 1200);
    setTimeout(loadQRCode, 200);
    autoRefreshInterval = setInterval(refreshNodesTable, 3500);
  }

  let _cachedQrDataUrl = '';

  function onProviderChange(provider) {
    const details = document.getElementById('details-supabase-config');
    const badge = document.getElementById('badge-provider-mode');
    const slugLabel = document.getElementById('lbl-shop-slug');
    const slugInput = document.getElementById('cfg-shop-slug');
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;

    if (details) details.style.display = (provider === 'cloud') ? 'block' : 'none';
    if (badge) {
      if (provider === 'direct') {
        badge.className = 'badge badge-success';
        badge.textContent = '⚡ 100% Free / Zero-Cost';
      } else {
        badge.className = 'badge badge-primary';
        badge.textContent = '☁️ Supabase Cloud';
      }
    }
    if (slugLabel && slugInput) {
      if (provider === 'cloud') {
        slugLabel.innerHTML = `🏷️ ${isAR ? 'معرّف المتجر السحابي (مطلوب للربط)' : 'Cloud Tenant Slug (Required)'}`;
        slugInput.placeholder = 'bobmarket';
        slugInput.style.borderColor = 'var(--primary)';
      } else {
        slugLabel.innerHTML = `🏷️ ${isAR ? 'معرّف المتجر (اختياري في نمط السيرفر)' : 'Shop Slug (Optional in Direct Server)'}`;
        slugInput.placeholder = isAR ? 'اختياري (غير مطلوب)' : 'Optional (Not required)';
        slugInput.style.borderColor = 'var(--border-color)';
      }
    }
    updateStorefrontLinks(slugInput?.value);
  }

  async function getResolvedCustomerUrls() {
    const slug = (document.getElementById('cfg-shop-slug')?.value || '').trim();
    const provider = document.querySelector('input[name="store_provider"]:checked')?.value || 'direct';
    let tunnel = (document.getElementById('cfg-shop-tunnel')?.value || '').trim();
    const cfg = await getConfig();

    let customerUrl = '';
    let managerUrl = '';

    if (provider === 'direct') {
      let cleanTunnel = tunnel.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      if (!cleanTunnel) {
        cleanTunnel = slug ? `${slug}.redshark-ai.com` : '127.0.0.1';
      }
      const isHttps = cleanTunnel && !cleanTunnel.match(/^(\d+\.){3}\d+/) && cleanTunnel !== 'localhost';
      const baseOrigin = isHttps ? `https://${cleanTunnel}` : `http://${cleanTunnel}:3000`;

      // In Direct Server mode, the server URL/tunnel points directly to the shop - no slug query parameter needed!
      customerUrl = `${baseOrigin}/`;
      managerUrl = `${baseOrigin}/app`;
    } else {
      const activeSlug = slug || 'bobmarket';
      customerUrl = `https://shop.redshark-ai.com/?shop=${encodeURIComponent(activeSlug)}`;
      managerUrl = `https://shop.redshark-ai.com/app?shop=${encodeURIComponent(activeSlug)}`;
    }
    return { customerUrl, managerUrl, slug, provider };
  }

  async function updateStorefrontLinks(slug) {
    const cleanSlug = (slug || '').trim().toLowerCase();
    const tunnelInput = document.getElementById('cfg-shop-tunnel');
    if (tunnelInput && cleanSlug) {
      const curTunnel = tunnelInput.value.trim().toLowerCase();
      // If empty or already following a .redshark-ai.com subdomain, update dynamically to match this shop slug
      if (!curTunnel || curTunnel.endsWith('.redshark-ai.com')) {
        tunnelInput.value = `${cleanSlug}.redshark-ai.com`;
      }
    }

    const { customerUrl, managerUrl } = await getResolvedCustomerUrls();
    const stLink = document.getElementById('sync-link-storefront');
    const admLink = document.getElementById('sync-link-adminapp');
    if (stLink) {
      stLink.href = customerUrl;
      stLink.textContent = customerUrl + ' ↗';
    }
    if (admLink) {
      admLink.href = managerUrl;
      admLink.textContent = managerUrl + ' ↗';
    }
    loadQRCode();
  }

  async function loadQRCode() {
    const { customerUrl } = await getResolvedCustomerUrls();
    const img = document.getElementById('sync-qr-preview-img');
    if (!img || !customerUrl) return;

    try {
      const res = await fetch(`/api/qr-code?text=${encodeURIComponent(customerUrl)}`);
      if (res.ok) {
        const j = await res.json();
        if (j.dataUrl) {
          _cachedQrDataUrl = j.dataUrl;
          img.src = j.dataUrl;
        }
      }
    } catch(e) {}
  }

  async function copyCustomerLink() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const { customerUrl } = await getResolvedCustomerUrls();
    try {
      await navigator.clipboard.writeText(customerUrl);
      Utils.toast(isAR ? '📋 تم نسخ رابط متجر الزبائن بنجاح!' : '📋 Customer Store link copied to clipboard!', 'success');
    } catch(e) {
      prompt(isAR ? 'انسخ الرابط:' : 'Copy link:', customerUrl);
    }
  }

  async function downloadQR() {
    const { slug } = await getResolvedCustomerUrls();
    if (!_cachedQrDataUrl) {
      await loadQRCode();
    }
    if (!_cachedQrDataUrl) return;
    const a = document.createElement('a');
    a.href = _cachedQrDataUrl;
    a.download = `${slug}-storefront-qr.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  async function printCustomerStand() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const { customerUrl, slug } = await getResolvedCustomerUrls();

    if (!_cachedQrDataUrl) {
      await loadQRCode();
    }

    let shopName = 'Red Shark Store';
    let shopPhone = '';
    let shopAddress = '';
    try {
      shopName = (await DB.getSetting('company_name', '')) || (await DB.getSetting('company_name_ar', '')) || slug;
      shopPhone = (await DB.getSetting('company_phone', '')) || '';
      shopAddress = (await DB.getSetting('company_address', '')) || '';
    } catch(e) {}

    const printWindow = window.open('', '_blank', 'width=460,height=680');
    if (!printWindow) {
      return Utils.toast(isAR ? 'يرجى السماح بالنوافذ المنبثقة لطباعة الستاند' : 'Please allow popups to print stand', 'warning');
    }

    const standHtml = `
      <!DOCTYPE html>
      <html dir="${isAR ? 'rtl' : 'ltr'}">
      <head>
        <meta charset="UTF-8">
        <title>Store QR Stand - ${shopName}</title>
        <style>
          @page { size: auto; margin: 4mm; }
          * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Tajawal', system-ui, -apple-system, sans-serif; }
          body { background: #fff; color: #111; display: flex; align-items: center; justify-content: center; min-height: 100vh; padding: 12px; }
          .stand-card {
            width: 100%;
            max-width: 380px;
            border: 3px solid #dc2626;
            border-radius: 22px;
            padding: 24px 20px;
            text-align: center;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
          }
          .logo-icon { font-size: 2.8rem; margin-bottom: 6px; }
          .shop-name { font-size: 1.5rem; font-weight: 900; margin-bottom: 4px; color: #111; }
          .tagline { font-size: 1rem; font-weight: 800; color: #dc2626; margin-bottom: 16px; }
          .qr-box {
            display: inline-block;
            padding: 12px;
            background: #fff;
            border: 2px dashed #dc2626;
            border-radius: 16px;
            margin-bottom: 16px;
          }
          .qr-box img { width: 220px; height: 220px; display: block; margin: 0 auto; }
          .features { text-align: ${isAR ? 'right' : 'left'}; font-size: 0.88rem; font-weight: 700; line-height: 1.8; margin-bottom: 16px; padding: 0 10px; color: #333; }
          .footer-info { border-top: 1px dashed #ccc; padding-top: 10px; font-size: 0.78rem; color: #555; font-weight: 600; }
          .url-box { margin-top: 6px; font-family: monospace; font-size: 0.75rem; word-break: break-all; color: #000; font-weight: 800; }
          @media print {
            body { padding: 0; }
            .stand-card { border: 2px solid #000; box-shadow: none; border-radius: 12px; padding: 16px; }
            .tagline { color: #000; }
            .qr-box { border-color: #000; }
          }
        </style>
      </head>
      <body>
        <div class="stand-card">
          <div class="logo-icon">🦈 🛒</div>
          <h1 class="shop-name">${shopName}</h1>
          <div class="tagline">${isAR ? 'امسح للطلب أونلاين وتثبيت التطبيق' : 'Scan to Order Online & Install App'}</div>
          <div class="qr-box">
            <img src="${_cachedQrDataUrl}" alt="QR Code">
          </div>
          <div class="features">
            <div>⚡ <strong>${isAR ? 'تصفح الأصناف والأسعار بالوقت الفعلي' : 'Browse live items & prices'}</strong></div>
            <div>🛵 <strong>${isAR ? 'طلب فوري إلى باب بيتك أو استلام من الفرع' : 'Fast home delivery or store pickup'}</strong></div>
            <div>📲 <strong>${isAR ? 'تثبيت التطبيق بضغطة زر على شاشة هاتفك' : '1-Tap install to phone home screen'}</strong></div>
          </div>
          <div class="footer-info">
            ${shopPhone ? `<div>📞 ${shopPhone}</div>` : ''}
            ${shopAddress ? `<div>📍 ${shopAddress}</div>` : ''}
            <div class="url-box">${customerUrl}</div>
          </div>
        </div>
        <script>
          window.onload = function() {
            setTimeout(function() { window.print(); }, 400);
          };
        <\/script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(standHtml);
    printWindow.document.close();
  }

  // ── Auto-refresh live stations table ──────────────────────────────
  async function refreshNodesTable() {
    const isAR = i18n.getLang() === 'ar';
    try {
      const [resNodes, resStatus] = await Promise.all([
        fetch('/api/sync/nodes'),
        fetch('/api/sync/status')
      ]);

      if (resStatus.ok) {
        const s = await resStatus.json();
        const cntEl = document.getElementById('sync-connected-clients-count');
        if (cntEl) {
          cntEl.innerHTML = isAR
            ? `المحطات المتصلة حالياً بالسيرفر في الوقت الفعلي: <strong style="color:var(--primary);font-size:0.95rem">${s.connectedClients}</strong>`
            : `Active live connected client stations: <strong style="color:var(--primary);font-size:0.95rem">${s.connectedClients}</strong>`;
        }
      }

      let nodes = [];
      if (resNodes && resNodes.ok) {
        try {
          const data = await resNodes.json();
          nodes = data.nodes || [];
        } catch(e) {}
      }

      // Merge with live Cloud-Connected Remote Branches from Supabase
      if (window.OnlineOrders && typeof OnlineOrders.fetchCloudConnectedBranches === 'function') {
        try {
          const cloudBranches = await OnlineOrders.fetchCloudConnectedBranches();
          const myCfg = await getConfig();
          for (const cb of cloudBranches) {
            if (cb.nodeId === myCfg.nodeId || cb.role === 'server') continue;
            const idx = nodes.findIndex(n => n.nodeId === cb.nodeId);
            if (idx >= 0) {
              nodes[idx] = {
                ...nodes[idx],
                ...cb,
                isOnline: cb.isOnline || nodes[idx].isOnline,
                ip: cb.ip || 'Cloud Supabase (Internet)'
              };
            } else {
              nodes.push({
                ...cb,
                ip: cb.ip || 'Cloud Supabase (Internet)'
              });
            }
          }
        } catch(e) {
          console.warn('[BranchSync] Error merging cloud branches:', e);
        }
      }

      const tbody = document.getElementById('sync-nodes-tbody');
      if (tbody) {
        if (nodes.length === 0) {
          tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted)">${isAR ? 'لا توجد محطات مسجلة بعد. عند اتصال أي نقطة بيع أو فرع بالسيرفر ستظهر هنا تلقائياً.' : 'No stations registered yet.'}</td></tr>`;
        } else {
          tbody.innerHTML = nodes.map(n => `
            <tr>
              <td style="font-family:monospace;font-weight:800">${n.nodeId}</td>
              <td style="font-weight:700">${n.name || '—'}</td>
              <td>
                <span class="badge ${n.role === 'branch' ? 'badge-warning' : 'badge-info'}" style="font-size:0.75rem">
                  ${n.role === 'branch' ? (isAR ? 'فرع' : 'Branch') : (isAR ? 'نقطة بيع' : 'POS')}
                </span>
              </td>
              <td style="font-family:monospace;color:var(--primary)">${n.ip || '—'}</td>
              <td>
                <span class="badge ${n.isOnline ? 'badge-success' : 'badge-secondary'}" style="display:inline-flex;align-items:center;gap:6px">
                  <span style="width:6px;height:6px;border-radius:50%;background:${n.isOnline ? '#10b981' : '#6b7280'}"></span>
                  ${n.isOnline ? (isAR ? 'متصل الآن' : 'Online') : (isAR ? 'غير متصل' : 'Offline')}
                </span>
              </td>
              <td style="font-size:0.8rem;color:var(--text-muted)">${n.lastSeen ? new Date(n.lastSeen).toLocaleTimeString() : '—'}</td>
              <td style="text-align:center">
                <button class="btn btn-secondary btn-sm" onclick="BranchSync.pingNode('${n.nodeId}', '${n.ip}')" title="Refresh">🔄</button>
                <button class="btn btn-danger btn-sm" onclick="BranchSync.deleteNode('${n.nodeId}')" title="Delete">🗑️</button>
              </td>
            </tr>`).join('');
        }
      }
    } catch (e) {}
  }

  // ── Handlers ─────────────────────────────────────────────────────
  function onRoleChange(newRole) {
    document.querySelectorAll('.role-selector-btn').forEach(btn => {
      btn.classList.remove('active');
      btn.style.borderColor = 'var(--border-color)';
      btn.style.background = 'transparent';
    });
    const target = document.querySelector(`input[name="node_role"][value="${newRole}"]`);
    if (target) {
      target.checked = true;
      const parent = target.closest('.role-selector-btn');
      if (parent) {
        parent.classList.add('active');
        parent.style.borderColor = 'var(--primary)';
        parent.style.background = 'rgba(59,130,246,0.15)';
      }
    }
    const clientBox = document.getElementById('client-ip-box');
    const serverBox = document.getElementById('server-ip-box');
    if (clientBox) clientBox.style.display = newRole === 'server' ? 'none' : 'block';
    if (serverBox) serverBox.style.display = newRole === 'server' ? 'block' : 'none';
  }

  async function saveSettings() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const roleRadio = document.querySelector('input[name="node_role"]:checked');
    const role = roleRadio ? roleRadio.value : 'server';
    const nodeId = document.getElementById('cfg-node-id')?.value.trim() || 'main';
    const nodeName = document.getElementById('cfg-node-name')?.value.trim() || 'Main Store';
    const branchId = document.getElementById('cfg-branch-id')?.value.trim() || 'main';
    const serverIp = document.getElementById('cfg-server-ip')?.value.trim() || '';
    const serverPort = parseInt(document.getElementById('cfg-server-port')?.value) || 3000;

    // Cloud Storefront settings
    const providerRadio = document.querySelector('input[name="store_provider"]:checked');
    const storeProvider = providerRadio ? providerRadio.value : 'direct';
    const shopTunnel = document.getElementById('cfg-shop-tunnel')?.value.trim() || '';
    const shopSlug = document.getElementById('cfg-shop-slug')?.value.trim() || '';
    const shopPin = document.getElementById('cfg-shop-pin')?.value.trim() || '';
    const shopUrl = document.getElementById('cfg-shop-url')?.value.trim() || '';
    const shopKey = document.getElementById('cfg-shop-key')?.value.trim() || '';
    const shopAutoPrint = document.getElementById('cfg-shop-autoprint')?.checked ?? false;

    // Enforce slug only when Cloud mode is selected
    if (storeProvider === 'cloud' && !shopSlug) {
      return Utils.toast(isAR ? '⚠️ يرجى إدخال معرّف المتجر السحابي (Slug) للربط مع Supabase' : '⚠️ Please enter Shop Slug for Supabase Cloud Sync', 'warning');
    }

    // Save to DB
    await DB.setSetting('online_store_provider', storeProvider);
    await DB.setSetting('online_store_tunnel_url', shopTunnel);
    localStorage.setItem('rs_store_provider', storeProvider);
    if (shopTunnel) localStorage.setItem('rs_direct_server_url', shopTunnel.startsWith('http') ? shopTunnel : `https://${shopTunnel}`);
    await DB.setSetting('sync_node_role', role);
    await DB.setSetting('sync_node_id', nodeId);
    await DB.setSetting('sync_node_name', nodeName);
    await DB.setSetting('sync_branch_id', branchId);
    await DB.setSetting('sync_server_ip', serverIp);
    await DB.setSetting('sync_server_port', serverPort);
    await DB.setSetting('pos_terminal_name', nodeName);

    await DB.setSetting('online_store_shop_slug', shopSlug);
    await DB.setSetting('online_store_cloud_pin', shopPin);
    localStorage.setItem('redshark_cloud_pin', shopPin);
    await DB.setSetting('online_store_url', shopUrl);
    await DB.setSetting('online_store_key', shopKey);
    await DB.setSetting('online_store_autoprint', shopAutoPrint);

    localStorage.setItem('sync_node_role', role);
    localStorage.setItem('sync_node_id', nodeId);
    localStorage.setItem('sync_node_name', nodeName);
    localStorage.setItem('sync_branch_id', branchId);
    localStorage.setItem('sync_server_ip', serverIp);
    localStorage.setItem('sync_server_port', String(serverPort));
    if (shopSlug) { localStorage.setItem('redshark_shop_slug', shopSlug); } else { localStorage.removeItem('redshark_shop_slug'); localStorage.removeItem('sync_cloud_slug'); }
    localStorage.setItem('redshark_pos_terminal', nodeName);

    // Save selected sync tables for this branch
    const tableCheckboxes = document.querySelectorAll('.sync-table-checkbox:checked');
    if (tableCheckboxes.length > 0) {
      const selectedTables = Array.from(tableCheckboxes).map(c => c.value);
      await DB.setSetting('sync_tables', selectedTables);
    }

    // If client, immediately ping server
    if (role !== 'server') {
      try {
        const baseUrl = getServerBaseUrl({ serverIp, serverPort, role });
        const pingUrl = `${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(nodeId)}&name=${encodeURIComponent(nodeName)}&role=${encodeURIComponent(role)}`;
        await fetch(pingUrl, { signal: AbortSignal.timeout(15000) });
      } catch(e) {}
    }
    try {
      await fetch('/api/sync/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nodeRole: role, nodeId, nodeName, branchId, serverIp, serverPort, shopSlug, shopUrl })
        });
      } catch(e) {}

    Utils.toast(isAR ? '✅ تم حفظ كافة إعدادات الفرع والربط السحابي بنجاح!' : '✅ All Cloud & Branch settings saved successfully!', 'success');
    await startListener();
    const embedContainer = document.getElementById('settings-branches-embed-container');
    if (embedContainer) {
      render(embedContainer);
    }
  }

  async function saveTablesConfig() {
    const isAR = i18n.getLang() === 'ar';
    const checkboxes = document.querySelectorAll('.sync-table-checkbox:checked');
    const selected = Array.from(checkboxes).map(c => c.value);

    await DB.setSetting('sync_tables', selected);
    try {
      await fetch('/api/sync/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ syncTables: selected })
      });
    } catch(e) {}

    Utils.toast(isAR ? '✅ تم حفظ جداول المزامنة المحددة' : '✅ Sync tables updated', 'success');
    const embedContainer = document.getElementById('settings-branches-embed-container');
    if (embedContainer && embedContainer.offsetParent !== null) {
      render(embedContainer);
    } else {
      App.renderPage('multi-pos');
    }
  }

  async function testServerConnection() {
    const isAR = i18n.getLang() === 'ar';
    const ip = document.getElementById('cfg-server-ip')?.value.trim();
    const port = document.getElementById('cfg-server-port')?.value.trim() || 3000;
    const nodeId = document.getElementById('cfg-node-id')?.value.trim() || 'BRANCH';
    const nodeName = document.getElementById('cfg-node-name')?.value.trim() || nodeId;
    const roleRadio = document.querySelector('input[name="node_role"]:checked');
    const role = roleRadio ? roleRadio.value : 'branch';

    if (!ip) return Utils.toast(isAR ? 'يرجى إدخال عنوان IP أو رابط السيرفر' : 'Please enter server IP or URL', 'warning');

    const baseUrl = getServerBaseUrl({ serverIp: ip, serverPort: port, role });

    try {
      // Send ping with identity so the server registers this node as Online right away
      const pingUrl = `${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(nodeId)}&name=${encodeURIComponent(nodeName)}&role=${encodeURIComponent(role)}`;
      const res = await fetch(pingUrl, { signal: AbortSignal.timeout(6000) });
      if (res.ok) {
        const j = await res.json();
        Utils.toast(isAR ? `✅ الاتصال ناجح وتم تسجيل الجهاز (${nodeId}) كـ متصل على السيرفر!` : `✅ Connected & Registered node (${nodeId}) on Server!`, 'success');
        updateStatusBadge('online', isAR ? 'متصل بالسيرفر' : 'Connected to Server');
      } else {
        Utils.toast(isAR ? '❌ تعذر الاتصال: السيرفر أعاد استجابة غير صحيحة' : '❌ Server returned error', 'danger');
      }
    } catch(err) {
      Utils.toast(isAR ? `❌ فشل الاتصال بالسيرفر على ${baseUrl}` : `❌ Failed to connect to ${baseUrl}`, 'danger');
    }
  }

  function openAddNodeModal() {
    const modal = document.getElementById('modal-register-node');
    if (modal) modal.style.display = 'flex';
  }

  function closeAddNodeModal() {
    const modal = document.getElementById('modal-register-node');
    if (modal) modal.style.display = 'none';
  }

  async function saveNewNode() {
    const isAR = i18n.getLang() === 'ar';
    const nodeId = document.getElementById('modal-node-id')?.value.trim();
    const name = document.getElementById('modal-node-name')?.value.trim();
    const role = document.getElementById('modal-node-role')?.value || 'pos';
    const ip = document.getElementById('modal-node-ip')?.value.trim();

    if (!nodeId || !name) {
      return Utils.toast(isAR ? 'يرجى إدخال المعرف والاسم' : 'Please enter ID and Name', 'warning');
    }

    try {
      await fetch('/api/sync/nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'save', node: { nodeId, name, role, ip } })
      });
      closeAddNodeModal();
      Utils.toast(isAR ? '✅ تم تسجيل المحطة بنجاح' : '✅ Station registered successfully', 'success');
      refreshNodesTable();
    } catch(err) {
      Utils.toast(isAR ? 'خطأ أثناء حفظ المحطة' : 'Error saving node', 'danger');
    }
  }

  async function deleteNode(nodeId) {
    const isAR = i18n.getLang() === 'ar';
    if (!confirm(isAR ? `هل أنت متأكد من حذف المحطة ${nodeId}؟` : `Are you sure you want to remove station ${nodeId}?`)) return;
    try {
      // 1. Delete from local server registered nodes
      await fetch('/api/sync/nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', node: { nodeId } })
      });

      // 2. Delete from Cloud Supabase connected branches (so it doesn't reappear)
      if (window.OnlineOrders && typeof OnlineOrders.removeCloudConnectedBranch === 'function') {
        await OnlineOrders.removeCloudConnectedBranch(nodeId);
      }

      Utils.toast(isAR ? 'تم حذف المحطة بنجاح' : 'Station removed successfully', 'success');
      await refreshNodesTable();
    } catch(e) {
      console.warn('Error deleting node:', e);
      Utils.toast(isAR ? 'خطأ أثناء حذف المحطة' : 'Error removing station', 'danger');
    }
  }

  async function pingNode(nodeId, ip) {
    const isAR = i18n.getLang() === 'ar';
    Utils.toast(isAR ? `📡 فحص اتصال ${nodeId}...` : `📡 Checking ${nodeId}...`, 'info');
    await refreshNodesTable();
  }

  async function toggleAutoSync(enabled) {
    const isAR = i18n.getLang() === 'ar';
    await DB.setSetting('sync_auto_enabled', !!enabled);
    Utils.toast(isAR 
      ? (enabled ? '✅ تم تفعيل المزامنة التلقائية اللحظية والدورية' : '⏸️ تم تعطيل المزامنة التلقائية (المزامنة ستكون يدوية فقط عبر زر مزامنة الآن)')
      : (enabled ? '✅ Real-time auto-sync enabled' : '⏸️ Auto-sync disabled (Manual sync via button only)'),
      'success'
    );
    startListener();
    const container = document.getElementById('page-content');
    if (container && document.getElementById('cfg-auto-sync-toggle')) {
      render(container);
    }
  }

  function setLastSeenSeq(seq) {
    if (seq) {
      _lastSeenCloudSeq = Number(seq);
      try { localStorage.setItem('rs_cloud_sync_seq', String(seq)); } catch(e) {}
    }
  }

  return {
    getConfig,
    isServer,
    getEffectiveBranchId,
    getEffectiveNodeId,
    startListener,
    updateTopbarIndicator,
    syncNow,
    notifyChange,
    pushLocalTransactions,
    importBranchTransactionsToServerDb,
    render,
    onRoleChange,
    onProviderChange,
    saveSettings,
    updateStorefrontLinks,
    loadQRCode,
    copyCustomerLink,
    downloadQR,
    printCustomerStand,
    saveTablesConfig,
    publishTableToServer,
    applyTransferRecordToBranch,
    testServerConnection,
    openAddNodeModal,
    closeAddNodeModal,
    saveNewNode,
    deleteNode,
    pingNode,
    refreshNodesTable,
    toggleAutoSync,
    triggerCloudSentinelCheck,
    setLastSeenSeq
  };
})();
