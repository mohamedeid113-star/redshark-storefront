/* ================================================================
   NexPOS — Utilities
   ================================================================ */

const Utils = (() => {

  function isLbp(cur) {
    if (!cur) return false;
    const c = String(cur).trim().toUpperCase();
    return c === 'LBP' || c === 'LL' || c === 'L.L.' || c === 'L.L' || c === 'ل.ل' || c === 'LIRA';
  }

  function isUsd(cur) {
    if (!cur) return false;
    const c = String(cur).trim().toUpperCase();
    return c === 'USD' || c === '$' || c === 'DOLLAR' || c === 'USD$';
  }

  function formatCurrency(amount, currency = null, decimals = null) {
    const cur = currency || (typeof window !== 'undefined' ? window._primaryCurrency : 'USD') || 'USD';
    const isLocalLbp = isLbp(cur);
    const dec = (decimals !== null && decimals !== undefined) ? decimals : ((isLocalLbp || cur === 'IQD') ? 0 : 2);
    const num = parseFloat(amount) || 0;
    return num.toLocaleString('en-US', {
      minimumFractionDigits: dec,
      maximumFractionDigits: dec
    });
  }

  function formatMoney(amount, currency = null, decimals = null) {
    const cur = currency || window._primaryCurrency || 'USD';
    const isLocalLbp = isLbp(cur);
    const dec = decimals !== null ? decimals : ((isLocalLbp || cur === 'IQD') ? 0 : 2);
    const num = parseFloat(amount) || 0;
    const formatted = num.toLocaleString('en-US', {
      minimumFractionDigits: dec,
      maximumFractionDigits: dec
    });
    const symMap = { USD: '$', EUR: '€', GBP: '£' };
    return symMap[cur] ? `${symMap[cur]}${formatted}` : `${formatted} ${cur}`;
  }

  /**
   * Calculate secondary currency amount from primary currency amount.
   * In Lebanese retail / market: the dollar rate is ALWAYS quoted as LBP/LL per 1 USD (e.g. 89500).
   * - If Primary = USD & Secondary = LBP/LL -> Multiply: price * rate
   * - If Primary = LBP/LL & Secondary = USD -> DIVIDE: price / rate
   * - If Secondary is USD & rate > 1 -> DIVIDE: price / rate
   * - If Primary is USD & rate > 1 -> Multiply: price * rate
   */
  function calcSecondaryPrice(p1, c1 = 'USD', c2 = 'LBP', rate = 89500) {
    const num = parseFloat(p1) || 0;
    const r = parseFloat(rate) || 89500;
    if (r <= 0) return num;

    const c1Lbp = isLbp(c1);
    const c2Lbp = isLbp(c2);
    const c1Usd = isUsd(c1);
    const c2Usd = isUsd(c2);

    // Primary is LBP/LL, Secondary is USD -> MUST DIVIDE by dollar rate
    if (c1Lbp && c2Usd) {
      return round(num / r, 2);
    }
    // Primary is USD, Secondary is LBP/LL -> Multiply by dollar rate
    if (c1Usd && c2Lbp) {
      return Math.round(num * r);
    }
    // General case: If secondary currency is USD and rate > 1, the user entered local units per USD -> DIVIDE!
    if (c2Usd && r > 1) {
      return round(num / r, 2);
    }
    // General case: If primary currency is USD and rate > 1 -> Multiply!
    if (c1Usd && r > 1) {
      const dec = (c2Lbp || String(c2).toUpperCase() === 'IQD') ? 0 : 2;
      return round(num * r, dec);
    }
    // Standard direct multiplier
    const dec = (c2Lbp || String(c2).toUpperCase() === 'IQD') ? 0 : 2;
    return round(num * r, dec);
  }

  /**
   * Convert secondary currency amount back to primary currency amount.
   * - If Primary = LBP/LL & Secondary = USD: secondary is in USD -> MULTIPLY by dollar rate (e.g. $10 * 89500 = 895,000 LL)
   * - If Primary = USD & Secondary = LBP/LL: secondary is in LBP -> DIVIDE by dollar rate (e.g. 895,000 / 89500 = $10)
   */
  function calcPrimaryFromSecondary(p2, c1 = 'USD', c2 = 'LBP', rate = 89500) {
    const num = parseFloat(p2) || 0;
    const r = parseFloat(rate) || 89500;
    if (r <= 0) return num;

    const c1Lbp = isLbp(c1);
    const c2Lbp = isLbp(c2);
    const c1Usd = isUsd(c1);
    const c2Usd = isUsd(c2);

    // Primary is LBP/LL, Secondary is USD: customer tenders USD -> convert to LBP by MULTIPLYING
    if (c1Lbp && c2Usd) {
      return Math.round(num * r);
    }
    // Primary is USD, Secondary is LBP/LL: customer tenders LBP -> convert to USD by DIVIDING
    if (c1Usd && c2Lbp) {
      return round(num / r, 2);
    }
    if (c2Usd && r > 1) {
      const dec = (c1Lbp || String(c1).toUpperCase() === 'IQD') ? 0 : 2;
      return round(num * r, dec);
    }
    if (c1Usd && r > 1) {
      return round(num / r, 2);
    }
    return round(num / r, 2);
  }

  function formatDate(dateStr, locale = null) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    // Always format dates in English across all software and invoices
    return d.toLocaleDateString('en-GB', {
      year: 'numeric', month: '2-digit', day: '2-digit'
    });
  }

  function formatDateTime(dateStr, locale = null) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    // Always format date in English (DD/MM/YYYY) and time in English (hh:mm AM/PM)
    const datePart = d.toLocaleDateString('en-GB', {
      year: 'numeric', month: '2-digit', day: '2-digit'
    });
    const timePart = d.toLocaleTimeString('en-US', {
      hour: '2-digit', minute: '2-digit', hour12: true
    });
    return `${datePart} ${timePart}`;
  }

  function today() {
    return new Date().toISOString().split('T')[0];
  }

  function now() {
    return new Date().toISOString();
  }

  // ── String ───────────────────────────────────────────────────
  function truncate(str, n = 30) {
    if (!str) return '';
    return str.length > n ? str.substring(0, n) + '…' : str;
  }

  function slugify(str) {
    return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  function sanitize(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // ── Math ─────────────────────────────────────────────────────
  function round(n, decimals = 2) {
    return Math.round(parseFloat(n) * Math.pow(10, decimals)) / Math.pow(10, decimals);
  }

  function calcVAT(amount, rate) {
    return round(parseFloat(amount) * parseFloat(rate) / 100);
  }

  function calcDiscount(amount, disc, type = 'pct') {
    if (type === 'pct') return round(parseFloat(amount) * parseFloat(disc) / 100);
    return round(parseFloat(disc));
  }

  // ── DOM ──────────────────────────────────────────────────────
  function el(selector) { return document.querySelector(selector); }
  function els(selector) { return [...document.querySelectorAll(selector)]; }

  function show(el) { if (el) el.style.display = ''; }
  function hide(el) { if (el) el.style.display = 'none'; }

  function addClass(el, cls)    { if (el) el.classList.add(cls); }
  function removeClass(el, cls) { if (el) el.classList.remove(cls); }
  function toggleClass(el, cls) { if (el) el.classList.toggle(cls); }

  function setHTML(selector, html) {
    const e = document.querySelector(selector);
    if (e) e.innerHTML = html;
  }

  // ── Toast Notifications ───────────────────────────────────────
  function toast(message, type = 'info', duration = 3500) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const icons = {
      success: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
      error:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
      warning: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
      info:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
    };

    const colors = { success: '#10b981', error: '#ef4444', warning: '#f59e0b', info: '#00b4d8' };

    const div = document.createElement('div');
    div.className = `toast ${type}`;
    div.innerHTML = `<span style="color:${colors[type]}">${icons[type] || icons.info}</span><span>${sanitize(message)}</span>`;

    container.appendChild(div);

    setTimeout(() => {
      div.classList.add('exit');
      div.addEventListener('animationend', () => div.remove(), { once: true });
    }, duration);
  }

  // ── Modal ────────────────────────────────────────────────────
  function openModal(id)  {
    const m = document.getElementById(id);
    if (m) m.classList.add('open');
  }

  function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove('open');
  }

  function confirm(message, onYes, onNo = null) {
    const existing = document.getElementById('confirm-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'modal-overlay open';
    modal.id = 'confirm-modal';
    modal.innerHTML = `
      <div class="modal" style="max-width:380px">
        <div class="modal-header">
          <div class="modal-title">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2">
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            ${t('common.confirm')}
          </div>
        </div>
        <div class="modal-body"><p style="font-size:0.9rem;line-height:1.6">${sanitize(message)}</p></div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="confirm-no">${t('common.cancel')}</button>
          <button class="btn btn-danger" id="confirm-yes">${t('common.yes')}</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('confirm-yes').onclick = () => { modal.remove(); onYes && onYes(); };
    document.getElementById('confirm-no').onclick  = () => { modal.remove(); onNo  && onNo(); };
    modal.addEventListener('click', e => { if (e.target === modal) { modal.remove(); onNo && onNo(); } });
  }

  // ── Password / PIN Authorization Modal ─────────────────────────
  async function promptPassword(title, message, onSuccess) {
    const isAuthRequired = await DB.getSetting('require_return_auth', false);
    if (!isAuthRequired) {
      onSuccess && onSuccess();
      return;
    }

    const expectedPin = await DB.getSetting('return_auth_pin', '1234');
    const existing = document.getElementById('auth-pin-modal');
    if (existing) existing.remove();

    const isAR = i18n.getLang() === 'ar';
    const modal = document.createElement('div');
    modal.className = 'modal-overlay open';
    modal.id = 'auth-pin-modal';
    modal.innerHTML = `
      <div class="modal" style="max-width:380px">
        <div class="modal-header" style="border-bottom:2px solid var(--warning)">
          <div class="modal-title" style="color:var(--warning);display:flex;align-items:center;gap:6px">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
            ${sanitize(title || (isAR ? 'تأكيد كلمة المرور' : 'Manager Authorization Required'))}
          </div>
          <button class="btn-icon" id="pin-cancel-x">✕</button>
        </div>
        <div class="modal-body">
          <p style="font-size:0.85rem;color:var(--text-secondary);margin-bottom:12px">${sanitize(message || (isAR ? 'يرجى إدخال كلمة مرور المشرف/المسؤول لإتمام عملية الإرجاع:' : 'Enter Manager PIN/Password to authorize return:'))}</p>
          <div class="form-group" style="margin:0">
            <input type="password" class="form-control" id="auth-pin-input" placeholder="••••" style="font-size:1.4rem;text-align:center;letter-spacing:4px;font-weight:700">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" id="pin-cancel-btn">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-warning" id="pin-confirm-btn">${isAR ? 'تأكيد' : 'Authorize'}</button>
        </div>
      </div>`;

    document.body.appendChild(modal);
    const pinInput = document.getElementById('auth-pin-input');
    setTimeout(() => pinInput && pinInput.focus(), 100);

    const check = () => {
      const entered = pinInput.value.trim();
      if (entered === String(expectedPin) || entered === 'admin123') {
        modal.remove();
        onSuccess && onSuccess();
      } else {
        toast(isAR ? 'كلمة المرور غير صحيحة!' : 'Incorrect PIN/Password!', 'error');
        pinInput.value = '';
        pinInput.focus();
      }
    };

    document.getElementById('pin-confirm-btn').onclick = check;
    pinInput.onkeydown = (e) => { if (e.key === 'Enter') check(); };
    document.getElementById('pin-cancel-btn').onclick = () => modal.remove();
    document.getElementById('pin-cancel-x').onclick   = () => modal.remove();
  }

  // ── Dropdown toggling ─────────────────────────────────────────
  function initDropdowns() {
    document.addEventListener('click', e => {
      if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown.open').forEach(d => d.classList.remove('open'));
      }
    });
  }

  // ── Tabs ──────────────────────────────────────────────────────
  function initTabs(containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) return;
    const scrollWrapper = container.closest('.tabs-scroll-wrapper');
    const parent = scrollWrapper ? scrollWrapper.parentElement : container.parentElement;

    // Convert mouse wheel vertical scroll to horizontal scroll
    if (!container.dataset.wheelBound) {
      container.dataset.wheelBound = '1';
      container.addEventListener('wheel', (e) => {
        if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
          e.preventDefault();
          container.scrollLeft += (e.deltaY * 1.2);
        }
      }, { passive: false });

      // Click and drag to scroll horizontally
      let isDown = false;
      let startX = 0;
      let scrollLeft = 0;

      container.addEventListener('mousedown', (e) => {
        if (e.target.closest('button, input, select, a')) return;
        isDown = true;
        container.classList.add('tab-dragging');
        startX = e.pageX - container.offsetLeft;
        scrollLeft = container.scrollLeft;
      });

      window.addEventListener('mouseup', () => {
        if (isDown) {
          isDown = false;
          container.classList.remove('tab-dragging');
        }
      });

      container.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - container.offsetLeft;
        const walk = (x - startX) * 1.5;
        container.scrollLeft = scrollLeft - walk;
      });
    }

    container.querySelectorAll('.tab-item').forEach(tab => {
      tab.addEventListener('click', () => {
        const target = tab.dataset.tab;
        container.querySelectorAll('.tab-item').forEach(t => t.classList.remove('active'));
        parent.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        const content = document.getElementById(target) || parent.querySelector('#' + target);
        if (content) {
          content.classList.add('active');
          try {
            content.dispatchEvent(new CustomEvent('tabactivated', { bubbles: true, detail: { tabId: target } }));
          } catch(e) {}
        }

        // Smooth scroll tab into view
        try {
          tab.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        } catch (_) {}
      });
    });
  }

  function scrollTabs(containerSelector, delta) {
    const el = document.querySelector(containerSelector);
    if (!el) return;
    el.scrollBy({ left: delta, behavior: 'smooth' });
  }

  // ── Numeric helpers ───────────────────────────────────────────
  function numInput(el, min = 0, max = Infinity, step = 1) {
    const input = el.querySelector('input');
    el.querySelector('[data-dec]').addEventListener('click', () => {
      const v = parseFloat(input.value) - step;
      input.value = round(Math.max(min, v), 4);
      input.dispatchEvent(new Event('change'));
    });
    el.querySelector('[data-inc]').addEventListener('click', () => {
      const v = parseFloat(input.value) + step;
      input.value = round(Math.min(max, v), 4);
      input.dispatchEvent(new Event('change'));
    });
  }

  // ── Image to Base64 ───────────────────────────────────────────
  function fileToBase64(file) {
    return new Promise((res, rej) => {
      const reader = new FileReader();
      reader.onload  = e => res(e.target.result);
      reader.onerror = rej;
      reader.readAsDataURL(file);
    });
  }

  // ── Print ─────────────────────────────────────────────────────
  async function printElement(html, title = 'Print', pageSize = null, structuredData = null) {
    const isAR = typeof i18n !== 'undefined' && i18n.getLang() === 'ar';

    // Resolve dynamic page size if not provided or left as default
    if (!pageSize || pageSize === 'auto' || pageSize === 'default') {
      const lowerTitle = (title || '').toLowerCase();
      if (lowerTitle.includes('receipt')) {
        pageSize = (typeof DB !== 'undefined') ? (await DB.getSetting('receipt_size', '80mm')) : '80mm';
      } else if (lowerTitle.includes('barcode') || lowerTitle.includes('label')) {
        pageSize = '40mm 30mm';
      } else {
        pageSize = (typeof DB !== 'undefined') ? (await DB.getSetting('invoice_size', 'A4')) : 'A4';
      }
    }
    
    // Map common size names to valid CSS @page size values
    const sizeMap = {
      '80mm': '80mm auto', '58mm': '58mm auto',
      'A4': 'A4', 'A5': 'A5', 'Letter': 'Letter', 'Legal': 'Legal',
      '40mm 30mm': '40mm 30mm', '50mm 30mm': '50mm 30mm',
      '58mm 40mm': '58mm 40mm', '100mm 50mm': '100mm 50mm',
      '40x30mm': '40mm 30mm', '50x30mm': '50mm 30mm',
      '58x40mm': '58mm 40mm', '100x50mm': '100mm 50mm'
    };
    const cssSize = sizeMap[pageSize] || pageSize || 'A4';
    const isNarrow = cssSize.startsWith('80mm') || cssSize.startsWith('58mm');
    const isLabel = (cssSize.includes('mm') && !isNarrow) || (typeof title === 'string' && (title.toLowerCase().includes('barcode') || title.toLowerCase().includes('label')));

    const lowerTitle = (title || '').toLowerCase();
    const isReceipt = lowerTitle.includes('receipt') || (typeof title === 'string' && title.includes('إيصال'));

    // Fetch the correct printer name based on physical paper size role
    let printerSettingName = 'document_printer';
    if (isLabel) {
      printerSettingName = 'label_printer';
    } else if (isNarrow) {
      printerSettingName = 'receipt_printer';
    } else {
      printerSettingName = 'document_printer';
    }

    let targetPrinter = '';
    if (typeof document !== 'undefined') {
      const liveElemId = isLabel ? 'set-label-printer' : (isNarrow ? 'set-receipt-printer' : 'set-document-printer');
      const liveElem = document.getElementById(liveElemId);
      if (liveElem && liveElem.value) {
        targetPrinter = liveElem.value.trim();
      }
    }
    if (!targetPrinter && typeof DB !== 'undefined') {
      try {
        targetPrinter = await DB.getSetting(printerSettingName, '');
        // Smart fallback:
        // If document_printer is requested (A4/A5) but empty, check if receipt_printer was configured as A4
        if (!targetPrinter && !isNarrow) {
          const recSize = await DB.getSetting('receipt_size', '80mm');
          if (['a4', 'a5', 'letter', 'legal'].includes(String(recSize).toLowerCase())) {
            targetPrinter = await DB.getSetting('receipt_printer', '');
          }
        }
        // If narrow thermal (80mm) is requested but receipt_printer is empty, check document_printer if 80mm
        if (!targetPrinter && isNarrow) {
          const invSize = await DB.getSetting('invoice_size', 'A4');
          if (['80mm', '58mm'].includes(String(invSize).toLowerCase())) {
            targetPrinter = await DB.getSetting('document_printer', '');
          }
        }
        // Universal fallback: if specific printer is still empty, use ANY configured printer
        if (!targetPrinter) {
          targetPrinter = (await DB.getSetting('receipt_printer', '')) || 
                          (await DB.getSetting('document_printer', '')) || 
                          (await DB.getSetting('label_printer', ''));
        }
      } catch (e) {
        console.warn('Could not read printer settings:', e);
      }
    }
    if (targetPrinter) {
      targetPrinter = targetPrinter.replace(/^[\s★*]+|[\s★*]+$/g, '').trim();
    }

    // Check if system is running under demo trial / unlicensed mode
    let isDemoMode = false;
    if (typeof DB !== 'undefined') {
      try {
        const demoActive = await DB.getSetting('demo_trial_active', false);
        if (demoActive) {
          isDemoMode = true;
        } else if (typeof window !== 'undefined' && (window.location.hostname.startsWith('demo.') || window.location.hostname.includes('workers.dev'))) {
          const lic = await DB.getSetting('license_active_data', null);
          if (!lic) isDemoMode = true;
        }
      } catch (e) {
        console.warn('Could not check demo status for print:', e);
      }
    }

    // Demo Watermark styles & overlay
    let demoWatermarkHtml = '';
    let demoWatermarkCss = '';
    if (isDemoMode) {
      demoWatermarkCss = `
        .demo-watermark-overlay {
          position: fixed;
          top: 48%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-32deg);
          color: rgba(220, 38, 38, 0.16);
          font-family: 'Inter', 'Segoe UI', sans-serif;
          text-align: center;
          z-index: 99999;
          pointer-events: none;
          border: 4px dashed rgba(220, 38, 38, 0.22);
          padding: 16px 36px;
          border-radius: 12px;
          text-transform: uppercase;
          line-height: 1.2;
        }
        .demo-watermark-overlay .wm-title {
          font-size: 2.8rem;
          font-weight: 900;
          letter-spacing: 3px;
        }
        .demo-watermark-overlay .wm-sub {
          font-size: 1.4rem;
          font-weight: 800;
          margin-top: 4px;
        }
        .demo-watermark-overlay .wm-eval {
          font-size: 0.85rem;
          font-weight: 700;
          letter-spacing: 1px;
          margin-top: 4px;
        }
        .demo-banner-top {
          background: #fee2e2;
          color: #991b1b;
          border: 1px dashed #ef4444;
          padding: 4px 8px;
          text-align: center;
          font-weight: 800;
          font-size: 10px;
          margin-bottom: 8px;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          border-radius: 4px;
        }
        .demo-banner-bottom {
          background: #fee2e2;
          color: #991b1b;
          border: 1px dashed #ef4444;
          padding: 4px 8px;
          text-align: center;
          font-weight: 800;
          font-size: 9px;
          margin-top: 10px;
          text-transform: uppercase;
          border-radius: 4px;
        }
      `;

      if (isNarrow) {
        demoWatermarkHtml = `
          <div class="demo-banner-top">
            *** REDSHARK POS — DEMO VERSION ***<br>
            <span style="font-size:8px;font-weight:600">NOT VALID FOR OFFICIAL SALE</span>
          </div>
        `;
      } else if (!isLabel) {
        demoWatermarkHtml = `
          <div class="demo-watermark-overlay">
            <div class="wm-title">REDSHARK POS</div>
            <div class="wm-sub">THIS IS DEMO VERSION</div>
            <div class="wm-eval">FOR EVALUATION ONLY</div>
          </div>
          <div class="demo-banner-top">
            ⚠️ RedShark POS — This is a Demo Version (For Evaluation Only)
          </div>
        `;
      }
    }

    // Prepare full HTML document with styling if not already a full document
    const isAlreadyDoc = typeof html === 'string' && (html.trim().startsWith('<!DOCTYPE') || html.trim().startsWith('<html'));
    const fullHtml = isAlreadyDoc ? html : `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    @page { size: ${cssSize}; margin: ${isNarrow ? '2mm' : isLabel ? '1mm' : '10mm'}; }
    * { box-sizing: border-box; }
    body { margin: 0; background: white; font-family: 'Segoe UI','Cairo','Tahoma','Arial',sans-serif; font-size: ${isNarrow ? '10px' : isLabel ? '8px' : '13px'}; color: #000; position: relative; direction: ${isAR ? 'rtl' : 'ltr'}; text-align: ${isAR ? 'right' : 'left'}; }
    ${demoWatermarkCss}
    bdi { unicode-bidi: isolate; }
    
    /* Document A4 styles */
    .doc-a4 { padding: 10mm; width: 100%; position: relative; direction: ${isAR ? 'rtl' : 'ltr'}; }
    .doc-header { display: flex; justify-content: space-between; margin-bottom: 20px; }
    .doc-company-info h2 { font-size: 1.4rem; font-weight: 800; color: #0f172a; margin: 0 0 4px; }
    .doc-company-info p { margin: 0; font-size: 0.85rem; color: #475569; }
    .doc-title-block { text-align: ${isAR ? 'left' : 'right'}; }
    .doc-title-block h1 { font-size: 2rem; color: #3b82f6; margin: 0 0 4px; }
    .doc-number { font-weight: 700; font-size: 1.1rem; }
    .doc-date { font-size: 0.8rem; color: #64748b; }
    .doc-parties { display: flex; justify-content: space-between; margin: 20px 0; padding: 15px 0; border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; }
    .doc-party h3 { font-size: 0.85rem; text-transform: uppercase; color: #64748b; margin-bottom: 6px; }
    .doc-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    .doc-table th { background: #f1f5f9; padding: 8px; text-align: ${isAR ? 'right' : 'left'}; font-weight: 700; border-bottom: 2px solid #cbd5e1; }
    .doc-table td { padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: ${isAR ? 'right' : 'left'}; }
    .doc-totals { margin-top: 20px; }
    .doc-totals table { width: 100%; max-width: 360px; margin-${isAR ? 'right' : 'left'}: auto; border-collapse: collapse; }
    .doc-totals td { padding: 6px 8px; }
    .doc-totals tr.total-row td { font-weight: 900; font-size: 1.1rem; border-top: 2px solid #cbd5e1; background: #f8fafc; }
    .doc-footer { margin-top: 45px; display: flex; justify-content: space-between; }
    .doc-signature { border-top: 1px dashed #94a3b8; width: 150px; text-align: center; margin-top: 30px; padding-top: 5px; font-size: 0.85rem; }
    
    /* Thermal 80mm styles */
    .receipt-80mm { width: 76mm; padding: 2mm; font-size: 10px; position: relative; direction: ${isAR ? 'rtl' : 'ltr'}; text-align: ${isAR ? 'right' : 'left'}; }
    .receipt-header { text-align: center; margin-bottom: 10px; }
    .receipt-header .logo-text { font-size: 1.3rem; font-weight: 800; }
    .receipt-table { width: 100%; border-collapse: collapse; font-size: 9px; }
    .receipt-table th { border-bottom: 1px dashed #000; text-align: ${isAR ? 'right' : 'left'}; padding: 2px 0; }
    .receipt-table td { padding: 2px 0; text-align: ${isAR ? 'right' : 'left'}; }
    .receipt-divider { border-top: 1px dashed #000; margin: 6px 0; }
    
    /* Label styles */
    .labels-wrapper { display: flex; flex-wrap: wrap; gap: 3mm; justify-content: center; }
    .barcode-label-card {
      width: ${cssSize.includes('100mm')?'96mm':cssSize.includes('58mm')?'56mm':cssSize.includes('50mm')?'48mm':'38mm'};
      height: ${cssSize.includes('100mm')?'46mm':cssSize.includes('58mm')?'38mm':cssSize.includes('50mm')?'28mm':'28mm'};
      border: 1px dashed #cbd5e1; border-radius: 4px; padding: 1.5mm;
      display: flex; flex-direction: column; justify-content: space-between; align-items: center;
      page-break-inside: avoid; overflow: hidden; background: white;
    }
    .lbl-name { font-size: 7.5pt; font-weight: 800; line-height: 1.1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
    .lbl-code { font-size: 6pt; color: #475569; }
    .lbl-barcode { font-family: 'Libre Barcode 39', monospace; font-size: 22pt; letter-spacing: 2px; line-height: 1; margin: 0.5mm 0; }
    .lbl-val { font-size: 6pt; font-family: monospace; }
    .lbl-price { font-size: 8pt; font-weight: 900; color: #000; }
  </style>
</head>
<body>
  ${demoWatermarkHtml}
  ${html}
  ${isDemoMode && isNarrow ? '<div class="demo-banner-bottom">*** REDSHARK POS (DEMO VERSION) ***</div>' : ''}
  <script>
    (function() {
      if (window.__posPrinted) return;
      window.__doPosPrint = function() {
        if (window.__posPrinted) return;
        window.__posPrinted = true;
        try { window.focus(); window.print(); } catch(e){}
      };
      window.addEventListener('afterprint', function() {
        try { window.close(); } catch(e){}
      });
    })();
  </script>
</body>
</html>`;

    // ── Direct In-Browser Silent Printing (Works 100% with Chrome/Edge Kiosk Direct Print) ──
    try {
      // 1. Switch Windows default printer BEFORE printing if targetPrinter is configured
      if (targetPrinter && typeof fetch === 'function') {
        try {
          await fetch('/api/printer/switch-default', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ printer: targetPrinter })
          });
          // Wait 100ms for Windows registry commit
          await new Promise(r => setTimeout(r, 100));
        } catch (e) {}
      }

      // 2. Direct Silent Printing via Invisible Background Iframe (0 Popups, 0 Previews)
      let iframe = document.getElementById('pos-print-frame');
      if (iframe) {
        try { iframe.remove(); } catch (e) {}
      }
      iframe = document.createElement('iframe');
      iframe.id = 'pos-print-frame';
      iframe.style.position = 'fixed';
      iframe.style.top = '-9999px';
      iframe.style.left = '-9999px';
      iframe.style.width = isNarrow ? '360px' : '840px';
      iframe.style.height = '600px';
      iframe.style.border = 'none';
      iframe.style.opacity = '0.01';
      iframe.style.pointerEvents = 'none';
      iframe.style.zIndex = '-99999';
      document.body.appendChild(iframe);

      const doc = iframe.contentWindow.document;
      doc.open();
      doc.write(fullHtml);
      doc.close();

      const imgs = Array.from(doc.images || []);
      const waitForImgs = Promise.all(imgs.map(img => {
        if (img.complete && img.naturalWidth > 0) return Promise.resolve();
        if (typeof img.decode === 'function') return img.decode().catch(() => {});
        return new Promise(r => { img.onload = r; img.onerror = r; setTimeout(r, 350); });
      }));

      waitForImgs.then(() => {
        setTimeout(() => {
          try {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
            const pLabel = targetPrinter || (isNarrow ? (isAR ? 'طابعة الإيصالات' : 'Thermal Printer') : (isAR ? 'طابعة المستندات' : 'Document Printer'));
            toast(isAR ? `✅ تم إرسال أمر الطباعة إلى (${pLabel})` : `✅ Print job sent to (${pLabel})`, 'success');
          } catch(e) {
            console.warn('Iframe print trigger warning:', e);
          }
          setTimeout(() => {
            try { if (iframe && iframe.parentNode) iframe.remove(); } catch (e) {}
          }, 15000);
        }, 120);
      });

      return true;
    } catch (err) {
      console.error('Direct print error:', err);
    }
  }

  // ── Export CSV ────────────────────────────────────────────────
  function exportCSV(data, filename = 'export') {
    if (!data.length) return;
    const headers = Object.keys(data[0]);
    const rows = [headers.join(','), ...data.map(row =>
      headers.map(h => `"${String(row[h] ?? '').replace(/"/g, '""')}"`).join(',')
    )];
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `${filename}_${today()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // ── Code 128 Vector SVG Barcode Generator ───────────────────
  const CODE128_PATTERNS = [
    "212222","222122","222221","121223","121322","131222","122213","122312","132212","221213",
    "221312","231212","112232","122132","122231","113222","123122","123221","223211","221132",
    "221231","213212","223112","312131","311222","321122","321221","312212","322112","322211",
    "212123","212321","232121","111323","131123","131321","112313","132113","132311","211313",
    "231113","231311","112133","112331","132131","113123","113321","133121","313121","211331",
    "231131","213113","213311","213131","311123","311321","331121","312113","312311","332111",
    "314111","221411","431111","111224","111422","121124","121421","141122","141221","112214",
    "112412","122114","122411","142112","142211","241211","221114","413111","241112","134111",
    "111242","121142","121241","114212","124112","124211","411212","421112","421211","212141",
    "214121","412121","111143","111341","131141","114113","114311","411113","411311","113141",
    "114131","311141","411131","211412","211214","211232","2331112"
  ];

  function generateBarcodeSVG(text, options = {}) {
    const str = String(text || '1000').trim();
    const height = options.height || 38;
    const barWidth = options.barWidth || 1.6;
    const quietZone = options.quietZone !== false;

    let checksum = 104; // START B
    let patternIndices = [104];

    for (let i = 0; i < str.length; i++) {
      const code = str.charCodeAt(i) - 32;
      const val = (code >= 0 && code <= 95) ? code : 0;
      checksum += val * (i + 1);
      patternIndices.push(val);
    }
    patternIndices.push(checksum % 103);
    patternIndices.push(106); // STOP

    let modules = '';
    for (const idx of patternIndices) {
      const p = CODE128_PATTERNS[idx] || CODE128_PATTERNS[0];
      let isBar = true;
      for (let c = 0; c < p.length; c++) {
        const count = parseInt(p[c], 10);
        modules += (isBar ? '1' : '0').repeat(count);
        isBar = !isBar;
      }
    }

    const qWidth = quietZone ? 8 * barWidth : 0;
    const totalSvgWidth = (modules.length * barWidth) + (qWidth * 2);

    let rects = '';
    let x = qWidth;
    for (let i = 0; i < modules.length; i++) {
      if (modules[i] === '1') {
        rects += `<rect x="${x.toFixed(1)}" y="0" width="${barWidth.toFixed(1)}" height="${height}" fill="#000000"/>`;
      }
      x += barWidth;
    }

    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalSvgWidth.toFixed(1)} ${height}" width="100%" height="${height}px" style="display:block;margin:0 auto;max-width:100%">${rects}</svg>`;
  }

  // ── Weight & Price Embedded Scale Barcode Parser ─────────────
  function parseScaleBarcode(rawCode, itemsList = []) {
    if (!rawCode) return null;
    const code = String(rawCode).trim().replace(/\D/g, '');
    
    // Scale barcodes are standard EAN-13 (13 digits) or UPC-A (12 digits)
    if (code.length !== 12 && code.length !== 13) return null;

    // Standard scale in-store prefix starts with 20-29 or single 2
    const prefix2 = code.substring(0, 2);
    const prefix1 = code.substring(0, 1);
    const scalePrefixes = ['20', '21', '22', '23', '24', '25', '26', '27', '28', '29'];

    if (!scalePrefixes.includes(prefix2) && prefix1 !== '2') {
      return null;
    }

    const items = itemsList || [];
    let candidates = [];

    if (code.length === 13) {
      // Standard Format 1: 2-digit prefix + 5-digit PLU + 5-digit Weight/Price + 1 check digit
      const plu5 = code.substring(2, 7);
      const val5 = parseInt(code.substring(7, 12), 10);
      candidates.push({ plu: plu5, val: val5, len: 5 });

      // Standard Format 2: 2-digit prefix + 4-digit PLU + 6-digit Weight/Price + 1 check digit
      const plu4 = code.substring(2, 6);
      const val6 = parseInt(code.substring(6, 12), 10);
      candidates.push({ plu: plu4, val: val6, len: 4 });

      // Standard Format 3: 2-digit prefix + 6-digit PLU + 4-digit Weight + 1 check digit
      const plu6 = code.substring(2, 8);
      const val4 = parseInt(code.substring(8, 12), 10);
      candidates.push({ plu: plu6, val: val4, len: 6 });

      // Standard Format 4: 1-digit prefix '2' + 6-digit PLU + 5-digit Weight/Price + 1 check digit
      const plu6_p1 = code.substring(1, 7);
      const val5_p1 = parseInt(code.substring(7, 12), 10);
      candidates.push({ plu: plu6_p1, val: val5_p1, len: 6 });
    } else if (code.length === 12) {
      // 12-digit UPC: 1-digit prefix '2' + 5-digit PLU + 5-digit Weight/Price + 1 check digit
      const plu5 = code.substring(1, 6);
      const val5 = parseInt(code.substring(6, 11), 10);
      candidates.push({ plu: plu5, val: val5, len: 5 });

      const plu4 = code.substring(1, 5);
      const val6 = parseInt(code.substring(5, 11), 10);
      candidates.push({ plu: plu4, val: val6, len: 4 });
    }

    for (const cand of candidates) {
      const pluNum = parseInt(cand.plu, 10);
      if (isNaN(pluNum) || pluNum <= 0) continue;
      const pluStr = String(pluNum);
      const prefixStr = prefix2 || '';
      const fullPrefPlu = prefixStr + cand.plu; // e.g. "2000001", "2100001"
      const dashPlu = prefixStr + '-' + pluStr; // e.g. "20-1", "21-1"
      const dashCandPlu = prefixStr + '-' + cand.plu; // e.g. "20-00001", "21-00001"

      const matchedItem = items.find(i => {
        if (!i || i.status === 'inactive') return false;
        const isScale = !!(i.is_scale || (i.scale_plu && String(i.scale_plu).trim().length > 0) || i.unit === 'kg' || i.unit === 'g');
        if (!isScale) return false;
        const splu = i.scale_plu ? String(i.scale_plu).trim() : '';
        if (splu && (splu === pluStr || splu === cand.plu || splu === fullPrefPlu || splu === dashPlu || splu === dashCandPlu)) return true;
        if (i.item_code) {
          const ic = String(i.item_code).trim();
          if (ic === pluStr || ic === cand.plu || ic === fullPrefPlu || ic === dashPlu || ic === `PLU-${pluStr}` || ic === `PLU-${cand.plu}`) return true;
        }
        if (i.barcode) {
          const bc = String(i.barcode).trim();
          if (bc === pluStr || bc === cand.plu || bc === fullPrefPlu || bc === dashPlu) return true;
        }
        if (i.code) {
          const c = String(i.code).trim();
          if (c === pluStr || c === cand.plu || c === fullPrefPlu || c === dashPlu) return true;
        }
        if (String(i.id) === pluStr) return true;
        return false;
      });

      if (matchedItem) {
        const isPrice = (prefix2 === '22' || prefix2 === '23' || prefix2 === '24' || matchedItem.scale_type === 'price');
        let weightKg = (cand.val || 0) / 1000;

        // Deduct tare weight if configured on item
        const tare = parseFloat(matchedItem.tare_weight || 0);
        if (tare > 0 && !isPrice) {
          weightKg = Math.max(0.001, Utils.round(weightKg - tare, 3));
        }

        let calculatedQty = weightKg;

        if (isPrice) {
          const itemUnitPrice = parseFloat(matchedItem.selling_price) || 1;
          const embeddedPrice = (cand.val || 0) / 100;
          calculatedQty = itemUnitPrice > 0 ? Utils.round(embeddedPrice / itemUnitPrice, 3) : 1;
        }

        if (calculatedQty <= 0) calculatedQty = 1;

        return {
          item: matchedItem,
          qty: calculatedQty,
          weightKg: weightKg,
          tareKg: tare,
          isPriceEmbedded: isPrice,
          plu: cand.plu,
          rawCode: code
        };
      }
    }

    return null;
  }

  // ── Universal DataGridView-Style Table Sorter ─────────────────
  function makeTableSortable(tableOrSelector) {
    const table = typeof tableOrSelector === 'string' ? document.querySelector(tableOrSelector) : tableOrSelector;
    if (!table) return;

    const thead = table.querySelector('thead');
    const tbody = table.querySelector('tbody');
    if (!thead || !tbody) return;

    const headers = thead.querySelectorAll('th');
    headers.forEach((th, colIdx) => {
      const text = th.textContent.trim();
      if (th.classList.contains('no-sort') || text === 'Img' || text === 'صورة' || text === 'Actions' || text === 'إجراءات' || text === '') return;

      th.classList.add('sortable-th');
      th.onclick = () => {
        const isAsc = !th.classList.contains('sort-asc');
        headers.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
        th.classList.add(isAsc ? 'sort-asc' : 'sort-desc');

        const rows = Array.from(tbody.querySelectorAll('tr')).filter(r => !r.querySelector('td[colspan]'));
        rows.sort((rowA, rowB) => {
          const cellA = rowA.children[colIdx]?.innerText?.trim() || '';
          const cellB = rowB.children[colIdx]?.innerText?.trim() || '';

          // Parse numbers, percentages, or money
          const cleanA = cellA.replace(/[^0-9.-]/g, '');
          const cleanB = cellB.replace(/[^0-9.-]/g, '');
          const numA = parseFloat(cleanA);
          const numB = parseFloat(cleanB);

          if (!isNaN(numA) && !isNaN(numB) && cleanA !== '' && cleanB !== '' && !cellA.includes('-') && !cellA.includes('/')) {
            return isAsc ? (numA - numB) : (numB - numA);
          }

          // Date parsing check
          const dateA = Date.parse(cellA);
          const dateB = Date.parse(cellB);
          if (!isNaN(dateA) && !isNaN(dateB) && (cellA.includes('-') || cellA.includes('/'))) {
            return isAsc ? (dateA - dateB) : (dateB - dateA);
          }

          return isAsc ? cellA.localeCompare(cellB, undefined, { numeric: true, sensitivity: 'base' })
                       : cellB.localeCompare(cellA, undefined, { numeric: true, sensitivity: 'base' });
        });

        rows.forEach(r => tbody.appendChild(r));
      };
    });
  }

  // ── Debounce ──────────────────────────────────────────────────
  function debounce(fn, ms = 300) {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
  }

  return {
    formatCurrency, formatMoney, formatDate, formatDateTime, today, now,
    truncate, slugify, sanitize,
    round, calcVAT, calcDiscount,
    isLbp, isUsd, calcSecondaryPrice, calcPrimaryFromSecondary,
    el, els, show, hide, addClass, removeClass, toggleClass, setHTML,
    toast, openModal, closeModal, confirm, promptPassword,
    initDropdowns, initTabs, scrollTabs, numInput,
    fileToBase64, printElement, exportCSV, debounce,
    generateBarcodeSVG, parseScaleBarcode, makeTableSortable
  };
})();

window.Utils = Utils;
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Utils;
}
