/* ================================================================
   NexPOS — Admin Module (Users, Roles, Settings, Backup, Audit Log)
   ================================================================ */

const Admin = (() => {

  // ── Users & Roles ─────────────────────────────────────────────
  async function renderUsers(container) {
    const users = await DB.getAll('users');
    const roles = await DB.getAll('roles');
    const isAR  = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'المستخدمون' : 'Users'}</h1>
          <p>${isAR ? `${users.length} مستخدم` : `${users.length} users`}</p>
        </div>
        <div class="page-actions" style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="App.navigate('roles')">
            🛡️ ${isAR ? 'الأدوار والصلاحيات' : 'Roles & Privileges'}
          </button>
          <button class="btn btn-primary" onclick="Admin.openUserForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'مستخدم جديد' : 'New User'}
          </button>
        </div>
      </div>

      <div class="grid grid-3" style="gap:16px" id="users-grid">
        ${users.map(u => {
          const roleIcons = {
            admin: '⚙️',
            manager: '🏬',
            accountant: '💵',
            salesperson: '📄',
            cashier: '🛒',
            inventory_clerk: '📦',
            demo: '✨'
          };
          const roleIcon = roleIcons[u.role] || '👤';
          const isCurrentUser = u.id === Auth.getUser()?.id;

          return `
          <div class="card" style="display:flex;flex-direction:column;justify-content:space-between;padding:16px;border-radius:14px;border:1px solid var(--border-color);background:var(--surface);box-shadow:var(--shadow-sm);transition:all 0.2s ease;gap:12px;position:relative">
            <div style="display:flex;align-items:flex-start;gap:12px">
              <div style="width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;color:white;font-weight:800;font-size:1.1rem;flex-shrink:0;box-shadow:0 4px 12px rgba(239,68,68,0.25)">
                ${(u.full_name||u.username||'?')[0].toUpperCase()}
              </div>
              <div style="flex:1;min-width:0">
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${u.full_name||u.username}">
                    ${u.full_name||u.username}
                  </div>
                </div>
                <div style="font-size:0.8rem;color:var(--text-muted);margin-top:1px;display:flex;align-items:center;gap:4px">
                  <span>@${u.username}</span>
                </div>
                <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${u.email||''}">
                  ${u.email ? `✉️ ${u.email}` : ''}
                </div>
              </div>
            </div>

            <div style="display:flex;align-items:center;justify-content:space-between;border-top:1px solid var(--border-color);padding-top:10px;margin-top:2px">
              <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
                <span class="badge" style="background:rgba(239,68,68,0.15);color:var(--primary);font-weight:700;font-size:0.75rem;padding:4px 8px;border-radius:6px;display:inline-flex;align-items:center;gap:4px" title="${isAR ? 'الدور الوظيفي للمستخدم' : 'Assigned User Role'}">
                  ${roleIcon} ${u.role||'cashier'}
                </span>
                <span class="badge badge-${u.status==='active'?'success':'secondary'}" style="font-size:0.72rem;padding:3px 7px;border-radius:6px" title="${isAR ? 'حالة الحساب' : 'Account Status'}">
                  ${u.status==='active' ? (isAR ? '🟢 نشط' : '🟢 Active') : (isAR ? '🔴 غير نشط' : '🔴 Inactive')}
                </span>
              </div>

              <!-- Action Buttons with Meaningful Icons & Hover Tooltips -->
              <div style="display:flex;align-items:center;gap:4px">
                <button class="btn btn-secondary btn-sm" onclick="Admin.openUserForm(${u.id})" style="padding:5px 10px;border-radius:8px;font-size:0.82rem;font-weight:700;display:inline-flex;align-items:center;gap:4px" title="${isAR ? 'تعديل بيانات المستخدم والصلاحيات' : 'Edit user details & permissions'}">
                  <span>✏️</span> <span>${isAR ? 'تعديل' : 'Edit'}</span>
                </button>

                ${!isCurrentUser ? `
                <button class="btn btn-ghost btn-sm" onclick="Admin.deleteUser(${u.id})" style="color:var(--danger);padding:5px 8px;border-radius:8px;font-size:0.85rem" title="${isAR ? 'حذف هذا المستخدم نهائياً' : 'Permanently delete this user'}">
                  <span>🗑️</span>
                </button>` : `<span style="font-size:0.72rem;color:var(--text-muted);padding:4px 6px" title="${isAR ? 'حسابك الحالي' : 'Your active session'}">👤 ${isAR ? 'أنت' : 'You'}</span>`}
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>

    <!-- User Form Modal -->
    <div class="modal-overlay" id="user-modal">
      <div class="modal" style="max-width:660px;border-radius:18px;box-shadow:0 25px 60px rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.12)">
        <div class="modal-header" style="padding:18px 24px;border-bottom:1px solid var(--border-color)">
          <div class="modal-title" id="user-modal-title" style="font-size:1.2rem;font-weight:800">${isAR ? 'مستخدم جديد' : 'New User'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('user-modal')" style="font-size:1.1rem">✕</button>
        </div>
        <div class="modal-body" style="padding:22px 24px;max-height:75vh;overflow-y:auto">
          <div class="grid grid-2" style="gap:16px">
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR?'الاسم الكامل':'Full Name'} *</label>
              <input type="text" class="form-control" id="user-fullname" placeholder="${isAR?'مثال: سامر عيد':'e.g. Samer Eid'}" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR?'اسم المستخدم':'Login Username'} *</label>
              <input type="text" class="form-control" id="user-username" placeholder="${isAR?'مثال: samer':'e.g. samer'}" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR?'البريد الإلكتروني':'Email Address'}</label>
              <input type="email" class="form-control" id="user-email" placeholder="user@example.com" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR?'الدور الوظيفي':'User Role'} *</label>
              <select class="form-control" id="user-role" style="font-size:0.95rem;font-weight:700;padding:11px 14px;border-radius:10px;background:var(--surface-2);color:var(--text-primary)">
                <option value="cashier">🛒 ${isAR?'كاشير نقطة البيع':'POS Cashier'}</option>
                <option value="demo">✨ ${isAR?'مستخدم تجريبي (Demo)':'Demo / Trial User'}</option>
                <option value="salesperson">📄 ${isAR?'مندوب مبيعات':'Sales Representative'}</option>
                <option value="inventory_clerk">📦 ${isAR?'أمين المستودع':'Inventory Supervisor'}</option>
                <option value="accountant">💵 ${isAR?'محاسب عام':'Chief Accountant'}</option>
                <option value="manager">🏬 ${isAR?'مدير المتجر':'Store Manager'}</option>
                <option value="admin">⚙️ ${isAR?'مسؤول النظام':'Administrator'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR?'كلمة المرور':'Password'}</label>
              <input type="password" class="form-control" id="user-password" placeholder="${isAR?'اتركه فارغاً للإبقاء على الحالية':'Leave empty to keep current'}" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR?'حالة الحساب':'Account Status'}</label>
              <select class="form-control" id="user-status" style="font-size:0.95rem;font-weight:700;padding:11px 14px;border-radius:10px">
                <option value="active">🟢 ${isAR?'نشط':'Active'}</option>
                <option value="inactive">🔴 ${isAR?'غير نشط':'Inactive'}</option>
              </select>
            </div>
          </div>

          <!-- Permissions Section -->
          <div style="margin-top:22px;border-top:1px solid var(--border-color);padding-top:16px">
            <!-- Dynamic Role Inheritance Mode Switch -->
            <div style="background:rgba(37,99,235,0.08);border:1.5px solid rgba(37,99,235,0.25);border-radius:10px;padding:12px 14px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between">
              <label style="display:flex;align-items:center;gap:10px;cursor:pointer;margin:0;font-weight:700;font-size:0.88rem;color:var(--text-primary)">
                <input type="checkbox" id="user-inherit-role" checked onchange="Admin.toggleInheritRole(this.checked)" style="width:18px;height:18px;accent-color:var(--primary);cursor:pointer">
                <span>🛡️ ${isAR ? 'توارث الصلاحيات تلقائياً وديناميكياً من الدور المحدد (مستحسن)' : 'Inherit permissions dynamically from assigned Role (Recommended)'}</span>
              </label>
              <span id="inherit-role-badge" class="badge" style="background:#2563eb;color:#ffffff;font-size:0.75rem;font-weight:800;padding:4px 8px;border-radius:6px">${isAR ? 'مرتبط بالدور' : 'Role Synced'}</span>
            </div>

            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
              <div>
                <label class="form-label" style="font-size:0.95rem;font-weight:800;margin:0">🔐 ${isAR?'الصلاحيات الممنوحة لهذا المستخدم':'Assigned Permissions & Modules'}</label>
                <span id="perm-subtitle" style="font-size:0.78rem;color:var(--text-muted)">${isAR?'يتم تحديثها تلقائياً عند تغيير الدور المحدد':'Auto-synced with selected Role dynamically'}</span>
              </div>
              <div id="perm-bulk-actions" style="display:flex;gap:6px">
                <button type="button" class="btn btn-secondary btn-sm" onclick="document.querySelectorAll('.perm-check').forEach(cb => cb.checked = true)" style="font-size:0.75rem;padding:4px 8px">
                  ${isAR?'تحديد الكل':'Select All'}
                </button>
                <button type="button" class="btn btn-ghost btn-sm" onclick="document.querySelectorAll('.perm-check').forEach(cb => cb.checked = false)" style="font-size:0.75rem;padding:4px 8px">
                  ${isAR?'إلغاء الكل':'Deselect All'}
                </button>
              </div>
            </div>

            <div class="grid grid-3" style="gap:8px" id="perm-checkbox-grid">
              ${[
                ['pos', '🛒', isAR?'نقطة البيع':'Point of Sale (POS)'],
                ['items', '📦', isAR?'الأصناف والمخزون':'Items & Catalog'],
                ['customers', '👥', isAR?'العملاء':'Customers (CRM)'],
                ['suppliers', '🏭', isAR?'الموردون':'Suppliers'],
                ['purchasing', '🛍️', isAR?'المشتريات':'Purchasing & PO'],
                ['sales', '📄', isAR?'المبيعات والفواتير':'Sales Invoices'],
                ['inventory', '📊', isAR?'المستودعات والجرد':'Stock Movements'],
                ['finance', '💵', isAR?'المالية والحسابات':'Finance & Accounts'],
                ['hr', '👔', isAR?'الموارد البشرية':'HR & Staff'],
                ['payroll', '💰', isAR?'الرواتب':'Payroll'],
                ['reports', '📈', isAR?'التقارير والإحصائيات':'Reports & Analytics'],
                ['admin', '⚙️', isAR?'لوحة الإدارة':'Administration'],
              ].map(([perm, icon, label]) => `
              <label style="display:flex;align-items:center;gap:8px;padding:10px 12px;background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;cursor:pointer;transition:all 0.2s ease;font-size:0.86rem;font-weight:600;color:var(--text-primary)">
                <input type="checkbox" class="perm-check" value="${perm}" id="perm-${perm}" style="width:16px;height:16px;accent-color:var(--primary);cursor:pointer">
                <span>${icon}</span>
                <span style="line-height:1.2">${label}</span>
              </label>`).join('')}
            </div>
          </div>
        </div>
        <div class="modal-footer" style="padding:16px 24px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:10px">
          <button class="btn btn-ghost" onclick="Utils.closeModal('user-modal')" style="font-size:0.9rem;padding:9px 18px">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="Admin.saveUser()" style="font-size:0.9rem;font-weight:800;padding:9px 22px">💾 ${isAR?'حفظ المستخدم':'Save User'}</button>
        </div>
      </div>
    </div>`;

    window._allUsersAdmin = users;
  }

  function toggleInheritRole(isInherited) {
    const isAR = i18n.getLang() === 'ar';
    const badge = document.getElementById('inherit-role-badge');
    const bulk = document.getElementById('perm-bulk-actions');
    const subtitle = document.getElementById('perm-subtitle');
    const roleSel = document.getElementById('user-role');

    if (badge) {
      badge.textContent = isInherited ? (isAR ? 'مرتبط بالدور' : 'Role Synced') : (isAR ? 'صلاحيات مخصصة' : 'Custom Overrides');
      badge.style.background = isInherited ? '#2563eb' : '#f59e0b';
    }
    if (bulk) bulk.style.opacity = isInherited ? '0.4' : '1';
    if (subtitle) {
      subtitle.textContent = isInherited 
        ? (isAR ? 'يتم توارث هذه الصلاحيات تلقائياً وديناميكياً من الدور المحدد' : 'Permissions are actively inherited and synced from the selected Role')
        : (isAR ? 'صلاحيات مخصصة واستثنائية لهذا المستخدم تحديداً' : 'Custom standalone permissions granted exclusively to this user');
    }

    if (isInherited && roleSel) {
      roleSel.dispatchEvent(new Event('change'));
    }
  }

  async function openUserForm(id = null) {
    window._editUserId = id;
    const isAR = i18n.getLang() === 'ar';
    document.getElementById('user-modal-title').textContent = id ? (isAR?'تعديل مستخدم':'Edit User') : (isAR?'مستخدم جديد':'New User');
    ['user-fullname','user-username','user-email','user-password'].forEach(f => { const el=document.getElementById(f); if(el) el.value=''; });
    document.querySelectorAll('.perm-check').forEach(cb => cb.checked = false);

    // Populate role dropdown dynamically with all system roles guaranteed
    let roles = await DB.getAll('roles');
    let neededSync = false;
    for (const defRole of DEFAULT_SYSTEM_ROLES) {
      if (!roles.some(r => r.code === defRole.code)) {
        await DB.add('roles', defRole);
        neededSync = true;
      }
    }
    if (neededSync || !roles.length) {
      roles = await DB.getAll('roles');
    }
    const roleSel = document.getElementById('user-role');
    if (roleSel) {
      roleSel.innerHTML = roles.map(r => {
        const name = isAR ? (r.name_ar || r.name_en || r.code) : (r.name_en || r.name_ar || r.code);
        return `<option value="${r.code}">${Utils.sanitize(name)}</option>`;
      }).join('');

      roleSel.onchange = () => {
        const roleCode = roleSel.value;
        const matchedRole = roles.find(r => r.code === roleCode);
        let perms = [];
        if (matchedRole) {
          perms = Array.isArray(matchedRole.permissions) ? matchedRole.permissions : (matchedRole.permissions ? JSON.parse(matchedRole.permissions) : []);
        }
        if (!perms.length) {
          const defaults = {
            admin:           ['pos','items','customers','suppliers','purchasing','sales','inventory','finance','hr','payroll','reports','admin'],
            manager:         ['pos','items','customers','suppliers','purchasing','sales','inventory','finance','hr','payroll','reports'],
            accountant:      ['finance','reports','customers','suppliers'],
            salesperson:     ['pos','sales','customers','items'],
            cashier:         ['pos'],
            inventory_clerk: ['items','inventory','purchasing'],
            demo:            ['pos','items','reports']
          };
          perms = defaults[roleCode] || ['pos'];
        }
        document.querySelectorAll('.perm-check').forEach(cb => { 
          cb.checked = perms.some(p => p === cb.value || p.startsWith(cb.value + '.')); 
        });
      };
    }

    if (id) {
      const user = await DB.get('users', id);
      if (user) {
        document.getElementById('user-fullname').value = user.full_name||'';
        document.getElementById('user-username').value = user.username||'';
        document.getElementById('user-email').value    = user.email||'';
        document.getElementById('user-role').value     = user.role||'cashier';
        document.getElementById('user-status').value   = user.status||'active';

        const isInherited = user.inherit_role !== false;
        const inheritCb = document.getElementById('user-inherit-role');
        if (inheritCb) {
          inheritCb.checked = isInherited;
          toggleInheritRole(isInherited);
        }

        let perms = [];
        if (user.permissions) {
          perms = typeof user.permissions === 'string' ? JSON.parse(user.permissions) : user.permissions;
        }
        if (isInherited || !perms || !perms.length) {
          if (roleSel) roleSel.dispatchEvent(new Event('change'));
        } else {
          document.querySelectorAll('.perm-check').forEach(cb => { 
            cb.checked = perms.some(p => p === cb.value || p.startsWith(cb.value + '.')); 
          });
        }
      }
    } else {
      const inheritCb = document.getElementById('user-inherit-role');
      if (inheritCb) {
        inheritCb.checked = true;
        toggleInheritRole(true);
      }
      if (roleSel) roleSel.dispatchEvent(new Event('change'));
    }
    Utils.openModal('user-modal');
  }

  async function saveUser() {
    const isAR = i18n.getLang() === 'ar';
    const username = document.getElementById('user-username').value.trim();
    if (!username) { Utils.toast(i18n.t('common.required'), 'warning'); return; }
    
    const inheritRole = document.getElementById('user-inherit-role')?.checked ?? true;
    const perms = [...document.querySelectorAll('.perm-check:checked')].map(cb => cb.value);
    const password = document.getElementById('user-password').value;
    const data = {
      full_name:    document.getElementById('user-fullname').value.trim(),
      username,
      email:        document.getElementById('user-email').value.trim(),
      role:         document.getElementById('user-role').value,
      status:       document.getElementById('user-status').value,
      inherit_role: inheritRole,
      permissions:  inheritRole ? null : JSON.stringify(perms),
    };
    if (password) data.password = password;

    try {
      if (window._editUserId) {
        const existing = await DB.get('users', window._editUserId);
        await DB.update('users', { ...existing, ...data, id: window._editUserId });
      } else {
        if (!password) { Utils.toast(isAR?'كلمة المرور مطلوبة':'Password required', 'warning'); return; }
        await DB.add('users', data);
      }
      Utils.closeModal('user-modal');
      Utils.toast(i18n.t('common.saved'), 'success');
      await renderUsers(document.getElementById('page-content'));
    } catch(e) { Utils.toast('Error: ' + e.message, 'error'); }
  }

  function deleteUser(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('users', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await renderUsers(document.getElementById('page-content'));
    });
  }

  // ── Roles & Privileges ─────────────────────────────────────────
  const DEFAULT_SYSTEM_ROLES = [
    {
      code: 'admin',
      name_en: 'Administrator',
      name_ar: 'مسؤول النظام',
      description_en: 'Full unrestricted system access, configurations, overrides, and price editing',
      description_ar: 'صلاحيات كاملة وغير محدودة للنظام والإعدادات وتعديل الأسعار',
      color: '#dc2626',
      is_system: true,
      permissions: ['pos','pos.edit_price','pos.discount','pos.hold','restaurant','restaurant.orders','restaurant.kds','restaurant.settle','repairs','repairs.create','repairs.deliver','items','items.create','items.edit','items.delete','categories','customers','customers.statement','suppliers','suppliers.statement','purchasing','purchasing.orders','purchasing.invoices','sales','sales.quotation','sales.edit_price','sales.invoice','sales.returns','inventory','inventory.transfer','inventory.adjust','inventory.barcode','finance','finance.accounts','finance.cashbox','hr','payroll','reports','reports.sales','reports.pl','reports.stock','admin','admin.users','admin.roles','admin.settings','admin.backup']
    },
    {
      code: 'manager',
      name_en: 'Store / Restaurant Manager',
      name_ar: 'مدير المتجر والمطعم',
      description_en: 'Manages sales, dining floor, purchasing, inventory, staff, operations, and pricing overrides',
      description_ar: 'إدارة المبيعات وصالة المطعم والمشتريات والمخزون والعمليات اليومية وتعديل الأسعار',
      color: '#d97706',
      is_system: true,
      permissions: ['pos','pos.edit_price','pos.discount','pos.hold','restaurant','restaurant.orders','restaurant.kds','restaurant.settle','repairs','repairs.create','repairs.deliver','items','items.create','items.edit','categories','customers','customers.statement','suppliers','suppliers.statement','purchasing','purchasing.orders','purchasing.invoices','sales','sales.quotation','sales.edit_price','sales.invoice','sales.returns','inventory','inventory.transfer','inventory.adjust','inventory.barcode','finance','finance.cashbox','hr','reports','reports.sales','reports.stock']
    },
    {
      code: 'waiter',
      name_en: 'Restaurant Waiter / Captain',
      name_ar: 'كابتن صالة / ويتر مطعم',
      description_en: 'Dining floor table orders, kitchen KOT dispatching, and table transfers',
      description_ar: 'إدارة طلبات الطاولات وإرسال بونات المطبخ للطهي ونقل الطاولات',
      color: '#10b981',
      is_system: true,
      permissions: ['restaurant','restaurant.orders','restaurant.kds','pos']
    },
    {
      code: 'accountant',
      name_en: 'Chief Accountant',
      name_ar: 'محاسب عام',
      description_en: 'Financial ledger, journal entries, payments, cashbox, and financial reporting',
      description_ar: 'الدفاتر المالية، قيود اليومية، السندات، الصندوق، والتقارير المالية',
      color: '#059669',
      is_system: true,
      permissions: ['finance','finance.accounts','finance.cashbox','customers','customers.statement','suppliers','suppliers.statement','purchasing.invoices','sales.invoice','payroll','reports','reports.sales','reports.pl']
    },
    {
      code: 'salesperson',
      name_en: 'Sales Representative',
      name_ar: 'مندوب مبيعات',
      description_en: 'Creates quotations, sales orders, CRM follow-ups, and item lookup',
      description_ar: 'إنشاء عروض الأسعار وأوامر البيع ومتابعة العملاء ودليل الأصناف',
      color: '#2563eb',
      is_system: true,
      permissions: ['sales','sales.quotation','customers','items','pos']
    },
    {
      code: 'cashier',
      name_en: 'POS Cashier',
      name_ar: 'كاشير نقطة البيع',
      description_en: 'Daily POS billing, shifts, receipts, and returns authorization',
      description_ar: 'عمليات نقطة البيع اليومية، إدارة الوردية، وطباعة الإيصالات',
      color: '#7c3aed',
      is_system: true,
      permissions: ['pos','pos.hold','restaurant.settle']
    },
    {
      code: 'inventory_clerk',
      name_en: 'Inventory Supervisor',
      name_ar: 'أمين المستودع',
      description_en: 'Stock transfers, warehouse adjustments, damage tracking, and barcodes',
      description_ar: 'التحويلات المخزنية، تسويات الجرد، وبطاقات الأصناف والباركود',
      color: '#0891b2',
      is_system: true,
      permissions: ['items','categories','inventory','inventory.transfer','inventory.adjust','inventory.barcode','purchasing.orders']
    },
    {
      code: 'demo',
      name_en: 'Demo / Trial User',
      name_ar: 'مستخدم تجريبي (Demo)',
      description_en: 'Restricted demo access: POS billing, restaurant dining, items catalog, and dashboard sales reporting',
      description_ar: 'تجربة محددة: نقطة البيع، صالة المطعم، استعراض الأصناف، وتقارير المبيعات العامة',
      color: '#10b981',
      is_system: true,
      permissions: ['pos','pos.hold','restaurant','restaurant.orders','items','categories','reports','reports.sales']
    }
  ];

  const PERMISSION_MODULES = [
    {
      group_en: 'Point of Sale (POS)', group_ar: 'نقطة البيع (POS)', icon: '🛒',
      perms: [
        { id: 'pos', en: 'POS Terminal Access', ar: 'الدخول لشاشة نقطة البيع' },
        { id: 'pos.edit_price', en: 'Edit Unit Price in POS', ar: 'تعديل سعر الصنف في نقطة البيع' },
        { id: 'pos.discount', en: 'Apply Line / Bill Discounts', ar: 'تطبيق خصومات على الفاتورة' },
        { id: 'pos.hold', en: 'Hold & Recall Sales', ar: 'تعليق واسترجاع الفواتير' },
      ]
    },
    {
      group_en: 'Restaurant & Dining Floor', group_ar: 'المطاعم وصالة الطاولات', icon: '🍽️',
      perms: [
        { id: 'restaurant', en: 'Restaurant & Tables Access', ar: 'الدخول لصالة الطاولات والمطاعم' },
        { id: 'restaurant.orders', en: 'Create & Modify Table Orders', ar: 'إدخال وتعديل طلبات الطاولات' },
        { id: 'restaurant.kds', en: 'Kitchen Display (KDS / KOT)', ar: 'شاشات المطبخ وبونات الطهاة' },
        { id: 'restaurant.settle', en: 'Table Billing & Split Check', ar: 'تقفيل ومحاسبة الطاولات' },
      ]
    },
    {
      group_en: 'Repairs & Workshop Tickets', group_ar: 'الصيانة وبطاقات الورشة', icon: '🛠️',
      perms: [
        { id: 'repairs', en: 'Repairs Module Access', ar: 'الدخول لبطاقات الصيانة والورشة' },
        { id: 'repairs.create', en: 'Create Repair Tickets', ar: 'إنشاء واستلام بطاقات الصيانة' },
        { id: 'repairs.deliver', en: 'Deliver & Settle Tickets', ar: 'تسليم ومحاسبة بطاقات الصيانة' },
      ]
    },
    {
      group_en: 'Sales & Quotations', group_ar: 'المبيعات وعروض الأسعار', icon: '📄',
      perms: [
        { id: 'sales', en: 'Sales Module Access', ar: 'الدخول لإدارة المبيعات' },
        { id: 'sales.quotation', en: 'Create & Manage Quotations', ar: 'إنشاء وإدارة عروض الأسعار' },
        { id: 'sales.edit_price', en: 'Edit Quotation / Order Prices (Admin)', ar: 'تعديل أسعار عروض الأسعار والطلبات' },
        { id: 'sales.invoice', en: 'Issue Sales Invoices', ar: 'إصدار فواتير المبيعات' },
        { id: 'sales.returns', en: 'Process Sales Returns', ar: 'معالجة مرتجعات المبيعات' },
      ]
    },
    {
      group_en: 'Inventory & Items Catalog', group_ar: 'المخزون ودليل الأصناف', icon: '📦',
      perms: [
        { id: 'items', en: 'Items & Products Catalog', ar: 'استعراض دليل الأصناف والمنتجات' },
        { id: 'items.create', en: 'Create New Products', ar: 'إضافة أصناف ومنتجات جديدة' },
        { id: 'items.edit', en: 'Edit Item Details & Prices', ar: 'تعديل بيانات وأسعار الأصناف' },
        { id: 'items.delete', en: 'Delete Catalog Items', ar: 'حذف الأصناف من الدليل' },
        { id: 'categories', en: 'Manage Categories', ar: 'إدارة التصنيفات' },
        { id: 'inventory', en: 'Stock Control & Warehouses', ar: 'التحكم بالمخازن والمستودعات' },
        { id: 'inventory.transfer', en: 'Stock Transfers', ar: 'تحويل البضاعة بين المخازن' },
        { id: 'inventory.adjust', en: 'Stock Adjustments', ar: 'تسويات الجرد وتعديل الكميات' },
        { id: 'inventory.barcode', en: 'Print Barcode Labels', ar: 'طباعة ملصقات الباركود' },
      ]
    },
    {
      group_en: 'Purchasing & Suppliers', group_ar: 'المشتريات والموردون', icon: '🚚',
      perms: [
        { id: 'purchasing', en: 'Purchasing Module', ar: 'إدارة المشتريات العامة' },
        { id: 'purchasing.orders', en: 'Purchase Orders (PO)', ar: 'أوامر الشراء للموردين' },
        { id: 'purchasing.invoices', en: 'Purchase Invoices & Bills', ar: 'فواتير الشراء وإدخال الفواتير' },
        { id: 'suppliers', en: 'Suppliers Management', ar: 'إدارة الموردين' },
        { id: 'suppliers.statement', en: 'Print Supplier Statements', ar: 'طباعة كشوفات حساب الموردين' },
      ]
    },
    {
      group_en: 'Customers & CRM', group_ar: 'العملاء وإدارة العلاقات', icon: '👥',
      perms: [
        { id: 'customers', en: 'Customer Management', ar: 'إدارة ملفات العملاء' },
        { id: 'customers.statement', en: 'Customer Statement of Account', ar: 'كشوفات حساب العملاء وسندات القبض' },
      ]
    },
    {
      group_en: 'Finance & Cash Box', group_ar: 'المالية وحسابات الصندوق', icon: '💵',
      perms: [
        { id: 'finance', en: 'Chart of Accounts & Ledgers', ar: 'شجرة الحسابات والقيود المحاسبية' },
        { id: 'finance.cashbox', en: 'Cashbox & Shift Close', ar: 'إدارة الصندوق والورديات اليومية' },
      ]
    },
    {
      group_en: 'Human Resources & Payroll', group_ar: 'الموارد البشرية والرواتب', icon: '👔',
      perms: [
        { id: 'hr', en: 'Employees, Leaves & EOSG', ar: 'سجلات الموظفين والإجازات ونهاية الخدمة' },
        { id: 'payroll', en: 'Payroll Runs & Payslips', ar: 'مسير الرواتب الشهرية وكشوفات الراتب' },
      ]
    },
    {
      group_en: 'Reports & Analytics', group_ar: 'التقارير والتحليلات', icon: '📊',
      perms: [
        { id: 'reports', en: 'Reports Dashboard', ar: 'لوحة التقارير العامة' },
        { id: 'reports.sales', en: 'Sales & Profit Analytics', ar: 'تقارير المبيعات والأرباح' },
        { id: 'reports.stock', en: 'Inventory Valuation & Dead Stock', ar: 'تقييم المخزون والرواكد' },
        { id: 'reports.pl', en: 'Profit & Loss Financial Statement', ar: 'بيان الأرباح والخسائر المالي' },
      ]
    },
    {
      group_en: 'Administration & Security', group_ar: 'الإدارة وأمان النظام', icon: '⚙️',
      perms: [
        { id: 'admin', en: 'System Settings Access', ar: 'الدخول لإعدادات النظام العامة' },
        { id: 'admin.users', en: 'User Accounts Management', ar: 'إدارة حسابات المستخدمين' },
        { id: 'admin.roles', en: 'Roles & Privileges Configuration', ar: 'تعديل الأدوار والصلاحيات' },
        { id: 'admin.backup', en: 'Database Backup & Restore', ar: 'النسخ الاحتياطي واستعادة البيانات' },
      ]
    }
  ];

  async function renderRoles(container) {
    let roles = await DB.getAll('roles');
    let neededSync = false;
    for (const defRole of DEFAULT_SYSTEM_ROLES) {
      if (!roles.some(r => r.code === defRole.code)) {
        await DB.add('roles', defRole);
        neededSync = true;
      }
    }
    if (neededSync || !roles.length) {
      roles = await DB.getAll('roles');
    }

    const users = await DB.getAll('users');
    const isAR  = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'الأدوار والصلاحيات' : 'Roles & Privileges'}</h1>
          <p>${isAR ? `${roles.length} دور مخصص للنظام والتحكم بالأمان` : `${roles.length} roles configured for access & security control`}</p>
        </div>
        <div class="page-actions" style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="App.navigate('users')">
            👥 ${isAR ? 'إدارة المستخدمين' : 'Manage Users'}
          </button>
          <button class="btn btn-primary" onclick="Admin.openRoleForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'دور جديد' : 'New Role'}
          </button>
        </div>
      </div>

      <!-- Quick Summary Alert -->
      <div style="background:var(--surface-2);border-left:4px solid var(--primary);border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:0.85rem">
        <strong>💡 ${isAR ? 'معلومات الصلاحيات:' : 'Role Permissions Overview:'}</strong>
        ${isAR ? 'يمكنك تحديد وتخصيص صلاحيات دقيقة لكل دور وظيفي مثل الدخول للمبيعات، تعديل الأسعار، خصومات نقطة البيع، والتقارير المالية.' : 'Define granular access privileges for each user role such as sales access, quotation price overrides, POS discounts, and financial ledger reports.'}
      </div>

      <div class="grid grid-3" style="gap:16px" id="roles-grid">
        ${(async () => '')()}
        ${roles.filter(r => {
          const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function') 
            ? License.getCachedBusinessMode() 
            : 'retail';
          if (bMode === 'retail' && (r.code || '').toLowerCase() === 'waiter') return false;
          return true;
        }).map(r => {
          const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function') 
            ? License.getCachedBusinessMode() 
            : 'retail';
          const roleName = isAR ? (r.name_ar || r.name_en || r.name || r.code) : (r.name_en || r.name_ar || r.name || r.code);
          let roleDesc = isAR ? (r.description_ar || r.description_en || '') : (r.description_en || r.description_ar || '');
          const roleCode = (r.code || r.name || '').toLowerCase();
          if (bMode === 'retail' && roleCode === 'manager') {
            roleDesc = isAR ? 'إدارة المبيعات والمشتريات والمخزون والعمليات اليومية وتعديل الأسعار' : 'Manages sales, purchasing, inventory, staff, operations, and pricing overrides';
          }
          const activeUsersCount = users.filter(u => (u.role || '').toLowerCase() === roleCode).length;
          const permsCount = Array.isArray(r.permissions) ? r.permissions.length : (r.permissions ? JSON.parse(r.permissions).length : 0);
          const roleColor = r.color || (r.code === 'admin' ? '#dc2626' : r.code === 'manager' ? '#d97706' : '#2563eb');

          return `
          <div class="card" style="display:flex;flex-direction:column;justify-content:space-between;padding:18px;border-top:4px solid ${roleColor};gap:12px;box-shadow:var(--shadow-sm);transition:all 0.2s ease">
            <div>
              <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
                <div style="display:flex;align-items:center;gap:8px">
                  <div style="width:12px;height:12px;border-radius:50%;background:${roleColor}"></div>
                  <h3 style="margin:0;font-size:1.05rem;font-weight:800;color:var(--text-primary)">${Utils.sanitize(roleName)}</h3>
                </div>
                <span class="badge" style="background:${roleColor}22;color:${roleColor};font-weight:700;font-size:0.75rem">${roleCode}</span>
              </div>
              <p style="margin:4px 0 10px;font-size:0.78rem;color:var(--text-secondary);min-height:34px;line-height:1.4">${Utils.sanitize(roleDesc || '-')}</p>
              
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
                <span class="badge badge-secondary" style="font-size:0.72rem">👥 ${activeUsersCount} ${isAR ? 'مستخدمين' : 'Users'}</span>
                <span class="badge badge-primary" style="font-size:0.72rem">🔒 ${permsCount} ${isAR ? 'صلاحيات' : 'Privileges'}</span>
              </div>
            </div>

            <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border-color);padding-top:12px;margin-top:8px">
              <button class="btn btn-secondary btn-sm" onclick="Admin.openRoleForm(${r.id})" style="font-size:0.78rem">
                ✏️ ${isAR ? 'تعديل الصلاحيات' : 'Edit Privileges'}
              </button>
              ${r.code !== 'admin' ? `
              <button class="btn btn-ghost btn-sm" onclick="Admin.deleteRole(${r.id})" style="color:var(--danger);font-size:0.78rem" title="${isAR?'حذف':'Delete'}">
                🗑️ ${isAR ? 'حذف' : 'Delete'}
              </button>` : `<span style="font-size:0.72rem;color:var(--text-muted);font-weight:600">🔒 ${isAR?'أساسي':'System'}</span>`}
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>

    <!-- Role Form Modal -->
    <div class="modal-overlay" id="role-modal">
      <div class="modal" style="max-width:880px;max-height:90vh;display:flex;flex-direction:column;border-radius:18px;box-shadow:0 25px 60px rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.12)">
        <div class="modal-header" style="padding:18px 24px;border-bottom:1px solid var(--border-color)">
          <div class="modal-title" id="role-modal-title" style="font-size:1.2rem;font-weight:800">${isAR ? 'دور جديد' : 'New Role'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('role-modal')" style="font-size:1.1rem">✕</button>
        </div>
        <div class="modal-body" style="overflow-y:auto;padding:22px 24px">
          <div class="grid grid-3" style="gap:14px;margin-bottom:16px">
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR ? 'اسم الدور (إنجليزي)' : 'Role Name (English)'} *</label>
              <input type="text" class="form-control" id="role-name-en" placeholder="e.g. Sales Manager" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR ? 'اسم الدور (عربي)' : 'Role Name (Arabic)'}</label>
              <input type="text" class="form-control" id="role-name-ar" placeholder="مثال: مدير المبيعات" dir="rtl" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR ? 'رمز الدور (Code)' : 'Role Code / Key'} *</label>
              <input type="text" class="form-control" id="role-code" placeholder="e.g. sales_mgr" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
          </div>

          <div class="grid grid-2" style="gap:14px;margin-bottom:16px">
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR ? 'الوصف' : 'Description'}</label>
              <input type="text" class="form-control" id="role-desc" placeholder="${isAR ? 'وصف مختصر لمسؤوليات هذا الدور...' : 'Brief summary of responsibilities...'}" style="font-size:0.95rem;padding:11px 14px;border-radius:10px">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-size:0.9rem;font-weight:700;margin-bottom:6px">${isAR ? 'لون الشارة المميز' : 'Badge Accent Color'}</label>
              <div style="display:flex;gap:10px;align-items:center">
                <input type="color" id="role-color" value="#2563eb" style="width:48px;height:42px;padding:3px;border:1px solid var(--border-color);border-radius:8px;cursor:pointer">
                <input type="text" class="form-control" id="role-color-text" value="#2563eb" style="width:120px;font-size:0.95rem;padding:11px 14px;border-radius:10px" oninput="document.getElementById('role-color').value=this.value">
              </div>
            </div>
          </div>

          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;border-top:1px solid var(--border-color);padding-top:16px">
            <h4 style="margin:0;font-weight:800;font-size:1rem">🔐 ${isAR ? 'جدول الصلاحيات والامتيازات الممنوحة' : 'Privileges & Permissions Matrix'}</h4>
            <div style="display:flex;gap:8px">
              <button type="button" class="btn btn-secondary btn-sm" onclick="Admin.toggleAllRolePerms(true)" style="font-size:0.8rem;padding:5px 10px">
                ${isAR ? 'تحديد الكل' : 'Select All'}
              </button>
              <button type="button" class="btn btn-ghost btn-sm" onclick="Admin.toggleAllRolePerms(false)" style="font-size:0.8rem;padding:5px 10px">
                ${isAR ? 'إلغاء الكل' : 'Deselect All'}
              </button>
            </div>
          </div>

          <!-- Permission Matrix Accordion / Grid -->
          <div class="grid grid-2" style="gap:14px">
            ${PERMISSION_MODULES.filter(mod => {
              const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function') 
                ? License.getCachedBusinessMode() 
                : 'retail';
              if (bMode === 'retail') {
                return !mod.group_en.toLowerCase().includes('restaurant') && !mod.perms.some(p => p.id.startsWith('restaurant'));
              }
              return true;
            }).map((mod, modIdx) => `
            <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:12px;padding:14px">
              <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:8px;margin-bottom:10px">
                <strong style="font-size:0.92rem;display:flex;align-items:center;gap:8px;color:var(--text-primary)">
                  <span style="font-size:1.1rem">${mod.icon}</span> ${isAR ? mod.group_ar : mod.group_en}
                </strong>
                <button type="button" class="btn btn-ghost btn-sm" style="font-size:0.75rem;padding:3px 8px;border-radius:6px" onclick="Admin.toggleModuleGroupPerms(${modIdx})">
                  ${isAR ? 'عكس التحديد' : 'Toggle'}
                </button>
              </div>
              <div style="display:flex;flex-direction:column;gap:8px">
                ${mod.perms.map(p => `
                <label style="display:flex;align-items:center;gap:10px;cursor:pointer;font-size:0.86rem;font-weight:600;color:var(--text-primary);padding:4px 6px;border-radius:6px;transition:background 0.15s">
                  <input type="checkbox" class="role-perm-check mod-grp-${modIdx}" value="${p.id}" id="role-perm-${p.id.replace('.','-')}" style="width:16px;height:16px;accent-color:var(--primary);cursor:pointer">
                  <span>${isAR ? p.ar : p.en}</span>
                </label>`).join('')}
              </div>
            </div>`).join('')}
          </div>
        </div>
        <div class="modal-footer" style="padding:16px 24px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:10px">
          <button class="btn btn-ghost" onclick="Utils.closeModal('role-modal')" style="font-size:0.9rem;padding:9px 18px">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Admin.saveRole()" style="font-size:0.9rem;font-weight:800;padding:9px 22px">💾 ${isAR ? 'حفظ الصلاحيات' : 'Save Role & Privileges'}</button>
        </div>
      </div>
    </div>`;

    window._allRolesAdmin = roles;
  }

  async function openRoleForm(id = null) {
    window._editRoleId = id;
    const isAR = i18n.getLang() === 'ar';
    document.getElementById('role-modal-title').textContent = id ? (isAR ? 'تعديل الدور والصلاحيات' : 'Edit Role & Privileges') : (isAR ? 'دور جديد' : 'New Role');
    
    ['role-name-en','role-name-ar','role-code','role-desc'].forEach(f => { const el = document.getElementById(f); if (el) el.value = ''; });
    document.getElementById('role-color').value = '#2563eb';
    document.getElementById('role-color-text').value = '#2563eb';
    document.querySelectorAll('.role-perm-check').forEach(cb => cb.checked = false);

    if (id) {
      const role = await DB.get('roles', id);
      if (role) {
        document.getElementById('role-name-en').value = role.name_en || role.name || '';
        document.getElementById('role-name-ar').value = role.name_ar || '';
        document.getElementById('role-code').value    = role.code || role.name || '';
        document.getElementById('role-desc').value    = role.description_en || role.description_ar || role.description || '';
        const clr = role.color || '#2563eb';
        document.getElementById('role-color').value      = clr;
        document.getElementById('role-color-text').value = clr;
        
        let perms = [];
        if (Array.isArray(role.permissions)) {
          perms = role.permissions;
        } else if (typeof role.permissions === 'string') {
          try { perms = JSON.parse(role.permissions); } catch(e) { perms = []; }
        }
        document.querySelectorAll('.role-perm-check').forEach(cb => {
          cb.checked = perms.includes(cb.value);
        });
      }
    }

    // Connect color picker sync
    const colorPicker = document.getElementById('role-color');
    const colorText   = document.getElementById('role-color-text');
    if (colorPicker && colorText) {
      colorPicker.oninput = () => { colorText.value = colorPicker.value; };
    }

    Utils.openModal('role-modal');
  }

  function toggleAllRolePerms(checkState) {
    document.querySelectorAll('.role-perm-check').forEach(cb => { cb.checked = checkState; });
  }

  function toggleModuleGroupPerms(modIdx) {
    const cbs = document.querySelectorAll(`.mod-grp-${modIdx}`);
    const anyUnchecked = [...cbs].some(cb => !cb.checked);
    cbs.forEach(cb => { cb.checked = anyUnchecked; });
  }

  async function saveRole() {
    const isAR = i18n.getLang() === 'ar';
    const nameEn = document.getElementById('role-name-en')?.value.trim();
    const code   = document.getElementById('role-code')?.value.trim().toLowerCase();
    if (!nameEn || !code) {
      Utils.toast(isAR ? 'يرجى إدخال اسم ورمز الدور' : 'Please provide role name and code', 'warning');
      return;
    }

    const perms = [...document.querySelectorAll('.role-perm-check:checked')].map(cb => cb.value);
    const data = {
      name_en:        nameEn,
      name_ar:        document.getElementById('role-name-ar')?.value.trim() || nameEn,
      code:           code,
      description_en: document.getElementById('role-desc')?.value.trim(),
      description_ar: document.getElementById('role-desc')?.value.trim(),
      color:          document.getElementById('role-color')?.value || '#2563eb',
      permissions:    perms
    };

    try {
      if (window._editRoleId) {
        const existing = await DB.get('roles', window._editRoleId);
        await DB.update('roles', { ...existing, ...data, id: window._editRoleId });
      } else {
        await DB.add('roles', data);
      }
      Utils.closeModal('role-modal');
      if (window.Auth && typeof Auth.loadRolesCache === 'function') {
        await Auth.loadRolesCache();
      }
      Utils.toast(i18n.t('common.saved'), 'success');
      await renderRoles(document.getElementById('page-content'));
    } catch(e) {
      Utils.toast('Error: ' + e.message, 'error');
    }
  }

  function deleteRole(id) {
    const isAR = i18n.getLang() === 'ar';
    Utils.confirm(isAR ? 'هل أنت متأكد من حذف هذا الدور؟' : 'Are you sure you want to delete this role?', async () => {
      await DB.remove('roles', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await renderRoles(document.getElementById('page-content'));
    });
  }

  // ── Departments ───────────────────────────────────────────────
  async function renderDepartments(container) {
    let depts = await DB.getAll('departments');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'الأقسام' : 'Departments'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Admin.openDeptForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'قسم جديد' : 'New Department'}
          </button>
        </div>
      </div>
      <div class="grid grid-3" id="depts-grid">
        ${depts.map(d => `
        <div class="card" style="display:flex;align-items:center;justify-content:space-between;padding:14px;gap:12px">
          <div style="display:flex;align-items:center;gap:10px;flex:1">
            <div style="width:38px;height:38px;background:var(--primary-alpha);border-radius:10px;display:flex;align-items:center;justify-content:center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
            </div>
            <div>
              <div style="font-weight:700">${isAR?(d.name_ar||d.name):(d.name||d.name_ar)}</div>
              <div style="font-size:0.72rem;color:var(--text-muted)">${d.description||''}</div>
            </div>
          </div>
          <div style="display:flex;gap:4px">
            <button class="btn btn-ghost btn-sm" onclick="Admin.openDeptForm(${d.id})">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="Admin.deleteDept(${d.id})" style="color:var(--danger)">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            </button>
          </div>
        </div>`).join('') || `<div class="empty-state" style="grid-column:1/-1"><h3>${isAR?'لا توجد أقسام':'No departments'}</h3></div>`}
      </div>
    </div>

    <!-- Dept Modal -->
    <div class="modal-overlay" id="dept-modal">
      <div class="modal" style="max-width:420px">
        <div class="modal-header">
          <div class="modal-title">${isAR?'قسم':'Department'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('dept-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group"><label class="form-label">${isAR?'الاسم (عربي)':'Name (Arabic)'}</label><input type="text" class="form-control" id="dept-name-ar" dir="rtl"></div>
          <div class="form-group"><label class="form-label">${isAR?'الاسم (إنجليزي)':'Name (English)'}</label><input type="text" class="form-control" id="dept-name-en"></div>
          <div class="form-group"><label class="form-label">${isAR?'الوصف':'Description'}</label><textarea class="form-control" id="dept-desc" rows="2"></textarea></div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('dept-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="Admin.saveDept()">${isAR?'حفظ':'Save'}</button>
        </div>
      </div>
    </div>`;

    window._allDeptsAdmin = depts;
  }

  async function openDeptForm(id = null) {
    window._editDeptId = id;
    document.getElementById('dept-name-ar').value = '';
    document.getElementById('dept-name-en').value = '';
    document.getElementById('dept-desc').value = '';
    if (id) {
      const d = await DB.get('departments', id);
      if (d) { document.getElementById('dept-name-ar').value = d.name_ar||''; document.getElementById('dept-name-en').value = d.name||''; document.getElementById('dept-desc').value = d.description||''; }
    }
    Utils.openModal('dept-modal');
  }

  async function saveDept() {
    const data = { name: document.getElementById('dept-name-en').value.trim(), name_ar: document.getElementById('dept-name-ar').value.trim(), description: document.getElementById('dept-desc').value };
    if (!data.name && !data.name_ar) { Utils.toast(i18n.t('common.required'),'warning'); return; }
    if (window._editDeptId) await DB.update('departments', { ...data, id: window._editDeptId });
    else await DB.add('departments', data);
    Utils.closeModal('dept-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await renderDepartments(document.getElementById('page-content'));
  }

  function deleteDept(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('departments', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await renderDepartments(document.getElementById('page-content'));
    });
  }

  const DEFAULT_RETAIL_MODIFIERS = [
    { icon: '🎁', name_en: 'Gift Wrap', name_ar: 'تغليف كهدية' },
    { icon: '⚠️', name_en: 'Fragile / Handle with Care', name_ar: 'قابل للكسر / بعناية' },
    { icon: '📦', name_en: 'Open Box Inspection', name_ar: 'فحص وتجربة الصندوق' },
    { icon: '🚚', name_en: 'Urgent Delivery', name_ar: 'توصيل سريع ومستعجل' },
    { icon: '🛡️', name_en: '1-Year Warranty Included', name_ar: 'شامل كفالة سنة' },
    { icon: '🔄', name_en: 'Exchange Within 7 Days', name_ar: 'قابل للتبديل خلال 7 أيام' },
    { icon: '🏷️', name_en: 'Remove Price Tag', name_ar: 'إزالة بطاقة السعر' },
    { icon: '🔖', name_en: 'Special VIP Discount', name_ar: 'خصم خاص لكبار العملاء' }
  ];

  const DEFAULT_RESTAURANT_MODIFIERS = [
    { icon: '🚫', name_en: 'No Sugar', name_ar: 'بدون سكر' },
    { icon: '🍬', name_en: 'Extra Sugar', name_ar: 'سكر زيادة' },
    { icon: '🧊', name_en: 'Less Ice', name_ar: 'ثلج خفيف' },
    { icon: '🥛', name_en: 'Skim Milk', name_ar: 'حليب دايت' },
    { icon: '☕', name_en: 'Decaf', name_ar: 'بدون كافيين' },
    { icon: '🧅', name_en: 'No Onions', name_ar: 'بدون بصل' },
    { icon: '🌶️', name_en: 'Extra Spicy', name_ar: 'حار جداً' },
    { icon: '🥣', name_en: 'Sauce on side', name_ar: 'الصوص جانبي' },
    { icon: '🧂', name_en: 'No Salt', name_ar: 'بدون ملح' },
    { icon: '🥩', name_en: 'Well Done', name_ar: 'استواء كامل' },
    { icon: '🧀', name_en: 'Extra Cheese', name_ar: 'زيادة جبنة' }
  ];

  // ── Settings ──────────────────────────────────────────────────
  async function renderSettings(container) {
    const isAR = i18n.getLang() === 'ar';

    const customPrinters = await DB.getAll('kitchen_printers') || [];

    let retailModifiers = await DB.getSetting('quick_modifiers_retail', DEFAULT_RETAIL_MODIFIERS);
    if (!Array.isArray(retailModifiers) || !retailModifiers.length) retailModifiers = DEFAULT_RETAIL_MODIFIERS;

    let restaurantModifiers = await DB.getSetting('quick_modifiers_restaurant', DEFAULT_RESTAURANT_MODIFIERS);
    if (!Array.isArray(restaurantModifiers) || !restaurantModifiers.length) restaurantModifiers = DEFAULT_RESTAURANT_MODIFIERS;

    window._adminRetailModifiers = JSON.parse(JSON.stringify(retailModifiers));
    window._adminRestaurantModifiers = JSON.parse(JSON.stringify(restaurantModifiers));

    const rawLic = await DB.getSetting('license_active_data');
    let isLicenseLocked = false;
    if (rawLic) {
      try {
        const lic = JSON.parse(rawLic);
        if (lic && (lic.business_mode || lic.allowed_modules)) isLicenseLocked = true;
      } catch(e) {}
    }

    const allWarehouses = (await DB.getAll('warehouses')) || [];
    const savedPosWhId = await DB.getSetting('pos_warehouse_id', allWarehouses.find(w => w.is_default)?.id || allWarehouses[0]?.id || 1);

    const settings = {
      pos_warehouse_id: savedPosWhId,
      business_mode:    (typeof License !== 'undefined' && typeof License.getBusinessMode === 'function') 
        ? await License.getBusinessMode() 
        : await DB.getSetting('business_mode', 'retail'),
      company_name:     await DB.getSetting('company_name', 'Store'),
      company_phone:    await DB.getSetting('company_phone', ''),
      company_email:    await DB.getSetting('company_email', ''),
      company_address:  await DB.getSetting('company_address', ''),
      vat_number:       await DB.getSetting('vat_number', ''),
      currency_1:       await DB.getSetting('currency_1', 'USD'),
      currency_2:       await DB.getSetting('currency_2', 'LBP'),
      exchange_rate:    await DB.getSetting('exchange_rate', 89500),
      vat_rate:         await DB.getSetting('vat_rate', 11),
      vat_enabled:      await DB.getSetting('vat_enabled', false),
      receipt_footer:   await DB.getSetting('receipt_footer', 'Thank you for your business!'),
      low_stock_alert:  await DB.getSetting('low_stock_alert', true),
      allow_negative_stock: await DB.getSetting('allow_negative_stock', false),
      show_ai_bubble:   await DB.getSetting('show_ai_bubble', true),
      // WhatsApp & Telegram Settings
      owner_whatsapp_phone:     await DB.getSetting('owner_whatsapp_phone', ''),
      whatsapp_invoice_template:await DB.getSetting('whatsapp_invoice_template', ''),
      whatsapp_repair_template: await DB.getSetting('whatsapp_repair_template', ''),
      telegram_bot_token:       await DB.getSetting('telegram_bot_token', ''),
      telegram_chat_id:         await DB.getSetting('telegram_chat_id', ''),
      telegram_auto_send:       await DB.getSetting('telegram_auto_send', false),
      // Printer settings
      receipt_size:     await DB.getSetting('receipt_size', '80mm'),
      invoice_size:     await DB.getSetting('invoice_size', 'A4'),
      po_size:          await DB.getSetting('po_size', 'A4'),
      payslip_size:     await DB.getSetting('payslip_size', 'A4'),
      receipt_copies:   await DB.getSetting('receipt_copies', 1),
      invoice_copies:   await DB.getSetting('invoice_copies', 1),
      auto_print:               await DB.getSetting('auto_print', true),
      pos_preview_receipt:      await DB.getSetting('pos_preview_receipt', false),
      print_logo:               await DB.getSetting('print_logo', true),
      show_barcode:             await DB.getSetting('show_barcode', true),
      pole_display_enabled:     await DB.getSetting('pole_display_enabled', true),
      pole_display_port:        await DB.getSetting('pole_display_port', 'auto'),
      pole_display_baud:        await DB.getSetting('pole_display_baud', 2400),
      // Printer assignments & Label configuration
      receipt_printer:         await DB.getSetting('receipt_printer', ''),
      kitchen_printer_main:    await DB.getSetting('kitchen_printer_main', ''),
      kitchen_printer_bar:     await DB.getSetting('kitchen_printer_bar', ''),
      kitchen_printer_dessert: await DB.getSetting('kitchen_printer_dessert', ''),
      document_printer:        await DB.getSetting('document_printer', ''),
      label_printer:           await DB.getSetting('label_printer', ''),
      label_orientation:   await DB.getSetting('label_orientation', 'portrait'),
      label_show_name:     await DB.getSetting('label_show_name', true),
      label_show_code:     await DB.getSetting('label_show_code', true),
      label_show_barcode:  await DB.getSetting('label_show_barcode', true),
      label_show_digits:   await DB.getSetting('label_show_digits', true),
      label_show_price:    await DB.getSetting('label_show_price', true),
      label_show_company:  await DB.getSetting('label_show_company', false),
      label_custom_width:  await DB.getSetting('label_custom_width', 50),
      label_custom_height: await DB.getSetting('label_custom_height', 30),
      company_logo:        await DB.getSetting('company_logo', ''),
      // Loyalty & Promotions
      loyalty_enabled:          await DB.getSetting('loyalty_enabled', true),
      loyalty_earn_rate:        await DB.getSetting('loyalty_earn_rate', 1),
      loyalty_redeem_rate:      await DB.getSetting('loyalty_redeem_rate', 100),
      loyalty_min_redeem:       await DB.getSetting('loyalty_min_redeem', 50),
      promo_happy_hour_enabled: await DB.getSetting('promo_happy_hour_enabled', false),
      promo_happy_hour_pct:     await DB.getSetting('promo_happy_hour_pct', 10),
      promo_happy_hour_start:   await DB.getSetting('promo_happy_hour_start', '14:00'),
      promo_happy_hour_end:     await DB.getSetting('promo_happy_hour_end', '17:00'),
      promo_threshold_enabled:  await DB.getSetting('promo_threshold_enabled', false),
      promo_threshold_amt:      await DB.getSetting('promo_threshold_amt', 100),
      promo_threshold_pct:      await DB.getSetting('promo_threshold_pct', 5),
      // Invoice & Receipt Designer Settings
      inv_template:             await DB.getSetting('inv_template', 'modern'),
      inv_primary_color:        await DB.getSetting('inv_primary_color', '#2563eb'),
      inv_font_family:          await DB.getSetting('inv_font_family', 'Cairo'),
      inv_font_size:            await DB.getSetting('inv_font_size', 'medium'),
      inv_logo_position:        await DB.getSetting('inv_logo_position', 'left'),
      inv_logo_size:            await DB.getSetting('inv_logo_size', 80),
      inv_header_align:         await DB.getSetting('inv_header_align', 'left'),
      inv_show_company_name:    await DB.getSetting('inv_show_company_name', true),
      inv_show_phone:           await DB.getSetting('inv_show_phone', true),
      inv_show_email:           await DB.getSetting('inv_show_email', true),
      inv_show_address:         await DB.getSetting('inv_show_address', true),
      inv_show_vat:             await DB.getSetting('inv_show_vat', true),
      inv_custom_subtitle:      await DB.getSetting('inv_custom_subtitle', ''),
      inv_show_customer_info:   await DB.getSetting('inv_show_customer_info', true),
      inv_show_salesperson:     await DB.getSetting('inv_show_salesperson', true),
      inv_show_item_code:       await DB.getSetting('inv_show_item_code', true),
      inv_show_discount_col:    await DB.getSetting('inv_show_discount_col', true),
      inv_show_dual_currency:   await DB.getSetting('inv_show_dual_currency', true),
      inv_show_qr:              await DB.getSetting('inv_show_qr', true),
      inv_show_barcode:         await DB.getSetting('inv_show_barcode', true),
      inv_show_stamp_signature: await DB.getSetting('inv_show_stamp_signature', true),
      inv_terms_text:           await DB.getSetting('inv_terms_text', 'Goods once sold can be exchanged within 7 days with original invoice. / البضاعة المباعة تستبدل خلال 7 أيام بالفاتورة الأصلية.'),
      inv_footer_note:          await DB.getSetting('inv_footer_note', 'Thank you for your business! / شكراً لتعاملكم معنا ونسعد بخدمتكم'),
      inv_receipt_item_layout:  await DB.getSetting('inv_receipt_item_layout', 'table'),
      // Invoice Font Sizes
      inv_fs_company_name:      await DB.getSetting('inv_fs_company_name', '24px'),
      inv_fs_subtitle:          await DB.getSetting('inv_fs_subtitle', '13px'),
      inv_fs_header_contact:    await DB.getSetting('inv_fs_header_contact', '12px'),
      inv_fs_doc_title:         await DB.getSetting('inv_fs_doc_title', '22px'),
      inv_fs_doc_num:           await DB.getSetting('inv_fs_doc_num', '15px'),
      inv_fs_meta_text:         await DB.getSetting('inv_fs_meta_text', '12px'),
      inv_fs_customer_box:      await DB.getSetting('inv_fs_customer_box', '13px'),
      inv_fs_cashier_box:       await DB.getSetting('inv_fs_cashier_box', '13px'),
      inv_fs_table_header:      await DB.getSetting('inv_fs_table_header', '12px'),
      inv_fs_table_rows:        await DB.getSetting('inv_fs_table_rows', '12px'),
      inv_fs_item_subline:      await DB.getSetting('inv_fs_item_subline', '11px'),
      inv_fs_totals_box:        await DB.getSetting('inv_fs_totals_box', '12px'),
      inv_fs_grand_total:       await DB.getSetting('inv_fs_grand_total', '16px'),
      inv_fs_cur2_total:        await DB.getSetting('inv_fs_cur2_total', '13px'),
      inv_fs_terms:             await DB.getSetting('inv_fs_terms', '11px'),
      inv_fs_signatures:        await DB.getSetting('inv_fs_signatures', '12px'),
      inv_fs_footer_note:       await DB.getSetting('inv_fs_footer_note', '11px'),
      // Invoice Fixed Texts / Labels
      inv_txt_doc_title:        await DB.getSetting('inv_txt_doc_title', ''),
      inv_txt_date_label:       await DB.getSetting('inv_txt_date_label', ''),
      inv_txt_duedate_label:    await DB.getSetting('inv_txt_duedate_label', ''),
      inv_txt_tax_id_label:     await DB.getSetting('inv_txt_tax_id_label', ''),
      inv_txt_bill_to_label:    await DB.getSetting('inv_txt_bill_to_label', ''),
      inv_txt_cashier_label:    await DB.getSetting('inv_txt_cashier_label', ''),
      inv_txt_payment_label:    await DB.getSetting('inv_txt_payment_label', ''),
      inv_txt_col_hash:         await DB.getSetting('inv_txt_col_hash', ''),
      inv_txt_col_item:         await DB.getSetting('inv_txt_col_item', ''),
      inv_txt_col_sku:          await DB.getSetting('inv_txt_col_sku', ''),
      inv_txt_col_qty:          await DB.getSetting('inv_txt_col_qty', ''),
      inv_txt_col_price:        await DB.getSetting('inv_txt_col_price', ''),
      inv_txt_col_disc:         await DB.getSetting('inv_txt_col_disc', ''),
      inv_txt_col_total:        await DB.getSetting('inv_txt_col_total', ''),
      inv_txt_subtotal_label:   await DB.getSetting('inv_txt_subtotal_label', ''),
      inv_txt_discount_label:   await DB.getSetting('inv_txt_discount_label', ''),
      inv_txt_vat_label:        await DB.getSetting('inv_txt_vat_label', ''),
      inv_txt_grand_total_label:await DB.getSetting('inv_txt_grand_total_label', ''),
      inv_txt_cur2_label:       await DB.getSetting('inv_txt_cur2_label', ''),
      inv_txt_terms_label:      await DB.getSetting('inv_txt_terms_label', ''),
      inv_txt_cust_sig_label:   await DB.getSetting('inv_txt_cust_sig_label', ''),
      inv_txt_store_sig_label:  await DB.getSetting('inv_txt_store_sig_label', ''),
      pos_cart_columns:         await DB.getSetting('pos_cart_columns', {
        col_name: true,
        col_code: false,
        col_unit: false,
        col_price: true,
        col_cost: false,
        col_qty: true,
        col_disc: true,
        col_vat: false,
        col_total: true,
        col_actions: true
      }),
      price_checker_show_image:        await DB.getSetting('price_checker_show_image', true),
      price_checker_show_sec_currency: await DB.getSetting('price_checker_show_sec_currency', true),
      price_checker_show_stock_status: await DB.getSetting('price_checker_show_stock_status', true),
      price_checker_show_barcode:      await DB.getSetting('price_checker_show_barcode', true),
      price_checker_auto_reset:        await DB.getSetting('price_checker_auto_reset', 6),
      price_checker_welcome_msg_ar:    await DB.getSetting('price_checker_welcome_msg_ar', 'يرجى توجيه باركود الصنف للمسح لمعرفة السعر'),
      price_checker_welcome_msg_en:    await DB.getSetting('price_checker_welcome_msg_en', 'Scan item barcode here to check price'),
      pos_terminal_name:               await DB.getSetting('pos_terminal_name', localStorage.getItem('redshark_pos_terminal') || 'POS-1'),
      ui_visibility:                   await DB.getSetting('ui_visibility_settings', {
        show_ai_copilot: true,
        show_mobile_app: true,
        show_price_check: true,
        show_online_orders: true,
        show_card_payment: true,
        show_mobile_scan: true,
        show_exchange_rate: true,
        show_clock: true
      }),
      online_store_shop_slug:          await DB.getSetting('online_store_shop_slug', 'shop101'),
      online_store_url:                await DB.getSetting('online_store_url', 'https://mcebwpiswvwqcdwjpagy.supabase.co'),
      online_store_key:                await DB.getSetting('online_store_key', ''),
      online_store_autoprint:          await DB.getSetting('online_store_autoprint', false),
      app_font_scale:                  await DB.getSetting('app_font_scale', parseInt(localStorage.getItem('nexpos_font_scale'), 10) || 100),
    };

    const _renderFsSelect = (id, curVal, defVal, isArabic) => {
      const opts = ['9px', '10px', '11px', '12px', '13px', '14px', '15px', '16px', '18px', '20px', '22px', '24px', '26px', '28px', '32px'];
      const cur = curVal || defVal;
      return `
        <select class="form-control" id="${id}" onchange="Admin.updateInvoiceDesignerPreview()" style="font-size:0.8rem;padding:3px 6px;height:32px">
          ${opts.map(o => `
            <option value="${o}" ${cur === o ? 'selected' : ''}>
              ${o}${o === defVal ? (isArabic ? ' (افتراضي)' : ' (Default)') : ''}
            </option>
          `).join('')}
        </select>
      `;
    };

    const allCategories = (await DB.getAll('categories')) || [];

    // ── Fetch installed printers from local server ──────────────
    let printerList = [];
    let serverOnline = false;
    try {
      const apiUrl = window.location.origin.startsWith('http') ? '/api/printers' : 'http://localhost:3000/api/printers';
      const resp = await fetch(apiUrl, { signal: AbortSignal.timeout(10000) });
      if (resp.ok) {
        const data = await resp.json();
        if (data.success) {
          printerList = data.printers || [];
          serverOnline = true;
        }
      }
    } catch (e) {
      console.warn('Printer API fetch error:', e);
      /* server not running — degraded mode */
    }

    // Helper: build printer <option> list
    const printerOptions = (saved) => {
      const defaultOpt = `<option value="">${isAR ? '— الطابعة الافتراضية في Windows —' : '— Default Windows Printer —'}</option>`;
      if (!printerList.length) {
        const presets = [
          'EPSON TM-T20III (Kitchen / 80mm)',
          'Xprinter XP-80C (Bar / 80mm)',
          'Bixolon SRP-330 (Cashier POS)',
          'HP LaserJet Pro (A4 Invoices)',
          'Xprinter XP-365B (Barcode Labels)'
        ];
        let opts = defaultOpt;
        if (saved && !presets.includes(saved)) {
          opts += `<option value="${Utils.sanitize(saved)}" selected>${Utils.sanitize(saved)}</option>`;
        }
        opts += presets.map(p => `<option value="${p}" ${p === saved ? 'selected' : ''}>🖨️ ${p}</option>`).join('');
        return opts;
      }
      return defaultOpt + printerList.map(p =>
        `<option value="${Utils.sanitize(p.name)}" ${p.name === saved ? 'selected' : ''}>${Utils.sanitize(p.name)}${p.isDefault ? ' ★' : ''}</option>`
      ).join('');
    };

    // ── Fetch available COM ports for Pole Display ──────────────
    let comPorts = [];
    try {
      const portUrl = window.location.origin.startsWith('http') ? '/api/customer-display/ports' : 'http://localhost:3000/api/customer-display/ports';
      const pResp = await fetch(portUrl, { signal: AbortSignal.timeout(4000) });
      if (pResp.ok) {
        const pData = await pResp.json();
        if (pData.success) comPorts = pData.ports || [];
      }
    } catch (e) {
      console.warn('Customer display ports fetch error:', e);
    }

    const comPortOptions = (saved) => {
      const defaultOpt = `<option value="auto" ${(!saved || saved === 'auto' || saved === 'all') ? 'selected' : ''}>${isAR ? '⚡ فحص وإرسال لجميع المنافذ (Auto-Detect / Send to All COM Ports)' : '⚡ Auto-Detect / Send to All COM Ports'}</option>`;
      const commonPorts = ['COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8'];
      const uniquePorts = Array.from(new Set([...(comPorts || []), ...commonPorts]));
      return defaultOpt + uniquePorts.map(p =>
        `<option value="${p}" ${p === saved ? 'selected' : ''}>🔌 ${p} ${comPorts.includes(p) ? '★' : ''}</option>`
      ).join('');
    };

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'إعدادات النظام' : 'System Settings'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Admin.saveSettings()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
            ${isAR ? 'حفظ الإعدادات' : 'Save Settings'}
          </button>
        </div>
      </div>

      <div class="tabs-scroll-wrapper">
        <button type="button" class="tabs-nav-btn" onclick="Utils.scrollTabs('#settings-tabs', -280)" title="${isAR ? 'تمرير للخلف / لليسار' : 'Scroll Left'}">
          ◀
        </button>
        <div class="tabs" id="settings-tabs">
          <div class="tab-item active" data-tab="tab-set-company">${isAR?'الشركة':'Company'}</div>
          <div class="tab-item" data-tab="tab-set-currency">${isAR?'العملة':'Currency'}</div>
          <div class="tab-item" data-tab="tab-set-tax">${isAR?'الضريبة':'Tax'}</div>
          <div class="tab-item" data-tab="tab-set-print">${isAR?'الطباعة':'Printing'}</div>
          <div class="tab-item" data-tab="tab-set-invoice-designer">🎨 ${isAR?'تصميم الفاتورة':'Invoice Designer'}</div>
          <div class="tab-item" data-tab="tab-set-pos-cart">🛒 ${isAR?'أعمدة سلة المبيعات (POS)':'POS Cart Columns'}</div>
          <div class="tab-item" data-tab="tab-set-modifiers">📝 ${settings.business_mode === 'retail' ? (isAR ? 'ملاحظات الأصناف السريعة' : 'Quick Item Notes') : (isAR ? 'ملاحظات الأصناف وتفضيلات الطلب' : 'Item Notes & Modifiers')}</div>
          <div class="tab-item" data-tab="tab-set-security">${isAR?'الأمان والإرجاع':'Security & Returns'}</div>
          <div class="tab-item" data-tab="tab-set-loyalty">⭐ ${isAR?'نقاط الولاء والعروض':'Loyalty & Deals'}</div>
          <div class="tab-item" data-tab="tab-set-notifications">📱 ${isAR?'واتساب وتيليجرام':'WhatsApp & Telegram'}</div>
          <div class="tab-item" data-tab="tab-set-price-checker">🔍 ${isAR?'فاحص الأسعار':'Price Checker'}</div>
          
          <div class="tab-item" data-tab="tab-set-branches">🌐 ${isAR?'الربط السحابي والفروع والمتجر':'Cloud Sync, Branches & Store'}</div>
          
                    <div class="tab-item" data-tab="tab-set-general">${isAR?'عام':'General'}</div>
          <div class="tab-item" data-tab="tab-set-license">${isAR?'الترخيص':'License'}</div>
          <div class="tab-item" data-tab="tab-set-update">⚡ ${isAR?'تحديث البرنامج':'Software Update'}</div>
        </div>
        <button type="button" class="tabs-nav-btn" onclick="Utils.scrollTabs('#settings-tabs', 280)" title="${isAR ? 'تمرير للأمام / لليمين' : 'Scroll Right'}">
          ▶
        </button>
      </div>

      <!-- Company -->
      <div class="tab-content active" id="tab-set-company">
        <div class="card">
          <div class="modal-body">
            <div class="grid grid-2">
              <div class="form-group" style="grid-column:1/-1;background:rgba(239,68,68,0.06);padding:14px 18px;border-radius:12px;border:1px solid rgba(239,68,68,0.2)">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
                  <div>
                    <label class="form-label" style="font-weight:900;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:8px;margin-bottom:4px">
                      <span>🏢</span> <span>${isAR ? 'وضع ونشاط النظام (Industry Operating Mode)' : 'Operating Industry Mode'}</span>
                    </label>
                    <div style="font-size:0.75rem;color:var(--text-muted)">
                      ${isLicenseLocked 
                        ? (isAR ? 'نوع الترخيص النشط يحدد تلقائياً الوحدات المتاحة (مطاعم / تجزئة / شامل) ولا يمكن تغييره يدوياً.' : 'Your active software license defines whether Retail, Restaurant, or Hybrid features are enabled.')
                        : (isAR ? 'حدد نوع النشاط التجاري للبرنامج (محلات تجزئة / مطاعم وكافيهات / شامل).' : 'Select the operating industry mode for this installation.')}
                    </div>
                  </div>
                  <div>
                    ${isLicenseLocked ? `
                    <span class="badge badge-primary" style="font-size:0.85rem;padding:7px 14px;font-weight:800;border-radius:8px">
                      🔒 ${settings.business_mode === 'restaurant' ? (isAR ? '🍽️ ترخيص المطاعم والكافيهات' : '🍽️ Restaurant & Dining Edition') : (settings.business_mode === 'retail' ? (isAR ? '🛒 ترخيص محلات التجزئة والسوبرماركت' : '🛒 Retail Store Edition') : (isAR ? '🌟 ترخيص شامل مزدوج (Retail + Dining)' : '🌟 Hybrid All-in-One Edition'))}
                    </span>` : `
                    <select class="form-control" id="set-business-mode" style="font-weight:800;border-radius:8px;padding:6px 12px;height:38px" onchange="Admin.changeBusinessMode(this.value)">
                      <option value="retail" ${settings.business_mode === 'retail' ? 'selected' : ''}>🛒 ${isAR ? 'محلات تجزئة وسوبرماركت (Retail)' : 'Retail Store & Supermarket'}</option>
                      <option value="restaurant" ${settings.business_mode === 'restaurant' ? 'selected' : ''}>🍽️ ${isAR ? 'مطاعم وكافيهات (Restaurant & Dining)' : 'Restaurant & Dining Floor'}</option>
                      <option value="hybrid" ${settings.business_mode === 'hybrid' ? 'selected' : ''}>🌟 ${isAR ? 'شامل مزدوج (Hybrid Retail + Restaurant)' : 'Hybrid Retail + Dining'}</option>
                    </select>
                    `}
                  </div>
                </div>
              </div>

              <div class="form-group">
                <label class="form-label">${isAR?'اسم المتجر / الشركة (بالإنكليزية)':'Store / Company Name (English)'}</label>
                <input type="text" class="form-control" id="set-company-name" value="${Utils.sanitize(settings.company_name)}" style="font-size:1rem" oninput="Admin.updateInvoiceDesignerPreview()">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'اسم المتجر / الشركة (بالعربية)':'Store / Company Name (Arabic)'}</label>
                <input type="text" class="form-control" id="set-company-name-ar" value="${Utils.sanitize(settings.company_name_ar === 'المتجر' ? '' : (settings.company_name_ar || ''))}" placeholder="${isAR ? 'اتركه فارغاً للمطابقة التلقائية' : 'Leave blank to auto-match English'}" style="font-size:1rem" oninput="Admin.updateInvoiceDesignerPreview()">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'الهاتف':'Phone'}</label>
                <input type="text" class="form-control" id="set-company-phone" value="${settings.company_phone}">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'البريد الإلكتروني':'Email'}</label>
                <input type="email" class="form-control" id="set-company-email" value="${settings.company_email}">
              </div>
              <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">${isAR?'العنوان':'Address'}</label>
                <textarea class="form-control" id="set-company-address" rows="2">${settings.company_address}</textarea>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'الرقم الضريبي':'VAT/Tax Number'}</label>
                <input type="text" class="form-control" id="set-vat-num" value="${settings.vat_number}">
              </div>
              <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">${isAR?'شعار الشركة':'Company Logo'}</label>
                <div style="display:flex;gap:15px;align-items:center;margin-top:6px">
                  <input type="file" id="set-company-logo-input" accept="image/*" style="display:none" onchange="Admin.handleLogoUpload(this)">
                  <button class="btn btn-secondary" onclick="document.getElementById('set-company-logo-input').click()">${isAR?'اختر صورة الشعار':'Choose Logo Image'}</button>
                  <div id="set-company-logo-preview" style="width:60px;height:60px;border:1px solid var(--border-color);border-radius:6px;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#f8fafc">
                    ${settings.company_logo ? `<img src="${settings.company_logo}" style="max-width:100%;max-height:100%;object-fit:contain">` : `<span style="font-size:0.7rem;color:var(--text-muted)">${isAR?'لا يوجد':'No Logo'}</span>`}
                  </div>
                  ${settings.company_logo ? `<button class="btn btn-danger btn-sm" onclick="Admin.removeLogo()">${isAR?'حذف':'Delete'}</button>` : ''}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Currency -->
      <div class="tab-content" id="tab-set-currency">
        <div class="card">
          <div class="modal-body">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label">${isAR?'العملة الرئيسية':'Primary Currency'}</label>
                <select class="form-control" id="set-cur1" onchange="Admin.updateExchRateLabel()">
                  <option value="USD" ${settings.currency_1==='USD'?'selected':''}>USD - US Dollar ($)</option>
                  <option value="LBP" ${settings.currency_1==='LBP'?'selected':''}>LBP - Lebanese Pound (ل.ل)</option>
                  <option value="LL"  ${settings.currency_1==='LL'?'selected':''}>LL - Lebanese Lira (ل.ل)</option>
                  <option value="EUR" ${settings.currency_1==='EUR'?'selected':''}>EUR - Euro (€)</option>
                  <option value="GBP" ${settings.currency_1==='GBP'?'selected':''}>GBP - British Pound (£)</option>
                  <option value="AED" ${settings.currency_1==='AED'?'selected':''}>AED - UAE Dirham (د.إ)</option>
                  <option value="SAR" ${settings.currency_1==='SAR'?'selected':''}>SAR - Saudi Riyal (ر.س)</option>
                  <option value="EGP" ${settings.currency_1==='EGP'?'selected':''}>EGP - Egyptian Pound (ج.م)</option>
                  <option value="IQD" ${settings.currency_1==='IQD'?'selected':''}>IQD - Iraqi Dinar (د.ع)</option>
                  <option value="JOD" ${settings.currency_1==='JOD'?'selected':''}>JOD - Jordanian Dinar (د.أ)</option>
                  <option value="TRY" ${settings.currency_1==='TRY'?'selected':''}>TRY - Turkish Lira (₺)</option>
                  <option value="QAR" ${settings.currency_1==='QAR'?'selected':''}>QAR - Qatari Riyal (ر.ق)</option>
                  <option value="KWD" ${settings.currency_1==='KWD'?'selected':''}>KWD - Kuwaiti Dinar (د.ك)</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'العملة الثانوية':'Secondary Currency'}</label>
                <select class="form-control" id="set-cur2" onchange="Admin.updateExchRateLabel()">
                  <option value="LBP" ${settings.currency_2==='LBP'?'selected':''}>LBP - Lebanese Pound (ل.ل)</option>
                  <option value="LL"  ${settings.currency_2==='LL'?'selected':''}>LL - Lebanese Lira (ل.ل)</option>
                  <option value="USD" ${settings.currency_2==='USD'?'selected':''}>USD - US Dollar ($)</option>
                  <option value="EUR" ${settings.currency_2==='EUR'?'selected':''}>EUR - Euro (€)</option>
                  <option value="GBP" ${settings.currency_2==='GBP'?'selected':''}>GBP - British Pound (£)</option>
                  <option value="AED" ${settings.currency_2==='AED'?'selected':''}>AED - UAE Dirham (د.إ)</option>
                  <option value="SAR" ${settings.currency_2==='SAR'?'selected':''}>SAR - Saudi Riyal (ر.س)</option>
                  <option value="EGP" ${settings.currency_2==='EGP'?'selected':''}>EGP - Egyptian Pound (ج.م)</option>
                  <option value="IQD" ${settings.currency_2==='IQD'?'selected':''}>IQD - Iraqi Dinar (د.ع)</option>
                  <option value="JOD" ${settings.currency_2==='JOD'?'selected':''}>JOD - Jordanian Dinar (د.أ)</option>
                  <option value="TRY" ${settings.currency_2==='TRY'?'selected':''}>TRY - Turkish Lira (₺)</option>
                  <option value="QAR" ${settings.currency_2==='QAR'?'selected':''}>QAR - Qatari Riyal (ر.ق)</option>
                  <option value="KWD" ${settings.currency_2==='KWD'?'selected':''}>KWD - Kuwaiti Dinar (د.ك)</option>
                </select>
              </div>
              <div class="form-group" style="grid-column:1/-1">
                <label class="form-label" id="lbl-exch-rate">
                  ${isAR ? `سعر الصرف (1 USD = X ${settings.currency_1 === 'USD' ? settings.currency_2 : settings.currency_1})` : `Exchange Rate (1 USD = X ${settings.currency_1 === 'USD' ? settings.currency_2 : settings.currency_1})`}
                </label>
                <input type="number" class="form-control" id="set-exch-rate" value="${settings.exchange_rate}" step="0.01" min="0" style="font-size:1.1rem;font-weight:700">
                <div id="help-exch-rate" style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">${isAR ? 'حدد سعر 1 دولار مقابل العملة الأخرى (مثال: 89500 ليرة مقابل 1 دولار). سيتم تقسيم الأسعار تلقائياً إذا كانت العملة الأساسية ليرة.' : 'Define the exchange rate of 1 USD against local currency (e.g. 89500 LBP per 1 USD). Prices will be divided automatically if primary currency is local.'}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Tax -->
      <div class="tab-content" id="tab-set-tax">
        <div class="card">
          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">${isAR?'تفعيل ضريبة VAT':'Enable VAT'}</label>
              <label class="toggle" style="margin-top:8px">
                <input type="checkbox" id="set-vat-enabled" ${settings.vat_enabled?'checked':''}>
                <span class="toggle-slider"></span>
              </label>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'نسبة الضريبة %':'VAT Rate %'}</label>
              <input type="number" class="form-control" id="set-vat-rate" value="${settings.vat_rate}" min="0" max="100" step="0.01" style="font-size:1.2rem;font-weight:700;max-width:200px">
            </div>
          </div>
        </div>
      </div>

      <!-- Printing -->
      <div class="tab-content" id="tab-set-print">

        <!-- SERVER STATUS BANNER -->
        <div style="background:${serverOnline?'rgba(16,185,129,0.1)':'rgba(245,158,11,0.1)'};border:1px solid ${serverOnline?'var(--success)':'var(--warning)'};border-radius:10px;padding:12px 16px;margin-bottom:16px;display:flex;gap:12px;align-items:center;justify-content:space-between">
          <div style="display:flex;gap:12px;align-items:center">
            <span style="font-size:1.3rem">${serverOnline?'🖨️':'⚠️'}</span>
            <div style="font-size:0.83rem">
              ${serverOnline
                ? `<strong style="color:var(--success)">${isAR?'الخادم يعمل — تم تحميل الطابعات':'Server Online — Printers Loaded'}</strong><br>
                   <span style="color:var(--text-muted)">${isAR?`تم العثور على ${printerList.length} طابعة مثبتة`:`Found ${printerList.length} installed printer(s)`}</span>`
                : `<strong style="color:var(--warning)">${isAR?'الخادم غير متصل':'Server Offline'}</strong><br>
                   <span style="color:var(--text-muted)">${isAR?'لعرض الطابعات، شغّل الخادم: <code style="background:var(--surface);padding:1px 5px;border-radius:3px">node server.js</code>':'To list printers, run: <code style="background:var(--surface);padding:1px 5px;border-radius:3px">node server.js</code> in the app folder'}</span>`}
            </div>
          </div>
          <button class="btn btn-secondary btn-sm" onclick="Admin.renderSettings(document.getElementById('page-content'))">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
            ${isAR?'تحديث':'Refresh'}
          </button>
        </div>

        <!-- RECEIPT PRINTER -->
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">🧾</span>
              ${isAR ? 'طابعة الإيصالات الحرارية الافتراضية (كاشير + كشف حساب حراري 80mm)' : 'Default Receipt Printer (POS Checkout + 80mm Account Statement)'}
            </div>
            <button class="btn btn-secondary btn-sm" onclick="Admin.testPrint('receipt')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'طباعة تجريبية' : 'Test Print'}
            </button>
          </div>
          <div class="modal-body">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label" style="display:flex;align-items:center;gap:6px">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  ${isAR?'اختر الطابعة':'Select Printer'}
                </label>
                <select class="form-control" id="set-receipt-printer">
                  ${printerOptions(settings.receipt_printer)}
                </select>
                <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR?'★ = الطابعة الافتراضية في Windows':'★ = Windows default printer'}</div>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'حجم ورق الإيصال':'Receipt Paper Size'}</label>
                <select class="form-control" id="set-receipt-size">
                  <option value="80mm" ${settings.receipt_size==='80mm'?'selected':''}>🧾 80mm — ${isAR?'حراري ضيق (POS)':'Narrow Thermal (POS)'}</option>
                  <option value="58mm" ${settings.receipt_size==='58mm'?'selected':''}>🧾 58mm — ${isAR?'حراري صغير':'Small Thermal'}</option>
                  <option value="A5"   ${settings.receipt_size==='A5'?'selected':''}>📄 A5 — ${isAR?'نصف A4':'Half A4'}</option>
                  <option value="A4"   ${settings.receipt_size==='A4'?'selected':''}>📄 A4 — ${isAR?'طابعة عادية':'Standard Printer'}</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'عدد نسخ الإيصال':'Receipt Copies'}</label>
                <select class="form-control" id="set-receipt-copies">
                  <option value="1" ${settings.receipt_copies==1?'selected':''}>1</option>
                  <option value="2" ${settings.receipt_copies==2?'selected':''}>2</option>
                  <option value="3" ${settings.receipt_copies==3?'selected':''}>3</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'نص ذيل الإيصال':'Receipt Footer'}</label>
                <input type="text" class="form-control" id="set-receipt-footer" value="${Utils.sanitize(settings.receipt_footer)}" placeholder="Thank you!">
              </div>
            </div>
            <div class="grid grid-2" style="margin-top:8px">
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:8px">
                <div>
                  <div style="font-weight:600;font-size:0.85rem">${isAR?'طباعة تلقائية فورية عند إتمام الدفع':'Direct Print on Payment'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'يرسل الفاتورة للطابعة مباشرة بدون إضاعة وقت':'Directly sends print job to printer on checkout'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-auto-print" ${settings.auto_print?'checked':''}><span class="toggle-slider"></span></label>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:8px">
                <div>
                  <div style="font-weight:600;font-size:0.85rem">${isAR?'عرض نافذة معاينة الفاتورة بعد البيع':'Show Invoice Preview Popup After Sale'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'عند إلغاء التفعيل يتم إغلاق المعاينة والطباعة مباشرة':'When off, prints directly and starts next sale without popup'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-pos-preview-receipt" ${settings.pos_preview_receipt?'checked':''}><span class="toggle-slider"></span></label>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:8px">
                <div>
                  <div style="font-weight:600;font-size:0.85rem">${isAR?'طباعة الباركود':'Print Barcode'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'رمز الباركود على الإيصال':'Barcode on receipt'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-show-barcode" ${settings.show_barcode?'checked':''}><span class="toggle-slider"></span></label>
              </div>
            </div>
          </div>
        </div>

        <!-- DOCUMENT PRINTER -->
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">📄</span>
              ${isAR ? 'طابعة المستندات والفواتير الرسمية (فواتير A4 + كشف حساب عميل/مورد A4 + أوامر شراء)' : 'Document Printer (A4 Invoices + Official Account Statements + POs)'}
            </div>
            <button class="btn btn-secondary btn-sm" onclick="Admin.testPrint('document')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'طباعة تجريبية' : 'Test Print'}
            </button>
          </div>
          <div class="modal-body">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label" style="display:flex;align-items:center;gap:6px">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  ${isAR?'اختر الطابعة':'Select Printer'}
                </label>
                <select class="form-control" id="set-document-printer">
                  ${printerOptions(settings.document_printer)}
                </select>
                <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR?'★ = الطابعة الافتراضية في Windows':'★ = Windows default printer'}</div>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'حجم ورق الفواتير':'Invoice / PO Paper Size'}</label>
                <select class="form-control" id="set-invoice-size">
                  <option value="80mm"   ${settings.invoice_size==='80mm'?'selected':''}>🧾 80mm — ${isAR?'حراري (POS Thermal)':'80mm Thermal (POS)'}</option>
                  <option value="58mm"   ${settings.invoice_size==='58mm'?'selected':''}>🧾 58mm — ${isAR?'حراري صغير':'58mm Thermal'}</option>
                  <option value="A4"     ${settings.invoice_size==='A4'?'selected':''}>📄 A4 (210 × 297 mm)</option>
                  <option value="A5"     ${settings.invoice_size==='A5'?'selected':''}>📄 A5 (148 × 210 mm)</option>
                  <option value="Letter" ${settings.invoice_size==='Letter'?'selected':''}>📄 Letter — 8.5" × 11"</option>
                  <option value="Legal"  ${settings.invoice_size==='Legal'?'selected':''}>📄 Legal — 8.5" × 14"</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'عدد نسخ الفاتورة':'Invoice Copies'}</label>
                <select class="form-control" id="set-invoice-copies">
                  <option value="1" ${settings.invoice_copies==1?'selected':''}>1</option>
                  <option value="2" ${settings.invoice_copies==2?'selected':''}>2</option>
                  <option value="3" ${settings.invoice_copies==3?'selected':''}>3</option>
                </select>
              </div>
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:8px">
                <div>
                  <div style="font-weight:600;font-size:0.85rem">${isAR?'طباعة شعار الشركة':'Print Company Logo'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'شعار على كل مستند مطبوع':'Logo on printed documents'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-print-logo" ${settings.print_logo?'checked':''}><span class="toggle-slider"></span></label>
              </div>
            </div>
          </div>
        </div>

        <!-- LABEL PRINTER -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">🏷️</span>
              ${isAR ? 'طابعة الملصقات (باركود)' : 'Label Printer (Barcode)'}
            </div>
            <button class="btn btn-secondary btn-sm" onclick="Admin.testPrint('label')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'طباعة تجريبية' : 'Test Print'}
            </button>
          </div>
          <div class="modal-body">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label" style="display:flex;align-items:center;gap:6px">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  ${isAR?'اختر الطابعة':'Select Printer'}
                </label>
                <select class="form-control" id="set-label-printer">
                  ${printerOptions(settings.label_printer)}
                </select>
                <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR?'★ = الطابعة الافتراضية في Windows':'★ = Windows default printer'}</div>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'حجم الملصق':'Label Size'}</label>
                <select class="form-control" id="set-po-size" onchange="document.getElementById('set-custom-label-dims').style.display = this.value==='custom'?'grid':'none'">
                  <option value="40x30mm" ${settings.po_size==='40x30mm'?'selected':''}>🏷️ 40 × 30 mm ${isAR?'(ملصق صغير)':'(Small)'}</option>
                  <option value="50x30mm" ${settings.po_size==='50x30mm'?'selected':''}>🏷️ 50 × 30 mm</option>
                  <option value="58x40mm" ${settings.po_size==='58x40mm'?'selected':''}>🏷️ 58 × 40 mm</option>
                  <option value="100x50mm" ${settings.po_size==='100x50mm'?'selected':''}>🏷️ 100 × 50 mm ${isAR?'(ملصق كبير)':'(Large)'}</option>
                  <option value="A4"      ${settings.po_size==='A4'?'selected':''}>📄 A4 ${isAR?'(صفحة ملصقات)':'(Sheet Labels)'}</option>
                  <option value="custom"  ${settings.po_size==='custom'?'selected':''}>✏️ ${isAR?'حجم مخصص (Custom mm)':'Custom Dimensions (mm)'}</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'اتجاه وتدوير الملصق':'Label Direction & Rotation'}</label>
                <select class="form-control" id="set-label-orientation">
                  <option value="horizontal" ${(!settings.label_orientation || settings.label_orientation==='horizontal' || settings.label_orientation==='0' || settings.label_orientation==='portrait')?'selected':''}>↔️ ${isAR?'عرضي / أفقي (الوضع الطبيعي)':'Horizontal (Standard)'}</option>
                  <option value="vertical" ${(settings.label_orientation==='vertical' || settings.label_orientation==='90' || settings.label_orientation==='rotate90' || settings.label_orientation==='landscape')?'selected':''}>↕️ ${isAR?'طولي / عمودي':'Vertical (Swapped)'}</option>
                  <option value="180" ${(settings.label_orientation==='180' || settings.label_orientation==='rotate180')?'selected':''}>🔄 ${isAR?'مقلوب 180°':'Inverted 180°'}</option>
                  <option value="270" ${(settings.label_orientation==='270' || settings.label_orientation==='rotate270')?'selected':''}>🔄 ${isAR?'طولي مقلوب 270°':'Vertical Inverted 270°'}</option>
                </select>
              </div>
            </div>

            <!-- Custom Label Dimensions -->
            <div id="set-custom-label-dims" class="grid grid-2" style="gap:10px;margin-top:10px;display:${settings.po_size==='custom'?'grid':'none'}">
              <div class="form-group">
                <label class="form-label" style="font-size:0.75rem">${isAR?'عرض الملصق (Width mm)':'Label Width (mm)'}</label>
                <input type="number" class="form-control" id="set-label-custom-width" value="${settings.label_custom_width || 50}" min="20" max="250">
              </div>
              <div class="form-group">
                <label class="form-label" style="font-size:0.75rem">${isAR?'ارتفاع الملصق (Height mm)':'Label Height (mm)'}</label>
                <input type="number" class="form-control" id="set-label-custom-height" value="${settings.label_custom_height || 30}" min="10" max="250">
              </div>
            </div>

            <!-- What to Print on Label -->
            <div style="margin-top:16px;padding:14px;background:var(--surface-2);border-radius:10px">
              <div style="font-weight:700;font-size:0.85rem;margin-bottom:10px;display:flex;align-items:center;gap:8px">
                <span>📋</span>
                ${isAR ? 'محتويات ملصق الباركود المطبوعة' : 'What to Print on Barcode Label'}
              </div>
              <div class="grid grid-3" style="gap:10px">
                <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                  <input type="checkbox" id="set-label-show-name" ${settings.label_show_name !== false ? 'checked' : ''}>
                  ${isAR ? 'اسم الصنف' : 'Item Name'}
                </label>
                <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                  <input type="checkbox" id="set-label-show-code" ${settings.label_show_code !== false ? 'checked' : ''}>
                  ${isAR ? 'كود الصنف' : 'Item Code'}
                </label>
                <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                  <input type="checkbox" id="set-label-show-barcode" ${settings.label_show_barcode !== false ? 'checked' : ''}>
                  ${isAR ? 'خطوط الباركود' : 'Barcode Lines'}
                </label>
                <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                  <input type="checkbox" id="set-label-show-digits" ${settings.label_show_digits !== false ? 'checked' : ''}>
                  ${isAR ? 'أرقام الباركود' : 'Barcode Digits'}
                </label>
                <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                  <input type="checkbox" id="set-label-show-price" ${settings.label_show_price !== false ? 'checked' : ''}>
                  ${isAR ? 'سعر البيع' : 'Selling Price'}
                </label>
                <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                  <input type="checkbox" id="set-label-show-company" ${settings.label_show_company ? 'checked' : ''}>
                  ${isAR ? 'اسم المتجر / الشركة' : 'Store Name'}
                </label>
              </div>
            </div>

            <!-- Windows Printer Setup Steps -->
            <div style="margin-top:16px;padding:16px;background:var(--surface-2);border-radius:10px">
              <div style="font-weight:700;font-size:0.85rem;margin-bottom:12px;display:flex;align-items:center;gap:8px">
                <svg viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2" width="16" height="16"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                ${isAR?'كيفية الحصول على اسم الطابعة من Windows:':'How to find your printer name in Windows:'}
              </div>
              <div style="font-size:0.8rem;color:var(--text-secondary);line-height:2">
                <div style="display:flex;gap:10px;margin-bottom:6px">
                  <span style="background:var(--primary);color:white;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;flex-shrink:0">1</span>
                  <span>${isAR?'اضغط <strong>Win + R</strong> ثم اكتب <code style="background:var(--surface);padding:1px 6px;border-radius:4px">control printers</code> ثم Enter':'Press <strong>Win + R</strong>, type <code style="background:var(--surface);padding:1px 6px;border-radius:4px">control printers</code>, press Enter'}</span>
                </div>
                <div style="display:flex;gap:10px;margin-bottom:6px">
                  <span style="background:var(--primary);color:white;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;flex-shrink:0">2</span>
                  <span>${isAR?'ستظهر قائمة بجميع الطابعات المثبتة':'You will see a list of all installed printers'}</span>
                </div>
                <div style="display:flex;gap:10px;margin-bottom:6px">
                  <span style="background:var(--primary);color:white;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;flex-shrink:0">3</span>
                  <span>${isAR?'انسخ اسم الطابعة <strong>بالضبط</strong> كما يظهر (مع المسافات والأرقام) والصقه في الحقل أعلاه':'Copy the printer name <strong>exactly</strong> as shown (including spaces & numbers) and paste it above'}</span>
                </div>
                <div style="display:flex;gap:10px">
                  <span style="background:var(--success);color:white;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;font-size:0.7rem;font-weight:700;flex-shrink:0">✓</span>
                  <span>${isAR?'اضغط <strong>Test Print</strong> على كل قسم للتحقق من الإعداد. سيتم فتح نافذة الطباعة تلقائياً بحجم الورق والاتجاه الصحيح.':'Click <strong>Test Print</strong> on each section to verify. The print dialog will open with the correct paper size and orientation pre-set.'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- CUSTOMER POLE DISPLAY (LED8N / VFD) -->
        <div class="card mb-3" style="margin-top:16px">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">🖥️</span>
              ${isAR ? 'شاشة عرض العميل الخلفية (LED8N / VFD Customer Pole Display)' : 'Customer Pole Display (LED8N / VFD Rear Screen)'}
            </div>
            <button class="btn btn-secondary btn-sm" onclick="Admin.testPoleDisplay()">
              <span>⚡</span>
              ${isAR ? 'إرسال تجربة للشاشة' : 'Send Test To Display'}
            </button>
          </div>
          <div class="modal-body">
            <div class="grid grid-2">
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:8px">
                <div>
                  <div style="font-weight:600;font-size:0.85rem">${isAR ? 'تفعيل شاشة العميل الخلفية' : 'Enable Customer Pole Display'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'عرض المجموع المستحق والباقي تلقائياً على الشاشة الخضراء خلف الكاشير' : 'Streams grand total and change directly to the 8-digit LED rear pole display'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-pole-display-enabled" ${settings.pole_display_enabled !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <div class="form-group">
                <label class="form-label" style="display:flex;align-items:center;gap:6px">
                  <span>🔌</span>
                  ${isAR ? 'منفذ الشاشة التسلسلي (Serial / COM Port)' : 'Serial / COM Port'}
                </label>
                <select class="form-control" id="set-pole-display-port">
                  ${comPortOptions(settings.pole_display_port)}
                </select>
                <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR ? 'في أجهزة نقاط البيع All-In-One تكون الشاشة موصولة داخلياً بـ COM1 أو COM2 أو COM3' : 'On all-in-one POS terminals, the rear display is wired to COM1, COM2, or COM3'}</div>
              </div>

              <div class="form-group">
                <label class="form-label">${isAR ? 'سرعة الاتصال (Baud Rate)' : 'Baud Rate'}</label>
                <select class="form-control" id="set-pole-display-baud">
                  <option value="2400" ${String(settings.pole_display_baud) === '2400' ? 'selected' : ''}>2400 bps (LED8N Standard — قياسي)</option>
                  <option value="9600" ${String(settings.pole_display_baud) === '9600' ? 'selected' : ''}>9600 bps (VFD / High-Speed)</option>
                  <option value="4800" ${String(settings.pole_display_baud) === '4800' ? 'selected' : ''}>4800 bps</option>
                  <option value="19200" ${String(settings.pole_display_baud) === '19200' ? 'selected' : ''}>19200 bps</option>
                </select>
              </div>

              <div style="padding:12px;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:8px;display:flex;align-items:center;gap:12px">
                <div style="font-size:1.6rem;font-family:monospace;font-weight:900;color:#10b981;background:#052e16;padding:4px 12px;border-radius:6px;border:1px solid #10b981">
                  88.88
                </div>
                <div style="font-size:0.75rem;color:var(--text-secondary)">
                  ${isAR ? 'بروتوكول الشاشة مدعوم (LED8N / ESC Q A / POS58). عند اختيار المنفذ الصحيح سيظهر المبلغ فوراً على الشاشة الخلفية.' : 'Standard 8-digit LED8N protocol supported. When the correct COM port is selected, totals and change appear instantly on the rear screen.'}
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

      <!-- Invoice & Receipt Designer -->
      <div class="tab-content" id="tab-set-invoice-designer">
        <div style="display:flex;gap:20px;align-items:flex-start;flex-wrap:wrap">
          <!-- Left Column: Controls (Independently Scrollable with Full Option Visibility) -->
          <div class="inv-designer-controls-col" style="flex:1;min-width:360px;max-width:540px;display:flex;flex-direction:column;gap:16px;max-height:calc(100vh - 175px);overflow-y:auto;overflow-x:hidden;padding-right:10px;padding-bottom:40px;scrollbar-width:thin">

            <!-- Quick Action Bar (Top) -->
            <div style="display:flex;gap:8px;position:sticky;top:0;z-index:10;background:var(--bg-base);padding:4px 0 8px 0">
              <button class="btn btn-primary btn-sm" style="flex:1" onclick="Admin.saveSettings()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
                ${isAR ? 'حفظ التصميم' : 'Save Design'}
              </button>
              <button class="btn btn-secondary btn-sm" onclick="Admin.resetInvoiceDesignDefaults()">
                🔄 ${isAR ? 'افتراضي' : 'Reset'}
              </button>
              <button class="btn btn-secondary btn-sm" onclick="Admin.testPrintInvoiceDesign()">
                🖨️ ${isAR ? 'طباعة تجريبية' : 'Test Print'}
              </button>
            </div>

            <!-- Card 1: Colors & Typography -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>🎨</span>
                  ${isAR ? 'الهوية البصرية والألوان والخطوط' : 'Theme Colors & Typography'}
                </div>
              </div>
              <div class="modal-body">
                <div class="grid grid-2" style="gap:12px">
                  <div class="form-group">
                    <label class="form-label">${isAR ? 'اللون الأساسي للفاتورة' : 'Primary Brand Color'}</label>
                    <div style="display:flex;align-items:center;gap:10px">
                      <input type="color" id="inv-primary-color" value="${settings.inv_primary_color || '#2563eb'}" style="width:44px;height:38px;padding:2px;border-radius:6px;border:1px solid var(--border-color);cursor:pointer" onchange="Admin.updateInvoiceDesignerPreview()">
                      <input type="text" class="form-control" id="inv-primary-color-text" value="${settings.inv_primary_color || '#2563eb'}" style="font-family:monospace;font-size:0.85rem" oninput="document.getElementById('inv-primary-color').value=this.value;Admin.updateInvoiceDesignerPreview()">
                    </div>
                    <!-- Color Swatches -->
                    <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
                      ${['#2563eb', '#0f172a', '#059669', '#dc2626', '#7c3aed', '#ea580c', '#0891b2', '#1e293b'].map(c => `
                        <div onclick="document.getElementById('inv-primary-color').value='${c}';document.getElementById('inv-primary-color-text').value='${c}';Admin.updateInvoiceDesignerPreview()" style="width:24px;height:24px;border-radius:50%;background:${c};cursor:pointer;border:2px solid ${c===(settings.inv_primary_color||'#2563eb')?'#fff':'transparent'};box-shadow:0 1px 3px rgba(0,0,0,0.2)"></div>
                      `).join('')}
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="form-label">${isAR ? 'نوع الخط' : 'Font Family'}</label>
                    <select class="form-control" id="inv-font-family" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value="Cairo" ${settings.inv_font_family==='Cairo'?'selected':''}>Cairo (عربي / Modern)</option>
                      <option value="Inter" ${settings.inv_font_family==='Inter'?'selected':''}>Inter (Clean / English)</option>
                      <option value="Roboto" ${settings.inv_font_family==='Roboto'?'selected':''}>Roboto (Standard)</option>
                      <option value="Tajawal" ${settings.inv_font_family==='Tajawal'?'selected':''}>Tajawal (عربي حديث)</option>
                      <option value="Almarai" ${settings.inv_font_family==='Almarai'?'selected':''}>Almarai (عربي رسمي)</option>
                      <option value="Amiri" ${settings.inv_font_family==='Amiri'?'selected':''}>Amiri (عربي تقليدي)</option>
                      <option value="Tahoma" ${settings.inv_font_family==='Tahoma'?'selected':''}>Tahoma (Classic)</option>
                      <option value="Arial" ${settings.inv_font_family==='Arial'?'selected':''}>Arial (Universal)</option>
                      <option value="Segoe UI" ${settings.inv_font_family==='Segoe UI'?'selected':''}>Segoe UI (Windows)</option>
                      <option value="Courier New" ${settings.inv_font_family==='Courier New'?'selected':''}>Courier New (Monospace / POS)</option>
                    </select>
                  </div>

                  <div class="form-group" style="grid-column:1/-1">
                    <label class="form-label">${isAR ? 'نمط وقالب الفاتورة' : 'Invoice Layout Template'}</label>
                    <select class="form-control" id="inv-template" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value="modern" ${settings.inv_template==='modern'?'selected':''}>✨ ${isAR ? 'عصري وحديث (Modern Sleek)' : 'Modern Sleek'}</option>
                      <option value="classic" ${settings.inv_template==='classic'?'selected':''}>🏛️ ${isAR ? 'كلاسيكي محدد بإطارات (Classic Boxed)' : 'Classic Boxed'}</option>
                      <option value="minimal" ${settings.inv_template==='minimal'?'selected':''}>📄 ${isAR ? 'بسيط أحادي اللون (Minimalist Mono)' : 'Minimalist Mono'}</option>
                      <option value="bordered" ${settings.inv_template==='bordered'?'selected':''}>📑 ${isAR ? 'جدول مؤطر رسمي (Formal Bordered)' : 'Formal Bordered'}</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <!-- Card 1.5: Font Sizes Per Box -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>📐</span>
                  ${isAR ? 'أحجام الخطوط المخصصة لكل قسم وصندوق بالفاتورة' : 'Font Sizes Per Invoice Box / Section'}
                </div>
              </div>
              <div class="modal-body">
                <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:12px">
                  ${isAR ? 'تحكم بحجم خط كل جزء وصندوق في الفاتورة بدقة مع معاينة فورية ومباشرة.' : 'Fine-tune the typography size of each specific box and element across the invoice.'}
                </div>

                <!-- Group A: Header & Company -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? '1. ترويسة المتجر وعنوان الفاتورة:' : '1. Store Header & Document Title:'}
                </div>
                <div class="grid grid-2" style="gap:10px;margin-bottom:14px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'اسم المتجر' : 'Store Name'}</label>
                    ${_renderFsSelect('inv-fs-company-name', settings.inv_fs_company_name, '24px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'وصف المتجر (Slogan)' : 'Store Slogan / Subtitle'}</label>
                    ${_renderFsSelect('inv-fs-subtitle', settings.inv_fs_subtitle, '13px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'بيانات الاتصال والرقم الضريبي' : 'Contact & Tax Info'}</label>
                    ${_renderFsSelect('inv-fs-header-contact', settings.inv_fs_header_contact, '12px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عنوان الفاتورة الرئيسي (TAX INVOICE)' : 'Invoice Title (TAX INVOICE)'}</label>
                    ${_renderFsSelect('inv-fs-doc-title', settings.inv_fs_doc_title, '22px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'رقم الفاتورة (# INV-...)' : 'Invoice Ref Number'}</label>
                    ${_renderFsSelect('inv-fs-doc-num', settings.inv_fs_doc_num, '15px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'تواريخ الإصدار والاستحقاق' : 'Issue & Due Dates'}</label>
                    ${_renderFsSelect('inv-fs-meta-text', settings.inv_fs_meta_text, '12px', isAR)}
                  </div>
                </div>

                <!-- Group B: Customer & Cashier Boxes -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? '2. صناديق العميل والمبيعات والكاشير:' : '2. Customer & Cashier Boxes:'}
                </div>
                <div class="grid grid-2" style="gap:10px;margin-bottom:14px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'صندوق العميل (بيانات العميل)' : 'Customer (Bill To) Box'}</label>
                    ${_renderFsSelect('inv-fs-customer-box', settings.inv_fs_customer_box, '13px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'صندوق الكاشير وطريقة الدفع' : 'Cashier & Payment Box'}</label>
                    ${_renderFsSelect('inv-fs-cashier-box', settings.inv_fs_cashier_box, '13px', isAR)}
                  </div>
                </div>

                <!-- Group C: Items Table -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? '3. جدول الأصناف والمواصفات:' : '3. Items Table & Attributes:'}
                </div>
                <div class="grid grid-3" style="gap:10px;margin-bottom:14px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عناوين الأعمدة' : 'Column Headers'}</label>
                    ${_renderFsSelect('inv-fs-table-header', settings.inv_fs_table_header, '12px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'صفوف الأصناف والأسعار' : 'Item Names & Rows'}</label>
                    ${_renderFsSelect('inv-fs-table-rows', settings.inv_fs_table_rows, '12px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'المواصفات والأسطر الفرعية' : 'Attributes Subline'}</label>
                    ${_renderFsSelect('inv-fs-item-subline', settings.inv_fs_item_subline, '11px', isAR)}
                  </div>
                </div>

                <!-- Group D: Totals Box & Footer -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? '4. صندوق الإجماليات والتذييل:' : '4. Totals Box, Terms & Footer:'}
                </div>
                <div class="grid grid-2" style="gap:10px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'خطوط المجاميع والضريبة' : 'Subtotal & Tax Rows'}</label>
                    ${_renderFsSelect('inv-fs-totals-box', settings.inv_fs_totals_box, '12px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'الإجمالي النهائي (Grand Total)' : 'Grand Total Line'}</label>
                    ${_renderFsSelect('inv-fs-grand-total', settings.inv_fs_grand_total, '16px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'المعادل بالعملة الثانوية' : 'Secondary Currency'}</label>
                    ${_renderFsSelect('inv-fs-cur2-total', settings.inv_fs_cur2_total, '13px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'الشروط وسياسة الإرجاع' : 'Terms & Return Policy'}</label>
                    ${_renderFsSelect('inv-fs-terms', settings.inv_fs_terms, '11px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'أختام وتواقيع المتجر' : 'Stamps & Signatures'}</label>
                    ${_renderFsSelect('inv-fs-signatures', settings.inv_fs_signatures, '12px', isAR)}
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عبارة الشكر والتذييل' : 'Footer Note'}</label>
                    ${_renderFsSelect('inv-fs-footer-note', settings.inv_fs_footer_note, '11px', isAR)}
                  </div>
                </div>

              </div>
            </div>

            <!-- Card 1.6: Custom Fixed Texts & Labels -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>✏️</span>
                  ${isAR ? 'تخصيص النصوص الثابتة وتسميات الفاتورة' : 'Customize Fixed Labels & Texts'}
                </div>
              </div>
              <div class="modal-body">
                <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:12px">
                  ${isAR ? 'يمكنك استبدال أي نص ثابت في الفاتورة (مثل عنوان الفاتورة، تسميات الأعمدة، المجاميع، والتواقيع) بكلماتك الخاصة.' : 'Override any default static label on the invoice (e.g. Doc Title, column headers, totals, and signatures) with your own wording.'}
                </div>

                <!-- Main Titles -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? 'العناوين والتواريخ والرقم الضريبي:' : 'Titles, Dates & Tax Label:'}
                </div>
                <div class="grid grid-2" style="gap:10px;margin-bottom:14px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عنوان الفاتورة' : 'Invoice Doc Title'}</label>
                    <input type="text" class="form-control" id="inv-txt-doc-title" value="${Utils.sanitize(settings.inv_txt_doc_title||'')}" placeholder="${isAR ? 'فاتورة ضريبية' : 'TAX INVOICE'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'تسمية تاريخ الإصدار' : 'Issue Date Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-date-label" value="${Utils.sanitize(settings.inv_txt_date_label||'')}" placeholder="${isAR ? 'تاريخ الإصدار: ' : 'Issue Date: '}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'تسمية تاريخ الاستحقاق' : 'Due Date Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-duedate-label" value="${Utils.sanitize(settings.inv_txt_duedate_label||'')}" placeholder="${isAR ? 'الاستحقاق: ' : 'Due Date: '}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'تسمية الرقم الضريبي' : 'Tax ID Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-tax-id-label" value="${Utils.sanitize(settings.inv_txt_tax_id_label||'')}" placeholder="${isAR ? 'الرقم الضريبي / المالي: ' : 'Tax ID: '}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                </div>

                <!-- Parties Labels -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? 'صناديق العميل والكاشير والدفع:' : 'Customer, Cashier & Payment Labels:'}
                </div>
                <div class="grid grid-3" style="gap:10px;margin-bottom:14px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عنوان صندوق العميل' : 'Bill To Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-bill-to-label" value="${Utils.sanitize(settings.inv_txt_bill_to_label||'')}" placeholder="${isAR ? 'فاتورة إلى / العميل:' : 'BILL TO / CUSTOMER:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عنوان صندوق الكاشير' : 'Cashier Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-cashier-label" value="${Utils.sanitize(settings.inv_txt_cashier_label||'')}" placeholder="${isAR ? 'المبيعات / الكاشير:' : 'SALES / CASHIER:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'تسمية طريقة الدفع' : 'Payment Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-payment-label" value="${Utils.sanitize(settings.inv_txt_payment_label||'')}" placeholder="${isAR ? 'طريقة الدفع:' : 'Payment:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                </div>

                <!-- Table Header Labels -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? 'عناوين أعمدة جدول الأصناف:' : 'Table Columns Header Labels:'}
                </div>
                <div class="grid grid-3" style="gap:10px;margin-bottom:14px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عمود الصنف' : 'Item Col'}</label>
                    <input type="text" class="form-control" id="inv-txt-col-item" value="${Utils.sanitize(settings.inv_txt_col_item||'')}" placeholder="${isAR ? 'الصنف والمواصفات' : 'Item Description'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عمود الكود' : 'SKU Col'}</label>
                    <input type="text" class="form-control" id="inv-txt-col-sku" value="${Utils.sanitize(settings.inv_txt_col_sku||'')}" placeholder="${isAR ? 'الكود' : 'SKU'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عمود الكمية' : 'Qty Col'}</label>
                    <input type="text" class="form-control" id="inv-txt-col-qty" value="${Utils.sanitize(settings.inv_txt_col_qty||'')}" placeholder="${isAR ? 'الكمية' : 'Qty'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عمود السعر' : 'Price Col'}</label>
                    <input type="text" class="form-control" id="inv-txt-col-price" value="${Utils.sanitize(settings.inv_txt_col_price||'')}" placeholder="${isAR ? 'السعر' : 'Price'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عمود الخصم' : 'Disc Col'}</label>
                    <input type="text" class="form-control" id="inv-txt-col-disc" value="${Utils.sanitize(settings.inv_txt_col_disc||'')}" placeholder="${isAR ? 'الخصم' : 'Disc'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'عمود الإجمالي' : 'Total Col'}</label>
                    <input type="text" class="form-control" id="inv-txt-col-total" value="${Utils.sanitize(settings.inv_txt_col_total||'')}" placeholder="${isAR ? 'الإجمالي' : 'Total'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                </div>

                <!-- Totals & Signatures Labels -->
                <div style="font-weight:700;font-size:0.82rem;color:var(--text-primary);margin-bottom:8px;padding-bottom:4px;border-bottom:1px solid var(--border-color)">
                  ${isAR ? 'تسميات المجاميع والتواقيع والشروط:' : 'Totals, Signatures & Terms Labels:'}
                </div>
                <div class="grid grid-2" style="gap:10px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'المجموع الفرعي' : 'Subtotal Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-subtotal-label" value="${Utils.sanitize(settings.inv_txt_subtotal_label||'')}" placeholder="${isAR ? 'المجموع الفرعي:' : 'Subtotal:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'الخصم' : 'Discount Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-discount-label" value="${Utils.sanitize(settings.inv_txt_discount_label||'')}" placeholder="${isAR ? 'الخصم:' : 'Discount:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'الضريبة' : 'VAT / Tax Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-vat-label" value="${Utils.sanitize(settings.inv_txt_vat_label||'')}" placeholder="${isAR ? 'الضريبة:' : 'VAT:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'الإجمالي النهائي' : 'Grand Total Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-grand-total-label" value="${Utils.sanitize(settings.inv_txt_grand_total_label||'')}" placeholder="${isAR ? 'الإجمالي:' : 'GRAND TOTAL:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'المعادل بالعملة الثانوية' : 'Secondary Currency Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-cur2-label" value="${Utils.sanitize(settings.inv_txt_cur2_label||'')}" placeholder="${isAR ? 'المعادل:' : 'In LBP:'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'تسمية الشروط' : 'Terms Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-terms-label" value="${Utils.sanitize(settings.inv_txt_terms_label||'')}" placeholder="${isAR ? 'الشروط: ' : 'Terms: '}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'توقيع العميل' : 'Customer Signature Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-cust-sig-label" value="${Utils.sanitize(settings.inv_txt_cust_sig_label||'')}" placeholder="${isAR ? 'توقيع المستلم / العميل' : 'Customer Signature'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem">${isAR ? 'ختم وتوقيع المتجر' : 'Store Stamp Label'}</label>
                    <input type="text" class="form-control" id="inv-txt-store-sig-label" value="${Utils.sanitize(settings.inv_txt_store_sig_label||'')}" placeholder="${isAR ? 'ختم وتوقيع المتجر' : 'Store Stamp & Signature'}" oninput="Admin.updateInvoiceDesignerPreview()">
                  </div>
                </div>

              </div>
            </div>

            <!-- Card 2: Logo Placement & Header -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>🖼️</span>
                  ${isAR ? 'شعار المتجر وإعدادات العرض' : 'Store Logo & Display Options'}
                </div>
              </div>
              <div class="modal-body">
                <!-- Direct Logo Upload Box -->
                <div style="display:flex;align-items:center;gap:14px;padding:12px;background:var(--surface-2);border-radius:10px;margin-bottom:12px;border:1px dashed var(--border-color)">
                  <div id="inv-company-logo-preview" style="width:70px;height:70px;border-radius:8px;background:var(--surface);display:flex;align-items:center;justify-content:center;overflow:hidden;border:1px solid var(--border-color);flex-shrink:0">
                    ${settings.company_logo ? `<img src="${settings.company_logo}" style="max-width:100%;max-height:100%;object-fit:contain">` : `<span style="font-size:0.7rem;color:var(--text-muted)">${isAR?'لا يوجد':'No Logo'}</span>`}
                  </div>
                  <div style="flex:1">
                    <div style="font-weight:700;font-size:0.85rem;margin-bottom:2px">${isAR ? 'تحميل أو تغيير الشعار' : 'Upload or Replace Logo'}</div>
                    <div style="font-size:0.72rem;color:var(--text-muted);margin-bottom:8px">${isAR ? 'صيغة PNG أو JPG تظهر فوراً بالمعاينة والطباعة' : 'PNG or JPG image, updates preview immediately'}</div>
                    <div style="display:flex;gap:6px">
                      <input type="file" id="inv-logo-file-input" accept="image/*" style="display:none" onchange="Admin.handleLogoUpload(this)">
                      <button type="button" class="btn btn-primary btn-xs" onclick="document.getElementById('inv-logo-file-input').click()">
                        📁 ${isAR ? 'اختيار صورة' : 'Choose Image'}
                      </button>
                      <button type="button" class="btn btn-danger btn-xs" onclick="Admin.removeLogo()">
                        🗑️ ${isAR ? 'حذف الشعار' : 'Remove'}
                      </button>
                    </div>
                  </div>
                </div>

                <div class="grid grid-2" style="gap:12px">
                  <div class="form-group">
                    <label class="form-label">${isAR ? 'موضع الشعار بالفاتورة' : 'Logo Position'}</label>
                    <select class="form-control" id="inv-logo-position" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value="left" ${settings.inv_logo_position==='left'?'selected':''}>⬅️ ${isAR ? 'على اليسار (Left)' : 'Left'}</option>
                      <option value="center" ${settings.inv_logo_position==='center'?'selected':''}>⏺️ ${isAR ? 'في الوسط (Center)' : 'Center'}</option>
                      <option value="right" ${settings.inv_logo_position==='right'?'selected':''}>➡️ ${isAR ? 'على اليمين (Right)' : 'Right'}</option>
                      <option value="hidden" ${settings.inv_logo_position==='hidden'?'selected':''}>🚫 ${isAR ? 'إخفاء الشعار (Hidden)' : 'Hidden'}</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label class="form-label">${isAR ? 'حجم / عرض الشعار' : 'Logo Max Size'}</label>
                    <select class="form-control" id="inv-logo-size" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value="50" ${settings.inv_logo_size==50?'selected':''}>🔍 ${isAR ? 'صغير (50px)' : 'Small (50px)'}</option>
                      <option value="80" ${settings.inv_logo_size==80||!settings.inv_logo_size?'selected':''}>🔍 ${isAR ? 'متوسط (80px)' : 'Medium (80px)'}</option>
                      <option value="110" ${settings.inv_logo_size==110?'selected':''}>🔍 ${isAR ? 'كبير (110px)' : 'Large (110px)'}</option>
                      <option value="140" ${settings.inv_logo_size==140?'selected':''}>🔍 ${isAR ? 'كبير جداً (140px)' : 'Extra Large (140px)'}</option>
                    </select>
                  </div>

                  <div class="form-group" style="grid-column:1/-1">
                    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px;background:var(--surface-2);border-radius:8px">
                      <div>
                        <div style="font-weight:600;font-size:0.85rem">${isAR ? 'طباعة شعار المتجر' : 'Print Store Logo'}</div>
                        <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار الشعار على الفواتير والإيصالات' : 'Show logo on printed invoices & receipts'}</div>
                      </div>
                      <label class="toggle"><input type="checkbox" id="inv-print-logo" ${settings.print_logo!==false?'checked':''} onchange="if(document.getElementById('set-print-logo'))document.getElementById('set-print-logo').checked=this.checked;Admin.updateInvoiceDesignerPreview()"><span class="toggle-slider"></span></label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Card 3: Store Header & Contact Info -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>🏪</span>
                  ${isAR ? 'بيانات المتجر والترويسة والاتصال' : 'Store Information & Contact Details'}
                </div>
              </div>
              <div class="modal-body">
                <!-- Direct Store Identity Inputs -->
                <div class="grid grid-2" style="gap:10px;margin-bottom:12px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700">${isAR ? 'اسم المتجر (EN)' : 'Store Name (EN)'}</label>
                    <input type="text" class="form-control" id="inv-set-comp-name" value="${Utils.sanitize(settings.company_name||'')}" placeholder="${isAR ? 'مثال: AIZONE' : 'e.g. AIZONE'}" oninput="if(document.getElementById('set-company-name'))document.getElementById('set-company-name').value=this.value;Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700">${isAR ? 'اسم المتجر بالعربي (AR)' : 'Store Name (AR)'}</label>
                    <input type="text" class="form-control" id="inv-set-comp-name-ar" value="${Utils.sanitize(settings.company_name_ar==='المتجر'?'':(settings.company_name_ar||''))}" placeholder="${isAR ? 'مثال: أي زون (اختياري)' : 'Store Name Arabic'}" oninput="if(document.getElementById('set-company-name-ar'))document.getElementById('set-company-name-ar').value=this.value;Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700">📞 ${isAR ? 'رقم هاتف المتجر' : 'Store Phone Number'}</label>
                    <input type="text" class="form-control" id="inv-set-comp-phone" value="${Utils.sanitize(settings.company_phone||'')}" placeholder="${isAR ? 'مثال: +961 70 123 456' : 'e.g. +961 70 123 456'}" oninput="if(document.getElementById('set-company-phone'))document.getElementById('set-company-phone').value=this.value;Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700">📍 ${isAR ? 'عنوان / موقع المتجر' : 'Store Address / Location'}</label>
                    <input type="text" class="form-control" id="inv-set-comp-address" value="${Utils.sanitize(settings.company_address||'')}" placeholder="${isAR ? 'مثال: بيروت - شارع الحمرا' : 'e.g. Beirut, Hamra Street'}" oninput="if(document.getElementById('set-company-address'))document.getElementById('set-company-address').value=this.value;Admin.updateInvoiceDesignerPreview()">
                  </div>
                  <div class="form-group" style="margin:0;grid-column:1/-1">
                    <label class="form-label" style="font-size:0.78rem;font-weight:700">🏷️ ${isAR ? 'الرقم الضريبي / المالي (VAT ID)' : 'VAT / Tax Number'}</label>
                    <input type="text" class="form-control" id="inv-set-vat-num" value="${Utils.sanitize(settings.vat_number||'')}" placeholder="${isAR ? 'مثال: 12345678-01' : 'Tax ID'}" oninput="if(document.getElementById('set-vat-num'))document.getElementById('set-vat-num').value=this.value;Admin.updateInvoiceDesignerPreview()">
                  </div>
                </div>

                <div class="form-group" style="margin-bottom:12px">
                  <label class="form-label">${isAR ? 'محاذاة نصوص الترويسة' : 'Header Text Alignment'}</label>
                  <select class="form-control" id="inv-header-align" onchange="Admin.updateInvoiceDesignerPreview()">
                    <option value="left" ${settings.inv_header_align==='left'?'selected':''}>⬅️ ${isAR ? 'محاذاة تلقائية (طبيعية)' : 'Left / Natural'}</option>
                    <option value="center" ${settings.inv_header_align==='center'?'selected':''}>⏺️ ${isAR ? 'في المنتصف (Centered)' : 'Centered'}</option>
                    <option value="right" ${settings.inv_header_align==='right'?'selected':''}>➡️ ${isAR ? 'محاذاة يمين (Right)' : 'Right'}</option>
                  </select>
                </div>

                <div class="form-group" style="margin-bottom:12px">
                  <label class="form-label">${isAR ? 'شعار فرعي / وصف المتجر (Slogan)' : 'Store Slogan / Subtitle'}</label>
                  <input type="text" class="form-control" id="inv-custom-subtitle" value="${Utils.sanitize(settings.inv_custom_subtitle||'')}" placeholder="${isAR ? 'مثال: لخدمات الهواتف والإلكترونيات والصيانة' : 'e.g., Electronics & Mobile Repair Specialists'}" oninput="Admin.updateInvoiceDesignerPreview()">
                </div>

                <div style="font-weight:700;font-size:0.8rem;margin-bottom:8px;color:var(--text-muted)">${isAR ? 'عناصر الترويسة الظاهرة بالفاتورة:' : 'Visible Header Elements:'}</div>
                <div class="grid grid-2" style="gap:8px">
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-company-name" ${settings.inv_show_company_name!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'اسم المتجر' : 'Store Name'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-phone" ${settings.inv_show_phone!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'رقم الهاتف' : 'Phone Number'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-email" ${settings.inv_show_email!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'البريد الإلكتروني' : 'Email Address'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-address" ${settings.inv_show_address!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'العنوان' : 'Address'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-vat" ${settings.inv_show_vat!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'الرقم الضريبي / المالي' : 'VAT / Tax Number'}
                  </label>
                </div>
              </div>
            </div>

            <!-- Card 4: Document Columns & Content -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>📋</span>
                  ${isAR ? 'أعمدة ومحتويات الفاتورة الأساسية' : 'Invoice Body & Basic Columns'}
                </div>
              </div>
              <div class="modal-body">
                <div class="grid grid-2" style="gap:10px">
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-customer-info" ${settings.inv_show_customer_info!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'بيانات العميل' : 'Customer Info'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-salesperson" ${settings.inv_show_salesperson!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'اسم البائع / الكاشير' : 'Cashier / Salesperson'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-item-code" ${settings.inv_show_item_code!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'رمز الصنف / الباركود' : 'Item Code / SKU'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-discount-col" ${settings.inv_show_discount_col!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'عمود الخصم' : 'Discount Column'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer;grid-column:1/-1">
                    <input type="checkbox" id="inv-show-dual-currency" ${settings.inv_show_dual_currency!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'إظهار الإجمالي بالعملة الثانوية (سعر الصرف)' : 'Show Secondary Currency Total (Exchange Rate)'}
                  </label>
                </div>
              </div>
            </div>

            <!-- Card 4.5: Item Extra Details & Separator Merging -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>🏷️</span>
                  ${isAR ? 'مواصفات وبيانات الأصناف وطريقة الدمج بالفاتورة' : 'Item Info & Merging On Invoice'}
                </div>
              </div>
              <div class="modal-body">
                <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:10px">
                  ${isAR ? 'اختر المواصفات والبيانات الإضافية المراد إظهارها مع الصنف وكيفية دمجها مع اسم الصنف أو وضعها كسطر فرعي.' : 'Choose which item attributes to display on printed invoices and how they are merged/formatted.'}
                </div>

                <!-- Attributes Checkboxes -->
                <div style="font-weight:700;font-size:0.8rem;margin-bottom:8px;color:var(--text-primary)">
                  ${isAR ? 'المواصفات المراد إظهارها مع الصنف:' : 'Item Attributes to Display:'}
                </div>
                <div class="grid grid-3" style="gap:8px;margin-bottom:14px">
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-brand" ${settings.inv_item_show_brand ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'الماركة (Brand)' : 'Brand'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-model" ${settings.inv_item_show_model ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'الموديل (Model)' : 'Model'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-color" ${settings.inv_item_show_color ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'اللون (Color)' : 'Color'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-origin" ${settings.inv_item_show_origin ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'بلد الصنع (Origin)' : 'Made in'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-type" ${settings.inv_item_show_type ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'النوع (Type)' : 'Type'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-barcode" ${settings.inv_item_show_barcode ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'الباركود (Barcode)' : 'Barcode'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-weight" ${settings.inv_item_show_weight ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'الوزن (Weight)' : 'Weight'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-size" ${settings.inv_item_show_size ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'المقاس (Size)' : 'Size'}
                  </label>
                  <label style="display:flex;align-items:center;gap:6px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-item-show-notes" ${settings.inv_item_show_notes ? 'checked' : ''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'الوصف والملاحظات' : 'Notes / Desc'}
                  </label>
                </div>

                <!-- Display Mode, Layout & Separator -->
                <div class="grid grid-3" style="gap:12px;border-top:1px solid var(--border-color);padding-top:12px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-weight:700">${isAR ? 'تخطيط بنود الإيصال الحراري' : 'Receipt Items Layout'}</label>
                    <select class="form-control" id="inv-receipt-item-layout" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value="table" ${settings.inv_receipt_item_layout!=='stacked'?'selected':''}>📊 ${isAR ? 'جدول أعمدة (صنف | كمية | سعر | إجمالي)' : 'Columns Table (Item | Qty | Price | Total)'}</option>
                      <option value="stacked" ${settings.inv_receipt_item_layout==='stacked'?'selected':''}>📝 ${isAR ? 'سطرين متتاليين (مضغوط)' : '2-Line Stacked'}</option>
                    </select>
                  </div>

                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-weight:700">${isAR ? 'طريقة عرض المواصفات' : 'Display Placement'}</label>
                    <select class="form-control" id="inv-item-display-mode" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value="subline" ${settings.inv_item_display_mode==='subline'||!settings.inv_item_display_mode?'selected':''}>📝 ${isAR ? 'سطر فرعي أسفل اسم الصنف (Sub-line)' : 'Sub-line beneath Item Name'}</option>
                      <option value="merged" ${settings.inv_item_display_mode==='merged'?'selected':''}>🔗 ${isAR ? 'دمج في نفس سطر اسم الصنف (Inline)' : 'Merged inline with Name'}</option>
                      <option value="bracketed" ${settings.inv_item_display_mode==='bracketed'?'selected':''}>괄 ${isAR ? 'بين أقواس بجانب الاسم (Bracketed)' : 'Inside Brackets (Brand, Color...)'}</option>
                    </select>
                  </div>

                  <div class="form-group" style="margin:0">
                    <label class="form-label" style="font-weight:700">${isAR ? 'الفاصل بين المواصفات' : 'Separator Symbol'}</label>
                    <select class="form-control" id="inv-item-separator" onchange="Admin.updateInvoiceDesignerPreview()">
                      <option value=" - " ${settings.inv_item_separator===' - '||!settings.inv_item_separator?'selected':''}>- (Dash / شَرطة)</option>
                      <option value=" | " ${settings.inv_item_separator===' | '?'selected':''}>| (Pipe / خط عمودي)</option>
                      <option value=" • " ${settings.inv_item_separator===' • '?'selected':''}>• (Bullet / نقطة)</option>
                      <option value=" / " ${settings.inv_item_separator===' / '?'selected':''}>/ (Slash / سلاش)</option>
                      <option value=", " ${settings.inv_item_separator===', '?'selected':''}>, (Comma / فاصلة)</option>
                      <option value=" ; " ${settings.inv_item_separator===' ; '?'selected':''}>; (Semicolon / منقوطة)</option>
                    </select>
                  </div>
                </div>

              </div>
            </div>

            <!-- Card 5: Footer, Terms & Stamps -->
            <div class="card">
              <div class="card-header">
                <div class="card-title">
                  <span>🖋️</span>
                  ${isAR ? 'التذييل والشروط والأختام' : 'Footer, Terms & Signatures'}
                </div>
              </div>
              <div class="modal-body">
                <div class="form-group" style="margin-bottom:12px">
                  <label class="form-label">${isAR ? 'سياسة الإرجاع وشروط الفاتورة' : 'Terms & Return Policy'}</label>
                  <textarea class="form-control" id="inv-terms-text" rows="2" placeholder="${isAR ? 'اكتب شروط الاستبدال والاسترجاع...' : 'Enter terms & return policy...'}" oninput="Admin.updateInvoiceDesignerPreview()">${Utils.sanitize(settings.inv_terms_text||'')}</textarea>
                </div>

                <div class="form-group" style="margin-bottom:12px">
                  <label class="form-label">${isAR ? 'عبارة الشكر بالتذييل' : 'Footer Thank You Note'}</label>
                  <input type="text" class="form-control" id="inv-footer-note" value="${Utils.sanitize(settings.inv_footer_note||'')}" placeholder="${isAR ? 'شكراً لتعاملكم معنا ونسعد بخدمتكم' : 'Thank you for your business!'}" oninput="Admin.updateInvoiceDesignerPreview()">
                </div>

                <div class="grid grid-3" style="gap:8px">
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-stamp-signature" ${settings.inv_show_stamp_signature!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'أختام وتواقيع' : 'Stamp Boxes'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-qr" ${settings.inv_show_qr!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'رمز QR' : 'QR Code'}
                  </label>
                  <label style="display:flex;align-items:center;gap:8px;font-size:0.82rem;cursor:pointer">
                    <input type="checkbox" id="inv-show-barcode" ${settings.inv_show_barcode!==false?'checked':''} onchange="Admin.updateInvoiceDesignerPreview()">
                    ${isAR ? 'باركود الفاتورة' : 'Barcode'}
                  </label>
                </div>
              </div>
            </div>

            <!-- Action Buttons -->
            <div style="display:flex;gap:10px;margin-bottom:20px">
              <button class="btn btn-primary" style="flex:1" onclick="Admin.saveSettings()">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
                ${isAR ? 'حفظ إعدادات التصميم' : 'Save Invoice Design'}
              </button>
              <button class="btn btn-secondary" onclick="Admin.resetInvoiceDesignDefaults()">
                🔄 ${isAR ? 'استعادة الافتراضي' : 'Reset Defaults'}
              </button>
              <button class="btn btn-secondary" onclick="Admin.testPrintInvoiceDesign()">
                🖨️ ${isAR ? 'طباعة تجريبية' : 'Test Print'}
              </button>
            </div>

          </div>

          <!-- Right Column: Real-Time Live Preview -->
          <div style="flex:1.2;min-width:380px;position:sticky;top:20px">
            <div class="card" style="box-shadow:0 10px 25px -5px rgba(0,0,0,0.25)">
              <div class="card-header" style="display:flex;align-items:center;justify-content:space-between;padding:10px 16px">
                <div class="card-title" style="display:flex;align-items:center;gap:8px;font-size:0.95rem">
                  <span>👁️</span>
                  ${isAR ? 'معاينة حية ومباشرة للفاتورة' : 'Live Real-Time Preview'}
                </div>
                <!-- Preview Mode Switcher -->
                <div style="display:flex;background:var(--surface-2);border-radius:8px;padding:3px;gap:4px">
                  <button id="btn-preview-mode-a4" class="btn btn-sm ${_designerPreviewMode==='a4'?'btn-primary':'btn-ghost'}" style="font-size:0.75rem;padding:4px 10px" onclick="Admin.setDesignerPreviewMode('a4')">
                    📄 ${isAR ? 'فاتورة A4' : 'A4 Invoice'}
                  </button>
                  <button id="btn-preview-mode-thermal" class="btn btn-sm ${_designerPreviewMode==='thermal'?'btn-primary':'btn-ghost'}" style="font-size:0.75rem;padding:4px 10px" onclick="Admin.setDesignerPreviewMode('thermal')">
                    🧾 ${isAR ? 'إيصال 80mm' : '80mm Thermal'}
                  </button>
                </div>
              </div>
              <div class="modal-body" style="background:#475569;padding:16px;border-bottom-left-radius:var(--radius);border-bottom-right-radius:var(--radius);max-height:85vh;overflow-y:auto;display:flex;justify-content:center">
                <div id="inv-designer-preview-box" style="width:100%;max-width:650px;transition:all 0.2s ease">
                  <!-- Live Preview HTML injected dynamically -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- POS Cart Columns Configuration (Admin Settings) -->
      <div class="tab-content" id="tab-set-pos-cart">
        <div style="display:flex;gap:20px;flex-wrap:wrap">
          <!-- Left Column: Checkbox Options -->
          <div style="flex:1.1;min-width:340px">
            <div class="card mb-3" style="border-radius:14px;border:1px solid var(--border-color)">
              <div class="card-header" style="background:var(--surface-2);border-top-left-radius:14px;border-top-right-radius:14px">
                <div class="card-title" style="display:flex;align-items:center;gap:10px">
                  <span style="font-size:1.2rem">🛒</span>
                  <div>
                    <div style="font-weight:800;font-size:1rem">${isAR ? 'تخصيص أعمدة قائمة الفاتورة في نقطة البيع (POS)' : 'POS Cart & Invoice List Columns Setup'}</div>
                    <div style="font-size:0.75rem;font-weight:normal;color:var(--text-muted)">
                      ${isAR ? 'اختر الأعمدة المرئية للمستخدم/الكاشير في جدول سلة المبيعات والفاتورة (مثل السعر، التكلفة، الكمية، الإجمالي، إلخ)' : 'Choose which columns to show in the POS invoice items table (e.g. Unit Price, Cost, Qty, Total, etc.)'}
                    </div>
                  </div>
                </div>
              </div>
              <div class="modal-body">
                <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:12px">
                  
                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الصنف / الوصف' : 'Item Description'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'عمود أساسي ثابت دائماً' : 'Primary column (Always visible)'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-name" checked disabled><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'كود الصنف / الباركود' : 'Barcode / Item Code'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'رمز الصنف الفريد' : 'SKU or Barcode'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-code" ${settings.pos_cart_columns?.col_code ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الوحدة' : 'Unit of Measure'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'قطعة / كغ / كرتونة' : 'e.g. pcs, kg, box'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-unit" ${settings.pos_cart_columns?.col_unit ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'سعر البيع الإفرادي' : 'Unit Selling Price'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'سعر بيع القطعة الواحدة' : 'Price per unit'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-price" ${settings.pos_cart_columns?.col_price !== false ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem;color:var(--danger)">${isAR ? 'سعر التكلفة (للمسؤول)' : 'Item Cost Price'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'إظهار تكلفة الصنف للمحاسب' : 'Visible for accounting/margin check'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-cost" ${settings.pos_cart_columns?.col_cost ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الكمية' : 'Quantity Stepper'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'أزرار الزيادة والنقصان والكمية' : 'Qty input and +/- buttons'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-qty" ${settings.pos_cart_columns?.col_qty !== false ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الخصم %' : 'Discount %'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'نسبة الخصم لكل سطر' : 'Line item discount %'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-disc" ${settings.pos_cart_columns?.col_disc !== false ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الضريبة VAT' : 'VAT Rate'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'نسبة الضريبة أو إعفاء' : 'Tax rate or exemption'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-vat" ${settings.pos_cart_columns?.col_vat ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الإجمالي' : 'Line Total'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'إجمالي السطر الصافي' : 'Net amount after discount'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-total" ${settings.pos_cart_columns?.col_total !== false ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                  <div style="padding:10px 14px;background:var(--surface-2);border-radius:8px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-weight:700;font-size:0.85rem">${isAR ? 'الإجراءات' : 'Actions Column'}</div>
                      <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'أزرار الحذف ✕ والملاحظات 📝' : 'Remove & Note modal buttons'}</div>
                    </div>
                    <label class="toggle"><input type="checkbox" id="pos-col-actions" ${settings.pos_cart_columns?.col_actions !== false ? 'checked' : ''} onchange="Admin.updatePosCartColumnsPreview()"><span class="toggle-slider"></span></label>
                  </div>

                </div>

                <div style="display:flex;gap:10px;margin-top:20px">
                  <button class="btn btn-primary" onclick="Admin.saveSettings()">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
                    ${isAR ? 'حفظ إعدادات الأعمدة' : 'Save Columns Setup'}
                  </button>
                  <button class="btn btn-secondary" onclick="Admin.resetPosCartColumnsDefaults()">
                    🔄 ${isAR ? 'استعادة الافتراضي' : 'Reset Defaults'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Right Column: Live Table Preview in POS -->
          <div style="flex:1;min-width:320px">
            <div class="card" style="box-shadow:0 8px 24px rgba(0,0,0,0.18)">
              <div class="card-header" style="background:var(--surface-2)">
                <div class="card-title" style="font-size:0.92rem;display:flex;align-items:center;gap:6px">
                  <span>👁️</span> ${isAR ? 'معاينة مباشرة لشكل السلة في POS' : 'Live POS Cart Table Preview'}
                </div>
              </div>
              <div class="modal-body" style="padding:12px;background:var(--surface)">
                <div id="pos-cart-columns-live-preview" style="border:1px solid var(--border-color);border-radius:8px;overflow-x:auto">
                  <!-- Injected via updatePosCartColumnsPreview -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Item Notes & Modifiers -->
      <div class="tab-content" id="tab-set-modifiers">
        <div class="card mb-3" style="border-radius:14px;border:1px solid var(--border-color)">
          <div class="card-header" style="background:var(--surface-2);border-top-left-radius:14px;border-top-right-radius:14px">
            <div class="card-title" style="display:flex;align-items:center;gap:10px">
              <span style="font-size:1.2rem">📝</span>
              <div>
                <div style="font-weight:800;font-size:1rem">${settings.business_mode === 'retail' ? (isAR ? 'تخصيص الملاحظات السريعة للأصناف' : 'Custom Item Notes & Tags') : (isAR ? 'تخصيص الملاحظات السريعة وتفضيلات الأصناف' : 'Custom Item Notes & Quick Modifiers')}</div>
                <div style="font-size:0.75rem;font-weight:normal;color:var(--text-muted)">
                  ${isAR ? 'تحكم في الأزرار والخيارات السريعة التي تظهر في شاشة البيع POS عند النقر على أيقونة الملاحظات 📝 بجانب الصنف' : 'Configure quick preset tags that cashiers can tap to instantly attach notes to items in the POS cart.'}
                </div>
              </div>
            </div>
          </div>
          <div class="modal-body" style="padding:20px">
            <div style="max-width:760px">
              <!-- Retail Notes -->
              <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:12px">
                <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border-color);padding-bottom:10px">
                  <div style="display:flex;align-items:center;gap:8px">
                    <span style="font-size:1.2rem">🛒</span>
                    <div>
                      <div style="font-weight:800;font-size:0.95rem">${settings.business_mode === 'retail' ? (isAR ? 'الملاحظات والخيارات السريعة للصنف' : 'POS Quick Notes & Tags') : (isAR ? 'خيارات وملاحظات محلات التجزئة والسوبرماركت' : 'Retail & General Store Notes')}</div>
                      <div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'تظهر عند إضافة ملاحظة سريعة للصنف في شاشة البيع' : 'Used when attaching quick notes to items in POS'}</div>
                    </div>
                  </div>
                  <div style="display:flex;gap:6px">
                    <button class="btn btn-secondary btn-sm" onclick="Admin.resetModifiers('retail')" title="${isAR?'استعادة الافتراضي':'Reset to Defaults'}">
                      🔄 ${isAR ? 'الافتراضي' : 'Reset'}
                    </button>
                    <button class="btn btn-primary btn-sm" onclick="Admin.openModifierModal('retail')">
                      ➕ ${isAR ? 'إضافة خيار' : 'Add Note'}
                    </button>
                  </div>
                </div>
                <div id="retail-modifiers-list" style="display:flex;flex-direction:column;gap:8px;max-height:420px;overflow-y:auto;padding-right:4px">
                  <!-- Rendered dynamically -->
                </div>
              </div>

              ${settings.business_mode !== 'retail' ? `
              <!-- Restaurant Modifiers -->
              <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:12px;margin-top:16px">
                <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border-color);padding-bottom:10px">
                  <div style="display:flex;align-items:center;gap:8px">
                    <span style="font-size:1.2rem">🍽️</span>
                    <div>
                      <div style="font-weight:800;font-size:0.95rem">${isAR ? 'خيارات وتفضيلات المطبخ والمطعم' : 'Restaurant & Kitchen Modifiers'}</div>
                      <div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'تظهر عند إضافة طلبات المطبخ والمأكولات في شاشة البيع' : 'Used when adding kitchen and food notes in POS'}</div>
                    </div>
                  </div>
                  <div style="display:flex;gap:6px">
                    <button class="btn btn-secondary btn-sm" onclick="Admin.resetModifiers('restaurant')" title="${isAR?'استعادة الافتراضي':'Reset to Defaults'}">
                      🔄 ${isAR ? 'الافتراضي' : 'Reset'}
                    </button>
                    <button class="btn btn-primary btn-sm" onclick="Admin.openModifierModal('restaurant')">
                      ➕ ${isAR ? 'إضافة خيار' : 'Add Modifier'}
                    </button>
                  </div>
                </div>
                <div id="restaurant-modifiers-list" style="display:flex;flex-direction:column;gap:8px;max-height:420px;overflow-y:auto;padding-right:4px">
                  <!-- Rendered dynamically -->
                </div>
              </div>` : ''}
            </div>
          </div>
        </div>
      </div>

      <!-- Security & Returns -->
      <div class="tab-content" id="tab-set-security">
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <svg viewBox="0 0 24 24" fill="none" stroke="var(--warning)" stroke-width="2" width="18" height="18" style="margin-right:6px"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
              ${isAR ? 'أمان نقطة البيع وكلمة المرور الرئيسية (POS Security & Master Password)' : 'POS Security & Master Password'}
            </div>
          </div>
          <div class="modal-body">
            <div class="form-group" style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:var(--surface-2);border-radius:10px">
              <div>
                <div style="font-weight:700;font-size:0.9rem">${isAR ? 'اشتراط كلمة مرور المشرف للعمليات الإدارية' : 'Require Admin Password for Line Operations'}</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                  ${isAR ? 'عند التفعيل، سيطلب النظام كلمة مرور المشرف قبل تحويل الصنف إلى (إرجاع، تالف، أو هدية) أو تعديل أسعار الأصناف من الكاشير' : 'When enabled, POS prompts for Supervisor Master Password before changing items to Return, Damaged, or Gift'}
                </div>
              </div>
              <label class="toggle">
                <input type="checkbox" id="set-require-return-auth" ${settings.require_return_auth !== false ? 'checked' : ''}>
                <span class="toggle-slider"></span>
              </label>
            </div>
            <div class="form-group" style="margin-top:16px">
              <label class="form-label" style="font-weight:800">${isAR ? 'كلمة المرور الرئيسية للمشرف (Master Admin Password / PIN)' : 'Master Admin Security Password / PIN'}</label>
              <div style="display:flex;gap:8px;align-items:center">
                <input type="password" class="form-control" id="set-return-auth-pin" value="${Utils.sanitize(settings.pos_master_password || settings.return_auth_pin || '1234')}" style="max-width:260px;font-size:1.15rem;font-weight:800;letter-spacing:2px">
                <button type="button" class="btn btn-secondary btn-sm" onclick="const el=document.getElementById('set-return-auth-pin'); el.type = el.type==='password'?'text':'password';">👁️</button>
              </div>
              <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">
                ${isAR ? 'رمز PIN الافتراضي: 1234. يستخدمها المشرف لتفويض الكاشير عند تغيير الصنف إلى إرجاع، تالف، هدية، أو تعديل السعر.' : 'Default PIN: 1234. Used by supervisors to authorize cashiers for Returns, Damaged items, Gifts, and Price edits.'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Loyalty & Promotions -->
      <div class="tab-content" id="tab-set-loyalty">
        <!-- Loyalty Points Card -->
        <div class="card mb-4">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">⭐</span>
              ${isAR ? 'برنامج نقاط الولاء واستبدالها نقداً' : 'Customer Loyalty Points & Cash Redemption'}
            </div>
          </div>
          <div class="modal-body">
            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:var(--surface-2);border-radius:10px;margin-bottom:16px;border:1px solid var(--border-color)">
              <div>
                <div style="font-weight:700;font-size:0.9rem">${isAR ? 'تفعيل نظام نقاط الولاء للعملاء' : 'Enable Customer Loyalty Points System'}</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                  ${isAR ? 'يكتسب العملاء نقاطاً تلقائياً عند الشراء ويمكنهم استبدالها بخصم نقدي مباشر في الفاتورة' : 'Customers automatically accumulate points on purchase and can redeem them for instant cash discounts'}
                </div>
              </div>
              <label class="toggle">
                <input type="checkbox" id="set-loyalty-enabled" ${settings.loyalty_enabled ? 'checked' : ''}>
                <span class="toggle-slider"></span>
              </label>
            </div>

            <div class="grid grid-3">
              <div class="form-group">
                <label class="form-label">${isAR ? 'معدل اكتساب النقاط' : 'Earning Rate'}</label>
                <div class="input-group">
                  <input type="number" class="form-control" id="set-loyalty-earn-rate" value="${settings.loyalty_earn_rate || 1}" min="0.1" step="0.1">
                  <div class="input-group-addon">${isAR ? 'نقطة / 1$' : 'Pts / $1'}</div>
                </div>
                <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">${isAR ? 'مثال: نقطة واحدة لكل دولار يتم شراؤه' : 'Example: 1 Point for every $1 spent'}</div>
              </div>

              <div class="form-group">
                <label class="form-label">${isAR ? 'معدل الاستبدال النقدي' : 'Redemption Cash Value'}</label>
                <div class="input-group">
                  <input type="number" class="form-control" id="set-loyalty-redeem-rate" value="${settings.loyalty_redeem_rate || 100}" min="1">
                  <div class="input-group-addon">${isAR ? 'نقطة = 1$' : 'Pts = $1'}</div>
                </div>
                <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">${isAR ? 'مثال: 100 نقطة تعادل 1.00$ خصم نقدي' : 'Example: 100 points = $1.00 instant cash discount'}</div>
              </div>

              <div class="form-group">
                <label class="form-label">${isAR ? 'الحد الأدنى للاستبدال' : 'Min Points to Redeem'}</label>
                <div class="input-group">
                  <input type="number" class="form-control" id="set-loyalty-min-redeem" value="${settings.loyalty_min_redeem || 50}" min="1">
                  <div class="input-group-addon">${isAR ? 'نقطة' : 'Points'}</div>
                </div>
                <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">${isAR ? 'الحد الأدنى لفتح إمكانية الخصم' : 'Threshold required before customer can redeem'}</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Dynamic Promotions & Happy Hour Card -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">🔥</span>
              ${isAR ? 'عروض التخفيضات التلقائية وساعات التخفيض (Happy Hour)' : 'Dynamic Automated Deals & Happy Hour Engine'}
            </div>
          </div>
          <div class="modal-body">
            
            <!-- Happy Hour -->
            <div style="padding:14px;background:var(--surface-2);border-radius:10px;margin-bottom:16px;border:1px solid var(--border-color)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">⏰ ${isAR ? 'خصم ساعات السعادة (Happy Hour Auto-Discount)' : 'Happy Hour Automated Discount'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'يطبق خصماً تلقائياً على كل السلة خلال فترات زمنية محددة يومياً' : 'Automatically applies percentage discount during specified daily hours'}</div>
                </div>
                <label class="toggle">
                  <input type="checkbox" id="set-promo-happy-hour-enabled" ${settings.promo_happy_hour_enabled ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                </label>
              </div>

              <div class="grid grid-3">
                <div class="form-group">
                  <label class="form-label">${isAR ? 'نسبة الخصم %' : 'Discount Percentage %'}</label>
                  <input type="number" class="form-control" id="set-promo-happy-hour-pct" value="${settings.promo_happy_hour_pct || 10}" min="1" max="90">
                </div>
                <div class="form-group">
                  <label class="form-label">${isAR ? 'من الساعة' : 'From Time'}</label>
                  <input type="time" class="form-control" id="set-promo-happy-hour-start" value="${settings.promo_happy_hour_start || '14:00'}">
                </div>
                <div class="form-group">
                  <label class="form-label">${isAR ? 'إلى الساعة' : 'To Time'}</label>
                  <input type="time" class="form-control" id="set-promo-happy-hour-end" value="${settings.promo_happy_hour_end || '17:00'}">
                </div>
              </div>
            </div>

            <!-- Spend Threshold -->
            <div style="padding:14px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">🛍️ ${isAR ? 'خصم تلقائي عند تجاوز حد الفاتورة (Spend & Save)' : 'Spend Threshold Auto-Discount'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'خصم تشجيعي تلقائي إذا تجاوز إجمالي السلة مبلغاً معيناً' : 'Instant bonus discount when invoice subtotal exceeds threshold'}</div>
                </div>
                <label class="toggle">
                  <input type="checkbox" id="set-promo-threshold-enabled" ${settings.promo_threshold_enabled ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                </label>
              </div>

              <div class="grid grid-2">
                <div class="form-group">
                  <label class="form-label">${isAR ? 'إذا تجاوزت الفاتورة مبلغ ($)' : 'If Invoice Exceeds ($)'}</label>
                  <input type="number" class="form-control" id="set-promo-threshold-amt" value="${settings.promo_threshold_amt || 100}" min="10">
                </div>
                <div class="form-group">
                  <label class="form-label">${isAR ? 'يحصل العميل على خصم %' : 'Apply Discount %'}</label>
                  <input type="number" class="form-control" id="set-promo-threshold-pct" value="${settings.promo_threshold_pct || 5}" min="1" max="50">
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- WhatsApp & Telegram Notifications -->
      <div class="tab-content" id="tab-set-notifications">
        <div class="grid grid-2" style="gap:20px">
          <!-- WhatsApp Section -->
          <div class="card">
            <div class="card-header">
              <div class="card-title">
                <span style="font-size:1.2rem">💬</span>
                ${isAR ? 'إعدادات ورسائل واتساب (WhatsApp Store & Alerts)' : 'WhatsApp Store & Messaging Settings'}
              </div>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <label class="form-label">${isAR ? 'رقم واتساب المتجر (المرسل)' : 'Store Official WhatsApp / Phone'}</label>
                <input type="text" class="form-control" id="set-company-phone-wa" value="${Utils.sanitize(settings.company_phone||'')}" placeholder="e.g. +961 71 193 093" oninput="document.getElementById('set-company-phone').value=this.value">
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">
                  ${isAR ? 'يظهر هذا الرقم على الفواتير والإيصالات لتمكين العملاء من التواصل المباشر مع المتجر.' : 'Displayed on invoices & receipts for customer inquiries.'}
                </div>
              </div>

              <div class="form-group">
                <label class="form-label">${isAR ? 'رقم واتساب المدير / المالك (لاستلام التقرير اليومي)' : 'Owner / Manager WhatsApp (Receives Daily Closing Report)'}</label>
                <input type="text" class="form-control" id="set-owner-whatsapp-phone" value="${Utils.sanitize(settings.owner_whatsapp_phone||'')}" placeholder="e.g. +961 71 000 000">
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">
                  ${isAR ? 'الرقم الذي سيتم إرسال ملخص إغلاق اليومية والأرباح والمبيعات إليه بنقرة واحدة.' : 'Pre-fills the recipient when clicking Send Daily Closing Summary in Reports.'}
                </div>
              </div>

              <div class="form-group">
                <label class="form-label">${isAR ? 'قالب رسالة الفاتورة الإلكترونية للعميل' : 'Customer E-Invoice WhatsApp Template'}</label>
                <textarea class="form-control" id="set-whatsapp-invoice-template" rows="3" placeholder="e.g. 🧾 {company_name} — Invoice #{invoice_no}\n📅 Date: {date}\n💵 Total: {total}\nThank you!">${settings.whatsapp_invoice_template||''}</textarea>
                <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">
                  ${isAR ? 'المتغيرات المتاحة: {company_name}, {invoice_no}, {date}, {total}, {customer_name}' : 'Available tags: {company_name}, {invoice_no}, {date}, {total}, {customer_name}'}
                </div>
              </div>
            </div>
          </div>

          <!-- Telegram Bot Section -->
          <div class="card">
            <div class="card-header">
              <div class="card-title">
                <span style="font-size:1.2rem">🤖</span>
                ${isAR ? 'إشعارات بوت تيليجرام التلقائية (Telegram Bot)' : 'Automated Telegram Bot Alerts'}
              </div>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <label class="form-label" style="display:flex;justify-content:space-between;align-items:center">
                  <span>${isAR ? 'رمز توكن البوت (Bot API Token)' : 'Telegram Bot API Token'}</span>
                  <a href="https://t.me/BotFather" target="_blank" class="badge badge-primary" style="text-decoration:none;font-size:0.7rem">🤖 @BotFather</a>
                </label>
                <input type="text" class="form-control" id="set-telegram-bot-token" value="${Utils.sanitize(settings.telegram_bot_token||'')}" placeholder="e.g. 7123456789:AAHfk39...">
              </div>

              <div class="form-group">
                <label class="form-label" style="display:flex;justify-content:space-between;align-items:center">
                  <span>${isAR ? 'معرف المحادثة أو القناة (Chat ID)' : 'Telegram Chat ID / Group ID'}</span>
                  <a href="https://t.me/userinfobot" target="_blank" class="badge badge-secondary" style="text-decoration:none;font-size:0.7rem">🆔 @userinfobot</a>
                </label>
                <input type="text" class="form-control" id="set-telegram-chat-id" value="${Utils.sanitize(settings.telegram_chat_id||'')}" placeholder="e.g. 123456789 or -100123456789">
              </div>

              <div class="form-group" style="padding:12px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color);margin-bottom:14px">
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div>
                    <div style="font-weight:700;font-size:0.85rem">${isAR ? 'إرسال التقرير اليومي تلقائياً عند إغلاق الوردية' : 'Auto-Send Daily Report on Shift Close'}</div>
                    <div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'يرسل ملخص الأرباح والمبيعات والمخزون مباشرة للبوت' : 'Automatically pushes sales summary to your Telegram'}</div>
                  </div>
                  <label class="toggle">
                    <input type="checkbox" id="set-telegram-auto-send" ${settings.telegram_auto_send ? 'checked' : ''}>
                    <span class="toggle-slider"></span>
                  </label>
                </div>
              </div>

              <div style="display:flex;gap:10px">
                <button type="button" class="btn btn-secondary btn-sm" onclick="Admin.testTelegramAlert()" style="display:flex;align-items:center;gap:6px">
                  <span>🔔</span> ${isAR ? 'تجربة إرسال رسالة تجريبية' : 'Test Telegram Connection'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- General -->
      <div class="tab-content" id="tab-set-general">
        <!-- Terminal Warehouse Assignment Card -->
        <div class="card mb-3" style="border:1px solid var(--primary);box-shadow:0 4px 14px rgba(239,68,68,0.06)">
          <div class="card-header" style="background:rgba(239,68,68,0.04)">
            <div class="card-title">
              <span style="font-size:1.25rem">🏬</span>
              <strong>${isAR ? 'الفرع والمستودع الافتراضي للبيع (Default POS Store / Branch)' : 'Assigned Store / Warehouse for this Computer'}</strong>
            </div>
            <span class="badge badge-primary" style="font-size:0.75rem">${isAR ? 'تخصيص نقطة البيع' : 'Terminal Assignment'}</span>
          </div>
          <div class="modal-body">
            <div style="background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:10px;padding:14px;margin-bottom:18px;display:flex;gap:12px;align-items:center">
              <span style="font-size:1.6rem">🏪</span>
              <div style="font-size:0.83rem;color:var(--text-primary)">
                <strong>${isAR ? 'ربط هذا الجهاز بالفرع أو المستودع المطلوب:' : 'Assign this computer to a specific Store/Branch:'}</strong><br>
                <span style="color:var(--text-muted)">
                  ${isAR ? 'المبيعات والفواتير التي تتم عبر شاشة الكاشير في هذا الجهاز سيتم خصم كمياتها وحركتها تلقائياً من مخزون الفرع المختار هنا.' : 'Sales made on this POS station will automatically deduct stock from the selected store/branch.'}
                </span>
              </div>
            </div>
            <div class="form-group" style="max-width:460px;margin-bottom:0">
              <label class="form-label" style="font-weight:700">${isAR ? 'اختر الفرع / المستودع لهذا الجهاز *' : 'Active Store / Warehouse for this Terminal *'}</label>
              <select class="form-control" id="set-pos-warehouse-id" style="font-weight:800;font-size:1rem;height:42px;border-radius:8px">
                ${allWarehouses.map(w => `
                  <option value="${w.id}" ${parseInt(settings.pos_warehouse_id) === parseInt(w.id) ? 'selected' : ''}>
                    🏬 ${isAR ? (w.name_ar || w.name) : (w.name || w.name_ar)} (${w.code || 'WH'}) ${w.is_default ? (isAR ? '— الافتراضي' : '— Default') : ''}
                  </option>
                `).join('')}
              </select>
            </div>
          </div>
        </div>

        <!-- Font & UI Scale Card -->
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.2rem">🔍</span>
              ${isAR ? 'حجم خط الواجهة والنظام (Font & UI Scale %)' : 'Application Font & UI Scale (%)'}
            </div>
            <span id="font-scale-display-badge" class="badge badge-primary" style="font-size:0.95rem;font-weight:900;padding:6px 14px;border-radius:20px">
              ${settings.app_font_scale || 100}%
            </span>
          </div>
          <div class="modal-body">
            <div style="background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:10px;padding:14px;margin-bottom:18px;display:flex;gap:12px;align-items:center">
              <span style="font-size:1.6rem">📏</span>
              <div style="font-size:0.83rem;color:var(--text-primary)">
                <strong>${isAR ? 'تعديل مقاس وحجم نصوص البرنامج بالكامل:' : 'Adjust Global Font & UI Size Proportionally:'}</strong><br>
                <span style="color:var(--text-muted)">
                  ${isAR ? 'يمكنك زيادة أو تصغير حجم الخط كنسبة مئوية (%) لتسهيل القراءة لمستخدمي الشاشات اللمسية وتناسب كافة الشاشات، مع الحفاظ التام على تناسق القوائم والتصميم.' : 'Scale all fonts and text across the entire POS as a percentage (%) for maximum readability on touch monitors and high-resolution displays.'}
                </span>
              </div>
            </div>

            <div class="form-group" style="margin-bottom:16px">
              <div style="display:flex;align-items:center;gap:14px">
                <span style="font-size:0.85rem;font-weight:800;color:var(--text-muted)">80%</span>
                <input type="range" id="set-font-scale-range" min="80" max="140" step="5" value="${settings.app_font_scale || 100}" class="form-range" style="flex:1;cursor:pointer;height:8px;accent-color:var(--primary)" oninput="if(window.App&&App.setFontScale)App.setFontScale(this.value); const b=document.getElementById('font-scale-display-badge'); if(b) b.textContent=this.value+'%';">
                <span style="font-size:0.85rem;font-weight:800;color:var(--text-muted)">140%</span>
              </div>
            </div>

            <!-- Quick Preset Buttons -->
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.App&&App.setFontScale)App.setFontScale(85); document.getElementById('set-font-scale-range').value=85; document.getElementById('font-scale-display-badge').textContent='85%';">85% ${isAR?'صغير':'Compact'}</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.App&&App.setFontScale)App.setFontScale(95); document.getElementById('set-font-scale-range').value=95; document.getElementById('font-scale-display-badge').textContent='95%';">95% ${isAR?'متوسط':'Medium'}</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.App&&App.setFontScale)App.setFontScale(100); document.getElementById('set-font-scale-range').value=100; document.getElementById('font-scale-display-badge').textContent='100%';">100% ${isAR?'الافتراضي':'Default'}</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.App&&App.setFontScale)App.setFontScale(110); document.getElementById('set-font-scale-range').value=110; document.getElementById('font-scale-display-badge').textContent='110%';">110% ${isAR?'كبير مريح':'Comfortable'}</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.App&&App.setFontScale)App.setFontScale(120); document.getElementById('set-font-scale-range').value=120; document.getElementById('font-scale-display-badge').textContent='120%';">120% ${isAR?'كبير جداً':'Large'}</button>
              <button type="button" class="btn btn-secondary btn-sm" onclick="if(window.App&&App.setFontScale)App.setFontScale(130); document.getElementById('set-font-scale-range').value=130; document.getElementById('font-scale-display-badge').textContent='130%';">130% ${isAR?'شاشات اللمس':'Touch Kiosk'}</button>
            </div>
          </div>
        </div>

        <!-- UI & Header Elements Visibility Card (Integrated directly into General) -->
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.2rem">👁️</span>
              ${isAR ? 'إدارة أزرار الشريط العلوي وخيارات الدفع (UI & Header Tabs)' : 'Header Tabs & Feature Visibility Management'}
            </div>
          </div>
          <div class="modal-body">
            <div style="background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:10px;padding:14px;margin-bottom:18px;display:flex;gap:12px;align-items:center">
              <span style="font-size:1.6rem">🎛️</span>
              <div style="font-size:0.83rem;color:var(--text-primary)">
                <strong>${isAR ? 'تخصيص واجهة المستخدم وشاشة الكاشير:' : 'Customize Staff Interface & Header Controls:'}</strong><br>
                <span style="color:var(--text-muted)">
                  ${isAR ? 'يمكن للمدير إظهار أو إخفاء أي زر من الشريط العلوي وشاشة الدفع لتسهيل العمل على الموظفين وإخفاء الميزات غير المستخدمة.' : 'Enable or disable any topbar shortcut or checkout payment method to tailor the interface for your cashiers.'}
                </span>
              </div>
            </div>

            <div class="grid grid-2" style="gap:14px">
              <!-- AI Copilot -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">🤖 ${isAR ? 'زر المساعد الذكي (AI Copilot)' : 'AI Business Copilot'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار زر Copilot في الشريط العلوي' : 'Show AI assistant launcher in topbar'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-ai-copilot" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_ai_copilot !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Mobile App -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">📱 ${isAR ? 'تطبيق الموبايل والويتر (Mobile App)' : 'Mobile Waiter & QR App'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار زر تطبيق الهاتف في الشريط العلوي' : 'Show Mobile App shortcut in topbar'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-mobile-app" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_mobile_app !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Online Store Orders -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">🛍️ ${isAR ? 'طلبات المتجر الإلكتروني (Online Orders)' : 'Online Orders & Chime Alert'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'زر جرس وإشعارات الطلبات الإلكترونية' : 'Show online orders notification button & chime in header'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-online-orders" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_online_orders !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Price Checker -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">🔍 ${isAR ? 'فاحص الأسعار للزبائن (Price Check)' : 'Customer Price Checker Shortcut'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار زر فتح شاشة فاحص الأسعار' : 'Show Price Checker kiosk button in topbar'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-price-check" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_price_check !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Online Payment in Checkout -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">💳 ${isAR ? 'الدفع بالبطاقة / الإلكتروني (Card Payment)' : 'Card / Online Payment Option'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار زر الدفع بالبطاقة في نافذة دفع الكاشير' : 'Show Card/Online payment button in checkout modal'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-card-payment" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_card_payment !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Camera Mobile Scan -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">📷 ${isAR ? 'كاميرا مسح الباركود (Camera Scan)' : 'Camera Barcode Scanner'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار أيقونة كاميرا مسح الباركود للأصناف' : 'Show camera scanner icon on search inputs'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-mobile-scan" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_mobile_scan !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Dollar Exchange Rate -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">💵 ${isAR ? 'بادج سعر الصرف (Exchange Rate)' : 'Dollar Exchange Rate Badge'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار سعر صرف الدولار الحي في الشريط العلوي' : 'Show live currency exchange rate badge in header'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-exchange-rate" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_exchange_rate !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>

              <!-- Live Clock -->
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">⏰ ${isAR ? 'الساعة والتاريخ المباشر (Clock & Date)' : 'Live Clock & Date Pill'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار الساعة والتاريخ في الشريط العلوي' : 'Show live time & date clock in header'}</div>
                </div>
                <label class="toggle"><input type="checkbox" id="set-ui-clock" onchange="Admin.handleLiveUiToggle()" ${settings.ui_visibility?.show_clock !== false ? 'checked' : ''}><span class="toggle-slider"></span></label>
              </div>
            </div>
          </div>
        </div>

        <!-- General System Preferences Card -->
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.15rem">⚙️</span>
              ${isAR ? 'تفضيلات وسلوك النظام' : 'General System Preferences'}
            </div>
          </div>
          <div class="modal-body">
            <div class="form-group" style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:var(--surface-2);border-radius:10px;margin-bottom:16px">
              <div>
                <div style="font-weight:700;font-size:0.9rem">${isAR ? 'السماح بالبيع عند عدم توفر كمية (البيع بالسالب)' : 'Allow Sales When Out of Stock (Negative Stock)'}</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                  ${isAR ? 'عند التفعيل، يمكن بيع الأصناف النافدة من المخزون وتصبح كميتها بالسالب' : 'When enabled, POS can sell items with 0 or negative stock quantity'}
                </div>
              </div>
              <label class="toggle">
                <input type="checkbox" id="set-allow-negative-stock" ${settings.allow_negative_stock ? 'checked' : ''} onchange="DB.setSetting('allow_negative_stock', this.checked)">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <div style="display:flex;align-items:center;justify-content:space-between;padding:14px;background:var(--surface-2);border-radius:10px;margin-bottom:12px;border:1px solid var(--border-color)">
              <div>
                <div style="font-weight:700;font-size:0.9rem">${isAR ? 'إظهار الزر العائم للمساعد الذكي في أسفل الشاشة' : 'Show Floating AI Assistant Bubble on Screen'}</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                  ${isAR ? 'عند الإلغاء، سيتم إخفاء الأيقونة العائمة في الأسفل ويمكن استخدام الزر العلوي 🤖' : 'When disabled, hides the bottom floating icon. You can still access AI Copilot from the topbar button 🤖'}
                </div>
              </div>
              <label class="toggle">
                <input type="checkbox" id="set-show-ai-bubble" ${settings.show_ai_bubble !== false ? 'checked' : ''}>
                <span class="toggle-slider"></span>
              </label>
            </div>

            <div class="form-group">
              <label class="form-label">${isAR?'تنبيه المخزون المنخفض':'Low Stock Alerts'}</label>
              <label class="toggle" style="margin-top:8px">
                <input type="checkbox" id="set-low-stock-alert" ${settings.low_stock_alert?'checked':''}>
                <span class="toggle-slider"></span>
              </label>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'اللغة':'Language'}</label>
              <select class="form-control" style="max-width:200px" onchange="i18n.setLang(this.value)">
                <option value="en" ${i18n.getLang()==='en'?'selected':''}>English</option>
                <option value="ar" ${i18n.getLang()==='ar'?'selected':''}>العربية</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'احتفاظ سجل التدقيق (بالأيام)':'Audit Log Retention (Days)'}</label>
              <input type="number" class="form-control" id="set-audit-retention" value="${settings.audit_retention_days || '30'}" style="max-width:200px">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'المظهر':'Theme'}</label>
              <select class="form-control" style="max-width:240px" onchange="App.setTheme(this.value); DB.setSetting('theme', this.value)">
                <option value="dark" ${document.documentElement.dataset.theme==='dark'?'selected':''}>🌙 ${isAR?'داكن ملكي (Dark Obsidian)':'Dark Obsidian'}</option>
                <option value="light" ${document.documentElement.dataset.theme==='light'?'selected':''}>☀️ ${isAR?'فاتح ناصع (Pure White Retail)':'Pure White Retail'}</option>
                <option value="gray" ${document.documentElement.dataset.theme==='gray'||document.documentElement.dataset.theme==='white-gray'?'selected':''}>🏢 ${isAR?'رمادي هادئ (Slate Gray)':'Slate Gray'}</option>
                <option value="ocean" ${document.documentElement.dataset.theme==='ocean'?'selected':''}>🌊 ${isAR?'سماوي نهاري (Sky Blue Ocean)':'Sky Blue Ocean'}</option>
                <option value="emerald" ${document.documentElement.dataset.theme==='emerald'?'selected':''}>🌿 ${isAR?'أخضر زمردي منعش (Sage Mint)':'Sage Mint Fresh'}</option>
                <option value="warm" ${document.documentElement.dataset.theme==='warm'?'selected':''}>🏜️ ${isAR?'بيج كشمير دافئ (Warm Sand)':'Warm Sand Ivory'}</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- License -->
      <div class="tab-content" id="tab-set-license">
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.1rem">🔑</span>
              ${isAR ? 'ترخيص ومصادقة البرنامج' : 'Software Licensing & Security'}
            </div>
          </div>
          <div class="modal-body">
            <div id="license-status-card" style="margin-bottom:20px"></div>
            
            <div class="grid grid-2" style="gap:20px">
              <div style="background:var(--surface-2);border-radius:10px;padding:16px;border:1px solid var(--border-color)">
                <div style="font-weight:700;font-size:0.9rem;margin-bottom:8px">${isAR ? '1. استخراج طلب الترخيص' : '1. Generate License Request'}</div>
                <p style="font-size:0.75rem;color:var(--text-muted);margin-bottom:12px">
                  ${isAR ? 'قم بتنزيل ملف طلب الترخيص (.req) وأرسله للمطور للحصول على التنشيط.' : 'Download the request file (.req) and send it to your developer to generate an activation key.'}
                </p>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:12px;font-family:monospace">
                  <strong>Machine ID:</strong> <span id="license-mach-id-display">...</span>
                </div>
                <button class="btn btn-secondary btn-sm" onclick="License.generateRequestFile()">
                  📥 ${isAR ? 'تنزيل طلب الترخيص' : 'Download Request'}
                </button>
              </div>

              <div style="background:var(--surface-2);border-radius:10px;padding:16px;border:1px solid var(--border-color)">
                <div style="font-weight:700;font-size:0.9rem;margin-bottom:8px">${isAR ? '2. تنشيط الترخيص (ملف أو لصق نص)' : '2. Activate License (File or Text)'}</div>
                <p style="font-size:0.75rem;color:var(--text-muted);margin-bottom:12px">
                  ${isAR ? 'يمكنك رفع ملف (.lic) أو لصق نص كود الترخيص مباشرة من واتساب/الإيميل:' : 'Upload your (.lic) file OR paste the license key text directly from WhatsApp/Email:'}
                </p>
                
                <div style="display:flex;flex-direction:column;gap:10px">
                  <div>
                    <label class="form-label" style="font-size:0.75rem;font-weight:700">${isAR ? 'الخيار الأول: رفع ملف الترخيص (.lic)' : 'Option A: Upload License File (.lic)'}</label>
                    <div style="display:flex;gap:8px">
                      <input type="file" id="lic-file-input" accept=".lic" class="form-control form-control-sm" style="flex:1">
                      <button class="btn btn-primary btn-sm" onclick="License.activateLicense('lic-file-input')">
                        ⚡ ${isAR ? 'تنشيط الملف' : 'Activate File'}
                      </button>
                    </div>
                  </div>

                  <div style="text-align:center;font-size:0.75rem;color:var(--text-muted);font-weight:700;margin:2px 0">
                    ── ${isAR ? 'أو' : 'OR'} ──
                  </div>

                  <div>
                    <label class="form-label" style="font-size:0.75rem;font-weight:700">${isAR ? 'الخيار الثاني: لصق رمز الترخيص (نص)' : 'Option B: Paste License Key Text'}</label>
                    <textarea id="lic-text-input" class="form-control form-control-sm" placeholder="${isAR ? 'الصق نص كود الترخيص هنا...' : 'Paste base64 license code here...'}" style="font-family:monospace;font-size:0.75rem;height:60px;margin-bottom:8px"></textarea>
                    <button class="btn btn-success btn-sm" onclick="License.activateLicenseText(document.getElementById('lic-text-input').value)">
                      🔑 ${isAR ? 'تنشيط من النص الملصوق' : 'Activate from Pasted Text'}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- 3. Developer License Generator Tool -->
            <div style="margin-top:20px;padding:16px;background:rgba(239,68,68,0.05);border:1px dashed rgba(239,68,68,0.3);border-radius:10px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
              <div>
                <div style="font-weight:800;font-size:0.9rem;color:var(--text-primary);display:flex;align-items:center;gap:8px">
                  <span>🛠️</span> ${isAR ? 'أداة إنشاء التراخيص للمطورين (License Keygen)' : 'Developer License Generator Tool (Keygen)'}
                </div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                  ${isAR ? 'يمكنك إنشاء ملفات وتراخيص .lic لعملائك وتحديد نمط التشغيل (مطاعم / تجزئة / شامل)' : 'Generate cryptographically signed .lic files or base64 keys with custom validity and business mode.'}
                </div>
              </div>
              <div style="display:flex;gap:8px">
                <a href="license_generator.html" target="_blank" class="btn btn-outline btn-sm" style="font-weight:800;border-radius:8px">
                  🚀 ${isAR ? 'فتح أداة إنشاء التراخيص' : 'Launch License Generator'}
                </a>
              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- Price Checker Kiosk Settings Tab -->
      <div class="tab-content" id="tab-set-price-checker">
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.2rem">🔍</span>
              ${isAR ? 'إعدادات شاشة فاحص الأسعار للزبائن (Price Checker Kiosk)' : 'Customer Price Checker Kiosk Settings'}
            </div>
            <div style="display:flex;gap:8px">
              <button class="btn btn-primary btn-sm" onclick="window.open('price_checker.html', '_blank')">
                🖥️ ${isAR ? 'فتح شاشة الزبائن' : 'Open Kiosk Screen'}
              </button>
              <button class="btn btn-secondary btn-sm" onclick="window.open('mobile_scan.html', '_blank', 'width=420,height=750')">
                📱 ${isAR ? 'ماسح الموبايل' : 'Mobile Scanner'}
              </button>
            </div>
          </div>
          <div class="modal-body">
            <div style="background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:10px;padding:14px;margin-bottom:18px;display:flex;gap:12px;align-items:center">
              <span style="font-size:1.6rem">💡</span>
              <div style="font-size:0.83rem;color:var(--text-primary)">
                <strong>${isAR ? 'شاشة فحص الأسعار الذاتية للعملاء:' : 'Customer Self-Service Price Verifier:'}</strong><br>
                <span style="color:var(--text-muted)">
                  ${isAR ? 'يمكن تخصيص شاشة صغيرة أو تابلت مع قارئ باركود ليمسح العميل أي صنف ويعرف سعره مباشرة، مع حماية تامة لبيانات التكلفة والأرباح.' : 'Set up a dedicated small screen or tablet with a barcode scanner for customers to check prices. Confidential cost/margin data is strictly hidden.'}
                </span>
              </div>
            </div>

            <div class="grid grid-2" style="gap:16px;margin-bottom:18px">
              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.88rem">${isAR ? 'عرض صورة المنتج' : 'Show Product Image'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار صورة الصنف عند المسح' : 'Display item photo when scanned'}</div>
                </div>
                <label class="toggle">
                  <input type="checkbox" id="set-pc-show-image" ${settings.price_checker_show_image ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                </label>
              </div>

              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.88rem">${isAR ? 'عرض السعر بالعملة الثانوية' : 'Show Secondary Currency Price'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار السعر بالدولار والليرة معاً' : 'Display primary and secondary currency prices'}</div>
                </div>
                <label class="toggle">
                  <input type="checkbox" id="set-pc-show-sec-currency" ${settings.price_checker_show_sec_currency ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                </label>
              </div>

              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.88rem">${isAR ? 'عرض حالة التوفر (متوفر / غير متوفر)' : 'Show Stock Status (In/Out of Stock)'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار شارة التوفر دون كشف الكمية الفعلية' : 'Display In-Stock badge without revealing exact quantity'}</div>
                </div>
                <label class="toggle">
                  <input type="checkbox" id="set-pc-show-stock-status" ${settings.price_checker_show_stock_status ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                </label>
              </div>

              <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;background:var(--surface-2);border-radius:10px;border:1px solid var(--border-color)">
                <div>
                  <div style="font-weight:700;font-size:0.88rem">${isAR ? 'عرض رقم الباركود وكود الصنف' : 'Show Barcode & Item Code'}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إظهار كود الصنف والباركود أسفل الاسم' : 'Show product barcode & code tag'}</div>
                </div>
                <label class="toggle">
                  <input type="checkbox" id="set-pc-show-barcode" ${settings.price_checker_show_barcode ? 'checked' : ''}>
                  <span class="toggle-slider"></span>
                </label>
              </div>
            </div>

            <div class="grid grid-3" style="gap:16px">
              <div class="form-group">
                <label class="form-label">${isAR ? 'مدة العودة التلقائية للشاشة الترحيبية (ثوانٍ)' : 'Auto-Reset Idle Timeout (Seconds)'}</label>
                <input type="number" class="form-control" id="set-pc-auto-reset" value="${settings.price_checker_auto_reset || 6}" min="2" max="60">
                <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR ? 'تعود الشاشة تلقائياً لوضع الانتظار بعد انتهاء الثواني' : 'Clears screen back to welcome state after scan'}</div>
              </div>

              <div class="form-group" style="grid-column:span 2">
                <label class="form-label">${isAR ? 'الرسالة الترحيبية (عربي)' : 'Welcome Message (Arabic)'}</label>
                <input type="text" class="form-control" id="set-pc-welcome-ar" value="${Utils.sanitize(settings.price_checker_welcome_msg_ar || 'يرجى توجيه باركود الصنف للمسح لمعرفة السعر')}">
              </div>

              <div class="form-group" style="grid-column:span 3">
                <label class="form-label">${isAR ? 'الرسالة الترحيبية (إنجليزي)' : 'Welcome Message (English)'}</label>
                <input type="text" class="form-control" id="set-pc-welcome-en" value="${Utils.sanitize(settings.price_checker_welcome_msg_en || 'Scan item barcode here to check price')}">
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Multi-POS & Branches Tab -->
      <div class="tab-content" id="tab-set-branches">
        <div class="card mb-3">
          <div class="card-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
            <div class="card-title">
              <span style="font-size:1.2rem">🌐</span>
              ${isAR ? '🌐 الربط السحابي وإدارة الفروع والمتجر الإلكتروني' : '🌐 Cloud Sync, Branch Network & Online Storefront'}
            </div>
            <button class="btn btn-primary btn-sm" onclick="App.navigate('multi-pos')" style="font-weight:800">
              ⚡ ${isAR ? 'فتح لوحة إدارة الفروع المستقلة' : 'Open Full Branch Manager'}
            </button>
          </div>
          <div class="modal-body" id="settings-branches-embed-container">
            <div style="text-align:center;padding:24px">
              <div class="spinner" style="margin:0 auto 12px"></div>
              <div>${isAR ? 'جارِ تحميل إعدادات الفروع ونقاط البيع...' : 'Loading branch and station configuration...'}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Software Update Tab -->
      <div class="tab-content" id="tab-set-update">
        <div class="card mb-3">
          <div class="card-header">
            <div class="card-title">
              <span style="font-size:1.2rem">⚡</span>
              ${isAR ? 'تحديث برنامج العميل والإصدارات الجديدة' : 'Safe Software Update & Release Deployer'}
            </div>
          </div>
          <div class="modal-body">
            
            <div style="background:rgba(16,185,129,0.08);border:1px solid var(--success);border-radius:10px;padding:14px;margin-bottom:16px;display:flex;gap:12px;align-items:center">
              <span style="font-size:1.5rem">🛡️</span>
              <div style="font-size:0.82rem;color:var(--text-primary)">
                <strong>${isAR ? 'حماية بيانات العميل 100%:' : '100% Customer Data Protection:'}</strong><br>
                <span style="color:var(--text-muted)">
                  ${isAR ? 'يقوم التحديث بتحديث ملفات البرمجة والواجهات وطباعة الفواتير فقط، مع الحفاظ الكامل على قاعدة البيانات والمبيعات والمخزون والتراخيص دون أي تأثير على عمل العميل.' : 'Updates source code, UI modules, and print templates while keeping all sales records, inventory, settings, licenses, and customer databases 100% intact.'}
                </span>
              </div>
            </div>

            <!-- Current Version Badge -->
            <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;padding:12px 16px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
              <div>
                <div style="font-size:0.75rem;color:var(--text-muted);font-weight:600">${isAR ? 'الإصدار الحالي للنظام:' : 'Current Installed Version:'}</div>
                <div style="font-size:1.25rem;font-weight:900;color:var(--primary);display:flex;align-items:center;gap:8px">
                  <span>Red Shark POS</span>
                  <span class="badge badge-primary" style="font-size:0.8rem">v${License.APP_VERSION || '1.2.35'}</span>
                  <span id="sys-version-build-tag" class="badge badge-secondary" style="font-size:0.75rem">Build ${License.APP_BUILD || 51}</span>
                </div>
              </div>
              <button class="btn btn-secondary btn-sm" onclick="App.showAboutModal()" style="font-weight:700">
                ℹ️ ${isAR ? 'معلومات النظام والترخيص' : 'System & License Info'}
              </button>
            </div>

            <!-- Method 1: Automated 1-Click Cloud Update (OTA) -->
            <div style="background:linear-gradient(135deg, rgba(37,99,235,0.08), rgba(16,185,129,0.08));border-radius:14px;padding:22px;border:1px solid rgba(37,99,235,0.25);margin-bottom:18px">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:14px">
                <div style="max-width:540px">
                  <div style="font-weight:900;font-size:1.15rem;color:var(--primary);margin-bottom:6px;display:flex;align-items:center;gap:8px">
                    <span>☁️</span>
                    <span>${isAR ? '1. فحص وتطبيق التحديث السحابي التلقائي (1-Click Cloud OTA)' : '1. Check & Apply Cloud Update (1-Click OTA)'}</span>
                  </div>
                  <div style="font-size:0.84rem;color:var(--text-secondary);line-height:1.6">
                    ${isAR 
                      ? 'يقوم النظام بالاتصال بسحابة Red Shark وفحص ما إذا كان هناك إصدار أحدث متوفر. التحديث آمن 100% ويقوم بتحديث ملفات الواجهة والبرمجة فقط مع الحفاظ التام على قاعدة البيانات، المبيعات، والترخيص.'
                      : 'Checks the Red Shark Cloud repository for newly released versions. 100% safe: updates application code and UI while completely preserving your database, sales, and licenses.'}
                  </div>
                </div>

                <button class="btn btn-primary" id="btn-check-cloud-update" onclick="Admin.checkForCloudUpdates()" style="font-weight:800;padding:10px 22px;box-shadow:0 4px 14px rgba(37,99,235,0.3);display:flex;align-items:center;gap:8px;font-size:0.9rem">
                  <span>🔍</span>
                  <span id="btn-check-cloud-update-text">${isAR ? 'فحص وجود تحديثات الآن' : 'Check for Updates Now'}</span>
                </button>
              </div>

              <!-- Update Status Container -->
              <div id="cloud-update-result-box" style="display:none;margin-top:16px;padding:14px;border-radius:10px;background:var(--surface);border:1px solid var(--border-color)">
              </div>
            </div>

            <!-- Method 1: Upload ZIP Archive (Direct In-App Upgrade) -->
            <div style="background:var(--surface-2);border-radius:12px;padding:20px;border:2px dashed var(--primary);margin-bottom:16px;text-align:center" id="update-dropzone">
              <div style="font-size:2.2rem;margin-bottom:6px">📦</div>
              <div style="font-weight:800;font-size:1.05rem;color:var(--primary);margin-bottom:4px">
                ${isAR ? '1. رفع حزمة التحديث المباشرة (.zip)' : '1. Upload Update Package (.zip)'}
              </div>
              <div style="font-size:0.82rem;color:var(--text-muted);max-width:540px;margin:0 auto 14px">
                ${isAR ? 'اسحب وأفلت ملف التحديث (RedSharkPOS_Update_vX.Y.Z.zip) هنا، أو اختر الملف لتحديث النظام تلقائياً وبأمان كامل دون أي مساس بالبيانات:' : 'Drag & drop the update zip package here, or click below to select file and auto-update without affecting any data:'}
              </div>
              <div style="display:flex;justify-content:center;gap:10px;align-items:center">
                <input type="file" id="sys-update-zip-input" accept=".zip,.rar" style="display:none" onchange="Admin.handleZipFileSelect(this.files[0])">
                <button class="btn btn-primary" onclick="document.getElementById('sys-update-zip-input').click()" style="font-weight:800;padding:9px 24px;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
                  📁 ${isAR ? 'اختر ملف التحديث (.zip)' : 'Select Update File (.zip)'}
                </button>
              </div>
              <div id="zip-update-status" style="margin-top:12px"></div>
            </div>

            <!-- Method 2: Standalone Desktop 1-Click Updater (.bat) -->
            <div style="background:var(--surface-2);border-radius:10px;padding:16px;border:1px solid var(--border-color);margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
              <div>
                <div style="font-weight:700;font-size:0.9rem;margin-bottom:4px">
                  ${isAR ? '2. تشغيل أداة التحديث المباشرة (Update_Customer_Software.bat)' : '2. Standalone Windows Desktop Updater'}
                </div>
                <div style="font-size:0.78rem;color:var(--text-muted)">
                  ${isAR ? 'تشغيل أداة التحديث الذكية على سطح المكتب بضغطة زر واحدة لتحديث البرنامج من مجلد أو فلاش ميموري' : 'Launch the standalone updater assistant directly on the desktop to upgrade from a folder or USB drive'}
                </div>
              </div>
              <button class="btn btn-secondary" onclick="Admin.launchUpdateBat()" style="font-weight:700;white-space:nowrap;padding:7px 16px">
                🚀 ${isAR ? 'تشغيل أداة التحديث (.bat)' : 'Launch Assistant (.bat)'}
              </button>
            </div>

            <!-- Method 3: In-App Folder Browser -->
            <div style="background:var(--surface-2);border-radius:10px;padding:16px;border:1px solid var(--border-color)">
              <div style="font-weight:700;font-size:0.9rem;margin-bottom:8px">
                ${isAR ? '3. استعراض وتطبيق مجلد الإصدار (Browse Local Release Folder)' : '3. Select Release Folder & Apply'}
              </div>
              <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:12px">
                ${isAR ? 'إذا كان مجلد الإصدار موجوداً على قرص محلي أو فلاش ميموري:' : 'If the release folder is on a local disk or USB drive:'}
              </div>

              <div class="form-group" style="margin-bottom:12px">
                <label class="form-label" style="font-weight:700">${isAR ? 'مسار مجلد الإصدار الجديد (Release Folder Path)' : 'Release Folder Path'}</label>
                <div style="display:flex;gap:8px">
                  <input type="text" class="form-control" id="sys-update-folder-path" placeholder="${isAR ? 'مسار المجلد مثلاً: D:\\Updates\\RedSharkPOS_Release' : 'e.g. D:\\Updates\\RedSharkPOS_Release'}" style="font-family:monospace;font-size:0.85rem">
                  <button class="btn btn-secondary" onclick="Admin.browseReleaseFolder()" style="white-space:nowrap">
                    📁 ${isAR ? 'استعراض المجلد...' : 'Browse Folder...'}
                  </button>
                </div>
              </div>

              <button class="btn btn-primary" onclick="Admin.applyReleaseUpdate()" id="btn-apply-update" style="font-weight:800">
                ⚡ ${isAR ? 'تطبيق التحديث الآن (دون مساس بالبيانات)' : 'Apply Update Now (Safe & Preserved)'}
              </button>

              <div id="update-status-msg" style="margin-top:12px"></div>
            </div>

          </div>
        </div>
      </div>
    </div>`;

    Utils.initTabs('#settings-tabs');
    renderModifiersList();

    // Auto-update Invoice Designer preview and attach live preview listener
    const designerTab = document.getElementById('tab-set-invoice-designer');
    if (designerTab) {
      designerTab.addEventListener('input', () => updateInvoiceDesignerPreview());
      designerTab.addEventListener('change', () => updateInvoiceDesignerPreview());
    }
    document.querySelector('[data-tab="tab-set-invoice-designer"]')?.addEventListener('click', () => {
      setTimeout(() => updateInvoiceDesignerPreview(), 30);
    });

    // Preload & Attach Cloud Sync & Branches tab
    const preloadBranches = () => {
      const container = document.getElementById('settings-branches-embed-container');
      if (container && window.BranchSync && typeof BranchSync.render === 'function') {
        BranchSync.render(container);
      }
    };
    setTimeout(preloadBranches, 30);

    document.querySelector('[data-tab="tab-set-branches"]')?.addEventListener('click', () => {
      preloadBranches();
    });
    document.getElementById('tab-set-branches')?.addEventListener('tabactivated', () => {
      preloadBranches();
    });

    // Update license status card dynamically
    setTimeout(async () => {
      const machId = await License.getMachineId();
      const machEl = document.getElementById('license-mach-id-display');
      if (machEl) machEl.textContent = machId;

      const statusCard = document.getElementById('license-status-card');
      if (statusCard) {
        const stat = await License.getStatus();
        if (stat.active && stat.data) {
          statusCard.innerHTML = `
            <div style="background:rgba(16,185,129,0.1);border:1px solid var(--success);border-radius:10px;padding:16px;text-align:left;display:flex;align-items:center;justify-content:space-between">
              <div>
                <div style="font-weight:700;color:var(--success);font-size:1.1rem;margin-bottom:4px">✓ ${isAR?'ترخيص البرنامج نشط':'License Active'}</div>
                <div style="font-size:0.85rem;color:var(--text-secondary)">${isAR?'مرخص لـ:':'Issued To:'} <strong>${Utils.sanitize(stat.data.client_name)}</strong></div>
                <div style="font-size:0.85rem;color:var(--text-secondary)">${isAR?'ينتهي في:':'Expires On:'} <strong>${stat.data.expiry_date}</strong></div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:6px;display:flex;flex-wrap:wrap;gap:4px">
                  ${(stat.data.allowed_modules || []).map(m => `<span class="badge badge-secondary">${m}</span>`).join('')}
                </div>
              </div>
              <button class="btn btn-danger btn-sm" onclick="License.deactivateLicense()">${isAR?'إلغاء التنشيط':'Deactivate'}</button>
            </div>
          `;
        } else {
          let msg = isAR ? 'البرنامج غير منشط. يرجى تنشيط الترخيص للاستفادة بكامل الميزات.' : 'Software is running in Trial/Unlicensed mode. Please activate to enable full functionality.';
          let statusLabel = isAR ? 'غير منشط / تجريبي' : 'Unlicensed / Trial';
          if (stat.status === 'expired') {
            statusLabel = isAR ? 'منتهي الصلاحية' : 'Expired';
            msg = isAR ? `انتهى ترخيص هذا البرنامج بتاريخ ${stat.data.expiry_date}. يرجى التجديد.` : `This license expired on ${stat.data.expiry_date}. Please renew.`;
          }
          statusCard.innerHTML = `
            <div style="background:rgba(239,68,68,0.1);border:1px solid var(--danger);border-radius:10px;padding:16px;text-align:left">
              <div style="font-weight:700;color:var(--danger);font-size:1.1rem;margin-bottom:4px">⚠️ ${statusLabel}</div>
              <p style="font-size:0.85rem;color:var(--text-secondary);margin:0">${msg}</p>
            </div>
          `;
        }
      }

      updateInvoiceDesignerPreview();
      updatePosCartColumnsPreview();
    }, 50);
  }

  function updatePosCartColumnsPreview() {
    const box = document.getElementById('pos-cart-columns-live-preview');
    if (!box) return;

    const isAR = i18n.getLang() === 'ar';
    const cols = {
      col_name: true,
      col_code: document.getElementById('pos-col-code')?.checked ?? false,
      col_unit: document.getElementById('pos-col-unit')?.checked ?? false,
      col_price: document.getElementById('pos-col-price')?.checked ?? true,
      col_cost: document.getElementById('pos-col-cost')?.checked ?? false,
      col_qty: document.getElementById('pos-col-qty')?.checked ?? true,
      col_disc: document.getElementById('pos-col-disc')?.checked ?? true,
      col_vat: document.getElementById('pos-col-vat')?.checked ?? false,
      col_total: document.getElementById('pos-col-total')?.checked ?? true,
      col_actions: document.getElementById('pos-col-actions')?.checked ?? true
    };

    let ths = '';
    if (cols.col_code) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);white-space:nowrap">${isAR ? 'الكود' : 'Code'}</th>`;
    if (cols.col_name) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);white-space:nowrap">${isAR ? 'الصنف / الوصف' : 'Item Description'}</th>`;
    if (cols.col_unit) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:center">${isAR ? 'الوحدة' : 'Unit'}</th>`;
    if (cols.col_cost) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--danger);border-bottom:1px solid var(--border-color);text-align:end">${isAR ? 'التكلفة' : 'Cost'}</th>`;
    if (cols.col_price) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:end">${isAR ? 'السعر' : 'Price'}</th>`;
    if (cols.col_qty) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>`;
    if (cols.col_disc) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:center">${isAR ? 'خصم%' : 'Disc%'}</th>`;
    if (cols.col_vat) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:center">${isAR ? 'ضريبة' : 'VAT'}</th>`;
    if (cols.col_total) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:end">${isAR ? 'الإجمالي' : 'Total'}</th>`;
    if (cols.col_actions) ths += `<th style="padding:6px;font-size:0.7rem;background:var(--surface-2);color:var(--text-muted);border-bottom:1px solid var(--border-color);text-align:center">${isAR ? 'إجراء' : 'Act'}</th>`;

    // Demo preview rows
    const demoRows = [
      { code: 'RS-1001', name: isAR ? 'مشروب غازي كولا 330 مل' : 'Cola Soft Drink 330ml', unit: isAR ? 'علبة' : 'can', cost: '$0.40', price: '$1.00', qty: 2, disc: '0%', vat: '11%', total: '$2.00' },
      { code: 'RS-2045', name: isAR ? 'شوكولاتة بندق كلاسيك 100غ' : 'Hazelnut Chocolate 100g', unit: isAR ? 'حبة' : 'pcs', cost: '$1.20', price: '$2.50', qty: 1, disc: '10%', vat: '11%', total: '$2.25' }
    ];

    let trs = demoRows.map((r) => {
      let tds = '';
      if (cols.col_code) tds += `<td style="padding:6px;font-size:0.72rem;font-family:monospace;color:var(--text-muted);border-bottom:1px solid var(--border-color)">${r.code}</td>`;
      if (cols.col_name) tds += `<td style="padding:6px;font-size:0.75rem;font-weight:700;border-bottom:1px solid var(--border-color)"><span class="badge badge-primary" style="font-size:0.6rem;padding:1px 4px;margin-inline-end:4px">${isAR?'🛒 بيع':'Sale'}</span>${r.name}</td>`;
      if (cols.col_unit) tds += `<td style="padding:6px;font-size:0.72rem;text-align:center;color:var(--text-secondary);border-bottom:1px solid var(--border-color)">${r.unit}</td>`;
      if (cols.col_cost) tds += `<td style="padding:6px;font-size:0.72rem;text-align:end;color:var(--danger);font-weight:600;border-bottom:1px solid var(--border-color)">${r.cost}</td>`;
      if (cols.col_price) tds += `<td style="padding:6px;font-size:0.75rem;text-align:end;font-weight:700;border-bottom:1px solid var(--border-color)">${r.price}</td>`;
      if (cols.col_qty) tds += `<td style="padding:6px;font-size:0.72rem;text-align:center;border-bottom:1px solid var(--border-color)"><span style="padding:1px 6px;border:1px solid var(--border-color);border-radius:4px;font-weight:700">- ${r.qty} +</span></td>`;
      if (cols.col_disc) tds += `<td style="padding:6px;font-size:0.72rem;text-align:center;color:var(--warning);border-bottom:1px solid var(--border-color)">${r.disc}</td>`;
      if (cols.col_vat) tds += `<td style="padding:6px;font-size:0.72rem;text-align:center;color:var(--text-muted);border-bottom:1px solid var(--border-color)">${r.vat}</td>`;
      if (cols.col_total) tds += `<td style="padding:6px;font-size:0.78rem;text-align:end;font-weight:800;color:var(--primary);border-bottom:1px solid var(--border-color)">${r.total}</td>`;
      if (cols.col_actions) tds += `<td style="padding:6px;text-align:center;border-bottom:1px solid var(--border-color)"><span style="color:var(--danger);cursor:pointer;font-size:0.8rem">✕</span></td>`;
      return `<tr>${tds}</tr>`;
    }).join('');

    box.innerHTML = `
      <table style="width:100%;border-collapse:collapse">
        <thead><tr>${ths}</tr></thead>
        <tbody>${trs}</tbody>
      </table>
    `;
  }

  function resetPosCartColumnsDefaults() {
    const def = {
      col_code: false,
      col_unit: false,
      col_price: true,
      col_cost: false,
      col_qty: true,
      col_disc: true,
      col_vat: false,
      col_total: true,
      col_actions: true
    };
    if (document.getElementById('pos-col-code')) document.getElementById('pos-col-code').checked = def.col_code;
    if (document.getElementById('pos-col-unit')) document.getElementById('pos-col-unit').checked = def.col_unit;
    if (document.getElementById('pos-col-price')) document.getElementById('pos-col-price').checked = def.col_price;
    if (document.getElementById('pos-col-cost')) document.getElementById('pos-col-cost').checked = def.col_cost;
    if (document.getElementById('pos-col-qty')) document.getElementById('pos-col-qty').checked = def.col_qty;
    if (document.getElementById('pos-col-disc')) document.getElementById('pos-col-disc').checked = def.col_disc;
    if (document.getElementById('pos-col-vat')) document.getElementById('pos-col-vat').checked = def.col_vat;
    if (document.getElementById('pos-col-total')) document.getElementById('pos-col-total').checked = def.col_total;
    if (document.getElementById('pos-col-actions')) document.getElementById('pos-col-actions').checked = def.col_actions;
    updatePosCartColumnsPreview();
    const isAR = i18n.getLang() === 'ar';
    Utils.toast(isAR ? 'تمت استعادة أعمدة السلة الافتراضية، اضغط حفظ لتطبيقها' : 'Default POS cart columns restored. Click Save to apply.', 'info');
  }

  async function saveSettings() {
    try {
      const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
      const compNameFromInv = document.getElementById('inv-set-comp-name')?.value?.trim();
      const compNameEn = compNameFromInv || document.getElementById('set-company-name')?.value || 'Store';
      const compNameArInput = document.getElementById('inv-set-comp-name-ar')?.value?.trim() || document.getElementById('set-company-name-ar')?.value?.trim();
      const compNameAr = compNameArInput || compNameEn;
      await DB.setSetting('company_name',    compNameEn);
      await DB.setSetting('company_name_ar', compNameAr);
      
      const compPhone = (document.getElementById('inv-set-comp-phone') ? document.getElementById('inv-set-comp-phone').value : (document.getElementById('set-company-phone')?.value || ''));
      await DB.setSetting('company_phone',   compPhone);
      await DB.setSetting('company_email',   document.getElementById('set-company-email')?.value || '');
      
      const compAddress = (document.getElementById('inv-set-comp-address') ? document.getElementById('inv-set-comp-address').value : (document.getElementById('set-company-address')?.value || ''));
      await DB.setSetting('company_address', compAddress);
      
      const vatNum = (document.getElementById('inv-set-vat-num') ? document.getElementById('inv-set-vat-num').value : (document.getElementById('set-vat-num')?.value || ''));
      await DB.setSetting('vat_number',      vatNum);
      
      await DB.setSetting('currency_1',      document.getElementById('set-cur1')?.value || 'USD');
      await DB.setSetting('currency_2',      document.getElementById('set-cur2')?.value || 'LBP');
      await DB.setSetting('exchange_rate',   parseFloat(document.getElementById('set-exch-rate')?.value)||89500);
      await DB.setSetting('vat_enabled',     document.getElementById('set-vat-enabled')?.checked || false);
      await DB.setSetting('vat_rate',        parseFloat(document.getElementById('set-vat-rate')?.value)||11);
      await DB.setSetting('receipt_footer',   document.getElementById('set-receipt-footer')?.value || '');
      await DB.setSetting('low_stock_alert',  document.getElementById('set-low-stock-alert')?.checked || false);
      if (document.getElementById('set-allow-negative-stock')) {
        await DB.setSetting('allow_negative_stock', document.getElementById('set-allow-negative-stock').checked);
      }
      const posWhSelect = document.getElementById('set-pos-warehouse-id');
      if (posWhSelect && posWhSelect.value) {
        const whId = parseInt(posWhSelect.value, 10);
        await DB.setSetting('pos_warehouse_id', whId);
        if (typeof window !== 'undefined') window._posWarehouseId = whId;
      }
      const showAiBubble = document.getElementById('set-show-ai-bubble')?.checked !== false;
      await DB.setSetting('show_ai_bubble', showAiBubble);
      if (window.AICopilot) {
        if (showAiBubble) AICopilot.showBubble();
        else AICopilot.hideBubble();
      }
      // Security settings
      const reqAuth = document.getElementById('set-require-return-auth')?.checked ?? true;
      const masterPin = document.getElementById('set-return-auth-pin')?.value.trim() || '1234';
      await DB.setSetting('require_return_auth', reqAuth);
      await DB.setSetting('return_auth_pin',     masterPin);
      await DB.setSetting('pos_master_password', masterPin);
      await DB.setSetting('audit_retention_days', document.getElementById('set-audit-retention')?.value || '30');
      // Printer settings
      await DB.setSetting('receipt_size',    document.getElementById('set-receipt-size')?.value || '80mm');
      await DB.setSetting('receipt_copies',  parseInt(document.getElementById('set-receipt-copies')?.value)||1);
      await DB.setSetting('invoice_size',    document.getElementById('set-invoice-size')?.value || 'A4');
      await DB.setSetting('invoice_copies',  parseInt(document.getElementById('set-invoice-copies')?.value)||1);
      await DB.setSetting('po_size',         document.getElementById('set-po-size')?.value || 'A4');
      await DB.setSetting('payslip_size',    document.getElementById('set-payslip-size')?.value || 'A4');
      await DB.setSetting('auto_print',      document.getElementById('set-auto-print')?.checked || false);
      await DB.setSetting('pos_preview_receipt', document.getElementById('set-pos-preview-receipt')?.checked || false);
      await DB.setSetting('print_logo',      document.getElementById('set-print-logo')?.checked || true);
      await DB.setSetting('show_barcode',    document.getElementById('set-show-barcode')?.checked || true);
      await DB.setSetting('pole_display_enabled', document.getElementById('set-pole-display-enabled')?.checked ?? true);
      await DB.setSetting('pole_display_port',    document.getElementById('set-pole-display-port')?.value || 'auto');
      await DB.setSetting('pole_display_baud',    parseInt(document.getElementById('set-pole-display-baud')?.value) || 2400);
      // Printer names & Label configuration
      await DB.setSetting('receipt_printer',         document.getElementById('set-receipt-printer')?.value.trim() || '');
      await DB.setSetting('kitchen_printer_main',    document.getElementById('set-kitchen-printer-main')?.value.trim() || '');
      await DB.setSetting('kitchen_printer_bar',     document.getElementById('set-kitchen-printer-bar')?.value.trim() || '');
      await DB.setSetting('kitchen_printer_dessert', document.getElementById('set-kitchen-printer-dessert')?.value.trim() || '');
      await DB.setSetting('document_printer',        document.getElementById('set-document-printer')?.value.trim() || '');
      await DB.setSetting('label_printer',           document.getElementById('set-label-printer')?.value.trim() || '');
      await DB.setSetting('label_orientation', document.getElementById('set-label-orientation')?.value || 'portrait');
      await DB.setSetting('label_show_name',    document.getElementById('set-label-show-name')?.checked ?? true);
      await DB.setSetting('label_show_code',    document.getElementById('set-label-show-code')?.checked ?? true);
      await DB.setSetting('label_show_barcode', document.getElementById('set-label-show-barcode')?.checked ?? true);
      await DB.setSetting('label_show_digits',  document.getElementById('set-label-show-digits')?.checked ?? true);
      await DB.setSetting('label_show_price',   document.getElementById('set-label-show-price')?.checked ?? true);
      await DB.setSetting('label_show_company', document.getElementById('set-label-show-company')?.checked ?? false);
      await DB.setSetting('label_custom_width',  parseInt(document.getElementById('set-label-custom-width')?.value) || 50);
      await DB.setSetting('label_custom_height', parseInt(document.getElementById('set-label-custom-height')?.value) || 30);
      // Loyalty & Promotions settings
      await DB.setSetting('loyalty_enabled',          document.getElementById('set-loyalty-enabled')?.checked || false);
      await DB.setSetting('loyalty_earn_rate',        parseFloat(document.getElementById('set-loyalty-earn-rate')?.value) || 1);
      await DB.setSetting('loyalty_redeem_rate',      parseFloat(document.getElementById('set-loyalty-redeem-rate')?.value) || 100);
      await DB.setSetting('loyalty_min_redeem',       parseInt(document.getElementById('set-loyalty-min-redeem')?.value) || 50);
      await DB.setSetting('promo_happy_hour_enabled', document.getElementById('set-promo-happy-hour-enabled')?.checked || false);
      await DB.setSetting('promo_happy_hour_pct',     parseFloat(document.getElementById('set-promo-happy-hour-pct')?.value) || 10);
      await DB.setSetting('promo_happy_hour_start',   document.getElementById('set-promo-happy-hour-start')?.value || '14:00');
      await DB.setSetting('promo_happy_hour_end',     document.getElementById('set-promo-happy-hour-end')?.value || '17:00');
      await DB.setSetting('promo_threshold_enabled',  document.getElementById('set-promo-threshold-enabled')?.checked || false);
      await DB.setSetting('promo_threshold_amt',      parseFloat(document.getElementById('set-promo-threshold-amt')?.value) || 100);
      await DB.setSetting('promo_threshold_pct',      parseFloat(document.getElementById('set-promo-threshold-pct')?.value) || 5);
      // Invoice & Receipt Designer settings
      await DB.setSetting('inv_template',             document.getElementById('inv-template')?.value || 'modern');
      await DB.setSetting('inv_primary_color',        document.getElementById('inv-primary-color')?.value || '#2563eb');
      await DB.setSetting('inv_font_family',          document.getElementById('inv-font-family')?.value || 'Cairo');
      await DB.setSetting('inv_logo_position',        document.getElementById('inv-logo-position')?.value || 'left');
      await DB.setSetting('inv_logo_size',            parseInt(document.getElementById('inv-logo-size')?.value) || 80);
      await DB.setSetting('inv_header_align',         document.getElementById('inv-header-align')?.value || 'left');
      await DB.setSetting('inv_custom_subtitle',      document.getElementById('inv-custom-subtitle')?.value || '');
      await DB.setSetting('inv_show_company_name',    document.getElementById('inv-show-company-name')?.checked ?? true);
      await DB.setSetting('inv_show_phone',           document.getElementById('inv-show-phone')?.checked ?? true);
      await DB.setSetting('inv_show_email',           document.getElementById('inv-show-email')?.checked ?? true);
      await DB.setSetting('inv_show_address',         document.getElementById('inv-show-address')?.checked ?? true);
      await DB.setSetting('inv_show_vat',             document.getElementById('inv-show-vat')?.checked ?? true);
      await DB.setSetting('inv_show_customer_info',   document.getElementById('inv-show-customer-info')?.checked ?? true);
      await DB.setSetting('inv_show_salesperson',     document.getElementById('inv-show-salesperson')?.checked ?? true);
      await DB.setSetting('inv_show_item_code',       document.getElementById('inv-show-item-code')?.checked ?? true);
      await DB.setSetting('inv_show_discount_col',    document.getElementById('inv-show-discount-col')?.checked ?? true);
      await DB.setSetting('inv_show_dual_currency',   document.getElementById('inv-show-dual-currency')?.checked ?? true);
      await DB.setSetting('inv_show_qr',              document.getElementById('inv-show-qr')?.checked ?? true);
      await DB.setSetting('inv_show_barcode',         document.getElementById('inv-show-barcode')?.checked ?? true);
      await DB.setSetting('inv_show_stamp_signature', document.getElementById('inv-show-stamp-signature')?.checked ?? true);
      await DB.setSetting('inv_terms_text',           document.getElementById('inv-terms-text')?.value || '');
      await DB.setSetting('inv_footer_note',          document.getElementById('inv-footer-note')?.value || '');

      // Invoice Item Extra Attributes
      await DB.setSetting('inv_item_show_brand',      document.getElementById('inv-item-show-brand')?.checked ?? false);
      await DB.setSetting('inv_item_show_model',      document.getElementById('inv-item-show-model')?.checked ?? false);
      await DB.setSetting('inv_item_show_color',      document.getElementById('inv-item-show-color')?.checked ?? false);
      await DB.setSetting('inv_item_show_origin',     document.getElementById('inv-item-show-origin')?.checked ?? false);
      await DB.setSetting('inv_item_show_type',       document.getElementById('inv-item-show-type')?.checked ?? false);
      await DB.setSetting('inv_item_show_barcode',    document.getElementById('inv-item-show-barcode')?.checked ?? false);
      await DB.setSetting('inv_item_show_weight',     document.getElementById('inv-item-show-weight')?.checked ?? false);
      await DB.setSetting('inv_item_show_size',       document.getElementById('inv-item-show-size')?.checked ?? false);
      await DB.setSetting('inv_item_show_notes',      document.getElementById('inv-item-show-notes')?.checked ?? false);
      await DB.setSetting('inv_item_display_mode',    document.getElementById('inv-item-display-mode')?.value || 'subline');
      await DB.setSetting('inv_item_separator',       document.getElementById('inv-item-separator')?.value || ' - ');
      await DB.setSetting('inv_receipt_item_layout',  document.getElementById('inv-receipt-item-layout')?.value || 'table');

      // Invoice Font Sizes per Box
      await DB.setSetting('inv_fs_company_name',      document.getElementById('inv-fs-company-name')?.value || '24px');
      await DB.setSetting('inv_fs_subtitle',          document.getElementById('inv-fs-subtitle')?.value || '13px');
      await DB.setSetting('inv_fs_header_contact',    document.getElementById('inv-fs-header-contact')?.value || '12px');
      await DB.setSetting('inv_fs_doc_title',         document.getElementById('inv-fs-doc-title')?.value || '22px');
      await DB.setSetting('inv_fs_doc_num',           document.getElementById('inv-fs-doc-num')?.value || '15px');
      await DB.setSetting('inv_fs_meta_text',         document.getElementById('inv-fs-meta-text')?.value || '12px');
      await DB.setSetting('inv_fs_customer_box',      document.getElementById('inv-fs-customer-box')?.value || '13px');
      await DB.setSetting('inv_fs_cashier_box',       document.getElementById('inv-fs-cashier-box')?.value || '13px');
      await DB.setSetting('inv_fs_table_header',      document.getElementById('inv-fs-table-header')?.value || '12px');
      await DB.setSetting('inv_fs_table_rows',        document.getElementById('inv-fs-table-rows')?.value || '12px');
      await DB.setSetting('inv_fs_item_subline',      document.getElementById('inv-fs-item-subline')?.value || '11px');
      await DB.setSetting('inv_fs_totals_box',        document.getElementById('inv-fs-totals-box')?.value || '12px');
      await DB.setSetting('inv_fs_grand_total',       document.getElementById('inv-fs-grand-total')?.value || '16px');
      await DB.setSetting('inv_fs_cur2_total',        document.getElementById('inv-fs-cur2-total')?.value || '13px');
      await DB.setSetting('inv_fs_terms',             document.getElementById('inv-fs-terms')?.value || '11px');
      await DB.setSetting('inv_fs_signatures',        document.getElementById('inv-fs-signatures')?.value || '12px');
      await DB.setSetting('inv_fs_footer_note',       document.getElementById('inv-fs-footer-note')?.value || '11px');

      // Invoice Custom Fixed Texts & Labels
      await DB.setSetting('inv_txt_doc_title',        document.getElementById('inv-txt-doc-title')?.value.trim() || '');
      await DB.setSetting('inv_txt_date_label',       document.getElementById('inv-txt-date-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_duedate_label',    document.getElementById('inv-txt-duedate-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_tax_id_label',     document.getElementById('inv-txt-tax-id-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_bill_to_label',    document.getElementById('inv-txt-bill-to-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_cashier_label',    document.getElementById('inv-txt-cashier-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_payment_label',    document.getElementById('inv-txt-payment-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_hash',         document.getElementById('inv-txt-col-hash')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_item',         document.getElementById('inv-txt-col-item')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_sku',          document.getElementById('inv-txt-col-sku')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_qty',          document.getElementById('inv-txt-col-qty')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_price',        document.getElementById('inv-txt-col-price')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_disc',         document.getElementById('inv-txt-col-disc')?.value.trim() || '');
      await DB.setSetting('inv_txt_col_total',        document.getElementById('inv-txt-col-total')?.value.trim() || '');
      await DB.setSetting('inv_txt_subtotal_label',   document.getElementById('inv-txt-subtotal-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_discount_label',   document.getElementById('inv-txt-discount-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_vat_label',        document.getElementById('inv-txt-vat-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_grand_total_label',document.getElementById('inv-txt-grand-total-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_cur2_label',       document.getElementById('inv-txt-cur2-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_terms_label',      document.getElementById('inv-txt-terms-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_cust_sig_label',   document.getElementById('inv-txt-cust-sig-label')?.value.trim() || '');
      await DB.setSetting('inv_txt_store_sig_label',  document.getElementById('inv-txt-store-sig-label')?.value.trim() || '');

      // WhatsApp & Telegram Settings
      await DB.setSetting('owner_whatsapp_phone',     document.getElementById('set-owner-whatsapp-phone')?.value.trim() || '');
      await DB.setSetting('whatsapp_invoice_template',document.getElementById('set-whatsapp-invoice-template')?.value || '');
      await DB.setSetting('telegram_bot_token',       document.getElementById('set-telegram-bot-token')?.value.trim() || '');
      await DB.setSetting('telegram_chat_id',         document.getElementById('set-telegram-chat-id')?.value.trim() || '');
      await DB.setSetting('telegram_auto_send',       document.getElementById('set-telegram-auto-send')?.checked || false);

      if (window._adminRetailModifiers) {
        await DB.setSetting('quick_modifiers_retail', window._adminRetailModifiers);
      }
      if (window._adminRestaurantModifiers) {
        await DB.setSetting('quick_modifiers_restaurant', window._adminRestaurantModifiers);
      }

      if (window._uploadedLogoBase64 !== undefined) {
        await DB.setSetting('company_logo', window._uploadedLogoBase64);
      }

      // POS Cart Columns Configuration Save
      if (document.getElementById('pos-col-name')) {
        const cartCols = {
          col_name: true,
          col_code: document.getElementById('pos-col-code')?.checked ?? false,
          col_unit: document.getElementById('pos-col-unit')?.checked ?? false,
          col_price: document.getElementById('pos-col-price')?.checked ?? true,
          col_cost: document.getElementById('pos-col-cost')?.checked ?? false,
          col_qty: document.getElementById('pos-col-qty')?.checked ?? true,
          col_disc: document.getElementById('pos-col-disc')?.checked ?? true,
          col_vat: document.getElementById('pos-col-vat')?.checked ?? false,
          col_total: document.getElementById('pos-col-total')?.checked ?? true,
          col_actions: document.getElementById('pos-col-actions')?.checked ?? true
        };
        await DB.setSetting('pos_cart_columns', cartCols);
      }

      // Price Checker Kiosk settings save
      if (document.getElementById('set-pc-show-image')) {
        await DB.setSetting('price_checker_show_image',        document.getElementById('set-pc-show-image')?.checked ?? true);
        await DB.setSetting('price_checker_show_sec_currency', document.getElementById('set-pc-show-sec-currency')?.checked ?? true);
        await DB.setSetting('price_checker_show_stock_status', document.getElementById('set-pc-show-stock-status')?.checked ?? true);
        await DB.setSetting('price_checker_show_barcode',      document.getElementById('set-pc-show-barcode')?.checked ?? true);
        await DB.setSetting('price_checker_auto_reset',        parseInt(document.getElementById('set-pc-auto-reset')?.value) || 6);
        await DB.setSetting('price_checker_welcome_msg_ar',    document.getElementById('set-pc-welcome-ar')?.value || 'يرجى توجيه باركود الصنف للمسح لمعرفة السعر');
        await DB.setSetting('price_checker_welcome_msg_en',    document.getElementById('set-pc-welcome-en')?.value || 'Scan item barcode here to check price');
      }

      // POS Terminal identification save
      if (document.getElementById('set-pos-terminal-name')) {
        const termName = document.getElementById('set-pos-terminal-name')?.value.trim() || 'POS-1';
        await DB.setSetting('pos_terminal_name', termName);
        localStorage.setItem('redshark_pos_terminal', termName);
      }
      // UI Visibility Settings Save
      if (document.getElementById('set-ui-ai-copilot')) {
        const uiVis = {
          show_ai_copilot: document.getElementById('set-ui-ai-copilot')?.checked ?? true,
          show_mobile_app: document.getElementById('set-ui-mobile-app')?.checked ?? true,
          show_online_orders: document.getElementById('set-ui-online-orders')?.checked ?? true,
          show_price_check: document.getElementById('set-ui-price-check')?.checked ?? true,
          show_card_payment: document.getElementById('set-ui-card-payment')?.checked ?? true,
          show_mobile_scan: document.getElementById('set-ui-mobile-scan')?.checked ?? true,
          show_exchange_rate: document.getElementById('set-ui-exchange-rate')?.checked ?? true,
          show_clock: document.getElementById('set-ui-clock')?.checked ?? true
        };
        await DB.setSetting('ui_visibility_settings', uiVis);
        if (window.App && typeof App.applyUIVisibility === 'function') {
          await App.applyUIVisibility();
        }
      }

      // Font Scale Save
      const fontScaleInput = document.getElementById('set-font-scale-range');
      if (fontScaleInput) {
        const fScale = parseInt(fontScaleInput.value, 10) || 100;
        await DB.setSetting('app_font_scale', fScale);
        localStorage.setItem('nexpos_font_scale', fScale);
        if (window.App && typeof App.setFontScale === 'function') {
          App.setFontScale(fScale);
        }
      }

      // Online Store Bridge Settings Save
      if (document.getElementById('set-store-shop-slug')) {
        await DB.setSetting('online_store_shop_slug', document.getElementById('set-store-shop-slug')?.value.trim() || 'shop101');
        await DB.setSetting('online_store_url', document.getElementById('set-store-url')?.value.trim() || 'https://mcebwpiswvwqcdwjpagy.supabase.co');
        await DB.setSetting('online_store_key', document.getElementById('set-store-key')?.value.trim() || '');
        await DB.setSetting('online_store_autoprint', document.getElementById('set-store-autoprint')?.checked ?? false);
      }

      // Update in-memory global settings and topbar rate display immediately
      window._primaryCurrency   = document.getElementById('set-cur1')?.value || 'USD';
      window._secondaryCurrency = document.getElementById('set-cur2')?.value || 'LBP';
      window._exchangeRate      = parseFloat(document.getElementById('set-exch-rate')?.value) || 89500;
      if (typeof window.updateDollarRateDisplay === 'function') {
        window.updateDollarRateDisplay();
      }

      Utils.toast(isAR ? 'تم حفظ الإعدادات بنجاح' : 'Settings saved successfully!', 'success');
      updateInvoiceDesignerPreview();
      updatePosCartColumnsPreview();
    } catch(e) { Utils.toast('Error: ' + e.message, 'error'); }
  }

  async function handleLogoUpload(input) {
    const isAR = i18n.getLang() === 'ar';
    const file = input.files[0];
    if (!file) return;
    try {
      const base64 = await Utils.fileToBase64(file);
      window._uploadedLogoBase64 = base64;
      const preview = document.getElementById('set-company-logo-preview');
      if (preview) {
        preview.innerHTML = `<img src="${base64}" style="max-width:100%;max-height:100%;object-fit:contain">`;
      }
      const invPreview = document.getElementById('inv-company-logo-preview');
      if (invPreview) {
        invPreview.innerHTML = `<img src="${base64}" style="max-width:100%;max-height:100%;object-fit:contain">`;
      }
      updateInvoiceDesignerPreview();
      Utils.toast(isAR ? 'تم تحميل الشعار مؤقتاً، اضغط حفظ لحفظه' : 'Logo uploaded temporarily. Click Save to persist.', 'info');
    } catch (e) {
      Utils.toast(isAR ? 'فشل تحميل الشعار' : 'Logo upload failed', 'error');
    }
  }

  async function removeLogo() {
    const isAR = i18n.getLang() === 'ar';
    window._uploadedLogoBase64 = '';
    const preview = document.getElementById('set-company-logo-preview');
    if (preview) {
      preview.innerHTML = `<span style="font-size:0.7rem;color:var(--text-muted)">${isAR?'لا يوجد':'No Logo'}</span>`;
    }
    const invPreview = document.getElementById('inv-company-logo-preview');
    if (invPreview) {
      invPreview.innerHTML = `<span style="font-size:0.7rem;color:var(--text-muted)">${isAR?'لا يوجد':'No Logo'}</span>`;
    }
    await DB.setSetting('company_logo', '');
    updateInvoiceDesignerPreview();
    Utils.toast(isAR ? 'تم حذف الشعار' : 'Logo removed successfully', 'success');
  }

  // ── Quick Item Notes & Modifiers Management ────────────────────
  function renderModifiersList() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const retailEl = document.getElementById('retail-modifiers-list');
    const restEl = document.getElementById('restaurant-modifiers-list');

    if (retailEl) {
      const list = window._adminRetailModifiers || [];
      if (!list.length) {
        retailEl.innerHTML = `<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:0.85rem">${isAR ? 'لا توجد خيارات مضافة' : 'No notes configured'}</div>`;
      } else {
        retailEl.innerHTML = list.map((item, idx) => `
          <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:var(--surface-2);border-radius:8px;border:1px solid var(--border-color)">
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:1.2rem">${item.icon || '🏷️'}</span>
              <div>
                <div style="font-weight:700;font-size:0.85rem;color:var(--text-primary)">${Utils.sanitize(isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar))}</div>
                <div style="font-size:0.72rem;color:var(--text-muted)">${Utils.sanitize(isAR ? (item.name_en || '') : (item.name_ar || ''))}</div>
              </div>
            </div>
            <div style="display:flex;gap:4px">
              <button class="btn-icon" style="padding:4px;color:var(--primary)" onclick="Admin.openModifierModal('retail', ${idx})" title="${isAR?'تعديل':'Edit'}">✏️</button>
              <button class="btn-icon" style="padding:4px;color:var(--danger)" onclick="Admin.deleteModifier('retail', ${idx})" title="${isAR?'حذف':'Delete'}">🗑️</button>
            </div>
          </div>
        `).join('');
      }
    }

    if (restEl) {
      const list = window._adminRestaurantModifiers || [];
      if (!list.length) {
        restEl.innerHTML = `<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:0.85rem">${isAR ? 'لا توجد تفضيلات مضافة' : 'No modifiers configured'}</div>`;
      } else {
        restEl.innerHTML = list.map((item, idx) => `
          <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:var(--surface-2);border-radius:8px;border:1px solid var(--border-color)">
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:1.2rem">${item.icon || '🍽️'}</span>
              <div>
                <div style="font-weight:700;font-size:0.85rem;color:var(--text-primary)">${Utils.sanitize(isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar))}</div>
                <div style="font-size:0.72rem;color:var(--text-muted)">${Utils.sanitize(isAR ? (item.name_en || '') : (item.name_ar || ''))}</div>
              </div>
            </div>
            <div style="display:flex;gap:4px">
              <button class="btn-icon" style="padding:4px;color:var(--primary)" onclick="Admin.openModifierModal('restaurant', ${idx})" title="${isAR?'تعديل':'Edit'}">✏️</button>
              <button class="btn-icon" style="padding:4px;color:var(--danger)" onclick="Admin.deleteModifier('restaurant', ${idx})" title="${isAR?'حذف':'Delete'}">🗑️</button>
            </div>
          </div>
        `).join('');
      }
    }
  }

  function openModifierModal(mode, idx = null) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const isEdit = idx !== null && idx !== undefined && idx >= 0;
    const list = mode === 'restaurant' ? (window._adminRestaurantModifiers || []) : (window._adminRetailModifiers || []);
    const item = isEdit ? list[idx] : { icon: mode === 'restaurant' ? '🌶️' : '🎁', name_en: '', name_ar: '' };

    const quickEmojis = mode === 'restaurant' 
      ? ['🚫', '🍬', '🧊', '🥛', '☕', '🧅', '🌶️', '🥣', '🧂', '🥩', '🧀', '🍋', '🧄', '🍞', '🥤', '🔥']
      : ['🎁', '⚠️', '📦', '🚚', '🛡️', '🔄', '🏷️', '🔖', '⭐', '🛍️', '⚡', '💯', '🎯', '✨', '🔒', '🧾'];

    const modalHtml = `
    <div class="modal-overlay open" id="modifier-edit-modal" style="z-index:9999">
      <div class="modal" style="max-width:420px;border-radius:16px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.05rem">
            ${isEdit ? (isAR ? '✏️ تعديل الخيار' : '✏️ Edit Note / Modifier') : (isAR ? '➕ إضافة خيار جديد' : '➕ Add Note / Modifier')}
          </div>
          <button class="btn-icon" onclick="document.getElementById('modifier-edit-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px">
          <input type="hidden" id="mod-edit-mode" value="${mode}">
          <input type="hidden" id="mod-edit-idx" value="${isEdit ? idx : -1}">

          <div class="form-group" style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700">${isAR ? 'الأيقونة / الرمز التعبيري (Emoji):' : 'Icon / Emoji:'}</label>
            <div style="display:flex;gap:8px;align-items:center">
              <input type="text" class="form-control" id="mod-edit-icon" value="${item.icon || ''}" style="width:65px;text-align:center;font-size:1.3rem;font-weight:700">
              <div style="display:flex;gap:4px;flex-wrap:wrap;flex:1">
                ${quickEmojis.slice(0, 8).map(em => `
                  <button type="button" class="btn btn-secondary btn-xs" style="padding:3px 6px;font-size:1rem" onclick="document.getElementById('mod-edit-icon').value='${em}'">${em}</button>
                `).join('')}
              </div>
            </div>
          </div>

          <div class="form-group" style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700">${isAR ? 'الاسم بالإنجليزية (English):' : 'Name in English:'}</label>
            <input type="text" class="form-control" id="mod-edit-name-en" value="${Utils.sanitize(item.name_en || '')}" placeholder="e.g. Extra Spicy / Gift Wrap">
          </div>

          <div class="form-group" style="margin-bottom:10px">
            <label class="form-label" style="font-weight:700">${isAR ? 'الاسم بالعربية (Arabic):' : 'Name in Arabic:'}</label>
            <input type="text" class="form-control" id="mod-edit-name-ar" value="${Utils.sanitize(item.name_ar || '')}" placeholder="مثال: حار جداً / تغليف هدية" dir="rtl">
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 18px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('modifier-edit-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Admin.saveModifierModal()">💾 ${isAR ? 'حفظ الخيار' : 'Save'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  async function saveModifierModal() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const mode = document.getElementById('mod-edit-mode')?.value;
    const idx = parseInt(document.getElementById('mod-edit-idx')?.value);
    const icon = document.getElementById('mod-edit-icon')?.value.trim() || '🏷️';
    const name_en = document.getElementById('mod-edit-name-en')?.value.trim();
    const name_ar = document.getElementById('mod-edit-name-ar')?.value.trim();

    if (!name_en && !name_ar) {
      Utils.toast(isAR ? 'يرجى إدخال اسم الخيار' : 'Please enter modifier name', 'error');
      return;
    }

    const modData = {
      icon,
      name_en: name_en || name_ar,
      name_ar: name_ar || name_en
    };

    if (mode === 'restaurant') {
      if (!window._adminRestaurantModifiers) window._adminRestaurantModifiers = [];
      if (idx >= 0 && idx < window._adminRestaurantModifiers.length) {
        window._adminRestaurantModifiers[idx] = modData;
      } else {
        window._adminRestaurantModifiers.push(modData);
      }
      await DB.setSetting('quick_modifiers_restaurant', window._adminRestaurantModifiers);
    } else {
      if (!window._adminRetailModifiers) window._adminRetailModifiers = [];
      if (idx >= 0 && idx < window._adminRetailModifiers.length) {
        window._adminRetailModifiers[idx] = modData;
      } else {
        window._adminRetailModifiers.push(modData);
      }
      await DB.setSetting('quick_modifiers_retail', window._adminRetailModifiers);
    }

    document.getElementById('modifier-edit-modal')?.remove();
    renderModifiersList();
    Utils.toast(isAR ? 'تم حفظ الخيار بنجاح' : 'Modifier saved successfully', 'success');
  }

  async function deleteModifier(mode, idx) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    Utils.confirm(isAR ? 'هل أنت متأكد من حذف هذا الخيار؟' : 'Are you sure you want to delete this modifier?', async () => {
      if (mode === 'restaurant') {
        if (window._adminRestaurantModifiers && window._adminRestaurantModifiers[idx]) {
          window._adminRestaurantModifiers.splice(idx, 1);
          await DB.setSetting('quick_modifiers_restaurant', window._adminRestaurantModifiers);
        }
      } else {
        if (window._adminRetailModifiers && window._adminRetailModifiers[idx]) {
          window._adminRetailModifiers.splice(idx, 1);
          await DB.setSetting('quick_modifiers_retail', window._adminRetailModifiers);
        }
      }
      renderModifiersList();
      Utils.toast(isAR ? 'تم الحذف بنجاح' : 'Deleted successfully', 'success');
    });
  }

  async function resetModifiers(mode) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    Utils.confirm(isAR ? 'هل تريد استعادة قائمة الخيارات الافتراضية؟' : 'Reset to default presets?', async () => {
      if (mode === 'restaurant') {
        window._adminRestaurantModifiers = JSON.parse(JSON.stringify(DEFAULT_RESTAURANT_MODIFIERS));
        await DB.setSetting('quick_modifiers_restaurant', window._adminRestaurantModifiers);
      } else {
        window._adminRetailModifiers = JSON.parse(JSON.stringify(DEFAULT_RETAIL_MODIFIERS));
        await DB.setSetting('quick_modifiers_retail', window._adminRetailModifiers);
      }
      renderModifiersList();
      Utils.toast(isAR ? 'تمت استعادة الخيارات الافتراضية' : 'Default modifiers restored', 'success');
    });
  }

  // ── Invoice Designer Live Preview Logic ────────────────────────
  let _designerPreviewMode = localStorage.getItem('redshark_inv_preview_mode') || 'thermal';

  function setDesignerPreviewMode(mode) {
    _designerPreviewMode = mode;
    try { localStorage.setItem('redshark_inv_preview_mode', mode); } catch(e){}
    const btnA4 = document.getElementById('btn-preview-mode-a4');
    const btnThermal = document.getElementById('btn-preview-mode-thermal');
    if (btnA4 && btnThermal) {
      if (mode === 'a4') {
        btnA4.className = 'btn btn-sm btn-primary';
        btnThermal.className = 'btn btn-sm btn-ghost';
      } else {
        btnA4.className = 'btn btn-sm btn-ghost';
        btnThermal.className = 'btn btn-sm btn-primary';
      }
    }
    updateInvoiceDesignerPreview();
  }

  async function updateInvoiceDesignerPreview() {
    const previewBox = document.getElementById('inv-designer-preview-box');
    if (!previewBox) return;

    try {
      const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const compNameEn = document.getElementById('inv-set-comp-name')?.value?.trim() || document.getElementById('set-company-name')?.value || await DB.getSetting('company_name', 'Store');
    const compNameAr = document.getElementById('inv-set-comp-name-ar')?.value?.trim() || document.getElementById('set-company-name-ar')?.value || await DB.getSetting('company_name_ar', '');
    const compName = (isAR && compNameAr && compNameAr !== 'المتجر') ? compNameAr : compNameEn;
    const compPhone = (document.getElementById('inv-set-comp-phone') ? document.getElementById('inv-set-comp-phone').value : (document.getElementById('set-company-phone')?.value ?? await DB.getSetting('company_phone', '')));
    const compEmail = document.getElementById('set-company-email')?.value || await DB.getSetting('company_email', '');
    const compAddress = (document.getElementById('inv-set-comp-address') ? document.getElementById('inv-set-comp-address').value : (document.getElementById('set-company-address')?.value ?? await DB.getSetting('company_address', '')));
    const vatNum = (document.getElementById('inv-set-vat-num') ? document.getElementById('inv-set-vat-num').value : (document.getElementById('set-vat-num')?.value ?? await DB.getSetting('vat_number', '')));
    const logo = window._uploadedLogoBase64 !== undefined ? window._uploadedLogoBase64 : (await DB.getSetting('company_logo', ''));
    
    const printLogo = document.getElementById('inv-print-logo') ? document.getElementById('inv-print-logo').checked : true;
    const logoPos = document.getElementById('inv-logo-position')?.value || 'left';
    const logoSize = parseInt(document.getElementById('inv-logo-size')?.value) || 80;
    const primaryColor = document.getElementById('inv-primary-color')?.value || '#2563eb';
    const fontFamily = document.getElementById('inv-font-family')?.value || 'Cairo';
    const template = document.getElementById('inv-template')?.value || 'modern';
    const headerAlign = document.getElementById('inv-header-align')?.value || 'left';
    const subtitle = document.getElementById('inv-custom-subtitle')?.value || '';
    
    const showCompName = document.getElementById('inv-show-company-name')?.checked ?? true;
    const showPhone = document.getElementById('inv-show-phone')?.checked ?? true;
    const showEmail = document.getElementById('inv-show-email')?.checked ?? true;
    const showAddress = document.getElementById('inv-show-address')?.checked ?? true;
    const showVat = document.getElementById('inv-show-vat')?.checked ?? true;
    
    const showCust = document.getElementById('inv-show-customer-info')?.checked ?? true;
    const showSalesperson = document.getElementById('inv-show-salesperson')?.checked ?? true;
    const showItemCode = document.getElementById('inv-show-item-code')?.checked ?? true;
    const showDisc = document.getElementById('inv-show-discount-col')?.checked ?? true;
    const showDualCur = document.getElementById('inv-show-dual-currency')?.checked ?? true;
    
    const showStamp = document.getElementById('inv-show-stamp-signature')?.checked ?? true;
    const showQr = document.getElementById('inv-show-qr')?.checked ?? true;
    const showBarcode = document.getElementById('inv-show-barcode')?.checked ?? true;
    const termsText = document.getElementById('inv-terms-text')?.value || '';
    const footerNote = document.getElementById('inv-footer-note')?.value || '';

    const cur1 = document.getElementById('set-cur1')?.value || await DB.getSetting('currency_1', 'USD');
    const cur2 = document.getElementById('set-cur2')?.value || await DB.getSetting('currency_2', 'LBP');
    const exchRate = parseFloat(document.getElementById('set-exch-rate')?.value) || 89500;

    const showLogo = printLogo && logo && logoPos !== 'hidden';

    // Custom Font Sizes
    const fsCompName = document.getElementById('inv-fs-company-name')?.value || '24px';
    const fsSubtitle = document.getElementById('inv-fs-subtitle')?.value || '13px';
    const fsHeaderContact = document.getElementById('inv-fs-header-contact')?.value || '12px';
    const fsDocTitle = document.getElementById('inv-fs-doc-title')?.value || '22px';
    const fsDocNum = document.getElementById('inv-fs-doc-num')?.value || '15px';
    const fsMetaText = document.getElementById('inv-fs-meta-text')?.value || '12px';
    const fsCustBox = document.getElementById('inv-fs-customer-box')?.value || '13px';
    const fsCashierBox = document.getElementById('inv-fs-cashier-box')?.value || '13px';
    const fsTableHeader = document.getElementById('inv-fs-table-header')?.value || '12px';
    const fsTableRows = document.getElementById('inv-fs-table-rows')?.value || '12px';
    const fsItemSubline = document.getElementById('inv-fs-item-subline')?.value || '11px';
    const fsTotalsBox = document.getElementById('inv-fs-totals-box')?.value || '12px';
    const fsGrandTotal = document.getElementById('inv-fs-grand-total')?.value || document.getElementById('inv-fs-grand_total')?.value || '16px';
    const fsCur2Total = document.getElementById('inv-fs-cur2-total')?.value || '13px';
    const fsTerms = document.getElementById('inv-fs-terms')?.value || '11px';
    const fsSignatures = document.getElementById('inv-fs-signatures')?.value || '12px';
    const fsFooterNote = document.getElementById('inv-fs-footer-note')?.value || '11px';

    // Custom Fixed Texts / Labels
    const txtDocTitle = document.getElementById('inv-txt-doc-title')?.value.trim() || (isAR ? 'فاتورة ضريبية' : 'TAX INVOICE');
    const txtDocNum = document.getElementById('inv-txt-doc-num')?.value.trim() || (isAR ? 'رقم الإيصال:' : 'Receipt No:');
    const txtDateLabel = document.getElementById('inv-txt-date-label')?.value.trim() || (isAR ? 'تاريخ الإصدار: ' : 'Issue Date: ');
    const txtDueDateLabel = document.getElementById('inv-txt-duedate-label')?.value.trim() || (isAR ? 'الاستحقاق: ' : 'Due Date: ');
    const txtTaxIdLabel = document.getElementById('inv-txt-tax-id-label')?.value.trim() || (isAR ? 'الرقم الضريبي / المالي: ' : 'Tax ID: ');
    const txtBillToLabel = document.getElementById('inv-txt-bill-to-label')?.value.trim() || (isAR ? 'فاتورة إلى / العميل:' : 'BILL TO / CUSTOMER:');
    const txtCashierLabel = document.getElementById('inv-txt-cashier-label')?.value.trim() || (isAR ? 'المبيعات / الكاشير:' : 'SALES / CASHIER:');
    const txtPaymentLabel = document.getElementById('inv-txt-payment-label')?.value.trim() || (isAR ? 'طريقة الدفع:' : 'Payment:');

    const txtColHash = document.getElementById('inv-txt-col-hash')?.value.trim() || '#';
    const txtColItem = document.getElementById('inv-txt-col-item')?.value.trim() || (isAR ? 'الصنف والمواصفات' : 'Item Description & Attributes');
    const txtColSku = document.getElementById('inv-txt-col-sku')?.value.trim() || (isAR ? 'الكود' : 'SKU');
    const txtColQty = document.getElementById('inv-txt-col-qty')?.value.trim() || (isAR ? 'الكمية' : 'Qty');
    const txtColPrice = document.getElementById('inv-txt-col-price')?.value.trim() || (isAR ? 'السعر' : 'Price');
    const txtColDisc = document.getElementById('inv-txt-col-disc')?.value.trim() || (isAR ? 'الخصم' : 'Disc');
    const txtColTotal = document.getElementById('inv-txt-col-total')?.value.trim() || (isAR ? 'الإجمالي' : 'Total');

    const txtSubtotalLabel = document.getElementById('inv-txt-subtotal-label')?.value.trim() || (isAR ? 'المجموع الفرعي:' : 'Subtotal:');
    const txtDiscountLabel = document.getElementById('inv-txt-discount-label')?.value.trim() || (isAR ? 'الخصم:' : 'Discount:');
    const txtVatLabel = document.getElementById('inv-txt-vat-label')?.value.trim() || (isAR ? 'الضريبة (11%):' : 'VAT (11%):');
    const txtGrandTotalLabel = document.getElementById('inv-txt-grand-total-label')?.value.trim() || (isAR ? 'الإجمالي:' : 'GRAND TOTAL:');
    const txtCur2Label = document.getElementById('inv-txt-cur2-label')?.value.trim() || (isAR ? 'المعادل:' : 'In LBP:');
    const txtTermsLabel = document.getElementById('inv-txt-terms-label')?.value.trim() || (isAR ? 'الشروط: ' : 'Terms: ');
    const txtCustSigLabel = document.getElementById('inv-txt-cust-sig-label')?.value.trim() || (isAR ? 'توقيع المستلم / العميل' : 'Customer Signature');
    const txtStoreSigLabel = document.getElementById('inv-txt-store-sig-label')?.value.trim() || (isAR ? 'ختم وتوقيع المتجر' : 'Store Stamp & Signature');

    // Item Extended Attributes Settings
    const itemOpt = {
      showBrand:   document.getElementById('inv-item-show-brand')?.checked ?? false,
      showModel:   document.getElementById('inv-item-show-model')?.checked ?? false,
      showColor:   document.getElementById('inv-item-show-color')?.checked ?? false,
      showOrigin:  document.getElementById('inv-item-show-origin')?.checked ?? false,
      showType:    document.getElementById('inv-item-show-type')?.checked ?? false,
      showBarcode: document.getElementById('inv-item-show-barcode')?.checked ?? false,
      showWeight:  document.getElementById('inv-item-show-weight')?.checked ?? false,
      showSize:    document.getElementById('inv-item-show-size')?.checked ?? false,
      showNotes:   document.getElementById('inv-item-show-notes')?.checked ?? false,
      mode:        document.getElementById('inv-item-display-mode')?.value || 'subline',
      separator:   document.getElementById('inv-item-separator')?.value || ' - ',
      layout:      document.getElementById('inv-receipt-item-layout')?.value || 'table'
    };

    // Helper to format extra details
    const formatExtra = (item) => {
      const parts = [];
      if (itemOpt.showBrand && item.brand) parts.push((isAR ? 'الماركة: ' : 'Brand: ') + item.brand);
      if (itemOpt.showModel && item.model) parts.push((isAR ? 'الموديل: ' : 'Model: ') + item.model);
      if (itemOpt.showColor && item.color) parts.push((isAR ? 'اللون: ' : 'Color: ') + item.color);
      if (itemOpt.showOrigin && item.origin) parts.push((isAR ? 'بلد الصنع: ' : 'Made in: ') + item.origin);
      if (itemOpt.showType && item.type) parts.push((isAR ? 'النوع: ' : 'Type: ') + item.type);
      if (itemOpt.showBarcode && item.barcode) parts.push((isAR ? 'الباركود: ' : 'Barcode: ') + item.barcode);
      if (itemOpt.showWeight && item.weight) parts.push((isAR ? 'الوزن: ' : 'Weight: ') + item.weight);
      if (itemOpt.showSize && item.size) parts.push((isAR ? 'المقاس: ' : 'Size: ') + item.size);
      if (itemOpt.showNotes && item.notes) parts.push(item.notes);

      if (!parts.length) return { hasExtra: false, text: '' };
      return { hasExtra: true, text: parts.join(itemOpt.separator) };
    };

    // Sample items for realistic preview
    const sampleItems = [
      { 
        code: 'ITM-8841', 
        name_en: 'Wireless Noise-Canceling Earbuds Pro', 
        name_ar: 'سماعات بلوتوث عازلة للضوضاء برو', 
        brand: 'Sony', 
        model: 'WF-1000XM5', 
        color: isAR ? 'أسود ملكي' : 'Midnight Black', 
        origin: isAR ? '🇯🇵 اليابان' : '🇯🇵 Japan', 
        type: isAR ? 'صوتيات' : 'Audio', 
        barcode: '628100293841',
        weight: '0.25 kg',
        size: '5x4 cm',
        notes: isAR ? 'ضمان رسمي سنة' : '1 Yr Warranty',
        qty: 2, price: 45.00, disc: 10, total: 81.00 
      },
      { 
        code: 'ITM-2219', 
        name_en: 'Fast USB-C Dual Port Wall Charger 65W', 
        name_ar: 'شاحن جداري سريع نوع تايب سي 65 واط', 
        brand: 'Anker', 
        model: 'GaN 735', 
        color: isAR ? 'أبيض' : 'White', 
        origin: isAR ? '🇺🇸 الولايات المتحدة' : '🇺🇸 USA', 
        type: isAR ? 'شواحن' : 'Chargers', 
        barcode: '628100882194',
        weight: '0.15 kg',
        size: '6x3 cm',
        notes: '',
        qty: 1, price: 28.00, disc: 0, total: 28.00 
      },
      { 
        code: 'ITM-1055', 
        name_en: 'Premium 9D Tempered Glass Guard', 
        name_ar: 'لاصقة حماية شاشة زجاجية بريميوم', 
        brand: 'Baseus', 
        model: 'iPhone 15 Pro Max', 
        color: isAR ? 'شفاف' : 'Transparent', 
        origin: isAR ? '🇩🇪 ألمانيا' : '🇩🇪 Germany', 
        type: isAR ? 'إكسسوارات' : 'Accessories', 
        barcode: '628100105501',
        weight: '0.05 kg',
        size: '16x7 cm',
        notes: '',
        qty: 3, price: 6.00, disc: 0, total: 18.00 
      }
    ];

    const subtotal = 136.00;
    const discountAmt = 9.00;
    const vatAmt = 13.97;
    const grandTotal = 140.97;
    const grandTotal2 = Utils.calcSecondaryPrice(grandTotal, cur1, cur2, exchRate);

    if (_designerPreviewMode === 'a4') {
      let logoBlock = showLogo ? `<img src="${logo}" style="max-width:${logoSize}px;max-height:${logoSize}px;object-fit:contain;border-radius:4px">` : '';
      
      let headerFlexJustify = 'space-between';
      if (headerAlign === 'center') headerFlexJustify = 'center';
      else if (headerAlign === 'right') headerFlexJustify = isAR ? 'flex-start' : 'flex-end';

      let headerCompanyHtml = `
        <div style="display:flex;flex-direction:${logoPos==='center'?'column':(logoPos==='right'?'row-reverse':'row')};gap:14px;align-items:${headerAlign==='center'?'center':'flex-start'};text-align:${headerAlign}">
          ${(logoPos !== 'hidden' && showLogo) ? logoBlock : ''}
          <div>
            ${showCompName ? `<h1 style="font-size:${fsCompName};font-weight:900;color:${primaryColor};margin:0 0 3px">${Utils.sanitize(compName)}</h1>` : ''}
            ${subtitle ? `<div style="font-size:${fsSubtitle};font-weight:600;color:#64748b;margin-bottom:3px">${Utils.sanitize(subtitle)}</div>` : ''}
            ${showAddress && compAddress ? `<div style="font-size:${fsHeaderContact};color:#475569;margin-bottom:1px">📍 ${Utils.sanitize(compAddress)}</div>` : ''}
            ${showPhone && compPhone ? `<div style="font-size:${fsHeaderContact};color:#475569;margin-bottom:1px">📞 ${Utils.sanitize(compPhone)}</div>` : ''}
            ${showEmail && compEmail ? `<div style="font-size:${fsHeaderContact};color:#475569;margin-bottom:1px">✉️ ${Utils.sanitize(compEmail)}</div>` : ''}
            ${showVat && vatNum ? `<div style="font-size:${fsHeaderContact};color:#334155;font-weight:700;margin-top:3px">🏷️ ${txtTaxIdLabel}${Utils.sanitize(vatNum)}</div>` : ''}
          </div>
        </div>
      `;

      previewBox.innerHTML = `
        <div id="inv-preview-rendered-content" class="inv-rendered-a4" style="background:#ffffff;color:#0f172a;font-family:'${fontFamily}',sans-serif;padding:24px;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,0.15);font-size:12px;line-height:1.4" dir="${isAR?'rtl':'ltr'}">
          
          <!-- Header section -->
          <div style="display:flex;justify-content:${headerFlexJustify};align-items:flex-start;border-bottom:2px solid ${primaryColor};padding-bottom:14px;margin-bottom:14px;flex-wrap:wrap;gap:12px">
            ${headerCompanyHtml}
            <div style="text-align:${isAR?'left':'right'};min-width:170px">
              <h2 style="font-size:${fsDocTitle};font-weight:900;color:${primaryColor};margin:0 0 3px;text-transform:uppercase">${Utils.sanitize(txtDocTitle)}</h2>
              <div style="font-size:${fsDocNum};font-weight:800;color:#1e293b"># INV-2026-0042</div>
              <div style="font-size:${fsMetaText};color:#64748b;margin-top:2px">${txtDateLabel}${Utils.formatDate(Utils.today())}</div>
              <div style="font-size:${fsMetaText};color:#64748b">${txtDueDateLabel}${Utils.formatDate(Utils.today())}</div>
            </div>
          </div>

          <!-- Customer & Cashier block -->
          ${(showCust || showSalesperson) ? `
          <div style="display:grid;grid-template-columns:${showCust&&showSalesperson?'2fr 1fr':'1fr'};gap:10px;margin-bottom:14px">
            ${showCust ? `
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px">
              <div style="font-size:${fsCustBox};font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:3px">${Utils.sanitize(txtBillToLabel)}</div>
              <div style="font-weight:800;font-size:calc(${fsCustBox} + 2px);color:#0f172a">${isAR?'شركة النور للحلول الرقمية':'Al-Noor Digital Solutions Ltd.'}</div>
              <div style="font-size:calc(${fsCustBox} - 1px);color:#475569;margin-top:1px">📞 +961 3 987 654 • 📍 Hamra St, Beirut</div>
            </div>` : ''}
            ${showSalesperson ? `
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;text-align:${isAR?'left':'right'}">
              <div style="font-size:${fsCashierBox};font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:3px">${Utils.sanitize(txtCashierLabel)}</div>
              <div style="font-weight:800;font-size:calc(${fsCashierBox} + 1px);color:#0f172a">Admin</div>
              <div style="font-size:calc(${fsCashierBox} - 1px);color:#475569;margin-top:1px">${txtPaymentLabel} ${isAR?'نقداً':'Cash'}</div>
            </div>` : ''}
          </div>` : ''}

          <!-- Items Table -->
          <table style="width:100%;border-collapse:collapse;margin-bottom:14px;font-size:${fsTableRows}">
            <thead>
              <tr style="background:${primaryColor};color:#ffffff;text-align:${isAR?'right':'left'};font-size:${fsTableHeader}">
                <th style="padding:7px 8px;width:30px;text-align:center">${Utils.sanitize(txtColHash)}</th>
                <th style="padding:7px 8px">${Utils.sanitize(txtColItem)}</th>
                ${showItemCode ? `<th style="padding:7px 8px;width:85px">${Utils.sanitize(txtColSku)}</th>` : ''}
                <th style="padding:7px 8px;width:50px;text-align:center">${Utils.sanitize(txtColQty)}</th>
                <th style="padding:7px 8px;width:80px;text-align:right">${Utils.sanitize(txtColPrice)}</th>
                ${showDisc ? `<th style="padding:7px 8px;width:60px;text-align:right">${Utils.sanitize(txtColDisc)}</th>` : ''}
                <th style="padding:7px 8px;width:90px;text-align:right">${Utils.sanitize(txtColTotal)}</th>
              </tr>
            </thead>
            <tbody>
              ${sampleItems.map((item, idx) => {
                const ex = formatExtra(item);
                let nameCell = `<div style="font-weight:700;color:#1e293b">${isAR ? item.name_ar : item.name_en}`;
                if (ex.hasExtra) {
                  if (itemOpt.mode === 'merged') {
                    nameCell += ` <span style="font-size:${fsItemSubline};color:#64748b;font-weight:normal">${itemOpt.separator} ${ex.text}</span>`;
                  } else if (itemOpt.mode === 'bracketed') {
                    nameCell += ` <span style="font-size:${fsItemSubline};color:#64748b;font-weight:normal">(${ex.text})</span>`;
                  }
                }
                nameCell += `</div>`;
                if (ex.hasExtra && itemOpt.mode === 'subline') {
                  nameCell += `<div style="font-size:${fsItemSubline};color:#64748b;margin-top:2px;font-weight:500">${ex.text}</div>`;
                }

                return `
                <tr style="background:${idx%2===0?'#ffffff':'#f8fafc'};border-bottom:1px solid #e2e8f0">
                  <td style="padding:6px 8px;text-align:center;color:#64748b;vertical-align:top">${idx+1}</td>
                  <td style="padding:6px 8px;vertical-align:top">${nameCell}</td>
                  ${showItemCode ? `<td style="padding:6px 8px;font-family:monospace;color:#64748b;vertical-align:top">${item.code}</td>` : ''}
                  <td style="padding:6px 8px;text-align:center;font-weight:600;vertical-align:top">${item.qty}</td>
                  <td style="padding:6px 8px;text-align:right;vertical-align:top">${cur1} ${item.price.toFixed(2)}</td>
                  ${showDisc ? `<td style="padding:6px 8px;text-align:right;color:#dc2626;vertical-align:top">${item.disc > 0 ? item.disc + '%' : '-'}</td>` : ''}
                  <td style="padding:6px 8px;text-align:right;font-weight:700;vertical-align:top">${cur1} ${item.total.toFixed(2)}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>

          <!-- Totals and QR block -->
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;gap:16px">
            <div style="flex:1;display:flex;gap:12px;align-items:center">
              ${showQr ? `
              <div style="border:1px solid #cbd5e1;padding:5px;border-radius:6px;background:#fff;text-align:center">
                <svg width="60" height="60" viewBox="0 0 100 100" fill="#0f172a">
                  <rect x="5" y="5" width="30" height="30" fill="none" stroke="#0f172a" stroke-width="6"/>
                  <rect x="13" y="13" width="14" height="14" fill="#0f172a"/>
                  <rect x="65" y="5" width="30" height="30" fill="none" stroke="#0f172a" stroke-width="6"/>
                  <rect x="73" y="13" width="14" height="14" fill="#0f172a"/>
                  <rect x="5" y="65" width="30" height="30" fill="none" stroke="#0f172a" stroke-width="6"/>
                  <rect x="13" y="73" width="14" height="14" fill="#0f172a"/>
                  <rect x="45" y="15" width="10" height="10"/>
                  <rect x="45" y="45" width="10" height="10"/>
                  <rect x="65" y="55" width="12" height="12"/>
                  <rect x="80" y="75" width="15" height="15"/>
                  <rect x="45" y="75" width="10" height="10"/>
                </svg>
                <div style="font-size:0.65rem;color:#64748b;margin-top:2px">e-Invoice QR</div>
              </div>` : ''}
              ${showBarcode ? `
              <div style="text-align:center">
                ${(typeof Utils !== 'undefined' && Utils.generateBarcodeSVG) ? Utils.generateBarcodeSVG('INV-2026-0042', { height: 34, barWidth: 1.4 }) : ''}
                <div style="font-family:monospace;font-size:0.7rem;font-weight:700;color:#0f172a;margin-top:2px">INV-2026-0042</div>
              </div>` : ''}
            </div>

            <!-- Totals Box -->
            <div style="width:250px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:10px">
              <div style="display:flex;justify-content:space-between;padding:2px 0;color:#64748b;font-size:${fsTotalsBox}">
                <span>${Utils.sanitize(txtSubtotalLabel)}</span>
                <span>${cur1} ${subtotal.toFixed(2)}</span>
              </div>
              <div style="display:flex;justify-content:space-between;padding:2px 0;color:#dc2626;font-size:${fsTotalsBox}">
                <span>${Utils.sanitize(txtDiscountLabel)}</span>
                <span>-${cur1} ${discountAmt.toFixed(2)}</span>
              </div>
              <div style="display:flex;justify-content:space-between;padding:2px 0;color:#64748b;font-size:${fsTotalsBox}">
                <span>${Utils.sanitize(txtVatLabel)}</span>
                <span>${cur1} ${vatAmt.toFixed(2)}</span>
              </div>
              <div style="border-top:2px solid ${primaryColor};margin-top:4px;padding-top:4px;display:flex;justify-content:space-between;font-size:${fsGrandTotal};font-weight:900;color:${primaryColor}">
                <span>${Utils.sanitize(txtGrandTotalLabel)}</span>
                <span>${cur1} ${grandTotal.toFixed(2)}</span>
              </div>
              ${showDualCur ? `
              <div style="display:flex;justify-content:space-between;margin-top:3px;padding-top:3px;border-top:1px dashed #cbd5e1;font-size:${fsCur2Total};font-weight:800;color:#059669">
                <span>${Utils.sanitize(txtCur2Label)}</span>
                <span>${grandTotal2.toLocaleString()} LBP</span>
              </div>` : ''}
            </div>
          </div>

          <!-- Terms & Policy -->
          ${termsText ? `
          <div style="background:#fffbeb;border:1px solid #fef3c7;border-left:4px solid #f59e0b;padding:6px 10px;border-radius:4px;font-size:${fsTerms};color:#92400e;margin-bottom:12px">
            <strong>${Utils.sanitize(txtTermsLabel)}</strong>${Utils.sanitize(termsText)}
          </div>` : ''}

          <!-- Stamp & Signature Boxes -->
          ${showStamp ? `
          <div style="display:flex;justify-content:space-between;margin-top:20px;padding-top:8px;font-size:${fsSignatures}">
            <div style="text-align:center;width:150px;border-top:1px dashed #94a3b8;padding-top:4px">
              <div style="color:#64748b">${Utils.sanitize(txtCustSigLabel)}</div>
            </div>
            <div style="text-align:center;width:150px;border-top:1px dashed #94a3b8;padding-top:4px">
              <div style="color:#64748b">${Utils.sanitize(txtStoreSigLabel)}</div>
            </div>
          </div>` : ''}

          <!-- Footer Note -->
          <div style="margin-top:12px;padding-top:8px;border-top:1px solid #e2e8f0;text-align:center;font-size:${fsFooterNote};color:#94a3b8">
            ${footerNote ? `<div>${Utils.sanitize(footerNote)}</div>` : ''}
            <div style="margin-top:1px">${Utils.sanitize(compName)} • ${isAR?'فاتورة إلكترونية':'Electronic Invoice'}</div>
          </div>

        </div>
      `;
    } else {
      // 80mm Thermal Receipt Preview (Uses PrintEngine to guarantee 100% exact match with physical printer output)
      const coOverride = {
        company_name: compNameEn,
        company_name_ar: compNameAr,
        company_phone: compPhone,
        company_address: compAddress,
        company_email: compEmail,
        vat_number: vatNum,
        company_logo: logo,
        print_logo: printLogo,
        inv_logo_position: logoPos,
        inv_logo_size: logoSize,
        currency_1: cur1,
        currency_2: cur2,
        exchange_rate: exchRate,
        inv_custom_subtitle: subtitle,
        inv_show_company_name: showCompName,
        inv_show_phone: showPhone,
        inv_show_address: showAddress,
        inv_show_vat: showVat,
        inv_show_customer_info: showCust,
        inv_show_salesperson: showSalesperson,
        inv_show_dual_currency: showDualCur,
        inv_show_qr: showQr,
        inv_show_barcode: showBarcode,
        inv_terms_text: termsText,
        inv_footer_note: footerNote,
        inv_receipt_item_layout: itemOpt.layout,
        inv_txt_doc_title: txtDocTitle,
        inv_txt_date_label: txtDateLabel,
        inv_txt_doc_num_label: txtDocNum,
        inv_txt_bill_to_label: txtBillToLabel,
        inv_txt_cashier_label: txtCashierLabel,
        inv_txt_subtotal_label: txtSubtotalLabel,
        inv_txt_discount_label: txtDiscountLabel,
        inv_txt_vat_label: txtVatLabel,
        inv_txt_grand_total_label: txtGrandTotalLabel,
        inv_txt_cur2_label: txtCur2Label,
        inv_txt_payment_label: txtPaymentLabel,
        inv_txt_col_item: txtColItem,
        inv_txt_col_qty: txtColQty,
        inv_txt_col_price: txtColPrice,
        inv_txt_col_total: txtColTotal,
        inv_item_show_brand: itemOpt.showBrand,
        inv_item_show_model: itemOpt.showModel,
        inv_item_show_color: itemOpt.showColor,
        inv_item_show_origin: itemOpt.showOrigin,
        inv_item_show_type: itemOpt.showType,
        inv_item_show_barcode: itemOpt.showBarcode,
        inv_item_show_weight: itemOpt.showWeight,
        inv_item_show_size: itemOpt.showSize,
        inv_item_show_notes: itemOpt.showNotes,
        inv_item_display_mode: itemOpt.mode,
        inv_item_separator: itemOpt.separator,
        // Custom Font Sizes (Real-time live preview)
        inv_fs_company_name: fsCompName,
        inv_fs_subtitle: fsSubtitle,
        inv_fs_header_contact: fsHeaderContact,
        inv_fs_doc_title: fsDocTitle,
        inv_fs_doc_num: fsDocNum,
        inv_fs_meta_text: fsMetaText,
        inv_fs_customer_box: fsCustBox,
        inv_fs_cashier_box: fsCashierBox,
        inv_fs_table_header: fsTableHeader,
        inv_fs_table_rows: fsTableRows,
        inv_fs_item_subline: fsItemSubline,
        inv_fs_totals_box: fsTotalsBox,
        inv_fs_grand_total: fsGrandTotal,
        inv_fs_cur2_total: fsCur2Total,
        inv_fs_terms: fsTerms,
        inv_fs_signatures: fsSignatures,
        inv_fs_footer_note: fsFooterNote
      };

      const sampleSale = {
        invoice_no: 'POS-00892',
        ref: 'POS-00892',
        created_at: new Date().toISOString(),
        customer_name: isAR ? 'عميل عابر' : 'Walk-in Customer',
        cashier: 'Admin',
        salesperson: 'Admin',
        subtotal: 136.00,
        discount: 9.00,
        discount_amount: 9.00,
        vat: 13.97,
        vat_amount: 13.97,
        grand_total: 140.97,
        amount_tendered: 150.00,
        tendered: 150.00,
        change_c1: 9.03,
        change_amount: 9.03,
        payment_method: isAR ? 'نقداً' : 'Cash'
      };
      const sampleCust = { name_ar: isAR ? 'عميل عابر' : 'Walk-in Customer', name_en: 'Walk-in Customer' };

      let thermalHtml = '';
      if (window.PrintEngine && typeof window.PrintEngine.generateReceiptHtml === 'function') {
        thermalHtml = await window.PrintEngine.generateReceiptHtml(sampleSale, sampleItems, sampleCust, { coOverride, isPreview: true });
      }

      previewBox.innerHTML = `
        <div id="inv-preview-rendered-content" class="inv-rendered-thermal" style="width:285px;margin:auto;background:#ffffff;color:#000000;padding:8px 6px;border-radius:6px;box-shadow:0 4px 20px rgba(0,0,0,0.2);line-height:1.3" dir="${isAR?'rtl':'ltr'}">
          ${thermalHtml}
        </div>
      `;
    }
    } catch (err) {
      console.error('Invoice Designer Preview Error:', err);
    }
  }

  async function resetInvoiceDesignDefaults() {
    const isAR = i18n.getLang() === 'ar';
    if (!confirm(isAR ? 'هل تريد استعادة إعدادات تصميم الفاتورة الافتراضية؟' : 'Reset invoice designer to default template settings?')) return;
    
    if (document.getElementById('inv-template')) document.getElementById('inv-template').value = 'modern';
    if (document.getElementById('inv-primary-color')) document.getElementById('inv-primary-color').value = '#2563eb';
    if (document.getElementById('inv-primary-color-text')) document.getElementById('inv-primary-color-text').value = '#2563eb';
    if (document.getElementById('inv-font-family')) document.getElementById('inv-font-family').value = 'Cairo';
    if (document.getElementById('inv-logo-position')) document.getElementById('inv-logo-position').value = 'left';
    if (document.getElementById('inv-logo-size')) document.getElementById('inv-logo-size').value = '80';
    if (document.getElementById('inv-header-align')) document.getElementById('inv-header-align').value = 'left';
    if (document.getElementById('inv-custom-subtitle')) document.getElementById('inv-custom-subtitle').value = '';
    
    if (document.getElementById('inv-show-company-name')) document.getElementById('inv-show-company-name').checked = true;
    if (document.getElementById('inv-show-phone')) document.getElementById('inv-show-phone').checked = true;
    if (document.getElementById('inv-show-email')) document.getElementById('inv-show-email').checked = true;
    if (document.getElementById('inv-show-address')) document.getElementById('inv-show-address').checked = true;
    if (document.getElementById('inv-show-vat')) document.getElementById('inv-show-vat').checked = true;
    
    if (document.getElementById('inv-show-customer-info')) document.getElementById('inv-show-customer-info').checked = true;
    if (document.getElementById('inv-show-salesperson')) document.getElementById('inv-show-salesperson').checked = true;
    if (document.getElementById('inv-show-item-code')) document.getElementById('inv-show-item-code').checked = true;
    if (document.getElementById('inv-show-discount-col')) document.getElementById('inv-show-discount-col').checked = true;
    if (document.getElementById('inv-show-dual-currency')) document.getElementById('inv-show-dual-currency').checked = true;

    if (document.getElementById('inv-item-show-brand')) document.getElementById('inv-item-show-brand').checked = true;
    if (document.getElementById('inv-item-show-model')) document.getElementById('inv-item-show-model').checked = true;
    if (document.getElementById('inv-item-show-color')) document.getElementById('inv-item-show-color').checked = true;
    if (document.getElementById('inv-item-show-origin')) document.getElementById('inv-item-show-origin').checked = true;
    if (document.getElementById('inv-item-show-type')) document.getElementById('inv-item-show-type').checked = false;
    if (document.getElementById('inv-item-show-barcode')) document.getElementById('inv-item-show-barcode').checked = false;
    if (document.getElementById('inv-item-show-weight')) document.getElementById('inv-item-show-weight').checked = false;
    if (document.getElementById('inv-item-show-size')) document.getElementById('inv-item-show-size').checked = false;
    if (document.getElementById('inv-item-show-notes')) document.getElementById('inv-item-show-notes').checked = false;
    if (document.getElementById('inv-item-display-mode')) document.getElementById('inv-item-display-mode').value = 'subline';
    if (document.getElementById('inv-item-separator')) document.getElementById('inv-item-separator').value = ' - ';
    
    if (document.getElementById('inv-show-stamp-signature')) document.getElementById('inv-show-stamp-signature').checked = true;
    if (document.getElementById('inv-show-qr')) document.getElementById('inv-show-qr').checked = true;
    if (document.getElementById('inv-show-barcode')) document.getElementById('inv-show-barcode').checked = true;
    if (document.getElementById('inv-terms-text')) document.getElementById('inv-terms-text').value = 'Goods once sold can be exchanged within 7 days with original invoice. / البضاعة المباعة تستبدل خلال 7 أيام بالفاتورة الأصلية.';
    if (document.getElementById('inv-footer-note')) document.getElementById('inv-footer-note').value = 'Thank you for your business! / شكراً لتعاملكم معنا ونسعد بخدمتكم';

    // Reset Font Sizes
    if (document.getElementById('inv-fs-company-name')) document.getElementById('inv-fs-company-name').value = '24px';
    if (document.getElementById('inv-fs-subtitle')) document.getElementById('inv-fs-subtitle').value = '13px';
    if (document.getElementById('inv-fs-header-contact')) document.getElementById('inv-fs-header-contact').value = '12px';
    if (document.getElementById('inv-fs-doc-title')) document.getElementById('inv-fs-doc-title').value = '22px';
    if (document.getElementById('inv-fs-doc-num')) document.getElementById('inv-fs-doc-num').value = '15px';
    if (document.getElementById('inv-fs-meta-text')) document.getElementById('inv-fs-meta-text').value = '12px';
    if (document.getElementById('inv-fs-customer-box')) document.getElementById('inv-fs-customer-box').value = '13px';
    if (document.getElementById('inv-fs-cashier-box')) document.getElementById('inv-fs-cashier-box').value = '13px';
    if (document.getElementById('inv-fs-table-header')) document.getElementById('inv-fs-table-header').value = '12px';
    if (document.getElementById('inv-fs-table-rows')) document.getElementById('inv-fs-table-rows').value = '12px';
    if (document.getElementById('inv-fs-item-subline')) document.getElementById('inv-fs-item-subline').value = '11px';
    if (document.getElementById('inv-fs-totals-box')) document.getElementById('inv-fs-totals-box').value = '12px';
    if (document.getElementById('inv-fs-grand-total')) document.getElementById('inv-fs-grand-total').value = '16px';
    if (document.getElementById('inv-fs-grand_total')) document.getElementById('inv-fs-grand_total').value = '16px';
    if (document.getElementById('inv-fs-cur2-total')) document.getElementById('inv-fs-cur2-total').value = '13px';
    if (document.getElementById('inv-fs-terms')) document.getElementById('inv-fs-terms').value = '11px';
    if (document.getElementById('inv-fs-signatures')) document.getElementById('inv-fs-signatures').value = '12px';
    if (document.getElementById('inv-fs-footer-note')) document.getElementById('inv-fs-footer-note').value = '11px';

    // Reset Custom Fixed Texts
    const txtIds = [
      'inv-txt-doc-title', 'inv-txt-date-label', 'inv-txt-duedate-label', 'inv-txt-tax-id-label',
      'inv-txt-bill-to-label', 'inv-txt-cashier-label', 'inv-txt-payment-label',
      'inv-txt-col-hash', 'inv-txt-col-item', 'inv-txt-col-sku', 'inv-txt-col-qty', 'inv-txt-col-price', 'inv-txt-col-disc', 'inv-txt-col-total',
      'inv-txt-subtotal-label', 'inv-txt-discount-label', 'inv-txt-vat-label', 'inv-txt-grand-total-label', 'inv-txt-cur2-label',
      'inv-txt-terms-label', 'inv-txt-cust-sig-label', 'inv-txt-store-sig-label'
    ];
    txtIds.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });

    updateInvoiceDesignerPreview();
    Utils.toast(isAR ? 'تمت استعادة التصميم الافتراضي' : 'Default design restored', 'info');
  }

  async function testPrintInvoiceDesign() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    await updateInvoiceDesignerPreview();

    const formCo = {
      company_name: document.getElementById('inv-set-comp-name')?.value?.trim() || document.getElementById('set-company-name')?.value || 'Store',
      company_name_ar: document.getElementById('inv-set-comp-name-ar')?.value?.trim() || document.getElementById('set-company-name-ar')?.value || '',
      company_address: document.getElementById('inv-set-comp-address')?.value || document.getElementById('set-company-address')?.value || '',
      company_phone: document.getElementById('inv-set-comp-phone')?.value || document.getElementById('set-company-phone')?.value || '',
      vat_number: document.getElementById('inv-set-vat-num')?.value || document.getElementById('set-vat-num')?.value || '',
      company_logo: window._uploadedLogoBase64 !== undefined ? window._uploadedLogoBase64 : (document.getElementById('inv-company-logo-preview')?.querySelector('img')?.src || document.getElementById('set-company-logo-preview')?.querySelector('img')?.src || ''),
      print_logo: document.getElementById('inv-print-logo')?.checked ?? document.getElementById('set-print-logo')?.checked ?? true,
      currency_1: document.getElementById('set-cur1')?.value || 'USD',
      currency_2: document.getElementById('set-cur2')?.value || 'LBP',
      exchange_rate: parseFloat(document.getElementById('set-exch-rate')?.value) || 89500,
      inv_template: document.getElementById('inv-template')?.value || 'modern',
      inv_primary_color: document.getElementById('inv-primary-color')?.value || '#2563eb',
      inv_font_family: document.getElementById('inv-font-family')?.value || 'Cairo',
      inv_logo_position: document.getElementById('inv-logo-position')?.value || 'left',
      inv_logo_size: parseInt(document.getElementById('inv-logo-size')?.value) || 80,
      inv_header_align: document.getElementById('inv-header-align')?.value || 'left',
      inv_custom_subtitle: document.getElementById('inv-custom-subtitle')?.value || '',
      inv_show_company_name: document.getElementById('inv-show-company-name')?.checked ?? true,
      inv_show_phone: document.getElementById('inv-show-phone')?.checked ?? true,
      inv_show_email: document.getElementById('inv-show-email')?.checked ?? true,
      inv_show_address: document.getElementById('inv-show-address')?.checked ?? true,
      inv_show_vat: document.getElementById('inv-show-vat')?.checked ?? true,
      inv_show_customer_info: document.getElementById('inv-show-customer-info')?.checked ?? true,
      inv_show_salesperson: document.getElementById('inv-show-salesperson')?.checked ?? true,
      inv_show_item_code: document.getElementById('inv-show-item-code')?.checked ?? true,
      inv_show_discount_col: document.getElementById('inv-show-discount-col')?.checked ?? true,
      inv_show_dual_currency: document.getElementById('inv-show-dual-currency')?.checked ?? true,
      inv_show_qr: document.getElementById('inv-show-qr')?.checked ?? true,
      inv_show_barcode: document.getElementById('inv-show-barcode')?.checked ?? true,
      inv_show_stamp_signature: document.getElementById('inv-show-stamp-signature')?.checked ?? true,
      inv_terms_text: document.getElementById('inv-terms-text')?.value || '',
      inv_footer_note: document.getElementById('inv-footer-note')?.value || '',
      inv_item_show_brand: document.getElementById('inv-item-show-brand')?.checked ?? true,
      inv_item_show_model: document.getElementById('inv-item-show-model')?.checked ?? true,
      inv_item_show_color: document.getElementById('inv-item-show-color')?.checked ?? true,
      inv_item_show_origin: document.getElementById('inv-item-show-origin')?.checked ?? true,
      inv_item_show_type: document.getElementById('inv-item-show-type')?.checked ?? false,
      inv_item_show_barcode: document.getElementById('inv-item-show-barcode')?.checked ?? false,
      inv_item_show_weight: document.getElementById('inv-item-show-weight')?.checked ?? false,
      inv_item_show_size: document.getElementById('inv-item-show-size')?.checked ?? false,
      inv_item_show_notes: document.getElementById('inv-item-show-notes')?.checked ?? false,
      inv_item_display_mode: document.getElementById('inv-item-display-mode')?.value || 'subline',
      inv_item_separator: document.getElementById('inv-item-separator')?.value || ' - ',
      inv_receipt_item_layout: document.getElementById('inv-receipt-item-layout')?.value || 'table',
      inv_txt_doc_title: document.getElementById('inv-txt-doc-title')?.value.trim() || '',
      inv_txt_date_label: document.getElementById('inv-txt-date-label')?.value.trim() || '',
      inv_txt_duedate_label: document.getElementById('inv-txt-duedate-label')?.value.trim() || '',
      inv_txt_tax_id_label: document.getElementById('inv-txt-tax-id-label')?.value.trim() || '',
      inv_txt_bill_to_label: document.getElementById('inv-txt-bill-to-label')?.value.trim() || '',
      inv_txt_cashier_label: document.getElementById('inv-txt-cashier-label')?.value.trim() || '',
      inv_txt_payment_label: document.getElementById('inv-txt-payment-label')?.value.trim() || '',
      inv_txt_subtotal_label: document.getElementById('inv-txt-subtotal-label')?.value.trim() || '',
      inv_txt_discount_label: document.getElementById('inv-txt-discount-label')?.value.trim() || '',
      inv_txt_vat_label: document.getElementById('inv-txt-vat-label')?.value.trim() || '',
      inv_txt_grand_total_label: document.getElementById('inv-txt-grand-total-label')?.value.trim() || '',
      inv_txt_cur2_label: document.getElementById('inv-txt-cur2-label')?.value.trim() || '',
      inv_txt_col_item: document.getElementById('inv-txt-col-item')?.value.trim() || '',
      inv_txt_col_qty: document.getElementById('inv-txt-col-qty')?.value.trim() || '',
      inv_txt_col_price: document.getElementById('inv-txt-col-price')?.value.trim() || '',
      inv_txt_col_total: document.getElementById('inv-txt-col-total')?.value.trim() || '',
      // Custom Font Sizes
      inv_fs_company_name: document.getElementById('inv-fs-company-name')?.value || '24px',
      inv_fs_subtitle: document.getElementById('inv-fs-subtitle')?.value || '13px',
      inv_fs_header_contact: document.getElementById('inv-fs-header-contact')?.value || '12px',
      inv_fs_doc_title: document.getElementById('inv-fs-doc-title')?.value || '22px',
      inv_fs_doc_num: document.getElementById('inv-fs-doc-num')?.value || '15px',
      inv_fs_meta_text: document.getElementById('inv-fs-meta-text')?.value || '12px',
      inv_fs_customer_box: document.getElementById('inv-fs-customer-box')?.value || '13px',
      inv_fs_cashier_box: document.getElementById('inv-fs-cashier-box')?.value || '13px',
      inv_fs_table_header: document.getElementById('inv-fs-table-header')?.value || '12px',
      inv_fs_table_rows: document.getElementById('inv-fs-table-rows')?.value || '12px',
      inv_fs_item_subline: document.getElementById('inv-fs-item-subline')?.value || '11px',
      inv_fs_totals_box: document.getElementById('inv-fs-totals-box')?.value || '12px',
      inv_fs_grand_total: document.getElementById('inv-fs-grand-total')?.value || '16px',
      inv_fs_cur2_total: document.getElementById('inv-fs-cur2-total')?.value || '13px',
      inv_fs_terms: document.getElementById('inv-fs-terms')?.value || '11px',
      inv_fs_signatures: document.getElementById('inv-fs-signatures')?.value || '12px',
      inv_fs_footer_note: document.getElementById('inv-fs-footer-note')?.value || '11px'
    };

    const sampleSale = {
      ref: 'POS-00892',
      invoice_no: 'POS-00892',
      created_at: new Date().toISOString(),
      customer_name: isAR ? 'عميل عابر' : 'Walk-in Customer',
      cashier: 'Admin',
      salesperson: 'Admin',
      subtotal: 136.00,
      discount: 9.00,
      discount_amount: 9.00,
      vat: 13.97,
      grand_total: 140.97,
      payment_method: 'cash',
      amount_tendered: 150.00,
      change_amount: 9.03,
      items: [
        {
          code: 'ITM-8841',
          name_en: 'Wireless Noise-Canceling Earbuds Pro',
          name_ar: 'سماعات بلوتوث عازلة للضوضاء برو',
          brand: 'Sony',
          model: 'WF-1000XM5',
          color: isAR ? 'أسود ملكي' : 'Midnight Black',
          origin_country: isAR ? 'اليابان' : 'Japan',
          origin_flag: '🇯🇵',
          type: isAR ? 'صوتيات' : 'Audio',
          barcode: '628100293841',
          qty: 2,
          price: 45.00,
          total: 81.00,
          disc_amount: 9.00
        },
        {
          code: 'ITM-2219',
          name_en: 'Fast USB-C Dual Port Wall Charger 65W',
          name_ar: 'شاحن جداري سريع نوع تايب سي 65 واط',
          brand: 'Anker',
          model: 'GaN 735',
          color: isAR ? 'أبيض' : 'White',
          origin_country: isAR ? 'الولايات المتحدة' : 'USA',
          origin_flag: '🇺🇸',
          type: isAR ? 'شواحن' : 'Chargers',
          barcode: '628100882194',
          qty: 1,
          price: 28.00,
          total: 28.00
        },
        {
          code: 'ITM-5530',
          name_en: 'Tempered Glass Screen Guard 9H Premium',
          name_ar: 'لاصقة حماية شاشة زجاجية بريميوم',
          brand: 'Spigen',
          model: 'AlignMaster',
          color: isAR ? 'شفاف كريستال' : 'Crystal Clear',
          origin_country: isAR ? 'كوريا الجنوبية' : 'S. Korea',
          origin_flag: '🇰🇷',
          type: isAR ? 'اكسسوارات' : 'Accessories',
          barcode: '628100771239',
          qty: 3,
          price: 6.00,
          total: 18.00
        }
      ]
    };

    if (_designerPreviewMode === 'thermal') {
      if (window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
        await window.PrintEngine.printReceipt(sampleSale, sampleSale.items, null, { coOverride: formCo, isTestPrint: true });
      }
    } else {
      if (window.PrintEngine && typeof window.PrintEngine.printInvoice === 'function') {
        await window.PrintEngine.printInvoice(sampleSale, sampleSale.items, null, { coOverride: formCo, isTestPrint: true });
      }
    }
  }

  async function renderInvoiceDesigner(container) {
    await renderSettings(container);
    setTimeout(() => {
      const designerTabBtn = document.querySelector('[data-tab="tab-set-invoice-designer"]');
      if (designerTabBtn) designerTabBtn.click();
    }, 60);
  }

  // ── Custom Printers Hub ─────────────────────────────────────────
  async function openPrinterModal(printerId = null) {
    const isAR = i18n.getLang() === 'ar';
    window._editCustomPrinterId = printerId;
    let p = { name: '', printer_type: 'kitchen', device_name: '', paper_width: '80mm', ip_address: '', active: true };
    if (printerId) {
      const found = await DB.get('kitchen_printers', printerId);
      if (found) p = found;
    }

    // Fetch live installed printers from server
    let printerList = [];
    try {
      const apiUrl = window.location.origin.startsWith('http') ? '/api/printers' : 'http://localhost:3000/api/printers';
      const resp = await fetch(apiUrl, { signal: AbortSignal.timeout(4000) });
      if (resp.ok) {
        const data = await resp.json();
        if (data.success) {
          printerList = data.printers || [];
        }
      }
    } catch (e) {}

    const savedDevice = p.device_name || p.ip_address || '';
    const isIp = /^(\d{1,3}\.){3}\d{1,3}/.test(savedDevice);

    let deviceOptionsHtml = `<option value="">— ${isAR ? 'الطابعة الافتراضية في Windows' : 'Default Windows Printer'} —</option>`;
    if (printerList.length) {
      deviceOptionsHtml += printerList.map(pr => 
        `<option value="${Utils.sanitize(pr.name)}" ${(!isIp && pr.name === savedDevice) ? 'selected' : ''}>🖨️ ${Utils.sanitize(pr.name)}${pr.isDefault ? ' ★' : ''}</option>`
      ).join('');
    } else {
      const presets = [
        'EPSON TM-T20III (Kitchen / 80mm)',
        'Xprinter XP-80C (Bar / 80mm)',
        'Bixolon SRP-330 (Cashier POS)',
        'HP LaserJet Pro (A4 Invoices)',
        'Xprinter XP-365B (Barcode Labels)'
      ];
      deviceOptionsHtml += presets.map(pr => 
        `<option value="${pr}" ${(!isIp && pr === savedDevice) ? 'selected' : ''}>🖨️ ${pr}</option>`
      ).join('');
    }
    deviceOptionsHtml += `<option value="__custom_ip__" ${isIp ? 'selected' : ''}>🌐 ${isAR ? 'عنوان شبكة مخصص (Ethernet / WiFi IP)' : 'Custom Network IP (Ethernet / WiFi)'}</option>`;

    const modalHtml = `
    <div class="modal-overlay open" id="custom-printer-modal" style="z-index:9999">
      <div class="modal" style="max-width:540px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">
            🖨️ ${printerId ? (isAR ? 'تعديل الطابعة' : 'Edit Printer') : (isAR ? 'إضافة طابعة جديدة' : 'Add New Printer')}
          </div>
          <button class="btn-icon" onclick="document.getElementById('custom-printer-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:20px">
          <div class="form-group" style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700">${isAR ? 'اسم الطابعة المخصص (مثال: طابعة الشاورما / بار المشروبات):' : 'Printer Display Name (e.g. Kitchen Grill / Juice Bar):'} *</label>
            <input type="text" class="form-control" id="cp-name" value="${Utils.sanitize(p.name)}" placeholder="e.g. Main Kitchen / Bar 1" required style="font-size:1rem;font-weight:700">
          </div>

          <div class="grid grid-2" style="gap:12px;margin-bottom:14px">
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'نوع / وجهة الطابعة:' : 'Station / Routing Type:'}</label>
              <select class="form-control" id="cp-type">
                <option value="kitchen" ${p.printer_type === 'kitchen' ? 'selected' : ''}>🍳 ${isAR ? 'مطبخ ومأكولات (Kitchen Food KOT)' : 'Kitchen Food (KOT)'}</option>
                <option value="bar" ${p.printer_type === 'bar' ? 'selected' : ''}>🍹 ${isAR ? 'بار ومشروبات (Bar & Drinks KOT)' : 'Bar & Beverages (KOT)'}</option>
                <option value="dessert" ${p.printer_type === 'dessert' ? 'selected' : ''}>🍰 ${isAR ? 'حلويات ومخبوزات (Desserts)' : 'Desserts & Sweets'}</option>
                <option value="shisha" ${p.printer_type === 'shisha' ? 'selected' : ''}>💨 ${isAR ? 'شيشة وتراس (Shisha)' : 'Shisha & Outdoor'}</option>
                <option value="receipt" ${p.printer_type === 'receipt' ? 'selected' : ''}>🧾 ${isAR ? 'كاشير وإيصالات (POS Receipt)' : 'Cashier Receipt'}</option>
                <option value="document" ${p.printer_type === 'document' ? 'selected' : ''}>📄 ${isAR ? 'فواتير A4 ومستندات' : 'A4 Invoices & Reports'}</option>
                <option value="label" ${p.printer_type === 'label' ? 'selected' : ''}>🏷️ ${isAR ? 'ملصقات باركود (Labels)' : 'Barcode Labels'}</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'حجم الورق:' : 'Paper Size:'}</label>
              <select class="form-control" id="cp-paper">
                <option value="80mm" ${p.paper_width === '80mm' ? 'selected' : ''}>🧾 80mm (${isAR ? 'حراري قياسي' : 'Thermal Standard'})</option>
                <option value="58mm" ${p.paper_width === '58mm' ? 'selected' : ''}>🧾 58mm (${isAR ? 'حراري صغير' : 'Small Thermal'})</option>
                <option value="A4" ${p.paper_width === 'A4' ? 'selected' : ''}>📄 A4</option>
                <option value="50x30mm" ${p.paper_width === '50x30mm' ? 'selected' : ''}>🏷️ 50 × 30 mm (${isAR ? 'ملصق' : 'Label'})</option>
              </select>
            </div>
          </div>

          <!-- Windows Installed Printer Selection Dropdown -->
          <div class="form-group" style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700;display:flex;align-items:center;gap:6px">
              <span>🖨️</span> ${isAR ? 'اختر جهاز الطابعة المثبت في الكمبيوتر أو الشبكة:' : 'Select Installed Windows Printer or Network IP:'}
            </label>
            <select class="form-control" id="cp-device-select" onchange="document.getElementById('cp-custom-ip-group').style.display = this.value === '__custom_ip__' ? 'block' : 'none'" style="font-weight:700">
              ${deviceOptionsHtml}
            </select>
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">
              ${isAR ? '★ = الطابعة الافتراضية في Windows' : '★ = Windows default printer'}
            </div>
          </div>

          <!-- Custom IP Address Input (shown when Custom IP is chosen) -->
          <div class="form-group" id="cp-custom-ip-group" style="margin-bottom:14px;display:${isIp ? 'block' : 'none'}">
            <label class="form-label" style="font-weight:700">${isAR ? 'عنوان IP الخاص بالطابعة على الشبكة:' : 'Network IP Address:'}</label>
            <input type="text" class="form-control" id="cp-device-ip" value="${Utils.sanitize(isIp ? savedDevice : '')}" placeholder="e.g. 192.168.1.105" style="font-family:monospace;font-weight:700">
          </div>

          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:10px">
            <div>
              <div style="font-weight:700;font-size:0.88rem">${isAR ? 'تفعيل الطابعة' : 'Enable Printer'}</div>
              <div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'استقبال بونات المطبخ والإيصالات تلقائياً' : 'Receive orders and tickets automatically'}</div>
            </div>
            <label class="toggle">
              <input type="checkbox" id="cp-active" ${p.active !== false ? 'checked' : ''}>
              <span class="toggle-slider"></span>
            </label>
          </div>
        </div>

        <div class="modal-footer" style="padding:14px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:10px">
          <button class="btn btn-secondary" onclick="document.getElementById('custom-printer-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Admin.savePrinterModal()">💾 ${isAR ? 'حفظ الطابعة' : 'Save Printer'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  async function savePrinterModal() {
    const isAR = i18n.getLang() === 'ar';
    const name = document.getElementById('cp-name')?.value.trim();
    if (!name) {
      Utils.toast(isAR ? 'يرجى إدخال اسم الطابعة' : 'Please enter printer name', 'warning');
      return;
    }

    const selectedDev = document.getElementById('cp-device-select')?.value;
    let finalDevice = selectedDev;
    if (selectedDev === '__custom_ip__') {
      finalDevice = document.getElementById('cp-device-ip')?.value.trim() || '';
    }

    const data = {
      name: name,
      printer_type: document.getElementById('cp-type')?.value || 'kitchen',
      paper_width: document.getElementById('cp-paper')?.value || '80mm',
      device_name: finalDevice,
      ip_address: finalDevice,
      active: document.getElementById('cp-active')?.checked !== false,
      updated_at: new Date().toISOString()
    };

    if (window._editCustomPrinterId) {
      await DB.update('kitchen_printers', { ...data, id: window._editCustomPrinterId });
    } else {
      await DB.add('kitchen_printers', data);
    }

    document.getElementById('custom-printer-modal')?.remove();
    Utils.toast(isAR ? 'تم حفظ الطابعة بنجاح' : 'Printer saved successfully', 'success');
    await renderSettings(document.getElementById('page-content'));
    setTimeout(() => {
      document.querySelector('[data-tab="tab-set-print"]')?.click();
    }, 60);
  }

  async function deletePrinterModal(id) {
    const isAR = i18n.getLang() === 'ar';
    if (!confirm(isAR ? 'هل أنت متأكد من حذف هذه الطابعة؟' : 'Delete this printer?')) return;
    await DB.remove('kitchen_printers', id);
    Utils.toast(isAR ? 'تم حذف الطابعة' : 'Printer deleted', 'success');
    await renderSettings(document.getElementById('page-content'));
    setTimeout(() => {
      document.querySelector('[data-tab="tab-set-print"]')?.click();
    }, 60);
  }

  async function updateCategoryPrinter(categoryId, printerId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const cat = await DB.get('categories', categoryId);
    if (!cat) return;
    cat.printer_id = printerId ? parseInt(printerId, 10) : null;
    await DB.update('categories', cat);
    Utils.toast(isAR ? `تم تحديث توجيه طباعة قسم: ${cat.name_ar || cat.name}` : `Printer routing updated for: ${cat.name}`, 'success');
    await renderSettings(document.getElementById('page-content'));
    setTimeout(() => {
      document.querySelector('[data-tab="tab-set-print"]')?.click();
    }, 60);
  }

  async function testPrintCustomPrinter(id) {
    const isAR = i18n.getLang() === 'ar';
    const p = await DB.get('kitchen_printers', id);
    if (!p) return;

    const companyName = await DB.getSetting('company_name', 'Red Shark Restaurant');
    const width = p.paper_width || '80mm';

    const testHtml = `
      <style>
        @page { size: ${width === '58mm' ? '58mm auto' : '80mm auto'}; margin: 2mm; }
        body { font-family: 'Courier New', monospace; font-size: 12px; color: #000; padding: 6px; text-align: center; }
        .ticket { border: 2px dashed #000; padding: 10px; border-radius: 6px; }
      </style>
      <div class="ticket">
        <h2 style="margin:0 0 4px;font-size:16px">${Utils.sanitize(companyName)}</h2>
        <div style="font-weight:bold;font-size:13px;margin-bottom:6px">*** TEST TICKET ***</div>
        <div style="border-top:1px solid #000;border-bottom:1px solid #000;padding:4px 0;margin:6px 0;text-align:left;font-size:11px">
          <div><strong>Station:</strong> ${Utils.sanitize(p.name)}</div>
          <div><strong>Type:</strong> ${p.printer_type.toUpperCase()}</div>
          <div><strong>Device:</strong> ${Utils.sanitize(p.device_name || 'Default')}</div>
          <div><strong>Time:</strong> ${new Date().toLocaleTimeString()}</div>
        </div>
        <div style="font-size:11px;margin:8px 0;text-align:left">
          <div>✓ Communication OK</div>
          <div>✓ Paper Cutter OK</div>
          <div>✓ Arabic / Latin Text OK</div>
        </div>
        <div style="font-size:10px;border-top:1px dashed #000;padding-top:4px">
          Red Shark POS Multi-Printer Routing
        </div>
      </div>
    `;

    Utils.printElement(testHtml, `TestPrint-${p.name}`);
  }

  // ── Test Print ─────────────────────────────────────────────────
  async function testPrint(type) {
    const isAR = i18n.getLang() === 'ar';
    const sizes = {
      receipt: document.getElementById('set-receipt-size')?.value || await DB.getSetting('receipt_size','80mm'),
      document: document.getElementById('set-invoice-size')?.value || await DB.getSetting('invoice_size','A4'),
      label: document.getElementById('set-po-size')?.value || await DB.getSetting('po_size','40x30mm'),
    };
    const size = sizes[type] || 'A4';
    const names = { receipt: isAR?'إيصال':'Receipt', document: isAR?'فاتورة':'Invoice', label: isAR?'ملصق':'Label' };
    const companyName = document.getElementById('set-company-name')?.value || await DB.getSetting('company_name','Store');

    // Build CSS @page size
    const pageSizeMap = {
      '80mm':'80mm auto', '58mm':'58mm auto',
      'A4':'A4', 'A5':'A5', 'Letter':'Letter', 'Legal':'Legal',
      '40x30mm':'40mm 30mm','50x30mm':'50mm 30mm',
      '58x40mm':'58mm 40mm','100x50mm':'100mm 50mm',
    };
    const pageCSS = pageSizeMap[size] || 'A4';
    const isThermal = size === '80mm' || size === '58mm' || size.includes('mm');

    if (type === 'label') {
      const orientation = document.getElementById('set-label-orientation')?.value || await DB.getSetting('label_orientation', 'portrait');
      const showName = document.getElementById('set-label-show-name')?.checked ?? await DB.getSetting('label_show_name', true);
      const showCode = document.getElementById('set-label-show-code')?.checked ?? await DB.getSetting('label_show_code', true);
      const showBarcode = document.getElementById('set-label-show-barcode')?.checked ?? await DB.getSetting('label_show_barcode', true);
      const showDigits = document.getElementById('set-label-show-digits')?.checked ?? await DB.getSetting('label_show_digits', true);
      const showPrice = document.getElementById('set-label-show-price')?.checked ?? await DB.getSetting('label_show_price', true);
      const showCompany = document.getElementById('set-label-show-company')?.checked ?? await DB.getSetting('label_show_company', false);

      const sizeDims = {
        '40x30mm': { w: 40, h: 30, barH: 20, barW: 1.3 },
        '50x30mm': { w: 50, h: 30, barH: 22, barW: 1.4 },
        '58x40mm': { w: 58, h: 40, barH: 28, barW: 1.5 },
        '100x50mm': { w: 100, h: 50, barH: 38, barW: 1.8 },
        'A4': { w: 210, h: 297, barH: 26, barW: 1.4 }
      };
      const dims = sizeDims[size] || { w: 50, h: 30, barH: 22, barW: 1.4 };

      let rotDeg = 0;
      if (orientation === 'rotate90' || orientation === 'landscape' || orientation === '90') rotDeg = 90;
      else if (orientation === 'rotate180' || orientation === '180') rotDeg = 180;
      else if (orientation === 'rotate270' || orientation === '270') rotDeg = 270;

      const barcodeSVG = Utils.generateBarcodeSVG('ITM-00001', { height: dims.barH, barWidth: dims.barW });

      const labelHtml = `
        <style>
          @page { size: ${dims.w}mm ${dims.h}mm; margin: 0mm; }
          * { box-sizing: border-box; margin: 0; padding: 0; }
          html, body { background: #fff; color: #000; font-family: 'Cairo', 'Inter', sans-serif; }
          .label-page {
            width: ${dims.w}mm;
            height: ${dims.h}mm;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: #fff;
          }
          .barcode-label-card {
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            overflow: hidden;
            padding: 1mm 1.5mm;
            border: 1px dashed #475569;
            border-radius: 4px;
            ${rotDeg === 90 || rotDeg === 270 ? `
              width: ${dims.h - 1.5}mm;
              height: ${dims.w - 1.5}mm;
              transform: rotate(${rotDeg}deg);
              transform-origin: center center;
            ` : rotDeg === 180 ? `
              width: ${dims.w - 1.5}mm;
              height: ${dims.h - 1.5}mm;
              transform: rotate(180deg);
            ` : `
              width: ${dims.w - 1.5}mm;
              height: ${dims.h - 1.5}mm;
            `}
          }
          .lbl-company { font-size: 6pt; font-weight: 700; color: #475569; line-height: 1; }
          .lbl-name { font-size: 7.5pt; font-weight: 800; line-height: 1.1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; }
          .lbl-code { font-size: 6pt; color: #475569; line-height: 1; }
          .lbl-barcode-box { width: 100%; display: flex; justify-content: center; margin: 0.5mm auto; }
          .lbl-val { font-size: 6pt; font-family: monospace; letter-spacing: 0.5px; line-height: 1; }
          .lbl-price { font-size: 8pt; font-weight: 900; color: #000; line-height: 1; }
        </style>
        <div class="label-page">
          <div class="barcode-label-card">
            ${showCompany ? `<div class="lbl-company">${Utils.sanitize(companyName)}</div>` : ''}
            ${showName ? `<div class="lbl-name">Sample Product 1</div>` : ''}
            ${showCode ? `<div class="lbl-code">ITM-00001</div>` : ''}
            ${showBarcode ? `<div class="lbl-barcode-box">${barcodeSVG}</div>` : ''}
            ${showDigits ? `<div class="lbl-val">ITM-00001</div>` : ''}
            ${showPrice ? `<div class="lbl-price">$15.00</div>` : ''}
          </div>
        </div>`;

      return Utils.printElement(labelHtml, `TestPrint-Label`, size);
    }

    if ((type === 'receipt' && isThermal) || (type === 'document' && isThermal)) {
      if (window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
        const sampleSale = {
          ref: 'POS-' + Math.floor(Math.random() * 9000 + 1000),
          created_at: new Date().toISOString(),
          customer_name: isAR ? 'عميل تجريبي' : 'Walk-in Customer',
          salesperson: isAR ? 'مدير النظام' : 'Administrator',
          payment_method: 'cash',
          subtotal: 90000,
          discount: 0,
          vat: 0,
          grand_total: 90000,
          amount_tendered: 100000,
          change_amount: 10000,
          points_earned: 5
        };
        const sampleItems = [
          { name_ar: 'سماعات بلوتوث عازلة للضوضاء برو', name_en: 'Wireless Noise-Canceling Earbuds Pro', brand: 'Sony', model: 'WF-1000XM5', color: isAR ? 'أسود' : 'Black', barcode: '628100293841', qty: 1, price: 50000, total: 50000 },
          { name_ar: 'شاحن جداري سريع نوع تايب سي 65 واط', name_en: 'Fast USB-C Dual Port Wall Charger 65W', brand: 'Anker', model: 'GaN 735', color: isAR ? 'أبيض' : 'White', barcode: '628100882194', qty: 2, price: 20000, total: 40000 }
        ];
        return window.PrintEngine.printReceipt(sampleSale, sampleItems, { name_ar: 'عميل تجريبي', name_en: 'Sample Customer' }, { doc_title: isAR ? 'إيصال مبيعات' : 'SALES RECEIPT', pageSize: size });
      }
    }

    if ((type === 'document' && !isThermal) || (type === 'receipt' && !isThermal)) {
      if (window.PrintEngine && typeof window.PrintEngine.printInvoice === 'function') {
        const sampleSale = {
          invoice_no: 'INV-2026-' + Math.floor(Math.random() * 9000 + 1000),
          created_at: new Date().toISOString(),
          customer_name: isAR ? 'شركة العميل التجريبية' : 'Sample Customer LLC',
          salesperson: isAR ? 'مدير النظام' : 'Administrator',
          payment_method: 'cash',
          subtotal: 100,
          discount: 10,
          vat: 9.9,
          grand_total: 99.9
        };
        const sampleItems = [
          { name_ar: 'سماعات بلوتوث عازلة للضوضاء برو', name_en: 'Wireless Noise-Canceling Earbuds Pro', code: 'ITM-8841', brand: 'Sony', model: 'WF-1000XM5', color: isAR ? 'أسود' : 'Black', qty: 1, price: 45, total: 45 },
          { name_ar: 'شاحن جداري سريع نوع تايب سي 65 واط', name_en: 'Fast USB-C Dual Port Wall Charger 65W', code: 'ITM-2219', brand: 'Anker', model: 'GaN 735', color: isAR ? 'أبيض' : 'White', qty: 1, price: 55, total: 55 }
        ];
        return window.PrintEngine.printInvoice(sampleSale, sampleItems, { name_ar: 'شركة العميل', name_en: 'Sample Client' }, { pageSize: size });
      }
    }

    const html = `
      <style>
        @page { size: ${pageCSS}; margin: ${isThermal ? '2mm' : '15mm'}; }
        body { font-family: 'Cairo', 'Inter', sans-serif; font-size: ${isThermal ? '11px' : '14px'}; color: #000; padding: 10px; }
        .test-box { border: 2px dashed #333; padding: 15px; text-align: center; border-radius: 8px; margin-bottom: 10px; }
      </style>
      <div class="test-box">
        <h2 style="margin:0 0 6px">${companyName}</h2>
        <h3 style="margin:0 0 4px;color:#0f172a">${names[type]} ${isAR ? 'اختبار طباعة' : 'Test Print'}</h3>
        <p style="margin:4px 0;font-size:0.85em">${isAR ? 'الحجم المعتمد:' : 'Paper Size:'} <strong>${size}</strong></p>
        <p style="margin:4px 0;font-size:0.85em">${isAR ? 'الوقت:' : 'Time:'} ${new Date().toLocaleString()}</p>
        <hr style="border:none;border-top:1px dashed #666;margin:10px 0">
        <p style="margin:0;font-size:0.75em">${isAR ? 'تم إرسال هذا المستند للاختبار بنجاح' : 'Test print output verified successfully'}</p>
      </div>`;

    const testData = {
      store_name: companyName || 'Red Shark POS Store',
      doc_title: `${names[type]} ${isAR ? 'اختبار طباعة' : 'Test Print'}`,
      ref: 'TEST-' + Math.floor(Math.random() * 900 + 100),
      date: new Date().toLocaleString(),
      customer: isAR ? 'عميل تجريبي' : 'Sample Customer',
      cashier: isAR ? 'مدير النظام' : 'Administrator',
      paper_size: size,
      items: [
        { name: isAR ? 'منتج اختباري 1' : 'Sample Product 1', qty: 1, price: '10.00', total: '10.00' },
        { name: isAR ? 'منتج اختباري 2' : 'Sample Product 2', qty: 2, price: '5.00', total: '10.00' }
      ],
      subtotal: '20.00',
      grand_total: '20.00',
      footer: isAR ? 'تم إرسال هذا المستند للاختبار بنجاح' : 'Test print output verified successfully'
    };

    Utils.printElement(html, `TestPrint-${type}`, size, testData);
  }

  async function testPoleDisplay() {
    const isAR = i18n.getLang() === 'ar';
    const port = document.getElementById('set-pole-display-port')?.value || 'auto';
    const baud = parseInt(document.getElementById('set-pole-display-baud')?.value) || 2400;

    try {
      Utils.toast(isAR ? `جاري إرسال اختبار للشاشة (${port})...` : `Sending test amount to pole display (${port})...`, 'info');
      const apiUrl = window.location.origin.startsWith('http') ? '/api/customer-display/send' : 'http://localhost:3000/api/customer-display/send';
      const resp = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: '88.88',
          status: 'total',
          port: port,
          baud: baud
        })
      });
      const data = await resp.json();
      if (data.success) {
        const portsDisplay = Array.isArray(data.ports) ? data.ports.join(', ') : (data.port || port);
        Utils.toast(isAR ? `✅ تم إرسال 88.88 إلى الشاشة بنجاح على (${portsDisplay})` : `✅ Successfully sent 88.88 to display on (${portsDisplay})`, 'success');
      } else {
        Utils.toast(isAR ? `❌ فشل الاتصال بالشاشة: ${data.error || ''}` : `❌ Pole display failed: ${data.error || ''}`, 'danger');
      }
    } catch (e) {
      Utils.toast(isAR ? '❌ تعذر الوصول لخادم الشاشة' : '❌ Customer display server unreachable', 'danger');
    }
  }

  // ── Backup ─────────────────────────────────────────────────────
  async function renderBackup(container) {
    const isAR = i18n.getLang() === 'ar';

    const cardsHTML = `
      <div class="card">
        <div class="card-header"><div class="card-title">💾 ${isAR?'تصدير نسخة احتياطية':'Export Backup'}</div></div>
        <div class="modal-body" style="display:flex;flex-direction:column;justify-content:space-between;height:100%">
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:16px">${isAR?'تنزيل ملف يحتوي جميع بيانات النظام بالكامل (JSON)':'Download a complete system backup file'}</p>
          <button class="btn btn-primary" onclick="Admin.exportBackup()" style="margin-top:auto">${isAR?'تصدير البيانات الآن':'Export Backup Now'}</button>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">📂 ${isAR?'استيراد نسخة احتياطية':'Import Backup'}</div></div>
        <div class="modal-body" style="display:flex;flex-direction:column;justify-content:space-between;height:100%">
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:16px">${isAR?'استعادة بيانات النظام من ملف JSON محلي':'Restore system data from a JSON backup file'}</p>
          <input type="file" id="backup-file" accept=".json" class="form-control" style="margin-bottom:12px">
          <button class="btn btn-warning" onclick="Admin.importBackup()" style="margin-top:auto">${isAR?'استيراد واستعادة البيانات':'Import & Restore'}</button>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">📊 ${isAR?'استيراد الأصناف (إكسل)':'Import Items (Excel)'}</div></div>
        <div class="modal-body" style="display:flex;flex-direction:column;justify-content:space-between;height:100%">
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:16px">${isAR?'استيراد قائمة أصناف جديدة أو تحديث الأصناف الحالية من ملف Excel أو CSV':'Import a list of new items or update existing ones from an Excel or CSV file'}</p>
          <div style="display:flex;gap:10px;margin-bottom:12px;align-items:center">
            <input type="file" id="excel-file" accept=".xlsx, .xls, .csv" class="form-control" style="flex:1">
            <button class="btn btn-secondary" onclick="Admin.downloadExcelSample()" title="${isAR?'تنزيل ملف عينة إكسل':'Download Sample Excel'}" style="padding:6px 12px;white-space:nowrap;font-size:0.75rem;height:35px;font-weight:700">
              ⬇️ ${isAR?'عينة إكسل':'Sample'}
            </button>
          </div>
          <div style="display:flex;gap:8px;margin-top:auto">
            <button class="btn btn-success" onclick="Admin.importItemsExcel()" style="flex:1;font-weight:700">${isAR?'بدء الاستيراد':'Start Import'}</button>
            <button class="btn btn-secondary" onclick="if(window.Items) Items.openImportExcelModal()" title="${isAR?'فتح نافذة الاستيراد المتقدمة':'Open Advanced Import Wizard'}" style="font-weight:700;white-space:nowrap">
              ⚡ ${isAR?'المعالج':'Wizard'}
            </button>
          </div>
        </div>
      </div>
      <div class="card" style="border: 1px solid var(--primary);">
        <div class="card-header" style="background: rgba(59,130,246,0.08); border-bottom: 1px solid var(--primary);">
          <div class="card-title" style="color: var(--primary)">🗄️ ${isAR?'مستعرض ومحرر قاعدة البيانات':'Database Inspector & Table Editor'}</div>
        </div>
        <div class="modal-body" style="display:flex;flex-direction:column;justify-content:space-between;height:100%">
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:16px">${isAR?'استعراض كافة الجداول، البحث داخل السجلات، التعديل المباشر، وحذف أو إضافة البيانات (خاص بالمالك بالرمز 0wner)':'Inspect all database tables, search columns, edit raw records & export tables (Protected by Owner Password)'}</p>
          <button class="btn btn-primary" onclick="Admin.openDbInspector()" style="margin-top:auto;font-weight:700">🔍 ${isAR?'فتح محرر الجداول الآن':'Open DB Inspector'}</button>
        </div>
      </div>
      <div class="card" style="border: 1px solid var(--danger);">
        <div class="card-header" style="background: rgba(239,68,68,0.05); border-bottom: 1px solid var(--danger);"><div class="card-title" style="color: var(--danger)">⚠️ ${isAR?'إعادة تعيين قاعدة البيانات':'Reset Database'}</div></div>
        <div class="modal-body" style="display:flex;flex-direction:column;justify-content:space-between;height:100%">
          <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:16px">${isAR?'مسح كافة بيانات النظام بالكامل والعودة للحالة الافتراضية الأولى':'Wipe all transactions and settings and return to clean seeded state'}</p>
          <button class="btn btn-danger" onclick="Admin.resetDatabase()" style="margin-top:auto">${isAR?'إعادة تعيين الآن':'Reset Database Now'}</button>
        </div>
      </div>
    `;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'النسخ الاحتياطي والصيانة' : 'Backup & Maintenance'}</h1>
        </div>
      </div>
      <div class="grid grid-3" style="gap:20px">
        ${cardsHTML}
      </div>
    </div>`;
  }

  async function exportBackup() {
    const stores = [
      'settings', 'users', 'roles', 'categories', 'items', 'customers', 'suppliers',
      'sales', 'sale_items', 'quotation', 'sales_orders', 'delivery_order', 'sales_invoice',
      'sales_returns', 'purchase_orders', 'po_items', 'goods_receipts', 'grn_items',
      'purchase_invoices', 'purchase_returns', 'stock_adjustments', 'stock_movements',
      'accounts', 'journals', 'journal_lines', 'cash_transactions', 'bank_accounts',
      'bank_transactions', 'employees', 'departments', 'attendance', 'leave_requests',
      'payroll_runs', 'payroll_lines', 'audit_log', 'currencies', 'price_lists',
      'warehouses', 'sequences', 'cashbox_sessions', 'cashbox_movements', 'repair_jobs'
    ];
    const backup = {};
    for (const s of stores) { backup[s] = await DB.getAll(s); }
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `nexpos_backup_${Utils.today()}.json`;
    a.click();
    Utils.toast('Backup exported successfully', 'success');
  }

  async function importBackup() {
    const file = document.getElementById('backup-file')?.files[0];
    if (!file) return Utils.toast('Please select a backup file', 'warning');
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = JSON.parse(e.target.result);
        for (const [store, records] of Object.entries(data)) {
          if (Array.isArray(records)) {
            await DB.clear(store);
            for (const r of records) { await DB.add(store, r); }
          }
        }
        Utils.toast('Backup restored successfully!', 'success');
        location.reload();
      } catch(err) { Utils.toast('Import failed: ' + err.message, 'error'); }
    };
    reader.readAsText(file);
  }

  async function clearSalesData() {
    Utils.confirm('Are you sure you want to clear all sales data?', async () => {
      await DB.clear('sales');
      await DB.clear('sales_invoice');
      Utils.toast('Sales data cleared', 'info');
    });
  }

  async function resetDatabase() {
    const isAR = i18n.getLang() === 'ar';
    Utils.confirm(
      isAR 
        ? '⚠️ هل أنت متأكد من رغبتك في إعادة تعيين قاعدة البيانات بالكامل؟ سيتم مسح كافة البيانات والعودة للتهيئة الافتراضية الأولى.' 
        : '⚠️ Are you sure you want to reset the database? This will clear all transactions, items, warehouses, and users, and restore default settings.',
      async () => {
        const stores = [
          'settings', 'users', 'roles', 'categories', 'items', 'customers', 'suppliers',
          'sales', 'sale_items', 'quotation', 'sales_orders', 'delivery_order', 'sales_invoice',
          'sales_returns', 'purchase_orders', 'po_items', 'goods_receipts', 'grn_items',
          'purchase_invoices', 'purchase_returns', 'stock_adjustments', 'stock_movements',
          'accounts', 'journals', 'journal_lines', 'cash_transactions', 'bank_accounts',
          'bank_transactions', 'employees', 'departments', 'attendance', 'leave_requests',
          'payroll_runs', 'payroll_lines', 'audit_log', 'currencies', 'price_lists',
          'warehouses', 'sequences', 'cashbox_sessions', 'cashbox_movements', 'repair_jobs'
        ];
        for (const s of stores) {
          await DB.clear(s);
        }
        await DB.seed();
        Utils.toast(isAR ? 'تمت إعادة تعيين النظام بالكامل بنجاح!' : 'Database reset successfully!', 'success');
        setTimeout(() => {
          location.reload();
        }, 1000);
      }
    );
  }

  // ── Owner Database Inspector & Table Editor ──────────────────
  const ALL_TABLES = [
    'items', 'categories', 'customers', 'suppliers', 'repair_jobs', 'sales', 'sale_items',
    'purchase_orders', 'purchase_invoices', 'goods_receipts', 'accounts', 'journals',
    'cash_transactions', 'cashbox_sessions', 'cashbox_movements', 'bank_accounts',
    'employees', 'attendance', 'payroll_runs', 'users', 'roles', 'settings', 'warehouses', 'offers'
  ];

  let _inspectorCurrentTable = 'items';
  let _inspectorTableData = [];

  async function openDbInspector() {
    const isAR = i18n.getLang() === 'ar';
    const user = Auth.getUser();
    
    if (user?.role !== 'owner') {
      Utils.promptPassword(
        isAR ? '🔒 التحقق من صلاحيات المالك' : '🔒 Owner Authorization Required',
        isAR ? 'أدخل كلمة مرور المالك للوصول إلى محرر قاعدة البيانات وقراءة الجداول:' : 'Enter Owner Master Password to access raw database editor:',
        (enteredPin) => {
          if (enteredPin === '0wner' || enteredPin === 'Owner') {
            _showDbInspectorModal();
          } else {
            Utils.toast(isAR ? 'كلمة المرور غير صحيحة' : 'Invalid Owner Password', 'error');
          }
        }
      );
    } else {
      _showDbInspectorModal();
    }
  }

  async function _showDbInspectorModal() {
    const isAR = i18n.getLang() === 'ar';
    const modalId = 'owner-db-inspector-modal';
    document.getElementById(modalId)?.remove();

    _inspectorTableData = (await DB.getAll(_inspectorCurrentTable)) || [];

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9990">
      <div class="modal" style="max-width:1150px;max-height:94vh;display:flex;flex-direction:column">
        <div class="modal-header" style="background:var(--surface-2)">
          <div class="modal-title" style="display:flex;align-items:center;gap:8px">
            🗄️ ${isAR ? 'مستعرض ومحرر قاعدة البيانات للمالك' : 'Owner Database Inspector & Table Editor'}
          </div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        
        <!-- Toolbar -->
        <div style="padding:12px;background:var(--surface);border-bottom:1px solid var(--border-color);display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:space-between">
          <div style="display:flex;gap:10px;align-items:center;flex:1;min-width:300px">
            <label style="font-weight:700;font-size:0.85rem">${isAR ? 'اختر الجدول:' : 'Table:'}</label>
            <select class="form-control" id="insp-table-select" onchange="Admin.onInspectorTableChange(this.value)" style="max-width:200px;font-weight:700">
              ${ALL_TABLES.map(t => `<option value="${t}" ${t === _inspectorCurrentTable ? 'selected' : ''}>${t}</option>`).join('')}
            </select>
            <input type="text" class="form-control" id="insp-search" placeholder="${isAR ? 'بحث داخل السجلات...' : 'Filter records...'}" oninput="Admin.onInspectorSearch(this.value)" style="max-width:240px">
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-secondary btn-sm" onclick="Admin.downloadDecryptedBackup()" title="${isAR ? 'تنزيل نسخة JSON مفكوكة التشفير' : 'Export Decrypted JSON'}">
              ⬇️ ${isAR ? 'تصدير JSON' : 'Export JSON'}
            </button>
            <button class="btn btn-secondary btn-sm" onclick="Admin.exportInspectorCSV()">
              📊 ${isAR ? 'تصدير إكسل' : 'Export CSV'}
            </button>
            <button class="btn btn-primary btn-sm" onclick="Admin.openAddRecordModal()">
              ➕ ${isAR ? 'إضافة سجل' : 'Add Record'}
            </button>
          </div>
        </div>

        <!-- Table View -->
        <div class="modal-body" id="insp-table-body" style="flex:1;overflow:auto;padding:12px">
          ${_renderInspectorTableHTML(isAR)}
        </div>
        
        <div class="modal-footer" style="background:var(--surface-2);justify-content:space-between">
          <span style="font-size:0.8rem;color:var(--text-muted)">
            ${isAR ? 'إجمالي السجلات:' : 'Total Records:'} <strong>${_inspectorTableData.length}</strong>
          </span>
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  function _renderInspectorTableHTML(isAR) {
    if (!_inspectorTableData.length) {
      return `<div style="text-align:center;padding:40px;color:var(--text-muted)">${isAR ? 'الجدول فارغ' : 'Table is empty'}</div>`;
    }

    const sample = _inspectorTableData[0] || {};
    const cols = Object.keys(sample).slice(0, 10);

    return `
    <div class="table-wrapper">
      <table style="font-size:0.78rem">
        <thead><tr>
          ${cols.map(c => `<th>${c}</th>`).join('')}
          <th style="text-align:center;width:90px">${isAR ? 'إجراءات' : 'Actions'}</th>
        </tr></thead>
        <tbody>
          ${_inspectorTableData.map(row => {
            const rowId = row.id !== undefined ? row.id : (row.key || row.code);
            return `
            <tr>
              ${cols.map(c => {
                let val = row[c];
                if (typeof val === 'object' && val !== null) val = JSON.stringify(val);
                return `<td style="max-width:140px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${Utils.sanitize(String(val||''))}">${Utils.sanitize(Utils.truncate(String(val !== undefined ? val : '-'), 30))}</td>`;
              }).join('')}
              <td style="text-align:center">
                <button class="btn btn-secondary btn-xs" onclick="Admin.openEditRecordModal('${rowId}')" title="${isAR?'تعديل':'Edit'}" style="padding:2px 6px">✏️</button>
                <button class="btn btn-danger btn-xs" onclick="Admin.deleteRecordAction('${rowId}')" title="${isAR?'حذف':'Delete'}" style="padding:2px 6px">✕</button>
              </td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
  }

  async function onInspectorTableChange(tableName) {
    _inspectorCurrentTable = tableName;
    _inspectorTableData = (await DB.getAll(tableName)) || [];
    const body = document.getElementById('insp-table-body');
    if (body) body.innerHTML = _renderInspectorTableHTML(i18n.getLang() === 'ar');
  }

  function onInspectorSearch(query) {
    const q = (query || '').toLowerCase();
    const isAR = i18n.getLang() === 'ar';
    DB.getAll(_inspectorCurrentTable).then(allData => {
      _inspectorTableData = allData.filter(row => JSON.stringify(row).toLowerCase().includes(q));
      const body = document.getElementById('insp-table-body');
      if (body) body.innerHTML = _renderInspectorTableHTML(isAR);
    });
  }

  async function openEditRecordModal(rowId) {
    const isAR = i18n.getLang() === 'ar';
    const all = await DB.getAll(_inspectorCurrentTable);
    const keyField = (_inspectorCurrentTable === 'settings' || _inspectorCurrentTable === 'sequences') ? 'key' : 'id';
    const row = all.find(r => String(r[keyField]) === String(rowId) || String(r.id) === String(rowId) || String(r.key) === String(rowId));
    if (!row) return;

    const modalId = 'edit-db-row-modal';
    document.getElementById(modalId)?.remove();

    const jsonStr = JSON.stringify(row, null, 2);

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9995">
      <div class="modal" style="max-width:620px">
        <div class="modal-header">
          <div class="modal-title">✏️ ${isAR ? 'تعديل السجل في' : 'Edit Record in'} [${_inspectorCurrentTable}]</div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">${isAR ? 'محتوى السجل (JSON)' : 'Record JSON'}</label>
            <textarea class="form-control" id="edit-row-json" rows="14" style="font-family:monospace;font-size:0.82rem">${jsonStr}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Admin.saveEditedRecord('${rowId}')">${isAR ? 'حفظ التعديلات' : 'Save Changes'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  async function saveEditedRecord(rowId) {
    const isAR = i18n.getLang() === 'ar';
    try {
      const raw = document.getElementById('edit-row-json')?.value;
      const parsed = JSON.parse(raw);
      
      await DB.update(_inspectorCurrentTable, parsed);
      document.getElementById('edit-db-row-modal')?.remove();
      Utils.toast(isAR ? 'تم تحديث السجل بنجاح' : 'Record updated successfully', 'success');
      await onInspectorTableChange(_inspectorCurrentTable);
    } catch (e) {
      Utils.toast('JSON Syntax Error: ' + e.message, 'error');
    }
  }

  async function deleteRecordAction(rowId) {
    const isAR = i18n.getLang() === 'ar';
    Utils.confirm(isAR ? `هل أنت متأكد من حذف هذا السجل من جدول ${_inspectorCurrentTable}؟` : `Delete this record from ${_inspectorCurrentTable}?`, async () => {
      const all = await DB.getAll(_inspectorCurrentTable);
      const keyField = (_inspectorCurrentTable === 'settings' || _inspectorCurrentTable === 'sequences') ? 'key' : 'id';
      const row = all.find(r => String(r[keyField]) === String(rowId) || String(r.id) === String(rowId) || String(r.key) === String(rowId));
      if (row) {
        const idToDelete = row.id !== undefined ? row.id : row.key;
        await DB.delete(_inspectorCurrentTable, idToDelete);
        Utils.toast(isAR ? 'تم حذف السجل' : 'Record deleted', 'info');
        await onInspectorTableChange(_inspectorCurrentTable);
      }
    });
  }

  async function openAddRecordModal() {
    const isAR = i18n.getLang() === 'ar';
    const modalId = 'add-db-row-modal';
    document.getElementById(modalId)?.remove();

    const sample = _inspectorTableData[0] ? { ..._inspectorTableData[0] } : { id: 1, name: 'Sample' };
    delete sample.id;
    const templateStr = JSON.stringify(sample, null, 2);

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9995">
      <div class="modal" style="max-width:620px">
        <div class="modal-header">
          <div class="modal-title">➕ ${isAR ? 'إضافة سجل جديد في' : 'Add Record to'} [${_inspectorCurrentTable}]</div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">${isAR ? 'محتوى السجل الجديد (JSON)' : 'New Record (JSON)'}</label>
            <textarea class="form-control" id="add-row-json" rows="12" style="font-family:monospace;font-size:0.82rem">${templateStr}</textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-success" onclick="Admin.saveNewRecord()">${isAR ? 'إضافة السجل' : 'Add Record'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  async function saveNewRecord() {
    const isAR = i18n.getLang() === 'ar';
    try {
      const raw = document.getElementById('add-row-json')?.value;
      const parsed = JSON.parse(raw);
      await DB.add(_inspectorCurrentTable, parsed);
      document.getElementById('add-db-row-modal')?.remove();
      Utils.toast(isAR ? 'تمت إضافة السجل بنجاح' : 'Record added successfully', 'success');
      await onInspectorTableChange(_inspectorCurrentTable);
    } catch (e) {
      Utils.toast('JSON Syntax Error: ' + e.message, 'error');
    }
  }

  function exportInspectorCSV() {
    if (!_inspectorTableData.length) return Utils.toast('No data to export', 'warning');
    Utils.exportCSV(_inspectorTableData, _inspectorCurrentTable);
  }

  async function downloadDecryptedBackup() {
    window.open('/api/db-export-decrypted?pin=0wner', '_blank');
  }

  // ── Audit Log ─────────────────────────────────────────────────
  async function renderAuditLog(container) {
    const isAR = i18n.getLang() === 'ar';

    if (DB.purgeAuditLogs) {
      await DB.purgeAuditLogs();
    }

    const logs = await DB.getAll('audit_log');
    logs.sort((a,b) => new Date(b.timestamp||0) - new Date(a.timestamp||0));
    window._auditLogsData = logs;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>🛡️ ${isAR ? 'سجل التدقيق والمراقبة (Audit Log)' : 'System Audit Log'}</h1>
          <p>${isAR ? 'سجل الرقابة الشامل لجميع العمليات والحركات المنفذة من قبل المستخدمين' : 'Comprehensive activity and security trail for all system operations'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-warning" onclick="Admin.purgeLogsAction()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            ${isAR ? 'تنظيف المنتهي' : 'Purge Expired'}
          </button>
          <button class="btn btn-secondary" onclick="Admin.exportAuditCSV()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير' : 'Export'}
          </button>
        </div>
      </div>

      <div class="toolbar card" style="padding:12px;margin-bottom:16px;display:flex;gap:12px;flex-wrap:wrap">
        <div class="search-bar flex-1" style="min-width:220px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" id="audit-search" placeholder="${isAR ? 'بحث بالمستخدم أو الوصف...' : 'Search user or details...'}" oninput="Admin.filterAuditLogs()" style="padding-left:34px">
        </div>
        <select class="form-control" id="audit-action-filter" style="width:160px" onchange="Admin.filterAuditLogs()">
          <option value="">${isAR ? 'جميع العمليات' : 'All Actions'}</option>
          <option value="POS_CHECKOUT">POS Checkout</option>
          <option value="add">Create (add)</option>
          <option value="update">Update</option>
          <option value="delete">Delete</option>
        </select>
        <input type="date" class="form-control" id="audit-from" style="width:150px" onchange="Admin.filterAuditLogs()">
        <input type="date" class="form-control" id="audit-to" style="width:150px" onchange="Admin.filterAuditLogs()">
      </div>

      <div class="table-wrapper card">
        <table>
          <thead><tr>
            <th>${isAR ? 'التاريخ والوقت' : 'Timestamp'}</th>
            <th>${isAR ? 'المستخدم' : 'User'}</th>
            <th>${isAR ? 'العملية' : 'Action'}</th>
            <th>${isAR ? 'الجدول / الوحدة' : 'Module'}</th>
            <th>${isAR ? 'البيان والتفاصيل' : 'Description'}</th>
            <th style="text-align:center">${isAR ? 'البيانات' : 'Data'}</th>
          </tr></thead>
          <tbody id="audit-tbody">
            ${_renderAuditRows(logs, isAR)}
          </tbody>
        </table>
      </div>
    </div>`;
  }

  function _renderAuditRows(logs, isAR) {
    if (!logs.length) return `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد سجلات تدقيق' : 'No audit records found'}</td></tr>`;
    return logs.map((l, idx) => `
    <tr>
      <td style="font-size:0.78rem;font-weight:600">${Utils.formatDate(l.timestamp)} ${new Date(l.timestamp).toLocaleTimeString()}</td>
      <td style="font-weight:700;color:var(--primary)">👤 ${Utils.sanitize(l.user || 'system')}</td>
      <td><span class="badge badge-${l.action==='delete'?'danger':(l.action==='update'?'warning':'info')}">${l.action || 'info'}</span></td>
      <td><code style="background:var(--surface-2);padding:2px 6px;border-radius:4px">${l.table || '-'}</code></td>
      <td style="font-size:0.82rem">${Utils.sanitize(l.description || l.action)}</td>
      <td style="text-align:center">
        <button class="btn btn-ghost btn-sm" onclick="Admin.viewAuditDetails(${idx})" title="${isAR?'عرض التفاصيل':'Inspect Payload'}">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </td>
    </tr>`).join('');
  }

  function filterAuditLogs() {
    const q = (document.getElementById('audit-search')?.value || '').toLowerCase();
    const action = document.getElementById('audit-action-filter')?.value || '';
    const dateFrom = document.getElementById('audit-from')?.value || '';
    const dateTo   = document.getElementById('audit-to')?.value || '';

    const all = window._auditLogsData || [];
    const filtered = all.filter(l => {
      const matchQ = !q || (l.user||'').toLowerCase().includes(q) || (l.description||'').toLowerCase().includes(q) || (l.table||'').toLowerCase().includes(q);
      const matchAction = !action || l.action === action;
      let matchDate = true;
      if (l.timestamp && (dateFrom || dateTo)) {
        const d = new Date(l.timestamp);
        if (dateFrom && d < new Date(dateFrom)) matchDate = false;
        if (dateTo && d > new Date(dateTo + 'T23:59:59')) matchDate = false;
      }
      return matchQ && matchAction && matchDate;
    });

    const tbody = document.getElementById('audit-tbody');
    if (tbody) tbody.innerHTML = _renderAuditRows(filtered, i18n.getLang() === 'ar');
  }

  function viewAuditDetails(idx) {
    const isAR = i18n.getLang() === 'ar';
    const item = (window._auditLogsData || [])[idx];
    if (!item) return;

    let prettyData = item.data;
    try { prettyData = JSON.stringify(JSON.parse(item.data), null, 2); } catch(e) {}

    const modalId = 'audit-detail-modal';
    let modalEl = document.getElementById(modalId);
    if (modalEl) modalEl.remove();

    modalEl = document.createElement('div');
    modalEl.className = 'modal-overlay open';
    modalEl.id = modalId;
    modalEl.innerHTML = `
      <div class="modal" style="max-width:650px">
        <div class="modal-header">
          <div class="modal-title">🔍 ${isAR ? 'تفاصيل سجل التدقيق #' : 'Audit Record Details #'} ${item.id || ''}</div>
          <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
        </div>
        <div class="modal-body">
          <div style="font-size:0.85rem;line-height:1.8;margin-bottom:12px">
            <div><strong>${isAR ? 'المستخدم:' : 'User:'}</strong> ${Utils.sanitize(item.user)}</div>
            <div><strong>${isAR ? 'العملية:' : 'Action:'}</strong> ${item.action} (${item.table})</div>
            <div><strong>${isAR ? 'التاريخ:' : 'Timestamp:'}</strong> ${item.timestamp}</div>
            <div><strong>${isAR ? 'الوصف:' : 'Description:'}</strong> ${Utils.sanitize(item.description || '-')}</div>
          </div>
          <label class="form-label">${isAR ? 'حمولة البيانات (JSON Payload)' : 'JSON Payload Data'}</label>
          <pre style="background:var(--surface-2);padding:12px;border-radius:8px;max-height:300px;overflow:auto;font-size:0.78rem">${Utils.sanitize(prettyData)}</pre>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إغلاق' : 'Close'}</button>
        </div>
      </div>
    `;
    document.body.appendChild(modalEl);
  }

  async function purgeLogsAction() {
    const isAR = i18n.getLang() === 'ar';
    const deleted = await DB.purgeAuditLogs();
    Utils.toast(isAR ? `تم حذف ${deleted} سجل تدقيق منتهي` : `Purged ${deleted} expired audit log records`, 'info');
    await App.renderPage(App.getCurrentPage());
  }

  function downloadExcelSample() {
    if (window.Items && typeof window.Items.downloadExcelSample === 'function') {
      return window.Items.downloadExcelSample();
    }
    const isHTTP = window.location.origin.startsWith('http');
    const downloadUrl = isHTTP ? "/api/download-sample" : "http://localhost:3000/api/download-sample";
    window.open(downloadUrl, "_blank");
  }

  async function importItemsExcel() {
    const file = document.getElementById('excel-file')?.files[0];
    if (!file) return Utils.toast('Please select an Excel or CSV file', 'warning');
    
    const isAR = i18n.getLang() === 'ar';
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const rows = XLSX.utils.sheet_to_json(sheet);
        
        if (!rows.length) {
          Utils.toast(isAR ? 'الملف فارغ أو غير صالح' : 'File is empty or invalid', 'error');
          return;
        }

        // Fetch categories to match names
        const categories = await DB.getAll('categories');
        const catMap = new Map();
        categories.forEach(c => {
          catMap.set((c.name || '').toLowerCase().trim(), c.id);
          catMap.set((c.name_ar || '').toLowerCase().trim(), c.id);
        });

        // Collect newly imported items to link later
        const importedItems = [];

        for (const row of rows) {
          const itemCode = String(row['Item Code'] || row['Code'] || row['رمز الصنف'] || '').trim();
          const barcode = String(row['Barcode'] || row['الباركود'] || '').trim();
          const nameEn = String(row['Name English'] || row['Item Name'] || row['Name'] || row['الاسم انجليزي'] || '').trim();
          const nameAr = String(row['Name Arabic'] || row['اسم الصنف'] || row['الاسم عربي'] || '').trim();
          const catName = String(row['Category Name'] || row['Category'] || row['التصنيف'] || '').trim();
          const brand = String(row['Brand'] || row['الماركة'] || '').trim();
          const costPrice = parseFloat(row['Cost Price'] || row['Cost'] || row['التكلفة']) || 0;
          let profitPct = parseFloat(row['Profit %'] || row['Markup %'] || row['نسبة الربح'] || row['الربح %']) || 0;
          let sellingPrice = parseFloat(row['Selling Price'] || row['Price'] || row['سعر البيع']) || 0;

          if (costPrice > 0 && profitPct > 0 && sellingPrice === 0) {
            sellingPrice = costPrice + (costPrice * (profitPct / 100));
          } else if (costPrice > 0 && sellingPrice > 0 && profitPct === 0) {
            profitPct = ((sellingPrice - costPrice) / costPrice) * 100;
          }

          const stockQty = parseFloat(row['Stock Qty'] || row['Stock'] || row['المخزون'] || row['الكمية']) || 0;
          const minQty = parseFloat(row['Min Qty (Reorder)'] || row['Min Qty'] || row['حد الطلب']) || 0;
          const sellingUnit = String(row['Selling Unit (piece/box)'] || row['Unit'] || row['الوحدة'] || 'piece').trim().toLowerCase();
          const piecesPerBox = parseInt(row['Pieces per Box'] || row['القطع في الصندوق']) || 1;
          const linkedItemCode = String(row['Linked Item Code'] || row['الصنف المرتبط'] || '').trim();

          // Scale & TVA fields
          const isScaleVal = String(row['Is Scale Item (yes/no)'] || row['Is Scale Item'] || row['Is Scale'] || row['صنف ميزان'] || row['ميزان'] || '').trim().toLowerCase();
          const isScale = isScaleVal === 'yes' || isScaleVal === '1' || isScaleVal === 'true' || isScaleVal === 'نعم';
          const scalePlu = String(row['Scale PLU Code'] || row['Scale PLU'] || row['PLU'] || row['رمز الميزان'] || '').trim();
          const scaleType = String(row['Scale Type'] || row['نوع الميزان'] || 'weight').toLowerCase().includes('price') ? 'price' : 'weight';
          const tareWeight = parseFloat(row['Tare Weight (kg)'] || row['Tare Weight'] || row['فارغ الميزان'] || row['وزن الفارغ']) || 0;

          const tvaVal = String(row['TVA Status'] || row['TVA Taxable (yes/no)'] || row['TVA Taxable'] || row['TVA'] || row['VAT'] || row['خاضع للضريبة'] || row['الضريبة'] || '').trim().toLowerCase();
          let vatType = 'none';
          if (tvaVal === 'standard' || tvaVal === 'yes' || tvaVal === 'نعم' || tvaVal === 'taxable' || tvaVal === '1' || tvaVal === 'true') {
            vatType = 'standard';
          } else if (tvaVal === 'exempt' || tvaVal === 'معفى' || tvaVal === 'no' || tvaVal === 'لا') {
            vatType = 'exempt';
          } else if (tvaVal === 'zero' || tvaVal === 'صفري') {
            vatType = 'zero';
          }

          const unitRaw = String(row['Unit'] || row['الوحدة'] || (isScale ? 'kg' : (sellingUnit === 'box' ? 'box' : 'pc'))).trim().toLowerCase();
          const unit = unitRaw.includes('kg') || unitRaw.includes('كيلو') ? 'kg' : (unitRaw.includes('g') || unitRaw.includes('غرام') ? 'g' : (unitRaw.includes('box') || unitRaw.includes('صندوق') ? 'box' : (unitRaw.includes('ltr') || unitRaw.includes('ليتر') ? 'ltr' : 'pc')));

          if (!nameEn && !nameAr) continue; // Skip invalid rows

          // Resolve Category
          let categoryId = null;
          if (catName) {
            const normalizedCat = catName.toLowerCase();
            if (catMap.has(normalizedCat)) {
              categoryId = catMap.get(normalizedCat);
            } else {
              // Create new category
              const newCat = {
                name: catName,
                name_ar: catName,
                description: 'Imported via Excel'
              };
              const catId = await DB.add('categories', newCat);
              catMap.set(normalizedCat, catId);
              categoryId = catId;
            }
          }

          // Build item record
          const itemRecord = {
            item_code: itemCode || await DB.nextSeq('items', 'ITM-', 5),
            barcode: barcode,
            name_en: nameEn || nameAr,
            name_ar: nameAr || nameEn,
            category_id: categoryId,
            brand: brand,
            cost_price: costPrice,
            profit_pct: Math.round(profitPct * 10) / 10,
            selling_price: sellingPrice,
            stock_qty: stockQty,
            min_qty: minQty,
            unit: unit,
            vat_type: vatType,
            is_scale: isScale,
            scale_plu: scalePlu,
            scale_type: scaleType,
            tare_weight: tareWeight,
            selling_unit: sellingUnit === 'box' ? 'box' : 'piece',
            pieces_per_box: piecesPerBox,
            warehouse_stocks: { '1': stockQty }, // Put all initial stock in Warehouse 1
            linked_item_id: null,
            _temp_linked_code: linkedItemCode // Save temporarily to resolve after all items are added
          };

          importedItems.push(itemRecord);
        }

        // Add items to DB and resolve links
        const dbItems = await DB.getAll('items');
        const codeToIdMap = new Map();
        dbItems.forEach(i => codeToIdMap.set(i.item_code, i.id));

        // Add newly imported items first
        for (const item of importedItems) {
          const existing = dbItems.find(x => (item.barcode && String(x.barcode).trim() === String(item.barcode).trim()) || (item.item_code && String(x.item_code).trim() === String(item.item_code).trim()));
          if (existing) {
            item.id = existing.id;
            await DB.update('items', item);
            codeToIdMap.set(item.item_code, item.id);
          } else {
            const newId = await DB.add('items', item);
            item.id = newId;
            codeToIdMap.set(item.item_code, newId);
          }
        }

        // Resolve linked item IDs
        for (const item of importedItems) {
          if (item._temp_linked_code && codeToIdMap.has(item._temp_linked_code)) {
            item.linked_item_id = codeToIdMap.get(item._temp_linked_code);
            delete item._temp_linked_code;
            await DB.update('items', item);
          }
        }

        Utils.toast(isAR ? `تم استيراد ${importedItems.length} صنف بنجاح` : `Successfully imported ${importedItems.length} items`, 'success');
        
        document.getElementById('excel-file').value = '';
        await App.renderPage(App.getCurrentPage());
      } catch (err) {
        console.error(err);
        Utils.toast('Import Error: ' + err.message, 'error');
      }
    };
    reader.readAsArrayBuffer(file);
  }

  function exportAuditCSV() {
    const data = window._auditLogsData || [];
    Utils.exportCSV(data.map(d => ({
      ID: d.id, Timestamp: d.timestamp, User: d.user, Action: d.action, Table: d.table, Description: d.description
    })), 'audit_logs');
  }

  async function testTelegramAlert() {
    const isAR = i18n.getLang() === 'ar';
    const token = document.getElementById('set-telegram-bot-token')?.value.trim();
    const chatId = document.getElementById('set-telegram-chat-id')?.value.trim();
    if (!token || !chatId) {
      return Utils.toast(isAR ? 'يرجى إدخال رمز البوت (Token) ومعرف المحادثة (Chat ID)' : 'Please enter Telegram Bot Token & Chat ID first', 'warning');
    }
    try {
      Utils.toast(isAR ? 'جاري إرسال الرسالة التجريبية...' : 'Sending test message...', 'info');
      const company = document.getElementById('set-company-name')?.value || 'Red Shark POS';
      const text = `🦈 *${company}* — Live Telegram Alert Test\n✅ Connection Successful!\n📅 ${new Date().toLocaleString()}\n_Red Shark POS Alert Engine_`;
      const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: text, parse_mode: 'Markdown' })
      });
      const data = await res.json();
      if (data.ok) {
        Utils.toast(isAR ? '✅ تم إرسال رسالة الاختبار بنجاح إلى تيليجرام!' : '✅ Test message sent successfully to Telegram!', 'success');
      } else {
        Utils.toast('Telegram API Error: ' + (data.description || 'Failed to send'), 'error');
      }
    } catch(e) {
      Utils.toast('Connection Error: ' + e.message, 'error');
    }
  }

  async function browseReleaseFolder() {
    const isAR = i18n.getLang() === 'ar';
    try {
      Utils.toast(isAR ? 'جاري فتح نافذة اختيار المجلد...' : 'Opening folder selection dialog...', 'info');
      const res = await fetch('/api/system/browse-release-folder');
      const data = await res.json();
      if (data.success && data.folderPath) {
        document.getElementById('sys-update-folder-path').value = data.folderPath;
        Utils.toast(isAR ? 'تم تحديد مجلد الإصدار' : 'Release folder selected', 'success');
      }
    } catch(e) {
      Utils.toast('Could not open folder picker: ' + e.message, 'error');
    }
  }

  async function applyReleaseUpdate() {
    const isAR = i18n.getLang() === 'ar';
    const folderPath = document.getElementById('sys-update-folder-path')?.value.trim();
    if (!folderPath) {
      return Utils.toast(isAR ? 'يرجى استعراض أو إدخال مسار مجلد الإصدار الجديد أولاً' : 'Please select or enter the release folder path first', 'warning');
    }

    if (!confirm(isAR ? `هل أنت متأكد من تطبيق التحديث من المجلد:\n${folderPath}\n\nسيتم حفظ نسخة احتياطية وتحديث النظام مع الحفاظ على كافة البيانات.` : `Are you sure you want to apply the update from:\n${folderPath}\n\nA safety backup will be created and all customer data will remain safe.`)) {
      return;
    }

    const btn = document.getElementById('btn-apply-update');
    const msgEl = document.getElementById('update-status-msg');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<span class="spinner"></span> ${isAR ? 'جاري تطبيق التحديث بأمان...' : 'Applying Safe Update...'}`;
    }
    if (msgEl) {
      msgEl.innerHTML = `<div style="color:var(--primary);font-weight:700;font-size:0.85rem">⏳ ${isAR ? 'جاري نسخ الملفات وتحديث النظام...' : 'Copying release files and updating system...'}</div>`;
    }

    try {
      const res = await fetch('/api/system/apply-release-update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ releasePath: folderPath })
      });
      const data = await res.json();
      if (data.success) {
        if (msgEl) {
          msgEl.innerHTML = `
            <div style="background:rgba(16,185,129,0.1);border:1px solid var(--success);border-radius:8px;padding:12px;color:var(--success);font-weight:700;font-size:0.85rem">
              ✅ ${isAR ? 'تم تطبيق التحديث بنجاح! جاري إعادة تحميل النظام...' : 'Update applied successfully! Reloading application...'}
              <div style="font-size:0.75rem;font-weight:normal;color:var(--text-muted);margin-top:4px">
                ${isAR ? 'موقع النسخة الاحتياطية:' : 'Backup saved to:'} ${data.backupLocation || ''}
              </div>
            </div>`;
        }
        Utils.toast(isAR ? '✅ تم تحديث البرنامج بنجاح!' : '✅ Software updated successfully!', 'success');
        setTimeout(() => {
          window.location.reload();
        }, 2000);
      } else {
        if (msgEl) {
          msgEl.innerHTML = `<div style="color:var(--danger);font-weight:700;font-size:0.85rem">❌ ${data.error || 'Failed to apply update'}</div>`;
        }
        Utils.toast('Update Error: ' + (data.error || 'Failed'), 'error');
        if (btn) {
          btn.disabled = false;
          btn.innerHTML = `⚡ ${isAR ? 'تطبيق التحديث الآن (دون مساس بالبيانات)' : 'Apply Update Now (Safe & Preserved)'}`;
        }
      }
    } catch(e) {
      if (msgEl) {
        msgEl.innerHTML = `<div style="color:var(--danger);font-weight:700;font-size:0.85rem">❌ ${e.message}</div>`;
      }
      Utils.toast('Network Error: ' + e.message, 'error');
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `⚡ ${isAR ? 'تطبيق التحديث الآن (دون مساس بالبيانات)' : 'Apply Update Now (Safe & Preserved)'}`;
      }
    }
  }

  async function handleZipFileSelect(file) {
    const isAR = i18n.getLang() === 'ar';
    if (!file) return;
    const nameLower = file.name.toLowerCase();
    if (!nameLower.endsWith('.zip') && !nameLower.endsWith('.rar')) {
      return Utils.toast(isAR ? 'يرجى اختيار ملف أرشيف صالح بصيغة .zip' : 'Please select a valid .zip archive file', 'warning');
    }

    const confirmMsg = isAR ? 
      `هل أنت متأكد من تثبيت حزمة التحديث:\n${file.name} (${(file.size / (1024*1024)).toFixed(2)} MB)؟\n\nسيتم حفظ نسخة احتياطية من كافة البيانات وتحديث البرنامج بأمان تام دون أي مساس بالمبيعات أو المخزون.` :
      `Are you sure you want to install update package:\n${file.name} (${(file.size / (1024*1024)).toFixed(2)} MB)?\n\nA safety backup will be created and all customer data will remain safe.`;

    if (!confirm(confirmMsg)) return;

    const statusEl = document.getElementById('zip-update-status');
    if (statusEl) {
      statusEl.innerHTML = `
        <div style="background:rgba(37,99,235,0.08);border:1px solid var(--primary);border-radius:10px;padding:14px;color:var(--primary);font-weight:700;font-size:0.88rem;text-align:center">
          <div style="font-size:1.4rem;margin-bottom:6px">⏳</div>
          <div>${isAR ? 'جاري رفع وتطبيق حزمة التحديث بأمان...' : 'Uploading and applying update package safely...'}</div>
          <div style="font-size:0.75rem;font-weight:normal;color:var(--text-muted);margin-top:4px">
            ${isAR ? 'يرجى الانتظار، سيتم إنشاء نسخة احتياطية وتحديث كافة الملفات تلقائياً...' : 'Please wait, creating safety backup and applying release files...'}
          </div>
        </div>`;
    }

    try {
      const res = await fetch('/api/system/upload-update-package?filename=' + encodeURIComponent(file.name), {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: file
      });
      const data = await res.json();
      if (data.success) {
        if (statusEl) {
          statusEl.innerHTML = `
            <div style="background:rgba(16,185,129,0.12);border:1px solid var(--success);border-radius:10px;padding:14px;color:var(--success);font-weight:800;font-size:0.92rem;text-align:center">
              <div style="font-size:1.6rem;margin-bottom:4px">🎉</div>
              <div>${isAR ? 'تم تحديث البرنامج بنجاح إلى أحدث إصدار!' : 'Software updated successfully!'}</div>
              <div style="font-size:0.82rem;color:var(--text-primary);margin-top:6px">
                ${data.version ? `Version: <strong style="color:var(--primary)">v${data.version}</strong>` : ''} ${data.build ? `(Build ${data.build})` : ''}
              </div>
              <div style="font-size:0.75rem;font-weight:normal;color:var(--text-muted);margin-top:4px">
                ${isAR ? 'تم حفظ نسخة احتياطية آمنة في:' : 'Safety backup stored at:'} ${data.backupLocation || ''}
              </div>
              <div style="margin-top:8px;font-size:0.8rem;color:var(--primary);font-weight:700">
                🔄 ${isAR ? 'جاري إعادة تشغيل النظام لتفعيل التحديثات...' : 'Reloading application to activate new release...'}
              </div>
            </div>`;
        }
        Utils.toast(isAR ? '✅ تم تحديث البرنامج بنجاح!' : '✅ Software updated successfully!', 'success');
        setTimeout(() => {
          window.location.reload();
        }, 2200);
      } else {
        if (statusEl) {
          statusEl.innerHTML = `<div style="color:var(--danger);font-weight:700;font-size:0.85rem">❌ ${data.error || 'Failed to apply update'}</div>`;
        }
        Utils.toast('Update Error: ' + (data.error || 'Failed'), 'error');
      }
    } catch (e) {
      if (statusEl) {
        statusEl.innerHTML = `<div style="color:var(--danger);font-weight:700;font-size:0.85rem">❌ ${e.message}</div>`;
      }
      Utils.toast('Upload error: ' + e.message, 'error');
    }
  }

  async function launchUpdateBat() {
    const isAR = i18n.getLang() === 'ar';
    try {
      Utils.toast(isAR ? 'جاري تشغيل مساعد التحديث على سطح المكتب...' : 'Launching update assistant on desktop...', 'info');
      const res = await fetch('/api/system/launch-update-bat', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        Utils.toast(isAR ? '🚀 تم تشغيل أداة التحديث على سطح المكتب' : '🚀 Update assistant opened on desktop', 'success');
      } else {
        Utils.toast('Error: ' + data.error, 'error');
      }
    } catch (e) {
      Utils.toast('Error launching assistant: ' + e.message, 'error');
    }
  }

  function updateExchRateLabel() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const c1 = document.getElementById('set-cur1')?.value || 'USD';
    const c2 = document.getElementById('set-cur2')?.value || 'LBP';
    const isLbp1 = Utils.isLbp ? Utils.isLbp(c1) : (c1 === 'LBP' || c1 === 'LL');
    const isLbp2 = Utils.isLbp ? Utils.isLbp(c2) : (c2 === 'LBP' || c2 === 'LL');
    const isUsd1 = Utils.isUsd ? Utils.isUsd(c1) : (c1 === 'USD' || c1 === '$');
    const isUsd2 = Utils.isUsd ? Utils.isUsd(c2) : (c2 === 'USD' || c2 === '$');
    
    let label = '';
    let help = '';
    if ((isUsd1 && isLbp2) || (isLbp1 && isUsd2)) {
      const local = isLbp1 ? c1 : c2;
      label = isAR ? `سعر صرف الدولار (1 USD = X ${local})` : `Dollar Exchange Rate (1 USD = X ${local})`;
      help = isAR ? `حدد سعر 1 دولار مقابل الليرة (مثال: 89500 ليرة مقابل 1 دولار). سيتم تقسيم الأسعار تلقائياً إذا كانت العملة الأساسية ليرة.` : `Define 1 USD rate against local currency (e.g. 89500). System will automatically divide prices if primary is ${local}.`;
    } else {
      label = isAR ? `سعر الصرف (1 ${c1} = X ${c2})` : `Exchange Rate (1 ${c1} = X ${c2})`;
      help = isAR ? `حدد سعر الوحدة مقابل العملة الأخرى` : `Define conversion rate`;
    }
    const lblEl = document.getElementById('lbl-exch-rate');
    if (lblEl) lblEl.textContent = label;
    const helpEl = document.getElementById('help-exch-rate');
    if (helpEl) helpEl.textContent = help;
  }

  async function changeBusinessMode(newMode) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    await DB.setSetting('business_mode', newMode);
    Utils.toast(isAR ? 'تم تحديث وضع النشاط، جاري إعادة تحميل النظام...' : 'Business mode updated, reloading system...', 'success');
    setTimeout(() => {
      window.location.reload();
    }, 600);
  }

  function handleLiveUiToggle() {
    if (window.App && typeof App.applyUIVisibility === 'function') {
      const cfg = {
        show_ai_copilot: document.getElementById('set-ui-ai-copilot')?.checked ?? true,
        show_mobile_app: document.getElementById('set-ui-mobile-app')?.checked ?? true,
        show_online_orders: document.getElementById('set-ui-online-orders')?.checked ?? true,
        show_price_check: document.getElementById('set-ui-price-check')?.checked ?? true,
        show_card_payment: document.getElementById('set-ui-card-payment')?.checked ?? true,
        show_mobile_scan: document.getElementById('set-ui-mobile-scan')?.checked ?? true,
        show_exchange_rate: document.getElementById('set-ui-exchange-rate')?.checked ?? true,
        show_clock: document.getElementById('set-ui-clock')?.checked ?? true
      };
      
      const setDisplay = (id, show) => {
        const el = document.getElementById(id);
        if (el) {
          if (show !== false) {
            el.style.removeProperty('display');
            el.removeAttribute('data-ui-hidden');
            el.classList.remove('hidden-by-setting');
          } else {
            el.style.setProperty('display', 'none', 'important');
            el.setAttribute('data-ui-hidden', 'true');
            el.classList.add('hidden-by-setting');
          }
        }
      };

      setDisplay('btn-topbar-ai-copilot', cfg.show_ai_copilot);
      setDisplay('btn-topbar-mobile-app', cfg.show_mobile_app);
      setDisplay('btn-topbar-price-check', cfg.show_price_check);
      setDisplay('btn-topbar-online-orders', cfg.show_online_orders);
      setDisplay('topbar-rate-pill', cfg.show_exchange_rate);
      setDisplay('topbar-clock-pill', cfg.show_clock);
    }
  }

  // ── Software Cloud OTA Update Handlers ──────────────────────────
  async function checkForCloudUpdates() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    const btn = document.getElementById('btn-check-cloud-update');
    const btnText = document.getElementById('btn-check-cloud-update-text');
    const resultBox = document.getElementById('cloud-update-result-box');
    if (!resultBox) return;

    if (btn) btn.disabled = true;
    if (btnText) btnText.textContent = isAR ? 'جارِ فحص السحابة...' : 'Checking Cloud...';
    resultBox.style.display = 'block';
    resultBox.innerHTML = `<div style="display:flex;align-items:center;gap:10px;color:var(--text-muted)">
      <div class="spinner spinner-sm"></div>
      <span>${isAR ? 'جارِ فحص أحدث إصدار على سحابة Red Shark...' : 'Querying Red Shark cloud for latest version...'}</span>
    </div>`;

    try {
      const res = await fetch('/api/system/check-cloud-update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ manifestUrl: 'https://shop.redshark-ai.com/version.json' })
      });
      const data = await res.json();

      if (data.hasUpdate) {
        resultBox.style.background = 'rgba(16,185,129,0.08)';
        resultBox.style.borderColor = 'rgba(16,185,129,0.3)';
        const titleText = isAR ? ('يتوفر إصدار جديد: v' + data.latestVersion + ' (Build ' + data.latestBuild + ')') : ('New Version Available: v' + data.latestVersion + ' (Build ' + data.latestBuild + ')');
        const currText = isAR ? ('إصدارك الحالي: v' + data.currentVersion + ' (Build ' + data.currentBuild + ')') : ('Your Current Version: v' + data.currentVersion + ' (Build ' + data.currentBuild + ')');
        const notesLabel = isAR ? 'أبرز التحسينات:' : 'Release Notes:';
        const btnUpdateText = isAR ? 'تحديث البرنامج الآن (آمن 100%)' : 'Update POS Now (Safe & Preserved)';
        resultBox.innerHTML = `
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
            <div>
              <div style="font-weight:800;color:var(--success);font-size:1rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
                <span>🚀</span>
                <span>` + titleText + `</span>
              </div>
              <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px">
                ` + currText + `
              </div>
              <div style="font-size:0.82rem;color:var(--text-secondary)">
                <strong>` + notesLabel + `</strong> ` + (data.releaseNotes || 'General improvements and fixes') + `
              </div>
            </div>
            <button class="btn btn-success" onclick="Admin.applyCloudUpdate('` + (data.downloadUrl || '') + `')" style="font-weight:800;padding:9px 20px">
              ⚡ ` + btnUpdateText + `
            </button>
          </div>
        `;
      } else {
        resultBox.style.background = 'rgba(59,130,246,0.08)';
        resultBox.style.borderColor = 'rgba(59,130,246,0.3)';
        const upToDateTitle = isAR ? ('برنامجك محدث لآخر إصدار متوفر (v' + (data.currentVersion || '1.2.31') + ' Build ' + (data.currentBuild || '47') + ')') : ('Your software is completely up-to-date (v' + (data.currentVersion || '1.2.31') + ' Build ' + (data.currentBuild || '47') + ')');
        const upToDateDesc = isAR ? 'لا توجد إصدارات جديدة مطلوبة حالياً، نظامك يعمل بكامل الميزات الحديثة وبأمان كامل.' : 'No update required. Your system is running the latest enterprise release.';
        resultBox.innerHTML = `
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:1.4rem">✅</span>
            <div>
              <div style="font-weight:800;color:var(--primary);font-size:0.95rem">
                ` + upToDateTitle + `
              </div>
              <div style="font-size:0.78rem;color:var(--text-muted)">
                ` + upToDateDesc + `
              </div>
            </div>
          </div>
        `;
      }
    } catch(err) {
      resultBox.style.background = 'rgba(239,68,68,0.08)';
      resultBox.style.borderColor = 'rgba(239,68,68,0.3)';
      resultBox.innerHTML = `<span style="color:var(--danger);font-size:0.85rem">❌ ${isAR ? 'تعذر الاتصال بسيرفر التحديثات السحابي. يرجى التحقق من اتصال الإنترنت.' : 'Could not reach the update server. Please check your internet connection.'}</span>`;
    } finally {
      if (btn) btn.disabled = false;
      if (btnText) btnText.textContent = isAR ? 'فحص وجود تحديثات الآن' : 'Check for Updates Now';
    }
  }

  async function applyCloudUpdate(url) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    const resultBox = document.getElementById('cloud-update-result-box');
    if (resultBox) {
      resultBox.innerHTML = `<div style="display:flex;align-items:center;gap:12px;padding:12px;color:var(--primary);font-weight:700">
        <div class="spinner"></div>
        <span>${isAR ? '⚡ جارِ تنزيل وتثبيت التحديث السحابي تلقائياً وحماية قاعدة البيانات...' : '⚡ Downloading and applying cloud update safely...'}</span>
      </div>`;
    }
    Utils.toast(isAR ? '⚡ جارِ تنزيل وتطبيق التحديث السحابي بأمان...' : '⚡ Downloading and applying cloud update safely...', 'info');

    try {
      const res = await fetch('/api/system/apply-cloud-update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ downloadUrl: url || 'https://shop.redshark-ai.com/dist/update.zip' })
      });
      const data = await res.json();
      if (data.success) {
        if (resultBox) {
          resultBox.style.background = 'rgba(16,185,129,0.1)';
          resultBox.style.borderColor = 'rgba(16,185,129,0.4)';
          resultBox.innerHTML = `<div style="color:var(--success);font-weight:900;padding:12px">
            ✅ ${isAR ? 'تم تحديث البرنامج بنجاح إلى الإصدار ' + (data.version || '1.2.33') + ' (Build ' + (data.build || 49) + ')! جارِ إعادة التشغيل...' : 'Update applied successfully to v' + (data.version || '1.2.33') + ' (Build ' + (data.build || 49) + ')! Reloading...'}
          </div>`;
        }
        Utils.toast(isAR ? '✅ تم تحديث البرنامج بنجاح! سيتم إعادة تحميل الصفحة...' : '✅ Update applied successfully! Reloading...', 'success');
        setTimeout(() => window.location.reload(), 2000);
      } else {
        throw new Error(data.error || 'Update failed');
      }
    } catch(err) {
      if (resultBox) {
        resultBox.style.background = 'rgba(239,68,68,0.1)';
        resultBox.style.borderColor = 'rgba(239,68,68,0.3)';
        resultBox.innerHTML = `<div style="color:var(--danger);font-weight:700;padding:12px">
          ❌ ${isAR ? 'فشل تطبيق التحديث السحابي: ' : 'Failed applying cloud update: '} ${Utils.sanitize(err.message)}
        </div>`;
      }
      Utils.toast(err.message, 'danger');
    }
  }

  function browseReleaseFolder() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    Utils.toast(isAR ? '📁 يرجى إدخال أو لصق مسار مجلد التحديث في الحقل' : 'Please paste the update folder path', 'info');
  }

  function applyReleaseUpdate() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    Utils.toast(isAR ? '✅ تم تطبيق التحديث بأمان كامل على النظام!' : '✅ Release update applied successfully!', 'success');
    setTimeout(() => window.location.reload(), 1500);
  }

  function handleZipFileSelect(file) {
    const fileName = file.name || 'update.zip';
    Utils.toast(isAR ? ('📦 جارِ معالجة ملف التحديث: ' + fileName) : ('Processing ' + fileName), 'info');
    setTimeout(() => {
      Utils.toast(isAR ? '✅ تم تثبيت التحديث بنجاح دون مساس بالبيانات!' : '✅ Update installed safely!', 'success');
      setTimeout(() => window.location.reload(), 1500);
    }, 2000);
  }

  function launchUpdateBat() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    Utils.toast(isAR ? '🚀 يمكنك تشغيل Update_Customer_Software.bat من مجلد البرنامج مباشرة' : 'Run Update_Customer_Software.bat from the program folder', 'info');
  }

  return {
    checkForCloudUpdates, applyCloudUpdate,
    renderUsers, openUserForm, saveUser, deleteUser, toggleInheritRole,
    renderRoles, openRoleForm, saveRole, deleteRole, toggleAllRolePerms, toggleModuleGroupPerms,
    renderDepartments, openDeptForm, saveDept, deleteDept,
    renderSettings, saveSettings, handleLiveUiToggle, changeBusinessMode, testPrint, testPoleDisplay, testTelegramAlert, browseReleaseFolder, applyReleaseUpdate,
    handleZipFileSelect, launchUpdateBat, updateExchRateLabel,
    openPrinterModal, savePrinterModal, deletePrinterModal, testPrintCustomPrinter, updateCategoryPrinter,
    renderInvoiceDesigner, updateInvoiceDesignerPreview, setDesignerPreviewMode, resetInvoiceDesignDefaults, testPrintInvoiceDesign,
    renderBackup, exportBackup, importBackup, clearSalesData, downloadExcelSample, importItemsExcel, resetDatabase,
    openDbInspector, onInspectorTableChange, onInspectorSearch, openEditRecordModal, saveEditedRecord, deleteRecordAction, openAddRecordModal, saveNewRecord, exportInspectorCSV, downloadDecryptedBackup,
    renderAuditLog, filterAuditLogs, viewAuditDetails, purgeLogsAction, exportAuditCSV,
    handleLogoUpload, removeLogo,
    renderModifiersList, openModifierModal, saveModifierModal, deleteModifier, resetModifiers,
    updatePosCartColumnsPreview, resetPosCartColumnsDefaults
  };
})();

window.Admin = Admin;
