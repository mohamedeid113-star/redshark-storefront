/* ================================================================
   Red Shark POS — Repair & Workshop Job Ticket Management Module
   ================================================================ */

const RepairsModule = (() => {
  let _jobs        = [];
  let _customers   = [];
  let _items       = [];
  let _users       = [];
  let _settings    = {};
  let _activeTab   = 'all'; // 'all', 'received', 'diagnosing', 'waiting_parts', 'in_progress', 'ready', 'delivered', 'cancelled'
  let _viewMode    = 'kanban'; // 'kanban' or 'table'
  let _searchQuery = '';
  let _techFilter  = '';

  const STATUS_MAP = {
    received:      { labelEn: 'Received',      labelAr: 'تم الاستلام',        color: '#3b82f6', bg: 'rgba(59,130,246,0.15)', icon: '📥' },
    diagnosing:    { labelEn: 'Diagnosing',    labelAr: 'قيد الفحص والتشخيص', color: '#a855f7', bg: 'rgba(168,85,247,0.15)', icon: '🔍' },
    waiting_parts: { labelEn: 'Waiting Parts', labelAr: 'بانتظار قطع الغيار', color: '#f59e0b', bg: 'rgba(245,158,11,0.15)', icon: '⏳' },
    in_progress:   { labelEn: 'In Progress',   labelAr: 'قيد العمل والصيانة', color: '#06b6d4', bg: 'rgba(6,182,212,0.15)',  icon: '⚙️' },
    ready:         { labelEn: 'Ready',         labelAr: 'جاهز للتسليم',       color: '#10b981', bg: 'rgba(16,185,129,0.15)', icon: '✅' },
    delivered:     { labelEn: 'Delivered',     labelAr: 'تم التسليم والتحصيل', color: '#64748b', bg: 'rgba(100,116,139,0.15)',icon: '🤝' },
    cancelled:     { labelEn: 'Cancelled',     labelAr: 'ملغي / غير مصلح',   color: '#ef4444', bg: 'rgba(239,68,68,0.15)',  icon: '❌' },
  };

  async function loadData() {
    _jobs      = (await DB.getAll('repair_jobs')) || [];
    _customers = (await DB.getAll('customers')) || [];
    _items     = (await DB.getAll('items', i => i.status !== 'inactive')) || [];
    _users     = (await DB.getAll('users')) || [];
    _settings  = {
      companyName:    await DB.getSetting('company_name', 'Red Shark POS'),
      companyPhone:   await DB.getSetting('company_phone', ''),
      companyAddress: await DB.getSetting('company_address', ''),
      currency1:      await DB.getSetting('currency_1', 'USD'),
      currency2:      await DB.getSetting('currency_2', 'LBP'),
      exchRate:       parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500,
    };
    _jobs.sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
  }

  async function render(container) {
    await loadData();
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';

    // Compute Metrics
    const totalJobs = _jobs.length;
    const activeJobs = _jobs.filter(j => j.status !== 'delivered' && j.status !== 'cancelled').length;
    const readyJobs = _jobs.filter(j => j.status === 'ready').length;
    const totalRevenue = _jobs.filter(j => j.status === 'delivered').reduce((s, j) => s + (parseFloat(j.final_cost || j.estimated_cost) || 0), 0);

    container.innerHTML = `
    <div class="animate-slide" style="padding:15px;max-width:1400px;margin:0 auto">

      <!-- Header & Actions -->
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px">
        <div>
          <h1 style="margin:0;font-size:1.6rem;font-weight:900;display:flex;align-items:center;gap:8px">
            🛠️ ${isAR ? 'ورشة وتذاكر الصيانة والخدمات' : 'Repair & Service Tickets'}
          </h1>
          <p style="margin:4px 0 0;font-size:0.85rem;color:var(--text-muted)">
            ${isAR ? 'تتبع استلام الأجهزة، قطع الغيار، مراحل العمل، طباعة لواصق الباركود، والتحصيل' : 'Manage intake, workshop workbench, spare parts, barcode stickers & payments'}
          </p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn btn-secondary" onclick="RepairsModule.openAnalyticsModal()">
            📊 ${isAR ? 'تقرير الأرباح والورشة' : 'Workshop Analytics'}
          </button>
          <button class="btn btn-primary" onclick="RepairsModule.openIntakeModal()" style="font-weight:700">
            ➕ ${isAR ? 'تذكرة صيانة جديدة' : 'New Repair Ticket'}
          </button>
        </div>
      </div>

      <!-- KPI Stat Cards -->
      <div class="grid grid-4" style="gap:12px;margin-bottom:16px">
        <div class="card" style="padding:14px;display:flex;align-items:center;gap:12px;border-left:4px solid var(--primary)">
          <div style="font-size:2rem">📋</div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:600">${isAR ? 'إجمالي التذاكر' : 'Total Tickets'}</div>
            <div style="font-size:1.4rem;font-weight:900">${totalJobs}</div>
          </div>
        </div>
        <div class="card" style="padding:14px;display:flex;align-items:center;gap:12px;border-left:4px solid #06b6d4">
          <div style="font-size:2rem">⚙️</div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:600">${isAR ? 'قيد العمل والفحص' : 'Active Repairs'}</div>
            <div style="font-size:1.4rem;font-weight:900;color:#06b6d4">${activeJobs}</div>
          </div>
        </div>
        <div class="card" style="padding:14px;display:flex;align-items:center;gap:12px;border-left:4px solid #10b981">
          <div style="font-size:2rem">✅</div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:600">${isAR ? 'جاهز للتسليم' : 'Ready for Pickup'}</div>
            <div style="font-size:1.4rem;font-weight:900;color:#10b981">${readyJobs}</div>
          </div>
        </div>
        <div class="card" style="padding:14px;display:flex;align-items:center;gap:12px;border-left:4px solid #f59e0b">
          <div style="font-size:2rem">💰</div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:600">${isAR ? 'إجمالي المحصل (المسلم)' : 'Completed Revenue'}</div>
            <div style="font-size:1.4rem;font-weight:900;color:var(--primary)">${Utils.formatMoney(totalRevenue, c1)}</div>
          </div>
        </div>
      </div>

      <!-- Filter Toolbar & View Toggle -->
      <div class="card" style="padding:12px;margin-bottom:16px">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:space-between">
          
          <!-- Search input -->
          <div class="search-bar" style="flex:1;min-width:240px;position:relative">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="position:absolute;left:10px;top:10px;width:16px;height:16px;color:var(--text-muted)"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" class="form-control" id="repair-search" placeholder="${isAR ? 'بحث برقم التذكرة، العميل، الهاتف، الموديل، أو السيريال...' : 'Search by ticket #, customer, phone, model, IMEI...'}" value="${_searchQuery}" oninput="RepairsModule.onSearch(this.value)" style="padding-left:34px">
          </div>

          <!-- Technician Selector -->
          <div style="min-width:160px">
            <select class="form-control" id="repair-tech-filter" onchange="RepairsModule.onTechFilter(this.value)" style="font-size:0.85rem">
              <option value="">${isAR ? 'كل الفنيين' : 'All Technicians'}</option>
              ${_users.map(u => `<option value="${u.id}" ${_techFilter == u.id ? 'selected' : ''}>${Utils.sanitize(u.full_name || u.username)}</option>`).join('')}
            </select>
          </div>

          <!-- View Mode Switcher (Kanban vs Table) -->
          <div style="display:flex;gap:4px;background:var(--surface-2);padding:4px;border-radius:8px">
            <button class="btn btn-sm ${_viewMode === 'kanban' ? 'btn-primary' : 'btn-ghost'}" onclick="RepairsModule.setViewMode('kanban')" title="${isAR ? 'لوحة البطاقات (كانبان)' : 'Kanban Board'}">
              📊 ${isAR ? 'لوحة كانبان' : 'Board'}
            </button>
            <button class="btn btn-sm ${_viewMode === 'table' ? 'btn-primary' : 'btn-ghost'}" onclick="RepairsModule.setViewMode('table')" title="${isAR ? 'جدول مفصل' : 'Table View'}">
              📄 ${isAR ? 'جدول مفصل' : 'Table'}
            </button>
          </div>
        </div>

        <!-- Status Filter Tabs -->
        <div style="display:flex;gap:6px;overflow-x:auto;margin-top:12px;padding-top:10px;border-top:1px solid var(--border-color);scrollbar-width:none" id="repair-status-tabs">
          <button class="btn btn-sm ${_activeTab === 'all' ? 'btn-primary' : 'btn-secondary'}" onclick="RepairsModule.setTab('all')">
            ${isAR ? 'الكل' : 'All'} (${_jobs.length})
          </button>
          ${Object.keys(STATUS_MAP).map(k => {
            const info = STATUS_MAP[k];
            const count = _jobs.filter(j => j.status === k).length;
            return `
            <button class="btn btn-sm ${_activeTab === k ? 'btn-primary' : 'btn-secondary'}" onclick="RepairsModule.setTab('${k}')" style="white-space:nowrap">
              ${info.icon} ${isAR ? info.labelAr : info.labelEn} (${count})
            </button>`;
          }).join('')}
        </div>
      </div>

      <!-- Main Content Area: Kanban or Table -->
      <div id="repair-content-area">
        ${_viewMode === 'kanban' ? renderKanban(isAR) : renderTable(isAR)}
      </div>

    </div>`;
  }

  function getFilteredJobs() {
    return _jobs.filter(j => {
      const matchTab = _activeTab === 'all' || j.status === _activeTab;
      const matchTech = !_techFilter || String(j.technician_id) === String(_techFilter);
      
      const q = _searchQuery.trim().toLowerCase();
      if (!q) return matchTab && matchTech;

      const matchQuery = 
        (j.ref || '').toLowerCase().includes(q) ||
        (j.customer_name || '').toLowerCase().includes(q) ||
        (j.customer_phone || '').toLowerCase().includes(q) ||
        (j.device_brand || '').toLowerCase().includes(q) ||
        (j.device_model || '').toLowerCase().includes(q) ||
        (j.serial_imei || '').toLowerCase().includes(q) ||
        (j.problem_desc || '').toLowerCase().includes(q);

      return matchTab && matchTech && matchQuery;
    });
  }

  // ── Render Kanban Board ──
  function renderKanban(isAR) {
    const statusesToRender = _activeTab === 'all' 
      ? ['received', 'diagnosing', 'waiting_parts', 'in_progress', 'ready', 'delivered']
      : [_activeTab];

    const filtered = getFilteredJobs();
    const c1 = _settings.currency1 || 'USD';

    return `
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px;align-items:start">
      ${statusesToRender.map(st => {
        const info = STATUS_MAP[st];
        const colJobs = filtered.filter(j => j.status === st);
        return `
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.05)">
          
          <!-- Column Header -->
          <div style="padding:10px 14px;background:${info.bg};border-bottom:1px solid var(--border-color);display:flex;align-items:center;justify-content:space-between">
            <div style="font-weight:800;font-size:0.88rem;color:${info.color};display:flex;align-items:center;gap:6px">
              <span>${info.icon}</span> ${isAR ? info.labelAr : info.labelEn}
            </div>
            <span class="badge" style="background:${info.color};color:white;font-weight:800;font-size:0.75rem">${colJobs.length}</span>
          </div>

          <!-- Cards List -->
          <div style="padding:10px;display:flex;flex-direction:column;gap:10px;max-height:calc(100vh - 350px);overflow-y:auto;scrollbar-width:thin">
            ${colJobs.map(job => renderKanbanCard(job, isAR, c1)).join('') || `
              <div style="text-align:center;padding:24px 10px;color:var(--text-muted);font-size:0.78rem">
                ${isAR ? 'لا توجد أجهزة في هذه المرحلة' : 'No tickets in this stage'}
              </div>
            `}
          </div>

        </div>`;
      }).join('')}
    </div>`;
  }

  function renderKanbanCard(job, isAR, c1) {
    const stInfo = STATUS_MAP[job.status] || STATUS_MAP.received;
    const est = parseFloat(job.final_cost || job.estimated_cost) || 0;
    const dep = parseFloat(job.deposit) || 0;
    const remain = Math.max(0, est - dep);

    return `
    <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;padding:12px;cursor:pointer;transition:transform 0.15s,box-shadow 0.15s;position:relative"
         onclick="RepairsModule.openWorkbenchModal(${job.id})"
         onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 16px rgba(0,0,0,0.1)'"
         onmouseout="this.style.transform='';this.style.boxShadow=''">
      
      <!-- Card Header -->
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
        <span style="font-weight:900;font-size:0.82rem;color:var(--primary);font-family:monospace">${job.ref}</span>
        <span style="font-size:0.7rem;color:var(--text-muted)">📅 ${Utils.formatDate(job.created_at)}</span>
      </div>

      <!-- Device & Customer -->
      <div style="font-weight:800;font-size:0.92rem;color:var(--text-primary);margin-bottom:2px">
        📱 ${Utils.sanitize(job.device_brand || '')} ${Utils.sanitize(job.device_model || (isAR ? 'جهاز مخصص' : 'Custom Item'))}
      </div>
      <div style="font-size:0.78rem;color:var(--text-secondary);display:flex;align-items:center;gap:4px;margin-bottom:6px">
        👤 <strong>${Utils.sanitize(job.customer_name || '')}</strong> ${job.customer_phone ? `(${job.customer_phone})` : ''}
      </div>

      <!-- Reported Issue -->
      <div style="background:var(--surface);border-radius:6px;padding:6px 8px;font-size:0.75rem;color:var(--text-primary);margin-bottom:8px;line-height:1.3;border:1px dashed var(--border-color)">
        ⚠️ <strong>${isAR ? 'المشكلة:' : 'Fault:'}</strong> ${Utils.truncate(job.problem_desc || (isAR ? 'فحص شامل' : 'General Diagnostic'), 60)}
      </div>

      <!-- Cost & Deposit Breakdown -->
      <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.78rem;padding-top:6px;border-top:1px solid var(--border-color)">
        <div>
          <span style="color:var(--text-muted)">${isAR ? 'المتبقي:' : 'Due:'}</span>
          <strong style="color:${remain > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(remain, c1)}</strong>
        </div>
        <div style="display:flex;gap:4px">
          <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();RepairsModule.sendWhatsAppAlert(${job.id})" title="${isAR ? 'إرسال واتساب للعميل' : 'WhatsApp Client'}" style="padding:2px 6px;color:#10b981;font-size:0.8rem">
            💬
          </button>
          <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();RepairsModule.printDeviceSticker(${job.id})" title="${isAR ? 'طباعة لاصق الجهاز' : 'Print Device Tag'}" style="padding:2px 6px;font-size:0.8rem">
            🏷️
          </button>
          <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();RepairsModule.printClaimTicket(${job.id})" title="${isAR ? 'طباعة إيصال الاستلام' : 'Print Claim Ticket'}" style="padding:2px 6px;font-size:0.8rem">
            🧾
          </button>
        </div>
      </div>
    </div>`;
  }

  // ── Render Table View ──
  function renderTable(isAR) {
    const filtered = getFilteredJobs();
    const c1 = _settings.currency1 || 'USD';

    return `
    <div class="table-wrapper card" style="overflow-x:auto">
      <table style="font-size:0.84rem">
        <thead>
          <tr>
            <th>${isAR ? 'رقم التذكرة' : 'Ticket Ref'}</th>
            <th>${isAR ? 'التاريخ' : 'Date'}</th>
            <th>${isAR ? 'العميل' : 'Customer'}</th>
            <th>${isAR ? 'الجهاز / الصنف' : 'Device / Model'}</th>
            <th>${isAR ? 'المشكلة المعلنة' : 'Reported Issue'}</th>
            <th>${isAR ? 'الفني المسؤول' : 'Technician'}</th>
            <th>${isAR ? 'الحالة' : 'Status'}</th>
            <th style="text-align:right">${isAR ? 'التكلفة' : 'Cost'}</th>
            <th style="text-align:right">${isAR ? 'المتبقي' : 'Balance'}</th>
            <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
          </tr>
        </thead>
        <tbody>
          ${filtered.map(job => {
            const stInfo = STATUS_MAP[job.status] || STATUS_MAP.received;
            const est = parseFloat(job.final_cost || job.estimated_cost) || 0;
            const dep = parseFloat(job.deposit) || 0;
            const remain = Math.max(0, est - dep);
            const tech = _users.find(u => String(u.id) === String(job.technician_id));
            const techName = tech ? (tech.full_name || tech.username) : '-';

            return `
            <tr>
              <td style="font-weight:800;color:var(--primary);font-family:monospace">${job.ref}</td>
              <td style="font-size:0.78rem">${Utils.formatDate(job.created_at)}</td>
              <td>
                <div style="font-weight:700">${Utils.sanitize(job.customer_name || '')}</div>
                <div style="font-size:0.72rem;color:var(--text-muted)">${job.customer_phone || ''}</div>
              </td>
              <td>
                <div style="font-weight:600">${Utils.sanitize(job.device_brand || '')} ${Utils.sanitize(job.device_model || '')}</div>
                ${job.serial_imei ? `<div style="font-size:0.7rem;color:var(--text-muted);font-family:monospace">S/N: ${Utils.sanitize(job.serial_imei)}</div>` : ''}
              </td>
              <td style="max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${Utils.sanitize(job.problem_desc||'')}">
                ${Utils.sanitize(job.problem_desc || '-')}
              </td>
              <td>${techName}</td>
              <td>
                <span class="badge" style="background:${stInfo.bg};color:${stInfo.color};font-weight:700">
                  ${stInfo.icon} ${isAR ? stInfo.labelAr : stInfo.labelEn}
                </span>
              </td>
              <td style="text-align:right;font-weight:700">${Utils.formatMoney(est, c1)}</td>
              <td style="text-align:right;font-weight:800;color:${remain > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(remain, c1)}</td>
              <td style="text-align:center">
                <div style="display:flex;gap:4px;justify-content:center">
                  <button class="btn btn-primary btn-sm" onclick="RepairsModule.openWorkbenchModal(${job.id})" title="${isAR ? 'فتح طاولة العمل' : 'Open Workbench'}" style="padding:3px 8px;font-size:0.75rem">
                    🛠️ ${isAR ? 'الورشة' : 'Work'}
                  </button>
                  <button class="btn btn-secondary btn-sm" onclick="RepairsModule.sendWhatsAppAlert(${job.id})" title="${isAR ? 'واتساب' : 'WhatsApp'}" style="padding:3px 6px;color:#10b981">
                    💬
                  </button>
                  <button class="btn btn-ghost btn-sm" onclick="RepairsModule.printDeviceSticker(${job.id})" title="${isAR ? 'لاصق الجهاز' : 'Tag'}" style="padding:3px 6px">
                    🏷️
                  </button>
                  <button class="btn btn-ghost btn-sm" onclick="RepairsModule.printClaimTicket(${job.id})" title="${isAR ? 'إيصال' : 'Claim Ticket'}" style="padding:3px 6px">
                    🧾
                  </button>
                </div>
              </td>
            </tr>`;
          }).join('') || `<tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد تذاكر صيانة مطابقة' : 'No repair tickets found'}</td></tr>`}
        </tbody>
      </table>
    </div>`;
  }

  // ── Intake Form Modal (New Repair Ticket) ──
  function openIntakeModal() {
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const modalId = 'repair-intake-modal';
    document.getElementById(modalId)?.remove();

    const html = `
    <div class="modal-overlay open" id="${modalId}">
      <div class="modal" style="max-width:680px;max-height:90vh;overflow-y:auto">
        <div class="modal-header">
          <div class="modal-title" style="display:flex;align-items:center;gap:8px">
            🛠️ ${isAR ? 'استلام جهاز جديد — تذكرة صيانة' : 'New Repair Ticket Intake'}
          </div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          
          <!-- Customer Section -->
          <div style="background:var(--surface-2);border-radius:10px;padding:12px;margin-bottom:14px;border:1px solid var(--border-color)">
            <div style="font-weight:800;font-size:0.85rem;margin-bottom:8px;color:var(--primary)">
              👤 ${isAR ? 'بيانات العميل' : 'Customer Information'}
            </div>
            <div class="grid grid-2" style="gap:10px">
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'اختر العميل أو أدخل الاسم' : 'Customer'}</label>
                <select class="form-control" id="intake-cust-select" onchange="RepairsModule.onIntakeCustomerSelect(this.value)">
                  <option value="">${isAR ? 'اختر عميل مسجل...' : 'Select existing customer...'}</option>
                  ${_customers.map(c => `<option value="${c.id}">${Utils.sanitize(c.name_ar || c.name_en)} (${c.phone || '-'})</option>`).join('')}
                </select>
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'اسم العميل (إذا كان جديداً)' : 'Customer Name (New)'}</label>
                <input type="text" class="form-control" id="intake-cust-name" placeholder="${isAR ? 'الاسم الكامل' : 'Full Name'}">
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'رقم الهاتف (للتواصل والواتساب)' : 'Phone Number (WhatsApp)'}</label>
                <input type="text" class="form-control" id="intake-cust-phone" placeholder="03-123456">
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'البريد أو العنوان' : 'Address / Email'}</label>
                <input type="text" class="form-control" id="intake-cust-addr" placeholder="${isAR ? 'العنوان...' : 'Address...'}">
              </div>
            </div>
          </div>

          <!-- Device & Item Specifications -->
          <div style="background:var(--surface-2);border-radius:10px;padding:12px;margin-bottom:14px;border:1px solid var(--border-color)">
            <div style="font-weight:800;font-size:0.85rem;margin-bottom:8px;color:var(--primary)">
              📱 ${isAR ? 'مواصفات وبيانات الجهاز' : 'Device & Specifications'}
            </div>
            <div class="grid grid-3" style="gap:10px;margin-bottom:10px">
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'نوع الجهاز' : 'Device Category'}</label>
                <select class="form-control" id="intake-device-type">
                  <option value="smartphone">📱 ${isAR ? 'هاتف ذكي (Smartphone)' : 'Smartphone'}</option>
                  <option value="laptop">💻 ${isAR ? 'كمبيوتر محمول (Laptop)' : 'Laptop'}</option>
                  <option value="tablet">📱 ${isAR ? 'جهاز لوحي (Tablet/iPad)' : 'Tablet'}</option>
                  <option value="desktop">🖥️ ${isAR ? 'كمبيوتر مكتبي (PC)' : 'Desktop PC'}</option>
                  <option value="watch">⌚ ${isAR ? 'ساعة / إكسسوار' : 'Watch / Accessories'}</option>
                  <option value="tailoring">🧵 ${isAR ? 'خياطة وتعديل ملابس' : 'Tailoring / Garment'}</option>
                  <option value="appliance">🔌 ${isAR ? 'أجهزة منزلية / كهربائيات' : 'Appliance'}</option>
                  <option value="other">🛠️ ${isAR ? 'أخرى / مخصص' : 'Other'}</option>
                </select>
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'الماركة / الشركة' : 'Brand'}</label>
                <input type="text" class="form-control" id="intake-brand" placeholder="Apple, Samsung, Dell, Sony...">
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'الموديل / الطراز' : 'Model'}</label>
                <input type="text" class="form-control" id="intake-model" placeholder="iPhone 14 Pro, XPS 15...">
              </div>
            </div>

            <div class="grid grid-3" style="gap:10px">
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'الرقم التسلسلي / IMEI' : 'Serial / IMEI'}</label>
                <input type="text" class="form-control" id="intake-serial" placeholder="354890...">
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'رمز القفل / كلمة المرور' : 'Passcode / PIN'}</label>
                <input type="text" class="form-control" id="intake-passcode" placeholder="1234">
              </div>
              <div class="form-group" style="margin:0">
                <label class="form-label">${isAR ? 'الملحقات المستلمة' : 'Accessories Received'}</label>
                <input type="text" class="form-control" id="intake-accessories" placeholder="${isAR ? 'شاحن، غطاء، كابل...' : 'Charger, case, box...'}">
              </div>
            </div>
          </div>

          <!-- Problem Diagnostic & Financial Estimates -->
          <div class="form-group">
            <label class="form-label" style="font-weight:700">⚠️ ${isAR ? 'وصف العطل / المشكلة المطلوبة' : 'Reported Fault / Problem Description'}</label>
            <textarea class="form-control" id="intake-problem" rows="3" placeholder="${isAR ? 'مثال: شاشة مكسورة لا تضيء، تبديل بطارية، فحص صوت السماعة...' : 'e.g. Broken screen, battery draining fast, no power...'}"></textarea>
          </div>

          <div class="grid grid-3" style="gap:10px;background:var(--surface-2);border-radius:10px;padding:12px;border:1px solid var(--border-color)">
            <div class="form-group" style="margin:0">
              <label class="form-label">${isAR ? 'التكلفة المقدرة' : 'Estimated Cost'} (${c1})</label>
              <input type="number" class="form-control" id="intake-est-cost" placeholder="0.00" step="0.01" style="font-size:1.1rem;font-weight:800;color:var(--primary)">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">${isAR ? 'الدفعة المقدمة (العربون)' : 'Deposit Received'} (${c1})</label>
              <input type="number" class="form-control" id="intake-deposit" placeholder="0.00" step="0.01" style="font-size:1.1rem;font-weight:800;color:var(--success)">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">${isAR ? 'تاريخ التسليم المتوقع' : 'Estimated Due Date'}</label>
              <input type="date" class="form-control" id="intake-due-date" value="${Utils.today()}">
            </div>
          </div>

          <div class="grid grid-2" style="gap:10px;margin-top:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">${isAR ? 'تعيين الفني المسؤول' : 'Assign Technician'}</label>
              <select class="form-control" id="intake-technician">
                <option value="">${isAR ? 'اختر فني الصيانة...' : 'Assign to technician...'}</option>
                ${_users.map(u => `<option value="${u.id}">${Utils.sanitize(u.full_name || u.username)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">${isAR ? 'فترة الضمان على الإصلاح' : 'Repair Warranty (Days)'}</label>
              <select class="form-control" id="intake-warranty">
                <option value="0">${isAR ? 'بدون ضمان' : 'No Warranty'}</option>
                <option value="7">7 ${isAR ? 'أيام' : 'Days'}</option>
                <option value="15">15 ${isAR ? 'يوماً' : 'Days'}</option>
                <option value="30" selected>30 ${isAR ? 'يوماً (شهر)' : 'Days (1 Month)'}</option>
                <option value="90">90 ${isAR ? 'يوماً (3 أشهر)' : 'Days (3 Months)'}</option>
                <option value="180">180 ${isAR ? 'يوماً (6 أشهر)' : 'Days (6 Months)'}</option>
              </select>
            </div>
          </div>

        </div>
        <div class="modal-footer" style="display:flex;justify-content:space-between;align-items:center">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <div style="display:flex;gap:8px">
            <button class="btn btn-primary" onclick="RepairsModule.saveIntakeTicket(true)" style="font-weight:800">
              💾 ${isAR ? 'حفظ وطباعة الإيصال' : 'Save & Print Claim Ticket'}
            </button>
          </div>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  function onIntakeCustomerSelect(custId) {
    if (!custId) return;
    const cust = _customers.find(c => String(c.id) === String(custId));
    if (cust) {
      document.getElementById('intake-cust-name').value = cust.name_ar || cust.name_en || '';
      document.getElementById('intake-cust-phone').value = cust.phone || '';
      document.getElementById('intake-cust-addr').value = cust.address || '';
    }
  }

  async function saveIntakeTicket(autoPrint = false) {
    const isAR = i18n.getLang() === 'ar';
    const custSelectId = document.getElementById('intake-cust-select')?.value;
    let custName  = document.getElementById('intake-cust-name')?.value.trim();
    let custPhone = document.getElementById('intake-cust-phone')?.value.trim();
    let custAddr  = document.getElementById('intake-cust-addr')?.value.trim();

    if (!custName && !custSelectId) {
      Utils.toast(isAR ? 'يرجى إدخال اسم العميل' : 'Please enter customer name', 'error');
      return;
    }

    let customerId = custSelectId ? parseInt(custSelectId) : null;
    if (!customerId) {
      // Auto register customer if new
      customerId = await DB.add('customers', {
        name_en: custName,
        name_ar: custName,
        phone: custPhone,
        address: custAddr,
        balance: 0,
        points_balance: 0,
        status: 'active',
        created_at: new Date().toISOString()
      });
    }

    const ref = await DB.nextSeq('repair_jobs', 'REP-', 5);
    const deviceType = document.getElementById('intake-device-type')?.value || 'smartphone';
    const brand      = document.getElementById('intake-brand')?.value.trim() || '';
    const model      = document.getElementById('intake-model')?.value.trim() || '';
    const serial     = document.getElementById('intake-serial')?.value.trim() || '';
    const passcode   = document.getElementById('intake-passcode')?.value.trim() || '';
    const accessories= document.getElementById('intake-accessories')?.value.trim() || '';
    const problem    = document.getElementById('intake-problem')?.value.trim() || (isAR ? 'فحص وصيانة' : 'General Repair');
    const estCost    = parseFloat(document.getElementById('intake-est-cost')?.value) || 0;
    const deposit    = parseFloat(document.getElementById('intake-deposit')?.value) || 0;
    const dueDate    = document.getElementById('intake-due-date')?.value || Utils.today();
    const techId     = document.getElementById('intake-technician')?.value || null;
    const warranty   = parseInt(document.getElementById('intake-warranty')?.value) || 30;

    const newJob = {
      ref,
      customer_id:      customerId,
      customer_name:    custName,
      customer_phone:   custPhone,
      device_type:      deviceType,
      device_brand:     brand,
      device_model:     model,
      serial_imei:      serial,
      device_passcode:  passcode,
      accessories:      accessories,
      problem_desc:     problem,
      technician_notes: '',
      estimated_cost:   estCost,
      labor_cost:       estCost,
      final_cost:       estCost,
      deposit:          deposit,
      spare_parts:      [],
      technician_id:    techId,
      warranty_days:    warranty,
      due_date:         dueDate,
      status:           'received',
      payment_status:   deposit >= estCost && estCost > 0 ? 'paid' : (deposit > 0 ? 'partial' : 'unpaid'),
      created_at:       new Date().toISOString(),
      updated_at:       new Date().toISOString()
    };

    const jobId = await DB.add('repair_jobs', newJob);
    newJob.id = jobId;

    // Record Deposit in CashBox if paid
    if (deposit > 0) {
      const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
      if (cb && typeof cb.recordSale === 'function') {
        await cb.recordSale(deposit, `Repair Deposit ${ref} - ${custName}`);
      }
    }

    document.getElementById('repair-intake-modal')?.remove();
    Utils.toast(isAR ? `تم إنشاء تذكرة الصيانة بنجاح! رقم: ${ref}` : `Repair ticket ${ref} created successfully!`, 'success');

    await render(document.getElementById('page-content'));

    if (autoPrint) {
      printClaimTicket(newJob);
    }
  }

  // ── Workbench & Ticket Details Modal ──
  async function openWorkbenchModal(jobId) {
    await loadData();
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const modalId = 'repair-workbench-modal';
    document.getElementById(modalId)?.remove();

    const parts = job.spare_parts || [];
    const partsTotal = parts.reduce((sum, p) => sum + ((parseFloat(p.price) || 0) * (p.qty || 1)), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    const finalTotal = labor + partsTotal;
    const deposit = parseFloat(job.deposit) || 0;
    const remaining = Math.max(0, finalTotal - deposit);

    const html = `
    <div class="modal-overlay open" id="${modalId}">
      <div class="modal" style="max-width:850px;max-height:92vh;overflow-y:auto">
        <div class="modal-header">
          <div class="modal-title" style="display:flex;align-items:center;gap:10px">
            <span style="font-family:monospace;font-weight:900;color:var(--primary);font-size:1.1rem">${job.ref}</span>
            <span>— ${Utils.sanitize(job.device_brand || '')} ${Utils.sanitize(job.device_model || '')}</span>
          </div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">

          <!-- Lifecycle Status Changer Bar -->
          <div style="background:var(--surface-2);border-radius:10px;padding:12px;margin-bottom:14px;border:1px solid var(--border-color)">
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700;margin-bottom:6px;text-transform:uppercase">
              ${isAR ? 'تحديث مرحلة العمل / الحالة' : 'Update Lifecycle Status'}
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              ${Object.keys(STATUS_MAP).map(stKey => {
                const info = STATUS_MAP[stKey];
                const isActive = job.status === stKey;
                return `
                <button class="btn btn-sm ${isActive ? 'btn-primary' : 'btn-secondary'}" onclick="RepairsModule.changeStatus(${job.id}, '${stKey}')" style="font-weight:700">
                  ${info.icon} ${isAR ? info.labelAr : info.labelEn}
                </button>`;
              }).join('')}
            </div>
          </div>

          <!-- Customer & Device Overview Grid -->
          <div class="grid grid-2" style="gap:12px;margin-bottom:14px">
            <div style="background:var(--surface-2);border-radius:8px;padding:12px;border:1px solid var(--border-color)">
              <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'بيانات العميل' : 'Customer Info'}</div>
              <div style="font-weight:800;font-size:1rem;margin-top:2px">${Utils.sanitize(job.customer_name)}</div>
              <div style="font-size:0.8rem;color:var(--text-secondary);margin-top:2px">📞 ${job.customer_phone || '-'}</div>
              <div style="margin-top:8px">
                <button class="btn btn-secondary btn-sm" onclick="RepairsModule.sendWhatsAppAlert(${job.id})" style="color:#10b981;font-weight:700;font-size:0.78rem">
                  💬 ${isAR ? 'مراسلة العميل واتساب' : 'WhatsApp Message'}
                </button>
              </div>
            </div>

            <div style="background:var(--surface-2);border-radius:8px;padding:12px;border:1px solid var(--border-color)">
              <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'تفاصيل الجهاز المسلم' : 'Device Specifications'}</div>
              <div style="font-weight:800;font-size:0.95rem;margin-top:2px">📱 ${Utils.sanitize(job.device_brand||'')} ${Utils.sanitize(job.device_model||'')}</div>
              <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px">
                ${job.serial_imei ? `<strong>S/N:</strong> ${Utils.sanitize(job.serial_imei)} | ` : ''}
                ${job.device_passcode ? `<strong>PIN:</strong> <code style="background:var(--surface);padding:1px 4px;border-radius:4px">${Utils.sanitize(job.device_passcode)}</code>` : ''}
              </div>
              <div style="font-size:0.72rem;color:var(--text-muted);margin-top:2px">
                <strong>${isAR ? 'الملحقات:' : 'Accessories:'}</strong> ${Utils.sanitize(job.accessories || (isAR ? 'بدون ملحقات' : 'None'))}
              </div>
            </div>
          </div>

          <!-- Problem & Diagnostic Notes -->
          <div class="form-group">
            <label class="form-label" style="font-weight:700">⚠️ ${isAR ? 'المشكلة المعلنة من العميل' : 'Reported Fault'}</label>
            <div style="background:var(--surface-2);border:1px dashed var(--border-color);border-radius:8px;padding:10px;font-size:0.85rem">
              ${Utils.sanitize(job.problem_desc)}
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" style="font-weight:700">🔍 ${isAR ? 'تقرير الفني والتشخيص الداخلي' : 'Technician Diagnostic Report & Notes'}</label>
            <textarea class="form-control" id="wb-tech-notes" rows="2" placeholder="${isAR ? 'أدخل ملاحظات الفحص، العطل الحقيقي، والقطع اللازمة...' : 'Add technician findings, repair steps, internal notes...'}">${Utils.sanitize(job.technician_notes || '')}</textarea>
          </div>

          <!-- Spare Parts & Inventory Items Section -->
          <div style="border-top:1px solid var(--border-color);padding-top:14px;margin-top:14px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
              <div style="font-weight:800;font-size:0.95rem;display:flex;align-items:center;gap:6px">
                📦 ${isAR ? 'قطع الغيار المستهلكة من المخزون' : 'Spare Parts & Consumables'}
              </div>
              <button class="btn btn-secondary btn-sm" onclick="RepairsModule.openAddSparePartModal(${job.id})">
                ➕ ${isAR ? 'إضافة قطعة من المخزون' : 'Add Spare Part'}
              </button>
            </div>

            <div class="table-wrapper" style="margin-bottom:12px">
              <table style="font-size:0.8rem">
                <thead><tr>
                  <th>${isAR ? 'القطعة / الصنف' : 'Part Description'}</th>
                  <th style="width:60px;text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>
                  <th style="text-align:right">${isAR ? 'سعر القطعة' : 'Unit Price'}</th>
                  <th style="text-align:right">${isAR ? 'الإجمالي' : 'Total'}</th>
                  <th style="width:40px;text-align:center">✕</th>
                </tr></thead>
                <tbody>
                  ${parts.map((p, pIdx) => `
                  <tr>
                    <td style="font-weight:600">${Utils.sanitize(p.name)}</td>
                    <td style="text-align:center">${p.qty}</td>
                    <td style="text-align:right">${Utils.formatMoney(p.price, c1)}</td>
                    <td style="text-align:right;font-weight:700">${Utils.formatMoney(p.price * p.qty, c1)}</td>
                    <td style="text-align:center">
                      <button class="btn-icon" onclick="RepairsModule.removeSparePart(${job.id}, ${pIdx})" style="color:var(--danger)">✕</button>
                    </td>
                  </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;padding:12px;color:var(--text-muted)">${isAR ? 'لم يتم إضافة قطع غيار بعد' : 'No spare parts added'}</td></tr>`}
                </tbody>
              </table>
            </div>
          </div>

          <!-- Cost Calculation Summary -->
          <div style="background:var(--surface-2);border-radius:10px;padding:14px;border:1px solid var(--border-color)">
            <div class="grid grid-3" style="gap:10px;align-items:center">
              <div>
                <label class="form-label" style="font-size:0.75rem">${isAR ? 'أجرة اليد / الصيانة (Labor)' : 'Labor / Service Charge'}</label>
                <input type="number" class="form-control" id="wb-labor-cost" value="${labor}" step="0.01" oninput="RepairsModule.recalcWorkbenchTotal()" style="font-weight:700">
              </div>
              <div>
                <label class="form-label" style="font-size:0.75rem">${isAR ? 'مجموع قطع الغيار' : 'Spare Parts Total'}</label>
                <div id="wb-parts-total" style="font-weight:800;font-size:1.1rem;color:var(--primary)">${Utils.formatMoney(partsTotal, c1)}</div>
              </div>
              <div style="text-align:right">
                <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'المبلغ الإجمالي المستحق' : 'Grand Total Due'}</div>
                <div id="wb-grand-total" style="font-weight:900;font-size:1.3rem;color:var(--primary)">${Utils.formatMoney(finalTotal, c1)}</div>
                <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
                  ${isAR ? 'المدفوع سلفاً:' : 'Deposit:'} ${Utils.formatMoney(deposit, c1)} | <strong style="color:var(--danger)">${isAR ? 'المتبقي:' : 'Due:'} ${Utils.formatMoney(remaining, c1)}</strong>
                </div>
              </div>
            </div>
          </div>

        </div>
        <div class="modal-footer" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
          <div style="display:flex;gap:6px">
            <button class="btn btn-secondary btn-sm" onclick="RepairsModule.printDeviceSticker(${job.id})">
              🏷️ ${isAR ? 'طباعة لاصق' : 'Device Sticker'}
            </button>
            <button class="btn btn-secondary btn-sm" onclick="RepairsModule.printClaimTicket(${job.id})">
              🧾 ${isAR ? 'إيصال استلام' : 'Claim Ticket'}
            </button>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
            <button class="btn btn-primary" onclick="RepairsModule.saveWorkbenchChanges(${job.id})">
              💾 ${isAR ? 'حفظ التعديلات' : 'Save Changes'}
            </button>
            ${job.status !== 'delivered' ? `
            <button class="btn btn-success" onclick="RepairsModule.openDeliveryCheckoutModal(${job.id})" style="font-weight:800">
              🤝 ${isAR ? 'تسليم الجهاز والتحصيل' : 'Deliver & Collect'}
            </button>` : ''}
          </div>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  function recalcWorkbenchTotal() {
    const labor = parseFloat(document.getElementById('wb-labor-cost')?.value) || 0;
    const partsTotalText = document.getElementById('wb-parts-total')?.textContent || '0';
    const c1 = _settings.currency1 || 'USD';
    
    // Read from DOM
    const partsEl = document.getElementById('wb-parts-total');
    let partsTotal = 0;
    if (window._currentWorkbenchJob && window._currentWorkbenchJob.spare_parts) {
      partsTotal = window._currentWorkbenchJob.spare_parts.reduce((s, p) => s + (p.price * p.qty), 0);
    }
    const grand = labor + partsTotal;
    const grandEl = document.getElementById('wb-grand-total');
    if (grandEl) grandEl.textContent = Utils.formatMoney(grand, c1);
  }

  async function changeStatus(jobId, newStatus) {
    const isAR = i18n.getLang() === 'ar';
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    job.status = newStatus;
    job.updated_at = new Date().toISOString();
    await DB.update('repair_jobs', job);

    const stInfo = STATUS_MAP[newStatus];
    Utils.toast(isAR ? `تم تغيير الحالة إلى: ${stInfo.labelAr}` : `Status changed to: ${stInfo.labelEn}`, 'success');

    openWorkbenchModal(jobId);
    await render(document.getElementById('page-content'));
  }

  async function saveWorkbenchChanges(jobId) {
    const isAR = i18n.getLang() === 'ar';
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    const labor = parseFloat(document.getElementById('wb-labor-cost')?.value) || 0;
    const notes = document.getElementById('wb-tech-notes')?.value.trim() || '';

    job.labor_cost = labor;
    job.technician_notes = notes;
    
    const partsTotal = (job.spare_parts || []).reduce((s, p) => s + ((parseFloat(p.price) || 0) * (p.qty || 1)), 0);
    job.final_cost = labor + partsTotal;
    job.updated_at = new Date().toISOString();

    await DB.update('repair_jobs', job);
    Utils.toast(isAR ? 'تم حفظ التعديلات بنجاح!' : 'Workbench changes saved!', 'success');
    document.getElementById('repair-workbench-modal')?.remove();
    await render(document.getElementById('page-content'));
  }

  // ── Spare Parts Picker ──
  function openAddSparePartModal(jobId) {
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const modalId = 'add-spare-part-modal';
    document.getElementById(modalId)?.remove();

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9999">
      <div class="modal" style="max-width:500px">
        <div class="modal-header">
          <div class="modal-title">📦 ${isAR ? 'إضافة قطعة غيار من المخزون' : 'Add Spare Part from Stock'}</div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">${isAR ? 'اختر الصنف من المخزون' : 'Select Inventory Item'}</label>
            <select class="form-control" id="part-item-select" onchange="RepairsModule.onPartSelect(this.value)">
              <option value="">${isAR ? 'اختر قطعة الغيار...' : 'Select item...'}</option>
              ${_items.map(i => `<option value="${i.id}">${Utils.sanitize(i.name_ar || i.name_en)} (${Utils.formatMoney(i.selling_price, c1)} - Stock: ${i.stock_qty || 0})</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'اسم القطعة' : 'Part Name'}</label>
            <input type="text" class="form-control" id="part-name" placeholder="${isAR ? 'اسم القطعة...' : 'Part description...'}">
          </div>
          <div class="grid grid-2" style="gap:10px">
            <div class="form-group">
              <label class="form-label">${isAR ? 'الكمية' : 'Quantity'}</label>
              <input type="number" class="form-control" id="part-qty" value="1" min="1">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'سعر البيع للعميل' : 'Customer Price'} (${c1})</label>
              <input type="number" class="form-control" id="part-price" value="0.00" step="0.01" style="font-weight:700;color:var(--primary)">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="RepairsModule.confirmAddSparePart(${jobId})">${isAR ? 'إضافة القطعة' : 'Add Part'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  function onPartSelect(itemId) {
    if (!itemId) return;
    const item = _items.find(i => String(i.id) === String(itemId));
    if (item) {
      document.getElementById('part-name').value = item.name_ar || item.name_en || '';
      document.getElementById('part-price').value = item.selling_price || 0;
    }
  }

  async function confirmAddSparePart(jobId) {
    const isAR = i18n.getLang() === 'ar';
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    const itemId = document.getElementById('part-item-select')?.value;
    const name = document.getElementById('part-name')?.value.trim();
    const qty = parseFloat(document.getElementById('part-qty')?.value) || 1;
    const price = parseFloat(document.getElementById('part-price')?.value) || 0;

    if (!name) {
      Utils.toast(isAR ? 'يرجى إدخال اسم القطعة' : 'Please enter part name', 'error');
      return;
    }

    if (!job.spare_parts) job.spare_parts = [];
    job.spare_parts.push({
      item_id: itemId ? parseInt(itemId) : null,
      name,
      qty,
      price
    });

    const partsTotal = job.spare_parts.reduce((s, p) => s + (p.price * p.qty), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    job.final_cost = labor + partsTotal;
    job.updated_at = new Date().toISOString();

    await DB.update('repair_jobs', job);
    document.getElementById('add-spare-part-modal')?.remove();
    Utils.toast(isAR ? 'تمت إضافة قطعة الغيار' : 'Spare part added', 'success');
    openWorkbenchModal(jobId);
  }

  async function removeSparePart(jobId, pIdx) {
    const job = _jobs.find(j => j.id === jobId);
    if (!job || !job.spare_parts) return;

    job.spare_parts.splice(pIdx, 1);
    const partsTotal = job.spare_parts.reduce((s, p) => s + (p.price * p.qty), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    job.final_cost = labor + partsTotal;
    job.updated_at = new Date().toISOString();

    await DB.update('repair_jobs', job);
    openWorkbenchModal(jobId);
  }

  // ── Delivery & Final Settlement Modal ──
  function openDeliveryCheckoutModal(jobId) {
    const isAR = i18n.getLang() === 'ar';
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';
    const rate = _settings.exchRate || 89500;

    const parts = job.spare_parts || [];
    const partsTotal = parts.reduce((sum, p) => sum + ((parseFloat(p.price) || 0) * (p.qty || 1)), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    const finalTotal = labor + partsTotal;
    const deposit = parseFloat(job.deposit) || 0;
    const remaining = Math.max(0, finalTotal - deposit);
    const remainC2 = Utils.calcSecondaryPrice(remaining, c1, c2, rate);

    const modalId = 'repair-delivery-modal';
    document.getElementById(modalId)?.remove();

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9999">
      <div class="modal" style="max-width:540px">
        <div class="modal-header">
          <div class="modal-title" style="display:flex;align-items:center;gap:8px">
            🤝 ${isAR ? 'تسليم الجهاز وتحصيل المبلغ المتبقي' : 'Deliver Device & Collect Payment'}
          </div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          
          <div style="background:var(--surface-2);border-radius:10px;padding:14px;margin-bottom:14px;border:1px solid var(--border-color);text-align:center">
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'المبلغ المتبقي للتحصيل' : 'Remaining Balance Due'}</div>
            <div style="font-size:2rem;font-weight:900;color:var(--primary);margin:4px 0">${Utils.formatMoney(remaining, c1)}</div>
            <div style="font-size:0.95rem;font-weight:700;color:var(--warning)">${Utils.formatCurrency(remainC2, c2, (c2==='LBP'||c2==='IQD')?0:2)} ${c2}</div>
          </div>

          <div class="grid grid-2" style="gap:10px;margin-bottom:12px">
            <div class="form-group">
              <label class="form-label">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
              <select class="form-control" id="delivery-pay-method" style="font-weight:700">
                <option value="cash">💵 ${isAR ? 'نقداً (الصندوق)' : 'Cash'}</option>
                <option value="card">💳 ${isAR ? 'بطاقة مصرفية' : 'Card'}</option>
                <option value="credit">👤 ${isAR ? 'على الحساب (دين)' : 'On Account (Credit)'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'المبلغ المسدد الآن' : 'Amount Paid Now'} (${c1})</label>
              <input type="number" class="form-control" id="delivery-paid-amt" value="${remaining}" step="0.01" style="font-size:1.1rem;font-weight:800;color:var(--success)">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isAR ? 'ملاحظات التسليم والضمان' : 'Delivery & Warranty Notes'}</label>
            <input type="text" class="form-control" id="delivery-notes" value="${isAR ? `ضمان صيانة ${job.warranty_days || 30} يوماً` : `${job.warranty_days || 30} Days Warranty`}">
          </div>

          <div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-radius:8px;padding:10px;font-size:0.78rem;color:var(--success)">
            ✅ ${isAR ? 'عند إتمام التسليم، سيتم خصم قطع الغيار تلقائياً من المخزون وتسجيل الإيراد في الصندوق.' : 'Upon delivery, spare parts will be deducted from inventory stock & payment recorded in CashBox.'}
          </div>

        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-success" onclick="RepairsModule.completeDelivery(${job.id})" style="font-weight:800">
            ✅ ${isAR ? 'إتمام التسليم وطباعة الفاتورة' : 'Complete Delivery & Invoice'}
          </button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  async function completeDelivery(jobId) {
    const isAR = i18n.getLang() === 'ar';
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    const method  = document.getElementById('delivery-pay-method')?.value || 'cash';
    const paidAmt = parseFloat(document.getElementById('delivery-paid-amt')?.value) || 0;
    const notes   = document.getElementById('delivery-notes')?.value || '';

    // 1. Deduct consumed spare parts from stock
    const parts = job.spare_parts || [];
    for (const part of parts) {
      if (part.item_id) {
        const item = await DB.get('items', part.item_id);
        if (item) {
          const newStock = Math.max(0, (item.stock_qty || 0) - (part.qty || 1));
          await DB.update('items', { ...item, stock_qty: newStock });
          
          await DB.add('stock_movements', {
            item_id: part.item_id,
            type: 'repair_consumption',
            ref: job.ref,
            qty: -(part.qty || 1),
            notes: `Consumed in Repair ${job.ref} (${job.device_brand} ${job.device_model})`,
            created_at: new Date().toISOString()
          });
        }
      }
    }

    // 2. Record payment in CashBox if cash and > 0
    if (paidAmt > 0 && method === 'cash') {
      const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
      if (cb && typeof cb.recordSale === 'function') {
        await cb.recordSale(paidAmt, `Repair Final Delivery ${job.ref} - ${job.customer_name}`);
      }
    }

    // 3. Update customer balance if on-account credit
    const partsTotal = parts.reduce((s, p) => s + (p.price * p.qty), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    const finalTotal = labor + partsTotal;
    const deposit = parseFloat(job.deposit) || 0;
    const unpaidDebt = Math.max(0, finalTotal - deposit - paidAmt);

    if (unpaidDebt > 0 && job.customer_id) {
      const cust = await DB.get('customers', job.customer_id);
      if (cust) {
        await DB.update('customers', {
          ...cust,
          balance: Utils.round((cust.balance || 0) + unpaidDebt)
        });
      }
    }

    // 4. Update Job Status to Delivered
    job.status = 'delivered';
    job.delivery_date = new Date().toISOString();
    job.delivery_notes = notes;
    job.payment_method = method;
    job.amount_collected_delivery = paidAmt;
    job.payment_status = unpaidDebt <= 0 ? 'paid' : 'partial';
    job.updated_at = new Date().toISOString();

    await DB.update('repair_jobs', job);

    document.getElementById('repair-delivery-modal')?.remove();
    document.getElementById('repair-workbench-modal')?.remove();

    Utils.toast(isAR ? `تم تسليم الجهاز بنجاح! تم حفظ الفاتورة وتحديث المخزون.` : `Device delivered successfully! Invoice generated.`, 'success');

    await render(document.getElementById('page-content'));
    printFinalInvoice(job);
  }

  // ── WhatsApp Message Generator ──
  function sendWhatsAppAlert(jobId) {
    const isAR = i18n.getLang() === 'ar';
    const job = _jobs.find(j => j.id === jobId);
    if (!job) return;

    const phone = (job.customer_phone || '').replace(/[^0-9+]/g, '');
    if (!phone) {
      Utils.toast(isAR ? 'لا يوجد رقم هاتف مسجل لهذا العميل' : 'No phone number for this customer', 'warning');
      return;
    }

    const c1 = _settings.currency1 || 'USD';
    const partsTotal = (job.spare_parts || []).reduce((s, p) => s + (p.price * p.qty), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    const total = labor + partsTotal;
    const remain = Math.max(0, total - (parseFloat(job.deposit) || 0));

    let msg = '';
    if (job.status === 'ready') {
      msg = `مرحباً ${job.customer_name}،\nنود إعلامكم بأن جهازكم *${job.device_brand || ''} ${job.device_model || ''}* (رقم التذكرة: *${job.ref}*) أصبح *جاهزاً للاستلام* لدى *${_settings.companyName}*.\n\n💰 المبلغ المتبقي للاستلام: *${Utils.formatMoney(remain, c1)}*\n📍 العنوان: ${_settings.companyAddress || ''}\nشكراً لثقتكم بنا!`;
    } else {
      msg = `مرحباً ${job.customer_name}،\nتحديث بخصوص جهازكم *${job.device_brand || ''} ${job.device_model || ''}* (رقم التذكرة: *${job.ref}*):\nالحالة الحالية: *${STATUS_MAP[job.status]?.labelAr || job.status}*\nالمبلغ المقدر: *${Utils.formatMoney(total, c1)}*\nشكراً لتواصلكم مع *${_settings.companyName}*.`;
    }

    const url = `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  }

  // ── Print Customer Claim Ticket (80mm Thermal) ──
  async function printClaimTicket(job) {
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const est = parseFloat(job.estimated_cost || job.final_cost) || 0;
    const dep = parseFloat(job.deposit) || 0;

    const barcodeSvg = Utils.generateBarcodeSVG ? Utils.generateBarcodeSVG(job.ref, 40, 1.2, true) : '';

    const html = `
    <div class="receipt-80mm" style="font-family:'Cairo','Inter',sans-serif;text-align:center;font-size:8.5pt;line-height:1.4">
      <div style="font-weight:900;font-size:13pt">${Utils.sanitize(_settings.companyName)}</div>
      <div style="font-size:7.5pt;color:#444">${Utils.sanitize(_settings.companyAddress || '')}</div>
      <div style="font-size:7.5pt;color:#444">${isAR ? 'هاتف: ' : 'Tel: '}${Utils.sanitize(_settings.companyPhone || '')}</div>
      <div style="border-top:1px dashed #000;margin:6px 0"></div>
      <div style="font-weight:900;font-size:11pt;color:#000">🛠️ ${isAR ? 'إيصال استلام جهاز للصيانة' : 'REPAIR CLAIM TICKET'}</div>
      
      <div style="margin:8px 0">
        ${barcodeSvg}
      </div>

      <div style="border-top:1px dashed #000;margin:6px 0"></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'رقم التذكرة:' : 'Ticket #:'}</span><strong>${job.ref}</strong></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'تاريخ الاستلام:' : 'Intake Date:'}</span><span>${Utils.formatDate(job.created_at)}</span></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'العميل:' : 'Customer:'}</span><strong>${Utils.sanitize(job.customer_name)}</strong></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'الهاتف:' : 'Phone:'}</span><span>${job.customer_phone || '-'}</span></div>
      <div style="border-top:1px dashed #000;margin:6px 0"></div>

      <div style="text-align:left;direction:ltr;background:#f1f5f9;padding:6px;border-radius:4px;margin-bottom:6px">
        <div style="font-weight:800;font-size:9.5pt">📱 ${Utils.sanitize(job.device_brand || '')} ${Utils.sanitize(job.device_model || '')}</div>
        ${job.serial_imei ? `<div style="font-size:7.5pt">S/N: ${Utils.sanitize(job.serial_imei)}</div>` : ''}
        ${job.accessories ? `<div style="font-size:7.5pt">Acc: ${Utils.sanitize(job.accessories)}</div>` : ''}
      </div>

      <div style="text-align:right;background:#fef3c7;padding:6px;border-radius:4px;font-size:8pt;margin-bottom:6px">
        <strong>⚠️ ${isAR ? 'العطل المعلن:' : 'Fault:'}</strong> ${Utils.sanitize(job.problem_desc)}
      </div>

      <div style="border-top:1px dashed #000;margin:6px 0"></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'التكلفة التقديرية:' : 'Estimated Cost:'}</span><strong>${Utils.formatMoney(est, c1)}</strong></div>
      <div style="display:flex;justify-content:space-between;color:#16a34a"><span>${isAR ? 'العربون / المدفوع:' : 'Deposit Paid:'}</span><strong>${Utils.formatMoney(dep, c1)}</strong></div>
      <div style="display:flex;justify-content:space-between;font-weight:800"><span>${isAR ? 'المتبقي المقدر:' : 'Est. Due:'}</span><strong>${Utils.formatMoney(Math.max(0, est - dep), c1)}</strong></div>
      <div style="display:flex;justify-content:space-between;font-size:7.5pt;margin-top:2px"><span>${isAR ? 'موعد التسليم المتوقع:' : 'Due Date:'}</span><span>${Utils.formatDate(job.due_date)}</span></div>

      <div style="border-top:1px dashed #000;margin:8px 0;padding-top:4px;font-size:6.8pt;color:#555;text-align:justify">
        ${isAR 
          ? '• يرجى إبراز هذا الإيصال عند الاستلام. المحل غير مسؤول عن الأجهزة المتروكة لأكثر من 30 يوماً بعد الإشعار بالجاهزية.' 
          : '• Please present this claim ticket for pickup. Unclaimed devices after 30 days are subject to disposal.'}
      </div>

      <div style="margin-top:15px;display:flex;justify-content:space-between;font-size:7.5pt">
        <div>${isAR ? 'توقيع العميل: ....................' : 'Customer Sig: ....................'}</div>
      </div>
    </div>`;

    await Utils.printElement(html, `Claim-${job.ref}`);
  }

  // ── Print Small Device Sticker (Adhesive Tag) ──
  async function printDeviceSticker(job) {
    const isAR = i18n.getLang() === 'ar';
    const barcodeSvg = Utils.generateBarcodeSVG ? Utils.generateBarcodeSVG(job.ref, 30, 1.1, false) : '';

    const html = `
    <div style="width:200px;font-family:'Cairo','Inter',sans-serif;text-align:center;padding:4px;border:1px solid #000;border-radius:4px;line-height:1.2">
      <div style="font-weight:900;font-size:9pt">${job.ref}</div>
      <div style="margin:2px 0">${barcodeSvg}</div>
      <div style="font-weight:800;font-size:8pt">${Utils.sanitize(job.customer_name)} (${job.customer_phone || ''})</div>
      <div style="font-size:7.5pt;font-weight:700">${Utils.sanitize(job.device_brand || '')} ${Utils.sanitize(job.device_model || '')}</div>
      <div style="font-size:6.5pt;color:#333">${Utils.formatDate(job.created_at)}</div>
    </div>`;

    await Utils.printElement(html, `Tag-${job.ref}`);
  }

  // ── Print Final Delivery Invoice & Warranty Certificate ──
  async function printFinalInvoice(job) {
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const parts = job.spare_parts || [];
    const partsTotal = parts.reduce((s, p) => s + (p.price * p.qty), 0);
    const labor = parseFloat(job.labor_cost !== undefined ? job.labor_cost : job.estimated_cost) || 0;
    const grand = labor + partsTotal;
    const deposit = parseFloat(job.deposit) || 0;
    const paidAtDelivery = parseFloat(job.amount_collected_delivery) || (grand - deposit);

    const html = `
    <div class="receipt-80mm" style="font-family:'Cairo','Inter',sans-serif;text-align:center;font-size:8.5pt;line-height:1.4">
      <div style="font-weight:900;font-size:13pt">${Utils.sanitize(_settings.companyName)}</div>
      <div style="font-size:7.5pt;color:#444">${Utils.sanitize(_settings.companyAddress || '')}</div>
      <div style="border-top:1px dashed #000;margin:6px 0"></div>
      <div style="font-weight:900;font-size:11pt">📄 ${isAR ? 'فاتورة صيانة وضمان' : 'REPAIR INVOICE & WARRANTY'}</div>
      <div style="display:flex;justify-content:space-between;margin-top:4px"><span>${isAR ? 'رقم التذكرة:' : 'Ref:'}</span><strong>${job.ref}</strong></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'تاريخ التسليم:' : 'Date:'}</span><span>${Utils.formatDate(job.delivery_date || job.created_at)}</span></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'العميل:' : 'Customer:'}</span><strong>${Utils.sanitize(job.customer_name)}</strong></div>
      <div style="border-top:1px dashed #000;margin:6px 0"></div>

      <div style="text-align:left;direction:ltr;background:#f8fafc;padding:6px;border-radius:4px;margin-bottom:6px">
        <div style="font-weight:800;font-size:9pt">📱 ${Utils.sanitize(job.device_brand || '')} ${Utils.sanitize(job.device_model || '')}</div>
        ${job.serial_imei ? `<div style="font-size:7.5pt">S/N: ${Utils.sanitize(job.serial_imei)}</div>` : ''}
      </div>

      <div style="border-top:1px solid #000;margin:6px 0"></div>
      <div style="display:flex;justify-content:space-between"><span>${isAR ? 'أجرة الصيانة واليد:' : 'Labor & Service:'}</span><span>${Utils.formatMoney(labor, c1)}</span></div>
      ${parts.map(p => `
        <div style="display:flex;justify-content:space-between;font-size:8pt;color:#333">
          <span>${p.qty} × ${Utils.sanitize(p.name)}</span>
          <span>${Utils.formatMoney(p.price * p.qty, c1)}</span>
        </div>
      `).join('')}

      <div style="border-top:2px solid #000;margin:6px 0;padding-top:4px"></div>
      <div style="display:flex;justify-content:space-between;font-weight:900;font-size:11pt"><span>${isAR ? 'الإجمالي:' : 'TOTAL:'}</span><span>${Utils.formatMoney(grand, c1)}</span></div>
      <div style="display:flex;justify-content:space-between;font-size:8pt"><span>${isAR ? 'العربون المسدد مسبقاً:' : 'Deposit Paid:'}</span><span>${Utils.formatMoney(deposit, c1)}</span></div>
      <div style="display:flex;justify-content:space-between;font-weight:700;color:#16a34a"><span>${isAR ? 'المحصل عند التسليم:' : 'Paid at Delivery:'}</span><span>${Utils.formatMoney(paidAtDelivery, c1)}</span></div>

      <div style="border-top:1px dashed #000;margin:8px 0;padding-top:6px">
        <div style="font-weight:900;color:#16a34a">🛡️ ${isAR ? `ضمان صيانة معتمد لمدة ${job.warranty_days || 30} يوماً` : `Certified ${job.warranty_days || 30}-Day Repair Warranty`}</div>
        <div style="font-size:7pt;color:#555;margin-top:2px">${isAR ? 'الضمان يشمل القطع المستبدلة فقط ولا يشمل سوء الاستخدام أو الكسر أو السوائل.' : 'Warranty covers replaced parts only. Water damage & physical drops excluded.'}</div>
      </div>

      <div style="text-align:center;font-size:7.5pt;margin-top:10px">${isAR ? 'شكراً لزيارتكم!' : 'Thank you for your business!'}</div>
    </div>`;

    await Utils.printElement(html, `Invoice-${job.ref}`);
  }

  // ── Workshop Analytics & Revenue Modal ──
  async function openAnalyticsModal() {
    await loadData();
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const modalId = 'repair-analytics-modal';
    document.getElementById(modalId)?.remove();

    const deliveredJobs = _jobs.filter(j => j.status === 'delivered');
    const totalRevenue = deliveredJobs.reduce((s, j) => s + (parseFloat(j.final_cost || j.estimated_cost) || 0), 0);
    const totalLabor = deliveredJobs.reduce((s, j) => s + (parseFloat(j.labor_cost || j.estimated_cost) || 0), 0);
    
    let totalPartsRev = 0;
    deliveredJobs.forEach(j => {
      (j.spare_parts || []).forEach(p => { totalPartsRev += (parseFloat(p.price) || 0) * (p.qty || 1); });
    });

    const netProfit = totalLabor + (totalPartsRev * 0.4); // Est 40% margin on parts + 100% on labor

    const html = `
    <div class="modal-overlay open" id="${modalId}">
      <div class="modal" style="max-width:650px">
        <div class="modal-header">
          <div class="modal-title">📊 ${isAR ? 'تقرير أرباح وأداء ورشة الصيانة' : 'Workshop Revenue & Performance Report'}</div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-3" style="gap:10px;margin-bottom:16px">
            <div class="card" style="padding:12px;text-align:center">
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الأجهزة المسلمة' : 'Repairs Delivered'}</div>
              <div style="font-size:1.4rem;font-weight:900;color:var(--primary);margin-top:2px">${deliveredJobs.length}</div>
            </div>
            <div class="card" style="padding:12px;text-align:center">
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إجمالي دخل الصيانة' : 'Total Revenue'}</div>
              <div style="font-size:1.4rem;font-weight:900;color:#10b981;margin-top:2px">${Utils.formatMoney(totalRevenue, c1)}</div>
            </div>
            <div class="card" style="padding:12px;text-align:center">
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'أرباح أجور اليد' : 'Labor Revenue'}</div>
              <div style="font-size:1.4rem;font-weight:900;color:#06b6d4;margin-top:2px">${Utils.formatMoney(totalLabor, c1)}</div>
            </div>
          </div>

          <div style="background:var(--surface-2);border-radius:10px;padding:14px;border:1px solid var(--border-color)">
            <div style="font-weight:800;font-size:0.85rem;margin-bottom:8px">📱 ${isAR ? 'أكثر الأجهزة طلباً للصيانة' : 'Top Repaired Device Categories'}</div>
            <div style="display:flex;flex-direction:column;gap:6px">
              ${['smartphone', 'laptop', 'tablet', 'desktop', 'watch', 'other'].map(type => {
                const count = _jobs.filter(j => j.device_type === type).length;
                if (count === 0) return '';
                const pct = totalRevenue > 0 ? Math.round((count / _jobs.length) * 100) : 0;
                return `
                <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem">
                  <span style="text-transform:capitalize">${type}</span>
                  <span style="font-weight:700">${count} (${pct}%)</span>
                </div>`;
              }).join('')}
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-primary" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  // ── Toolbar Handlers ──
  function onSearch(query) {
    _searchQuery = query;
    const area = document.getElementById('repair-content-area');
    if (area) area.innerHTML = _viewMode === 'kanban' ? renderKanban(i18n.getLang() === 'ar') : renderTable(i18n.getLang() === 'ar');
  }

  function onTechFilter(techId) {
    _techFilter = techId;
    const area = document.getElementById('repair-content-area');
    if (area) area.innerHTML = _viewMode === 'kanban' ? renderKanban(i18n.getLang() === 'ar') : renderTable(i18n.getLang() === 'ar');
  }

  function setTab(tabKey) {
    _activeTab = tabKey;
    document.querySelectorAll('#repair-status-tabs .btn').forEach(b => b.className = 'btn btn-sm btn-secondary');
    event?.target?.classList?.replace('btn-secondary', 'btn-primary');
    const area = document.getElementById('repair-content-area');
    if (area) area.innerHTML = _viewMode === 'kanban' ? renderKanban(i18n.getLang() === 'ar') : renderTable(i18n.getLang() === 'ar');
  }

  function setViewMode(mode) {
    _viewMode = mode;
    const area = document.getElementById('repair-content-area');
    if (area) area.innerHTML = _viewMode === 'kanban' ? renderKanban(i18n.getLang() === 'ar') : renderTable(i18n.getLang() === 'ar');
  }

  return {
    render,
    openIntakeModal,
    onIntakeCustomerSelect,
    saveIntakeTicket,
    openWorkbenchModal,
    recalcWorkbenchTotal,
    changeStatus,
    saveWorkbenchChanges,
    openAddSparePartModal,
    onPartSelect,
    confirmAddSparePart,
    removeSparePart,
    openDeliveryCheckoutModal,
    completeDelivery,
    sendWhatsAppAlert,
    printClaimTicket,
    printDeviceSticker,
    printFinalInvoice,
    openAnalyticsModal,
    onSearch,
    onTechFilter,
    setTab,
    setViewMode
  };
})();

window.RepairsModule = RepairsModule;
window.repairsModule = RepairsModule;
window.Repairs = RepairsModule;
