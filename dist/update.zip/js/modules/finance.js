/* ================================================================
   NexPOS — Finance Module
   ================================================================ */

const Finance = (() => {

  // ── Chart of Accounts ─────────────────────────────────────────
  async function renderAccounts(container) {
    const accounts = await DB.getAll('accounts');
    const isAR = i18n.getLang() === 'ar';
    const typeColors = { asset:'primary', liability:'danger', equity:'warning', revenue:'success', expense:'secondary' };

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'دليل الحسابات' : 'Chart of Accounts'}</h1>
          <p>${isAR ? `${accounts.length} حساب` : `${accounts.length} accounts`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Finance.openAccountForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'حساب جديد' : 'New Account'}
          </button>
        </div>
      </div>

      <div class="toolbar mb-3">
        <div class="search-bar flex-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" placeholder="${isAR?'بحث...':'Search...'}" oninput="Finance.searchAccounts(this.value)" style="padding-left:34px">
        </div>
        <select class="form-control" id="acc-type-filter" style="width:160px" onchange="Finance.filterAccounts()">
          <option value="">${isAR?'كل الأنواع':'All Types'}</option>
          <option value="asset">${isAR?'أصول':'Asset'}</option>
          <option value="liability">${isAR?'خصوم':'Liability'}</option>
          <option value="equity">${isAR?'حقوق ملكية':'Equity'}</option>
          <option value="revenue">${isAR?'إيرادات':'Revenue'}</option>
          <option value="expense">${isAR?'مصروفات':'Expense'}</option>
        </select>
      </div>

      <div class="table-wrapper">
        <table id="acc-table">
          <thead><tr>
            <th>${isAR?'الرمز':'Code'}</th>
            <th>${isAR?'اسم الحساب':'Account Name'}</th>
            <th>${isAR?'النوع':'Type'}</th>
            <th>${isAR?'الرصيد':'Balance'}</th>
            <th>${isAR?'إجراءات':'Actions'}</th>
          </tr></thead>
          <tbody id="acc-tbody">
            ${accounts.map(a => `
            <tr data-type="${a.type}" data-name="${(a.name_ar||'').toLowerCase()} ${(a.name||'').toLowerCase()} ${(a.code||'').toLowerCase()}">
              <td style="font-weight:700;color:var(--primary);font-size:0.82rem">${a.code}</td>
              <td style="padding-left:${(a.level||1)*10}px">
                <span style="font-weight:${a.level<=1?'700':'500'}">${isAR?(a.name_ar||a.name):(a.name||a.name_ar)}</span>
              </td>
              <td><span class="badge badge-${typeColors[a.type]||'secondary'}">${a.type}</span></td>
              <td style="font-weight:700">${Utils.formatMoney(a.balance||0)}</td>
              <td>
                <div style="display:flex;gap:4px">
                  <button class="btn btn-ghost btn-sm" onclick="Finance.openAccountForm(${a.id})">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                  </button>
                  <button class="btn btn-ghost btn-sm" onclick="Finance.deleteAccount(${a.id})" style="color:var(--danger)">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                  </button>
                </div>
              </td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Account Form Modal -->
    <div class="modal-overlay" id="acc-modal">
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <div class="modal-title" id="acc-modal-title">${isAR?'حساب جديد':'New Account'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('acc-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'رمز الحساب':'Account Code'}</label>
              <input type="text" class="form-control" id="acc-code" placeholder="e.g. 1100">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'النوع':'Type'}</label>
              <select class="form-control" id="acc-type">
                <option value="asset">${isAR?'أصول':'Asset'}</option>
                <option value="liability">${isAR?'خصوم':'Liability'}</option>
                <option value="equity">${isAR?'حقوق ملكية':'Equity'}</option>
                <option value="revenue">${isAR?'إيرادات':'Revenue'}</option>
                <option value="expense">${isAR?'مصروفات':'Expense'}</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'الاسم (عربي)':'Name (Arabic)'}</label>
            <input type="text" class="form-control" id="acc-name-ar" placeholder="اسم الحساب" dir="rtl">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'الاسم (إنجليزي)':'Name (English)'}</label>
            <input type="text" class="form-control" id="acc-name-en" placeholder="Account name">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'الرصيد الافتتاحي':'Opening Balance'}</label>
            <input type="number" class="form-control" id="acc-balance" value="0" step="0.01">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'ملاحظات':'Notes'}</label>
            <input type="text" class="form-control" id="acc-notes" placeholder="${isAR?'ملاحظات...':'Notes...'}">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('acc-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="Finance.saveAccount()">${isAR?'حفظ':'Save'}</button>
        </div>
      </div>
    </div>`;
  }

  function searchAccounts(q) {
    document.querySelectorAll('#acc-tbody tr').forEach(row => {
      row.style.display = !q || row.dataset.name?.includes(q.toLowerCase()) ? '' : 'none';
    });
  }

  function filterAccounts() {
    const type = document.getElementById('acc-type-filter')?.value;
    document.querySelectorAll('#acc-tbody tr').forEach(row => {
      row.style.display = !type || row.dataset.type === type ? '' : 'none';
    });
  }

  async function openAccountForm(id = null) {
    window._editAccId = id;
    ['acc-code','acc-name-ar','acc-name-en','acc-notes'].forEach(f => { const el=document.getElementById(f); if(el) el.value=''; });
    document.getElementById('acc-balance').value = '0';
    if (id) {
      const acc = await DB.get('accounts', id);
      if (acc) {
        document.getElementById('acc-code').value    = acc.code||'';
        document.getElementById('acc-name-ar').value = acc.name_ar||'';
        document.getElementById('acc-name-en').value = acc.name||'';
        document.getElementById('acc-type').value    = acc.type||'asset';
        document.getElementById('acc-balance').value = acc.balance||0;
        document.getElementById('acc-notes').value   = acc.notes||'';
      }
    }
    Utils.openModal('acc-modal');
  }

  async function saveAccount() {
    const data = {
      code:    document.getElementById('acc-code').value.trim(),
      name:    document.getElementById('acc-name-en').value.trim(),
      name_ar: document.getElementById('acc-name-ar').value.trim(),
      type:    document.getElementById('acc-type').value,
      balance: parseFloat(document.getElementById('acc-balance').value)||0,
      notes:   document.getElementById('acc-notes').value,
      level:   2,
    };
    if (!data.code) { Utils.toast(i18n.t('common.required'), 'warning'); return; }
    if (window._editAccId) await DB.update('accounts', { ...data, id: window._editAccId });
    else await DB.add('accounts', data);
    Utils.closeModal('acc-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await renderAccounts(document.getElementById('page-content'));
  }

  function deleteAccount(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('accounts', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await renderAccounts(document.getElementById('page-content'));
    });
  }

  // ── Journal Entries ───────────────────────────────────────────
  async function renderJournals(container) {
    const journals = await DB.getAll('journals');
    const accounts = await DB.getAll('accounts');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'قيود اليومية' : 'Journal Entries'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Finance.openJournalForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'قيد جديد' : 'New Journal'}
          </button>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR?'الرقم':'Ref'}</th>
            <th>${isAR?'التاريخ':'Date'}</th>
            <th>${isAR?'الوصف':'Description'}</th>
            <th>${isAR?'مدين':'Debit'}</th>
            <th>${isAR?'دائن':'Credit'}</th>
            <th>${isAR?'الحالة':'Status'}</th>
            <th>${isAR?'إجراءات':'Actions'}</th>
          </tr></thead>
          <tbody>
            ${journals.slice().reverse().map(j => `
            <tr>
              <td style="font-weight:700;color:var(--primary)">${j.ref||'-'}</td>
              <td style="font-size:0.78rem">${Utils.formatDate(j.date||j.created_at)}</td>
              <td>${Utils.truncate(j.description||'-',40)}</td>
              <td style="font-weight:700;color:var(--danger)">${Utils.formatMoney(j.total_debit||0)}</td>
              <td style="font-weight:700;color:var(--success)">${Utils.formatMoney(j.total_credit||0)}</td>
              <td><span class="badge badge-${j.status==='posted'?'success':'warning'}">${j.status||'draft'}</span></td>
              <td>
                <div style="display:flex;gap:4px">
                  <button class="btn btn-ghost btn-sm" onclick="Finance.openJournalForm(${j.id})">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                  </button>
                  <button class="btn btn-ghost btn-sm" onclick="Finance.deleteJournal(${j.id})" style="color:var(--danger)">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                  </button>
                </div>
              </td>
            </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد قيود':'No entries'}</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Journal Modal -->
    <div class="modal-overlay" id="jrn-modal">
      <div class="modal" style="max-width:700px">
        <div class="modal-header">
          <div class="modal-title">${isAR ? 'قيد يومية' : 'Journal Entry'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('jrn-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-3 mb-3">
            <div class="form-group">
              <label class="form-label">${isAR?'التاريخ':'Date'}</label>
              <input type="date" class="form-control" id="jrn-date" value="${Utils.today()}">
            </div>
            <div class="form-group" style="grid-column:2/-1">
              <label class="form-label">${isAR?'الوصف':'Description'}</label>
              <input type="text" class="form-control" id="jrn-desc" placeholder="${isAR?'وصف القيد...':'Journal description...'}">
            </div>
          </div>
          <div id="jrn-lines" style="margin-bottom:12px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
              <strong style="font-size:0.85rem">${isAR?'السطور':'Lines'}</strong>
              <button class="btn btn-secondary btn-sm" onclick="Finance.addJrnLine()">+ ${isAR?'سطر':'Line'}</button>
            </div>
            <table style="width:100%;font-size:0.82rem">
              <thead style="background:var(--surface-2)">
                <tr>
                  <th style="padding:6px 8px;text-align:left">${isAR?'الحساب':'Account'}</th>
                  <th style="padding:6px 8px;text-align:left">${isAR?'الوصف':'Description'}</th>
                  <th style="padding:6px 8px;text-align:right">${isAR?'مدين':'Debit'}</th>
                  <th style="padding:6px 8px;text-align:right">${isAR?'دائن':'Credit'}</th>
                  <th style="padding:6px 8px;width:30px"></th>
                </tr>
              </thead>
              <tbody id="jrn-lines-body"></tbody>
              <tfoot>
                <tr style="border-top:2px solid var(--border-color)">
                  <td colspan="2" style="padding:6px 8px;font-weight:700">${isAR?'الإجمالي':'Totals'}</td>
                  <td style="padding:6px 8px;text-align:right;font-weight:800;color:var(--danger)" id="jrn-total-dr">$0.00</td>
                  <td style="padding:6px 8px;text-align:right;font-weight:800;color:var(--success)" id="jrn-total-cr">$0.00</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
          <div id="jrn-balance-err" style="display:none;color:var(--danger);font-size:0.78rem;font-weight:600;margin-top:4px">
            ⚠️ ${isAR?'القيد غير متوازن!':'Journal not balanced!'}
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('jrn-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-secondary" onclick="Finance.saveJournal('draft')">${isAR?'حفظ كمسودة':'Save Draft'}</button>
          <button class="btn btn-primary" onclick="Finance.saveJournal('posted')">${isAR?'ترحيل':'Post'}</button>
        </div>
      </div>
    </div>`;

    window._jrnAccounts = accounts;
    window._jrnLines = [];
  }

  function addJrnLine() {
    const isAR = i18n.getLang() === 'ar';
    window._jrnLines = window._jrnLines || [];
    window._jrnLines.push({ account_id: '', desc: '', debit: 0, credit: 0 });
    renderJrnLines();
  }

  function renderJrnLines() {
    const isAR = i18n.getLang() === 'ar';
    const tbody = document.getElementById('jrn-lines-body');
    if (!tbody) return;
    const accounts = window._jrnAccounts || [];
    const lines = window._jrnLines || [];
    tbody.innerHTML = lines.map((l, idx) => `
    <tr>
      <td style="padding:4px 8px">
        <select style="width:100%;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--text-primary);font-size:0.78rem" onchange="Finance.updateJrnLine(${idx},'account_id',this.value)">
          <option value="">--</option>
          ${accounts.map(a => `<option value="${a.id}" ${l.account_id===a.id?'selected':''}>[${a.code}] ${isAR?(a.name_ar||a.name):(a.name||a.name_ar)}</option>`).join('')}
        </select>
      </td>
      <td style="padding:4px 8px">
        <input type="text" value="${l.desc||''}" style="width:100%;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--text-primary);font-size:0.78rem" placeholder="${isAR?'وصف...':'desc...'}" onchange="Finance.updateJrnLine(${idx},'desc',this.value)">
      </td>
      <td style="padding:4px 8px">
        <input type="number" value="${l.debit||''}" min="0" step="0.01" style="width:100%;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--danger);font-weight:600;font-size:0.82rem;text-align:right" placeholder="0.00" oninput="Finance.updateJrnLine(${idx},'debit',this.value)">
      </td>
      <td style="padding:4px 8px">
        <input type="number" value="${l.credit||''}" min="0" step="0.01" style="width:100%;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;color:var(--success);font-weight:600;font-size:0.82rem;text-align:right" placeholder="0.00" oninput="Finance.updateJrnLine(${idx},'credit',this.value)">
      </td>
      <td style="padding:4px 8px;text-align:center">
        <button class="btn-icon" onclick="Finance.removeJrnLine(${idx})" style="color:var(--danger)">✕</button>
      </td>
    </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;padding:16px;color:var(--text-muted)">${isAR?'أضف سطوراً':'Add lines'}</td></tr>`;
    recalcJrn();
  }

  function updateJrnLine(idx, field, val) {
    const l = (window._jrnLines||[])[idx];
    if (!l) return;
    l[field] = ['debit','credit'].includes(field) ? (parseFloat(val)||0) : (field==='account_id' ? parseInt(val)||'' : val);
    recalcJrn();
  }

  function removeJrnLine(idx) { window._jrnLines.splice(idx,1); renderJrnLines(); }

  function recalcJrn() {
    const lines  = window._jrnLines || [];
    const totDr  = lines.reduce((s,l) => s+(l.debit||0), 0);
    const totCr  = lines.reduce((s,l) => s+(l.credit||0), 0);
    Utils.setHTML('#jrn-total-dr', Utils.formatMoney(totDr));
    Utils.setHTML('#jrn-total-cr', Utils.formatMoney(totCr));
    const errEl = document.getElementById('jrn-balance-err');
    if (errEl) errEl.style.display = Math.abs(totDr - totCr) > 0.01 ? '' : 'none';
    window._jrnTotDr = totDr;
    window._jrnTotCr = totCr;
  }

  async function openJournalForm(id = null) {
    window._editJrnId  = id;
    window._jrnLines   = id ? JSON.parse((await DB.get('journals', id))?.lines_json||'[]') : [{ account_id:'', desc:'', debit:0, credit:0 },{ account_id:'', desc:'', debit:0, credit:0 }];
    document.getElementById('jrn-date').value = id ? ((await DB.get('journals', id))?.date||Utils.today()) : Utils.today();
    document.getElementById('jrn-desc').value = id ? ((await DB.get('journals', id))?.description||'') : '';
    renderJrnLines();
    Utils.openModal('jrn-modal');
  }

  async function saveJournal(status) {
    const lines  = window._jrnLines || [];
    const totDr  = window._jrnTotDr || 0;
    const totCr  = window._jrnTotCr || 0;
    if (status === 'posted' && Math.abs(totDr - totCr) > 0.01) {
      Utils.toast(i18n.getLang()==='ar'?'القيد غير متوازن!':'Journal not balanced!', 'error'); return;
    }
    const ref = await DB.nextSeq('journals', 'JV-', 5);
    const data = {
      ref,
      date:         document.getElementById('jrn-date')?.value || Utils.today(),
      description:  document.getElementById('jrn-desc')?.value || '',
      lines_json:   JSON.stringify(lines),
      total_debit:  totDr,
      total_credit: totCr,
      status
    };
    if (window._editJrnId) await DB.update('journals', { ...data, id: window._editJrnId });
    else await DB.add('journals', data);
    Utils.closeModal('jrn-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await renderJournals(document.getElementById('page-content'));
  }

  function deleteJournal(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('journals', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await renderJournals(document.getElementById('page-content'));
    });
  }

  // ── Generic Cash/Bank & Collections/Disbursements Renderer ───
  async function renderTransactions(container, store, titleEn, titleAr) {
    let txns = [];
    const accounts = await DB.getAll('accounts');
    const isAR = i18n.getLang() === 'ar';
    const isSpecialView = (store === 'customer_receipts' || store === 'supplier_payments');

    if (store === 'customer_receipts') {
      const cTxns = (await DB.getAll('cash_transactions')) || [];
      const bTxns = (await DB.getAll('bank_transactions')) || [];
      const customers = (await DB.getAll('customers')) || [];
      const cMap = {}; customers.forEach(c => { cMap[c.id] = c; });

      txns = [...cTxns.map(t => ({ ...t, _store: 'cash_transactions', _channel: isAR ? 'صندوق (كاش)' : 'Cash' })), 
              ...bTxns.map(t => ({ ...t, _store: 'bank_transactions', _channel: isAR ? 'بنك (تحويل)' : 'Bank' }))]
             .filter(t => t.type === 'receipt' || t.customer_id)
             .map(t => {
               const c = t.customer_id ? cMap[t.customer_id] : null;
               const cName = c ? (isAR ? (c.name_ar || c.name || c.name_en) : (c.name_en || c.name || c.name_ar)) : '';
               return {
                 ...t,
                 partyName: cName,
                 description: t.description || (cName ? `${isAR ? 'قبض من العميل:' : 'Receipt from:'} ${cName}` : '-')
               };
             });
    } else if (store === 'supplier_payments') {
      const cTxns = (await DB.getAll('cash_transactions')) || [];
      const bTxns = (await DB.getAll('bank_transactions')) || [];
      const suppliers = (await DB.getAll('suppliers')) || [];
      const sMap = {}; suppliers.forEach(s => { sMap[s.id] = s; });

      txns = [...cTxns.map(t => ({ ...t, _store: 'cash_transactions', _channel: isAR ? 'صندوق (كاش)' : 'Cash' })), 
              ...bTxns.map(t => ({ ...t, _store: 'bank_transactions', _channel: isAR ? 'بنك (تحويل)' : 'Bank' }))]
             .filter(t => t.type === 'payment' || t.supplier_id)
             .map(t => {
               const s = t.supplier_id ? sMap[t.supplier_id] : null;
               const sName = s ? (isAR ? (s.name_ar || s.name || s.name_en) : (s.name_en || s.name || s.name_ar)) : '';
               return {
                 ...t,
                 partyName: sName,
                 description: t.description || (sName ? `${isAR ? 'سداد للمورد:' : 'Payment to:'} ${sName}` : '-')
               };
             });
    } else {
      txns = (await DB.getAll(store)) || [];
    }

    const title = isAR ? titleAr : titleEn;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${title}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Finance.openTxnForm('${isSpecialView ? (store === 'customer_receipts' ? 'cash_transactions' : 'bank_transactions') : store}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'جديد' : 'New'}
          </button>
        </div>
      </div>

      <div class="grid grid-3 mb-4">
        <div class="stat-card success" style="padding:16px">
          <div style="font-size:0.75rem;color:var(--text-secondary);margin-bottom:4px">${isAR?'إجمالي الوارد':'Total In'}</div>
          <div style="font-size:1.3rem;font-weight:900;color:var(--success)">${Utils.formatMoney(txns.filter(t=>t.type==='receipt').reduce((s,t)=>s+(parseFloat(t.amount)||0),0))}</div>
        </div>
        <div class="stat-card danger" style="padding:16px">
          <div style="font-size:0.75rem;color:var(--text-secondary);margin-bottom:4px">${isAR?'إجمالي الصادر':'Total Out'}</div>
          <div style="font-size:1.3rem;font-weight:900;color:var(--danger)">${Utils.formatMoney(txns.filter(t=>t.type==='payment').reduce((s,t)=>s+(parseFloat(t.amount)||0),0))}</div>
        </div>
        <div class="stat-card primary" style="padding:16px">
          <div style="font-size:0.75rem;color:var(--text-secondary);margin-bottom:4px">${isAR?'الرصيد':'Balance'}</div>
          <div style="font-size:1.3rem;font-weight:900;color:var(--primary)">${Utils.formatMoney(txns.reduce((s,t)=>t.type==='receipt'?s+(parseFloat(t.amount)||0):s-(parseFloat(t.amount)||0),0))}</div>
        </div>
      </div>

      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR?'الرقم':'Ref'}</th>
            <th>${isAR?'التاريخ':'Date'}</th>
            <th>${isAR?'القناة / المصدر':'Channel'}</th>
            <th>${isAR?'الطرف / البيان':'Party / Type'}</th>
            <th>${isAR?'المبلغ':'Amount'}</th>
            <th>${isAR?'الوصف':'Description'}</th>
            <th>${isAR?'إجراءات':'Actions'}</th>
          </tr></thead>
          <tbody>
            ${txns.slice().reverse().map(t => `
            <tr>
              <td style="font-weight:700;color:var(--primary)">${t.ref||'-'}</td>
              <td style="font-size:0.78rem">${Utils.formatDate(t.date||t.created_at)}</td>
              <td><span class="badge badge-info">${t._channel || (store.includes('bank') ? (isAR ? 'بنك' : 'Bank') : (isAR ? 'صندوق' : 'Cash'))}</span></td>
              <td>
                <div style="font-weight:700">${t.partyName ? Utils.sanitize(t.partyName) : `<span class="badge badge-${t.type==='receipt'?'success':'danger'}">${t.type==='receipt'?(isAR?'وارد':'Receipt'):(isAR?'صرف':'Payment')}</span>`}</div>
              </td>
              <td style="font-weight:800;color:${t.type==='receipt'?'var(--success)':'var(--danger)'}">
                ${t.type==='receipt'?'+':'-'}${Utils.formatMoney(t.amount||0)}
              </td>
              <td>${Utils.truncate(t.description||t.notes||'-',45)}</td>
              <td>
                <button class="btn btn-ghost btn-sm" onclick="Finance.deleteTxn('${t._store || store}', ${t.id})" style="color:var(--danger)">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                </button>
              </td>
            </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد معاملات مسجلة':'No transactions'}</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Transaction Form -->
    <div class="modal-overlay" id="txn-modal">
      <div class="modal" style="max-width:460px">
        <div class="modal-header">
          <div class="modal-title">${isAR ? 'معاملة جديدة' : 'New Transaction'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('txn-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'النوع':'Type'}</label>
              <select class="form-control" id="txn-type">
                <option value="receipt">${isAR?'وارد (قبض)':'Receipt (In)'}</option>
                <option value="payment">${isAR?'صرف (دفع)':'Payment (Out)'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'التاريخ':'Date'}</label>
              <input type="date" class="form-control" id="txn-date" value="${Utils.today()}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'المبلغ':'Amount'}</label>
            <input type="number" class="form-control" id="txn-amount" placeholder="0.00" step="0.01" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'الحساب':'Account'}</label>
            <select class="form-control" id="txn-account">
              <option value="">--</option>
              ${accounts.map(a => `<option value="${a.id}">[${a.code}] ${isAR?(a.name_ar||a.name):(a.name||a.name_ar)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'الوصف':'Description'}</label>
            <input type="text" class="form-control" id="txn-desc" placeholder="${isAR?'وصف...':'Description...'}">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'ملاحظات':'Notes'}</label>
            <textarea class="form-control" id="txn-notes" rows="2" placeholder="${isAR?'ملاحظات...':'Notes...'}"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('txn-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="Finance.saveTxn('${store}')">${isAR?'حفظ':'Save'}</button>
        </div>
      </div>
    </div>`;
  }

  async function openTxnForm(store) { window._txnStore = store; Utils.openModal('txn-modal'); }

  async function saveTxn(store) {
    const amount = parseFloat(document.getElementById('txn-amount')?.value)||0;
    if (!amount) { Utils.toast(i18n.t('common.required'), 'warning'); return; }
    const ref = await DB.nextSeq(store, store.includes('bank')?'BNK-':'CSH-', 5);
    await DB.add(store, {
      ref,
      type:        document.getElementById('txn-type')?.value,
      date:        document.getElementById('txn-date')?.value,
      amount,
      account_id:  parseInt(document.getElementById('txn-account')?.value)||null,
      description: document.getElementById('txn-desc')?.value,
      notes:       document.getElementById('txn-notes')?.value,
    });
    Utils.closeModal('txn-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await App.renderPage(App.getCurrentPage());
  }

  function deleteTxn(store, id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove(store, id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await App.renderPage(App.getCurrentPage());
    });
  }

  // ── VAT Report ────────────────────────────────────────────────
  async function renderVAT(container) {
    const vatRate = await DB.getSetting('vat_rate', 11);
    const sales   = await DB.getAll('sales');
    const isAR    = i18n.getLang() === 'ar';
    const totalVat = sales.reduce((s,t) => s+(t.vat||0), 0);

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'ضريبة القيمة المضافة' : 'VAT Management'}</h1>
        </div>
      </div>
      <div class="grid grid-3 mb-4">
        <div class="stat-card primary">
          <div class="stat-info">
            <div class="stat-label">${isAR?'معدل ضريبة VAT':'VAT Rate'}</div>
            <div class="stat-value">${vatRate}%</div>
          </div>
        </div>
        <div class="stat-card success">
          <div class="stat-info">
            <div class="stat-label">${isAR?'إجمالي الضريبة المحصلة':'Total VAT Collected'}</div>
            <div class="stat-value">${Utils.formatMoney(totalVat)}</div>
          </div>
        </div>
        <div class="stat-card warning">
          <div class="stat-info">
            <div class="stat-label">${isAR?'الضريبة المستحقة':'VAT Payable'}</div>
            <div class="stat-value">${Utils.formatMoney(totalVat)}</div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">${isAR?'تقرير الضريبة':'VAT Report'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead><tr>
              <th>${isAR?'الشهر':'Month'}</th>
              <th>${isAR?'المبيعات':'Sales'}</th>
              <th>${isAR?'الضريبة المحصلة':'VAT Collected'}</th>
            </tr></thead>
            <tbody>
              ${Object.entries(groupByMonth(sales)).map(([month, txns]) => `
              <tr>
                <td style="font-weight:600">${month}</td>
                <td>${Utils.formatMoney(txns.reduce((s,t)=>s+(t.grand_total||0),0))}</td>
                <td style="font-weight:700;color:var(--warning)">${Utils.formatMoney(txns.reduce((s,t)=>s+(t.vat||0),0))}</td>
              </tr>`).join('') || `<tr><td colspan="3" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد بيانات':'No data'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  }

  function groupByMonth(items) {
    return items.reduce((acc, item) => {
      if (!item.created_at) return acc;
      const d = new Date(item.created_at);
      const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
      if (!acc[key]) acc[key] = [];
      acc[key].push(item);
      return acc;
    }, {});
  }

  // ── Fiscal Year Closing & New Year Management ─────────────────
  async function renderFiscalYears(container) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    let fiscalYears = await DB.getAll('fiscal_years');
    
    // Seed initial current fiscal year if none exists
    if (!fiscalYears || !fiscalYears.length) {
      const currentYear = new Date().getFullYear();
      const initialFY = {
        year_name: String(currentYear),
        start_date: `${currentYear}-01-01`,
        end_date: `${currentYear}-12-31`,
        status: 'active',
        is_current: true,
        created_at: new Date().toISOString()
      };
      const id = await DB.add('fiscal_years', initialFY);
      initialFY.id = id;
      fiscalYears = [initialFY];
    }

    const currentFY = fiscalYears.find(f => f.is_current || f.status === 'active') || fiscalYears[fiscalYears.length - 1];

    const startDate = currentFY?.start_date || `${new Date().getFullYear()}-01-01`;
    const endDate = currentFY?.end_date || `${new Date().getFullYear()}-12-31`;

    const allSales = await DB.getAll('sales', s => s.status !== 'cancelled' && (s.created_at || '').slice(0, 10) >= startDate && (s.created_at || '').slice(0, 10) <= endDate);
    const allPurchases = await DB.getAll('purchase_invoices', p => p.status !== 'cancelled' && (p.doc_date || p.created_at || '').slice(0, 10) >= startDate && (p.doc_date || p.created_at || '').slice(0, 10) <= endDate);
    const allExpenses = await DB.getAll('cash_transactions', t => t.type === 'expense' && (t.date || t.created_at || '').slice(0, 10) >= startDate && (t.date || t.created_at || '').slice(0, 10) <= endDate);

    const totalRevenue = allSales.reduce((s, x) => s + (parseFloat(x.grand_total) || 0), 0);
    const totalPurchases = allPurchases.reduce((s, x) => s + (parseFloat(x.grand_total) || 0), 0);
    const totalDirectExpenses = allExpenses.reduce((s, x) => s + (parseFloat(x.amount) || 0), 0);
    const netProfit = totalRevenue - (totalPurchases + totalDirectExpenses);

    const allCustomers = await DB.getAll('customers');
    const totalCustDebt = allCustomers.reduce((s, c) => s + (parseFloat(c.balance) || 0), 0);
    const allSuppliers = await DB.getAll('suppliers');
    const totalSuppDebt = allSuppliers.reduce((s, sp) => s + (parseFloat(sp.balance) || 0), 0);

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'إقفال السنوات المالية وإدارة الفترات' : 'Fiscal Years & Year-End Closing'}</h1>
          <p>${isAR ? 'إقفال السنة المالية وترحيل الأرباح والخسائر وافتتاح سنة مالية جديدة' : 'Close fiscal periods, transfer profit/loss to retained earnings, and open new fiscal years'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Finance.openFiscalClosingModal()" style="font-weight:800;padding:9px 18px;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
            🔒 ${isAR ? 'إقفال السنة المالية وافتتاح سنة جديدة' : 'Close Fiscal Year & Open New Year'}
          </button>
        </div>
      </div>

      <!-- Financial Metrics Ribbon -->
      <div class="grid grid-4 mb-4" style="gap:16px">
        <div class="kpi-card" style="border-inline-start:4px solid var(--primary)">
          <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'السنة المالية الحالية' : 'Active Fiscal Year'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:var(--text-primary);margin:4px 0">${Utils.sanitize(currentFY?.year_name || 'Current')}</div>
          <div style="font-size:0.78rem;color:var(--text-muted)">📅 ${currentFY?.start_date} ➔ ${currentFY?.end_date}</div>
        </div>

        <div class="kpi-card" style="border-inline-start:4px solid #10b981">
          <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'إجمالي إيرادات المبيعات للفترة' : 'Period Sales Revenue'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:#10b981;margin:4px 0">${Utils.formatMoney(totalRevenue)}</div>
          <div style="font-size:0.78rem;color:var(--text-muted)">${allSales.length} ${isAR ? 'فاتورة بيع' : 'invoices'}</div>
        </div>

        <div class="kpi-card" style="border-inline-start:4px solid #ef4444">
          <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'المشتريات والمصروفات' : 'Purchases & Expenses'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:#ef4444;margin:4px 0">${Utils.formatMoney(totalPurchases + totalDirectExpenses)}</div>
          <div style="font-size:0.78rem;color:var(--text-muted)">${isAR ? 'مشتريات: ' : 'Purchases: '}${Utils.formatMoney(totalPurchases)}</div>
        </div>

        <div class="kpi-card" style="border-inline-start:4px solid ${netProfit >= 0 ? '#10b981' : '#ef4444'}">
          <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'صافي الربح التقديري للفترة' : 'Net Period Profit / Loss'}</div>
          <div style="font-size:1.6rem;font-weight:900;color:${netProfit >= 0 ? '#10b981' : '#ef4444'};margin:4px 0">${Utils.formatMoney(netProfit)}</div>
          <div style="font-size:0.78rem;color:var(--text-muted)">${netProfit >= 0 ? (isAR ? '📈 أرباح محققة' : 'Profitable Period') : (isAR ? '📉 خسائر' : 'Net Loss')}</div>
        </div>
      </div>

      <!-- Receivables & Payables Carryover Status -->
      <div class="grid grid-2 mb-4" style="gap:16px">
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:16px;display:flex;justify-content:space-between;align-items:center">
          <div>
            <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary)">👥 ${isAR ? 'أرصدة ديون العملاء الحالية (تُرحّل تلقائياً)' : 'Customer Debt Receivables (Carried Forward)'}</div>
            <div style="font-size:0.8rem;color:var(--text-muted);margin-top:2px">${isAR ? 'جميع الذمم المدينة تُرحّل كأرصدة افتتاحية للسنة الجديدة' : 'All accounts receivable automatically transfer to new year'}</div>
          </div>
          <div style="font-size:1.3rem;font-weight:900;color:var(--danger)">${Utils.formatMoney(totalCustDebt)}</div>
        </div>
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:16px;display:flex;justify-content:space-between;align-items:center">
          <div>
            <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary)">🚛 ${isAR ? 'مستحقات الموردين الحالية (تُرحّل تلقائياً)' : 'Supplier Payables (Carried Forward)'}</div>
            <div style="font-size:0.8rem;color:var(--text-muted);margin-top:2px">${isAR ? 'جميع الذمم الدائنة تُرحّل كأرصدة افتتاحية للموردين' : 'All accounts payable automatically transfer to new year'}</div>
          </div>
          <div style="font-size:1.3rem;font-weight:900;color:var(--warning)">${Utils.formatMoney(totalSuppDebt)}</div>
        </div>
      </div>

      <!-- Fiscal Years Table -->
      <div class="card" style="padding:0;overflow:hidden">
        <div style="padding:14px 18px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
          <h3 style="margin:0;font-size:1rem;font-weight:800">📜 ${isAR ? 'سجل السنوات المالية المقفلة والنشطة' : 'Fiscal Years Log'}</h3>
          <span class="badge badge-secondary">${fiscalYears.length} ${isAR ? 'فترات' : 'years'}</span>
        </div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'السنة المالية' : 'Fiscal Year'}</th>
                <th>${isAR ? 'تاريخ البداية' : 'Start Date'}</th>
                <th>${isAR ? 'تاريخ النهاية' : 'End Date'}</th>
                <th>${isAR ? 'الحالة' : 'Status'}</th>
                <th>${isAR ? 'صافي الربح / الخسارة' : 'Net P&L'}</th>
                <th>${isAR ? 'تاريخ الإقفال' : 'Closing Date'}</th>
                <th>${isAR ? 'قيد الإقفال' : 'Closing Journal'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody>
              ${fiscalYears.slice().reverse().map(fy => `
              <tr>
                <td style="font-weight:800;font-size:0.95rem;color:var(--text-primary)">
                  ${fy.is_current ? '🟢 ' : (fy.status === 'closed' ? '🔒 ' : '⚪ ')}
                  ${Utils.sanitize(fy.year_name)}
                  ${fy.is_current ? `<span class="badge badge-success" style="font-size:0.7rem;margin-inline-start:4px">${isAR ? 'الحالية' : 'Current'}</span>` : ''}
                </td>
                <td>${fy.start_date || '-'}</td>
                <td>${fy.end_date || '-'}</td>
                <td>
                  <span class="badge ${fy.status === 'closed' ? 'badge-danger' : 'badge-success'}">
                    ${fy.status === 'closed' ? (isAR ? 'مقفلة' : 'Closed') : (isAR ? 'نشطة ومفتوحة' : 'Active')}
                  </span>
                </td>
                <td style="font-weight:800;color:${(fy.net_profit || 0) >= 0 ? 'var(--success)' : 'var(--danger)'}">
                  ${fy.net_profit !== undefined ? Utils.formatMoney(fy.net_profit) : (fy.status === 'closed' ? '$0.00' : (isAR ? 'قيد التشغيل' : 'In Progress'))}
                </td>
                <td style="color:var(--text-muted);font-size:0.8rem">
                  ${fy.closed_at ? Utils.formatDate(fy.closed_at) : (fy.status === 'closed' ? '-' : (isAR ? 'مفتوحة' : 'Open'))}
                </td>
                <td>
                  ${fy.closing_journal_ref ? `<span style="font-family:monospace;font-weight:700;color:var(--primary)">${fy.closing_journal_ref}</span>` : '-'}
                </td>
                <td style="text-align:center">
                  ${fy.status === 'closed' ? `
                  <button class="btn btn-ghost btn-sm" onclick="Finance.printFiscalReport(${fy.id})" title="${isAR ? 'طباعة تقرير الإقفال المالي' : 'Print Year-End Closing Statement'}">
                    🖨️ ${isAR ? 'تقرير الإقفال' : 'Statement'}
                  </button>
                  ` : `
                  <button class="btn btn-secondary btn-sm" onclick="Finance.openFiscalClosingModal(${fy.id})" style="font-weight:700">
                    🔒 ${isAR ? 'إقفال' : 'Close'}
                  </button>
                  `}
                </td>
              </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  }

  async function openFiscalClosingModal(fyId = null) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    let fiscalYears = await DB.getAll('fiscal_years');
    let targetFY = fyId ? fiscalYears.find(f => f.id === fyId) : fiscalYears.find(f => f.is_current || f.status === 'active');
    if (!targetFY) targetFY = fiscalYears[fiscalYears.length - 1];

    const currentYearNum = parseInt(String(targetFY?.year_name || '').replace(/\D/g, '')) || new Date().getFullYear();
    const nextYearNum = currentYearNum + 1;

    // Calculate real figures for the target year
    const sDate = targetFY?.start_date || `${currentYearNum}-01-01`;
    const eDate = targetFY?.end_date || `${currentYearNum}-12-31`;

    const allSales = await DB.getAll('sales', s => s.status !== 'cancelled' && (s.created_at || '').slice(0, 10) >= sDate && (s.created_at || '').slice(0, 10) <= eDate);
    const allPurchases = await DB.getAll('purchase_invoices', p => p.status !== 'cancelled' && (p.doc_date || p.created_at || '').slice(0, 10) >= sDate && (p.doc_date || p.created_at || '').slice(0, 10) <= eDate);
    const allExpenses = await DB.getAll('cash_transactions', t => t.type === 'expense' && (t.date || t.created_at || '').slice(0, 10) >= sDate && (t.date || t.created_at || '').slice(0, 10) <= eDate);

    const totalRev = allSales.reduce((s, x) => s + (parseFloat(x.grand_total) || 0), 0);
    const totalExp = allPurchases.reduce((s, x) => s + (parseFloat(x.grand_total) || 0), 0) + allExpenses.reduce((s, x) => s + (parseFloat(x.amount) || 0), 0);
    const netProfit = totalRev - totalExp;

    const modalId = 'fiscal-closing-modal';
    document.getElementById(modalId)?.remove();

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay open';
    overlay.id = modalId;
    overlay.innerHTML = `
      <div class="modal" style="max-width:620px">
        <div class="modal-header">
          <div class="modal-title">
            🔒 ${isAR ? `إقفال السنة المالية (${targetFY?.year_name}) وافتتاح السنة الجديدة` : `Close Fiscal Year (${targetFY?.year_name}) & Open New Year`}
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
        </div>
        <div class="modal-body">
          <div style="background:var(--surface-2);border:1.5px solid var(--border-color);border-radius:10px;padding:14px;margin-bottom:16px">
            <div style="font-size:0.85rem;font-weight:800;color:var(--text-primary);margin-bottom:8px">
              📊 ${isAR ? 'ملخص الحسابات الختامية للسنة المالية المنتهية:' : 'Year-End Closing Accounts Summary:'}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-bottom:4px">
              <span style="color:var(--text-muted)">${isAR ? 'إجمالي المبيعات والإيرادات:' : 'Total Sales & Revenues:'}</span>
              <span style="font-weight:700;color:#10b981">${Utils.formatMoney(totalRev)}</span>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-bottom:6px">
              <span style="color:var(--text-muted)">${isAR ? 'إجمالي المشتريات والمصروفات:' : 'Total Purchases & Expenses:'}</span>
              <span style="font-weight:700;color:#ef4444">${Utils.formatMoney(totalExp)}</span>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:1.05rem;font-weight:900;border-top:1.5px dashed var(--border-color);padding-top:8px">
              <span>${isAR ? 'صافي الربح / الخسارة المحول للأرباح المدورة:' : 'Net Profit / Loss transferred to Equity:'}</span>
              <span style="color:${netProfit >= 0 ? '#10b981' : '#ef4444'}">${Utils.formatMoney(netProfit)}</span>
            </div>
          </div>

          <div style="font-size:0.9rem;font-weight:800;color:var(--primary);margin-bottom:10px">
            ✨ ${isAR ? 'بيانات السنة المالية الجديدة:' : 'New Fiscal Year Details:'}
          </div>

          <div class="form-group mb-3">
            <label class="form-label">${isAR ? 'اسم أو رمز السنة المالية الجديدة' : 'New Fiscal Year Name'}</label>
            <input type="text" class="form-control" id="fy-new-name" value="${nextYearNum}" placeholder="e.g. ${nextYearNum}" style="font-weight:800;font-size:1rem">
          </div>

          <div class="grid grid-2" style="gap:12px">
            <div class="form-group">
              <label class="form-label">${isAR ? 'تاريخ بداية السنة الجديدة' : 'Start Date'}</label>
              <input type="date" class="form-control" id="fy-new-start" value="${nextYearNum}-01-01" style="font-weight:700">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'تاريخ نهاية السنة الجديدة' : 'End Date'}</label>
              <input type="date" class="form-control" id="fy-new-end" value="${nextYearNum}-12-31" style="font-weight:700">
            </div>
          </div>

          <div style="background:rgba(245,158,11,0.1);border:1px solid var(--warning);border-radius:8px;padding:10px 12px;margin-top:14px;font-size:0.8rem;color:#b45309;line-height:1.5">
            ⚠️ <strong>${isAR ? 'ملاحظة محاسبية هامة:' : 'Important Accounting Notice:'}</strong>
            ${isAR 
              ? 'سيتم توليد قيد إقفال تلقائي لتصفير حسابات الإيرادات والمصروفات وترحيل صافي النتيجة لحساب حقوق الملكية (الأرباح المدورة). أرصدة العملاء والموردين والنقدية بالمصارف ستستمر تلقائياً كأرصدة افتتاحية.'
              : 'An automatic closing journal entry will zero out revenue & expense accounts and roll net profits into Retained Earnings. Customer debts, supplier debts, and cash/bank balances will automatically roll forward.'}
          </div>
        </div>
        <div class="modal-footer" style="display:flex;justify-content:space-between">
          <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Finance.executeFiscalClosing(${targetFY?.id}, ${netProfit})" style="font-weight:800;box-shadow:0 4px 12px rgba(37,99,235,0.4)">
            🔒 ${isAR ? 'تأكيد الإقفال وافتتاح السنة الجديدة' : 'Confirm Closing & Open New Year'}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);
  }

  async function executeFiscalClosing(closingId, netProfit) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const newName  = document.getElementById('fy-new-name')?.value?.trim();
    const newStart = document.getElementById('fy-new-start')?.value?.trim();
    const newEnd   = document.getElementById('fy-new-end')?.value?.trim();

    if (!newName || !newStart || !newEnd) {
      return Utils.toast(isAR ? 'يرجى ملء جميع بيانات السنة الجديدة' : 'Please fill all new year dates', 'warning');
    }

    try {
      // 1. Get or create Equity / Retained Earnings account
      const accounts = await DB.getAll('accounts');
      let equityAcc = accounts.find(a => a.type === 'equity' || a.code === '3000' || a.code === '3100');
      if (!equityAcc) {
        const eqId = await DB.add('accounts', {
          code: '3100',
          name: 'Retained Earnings',
          name_ar: 'الأرباح والخسائر المدورة',
          type: 'equity',
          balance: 0,
          created_at: new Date().toISOString()
        });
        equityAcc = await DB.get('accounts', eqId);
      }

      // 2. Create Closing Journal Entry
      const targetFY = await DB.get('fiscal_years', closingId);
      const closeRef = `JRN-CLOSE-${targetFY?.year_name || 'FY'}`;
      
      const closingJournal = {
        ref: closeRef,
        date: targetFY?.end_date || Utils.today(),
        description: isAR 
          ? `قيد إقفال السنة المالية ${targetFY?.year_name} وترحيل صافي النتيجة لحساب الأرباح والخسائر المدورة` 
          : `Year-end closing entry for FY ${targetFY?.year_name} and net transfer to Retained Earnings`,
        status: 'posted',
        lines: [
          {
            account_id: equityAcc.id,
            account_name: isAR ? (equityAcc.name_ar || equityAcc.name) : (equityAcc.name || equityAcc.name_ar),
            debit: netProfit < 0 ? Math.abs(netProfit) : 0,
            credit: netProfit > 0 ? netProfit : 0,
            desc: isAR ? 'صافي نتيجة السنة المالية' : 'Net Year-End P&L'
          }
        ],
        created_at: new Date().toISOString()
      };
      await DB.add('journals', closingJournal);

      // Update Equity balance
      equityAcc.balance = Utils.round((equityAcc.balance || 0) + netProfit);
      await DB.update('accounts', equityAcc);

      // 3. Mark closing FY as closed
      targetFY.status = 'closed';
      targetFY.is_current = false;
      targetFY.closed_at = new Date().toISOString();
      targetFY.net_profit = netProfit;
      targetFY.closing_journal_ref = closeRef;
      await DB.update('fiscal_years', targetFY);

      // 4. Mark all other fiscal years as non-current
      const allFY = await DB.getAll('fiscal_years');
      for (const fy of allFY) {
        if (fy.id !== targetFY.id && fy.is_current) {
          fy.is_current = false;
          await DB.update('fiscal_years', fy);
        }
      }

      // 5. Create New Active Fiscal Year
      const newFY = {
        year_name: newName,
        start_date: newStart,
        end_date: newEnd,
        status: 'active',
        is_current: true,
        created_at: new Date().toISOString()
      };
      await DB.add('fiscal_years', newFY);
      await DB.setSetting('active_fiscal_year', newName);

      Utils.closeModal('fiscal-closing-modal');
      Utils.toast(isAR ? `✅ تم إقفال السنة المالية ${targetFY?.year_name} وافتتاح سنة ${newName} بنجاح!` : `✅ Fiscal Year ${targetFY?.year_name} closed and FY ${newName} opened successfully!`, 'success');

      // Refresh view
      const content = document.getElementById('main-content');
      if (content) {
        await renderFiscalYears(content);
      }
    } catch(err) {
      console.error('Fiscal closing error:', err);
      Utils.toast('Error closing fiscal year: ' + err.message, 'error');
    }
  }

  async function printFiscalReport(fyId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const fy = await DB.get('fiscal_years', fyId);
    if (!fy) return;

    const co = (window.getCompanyInfo && typeof getCompanyInfo === 'function') 
      ? await getCompanyInfo() 
      : { company_name: await DB.getSetting('company_name', 'Store'), company_name_ar: await DB.getSetting('company_name_ar', '') };

    const html = `
    <!DOCTYPE html>
    <html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
    <head>
      <meta charset="UTF-8">
      <title>${isAR ? 'تقرير إقفال السنة المالية' : 'Fiscal Year Closing Statement'} - ${fy.year_name}</title>
      <style>
        body { font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; padding: 30px; color: #1e293b; background: #fff; }
        .header { text-align: center; border-bottom: 3px double #0f172a; padding-bottom: 16px; margin-bottom: 24px; }
        .title { font-size: 24px; font-weight: 900; margin: 0; color: #0f172a; }
        .subtitle { font-size: 14px; color: #64748b; margin-top: 4px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px; }
        .box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; }
        .row { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; }
        .total-box { background: #eff6ff; border: 2px solid #3b82f6; border-radius: 8px; padding: 16px; text-align: center; margin-bottom: 30px; }
        .sig-grid { display: flex; justify-content: space-between; margin-top: 50px; padding-top: 20px; border-top: 1px solid #cbd5e1; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1 class="title">${isAR ? (co.company_name_ar || co.company_name) : (co.company_name || co.company_name_ar)}</h1>
        <div class="subtitle">${isAR ? 'شهادة وتقرير إقفال السنة المالية الختامية' : 'Official Year-End Financial Closing Certificate'}</div>
      </div>

      <div class="grid">
        <div class="box">
          <div class="row"><strong>${isAR ? 'السنة المالية:' : 'Fiscal Year:'}</strong> <span>${fy.year_name}</span></div>
          <div class="row"><strong>${isAR ? 'تاريخ البدء:' : 'Start Date:'}</strong> <span>${fy.start_date}</span></div>
          <div class="row"><strong>${isAR ? 'تاريخ الانتهاء:' : 'End Date:'}</strong> <span>${fy.end_date}</span></div>
        </div>
        <div class="box">
          <div class="row"><strong>${isAR ? 'الحالة:' : 'Status:'}</strong> <span style="font-weight:800;color:#dc2626">${isAR ? 'مقفلة رسمياً' : 'Officially Closed'}</span></div>
          <div class="row"><strong>${isAR ? 'تاريخ وتوقيت الإقفال:' : 'Closing Date:'}</strong> <span>${fy.closed_at ? Utils.formatDate(fy.closed_at) : '-'}</span></div>
          <div class="row"><strong>${isAR ? 'مرجع قيد اليومية:' : 'Closing Journal Ref:'}</strong> <span style="font-family:monospace">${fy.closing_journal_ref || '-'}</span></div>
        </div>
      </div>

      <div class="total-box">
        <div style="font-size:14px;color:#1e40af;font-weight:700">${isAR ? 'صافي الربح / الخسارة النهائي المحول لحساب الأرباح المدورة' : 'Net Final Profit / Loss Transferred to Retained Earnings'}</div>
        <div style="font-size:32px;font-weight:900;color:${(fy.net_profit || 0) >= 0 ? '#059669' : '#dc2626'};margin-top:6px">${Utils.formatMoney(fy.net_profit || 0)}</div>
      </div>

      <div class="sig-grid">
        <div style="text-align:center"><p style="margin-bottom:40px">${isAR ? 'توقيع المحاسب القانوني' : 'Accountant Signature'}</p><p>_______________________</p></div>
        <div style="text-align:center"><p style="margin-bottom:40px">${isAR ? 'اعتماد الإدارة العامة' : 'General Management'}</p><p>_______________________</p></div>
      </div>
    </body>
    </html>
    `;

    if (window.PrintEngine && typeof window.PrintEngine.openPrintWindow === 'function') {
      window.PrintEngine.openPrintWindow(html, `Fiscal-Closing-${fy.year_name}`, 'A4');
    } else {
      Utils.printElement(html, `Fiscal-Closing-${fy.year_name}`, 'A4');
    }
  }

  return {
    renderAccounts, openAccountForm, saveAccount, deleteAccount, searchAccounts, filterAccounts,
    renderJournals, openJournalForm, addJrnLine, removeJrnLine, updateJrnLine, renderJrnLines, saveJournal, deleteJournal,
    renderCash:             (c) => renderTransactions(c, 'cash_transactions', 'Cash Management', 'إدارة الصندوق'),
    renderBank:             (c) => renderTransactions(c, 'bank_transactions', 'Bank Management', 'إدارة البنك'),
    renderCustomerReceipts: (c) => renderTransactions(c, 'customer_receipts', 'Customer Receipts & Collections', 'إيصالات العملاء والتحصيلات'),
    renderSupplierPayments: (c) => renderTransactions(c, 'supplier_payments', 'Supplier Payments & Disbursements', 'مدفوعات وسندات صرف الموردين'),
    renderVAT, openTxnForm, saveTxn, deleteTxn,
    renderFiscalYears, openFiscalClosingModal, executeFiscalClosing, printFiscalReport
  };
})();

window.Finance = Finance;

