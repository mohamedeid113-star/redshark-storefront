/* ================================================================
   RedShark POS — Purchasing Module (PO, GRN, Purchase Invoice, Return)
   Ultra-Fast Barcode Scanning & Comprehensive Purchase Management
   ================================================================ */

const Purchasing = (() => {

  let _activeDropdownIndex = -1;
  let _lastScanCode = '';
  let _lastScanTime = 0;

  // ── Audio Feedback Helper ──────────────────────────────────
  function playAudioTone(type = 'beep') {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      if (type === 'beep') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, now);
        osc.frequency.exponentialRampToValueAtTime(1750, now + 0.08);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.12);
        osc.start(now);
        osc.stop(now + 0.12);
        setTimeout(() => { ctx.close().catch(() => {}); }, 200);
      } else if (type === 'error') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.setValueAtTime(160, now + 0.14);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.28);
        osc.start(now);
        osc.stop(now + 0.28);
        setTimeout(() => { ctx.close().catch(() => {}); }, 350);
      }
    } catch (e) {
      console.warn('Audio tone error:', e);
    }
  }

  // ── TVA Tax Eligibility Helper ─────────────────────────────
  function isItemTaxable(item) {
    if (!item) return false;
    const vt = (item.vat_type || '').toLowerCase();
    if (vt === 'exempt' || vt === 'none' || vt === 'zero') return false;
    if (vt === 'standard' || vt === 'taxable' || vt === 'vat') return true;
    if (item.is_taxable === false || item.taxable === false) return false;
    if (item.is_taxable === true || item.taxable === true || item.is_vat_taxable === true) return true;
    if ((parseFloat(item.vat_rate) > 0) || (parseFloat(item.tax_rate) > 0)) return true;
    return false;
  }

  // ── Unified Supplier Financial Synchronizer ────────────────
  async function updateSupplierFinancials(supplierId) {
    if (!supplierId) return null;
    const supId = parseInt(supplierId, 10);
    if (!supId) return null;
    const supplier = await DB.get('suppliers', supId);
    if (!supplier) return null;

    try {
      const invoices = await DB.getAll('purchase_invoices', i => i.supplier_id === supId && i.status !== 'cancelled' && i.status !== 'draft');
      const returns  = await DB.getAll('purchase_returns', r => r.supplier_id === supId && r.status !== 'cancelled');
      const cashTxns = await DB.getAll('cash_transactions', t => t.supplier_id === supId && (t.type === 'expense' || t.type === 'payment'));
      const bankTxns = await DB.getAll('bank_transactions', t => t.supplier_id === supId && t.type === 'payment');

      let totalPurchases = 0;
      invoices.forEach(inv => {
        totalPurchases += (parseFloat(inv.base_grand_total !== undefined ? inv.base_grand_total : inv.grand_total) || 0);
      });

      let totalReturns = 0;
      returns.forEach(ret => {
        totalReturns += (parseFloat(ret.base_grand_total !== undefined ? ret.base_grand_total : ret.grand_total) || 0);
      });

      let totalPaid = 0;
      cashTxns.concat(bankTxns).forEach(tx => {
        totalPaid += (parseFloat(tx.amount) || 0);
      });

      // Amount due to supplier (دين المورد)
      const balance = Utils.round(totalPurchases - totalReturns - totalPaid);

      supplier.total_purchases = Utils.round(totalPurchases);
      supplier.total_paid = Utils.round(totalPaid);
      supplier.total_returns = Utils.round(totalReturns);
      supplier.balance = balance;

      await DB.update('suppliers', supplier);

      // Refresh in active memory cache if present
      if (window._purSuppliers) {
        const cached = window._purSuppliers.find(s => s.id === supId);
        if (cached) {
          cached.balance = balance;
          cached.total_purchases = supplier.total_purchases;
          cached.total_paid = supplier.total_paid;
        }
      }
      return supplier;
    } catch (e) {
      console.warn('Failed to update supplier financials:', e);
      return supplier;
    }
  }

  // ── Reusable document list renderer ─────────────────────────
  async function renderDocList(container, store, titleEn, titleAr, refPrefix, statusBadge) {
    const docs = await DB.getAll(store);
    const suppliers = await DB.getAll('suppliers');
    const baseCur = await DB.getSetting('currency_1', 'USD');
    const isAR = i18n.getLang() === 'ar';
    const title = isAR ? titleAr : titleEn;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1 style="display:flex;align-items:center;gap:10px">
            <span>📦</span> ${title}
          </h1>
          <p>${isAR ? `إجمالي الفواتير والوثائق: ${docs.length}` : `Total recorded documents: ${docs.length}`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Purchasing.exportDocs('${store}')">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير CSV' : 'Export CSV'}
          </button>
          <button class="btn btn-primary" onclick="Purchasing.openDoc('${store}', null)" style="box-shadow:0 4px 14px rgba(37,99,235,0.35);font-weight:700">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'فاتورة جديدة (سريعة)' : 'New Invoice (Fast)'}
          </button>
        </div>
      </div>

      <!-- Filters -->
      <div class="toolbar" style="gap:10px;flex-wrap:wrap">
        <div class="search-bar flex-1" style="min-width:240px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" placeholder="${isAR ? 'بحث برقم الوثيقة، فاتورة المورد، أو اسم المورد...' : 'Search by Ref, Supplier Bill #, or Supplier...'}" id="pur-search" oninput="Purchasing.searchDocs(this.value, '${store}')" style="padding-left:36px">
        </div>
        <input type="date" class="form-control" id="pur-from" style="width:150px" onchange="Purchasing.searchDocs(document.getElementById('pur-search').value, '${store}')" title="${isAR ? 'من تاريخ' : 'From Date'}">
        <input type="date" class="form-control" id="pur-to" style="width:150px" onchange="Purchasing.searchDocs(document.getElementById('pur-search').value, '${store}')" title="${isAR ? 'إلى تاريخ' : 'To Date'}">
      </div>

      <div class="table-wrapper card" style="overflow-x:auto">
        <table id="pur-table">
          <thead><tr>
            <th>${isAR ? 'الرقم الداخلي' : 'Ref #'}</th>
            <th>${isAR ? 'رقم فاتورة المورد' : 'Supplier Bill #'}</th>
            <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
            <th>${isAR ? 'طريقة الدفع' : 'Payment'}</th>
            <th>${isAR ? 'المورد' : 'Supplier'}</th>
            <th style="text-align:center">${isAR ? 'العملة' : 'Currency'}</th>
            <th>${isAR ? 'الإجمالي' : 'Total'}</th>
            <th>${isAR ? 'المدفوع / المتبقي' : 'Paid / Due'}</th>
            <th>${isAR ? 'الحالة' : 'Status'}</th>
            <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
          </tr></thead>
          <tbody id="pur-tbody">
            ${renderDocRows(docs, suppliers, isAR, store, baseCur)}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Doc Form Modal (Full-Visibility Wide Layout) -->
    <div class="modal-overlay" id="pur-doc-modal">
      <div class="modal" id="pur-doc-modal-container" style="max-width:98vw;width:98vw;height:96vh;max-height:96vh;display:flex;flex-direction:column;border-radius:16px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,0.35)">
        <div class="modal-header" style="background:var(--surface);border-bottom:1px solid var(--border-color);padding:10px 18px;flex-shrink:0">
          <div class="modal-title" id="pur-doc-title" style="font-size:1.1rem;font-weight:800">
            ${title}
          </div>
          <button class="btn-icon" onclick="Purchasing.closeDocModal()" style="font-size:1.2rem">✕</button>
        </div>
        <div class="modal-body" id="pur-doc-body" style="padding:10px 14px;overflow:hidden;flex:1;display:flex;flex-direction:column;gap:8px;min-height:0;background:var(--background)"></div>
        <div class="modal-footer" style="background:var(--surface);border-top:1px solid var(--border-color);padding:10px 18px;display:flex;justify-content:space-between;align-items:center;flex-shrink:0">
          <div style="font-size:0.82rem;color:var(--text-muted);display:flex;align-items:center;gap:12px">
            <span>💡 <strong>Enter</strong>: ${isAR ? 'إضافة الباركود مباشرة' : 'Direct barcode scan'}</span>
            <span>•</span>
            <span>⌨️ <strong>F9</strong>: ${isAR ? 'حفظ الفاتورة' : 'Save Invoice'}</span>
          </div>
          <div style="display:flex;gap:10px">
            <button class="btn btn-ghost" onclick="Purchasing.closeDocModal()">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button class="btn btn-secondary" onclick="Purchasing.saveAndPrint('${store}')" style="font-weight:700">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'حفظ وطباعة' : 'Save & Print'}
            </button>
            <button class="btn btn-primary" onclick="Purchasing.saveDoc('${store}')" style="font-weight:800;padding:8px 24px;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/></svg>
              ${isAR ? 'حفظ الفاتورة' : 'Save Invoice'}
            </button>
          </div>
        </div>
      </div>
    </div>`;

    window._purStore     = store;
    window._purSuppliers = suppliers;
    window._purPrefix    = refPrefix;
  }

  function renderDocRows(docs, suppliers, isAR, store, baseCur = 'USD') {
    if (!docs.length) {
      return `<tr><td colspan="10" style="text-align:center;padding:42px;color:var(--text-muted);font-size:0.95rem">
        <div style="font-size:2rem;margin-bottom:8px">📄</div>
        ${isAR ? 'لا توجد فواتير أو وثائق مسجلة بعد' : 'No documents recorded yet'}
      </td></tr>`;
    }

    const payLabels = {
      cash:     { en: '💵 Cash',       ar: '💵 نقدي',      badge: 'success' },
      credit:   { en: '⏳ On Credit',   ar: '⏳ آجل',       badge: 'warning' },
      card:     { en: '💳 Card',       ar: '💳 بطاقة',     badge: 'info' },
      transfer: { en: '🏦 Transfer',   ar: '🏦 تحويل بنكي',badge: 'secondary' },
      cheque:   { en: '📝 Cheque',     ar: '📝 شيك',       badge: 'secondary' },
    };

    return docs.slice().reverse().map(d => {
      const sup = suppliers.find(s => s.id === d.supplier_id);
      const supName = sup ? (isAR ? (sup.name_ar||sup.name_en) : (sup.name_en||sup.name_ar)) : '-';
      const statusColors = { draft:'secondary', pending:'warning', approved:'info', received:'success', cancelled:'danger', paid:'success', partial:'warning' };

      const rawDate = d.doc_date || d.created_at || d.date;
      const dt = rawDate ? new Date(rawDate) : null;
      const dateFormatted = dt && !isNaN(dt.getTime()) ? dt.toLocaleDateString('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit' }) : (rawDate || '-');
      const timeFormatted = d.doc_time || (dt && !isNaN(dt.getTime()) ? dt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }) : '');

      const payMethod = (d.payment_method || d.pay_method || 'cash').toLowerCase();
      const pInfo = payLabels[payMethod] || { en: payMethod.toUpperCase(), ar: payMethod, badge: 'secondary' };

      const docCur = d.currency || baseCur || 'USD';
      const isDiffCur = docCur !== baseCur;
      const exchRate = parseFloat(d.exchange_rate) || 89500;

      const grandTotal = parseFloat(d.grand_total) || 0;
      const paidAmount = parseFloat(d.paid_amount ?? (payMethod === 'cash' ? grandTotal : 0));
      const dueAmount  = parseFloat(d.due_amount ?? Math.max(0, grandTotal - paidAmount));

      const isLbpDoc = Utils.isLbp ? Utils.isLbp(docCur) : (docCur === 'LBP' || docCur === 'LL');
      const isLbpBase = Utils.isLbp ? Utils.isLbp(baseCur) : (baseCur === 'LBP' || baseCur === 'LL');
      const baseGrandTotal = d.base_grand_total !== undefined ? parseFloat(d.base_grand_total) : (docCur === baseCur ? grandTotal : (isLbpDoc && !isLbpBase ? grandTotal / exchRate : grandTotal * exchRate));
      const baseDueAmount = d.base_due_amount !== undefined ? parseFloat(d.base_due_amount) : (docCur === baseCur ? dueAmount : (isLbpDoc && !isLbpBase ? dueAmount / exchRate : dueAmount * exchRate));

      return `<tr>
        <td style="font-weight:800">
          <a href="javascript:void(0)" onclick="Purchasing.openDoc('${store}', ${d.id})" style="color:var(--primary);text-decoration:none;font-weight:900" title="${isAR ? 'تعديل / عرض الفاتورة' : 'Edit / View Invoice'}">
            📝 ${d.ref || '-'}
          </a>
        </td>
        <td style="font-weight:700">${d.supplier_invoice_no ? `<span class="badge badge-secondary" style="font-size:0.75rem"># ${Utils.sanitize(d.supplier_invoice_no)}</span>` : '<span style="color:var(--text-muted)">—</span>'}</td>
        <td>
          <div style="font-weight:700;font-size:0.8rem;color:var(--text-primary)">${dateFormatted}</div>
          ${timeFormatted ? `<div style="font-size:0.7rem;color:var(--text-muted);margin-top:2px">🕒 ${timeFormatted}</div>` : ''}
        </td>
        <td>
          <span class="badge badge-${pInfo.badge}" style="font-weight:700;font-size:0.74rem;padding:3px 8px">${isAR ? pInfo.ar : pInfo.en}</span>
        </td>
        <td style="font-weight:600">${Utils.truncate(supName, 26)}</td>
        <td style="text-align:center">
          <span class="badge ${docCur === 'LBP' ? 'badge-warning' : 'badge-primary'}" style="font-weight:800;font-size:0.74rem;padding:3px 8px">
            ${docCur === 'LBP' ? (isAR ? 'ل.ل LBP' : 'L.L. (LBP)') : 'USD ($)'}
          </span>
        </td>
        <td style="font-weight:900;color:var(--text-primary);font-size:0.92rem">
          <div>${Utils.formatMoney(grandTotal, docCur)}</div>
          ${isDiffCur ? `<div style="font-size:0.72rem;color:var(--primary);font-weight:700;margin-top:2px">≈ ${Utils.formatMoney(baseGrandTotal, baseCur)}</div>` : ''}
        </td>
        <td>
          ${dueAmount > 0 ? `
            <div style="font-size:0.75rem;color:var(--danger);font-weight:700">${isAR ? 'متبقي: ' : 'Due: '}${Utils.formatMoney(dueAmount, docCur)}</div>
            ${isDiffCur ? `<div style="font-size:0.68rem;color:var(--danger);opacity:0.85">≈ ${Utils.formatMoney(baseDueAmount, baseCur)}</div>` : ''}
            ${paidAmount > 0 ? `<div style="font-size:0.68rem;color:var(--success);margin-top:2px">${isAR ? 'مدفوع: ' : 'Paid: '}${Utils.formatMoney(paidAmount, docCur)}</div>` : ''}
          ` : `
            <span class="badge badge-success" style="font-size:0.7rem">${isAR ? 'مدفوع بالكامل' : 'Paid in Full'}</span>
          `}
        </td>
        <td><span class="badge badge-${statusColors[d.status]||'secondary'}" style="text-transform:uppercase;font-size:0.7rem">${d.status||'draft'}</span></td>
        <td style="text-align:center">
          <div style="display:inline-flex;gap:4px;align-items:center">
            <button class="btn btn-primary btn-sm" onclick="Purchasing.openDoc('${store}', ${d.id})" style="font-weight:700;font-size:0.75rem;padding:3px 8px;display:flex;align-items:center;gap:3px" title="${isAR ? 'تعديل الفاتورة' : 'Edit Invoice'}">
              <span>✏️</span>
              <span>${isAR ? 'تعديل' : 'Edit'}</span>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="Purchasing.printDoc(${d.id}, '${store}')" title="${isAR ? 'طباعة' : 'Print'}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="Purchasing.deleteDoc(${d.id}, '${store}')" style="color:var(--danger)" title="${isAR ? 'حذف' : 'Delete'}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            </button>
          </div>
        </td>
      </tr>`;
    }).join('');
  }

  // ── Open Document Form ──────────────────────────────────────
  async function openDoc(store, id) {
    const isAR = i18n.getLang() === 'ar';
    const suppliers  = await DB.getAll('suppliers');
    const items      = await DB.getAll('items');
    let warehouses = (await DB.getAll('warehouses')) || [];
    if (!warehouses.length) {
      warehouses = [{ id: 1, name: 'Main Store', name_ar: 'المستودع الرئيسي', code: 'WH-01', is_default: true }];
    }

    let doc = null;
    let docItems = [];
    if (id) {
      doc = await DB.get(store, id);
      docItems = JSON.parse(doc?.items_json || '[]');
    }

    const storeLabels = {
      purchase_orders:   { en: 'Purchase Order',   ar: 'أمر شراء',       prefix: 'PO-' },
      goods_receipts:    { en: 'Goods Receipt',    ar: 'سند استلام بضاعة', prefix: 'GRN-' },
      purchase_invoices: { en: 'Purchase Invoice', ar: 'فاتورة شراء',    prefix: 'PINV-' },
      purchase_returns:  { en: 'Purchase Return',  ar: 'مرتجع شراء',     prefix: 'PRET-' },
    };
    const lbl = storeLabels[store] || { en: store, ar: store, prefix: 'DOC-' };

    document.getElementById('pur-doc-title').innerHTML = `
      <div style="display:flex;align-items:center;gap:10px">
        <span style="background:var(--primary);color:#fff;width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.1rem">📥</span>
        <div>
          <div>${id ? (isAR ? 'تعديل ' : 'Edit ') : (isAR ? 'إدخال ' : 'New ')}${isAR ? lbl.ar : lbl.en}</div>
          <div style="font-size:0.75rem;font-weight:500;color:var(--text-muted)">${isAR ? 'إدخال سريع للأصناف عبر مسح الباركود أو البحث الفوري' : 'Fast item insertion via barcode scanner or instant live search'}</div>
        </div>
      </div>`;

    window._purStore          = store;
    window._purDocId          = id;
    window._purDocItems       = [...docItems];
    window._purOriginalItems  = JSON.parse(doc?.items_json || '[]');
    window._purOriginalSupplierId = doc?.supplier_id || null;
    window._purDocPrefix      = lbl.prefix;
    window._purItems          = items;
    window._purSuppliers      = suppliers;
    window._purWarehouses     = warehouses;

    const baseCur = await DB.getSetting('currency_1', 'USD');
    const secCur  = await DB.getSetting('currency_2', 'LBP');
    const systemExchRate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const docCurrency = doc?.currency || baseCur;
    const docExchRate = parseFloat(doc?.exchange_rate) || systemExchRate;

    window._purBaseCurrency   = baseCur;
    window._purSecCurrency    = secCur;
    window._purSystemExchRate = systemExchRate;
    window._purDocCurrency    = docCurrency;
    window._purDocExchRate    = docExchRate;
    window._purVatRate        = parseFloat(await DB.getSetting('vat_rate', 11)) || 11;
    window._purVatEnabled     = (await DB.getSetting('vat_enabled', false)) !== false;

    const defaultDate = doc?.doc_date || Utils.today();
    const defaultTime = doc?.doc_time || new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    const selectedPayMethod = doc?.payment_method || 'cash';
    const selectedWhId = doc?.warehouse_id || warehouses[0]?.id || 1;

    document.getElementById('pur-doc-body').innerHTML = `
    ${id ? `
    <!-- Existing Invoice Edit Banner -->
    <div style="background:rgba(245,158,11,0.12);border:1px solid #f59e0b;border-radius:8px;padding:6px 12px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0">
      <div style="font-size:0.8rem;font-weight:800;color:#b45309;display:flex;align-items:center;gap:6px">
        <span>✏️</span>
        <span>${isAR ? `وضع تعديل فاتورة الشراء: [${doc?.ref || ''}] (صلاحية إدارية)` : `Editing Existing Purchase Invoice: [${doc?.ref || ''}] (Admin Access)`}</span>
      </div>
      <span class="badge badge-warning" style="font-size:0.72rem;font-weight:700">${isAR ? 'تعديل فاتورة مسجلة' : 'Existing Document'}</span>
    </div>` : ''}

    <!-- Top Details Section (Compact Ribbon) -->
    <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:8px 12px;flex-shrink:0">
      <div class="grid grid-4" style="gap:8px;margin-bottom:6px">
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">${isAR ? 'رقم الوثيقة الداخلي' : 'Internal Ref #'}</label>
          <input type="text" class="form-control" id="pur-doc-ref" value="${doc?.ref || ''}" placeholder="${isAR ? 'تلقائي (PINV-...)' : 'Auto generated'}" style="font-weight:800;color:var(--primary);height:32px;padding:4px 8px;font-size:0.85rem">
        </div>
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">
            ${isAR ? 'رقم فاتورة المورد الأصلية' : 'Supplier Invoice / Bill #'}
            <span style="color:var(--danger)">*</span>
          </label>
          <input type="text" class="form-control" id="pur-doc-supp-inv" value="${doc?.supplier_invoice_no || ''}" placeholder="${isAR ? 'مثال: INV-9842' : 'e.g. INV-9842'}" style="font-weight:700;height:32px;padding:4px 8px;font-size:0.85rem">
        </div>
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">${isAR ? 'تاريخ الفاتورة' : 'Invoice Date'}</label>
          <input type="date" class="form-control" id="pur-doc-date" value="${defaultDate}" style="height:32px;padding:4px 8px;font-size:0.85rem">
        </div>
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">${isAR ? 'وقت الإدخال' : 'Time'}</label>
          <input type="time" class="form-control" id="pur-doc-time" value="${defaultTime}" style="height:32px;padding:4px 8px;font-size:0.85rem">
        </div>
      </div>

      <div class="grid grid-5" style="gap:8px">
        <!-- Supplier with Quick Add -->
        <div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:2px">
            <label style="font-size:0.72rem;font-weight:700;margin:0">${isAR ? 'المورد' : 'Supplier'} *</label>
            <button type="button" class="btn btn-ghost btn-sm" onclick="Purchasing.openQuickSupplierModal()" style="font-size:0.7rem;padding:0 3px;color:var(--primary);height:18px">
              + ${isAR ? 'مورد جديد' : 'New'}
            </button>
          </div>
          <select class="form-control" id="pur-doc-supplier" onchange="Purchasing.onSupplierChange(this.value)" style="font-weight:600;height:32px;padding:4px 8px;font-size:0.82rem">
            <option value="">-- ${isAR ? 'اختر المورد' : 'Select Supplier'} --</option>
            ${suppliers.map(s => {
              const name = isAR ? (s.name_ar || s.name_en) : (s.name_en || s.name_ar);
              return `<option value="${s.id}" ${doc?.supplier_id === s.id ? 'selected' : ''}>
                ${Utils.sanitize(name)} ${s.phone ? `(${s.phone})` : ''}
              </option>`;
            }).join('')}
          </select>
          <div id="pur-supplier-balance-note" style="font-size:0.7rem;color:var(--text-muted);margin-top:2px"></div>
        </div>

        <!-- Destination Warehouse -->
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">${isAR ? 'المستودع المستلم' : 'Destination Warehouse'}</label>
          <select class="form-control" id="pur-doc-warehouse" style="font-weight:600;height:32px;padding:4px 8px;font-size:0.82rem">
            ${warehouses.map(w => {
              const wName = isAR ? (w.name_ar || w.name) : (w.name || w.name_ar);
              return `<option value="${w.id}" ${selectedWhId === w.id ? 'selected' : ''}>🏬 ${Utils.sanitize(wName)}</option>`;
            }).join('')}
          </select>
        </div>

        <!-- Payment Method -->
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
          <select class="form-control" id="pur-doc-payment-method" onchange="Purchasing.onPaymentMethodChange(this.value)" style="font-weight:700;height:32px;padding:4px 8px;font-size:0.82rem">
            <option value="cash" ${selectedPayMethod === 'cash' ? 'selected' : ''}>💵 ${isAR ? 'نقدي (Cash)' : 'Cash'}</option>
            <option value="credit" ${selectedPayMethod === 'credit' ? 'selected' : ''}>⏳ ${isAR ? 'آجل / ذمم (Debit/Credit)' : 'On Credit (Debit)'}</option>
            <option value="card" ${selectedPayMethod === 'card' ? 'selected' : ''}>💳 ${isAR ? 'بطاقة (Card)' : 'Card'}</option>
            <option value="transfer" ${selectedPayMethod === 'transfer' ? 'selected' : ''}>🏦 ${isAR ? 'تحويل (Transfer)' : 'Bank Transfer'}</option>
            <option value="cheque" ${selectedPayMethod === 'cheque' ? 'selected' : ''}>📝 ${isAR ? 'شيك (Cheque)' : 'Cheque'}</option>
          </select>
        </div>

        <!-- Currency Selector (Prominent!) -->
        <div>
          <label style="font-size:0.72rem;font-weight:800;display:block;margin-bottom:2px;color:var(--primary)">
            💱 ${isAR ? 'عملة الفاتورة' : 'Invoice Currency'} *
          </label>
          <select class="form-control" id="pur-doc-currency" onchange="Purchasing.onCurrencyChange(this.value)" style="font-weight:800;height:32px;padding:4px 8px;font-size:0.82rem;border:2px solid var(--primary);background:rgba(37,99,235,0.06);color:var(--primary)">
            <option value="USD" ${docCurrency === 'USD' ? 'selected' : ''}>💵 USD ($)</option>
            <option value="LBP" ${docCurrency === 'LBP' ? 'selected' : ''}>🇱🇧 L.L. / LBP (ل.ل)</option>
          </select>
        </div>

        <!-- Status -->
        <div>
          <label style="font-size:0.72rem;font-weight:700;display:block;margin-bottom:2px">${isAR ? 'حالة الفاتورة' : 'Status'}</label>
          <select class="form-control" id="pur-doc-status" style="font-weight:700;height:32px;padding:4px 8px;font-size:0.82rem">
            <option value="received" ${(!doc || doc?.status === 'received') ? 'selected' : ''}>✅ ${isAR ? 'مستلمة ومكتملة' : 'Received'}</option>
            <option value="approved" ${doc?.status === 'approved' ? 'selected' : ''}>🔵 ${isAR ? 'معتمدة' : 'Approved'}</option>
            <option value="pending" ${doc?.status === 'pending' ? 'selected' : ''}>⏳ ${isAR ? 'معلقة' : 'Pending'}</option>
            <option value="draft" ${doc?.status === 'draft' ? 'selected' : ''}>📝 ${isAR ? 'مسودة' : 'Draft'}</option>
          </select>
        </div>
      </div>

      <!-- Exchange Rate Banner for Foreign/Secondary Currency (e.g. LBP when base is USD) -->
      <div id="pur-exch-rate-panel" style="display:${docCurrency !== baseCur ? 'flex' : 'none'};align-items:center;justify-content:space-between;gap:12px;background:linear-gradient(135deg, rgba(245,158,11,0.14) 0%, rgba(217,119,6,0.08) 100%);border:1px solid #f59e0b;border-radius:8px;padding:5px 12px;margin-top:6px">
        <div style="display:flex;align-items:center;gap:8px;font-size:0.78rem;font-weight:700;color:#92400e">
          <span>💱</span>
          <span>${isAR ? 'سعر صرف الفاتورة مقابل الدولار:' : 'Invoice Exchange Rate to USD:'}</span>
          <span style="font-weight:800;color:#78350f">1 USD =</span>
          <input type="number" id="pur-doc-exch-rate" value="${docExchRate}" min="1" step="any"
            oninput="Purchasing.onExchRateChange(this.value)"
            style="width:115px;height:26px;padding:2px 8px;font-weight:800;font-size:0.85rem;color:#b45309;background:#fff;border:1.5px solid #f59e0b;border-radius:6px;text-align:center">
          <span style="font-weight:800;color:#78350f">L.L. (ل.ل)</span>
        </div>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="font-size:0.72rem;color:#78350f">
            (${isAR ? 'سعر النظام:' : 'System:'} <strong>${systemExchRate.toLocaleString()} L.L.</strong>)
          </span>
          <button type="button" class="btn btn-sm btn-ghost" onclick="Purchasing.resetExchRateToDefault()" style="font-size:0.7rem;padding:2px 6px;height:22px;color:#92400e;border:1px solid #f59e0b;background:rgba(255,255,255,0.7)" title="${isAR ? 'استعادة سعر النظام' : 'Reset to System Rate'}">
            ↺ ${isAR ? 'استعادة الافتراضي' : 'Reset'}
          </button>
        </div>
      </div>
    </div>

    <!-- MAIN 2-COLUMN WORKSPACE: Table on Left, Totals & Payment on Right (Both permanently visible!) -->
    <div style="flex:1;display:flex;gap:12px;min-height:0;overflow:hidden">

      <!-- LEFT COLUMN: Scanner Bar + Line Items Table (Expands to fill available space) -->
      <div style="flex:1;display:flex;flex-direction:column;gap:8px;min-width:0;min-height:0;overflow:hidden">
        
        <!-- FAST BARCODE SCANNING BAR (Flex layout - NO RTL/LTR text overlap!) -->
        <div style="position:relative;flex-shrink:0">
          <div style="background:var(--surface);border:2px solid var(--primary);border-radius:10px;padding:6px 12px;display:flex;align-items:center;gap:10px;box-shadow:0 2px 10px rgba(37,99,235,0.12)">
            <span style="font-size:1.3rem;line-height:1">⚡</span>
            <input type="text" class="form-control" id="pur-search-barcode"
              placeholder="${isAR ? 'امسح الباركود بجهاز القارئ، أو اكتب اسم الصنف أو الكود هنا...' : 'Scan barcode with handheld reader, or type product name/code...'}"
              oninput="Purchasing.onSearchInput(this.value)"
              onkeydown="Purchasing.onSearchKeyDown(event)"
              autocomplete="off"
              style="border:none;background:transparent;box-shadow:none;font-size:0.95rem;font-weight:700;flex:1;padding:4px 8px;outline:none">
            <span id="pur-scan-notice" style="font-size:0.75rem;font-weight:700;color:var(--success);display:none;white-space:nowrap"></span>
            <span class="badge badge-primary" style="font-size:0.75rem;font-weight:700;padding:4px 8px;white-space:nowrap">
              📟 ${isAR ? 'جاهز للمسح' : 'Scanner Ready'}
            </span>
            <button type="button" class="btn btn-primary btn-sm" onclick="Purchasing.openQuickNewItemModal()" style="font-weight:800;white-space:nowrap;padding:6px 12px;border-radius:8px;display:flex;align-items:center;gap:4px">
              <span>➕</span>
              <span>${isAR ? 'صنف جديد' : 'New Product'}</span>
            </button>
          </div>

          <!-- Live Autocomplete Floating Dropdown -->
          <div id="pur-search-results" style="display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;z-index:99999;background:var(--surface);border:1px solid var(--border-color);border-radius:12px;box-shadow:0 14px 36px rgba(0,0,0,0.3);max-height:300px;overflow-y:auto"></div>
        </div>

        <!-- ITEMS TABLE (Fills remaining height, scrolls internally if many items) -->
        <div style="flex:1;display:flex;flex-direction:column;min-height:0;overflow:hidden;background:var(--surface);border:1px solid var(--border-color);border-radius:10px">
          <div style="padding:6px 12px;background:var(--surface-2);border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-shrink:0">
            <div style="font-weight:800;font-size:0.85rem;display:flex;align-items:center;gap:6px">
              <span>📋</span>
              <span>${isAR ? 'قائمة أصناف الفاتورة' : 'Invoice Line Items'}</span>
              <span class="badge badge-primary" id="pur-items-badge-count" style="font-size:0.7rem;padding:2px 6px">0</span>
            </div>
            <div style="font-size:0.72rem;color:var(--text-muted)">
              ${isAR ? 'الضريبة TVA تحسب حصراً للأصناف الخاضعة ويمكن تعديلها لكل سطر' : 'TVA is calculated only for taxable items & can be edited per line'}
            </div>
          </div>

          <div style="flex:1;overflow:auto;min-height:0">
            <table id="pur-lines-table" style="width:100%;border-collapse:collapse">
              <thead style="position:sticky;top:0;z-index:2;background:var(--surface)">
                <tr style="font-size:0.78rem;color:var(--text-secondary);border-bottom:2px solid var(--border-color)">
                  <th style="padding:6px 8px;width:32px;text-align:center">#</th>
                  <th style="padding:6px 8px;text-align:left">${isAR ? 'الصنف والباركود' : 'Product & Barcode'}</th>
                  <th style="padding:6px 8px;width:75px;text-align:center">${isAR ? 'الوحدة' : 'Unit'}</th>
                  <th style="padding:6px 8px;width:80px;text-align:center">${isAR ? 'الكمية' : 'Qty'} *</th>
                  <th style="padding:6px 8px;width:105px;text-align:center">${isAR ? 'سعر الشراء' : 'Cost Price'} *</th>
                  <th style="padding:6px 8px;width:105px;text-align:center">${isAR ? 'سعر البيع' : 'Sell Price'}</th>
                  <th style="padding:6px 8px;width:65px;text-align:center">${isAR ? 'خصم%' : 'Disc%'}</th>
                  <th style="padding:6px 8px;width:75px;text-align:center">${isAR ? 'ضريبة TVA' : 'TVA Tax%'}</th>
                  <th style="padding:6px 8px;width:115px;text-align:center">${isAR ? 'الصلاحية' : 'Expiry'}</th>
                  <th style="padding:6px 8px;width:110px;text-align:right">${isAR ? 'الإجمالي' : 'Total'}</th>
                  <th style="padding:6px 8px;width:36px;text-align:center"></th>
                </tr>
              </thead>
              <tbody id="pur-lines-body"></tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- RIGHT COLUMN: Permanent Financial Summary & Payment Breakdown (Always in full view!) -->
      <div style="width:340px;flex-shrink:0;display:flex;flex-direction:column;gap:8px;overflow-y:auto;padding-right:2px">
        
        <!-- Big Net Grand Total Banner -->
        <div style="background:linear-gradient(135deg, #1e40af 0%, #2563eb 100%);color:#fff;border-radius:10px;padding:12px;text-align:center;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
          <div style="font-size:0.75rem;font-weight:700;opacity:0.9;text-transform:uppercase;letter-spacing:0.5px">
            ${isAR ? 'الصافي النهائي للمورد (شامل الضريبة)' : 'NET GRAND TOTAL (INCL. TAX)'}
          </div>
          <div id="pur-grand-total" style="font-size:1.85rem;font-weight:900;letter-spacing:1px;margin:2px 0">$0.00</div>
          <div id="pur-grand-total-base" style="display:none;font-size:0.82rem;font-weight:800;background:rgba(255,255,255,0.2);padding:4px 8px;border-radius:6px;margin:4px 0"></div>
          <div id="pur-total-qty" style="font-size:0.75rem;opacity:0.9">0 items (0 units)</div>
        </div>

        <!-- Financial Breakdown Box (Separating Net Amount and TVA Tax Amount alone!) -->
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:10px;font-size:0.82rem">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span style="color:var(--text-secondary)">${isAR ? 'المجموع الصافي (قبل الضريبة):' : 'Net Subtotal (Excl. Tax):'}</span>
            <span style="font-weight:700;color:var(--text-primary)" id="pur-subtotal">$0.00</span>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
            <span style="color:var(--text-secondary)">${isAR ? 'خصم الفاتورة:' : 'Discount:'}</span>
            <div style="display:flex;gap:4px;align-items:center">
              <input type="number" id="pur-disc-val" value="${doc?.discount || 0}" min="0" step="any"
                style="width:75px;padding:3px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;font-weight:700;text-align:right;font-size:0.8rem"
                oninput="Purchasing.recalcTotals()">
              <select id="pur-disc-type" onchange="Purchasing.recalcTotals()" style="padding:3px 4px;border-radius:6px;background:var(--input-bg);border:1px solid var(--border-color);font-size:0.75rem">
                <option value="amount" ${(!doc?.discount_type || doc?.discount_type === 'amount') ? 'selected' : ''}>$</option>
                <option value="pct" ${doc?.discount_type === 'pct' ? 'selected' : ''}>%</option>
              </select>
            </div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;padding:5px 8px;background:rgba(245,158,11,0.08);border-radius:6px;border:1px dashed #f59e0b">
            <div>
              <span style="color:#b45309;font-weight:700">${isAR ? 'ضريبة القيمة المضافة (TVA):' : 'TVA Tax Amount:'}</span>
              <div style="font-size:0.68rem;color:var(--text-muted)">${isAR ? 'للأصناف الخاضعة فقط' : 'Taxable items only'}</div>
            </div>
            <span id="pur-tax-amount" style="font-weight:800;color:#b45309;font-size:0.92rem">$0.00</span>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:var(--text-secondary)">${isAR ? 'شحن / مصاريف نقل:' : 'Freight / Shipping:'}</span>
            <input type="number" id="pur-shipping" value="${doc?.shipping_cost || 0}" min="0" step="any"
              style="width:75px;padding:3px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;font-weight:700;text-align:right;font-size:0.8rem"
              oninput="Purchasing.recalcTotals()">
          </div>
        </div>

        <!-- Supplier Payment Breakdown Box (Prominent DEBIT / CREDIT Selection Highlighting!) -->
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:10px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div style="font-weight:800;font-size:0.82rem;color:var(--text-primary)">
              💳 ${isAR ? 'تفاصيل السداد وحساب المورد' : 'Supplier Payment Breakdown'}
            </div>
          </div>

          <!-- Highlighted Payment Choice Buttons: Cash vs Debit -->
          <div style="display:flex;gap:6px;margin-bottom:8px">
            <button type="button" id="pur-pay-btn-cash" class="btn btn-sm flex-1" onclick="Purchasing.selectPaymentMode('cash')"
              style="font-size:0.78rem;padding:6px 4px;border-radius:8px;font-weight:700;border:1.5px solid var(--border-color);transition:all 0.2s">
              💵 ${isAR ? 'نقدي (سداد)' : 'Cash (Paid)'}
            </button>
            <button type="button" id="pur-pay-btn-credit" class="btn btn-sm flex-1" onclick="Purchasing.selectPaymentMode('credit')"
              style="font-size:0.78rem;padding:6px 4px;border-radius:8px;font-weight:700;border:1.5px solid var(--border-color);transition:all 0.2s">
              ⏳ ${isAR ? 'آجل / ذمم (Debit)' : 'On Credit (Debit)'}
            </button>
          </div>

          <!-- Live Visual Highlight Badge -->
          <div id="pur-payment-status-badge" style="margin-bottom:8px"></div>

          <div class="grid grid-2" style="gap:8px;margin-bottom:6px">
            <div>
              <label style="font-size:0.72rem;font-weight:600">${isAR ? 'المدفوع حالياً:' : 'Paid Now:'}</label>
              <input type="number" step="any" min="0" class="form-control" id="pur-doc-paid"
                value="${doc?.paid_amount !== undefined ? doc.paid_amount : 0}"
                oninput="Purchasing.recalcTotals()" style="font-weight:800;font-size:0.88rem;color:var(--success);padding:4px 8px;height:30px">
            </div>
            <div>
              <label style="font-size:0.72rem;font-weight:600">${isAR ? 'المتبقي (آجل / دين للمورد):' : 'Due (On Credit):'}</label>
              <input type="text" class="form-control" id="pur-doc-due" value="$0.00" readonly style="font-weight:800;font-size:0.88rem;color:var(--danger);background:var(--surface-2);padding:4px 8px;height:30px">
              <div id="pur-doc-due-hint" style="font-size:0.7rem;color:var(--danger);margin-top:2px;font-weight:700"></div>
            </div>
          </div>
          <div style="display:flex;gap:6px">
            <button type="button" class="btn btn-sm btn-secondary flex-1" onclick="Purchasing.quickSetPaid('full')" style="font-size:0.72rem;padding:4px">
              ✓ ${isAR ? 'سداد كامل' : 'Paid in Full'}
            </button>
            <button type="button" class="btn btn-sm btn-secondary flex-1" onclick="Purchasing.quickSetPaid('zero')" style="font-size:0.72rem;padding:4px">
              ⏳ ${isAR ? 'آجل بالكامل (Debit)' : 'Full Credit (Debit)'}
            </button>
          </div>
        </div>

        <!-- Auto-Sync Toggles & Notes -->
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:8px;font-size:0.75rem">
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;margin-bottom:4px;font-weight:700">
            <input type="checkbox" id="pur-toggle-stock" checked>
            <span>📦 ${isAR ? 'إضافة الكميات للمخزون' : 'Auto-add Qty to Stock'}</span>
          </label>
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer;margin-bottom:6px;font-weight:700">
            <input type="checkbox" id="pur-toggle-cost" checked>
            <span>💲 ${isAR ? 'تحديث سعر التكلفة والبيع' : 'Update Cost & Sell Price'}</span>
          </label>
          <textarea class="form-control" id="pur-doc-notes" rows="2" placeholder="${isAR ? 'ملاحظات الفاتورة...' : 'Invoice notes...'}" style="font-size:0.75rem;padding:4px 6px">${doc?.notes || ''}</textarea>
        </div>
      </div>
    </div>`;

    renderDocLines();
    if (doc?.supplier_id) {
      onSupplierChange(doc.supplier_id);
    }
    Utils.openModal('pur-doc-modal');

    // Global shortcut handler for Purchase modal
    if (window._purKeydownHandler) {
      window.removeEventListener('keydown', window._purKeydownHandler);
    }
    window._purKeydownHandler = (e) => {
      const modal = document.getElementById('pur-doc-modal');
      if (modal && (modal.classList.contains('open') || modal.classList.contains('active'))) {
        if (e.key === 'F9') {
          e.preventDefault();
          saveDoc(window._purStore || 'purchase_invoices');
        }
      }
    };
    window.addEventListener('keydown', window._purKeydownHandler);

    // Auto-focus barcode scan box
    setTimeout(() => {
      const searchBox = document.getElementById('pur-search-barcode');
      if (searchBox) searchBox.focus();
    }, 150);
  }

  function closeDocModal() {
    Utils.closeModal('pur-doc-modal');
    if (window._purKeydownHandler) {
      window.removeEventListener('keydown', window._purKeydownHandler);
      window._purKeydownHandler = null;
    }
  }

  // ── Supplier Change Handler ─────────────────────────────────
  async function onSupplierChange(supplierId) {
    const isAR = i18n.getLang() === 'ar';
    const noteEl = document.getElementById('pur-supplier-balance-note');
    if (!noteEl) return;
    if (!supplierId) {
      noteEl.innerHTML = '';
      return;
    }
    const supId = parseInt(supplierId, 10);
    const sup = (window._purSuppliers || []).find(s => s.id === supId);
    if (!sup) {
      noteEl.innerHTML = '';
      return;
    }

    try {
      const updatedSup = await updateSupplierFinancials(supId);
      const balance = updatedSup?.balance ?? (sup.balance || 0);

      noteEl.innerHTML = `
        <span style="font-weight:700;color:${balance > 0 ? 'var(--danger)' : 'var(--success)'}">
          ${isAR ? 'رصيد المورد المستحق (دين):' : 'Outstanding Supplier Due:'} ${Utils.formatMoney(balance)}
        </span>
        ${sup.tax_number ? ` • <span>${isAR ? 'الرقم الضريبي:' : 'Tax #:'} ${Utils.sanitize(sup.tax_number)}</span>` : ''}
      `;
    } catch (e) {
      noteEl.innerHTML = '';
    }
  }

  // ── Payment Mode & Debit Highlighting Handlers ──────────────
  function selectPaymentMode(mode) {
    const methodSel = document.getElementById('pur-doc-payment-method');
    const paidInput = document.getElementById('pur-doc-paid');

    if (mode === 'cash') {
      if (methodSel) methodSel.value = 'cash';
      if (paidInput) paidInput.value = window._purGrandTotal || 0;
    } else if (mode === 'credit') {
      if (methodSel) methodSel.value = 'credit';
      if (paidInput) paidInput.value = 0;
    }
    recalcTotals();
  }

  function onPaymentMethodChange(val) {
    if (val === 'cash') {
      selectPaymentMode('cash');
    } else if (val === 'credit') {
      selectPaymentMode('credit');
    } else {
      recalcTotals();
    }
  }

  function quickSetPaid(type) {
    if (type === 'full') {
      selectPaymentMode('cash');
    } else if (type === 'zero') {
      selectPaymentMode('credit');
    }
  }

  function updatePaymentHighlight(paidAmount, grandTotal) {
    const isAR = i18n.getLang() === 'ar';
    const payMethodSelect = document.getElementById('pur-doc-payment-method');
    const method = payMethodSelect ? payMethodSelect.value : 'cash';

    const btnCash = document.getElementById('pur-pay-btn-cash');
    const btnCredit = document.getElementById('pur-pay-btn-credit');
    const badgeStatus = document.getElementById('pur-payment-status-badge');
    const dueInput = document.getElementById('pur-doc-due');

    const isCredit = (method === 'credit') || (paidAmount === 0 && grandTotal > 0);
    const isPartial = (paidAmount > 0 && paidAmount < grandTotal);
    const isFullCash = (paidAmount >= grandTotal && grandTotal > 0);

    if (btnCash) {
      if (isFullCash && method === 'cash') {
        btnCash.style.background = '#16a34a';
        btnCash.style.color = '#ffffff';
        btnCash.style.border = '2px solid #15803d';
        btnCash.style.boxShadow = '0 3px 10px rgba(22,163,74,0.4)';
        btnCash.style.fontWeight = '800';
      } else {
        btnCash.style.background = 'var(--surface-2)';
        btnCash.style.color = 'var(--text-primary)';
        btnCash.style.border = '1.5px solid var(--border-color)';
        btnCash.style.boxShadow = 'none';
        btnCash.style.fontWeight = '600';
      }
    }

    if (btnCredit) {
      if (isCredit || method === 'credit') {
        // Highlighting DEBIT / ON CREDIT prominently!
        btnCredit.style.background = '#e11d48';
        btnCredit.style.color = '#ffffff';
        btnCredit.style.border = '2px solid #be123c';
        btnCredit.style.boxShadow = '0 4px 14px rgba(225,29,72,0.45)';
        btnCredit.style.fontWeight = '900';
      } else {
        btnCredit.style.background = 'var(--surface-2)';
        btnCredit.style.color = 'var(--text-primary)';
        btnCredit.style.border = '1.5px solid var(--border-color)';
        btnCredit.style.boxShadow = 'none';
        btnCredit.style.fontWeight = '600';
      }
    }

    if (dueInput) {
      if (grandTotal - paidAmount > 0) {
        dueInput.style.color = '#e11d48';
        dueInput.style.fontWeight = '900';
        dueInput.style.borderColor = '#e11d48';
      } else {
        dueInput.style.color = 'var(--text-muted)';
        dueInput.style.fontWeight = '700';
        dueInput.style.borderColor = 'var(--border-color)';
      }
    }

    if (badgeStatus) {
      if (method === 'credit' || (paidAmount === 0 && grandTotal > 0)) {
        badgeStatus.innerHTML = `
          <div style="background:linear-gradient(135deg, rgba(225,29,72,0.12) 0%, rgba(244,63,94,0.08) 100%);border:1.5px solid #e11d48;border-radius:8px;padding:6px 10px;display:flex;align-items:center;gap:6px;color:#e11d48;font-weight:800;font-size:0.78rem">
            <span>⏳</span>
            <span>${isAR ? 'فاتورة شراء آجل (ذمم / Debit) — سيتم قيد المبلغ كاملاً في حساب المورد' : 'Purchased On Credit (Debit) — Full amount will be added to supplier balance'}</span>
          </div>`;
        badgeStatus.style.display = 'block';
      } else if (isPartial) {
        badgeStatus.innerHTML = `
          <div style="background:linear-gradient(135deg, rgba(245,158,11,0.14) 0%, rgba(217,119,6,0.08) 100%);border:1.5px solid #f59e0b;border-radius:8px;padding:6px 10px;display:flex;align-items:center;gap:6px;color:#b45309;font-weight:800;font-size:0.78rem">
            <span>⚠️</span>
            <span>${isAR ? 'دفعة جزئية — سيتم قيد المتبقي آجل في حساب المورد' : 'Partial Payment — Remaining due will be added to supplier balance'}</span>
          </div>`;
        badgeStatus.style.display = 'block';
      } else {
        badgeStatus.innerHTML = `
          <div style="background:linear-gradient(135deg, rgba(22,163,74,0.12) 0%, rgba(34,197,94,0.08) 100%);border:1.5px solid #16a34a;border-radius:8px;padding:6px 10px;display:flex;align-items:center;gap:6px;color:#15803d;font-weight:800;font-size:0.78rem">
            <span>✓</span>
            <span>${isAR ? 'مسددة بالكامل نقداً — لا يترتب أي دين على حساب المورد' : 'Paid in Full — No debt added to supplier'}</span>
          </div>`;
        badgeStatus.style.display = 'block';
      }
    }
  }

  // ── Multi-Currency Handlers (USD / LBP) ─────────────────────
  function onCurrencyChange(newCur) {
    const isAR = i18n.getLang() === 'ar';
    const oldCur = window._purDocCurrency || 'USD';
    if (newCur === oldCur) return;

    const baseCur = window._purBaseCurrency || 'USD';
    const exchRate = window._purDocExchRate || window._purSystemExchRate || 89500;
    const exchPanel = document.getElementById('pur-exch-rate-panel');

    if (exchPanel) {
      exchPanel.style.display = (newCur !== baseCur) ? 'flex' : 'none';
    }

    const lines = window._purDocItems || [];
    if (lines.length > 0) {
      // Calculate conversion ratio from old to new currency
      let ratio = 1;
      const isLbpOld = Utils.isLbp ? Utils.isLbp(oldCur) : (oldCur === 'LBP' || oldCur === 'LL');
      const isLbpNew = Utils.isLbp ? Utils.isLbp(newCur) : (newCur === 'LBP' || newCur === 'LL');
      const isUsdOld = Utils.isUsd ? Utils.isUsd(oldCur) : (oldCur === 'USD' || oldCur === '$');
      const isUsdNew = Utils.isUsd ? Utils.isUsd(newCur) : (newCur === 'USD' || newCur === '$');
      if (isUsdOld && isLbpNew) {
        ratio = exchRate;
      } else if (isLbpOld && isUsdNew) {
        ratio = 1 / exchRate;
      }

      Utils.confirm(
        isAR 
          ? `هل ترغب بتحويل أسعار الأصناف الحالية (${lines.length} صنف) تلقائياً من ${oldCur === 'USD' ? 'الدولار ($)' : 'الليرة (ل.ل)'} إلى ${newCur === 'USD' ? 'الدولار ($)' : 'الليرة (ل.ل)'} بسعر صرف ${exchRate.toLocaleString()} ل.ل؟`
          : `Convert prices of existing ${lines.length} items from ${oldCur} to ${newCur} using rate ${exchRate.toLocaleString()} L.L.?`,
        () => {
          lines.forEach(l => {
            l.price = Utils.round(l.price * ratio, (newCur === 'LBP' ? 0 : 2));
            if (l.prev_cost) l.prev_cost = Utils.round(l.prev_cost * ratio, (newCur === 'LBP' ? 0 : 2));
            if (l.selling_price) l.selling_price = Utils.round(l.selling_price * ratio, (newCur === 'LBP' ? 0 : 2));
            const sub = (l.qty || 0) * (l.price || 0) * (1 - (l.disc || 0) / 100);
            l.total = Utils.round(sub * (1 + (l.tax_pct || 0) / 100), (newCur === 'LBP' ? 0 : 2));
          });
          window._purDocCurrency = newCur;
          renderDocLines();
        },
        () => {
          window._purDocCurrency = newCur;
          renderDocLines();
        }
      );
    } else {
      window._purDocCurrency = newCur;
      renderDocLines();
    }
  }

  function onExchRateChange(newRate) {
    const val = parseFloat(newRate);
    if (!val || val <= 0) return;
    window._purDocExchRate = val;
    renderDocLines();
  }

  function resetExchRateToDefault() {
    const defaultRate = window._purSystemExchRate || 89500;
    const input = document.getElementById('pur-doc-exch-rate');
    if (input) input.value = defaultRate;
    onExchRateChange(defaultRate);
  }

  // ── Currency Conversion Helpers (Lebanese USD / LBP) ────────
  function getDocRateToBase() {
    const baseCur = window._purBaseCurrency || 'USD';
    const docCur  = window._purDocCurrency || 'USD';
    const rate    = parseFloat(window._purDocExchRate) || 89500;
    if (docCur === baseCur) return 1;
    const isLbpBase = Utils.isLbp ? Utils.isLbp(baseCur) : (baseCur === 'LBP' || baseCur === 'LL');
    const isLbpDoc  = Utils.isLbp ? Utils.isLbp(docCur) : (docCur === 'LBP' || docCur === 'LL');
    const isUsdBase = Utils.isUsd ? Utils.isUsd(baseCur) : (baseCur === 'USD' || baseCur === '$');
    const isUsdDoc  = Utils.isUsd ? Utils.isUsd(docCur) : (docCur === 'USD' || docCur === '$');
    if (isUsdBase && isLbpDoc) return 1 / rate;
    if (isLbpBase && isUsdDoc) return rate;
    return 1;
  }

  function getBaseToDocMultiplier() {
    const baseCur = window._purBaseCurrency || 'USD';
    const docCur  = window._purDocCurrency || 'USD';
    const rate    = parseFloat(window._purDocExchRate) || 89500;
    if (docCur === baseCur) return 1;
    const isLbpBase = Utils.isLbp ? Utils.isLbp(baseCur) : (baseCur === 'LBP' || baseCur === 'LL');
    const isLbpDoc  = Utils.isLbp ? Utils.isLbp(docCur) : (docCur === 'LBP' || docCur === 'LL');
    const isUsdBase = Utils.isUsd ? Utils.isUsd(baseCur) : (baseCur === 'USD' || baseCur === '$');
    const isUsdDoc  = Utils.isUsd ? Utils.isUsd(docCur) : (docCur === 'USD' || docCur === '$');
    if (isUsdBase && isLbpDoc) return rate;
    if (isLbpBase && isUsdDoc) return 1 / rate;
    return 1;
  }

  function formatDocMoney(amt, cur = null) {
    const isAR = i18n.getLang() === 'ar';
    const c = cur || window._purDocCurrency || 'USD';
    const isLbp = (Utils.isLbp && Utils.isLbp(c)) || c === 'LBP' || c === 'LL';
    const dec = isLbp ? 0 : 2;
    const num = parseFloat(amt) || 0;
    const str = num.toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec });
    if (Utils.isUsd && Utils.isUsd(c)) return `$${str}`;
    if (isLbp) return `${str} ${isAR ? 'ل.ل' : 'L.L.'}`;
    return `${str} ${c}`;
  }

  // ── Render Document Lines ───────────────────────────────────
  function renderDocLines() {
    const isAR = i18n.getLang() === 'ar';
    const tbody = document.getElementById('pur-lines-body');
    const badge = document.getElementById('pur-items-badge-count');
    if (!tbody) return;
    const lines = window._purDocItems || [];
    const docCur = window._purDocCurrency || 'USD';
    const baseCur = window._purBaseCurrency || 'USD';
    const rateToBase = getDocRateToBase();
    const isForeign = (docCur !== baseCur);
    const curSym = docCur === 'USD' ? '$' : (isAR ? 'ل.ل' : 'L.L.');

    if (badge) badge.textContent = lines.length;

    if (!lines.length) {
      tbody.innerHTML = `
      <tr>
        <td colspan="11" style="text-align:center;padding:36px;color:var(--text-muted)">
          <div style="font-size:2.2rem;margin-bottom:8px">📦</div>
          <div style="font-size:1rem;font-weight:700;color:var(--text-primary);margin-bottom:4px">
            ${isAR ? 'لم تتم إضافة أي صنف بعد' : 'No line items added yet'}
          </div>
          <div style="font-size:0.82rem">
            ${isAR ? 'امسح الباركود بجهاز القارئ مباشرة أو اكتب اسم الصنف في حقل البحث أعلاه' : 'Scan a product barcode or type in the search bar above to begin'}
          </div>
        </td>
      </tr>`;
      recalcTotals();
      return;
    }

    tbody.innerHTML = lines.map((l, idx) => {
      const name = isAR ? (l.name_ar || l.name_en) : (l.name_en || l.name_ar);
      const isCostChanged = l.prev_cost > 0 && Math.abs(l.price - l.prev_cost) > 0.001;

      return `
      <tr id="pur-line-row-${idx}" style="border-bottom:1px solid var(--border-color);transition:background 0.3s">
        <td style="text-align:center;font-weight:700;color:var(--text-muted);font-size:0.75rem">${idx + 1}</td>
        <td style="padding:8px 10px">
          <div style="font-weight:800;font-size:0.88rem;color:var(--text-primary)">${Utils.sanitize(name)}</div>
          <div style="display:flex;gap:6px;align-items:center;margin-top:2px">
            ${l.barcode ? `<span class="badge badge-secondary" style="font-size:0.68rem;padding:2px 6px">🏷️ ${Utils.sanitize(l.barcode)}</span>` : ''}
            ${l.item_code ? `<span style="font-size:0.7rem;color:var(--text-muted)">[${Utils.sanitize(l.item_code)}]</span>` : ''}
            <span class="badge badge-info" style="font-size:0.68rem;padding:2px 6px">📦 ${isAR ? 'المخزون: ' : 'Stock: '}${l.current_stock ?? 0}</span>
          </div>
        </td>
        <td style="text-align:center">
          <input type="text" value="${l.unit || 'pcs'}" style="width:70px;padding:4px;text-align:center;font-size:0.78rem;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px" onchange="Purchasing.updateLine(${idx},'unit',this.value)">
        </td>
        <td style="text-align:center">
          <input type="number" value="${l.qty}" min="0.001" step="any" style="width:80px;padding:5px 6px;text-align:center;font-weight:800;font-size:0.9rem;color:var(--primary);background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px" onchange="Purchasing.updateLine(${idx},'qty',this.value)">
        </td>
        <td style="text-align:center">
          <div style="display:flex;align-items:center;justify-content:center;gap:3px">
            <span style="font-size:0.75rem;font-weight:700;color:var(--text-muted)">${curSym}</span>
            <input type="number" value="${l.price}" min="0" step="any" style="width:95px;padding:5px 6px;font-weight:800;font-size:0.88rem;color:var(--success);background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;text-align:right" onchange="Purchasing.updateLine(${idx},'price',this.value)">
          </div>
          ${isCostChanged ? `<div style="font-size:0.65rem;color:var(--warning);font-weight:700;margin-top:2px">${isAR ? 'سابقاً: ' : 'Was: '}${formatDocMoney(l.prev_cost, docCur)}</div>` : ''}
          ${isForeign ? `<div style="font-size:0.68rem;color:var(--primary);font-weight:700;margin-top:2px" title="${isAR ? 'معادل العملة الأساسية للنظام' : 'Equivalent in system base currency'}">≈ ${formatDocMoney(l.price * rateToBase, baseCur)}</div>` : ''}
        </td>
        <td style="text-align:center">
          <div style="display:flex;align-items:center;justify-content:center;gap:3px">
            <span style="font-size:0.75rem;font-weight:700;color:var(--text-muted)">${curSym}</span>
            <input type="number" value="${l.selling_price || 0}" min="0" step="any" style="width:95px;padding:5px 6px;font-weight:700;font-size:0.85rem;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;text-align:right" onchange="Purchasing.updateLine(${idx},'selling_price',this.value)">
          </div>
        </td>
        <td style="text-align:center">
          <input type="number" value="${l.disc || 0}" min="0" max="100" step="any" style="width:65px;padding:4px 6px;text-align:center;font-size:0.8rem;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px" onchange="Purchasing.updateLine(${idx},'disc',this.value)">
        </td>
        <td style="text-align:center">
          <div style="display:flex;align-items:center;justify-content:center;gap:2px">
            <input type="number" value="${l.tax_pct || 0}" min="0" max="100" step="any"
              style="width:55px;padding:4px 4px;text-align:center;font-size:0.82rem;font-weight:800;color:${(l.tax_pct || 0) > 0 ? '#b45309' : 'var(--text-muted)'};background:${(l.tax_pct || 0) > 0 ? 'rgba(245,158,11,0.1)' : 'var(--input-bg)'};border:1.5px solid ${(l.tax_pct || 0) > 0 ? '#f59e0b' : 'var(--border-color)'};border-radius:6px"
              onchange="Purchasing.updateLine(${idx},'tax_pct',this.value)">
            <span style="font-size:0.72rem;font-weight:700;color:var(--text-muted)">%</span>
          </div>
          ${(l.tax_pct || 0) > 0 ? `<div style="font-size:0.65rem;color:#b45309;font-weight:800;margin-top:2px">⭐ TVA (${l.tax_pct}%)</div>` : `<div style="font-size:0.65rem;color:var(--text-muted);margin-top:2px">${isAR ? 'معفى (0%)' : 'Exempt (0%)'}</div>`}
        </td>
        <td style="text-align:center">
          <input type="date" value="${l.expiry_date || ''}" style="width:125px;padding:4px;font-size:0.75rem;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px" onchange="Purchasing.updateLine(${idx},'expiry_date',this.value)">
        </td>
        <td style="text-align:right;font-weight:900;font-size:0.95rem;color:var(--text-primary);padding-right:10px">
          <div>${formatDocMoney(l.total || 0, docCur)}</div>
          ${(l.tax_amount > 0) ? `<div style="font-size:0.68rem;color:#b45309;font-weight:700">+TVA: ${formatDocMoney(l.tax_amount, docCur)}</div>` : ''}
          ${isForeign ? `<div style="font-size:0.7rem;color:var(--primary);font-weight:600">≈ ${formatDocMoney((l.total || 0) * rateToBase, baseCur)}</div>` : ''}
        </td>
        <td style="text-align:center">
          <button type="button" class="btn-icon" onclick="Purchasing.removeLine(${idx})" style="color:var(--danger);font-size:0.85rem" title="${isAR ? 'حذف السطر' : 'Remove Line'}">✕</button>
        </td>
      </tr>`;
    }).join('');

    recalcTotals();
  }

  function flashLineRow(idx) {
    const row = document.getElementById(`pur-line-row-${idx}`);
    if (!row) return;
    row.style.background = 'rgba(34, 197, 94, 0.25)';
    setTimeout(() => {
      row.style.background = '';
    }, 650);
  }

  function showScanNotice(text) {
    const el = document.getElementById('pur-scan-notice');
    if (!el) return;
    el.textContent = text;
    el.style.display = 'block';
    clearTimeout(window._scanNoticeTimeout);
    window._scanNoticeTimeout = setTimeout(() => {
      el.style.display = 'none';
    }, 2500);
  }

  // ── Add Item To Invoice ─────────────────────────────────────
  function addItemToInvoice(item, requestedQty = 1) {
    if (!item) return;
    const isAR = i18n.getLang() === 'ar';
    window._purDocItems = window._purDocItems || [];
    const docCur = window._purDocCurrency || 'USD';
    const dec = (docCur === 'LBP') ? 0 : 2;
    const baseToDoc = getBaseToDocMultiplier();

    // If item already in invoice, increment its quantity
    const existingIndex = window._purDocItems.findIndex(l => l.item_id === item.id);
    if (existingIndex !== -1) {
      const line = window._purDocItems[existingIndex];
      line.qty = Utils.round((parseFloat(line.qty) || 0) + requestedQty, 3);
      const netSub = line.qty * line.price * (1 - (line.disc || 0) / 100);
      const lineTax = netSub * ((line.tax_pct || 0) / 100);
      line.net_total = Utils.round(netSub, dec);
      line.tax_amount = Utils.round(lineTax, dec);
      line.total = Utils.round(netSub + lineTax, dec);
      playAudioTone('beep');
      renderDocLines();
      flashLineRow(existingIndex);
      showScanNotice(`✓ ${isAR ? 'تمت زيادة كمية' : 'Increased qty for'}: ${isAR ? (line.name_ar || line.name_en) : (line.name_en || line.name_ar)} (${line.qty})`);
      return;
    }

    // New item row: convert catalog base prices to invoice currency
    const baseCost = parseFloat(item.cost_price) || 0;
    const baseSell = parseFloat(item.selling_price || item.price) || 0;
    const cost = Utils.round(baseCost * baseToDoc, dec);
    const sell = Utils.round(baseSell * baseToDoc, dec);

    // Auto-detect if item is defined with TVA
    const isTaxable = isItemTaxable(item);
    const taxRate = isTaxable ? (parseFloat(item.vat_rate) || parseFloat(item.tax_rate) || window._purVatRate || 11) : 0;
    const netSub = requestedQty * cost;
    const lineTax = netSub * (taxRate / 100);

    const newLine = {
      item_id: item.id,
      item_code: item.item_code || item.code || '',
      barcode: item.barcode || '',
      name_en: item.name_en || item.name || '',
      name_ar: item.name_ar || item.name || '',
      unit: item.unit || item.selling_unit || 'pcs',
      qty: requestedQty,
      price: cost,
      prev_cost: cost,
      selling_price: sell,
      current_stock: parseFloat(item.stock_qty) || 0,
      disc: 0,
      tax_pct: taxRate,
      is_taxable: isTaxable,
      expiry_date: item.expiry_date || '',
      batch_no: '',
      net_total: Utils.round(netSub, dec),
      tax_amount: Utils.round(lineTax, dec),
      total: Utils.round(netSub + lineTax, dec)
    };

    window._purDocItems.unshift(newLine); // Add to top of list
    playAudioTone('beep');
    renderDocLines();
    flashLineRow(0);
    showScanNotice(`✓ ${isAR ? 'تمت إضافة' : 'Added'}: ${isAR ? (newLine.name_ar || newLine.name_en) : (newLine.name_en || newLine.name_ar)}`);
  }

  // ── Hardware Barcode Scanner & Search Handler ──────────────
  async function handleBarcodeScan(rawQuery) {
    if (!rawQuery) return false;
    const q = rawQuery.trim().toLowerCase();
    if (!q) return false;

    // Deduplication check: prevent scanning the same barcode twice in < 350ms
    const now = Date.now();
    if (_lastScanCode === q && (now - _lastScanTime) < 350) {
      return false;
    }
    _lastScanCode = q;
    _lastScanTime = now;

    if (!window._purItems || !window._purItems.length) {
      window._purItems = await DB.getAll('items');
    }
    const items = window._purItems;
    const isAR = i18n.getLang() === 'ar';

    // 1. Exact match by barcode, code, or item_code
    let match = items.find(i =>
      (i.barcode && String(i.barcode).trim().toLowerCase() === q) ||
      (i.code && String(i.code).trim().toLowerCase() === q) ||
      (i.item_code && String(i.item_code).trim().toLowerCase() === q)
    );

    if (match) {
      addItemToInvoice(match, 1);
      clearAndRefocusSearch();
      return true;
    }

    // 2. If dropdown is open and an item is actively highlighted with arrow keys
    const resultsContainer = document.getElementById('pur-search-results');
    if (resultsContainer && resultsContainer.style.display !== 'none' && _activeDropdownIndex >= 0) {
      const activeCard = resultsContainer.querySelectorAll('.pur-search-item')[_activeDropdownIndex];
      if (activeCard) {
        const itemId = parseInt(activeCard.dataset.itemId, 10);
        const selectedItem = items.find(i => i.id === itemId);
        if (selectedItem) {
          addItemToInvoice(selectedItem, 1);
          clearAndRefocusSearch();
          return true;
        }
      }
    }

    // 3. If there is exactly 1 match in search results
    const matches = items.filter(i =>
      (i.barcode && String(i.barcode).toLowerCase().includes(q)) ||
      (i.item_code && String(i.item_code).toLowerCase().includes(q)) ||
      (i.name_en && i.name_en.toLowerCase().includes(q)) ||
      (i.name_ar && i.name_ar.toLowerCase().includes(q))
    );

    if (matches.length === 1) {
      addItemToInvoice(matches[0], 1);
      clearAndRefocusSearch();
      return true;
    }

    if (matches.length > 1) {
      // Keep dropdown open for user selection
      showSearchResults(matches);
      return false;
    }

    // 4. Not found
    playAudioTone('error');
    Utils.toast(isAR ? `الصنف [${rawQuery}] غير موجود. اضغط "صنف جديد" لإضافته.` : `Item [${rawQuery}] not found. Click "New Product" to register it.`, 'warning');
    return false;
  }

  function clearAndRefocusSearch() {
    const input = document.getElementById('pur-search-barcode');
    if (input) {
      input.value = '';
      input.focus();
    }
    const resultsContainer = document.getElementById('pur-search-results');
    if (resultsContainer) resultsContainer.style.display = 'none';
    _activeDropdownIndex = -1;
  }

  // ── Live Autocomplete Search ────────────────────────────────
  function onSearchInput(val) {
    const q = (val || '').trim().toLowerCase();
    const resultsContainer = document.getElementById('pur-search-results');
    if (!resultsContainer) return;

    if (!q) {
      resultsContainer.style.display = 'none';
      _activeDropdownIndex = -1;
      return;
    }

    const items = window._purItems || [];
    const matches = items.filter(i =>
      (i.barcode && String(i.barcode).toLowerCase().includes(q)) ||
      (i.item_code && String(i.item_code).toLowerCase().includes(q)) ||
      (i.code && String(i.code).toLowerCase().includes(q)) ||
      (i.name_en && i.name_en.toLowerCase().includes(q)) ||
      (i.name_ar && i.name_ar.toLowerCase().includes(q))
    ).slice(0, 12);

    showSearchResults(matches);
  }

  function showSearchResults(matches) {
    const isAR = i18n.getLang() === 'ar';
    const resultsContainer = document.getElementById('pur-search-results');
    if (!resultsContainer) return;

    if (!matches.length) {
      resultsContainer.innerHTML = `
        <div style="padding:14px;text-align:center;color:var(--text-muted);font-size:0.85rem">
          ${isAR ? 'لا توجد أصناف مطابقة. اضغط "صنف جديد" لإضافته فوراً.' : 'No matching items. Click "New Product" to add it on the spot.'}
        </div>`;
      resultsContainer.style.display = 'block';
      _activeDropdownIndex = -1;
      return;
    }

    _activeDropdownIndex = 0; // Default highlight first result
    const baseToDoc = getBaseToDocMultiplier();
    const docCur = window._purDocCurrency || 'USD';
    const baseCur = window._purBaseCurrency || 'USD';
    const isForeign = (docCur !== baseCur);

    resultsContainer.innerHTML = matches.map((item, idx) => {
      const name = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
      const cost = parseFloat(item.cost_price) || 0;
      const sell = parseFloat(item.selling_price || item.price) || 0;
      const stock = parseFloat(item.stock_qty) || 0;

      return `
      <div class="pur-search-item ${idx === 0 ? 'active' : ''}" data-item-id="${item.id}" onclick="Purchasing.selectItemFromSearch(${item.id})"
        style="padding:10px 14px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);cursor:pointer;background:${idx === 0 ? 'var(--surface-2)' : 'transparent'};transition:background 0.15s">
        <div>
          <div style="font-weight:800;font-size:0.9rem;color:var(--text-primary)">${Utils.sanitize(name)}</div>
          <div style="display:flex;gap:8px;align-items:center;margin-top:2px;font-size:0.75rem">
            ${item.barcode ? `<span class="badge badge-secondary" style="padding:2px 5px">🏷️ ${Utils.sanitize(item.barcode)}</span>` : ''}
            ${item.item_code ? `<span style="color:var(--text-muted)">[${Utils.sanitize(item.item_code)}]</span>` : ''}
            <span style="color:var(--text-muted)">${isAR ? 'المخزون:' : 'Stock:'} <strong>${stock}</strong></span>
          </div>
        </div>
        <div style="text-align:right">
          <div style="font-weight:800;color:var(--success);font-size:0.85rem">
            ${isAR ? 'التكلفة: ' : 'Cost: '}${formatDocMoney(cost * baseToDoc, docCur)}
            ${isForeign ? `<span style="font-size:0.7rem;color:var(--text-muted);display:block">≈ ${formatDocMoney(cost, baseCur)}</span>` : ''}
          </div>
          <div style="font-size:0.72rem;color:var(--text-muted)">
            ${isAR ? 'البيع: ' : 'Sell: '}${formatDocMoney(sell * baseToDoc, docCur)}
          </div>
        </div>
      </div>`;
    }).join('');

    resultsContainer.style.display = 'block';
  }

  function onSearchKeyDown(e) {
    const resultsContainer = document.getElementById('pur-search-results');
    const isVisible = resultsContainer && resultsContainer.style.display !== 'none';

    if (e.key === 'ArrowDown') {
      if (!isVisible) return;
      e.preventDefault();
      const items = resultsContainer.querySelectorAll('.pur-search-item');
      if (!items.length) return;
      _activeDropdownIndex = Math.min(_activeDropdownIndex + 1, items.length - 1);
      updateDropdownSelection(items);
    } else if (e.key === 'ArrowUp') {
      if (!isVisible) return;
      e.preventDefault();
      const items = resultsContainer.querySelectorAll('.pur-search-item');
      if (!items.length) return;
      _activeDropdownIndex = Math.max(_activeDropdownIndex - 1, 0);
      updateDropdownSelection(items);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const input = document.getElementById('pur-search-barcode');
      handleBarcodeScan(input?.value || '');
    } else if (e.key === 'Escape') {
      if (resultsContainer) resultsContainer.style.display = 'none';
      _activeDropdownIndex = -1;
    }
  }

  function updateDropdownSelection(items) {
    items.forEach((it, idx) => {
      if (idx === _activeDropdownIndex) {
        it.classList.add('active');
        it.style.background = 'var(--surface-2)';
        it.scrollIntoView({ block: 'nearest' });
      } else {
        it.classList.remove('active');
        it.style.background = 'transparent';
      }
    });
  }

  function selectItemFromSearch(itemId) {
    const item = (window._purItems || []).find(i => i.id === itemId);
    if (!item) return;
    addItemToInvoice(item, 1);
    clearAndRefocusSearch();
  }

  // ── Quick Product Modal ─────────────────────────────────────
  async function openQuickNewItemModal() {
    const isAR = i18n.getLang() === 'ar';
    const categories = (await DB.getAll('categories')) || [];
    const searchVal = document.getElementById('pur-search-barcode')?.value.trim() || '';
    const docCur = window._purDocCurrency || 'USD';
    const curSym = docCur === 'USD' ? '$' : (isAR ? 'ل.ل' : 'L.L.');

    const modalHtml = `
    <div class="modal-overlay open" id="pur-quick-item-modal" style="z-index:999999">
      <div class="modal" style="max-width:540px;border-radius:18px">
        <div class="modal-header" style="background:var(--surface);border-bottom:1px solid var(--border-color);padding:14px 18px">
          <div class="modal-title" style="font-weight:800;font-size:1.1rem">
            ➕ ${isAR ? 'إضافة صنف جديد فوراً' : 'Quick Register New Product'}
          </div>
          <button class="btn-icon" onclick="document.getElementById('pur-quick-item-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px">
          <div class="grid grid-2" style="gap:12px;margin-bottom:12px">
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label" style="font-weight:700">${isAR ? 'اسم الصنف (بالعربية أو الإنجليزية)' : 'Product Name'} *</label>
              <input type="text" class="form-control" id="qitem-name" placeholder="e.g. Milk 1L / حليب 1 لتر" style="font-weight:700">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'الباركود' : 'Barcode'}</label>
              <input type="text" class="form-control" id="qitem-barcode" value="${Utils.sanitize(searchVal)}" placeholder="e.g. 628100123" style="font-weight:700">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'القسم / التصنيف' : 'Category'}</label>
              <select class="form-control" id="qitem-category">
                ${categories.map(c => `<option value="${c.id}">${isAR ? (c.name_ar || c.name) : (c.name || c.name_ar)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? `سعر الشراء / التكلفة (${curSym})` : `Cost Price (${curSym})`} *</label>
              <input type="number" step="any" min="0" class="form-control" id="qitem-cost" value="0" style="font-weight:800;color:var(--success)" oninput="Purchasing.recalcQuickItemPrice('cost')">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700;color:var(--primary)">📈 ${isAR ? 'نسبة الربح %' : 'Profit %'}</label>
              <input type="number" step="any" min="0" class="form-control" id="qitem-profit-pct" placeholder="مثال: 25%" style="font-weight:800;color:var(--primary);background:rgba(37,99,235,0.04)" oninput="Purchasing.recalcQuickItemPrice('profit')">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? `سعر البيع (${curSym})` : `Selling Price (${curSym})`} *</label>
              <input type="number" step="any" min="0" class="form-control" id="qitem-price" value="0" style="font-weight:800;color:var(--primary)" oninput="Purchasing.recalcQuickItemPrice('price')">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'الوحدة' : 'Unit'}</label>
              <select class="form-control" id="qitem-unit">
                <option value="pcs">${isAR ? 'قطعة (Piece)' : 'Piece (pcs)'}</option>
                <option value="box">${isAR ? 'كرتونة / صندوق (Box)' : 'Box'}</option>
                <option value="kg">${isAR ? 'كيلوغرام (Kg)' : 'Kg'}</option>
                <option value="liter">${isAR ? 'لتر (Liter)' : 'Liter'}</option>
                <option value="pack">${isAR ? 'علبة / باقة (Pack)' : 'Pack'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'الكمية بالفاتورة' : 'Invoice Quantity'}</label>
              <input type="number" step="any" min="0.001" class="form-control" id="qitem-qty" value="1" style="font-weight:800">
            </div>
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label" style="font-weight:700">${isAR ? 'الضريبة على القيمة المضافة (TVA)' : 'TVA Tax Status'}</label>
              <select class="form-control" id="qitem-vat-status" style="font-weight:700">
                <option value="standard">${isAR ? '⭐ خاضع لـ TVA (11%)' : '⭐ TVA Taxable (11%)'}</option>
                <option value="exempt">${isAR ? 'معفى من الضريبة (0%)' : 'Tax-Exempt (0%)'}</option>
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="background:var(--surface);border-top:1px solid var(--border-color);padding:12px 18px">
          <button class="btn btn-ghost" onclick="document.getElementById('pur-quick-item-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Purchasing.saveQuickNewItem()" style="font-weight:800">
            ✓ ${isAR ? 'حفظ وإدراج بالفاتورة' : 'Save & Add to Invoice'}
          </button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    setTimeout(() => {
      document.getElementById('qitem-name')?.focus();
    }, 100);
  }

  async function saveQuickNewItem() {
    const isAR = i18n.getLang() === 'ar';
    const name = document.getElementById('qitem-name')?.value.trim();
    if (!name) {
      Utils.toast(isAR ? 'يرجى إدخال اسم الصنف' : 'Please enter product name', 'warning');
      return;
    }

    const barcode = document.getElementById('qitem-barcode')?.value.trim();
    const catId   = parseInt(document.getElementById('qitem-category')?.value, 10) || 1;
    const cost    = parseFloat(document.getElementById('qitem-cost')?.value) || 0;
    const price   = parseFloat(document.getElementById('qitem-price')?.value) || 0;
    const unit    = document.getElementById('qitem-unit')?.value || 'pcs';
    const qty     = parseFloat(document.getElementById('qitem-qty')?.value) || 1;
    const profitPct = parseFloat(document.getElementById('qitem-profit-pct')?.value) || 0;
    const vatStatus = document.getElementById('qitem-vat-status')?.value || 'standard';
    const isTaxable = (vatStatus === 'standard');
    const vatRate   = isTaxable ? (window._purVatRate || 11) : 0;

    const rateToBase = getDocRateToBase();
    const baseCur = window._purBaseCurrency || 'USD';
    const isLbpBase = (Utils.isLbp && Utils.isLbp(baseCur)) || baseCur === 'LBP' || baseCur === 'LL';
    const baseCost = Utils.round(cost * rateToBase, (isLbpBase ? 0 : 4));
    const basePrice = Utils.round(price * rateToBase, (isLbpBase ? 0 : 2));

    const newItem = {
      name_en: name,
      name_ar: name,
      item_code: await DB.nextSeq('items', 'ITM-', 4),
      barcode: barcode,
      category_id: catId,
      unit: unit,
      selling_unit: unit,
      cost_price: baseCost,
      profit_pct: profitPct,
      selling_price: basePrice,
      price: basePrice,
      vat_type: vatStatus,
      vat_rate: vatRate,
      is_taxable: isTaxable,
      stock_qty: 0,
      warehouse_stocks: { 1: 0 },
      status: 'active',
      created_at: new Date().toISOString()
    };

    const newId = await DB.add('items', newItem);
    newItem.id = newId;

    // Add to cache
    window._purItems = window._purItems || [];
    window._purItems.push(newItem);

    // Remove modal
    document.getElementById('pur-quick-item-modal')?.remove();

    // Insert into active invoice lines
    addItemToInvoice(newItem, qty);
    clearAndRefocusSearch();
    Utils.toast(isAR ? 'تم إنشاء الصنف وإضافته للفاتورة' : 'Item registered & added to invoice', 'success');
  }

  // ── Quick Supplier Modal ────────────────────────────────────
  async function openQuickSupplierModal() {
    const isAR = i18n.getLang() === 'ar';
    const modalHtml = `
    <div class="modal-overlay open" id="pur-quick-supp-modal" style="z-index:999999">
      <div class="modal" style="max-width:480px;border-radius:18px">
        <div class="modal-header" style="background:var(--surface);border-bottom:1px solid var(--border-color);padding:14px 18px">
          <div class="modal-title" style="font-weight:800;font-size:1.1rem">
            ➕ ${isAR ? 'إضافة مورد جديد' : 'Add New Supplier'}
          </div>
          <button class="btn-icon" onclick="document.getElementById('pur-quick-supp-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px">
          <div class="form-group mb-2">
            <label class="form-label" style="font-weight:700">${isAR ? 'اسم المورد / الشركة' : 'Supplier / Company Name'} *</label>
            <input type="text" class="form-control" id="qsupp-name" placeholder="e.g. Al-Nour Trading" required style="font-weight:700">
          </div>
          <div class="grid grid-2" style="gap:10px;margin-bottom:10px">
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'رقم الهاتف' : 'Phone'}</label>
              <input type="text" class="form-control" id="qsupp-phone" placeholder="03-XXXXXX">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'الرقم الضريبي' : 'Tax / VAT #'}</label>
              <input type="text" class="form-control" id="qsupp-tax" placeholder="Tax ID">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label" style="font-weight:700">${isAR ? 'العنوان' : 'Address'}</label>
            <input type="text" class="form-control" id="qsupp-addr" placeholder="Beirut, Lebanon">
          </div>
          <div class="form-group" style="margin-top:10px">
            <label class="form-label" style="font-weight:700">${isAR ? 'الرصيد الافتتاحي / مستحق وقرض سابق (إن وجد)' : 'Opening Balance / Old Loan (Payable if migrating)'}</label>
            <input type="number" step="0.01" class="form-control" id="qsupp-opbal" value="0.00" placeholder="0.00" style="font-weight:700">
          </div>
        </div>
        <div class="modal-footer" style="background:var(--surface);border-top:1px solid var(--border-color);padding:12px 18px">
          <button class="btn btn-ghost" onclick="document.getElementById('pur-quick-supp-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Purchasing.saveQuickSupplier()" style="font-weight:800">
            💾 ${isAR ? 'حفظ المورد' : 'Save Supplier'}
          </button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    setTimeout(() => {
      document.getElementById('qsupp-name')?.focus();
    }, 100);
  }

  async function saveQuickSupplier() {
    const isAR = i18n.getLang() === 'ar';
    const name = document.getElementById('qsupp-name')?.value.trim();
    if (!name) {
      Utils.toast(isAR ? 'يرجى إدخال اسم المورد' : 'Please enter supplier name', 'warning');
      return;
    }

    const opBal = parseFloat(document.getElementById('qsupp-opbal')?.value) || 0;
    const newSup = {
      name_en: name,
      name_ar: name,
      phone: document.getElementById('qsupp-phone')?.value.trim() || '',
      tax_number: document.getElementById('qsupp-tax')?.value.trim() || '',
      address: document.getElementById('qsupp-addr')?.value.trim() || '',
      opening_balance: opBal,
      balance: opBal,
      created_at: new Date().toISOString()
    };

    const newId = await DB.add('suppliers', newSup);
    newSup.id = newId;

    window._purSuppliers = window._purSuppliers || [];
    window._purSuppliers.push(newSup);

    // Update supplier dropdown
    const sel = document.getElementById('pur-doc-supplier');
    if (sel) {
      const opt = document.createElement('option');
      opt.value = newId;
      opt.textContent = name;
      opt.selected = true;
      sel.appendChild(opt);
      onSupplierChange(newId);
    }

    document.getElementById('pur-quick-supp-modal')?.remove();
    Utils.toast(isAR ? 'تم حفظ المورد واختياره' : 'Supplier saved & selected', 'success');
  }

  // ── Line Items Updates ──────────────────────────────────────
  function removeLine(idx) {
    window._purDocItems.splice(idx, 1);
    renderDocLines();
  }

  function updateLine(idx, field, val) {
    const line = window._purDocItems[idx];
    if (!line) return;
    const docCur = window._purDocCurrency || 'USD';
    const dec = (docCur === 'LBP') ? 0 : 2;
    const baseCur = window._purBaseCurrency || 'USD';
    const rateToBase = getDocRateToBase();
    const isForeign = (docCur !== baseCur);

    if (field === 'unit' || field === 'expiry_date') {
      line[field] = val;
    } else {
      line[field] = parseFloat(val) || 0;
    }

    const netSub = (line.qty || 0) * (line.price || 0) * (1 - (line.disc || 0) / 100);
    const lineTax = netSub * ((line.tax_pct || 0) / 100);
    line.net_total = Utils.round(netSub, dec);
    line.tax_amount = Utils.round(lineTax, dec);
    line.total = Utils.round(netSub + lineTax, dec);

    // Update cell total
    const row = document.getElementById(`pur-line-row-${idx}`);
    if (row) {
      const totalCell = row.querySelectorAll('td')[9];
      if (totalCell) {
        totalCell.innerHTML = `
          <div>${formatDocMoney(line.total, docCur)}</div>
          ${(line.tax_amount > 0) ? `<div style="font-size:0.68rem;color:#b45309;font-weight:700">+TVA: ${formatDocMoney(line.tax_amount, docCur)}</div>` : ''}
          ${isForeign ? `<div style="font-size:0.7rem;color:var(--primary);font-weight:600">≈ ${formatDocMoney(line.total * rateToBase, baseCur)}</div>` : ''}
        `;
      }
    }

    recalcTotals();
  }

  // ── Totals Calculation (Net Subtotal, TVA Alone, Total Amount) ──
  function recalcTotals() {
    const lines = window._purDocItems || [];
    const docCur = window._purDocCurrency || 'USD';
    const baseCur = window._purBaseCurrency || 'USD';
    const rateToBase = getDocRateToBase();
    const isForeign = (docCur !== baseCur);
    const dec = (Utils.isLbp ? Utils.isLbp(docCur) : docCur === 'LBP') ? 0 : 2;
    const baseDec = (Utils.isLbp ? Utils.isLbp(baseCur) : baseCur === 'LBP') ? 0 : 2;

    // 1. Total Net Subtotal (المجموع الصافي قبل الخصم والضريبة)
    const netSubtotal = lines.reduce((s, l) => {
      const lineNet = (parseFloat(l.qty) || 0) * (parseFloat(l.price) || 0) * (1 - (parseFloat(l.disc) || 0) / 100);
      return s + lineNet;
    }, 0);
    const roundedNetSubtotal = Utils.round(netSubtotal, dec);

    const totalUnits = lines.reduce((s, l) => s + (parseFloat(l.qty) || 0), 0);

    // 2. Invoice Discount
    const isAR = i18n.getLang() === 'ar';
    const discVal  = parseFloat(document.getElementById('pur-disc-val')?.value) || 0;
    const discType = document.getElementById('pur-disc-type')?.value || 'amount';
    const discount = discType === 'pct' ? Utils.round(roundedNetSubtotal * discVal / 100, dec) : Math.min(roundedNetSubtotal, discVal);

    // 3. Net After Discount
    const netAfterDiscount = Math.max(0, roundedNetSubtotal - discount);
    const discountRatio = roundedNetSubtotal > 0 ? (netAfterDiscount / roundedNetSubtotal) : 1;

    // 4. Calculate TVA Amount ALONE strictly for items with TVA defined
    let totalTaxAmount = 0;
    lines.forEach(l => {
      const taxRate = parseFloat(l.tax_pct) || 0;
      if (taxRate > 0) {
        const lineNet = (parseFloat(l.qty) || 0) * (parseFloat(l.price) || 0) * (1 - (parseFloat(l.disc) || 0) / 100);
        const lineTax = (lineNet * discountRatio) * (taxRate / 100);
        totalTaxAmount += lineTax;
      }
    });
    const roundedTaxAmount = Utils.round(totalTaxAmount, dec);

    // 5. Freight / Shipping
    const shipping = parseFloat(document.getElementById('pur-shipping')?.value) || 0;

    // 6. Net Grand Total (الصافي النهائي الشامل للضريبة والشحن)
    const grandTotal = Utils.round(netAfterDiscount + roundedTaxAmount + shipping, dec);

    // 7. Payment breakdown
    const paidInput = document.getElementById('pur-doc-paid');
    let paidAmount = parseFloat(paidInput?.value) || 0;
    const dueAmount  = Utils.round(Math.max(0, grandTotal - paidAmount), dec);

    // Converted base equivalents
    const baseGrandTotal = Utils.round(grandTotal * rateToBase, baseDec);
    const baseSubtotal   = Utils.round(roundedNetSubtotal * rateToBase, baseDec);
    const baseTaxAmount  = Utils.round(roundedTaxAmount * rateToBase, baseDec);
    const basePaidAmount = Utils.round(paidAmount * rateToBase, baseDec);
    const baseDueAmount  = Utils.round(dueAmount * rateToBase, baseDec);

    Utils.setHTML('#pur-total-qty', `${lines.length} ${isAR ? 'أصناف' : 'items'} (${Utils.round(totalUnits, 2)} ${isAR ? 'وحدة' : 'units'})`);
    Utils.setHTML('#pur-subtotal', formatDocMoney(roundedNetSubtotal, docCur));
    Utils.setHTML('#pur-tax-amount', formatDocMoney(roundedTaxAmount, docCur));
    Utils.setHTML('#pur-grand-total', formatDocMoney(grandTotal, docCur));

    const baseEl = document.getElementById('pur-grand-total-base');
    if (baseEl) {
      if (isForeign) {
        baseEl.innerHTML = `≈ ${formatDocMoney(baseGrandTotal, baseCur)} <span style="font-size:0.72rem;opacity:0.85">(${isAR ? 'معادل عملة النظام' : 'Base Eq.'})</span>`;
        baseEl.style.display = 'block';
      } else {
        baseEl.style.display = 'none';
      }
    }

    const dueInput = document.getElementById('pur-doc-due');
    if (dueInput) {
      dueInput.value = formatDocMoney(dueAmount, docCur);
    }

    const dueHint = document.getElementById('pur-doc-due-hint');
    if (dueHint) {
      if (isForeign && dueAmount > 0) {
        dueHint.textContent = `(≈ ${formatDocMoney(baseDueAmount, baseCur)})`;
        dueHint.style.display = 'block';
      } else {
        dueHint.style.display = 'none';
      }
    }

    // Live update button highlights (Cash vs Debit)
    updatePaymentHighlight(paidAmount, grandTotal);

    window._purGrandTotal     = grandTotal;
    window._purSubtotal       = roundedNetSubtotal;
    window._purTaxAmount      = roundedTaxAmount;
    window._purDiscount       = discount;
    window._purTotalQty       = totalUnits;
    window._purBaseGrandTotal = baseGrandTotal;
    window._purBaseSubtotal   = baseSubtotal;
    window._purBaseTaxAmount  = baseTaxAmount;
    window._purBasePaidAmount = basePaidAmount;
    window._purBaseDueAmount  = baseDueAmount;
  }

  // ── Save Document & Synchronize Stock/Cost ──────────────────
  async function saveDoc(store) {
    const isAR = i18n.getLang() === 'ar';
    const supplier_id = parseInt(document.getElementById('pur-doc-supplier')?.value, 10) || null;
    const supplier_invoice_no = document.getElementById('pur-doc-supp-inv')?.value.trim() || '';
    const ref = document.getElementById('pur-doc-ref')?.value.trim() || await DB.nextSeq(store, window._purDocPrefix || 'DOC-', 5);
    const lines = window._purDocItems || [];
    const warehouse_id = parseInt(document.getElementById('pur-doc-warehouse')?.value, 10) || 1;
    const payment_method = document.getElementById('pur-doc-payment-method')?.value || 'cash';
    const status = document.getElementById('pur-doc-status')?.value || 'received';
    const notes = document.getElementById('pur-doc-notes')?.value.trim() || '';

    if (!lines.length) {
      Utils.toast(isAR ? 'يرجى إضافة صنف واحد على الأقل إلى الفاتورة' : 'Please add at least one line item to invoice', 'warning');
      return;
    }

    const paidInput = document.getElementById('pur-doc-paid');
    const grandTotal = window._purGrandTotal || 0;
    const docCur = window._purDocCurrency || 'USD';
    const baseCur = window._purBaseCurrency || 'USD';
    const docExchRate = parseFloat(window._purDocExchRate) || (window._purSystemExchRate || 89500);
    const rateToBase = getDocRateToBase();
    const dec = (Utils.isLbp ? Utils.isLbp(docCur) : docCur === 'LBP') ? 0 : 2;
    const baseDec = (Utils.isLbp ? Utils.isLbp(baseCur) : baseCur === 'LBP') ? 0 : 2;

    let paidAmount = parseFloat(paidInput?.value) || 0;
    if (payment_method === 'cash' && !paidAmount && paidInput?.value === '') {
      paidAmount = grandTotal;
    }
    const dueAmount = Utils.round(Math.max(0, grandTotal - paidAmount), dec);

    const baseGrandTotal = window._purBaseGrandTotal !== undefined ? window._purBaseGrandTotal : Utils.round(grandTotal * rateToBase, baseDec);
    const baseSubtotal   = window._purBaseSubtotal !== undefined ? window._purBaseSubtotal : Utils.round((window._purSubtotal || 0) * rateToBase, baseDec);
    const baseTaxAmount  = window._purBaseTaxAmount !== undefined ? window._purBaseTaxAmount : Utils.round((window._purTaxAmount || 0) * rateToBase, baseDec);
    const basePaidAmount = Utils.round(paidAmount * rateToBase, baseDec);
    const baseDueAmount  = Utils.round(dueAmount * rateToBase, baseDec);

    const updateStock = document.getElementById('pur-toggle-stock')?.checked !== false;
    const updateCost  = document.getElementById('pur-toggle-cost')?.checked !== false;

    const data = {
      ref,
      supplier_invoice_no,
      supplier_id,
      warehouse_id,
      currency: docCur,
      base_currency: baseCur,
      exchange_rate: docExchRate,
      rate_to_base: rateToBase,
      doc_date: document.getElementById('pur-doc-date')?.value || Utils.today(),
      doc_time: document.getElementById('pur-doc-time')?.value || '',
      payment_method,
      status,
      notes,
      items_json: JSON.stringify(lines),
      items_count: lines.length,
      total_qty: window._purTotalQty || lines.reduce((s, l) => s + (l.qty || 0), 0),
      subtotal: window._purSubtotal || 0,
      tax_amount: window._purTaxAmount || 0,
      discount: window._purDiscount || 0,
      discount_type: document.getElementById('pur-disc-type')?.value || 'amount',
      shipping_cost: parseFloat(document.getElementById('pur-shipping')?.value) || 0,
      grand_total: grandTotal,
      paid_amount: paidAmount,
      due_amount: dueAmount,
      base_grand_total: baseGrandTotal,
      base_subtotal: baseSubtotal,
      base_tax_amount: baseTaxAmount,
      base_paid_amount: basePaidAmount,
      base_due_amount: baseDueAmount,
      update_stock: updateStock,
      update_cost: updateCost,
      updated_at: new Date().toISOString()
    };

    try {
      let docId = window._purDocId;
      if (docId) {
        await DB.update(store, { ...data, id: docId });
      } else {
        data.created_at = new Date().toISOString();
        docId = await DB.add(store, data);
      }

      // ── Inventory Stock & Cost Synchronization (With Safe Delta Tracking) ──
      if (updateStock && (store === 'purchase_invoices' || store === 'goods_receipts')) {
        const origItems = window._purOriginalItems || [];
        const origMap = {};
        origItems.forEach(o => { origMap[o.item_id] = (parseFloat(o.qty) || 0); });

        // 1. Process line items on this invoice (apply difference / delta)
        for (const l of lines) {
          const item = await DB.get('items', l.item_id);
          if (item) {
            const whKey = String(warehouse_id);
            if (!item.warehouse_stocks) item.warehouse_stocks = {};

            const oldQty = window._purDocId ? (origMap[l.item_id] || 0) : 0;
            const deltaQty = l.qty - oldQty;

            if (deltaQty !== 0) {
              item.warehouse_stocks[whKey] = (parseFloat(item.warehouse_stocks[whKey]) || 0) + deltaQty;
              item.stock_qty = (parseFloat(item.stock_qty) || 0) + deltaQty;

              // Audit record in stock_movements
              await DB.add('stock_movements', {
                item_id: l.item_id,
                type: window._purDocId ? 'purchase_edit' : 'purchase',
                ref,
                qty: deltaQty,
                warehouse_id,
                supplier_id,
                notes: window._purDocId ? 
                  `Invoice ${ref} Edit (Previous: ${oldQty}, Updated: ${l.qty}, Diff: ${deltaQty > 0 ? '+' : ''}${deltaQty})` :
                  `Purchase Invoice ${ref}${supplier_invoice_no ? ` (Bill: ${supplier_invoice_no})` : ''}`,
                created_at: new Date().toISOString()
              });
            }

            // Auto-update Cost and Selling price in item master if toggled (Always stored in base currency!)
            if (updateCost && l.price > 0) {
              const isLbpBase = (Utils.isLbp && Utils.isLbp(baseCur)) || baseCur === 'LBP' || baseCur === 'LL';
              item.cost_price = Utils.round(l.price * rateToBase, (isLbpBase ? 0 : 4));
              if (l.selling_price > 0) {
                const convertedSell = Utils.round(l.selling_price * rateToBase, (isLbpBase ? 0 : 2));
                item.selling_price = convertedSell;
                item.price = convertedSell;
              }
            }

            if (l.expiry_date) {
              item.expiry_date = l.expiry_date;
            }

            // Box Link Logic
            if (item.selling_unit === 'box' && item.linked_item_id && item.pieces_per_box > 1 && deltaQty !== 0) {
              const linked = await DB.get('items', item.linked_item_id);
              if (linked) {
                const linkedDelta = deltaQty * item.pieces_per_box;
                if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
                linked.warehouse_stocks[whKey] = (parseFloat(linked.warehouse_stocks[whKey]) || 0) + linkedDelta;
                linked.stock_qty = (parseFloat(linked.stock_qty) || 0) + linkedDelta;
                await DB.update('items', linked);
              }
            }

            await DB.update('items', item);
          }
        }

        // 2. Process removed lines (deduct old qty)
        if (window._purDocId && origItems.length > 0) {
          const newLineItemIds = new Set(lines.map(l => l.item_id));
          for (const orig of origItems) {
            if (!newLineItemIds.has(orig.item_id)) {
              const item = await DB.get('items', orig.item_id);
              if (item) {
                const whKey = String(warehouse_id);
                if (!item.warehouse_stocks) item.warehouse_stocks = {};
                const removeQty = parseFloat(orig.qty) || 0;
                item.warehouse_stocks[whKey] = (parseFloat(item.warehouse_stocks[whKey]) || 0) - removeQty;
                item.stock_qty = (parseFloat(item.stock_qty) || 0) - removeQty;
                await DB.update('items', item);

                await DB.add('stock_movements', {
                  item_id: orig.item_id,
                  type: 'purchase_edit',
                  ref,
                  qty: -removeQty,
                  warehouse_id,
                  supplier_id,
                  notes: `Invoice ${ref} Edit: Item removed from invoice, deducted -${removeQty}`,
                  created_at: new Date().toISOString()
                });
              }
            }
          }
        }
      } else if (updateStock && store === 'purchase_returns') {
        // Deduct returned stock
        for (const l of lines) {
          const item = await DB.get('items', l.item_id);
          if (item) {
            const whKey = String(warehouse_id);
            if (!item.warehouse_stocks) item.warehouse_stocks = {};
            item.warehouse_stocks[whKey] = Math.max(0, (parseFloat(item.warehouse_stocks[whKey]) || 0) - l.qty);
            item.stock_qty = Math.max(0, (parseFloat(item.stock_qty) || 0) - l.qty);
            await DB.update('items', item);

            await DB.add('stock_movements', {
              item_id: l.item_id,
              type: 'purchase_return',
              ref,
              qty: -l.qty,
              warehouse_id,
              supplier_id,
              notes: `Purchase Return ${ref}`,
              created_at: new Date().toISOString()
            });
          }
        }
      }

      // ── Cashbox / Bank / Supplier Financial Record ───────────────
      if (paidAmount > 0) {
        try {
          if (payment_method === 'cash') {
            await DB.add('cash_transactions', {
              type: 'expense',
              category: 'purchases',
              amount: basePaidAmount,
              original_amount: paidAmount,
              currency: docCur,
              exchange_rate: docExchRate,
              ref,
              supplier_id,
              notes: isAR ? 
                `دفعة فاتورة شراء: ${ref}${supplier_invoice_no ? ` (${supplier_invoice_no})` : ''} [${formatDocMoney(paidAmount, docCur)}${docCur !== baseCur ? ` ≈ ${formatDocMoney(basePaidAmount, baseCur)}` : ''}]` :
                `Purchase Payment: ${ref}${supplier_invoice_no ? ` (${supplier_invoice_no})` : ''} [${formatDocMoney(paidAmount, docCur)}${docCur !== baseCur ? ` ≈ ${formatDocMoney(basePaidAmount, baseCur)}` : ''}]`,
              date: data.doc_date,
              created_at: new Date().toISOString()
            });
          } else if (payment_method === 'card' || payment_method === 'transfer' || payment_method === 'cheque') {
            await DB.add('bank_transactions', {
              type: 'payment',
              amount: basePaidAmount,
              currency: docCur,
              ref,
              supplier_id,
              description: isAR ?
                `سداد فاتورة شراء (${payment_method}): ${ref}` :
                `Purchase Payment (${payment_method}): ${ref}`,
              date: data.doc_date,
              created_at: new Date().toISOString()
            });
          }
        } catch (e) {
          console.warn('Payment transaction record error:', e);
        }
      }

      // Synchronize and update supplier balance & totals immediately in DB!
      if (supplier_id) {
        await updateSupplierFinancials(supplier_id);
      }
      if (window._purOriginalSupplierId && window._purOriginalSupplierId !== supplier_id) {
        await updateSupplierFinancials(window._purOriginalSupplierId);
      }

      closeDocModal();
      Utils.toast(isAR ? `تم حفظ فاتورة الشراء بنجاح: ${ref}` : `Purchase invoice saved successfully: ${ref}`, 'success');

      // Refresh page list
      if (window.App && typeof App.renderPage === 'function') {
        await App.renderPage(App.getCurrentPage());
      }
      return docId;
    } catch (e) {
      Utils.toast('Error: ' + e.message, 'error');
    }
  }

  async function saveAndPrint(store) {
    const docId = await saveDoc(store);
    if (docId) {
      await printDoc(docId, store);
    }
  }

  // ── Search & Filter Document List ───────────────────────────
  function searchDocs(q, store) {
    const tbody = document.getElementById('pur-tbody');
    if (!tbody) return;
    const fromVal = document.getElementById('pur-from')?.value;
    const toVal   = document.getElementById('pur-to')?.value;

    const rows = tbody.querySelectorAll('tr');
    rows.forEach(row => {
      let matchesText = true;
      if (q) {
        matchesText = row.textContent.toLowerCase().includes(q.toLowerCase());
      }
      row.style.display = matchesText ? '' : 'none';
    });
  }

  // ── Delete Document ─────────────────────────────────────────
  async function deleteDoc(id, store) {
    const isAR = i18n.getLang() === 'ar';
    Utils.confirm(isAR ? 'هل أنت متأكد من حذف هذه الفاتورة؟' : 'Are you sure you want to delete this invoice?', async () => {
      const doc = await DB.get(store, id);
      const supId = doc?.supplier_id;
      await DB.remove(store, id);
      if (supId) {
        await updateSupplierFinancials(supId);
      }
      Utils.toast(i18n.t('common.deleted'), 'success');
      if (window.App && typeof App.renderPage === 'function') {
        await App.renderPage(App.getCurrentPage());
      }
    });
  }

  // ── Export CSV ──────────────────────────────────────────────
  async function exportDocs(store) {
    const docs = await DB.getAll(store);
    const suppliers = await DB.getAll('suppliers');
    const supMap = {};
    suppliers.forEach(s => { supMap[s.id] = s.name_en || s.name_ar; });

    Utils.exportCSV(docs.map(d => ({
      Ref: d.ref,
      SupplierBillNo: d.supplier_invoice_no || '',
      Date: d.doc_date,
      Supplier: supMap[d.supplier_id] || d.supplier_id,
      PaymentMethod: d.payment_method || 'cash',
      Currency: d.currency || 'USD',
      ExchangeRate: d.exchange_rate || '',
      Total: d.grand_total,
      BaseTotalUSD: d.base_grand_total !== undefined ? d.base_grand_total : d.grand_total,
      Paid: d.paid_amount || 0,
      Due: d.due_amount || 0,
      Status: d.status
    })), store);
  }

  // ── High-Quality Document Print ─────────────────────────────
  async function printDoc(id, store) {
    const doc = await DB.get(store, id);
    if (!doc) return;
    const lines = JSON.parse(doc.items_json || '[]');
    const isAR  = i18n.getLang() === 'ar';
    const cur   = await DB.getSetting('currency_1', 'USD');
    const companyName = await DB.getSetting('company_name', 'Store');
    const companyLogo = await DB.getSetting('company_logo', '');
    const printLogo   = await DB.getSetting('print_logo', true);
    const suppliers   = await DB.getAll('suppliers');
    const warehouses  = await DB.getAll('warehouses') || [];
    const sup = suppliers.find(s => s.id === doc.supplier_id);
    const wh  = warehouses.find(w => w.id === doc.warehouse_id);

    const docCur = doc.currency || cur;
    const isForeign = (docCur !== cur);
    const docRate = parseFloat(doc.exchange_rate) || 1;
    const rateToBase = doc.rate_to_base || (isForeign && docCur === 'LBP' ? 1/docRate : (isForeign && docCur === 'USD' ? docRate : 1));

    const supName = sup ? (isAR ? (sup.name_ar || sup.name_en) : (sup.name_en || sup.name_ar)) : '-';
    const whName  = wh ? (isAR ? (wh.name_ar || wh.name) : (wh.name || wh.name_ar)) : (isAR ? 'المستودع الرئيسي' : 'Main Store');

    const invSize = await DB.getSetting('invoice_size', 'A4');
    if (invSize === '80mm' || invSize === '58mm') {
      const receiptHtml = `
      <div class="receipt-80mm" dir="${isAR ? 'rtl' : 'ltr'}" style="width:76mm;margin:0 auto;font-family:'Segoe UI','Cairo','Arial',sans-serif;color:#000;font-size:10px;padding:2mm">
        <div style="text-align:center;margin-bottom:8px">
          ${(printLogo && companyLogo) ? `<img src="${companyLogo}" style="max-width:65px;max-height:55px;object-fit:contain;margin-bottom:4px">` : ''}
          <div style="font-size:1.1rem;font-weight:900">${Utils.sanitize(companyName)}</div>
          <div style="font-size:0.75rem;font-weight:700;color:#333;margin-top:2px">${isAR ? 'أمر شراء / فاتورة مشتريات' : 'Purchase Order / Bill'}</div>
        </div>
        <div style="border-top:1px dashed #000;margin:6px 0"></div>
        <div style="font-size:0.8rem;line-height:1.4">
          <div><strong>${isAR ? 'الرقم:' : 'Ref:'}</strong> <span style="font-weight:800">${doc.ref}</span></div>
          ${doc.supplier_invoice_no ? `<div><strong>${isAR ? 'فاتورة المورد:' : 'Supplier Bill:'}</strong> ${Utils.sanitize(doc.supplier_invoice_no)}</div>` : ''}
          <div><strong>${isAR ? 'التاريخ:' : 'Date:'}</strong> ${Utils.formatDate(doc.doc_date || doc.created_at)} ${doc.doc_time || ''}</div>
          <div><strong>${isAR ? 'المورد:' : 'Supplier:'}</strong> <span style="font-weight:800">${Utils.sanitize(supName)}</span></div>
          <div><strong>${isAR ? 'المستودع:' : 'Warehouse:'}</strong> ${Utils.sanitize(whName)}</div>
          <div><strong>${isAR ? 'طريقة الدفع:' : 'Payment:'}</strong> ${doc.payment_method?.toUpperCase() || 'CASH'}</div>
        </div>
        <div style="border-top:1px dashed #000;margin:6px 0"></div>
        <table style="width:100%;border-collapse:collapse;font-size:9.5px">
          <thead>
            <tr style="border-bottom:1px solid #000">
              <th style="text-align:${isAR ? 'right' : 'left'};padding:3px 0">${isAR ? 'الصنف' : 'Item'}</th>
              <th style="text-align:center;padding:3px 2px">${isAR ? 'كمية' : 'Qty'}</th>
              <th style="text-align:right;padding:3px 2px">${isAR ? 'سعر' : 'Price'}</th>
              <th style="text-align:right;padding:3px 0">${isAR ? 'الإجمالي' : 'Total'}</th>
            </tr>
          </thead>
          <tbody>
            ${lines.map(l => `
            <tr style="border-bottom:1px dashed #ddd">
              <td style="padding:3px 0">
                <div style="font-weight:700">${Utils.sanitize(isAR ? (l.name_ar || l.name_en) : (l.name_en || l.name_ar))}</div>
                ${l.barcode ? `<div style="font-size:8px;color:#555">${Utils.sanitize(l.barcode)}</div>` : ''}
              </td>
              <td style="text-align:center;padding:3px 2px;font-weight:700">${l.qty}</td>
              <td style="text-align:right;padding:3px 2px">${formatDocMoney(l.price, docCur)}</td>
              <td style="text-align:right;padding:3px 0;font-weight:800">${formatDocMoney(l.total, docCur)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
        <div style="border-top:1px dashed #000;margin:6px 0"></div>
        <div style="font-size:10px;line-height:1.5">
          <div style="display:flex;justify-content:space-between"><span>${isAR ? 'المجموع الفرعي:' : 'Subtotal:'}</span><span style="font-weight:700">${formatDocMoney(doc.subtotal || doc.total, docCur)}</span></div>
          ${doc.discount_amount > 0 ? `<div style="display:flex;justify-content:space-between"><span>${isAR ? 'الخصم:' : 'Discount:'}</span><span style="font-weight:700">-${formatDocMoney(doc.discount_amount, docCur)}</span></div>` : ''}
          ${doc.tax_amount > 0 ? `<div style="display:flex;justify-content:space-between"><span>${isAR ? 'الضريبة:' : 'VAT/TVA:'}</span><span style="font-weight:700">+${formatDocMoney(doc.tax_amount, docCur)}</span></div>` : ''}
          <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:900;border-top:1px solid #000;border-bottom:1px solid #000;padding:3px 0;margin:3px 0">
            <span>${isAR ? 'الصافي الإجمالي:' : 'NET TOTAL:'}</span>
            <span>${formatDocMoney(doc.total, docCur)}</span>
          </div>
          ${isForeign ? `<div style="display:flex;justify-content:space-between;font-size:10px;font-weight:800"><span>المعادل بـ (${cur}):</span><span>≈ ${formatDocMoney(doc.base_total ?? (doc.total * rateToBase), cur)}</span></div>` : ''}
          <div style="display:flex;justify-content:space-between"><span>${isAR ? 'المدفوع:' : 'Paid:'}</span><span style="font-weight:700">${formatDocMoney(doc.paid_amount || 0, docCur)}</span></div>
          ${doc.due_amount > 0 ? `<div style="display:flex;justify-content:space-between;font-weight:900"><span>${isAR ? 'المتبقي (آجل):' : 'Due (Credit):'}</span><span>${formatDocMoney(doc.due_amount, docCur)}</span></div>` : ''}
        </div>
        <div style="border-top:1px dashed #000;margin:8px 0;text-align:center;font-size:9px;color:#444">
          ${isAR ? 'تم إنشاء السند إلكترونياً • نظام RedShark POS' : 'Electronically Generated • RedShark POS'}
        </div>
      </div>`;
      await Utils.printElement(receiptHtml, doc.ref, invSize);
      return;
    }

    const html = `
    <div class="doc-a4" dir="${isAR ? 'rtl' : 'ltr'}" style="font-family:'Cairo','Inter',sans-serif;color:#000;padding:12mm">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #000;padding-bottom:12px;margin-bottom:16px">
        <div style="display:flex;align-items:center;gap:14px">
          ${(printLogo && companyLogo) ? `<img src="${companyLogo}" style="max-width:70px;max-height:70px;object-fit:contain">` : ''}
          <div>
            <h2 style="margin:0;font-size:1.4rem;font-weight:900">${Utils.sanitize(companyName)}</h2>
            <div style="font-size:0.85rem;color:#444;margin-top:2px">${isAR ? 'فاتورة مشتريات وتوريد بضاعة' : 'Purchase & Inward Goods Invoice'}</div>
          </div>
        </div>
        <div style="text-align:${isAR ? 'left' : 'right'}">
          <div style="font-size:1.6rem;font-weight:900;color:var(--primary)">${doc.ref}</div>
          ${doc.supplier_invoice_no ? `<div style="font-weight:700;font-size:0.9rem">${isAR ? 'فاتورة المورد #:' : 'Supplier Bill #:'} ${Utils.sanitize(doc.supplier_invoice_no)}</div>` : ''}
          <div style="font-size:0.8rem;color:#555;margin-top:2px">${Utils.formatDate(doc.doc_date || doc.created_at)} ${doc.doc_time || ''}</div>
          <div style="margin-top:4px">
            <span style="font-weight:800;font-size:0.75rem;background:#e2e8f0;padding:2px 8px;border-radius:4px">
              ${docCur === 'USD' ? 'USD ($)' : 'L.L. (ل.ل)'}
            </span>
            ${isForeign ? `<span style="font-size:0.75rem;color:#64748b;font-weight:700;margin-inline-start:4px">1 USD = ${docRate.toLocaleString()} L.L.</span>` : ''}
          </div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;background:#f8fafc;border:1px solid #cbd5e1;border-radius:8px;padding:12px;margin-bottom:16px;font-size:0.85rem">
        <div>
          <div style="font-weight:800;color:#64748b;font-size:0.75rem;text-transform:uppercase;margin-bottom:4px">${isAR ? 'بيانات المورد:' : 'Supplier Details:'}</div>
          <div style="font-weight:800;font-size:1rem">${Utils.sanitize(supName)}</div>
          ${sup?.phone ? `<div>${isAR ? 'هاتف: ' : 'Phone: '}${Utils.sanitize(sup.phone)}</div>` : ''}
          ${sup?.tax_number ? `<div>${isAR ? 'الرقم الضريبي: ' : 'Tax ID: '}${Utils.sanitize(sup.tax_number)}</div>` : ''}
        </div>
        <div>
          <div style="font-weight:800;color:#64748b;font-size:0.75rem;text-transform:uppercase;margin-bottom:4px">${isAR ? 'شروط الفاتورة والدفع:' : 'Invoice & Payment Terms:'}</div>
          <div><strong>${isAR ? 'المستودع المستلم:' : 'Warehouse:'}</strong> 🏬 ${Utils.sanitize(whName)}</div>
          <div><strong>${isAR ? 'طريقة الدفع:' : 'Payment Method:'}</strong> ${doc.payment_method?.toUpperCase() || 'CASH'}</div>
          <div><strong>${isAR ? 'الحالة:' : 'Status:'}</strong> <span style="text-transform:uppercase;font-weight:700">${doc.status || 'Received'}</span></div>
        </div>
      </div>

      <table class="doc-table" style="width:100%;border-collapse:collapse;margin-bottom:16px;font-size:0.85rem">
        <thead>
          <tr style="background:#f1f5f9;border-bottom:2px solid #000">
            <th style="padding:8px;text-align:center;width:30px">#</th>
            <th style="padding:8px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'الصنف' : 'Product / Description'}</th>
            <th style="padding:8px;text-align:center;width:70px">${isAR ? 'الوحدة' : 'Unit'}</th>
            <th style="padding:8px;text-align:center;width:70px">${isAR ? 'الكمية' : 'Qty'}</th>
            <th style="padding:8px;text-align:right;width:100px">${isAR ? 'سعر الشراء' : 'Cost Price'}</th>
            <th style="padding:8px;text-align:right;width:100px">${isAR ? 'سعر البيع' : 'Sell Price'}</th>
            <th style="padding:8px;text-align:center;width:55px">${isAR ? 'خصم%' : 'Disc%'}</th>
            <th style="padding:8px;text-align:center;width:65px">${isAR ? 'ضريبة%' : 'TVA%'}</th>
            <th style="padding:8px;text-align:right;width:115px">${isAR ? 'الإجمالي' : 'Total'}</th>
          </tr>
        </thead>
        <tbody>
          ${lines.map((l, i) => `
          <tr style="border-bottom:1px solid #e2e8f0">
            <td style="padding:6px 8px;text-align:center">${i + 1}</td>
            <td style="padding:6px 8px">
              <div style="font-weight:700">${Utils.sanitize(isAR ? (l.name_ar || l.name_en) : (l.name_en || l.name_ar))}</div>
              ${l.barcode ? `<div style="font-size:0.7rem;color:#555">🏷️ ${Utils.sanitize(l.barcode)}</div>` : ''}
            </td>
            <td style="padding:6px 8px;text-align:center">${Utils.sanitize(l.unit || 'pcs')}</td>
            <td style="padding:6px 8px;text-align:center;font-weight:700">${l.qty}</td>
            <td style="padding:6px 8px;text-align:right">${formatDocMoney(l.price, docCur)}</td>
            <td style="padding:6px 8px;text-align:right">${formatDocMoney(l.selling_price || 0, docCur)}</td>
            <td style="padding:6px 8px;text-align:center">${l.disc || 0}%</td>
            <td style="padding:6px 8px;text-align:center;font-weight:700">${(l.tax_pct || 0) > 0 ? `${l.tax_pct}%` : (isAR ? 'معفى' : '0%')}</td>
            <td style="padding:6px 8px;text-align:right;font-weight:800">
              <div>${formatDocMoney(l.total, docCur)}</div>
              ${(l.tax_amount > 0) ? `<div style="font-size:0.7rem;color:#b45309">+TVA: ${formatDocMoney(l.tax_amount, docCur)}</div>` : ''}
            </td>
          </tr>`).join('')}
        </tbody>
      </table>

      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-top:14px">
        <div style="width:48%;font-size:0.85rem">
          ${doc.notes ? `<div style="padding:8px;background:#f8fafc;border:1px dashed #cbd5e1;border-radius:6px"><strong>${isAR ? 'ملاحظات:' : 'Notes:'}</strong> ${Utils.sanitize(doc.notes)}</div>` : ''}
          <div style="margin-top:10px;font-size:0.8rem;color:#555">
            <div>✓ ${isAR ? 'تم استلام وتدقيق البضاعة ومطابقة الأسعار والكميات' : 'Goods verified, audited and received into warehouse'}</div>
          </div>
        </div>

        <div style="width:48%">
          <table style="width:100%;border-collapse:collapse;font-size:0.9rem">
            <tr>
              <td style="padding:4px 0;color:#555">${isAR ? 'المجموع الصافي (قبل الضريبة):' : 'Net Subtotal (Excl. Tax):'}</td>
              <td style="padding:4px 0;text-align:right;font-weight:700">${formatDocMoney(doc.subtotal, docCur)}</td>
            </tr>
            ${doc.discount > 0 ? `
            <tr>
              <td style="padding:4px 0;color:#555">${isAR ? 'الخصم الإجمالي:' : 'Discount:'}</td>
              <td style="padding:4px 0;text-align:right;color:var(--danger)">-${formatDocMoney(doc.discount, docCur)}</td>
            </tr>` : ''}
            ${(doc.tax_amount > 0) ? `
            <tr>
              <td style="padding:4px 0;color:#b45309;font-weight:700">${isAR ? 'ضريبة القيمة المضافة (TVA):' : 'TVA Tax Amount:'}</td>
              <td style="padding:4px 0;text-align:right;font-weight:800;color:#b45309">+${formatDocMoney(doc.tax_amount, docCur)}</td>
            </tr>` : ''}
            ${doc.shipping_cost > 0 ? `
            <tr>
              <td style="padding:4px 0;color:#555">${isAR ? 'مصاريف نقل وشحن:' : 'Freight / Shipping:'}</td>
              <td style="padding:4px 0;text-align:right">+${formatDocMoney(doc.shipping_cost, docCur)}</td>
            </tr>` : ''}
            <tr style="border-top:2px solid #000;font-size:1.15rem;font-weight:900">
              <td style="padding:8px 0">${isAR ? 'الصافي النهائي (شامل الضريبة):' : 'TOTAL (INCL. TAX):'}</td>
              <td style="padding:8px 0;text-align:right;color:var(--primary)">
                <div>${formatDocMoney(doc.grand_total, docCur)}</div>
                ${isForeign ? `<div style="font-size:0.82rem;font-weight:700;color:#64748b">≈ ${formatDocMoney(doc.base_grand_total ?? (doc.grand_total * rateToBase), cur)}</div>` : ''}
              </td>
            </tr>
            <tr>
              <td style="padding:4px 0;color:#16a34a;font-weight:700">${isAR ? 'المبلغ المدفوع:' : 'Amount Paid:'}</td>
              <td style="padding:4px 0;text-align:right;font-weight:800;color:#16a34a">
                <div>${formatDocMoney(doc.paid_amount || 0, docCur)}</div>
                ${(isForeign && doc.paid_amount > 0) ? `<div style="font-size:0.75rem;font-weight:700">≈ ${formatDocMoney(doc.base_paid_amount ?? (doc.paid_amount * rateToBase), cur)}</div>` : ''}
              </td>
            </tr>
            ${(doc.due_amount > 0) ? `
            <tr>
              <td style="padding:4px 0;color:#e11d48;font-weight:700">${isAR ? 'المتبقي على حساب المورد (آجل):' : 'Remaining Due (Credit):'}</td>
              <td style="padding:4px 0;text-align:right;font-weight:800;color:#e11d48">
                <div>${formatDocMoney(doc.due_amount, docCur)}</div>
                ${isForeign ? `<div style="font-size:0.75rem;font-weight:700">≈ ${formatDocMoney(doc.base_due_amount ?? (doc.due_amount * rateToBase), cur)}</div>` : ''}
              </td>
            </tr>` : ''}
          </table>
        </div>
      </div>

      <div class="doc-footer" style="margin-top:45px;display:flex;justify-content:space-between;padding-top:16px;border-top:1px dashed #cbd5e1">
        <div style="text-align:center;width:160px;border-top:1px solid #000;padding-top:6px;font-size:0.8rem">
          ${isAR ? 'توقيع المستلم / أمين المخزن' : 'Storekeeper Signature'}
        </div>
        <div style="text-align:center;width:160px;border-top:1px solid #000;padding-top:6px;font-size:0.8rem">
          ${isAR ? 'توقيع مندوب المورد' : 'Supplier Representative'}
        </div>
        <div style="text-align:center;width:160px;border-top:1px solid #000;padding-top:6px;font-size:0.8rem">
          ${isAR ? 'اعتماد الإدارة / المحاسب' : 'Authorized Approval'}
        </div>
      </div>
    </div>`;

    Utils.printElement(html, doc.ref);
  }

  function recalcQuickItemPrice(source = 'profit') {
    const cost = parseFloat(document.getElementById('qitem-cost')?.value) || 0;
    const profitEl = document.getElementById('qitem-profit-pct');
    const priceEl = document.getElementById('qitem-price');
    let profitPct = parseFloat(profitEl?.value) || 0;
    let price = parseFloat(priceEl?.value) || 0;

    if (source === 'profit' || source === 'cost') {
      if (cost > 0 && profitEl && profitEl.value !== '') {
        price = cost + (cost * (profitPct / 100));
        if (priceEl) priceEl.value = (Math.round(price * 100) / 100).toFixed(2);
      }
    } else if (source === 'price') {
      if (cost > 0 && price >= 0) {
        profitPct = ((price - cost) / cost) * 100;
        if (profitEl) profitEl.value = (Math.round(profitPct * 10) / 10).toFixed(1);
      }
    }
  }

  return {
    renderPO:      (c) => renderDocList(c, 'purchase_orders',  'Purchase Orders',  'أوامر الشراء',   'PO-'),
    renderGRN:     (c) => renderDocList(c, 'goods_receipts',   'Goods Receipts',   'استلام البضاعة', 'GRN-'),
    renderInvoice: (c) => renderDocList(c, 'purchase_invoices','Purchase Invoices','فواتير الشراء',  'PINV-'),
    renderReturn:  (c) => renderDocList(c, 'purchase_returns', 'Purchase Returns', 'مرتجعات الشراء', 'PRET-'),
    openDoc, closeDocModal, removeLine, updateLine, recalcTotals,
    saveDoc, saveAndPrint, searchDocs, deleteDoc, exportDocs, printDoc,
    handleBarcodeScan, onSearchInput, onSearchKeyDown, selectItemFromSearch,
    openQuickNewItemModal, saveQuickNewItem, recalcQuickItemPrice,
    openQuickSupplierModal, saveQuickSupplier,
    onSupplierChange, onPaymentMethodChange, quickSetPaid,
    selectPaymentMode, updatePaymentHighlight, updateSupplierFinancials, isItemTaxable,
    onCurrencyChange, onExchRateChange, resetExchRateToDefault
  };
})();

window.Purchasing = Purchasing;
