/* ================================================================
   NexPOS — Categories Module
   ================================================================ */

const Categories = (() => {
  async function render(container) {
    let cats = await DB.getAll('categories');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'التصنيفات' : 'Categories'}</h1>
          <p>${isAR ? `${cats.length} تصنيف` : `${cats.length} categories`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Categories.openForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'تصنيف جديد' : 'New Category'}
          </button>
        </div>
      </div>

      <div class="grid grid-3" id="cats-grid">
        ${cats.map(c => renderCatCard(c, cats, isAR)).join('')}
        ${cats.length === 0 ? `<div class="empty-state" style="grid-column:1/-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px;height:40px"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
          <h3>${isAR ? 'لا توجد تصنيفات' : 'No categories yet'}</h3>
        </div>` : ''}
      </div>
    </div>

    <!-- Category Form Modal -->
    <div class="modal-overlay" id="cat-modal">
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <div class="modal-title" id="cat-modal-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            ${isAR ? 'تصنيف جديد' : 'New Category'}
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('cat-modal')">✕</button>
        </div>
        <div class="modal-body">
          
          <!-- Category Logo / Image Upload Section -->
          <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;background:var(--surface-2);padding:12px;border-radius:12px;border:1px solid var(--border-color)">
            <div id="cat-img-preview" style="width:64px;height:64px;border-radius:12px;background:var(--surface);border:2px dashed var(--border-color);display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
            </div>
            <div style="flex:1">
              <label class="form-label" style="font-size:0.8rem;margin-bottom:4px">${isAR ? 'صورة أو شعار التصنيف' : 'Category Image / Logo'}</label>
              <div style="display:flex;gap:6px">
                <label class="btn btn-secondary btn-sm" style="cursor:pointer;font-size:0.75rem">
                  📁 ${isAR ? 'رفع صورة' : 'Upload'}
                  <input type="file" id="cat-file-input" accept="image/*" style="display:none" onchange="Categories.previewImage(this)">
                </label>
                <button type="button" class="btn btn-ghost btn-sm" onclick="Categories.clearImage()" style="font-size:0.75rem;color:var(--danger)">
                  ✕ ${isAR ? 'إزالة' : 'Clear'}
                </button>
              </div>
              <div style="font-size:0.7rem;color:var(--text-muted);margin-top:4px">PNG, JPG, WebP (Max 2MB)</div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isAR ? 'الاسم (عربي)' : 'Name (Arabic)'}</label>
            <input type="text" class="form-control" id="cat-name-ar" placeholder="اسم التصنيف" dir="rtl">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'الاسم (إنجليزي)' : 'Name (English)'}</label>
            <input type="text" class="form-control" id="cat-name-en" placeholder="Category name">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'التصنيف الأب' : 'Parent Category'}</label>
            <select class="form-control" id="cat-parent">
              <option value="">${isAR ? '-- بدون أب --' : '-- No parent (Top level) --'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'الترتيب' : 'Sort Order'}</label>
            <input type="number" class="form-control" id="cat-sort" value="1" min="1">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('cat-modal')">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Categories.save()">${isAR ? 'حفظ' : 'Save'}</button>
        </div>
      </div>
    </div>`;

    // Load parent options
    const sel = document.getElementById('cat-parent');
    cats.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = isAR ? (c.name_ar||c.name) : (c.name||c.name_ar);
      sel.appendChild(opt);
    });

    // Store cats for later
    window._allCats = cats;
  }

  function renderCatCard(cat, cats, isAR) {
    const parent = cats.find(c => c.id === cat.parent_id);
    const name   = isAR ? (cat.name_ar || cat.name) : (cat.name || cat.name_ar);
    return `
    <div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:12px">
      <div style="display:flex;align-items:center;gap:12px;flex:1">
        <div style="width:48px;height:48px;border-radius:10px;background:var(--primary-alpha);display:flex;align-items:center;justify-content:center;overflow:hidden;border:1px solid var(--border-color);flex-shrink:0">
          ${cat.image
            ? `<img src="${cat.image}" style="max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;border-radius:9px">`
            : `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`}
        </div>
        <div>
          <div style="font-weight:700;font-size:0.9rem">${Utils.sanitize(name)}</div>
          ${parent ? `<div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'ضمن: ' : 'Under: '}${isAR ? (parent.name_ar||parent.name) : (parent.name||parent.name_ar)}</div>` : `<div style="font-size:0.72rem;color:var(--primary)">${isAR ? 'تصنيف رئيسي' : 'Top Level'}</div>`}
        </div>
      </div>
      <div style="display:flex;gap:4px">
        <button class="btn btn-ghost btn-sm" onclick="Categories.openForm(${cat.id})">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
        </button>
        <button class="btn btn-ghost btn-sm" onclick="Categories.deleteCategory(${cat.id})" style="color:var(--danger)">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
        </button>
      </div>
    </div>`;
  }

  async function openForm(id = null) {
    window._editCatId = id;
    window._uploadedCatImage = '';
    const isAR = i18n.getLang() === 'ar';
    document.getElementById('cat-modal-title').innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
      ${id ? (isAR ? 'تعديل التصنيف' : 'Edit Category') : (isAR ? 'تصنيف جديد' : 'New Category')}`;

    document.getElementById('cat-name-ar').value = '';
    document.getElementById('cat-name-en').value = '';
    document.getElementById('cat-parent').value  = '';
    document.getElementById('cat-sort').value    = '1';

    const previewEl = document.getElementById('cat-img-preview');
    if (previewEl) {
      previewEl.innerHTML = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`;
    }

    if (id) {
      const cat = await DB.get('categories', id);
      if (cat) {
        document.getElementById('cat-name-ar').value = cat.name_ar || '';
        document.getElementById('cat-name-en').value = cat.name || '';
        document.getElementById('cat-parent').value  = cat.parent_id || '';
        document.getElementById('cat-sort').value    = cat.sort_order || 1;
        if (cat.image) {
          window._uploadedCatImage = cat.image;
          if (previewEl) {
            previewEl.innerHTML = `<img src="${cat.image}" style="width:100%;height:100%;object-fit:cover">`;
          }
        }
      }
    }
    Utils.openModal('cat-modal');
  }

  async function previewImage(input) {
    const file = input.files[0];
    if (!file) return;
    try {
      const base64 = await Utils.fileToBase64(file);
      window._uploadedCatImage = base64;
      const previewEl = document.getElementById('cat-img-preview');
      if (previewEl) {
        previewEl.innerHTML = `<img src="${base64}" style="width:100%;height:100%;object-fit:cover">`;
      }
    } catch(err) {
      console.error(err);
    }
  }

  function clearImage() {
    window._uploadedCatImage = '';
    const previewEl = document.getElementById('cat-img-preview');
    if (previewEl) {
      previewEl.innerHTML = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`;
    }
    const fileInput = document.getElementById('cat-file-input');
    if (fileInput) fileInput.value = '';
  }

  async function save() {
    const isAR = i18n.getLang() === 'ar';
    const nameAr = document.getElementById('cat-name-ar').value.trim();
    const nameEn = document.getElementById('cat-name-en').value.trim();
    if (!nameAr && !nameEn) { Utils.toast(i18n.t('common.required'), 'warning'); return; }

    const data = {
      name:       nameEn || nameAr,
      name_ar:    nameAr,
      parent_id:  parseInt(document.getElementById('cat-parent').value) || null,
      sort_order: parseInt(document.getElementById('cat-sort').value) || 1,
      image:      window._uploadedCatImage !== undefined ? window._uploadedCatImage : ''
    };

    if (window._editCatId) {
      const existing = await DB.get('categories', window._editCatId);
      if (existing && window._uploadedCatImage === undefined) {
        data.image = existing.image || '';
      }
      await DB.update('categories', { ...data, id: window._editCatId });
      Utils.toast(i18n.t('common.updated'), 'success');
    } else {
      await DB.add('categories', data);
      Utils.toast(i18n.t('common.saved'), 'success');
    }
    if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
      BranchSync.notifyChange('categories');
    }
    Utils.closeModal('cat-modal');
    await render(document.getElementById('page-content'));
  }

  function deleteCategory(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('categories', id);
      if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
        BranchSync.notifyChange('categories');
      }
      Utils.toast(i18n.t('common.deleted'), 'success');
      await render(document.getElementById('page-content'));
    });
  }

  return { render, openForm, save, deleteCategory, previewImage, clearImage };
})();

window.Categories = Categories;
