/* ================================================================
   Red Shark POS — Multi-POS & Branch Sync Engine
   Real-Time SSE Catalog Push & Two-Way Centralized Transactions
   ================================================================ */

const BranchSync = (() => {
  let sseEventSource = null;
  let isSyncing = false;
  let reconnectTimeout = null;
  let heartbeatInterval = null;
  let autoRefreshInterval = null;
  let autoSyncInterval = null;
  let cloudDeltaInterval = null;
  let _isOffline = false;
  let _lastSeenCloudSeq = localStorage.getItem('rs_cloud_sync_seq') || 0;
  let _sentinelChecking = false;

  const DEFAULT_TABLES = ['items', 'categories', 'offers', 'units', 'warehouses', 'customers', 'stock_transfers'];
  const AVAILABLE_TABLES = [
    { id: 'items', en: 'Items & Barcodes', ar: 'الأصناف والباركود' },
    { id: 'categories', en: 'Categories & Brands', ar: 'الفئات والأقسام' },
    { id: 'offers', en: 'Offers & Deals', ar: 'العروض والخصومات' },
    { id: 'units', en: 'Units & Measurements', ar: 'الوحدات والقياسات' },
    { id: 'warehouses', en: 'Stores & Branches', ar: 'المستودعات والفروع' },
    { id: 'stock_transfers', en: 'Stock Transfers', ar: 'تحويلات المخزون' },
    { id: 'customers', en: 'Customers', ar: 'العملاء' },
    { id: 'suppliers', en: 'Suppliers', ar: 'الموردون' }
  ];

  // ── Node Configuration ───────────────────────────────────────────
  async function getConfig() {
    const role = (await DB.getSetting('sync_node_role', 'server')).toLowerCase(); // 'server' | 'pos' | 'branch'
    const serverIp = await DB.getSetting('sync_server_ip', '127.0.0.1');
    const serverPort = await DB.getSetting('sync_server_port', 3000);
    const nodeId = await DB.getSetting('sync_node_id', (role === 'server' ? 'SRV-01' : 'POS-' + Math.floor(100 + Math.random() * 900)));
    const nodeName = await DB.getSetting('sync_node_name', (role === 'server' ? 'Main Server (Central Branch)' : 'POS Workstation'));
    const branchId = await DB.getSetting('sync_branch_id', (role === 'server' ? 'main' : 'branch-1'));
    let syncTables = await DB.getSetting('sync_tables', DEFAULT_TABLES);
    if (typeof syncTables === 'string') {
      try { syncTables = JSON.parse(syncTables); } catch(e) { syncTables = DEFAULT_TABLES; }
    }
    const rawAutoSync = await DB.getSetting('sync_auto_enabled', true);
    const autoSync = (rawAutoSync !== false && rawAutoSync !== 'false' && rawAutoSync !== 0 && rawAutoSync !== '0');
    return { role, serverIp, serverPort, nodeId, nodeName, branchId, syncTables, autoSync };
  }

  async function isServer() {
    const cfg = await getConfig();
    return cfg.role === 'server';
  }

  async function getEffectiveBranchId() {
    const cfg = await getConfig();
    return cfg.branchId || 'main';
  }

  async function getEffectiveNodeId() {
    const cfg = await getConfig();
    return cfg.nodeId || 'SRV-01';
  }

  function getServerBaseUrl(cfg) {
    if (!cfg) return 'http://127.0.0.1:3000';
    if (cfg.role === 'server') {
      return window.location.origin.includes('http') ? window.location.origin : 'http://127.0.0.1:3000';
    }
    let raw = (cfg.serverIp || '127.0.0.1').trim();
    if (!raw) return 'http://127.0.0.1:3000';

    // If already has https:// or http:// scheme (e.g. Cloudflare tunnel URL)
    if (raw.startsWith('https://') || raw.startsWith('http://')) {
      return raw.replace(/\/+$/, '');
    }

    // If it's a domain name (e.g. trycloudflare.com or custom domain)
    if (raw.includes('trycloudflare.com') || (raw.includes('.') && !/^\d+\.\d+\.\d+\.\d+/.test(raw))) {
      return `https://${raw.replace(/\/+$/, '')}`;
    }

    let ip = raw.replace(/^https?:\/\//, '');
    const port = cfg.serverPort || 3000;
    if (ip.includes(':')) return `http://${ip}`;
    return `http://${ip}:${port}`;
  }

  // ── Real-Time Cloud Sentinel & Reconnection Handler ──────────────
  async function handleConnectionRestored() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    _isOffline = false;
    updateTopbarIndicator(true);
    updateStatusBadge('online', isAR ? 'المزامنة السحابية متصلة ومحدثة' : 'Cloud Sync Connected');
    if (typeof Utils !== 'undefined' && Utils.toast) {
      Utils.toast(isAR ? '🌐 تمت استعادة الاتصال بالسحابة! جاري مزامنة التحديثات فوراً...' : '🌐 Cloud connection restored! Syncing updates immediately...', 'info', 3000);
    }
    await triggerCloudSentinelCheck(true);
    if (window.OnlineOrders && typeof OnlineOrders.syncPosSalesToCloud === 'function') {
      OnlineOrders.syncPosSalesToCloud();
    }
  }

  async function triggerCloudSentinelCheck(force = false) {
    if (_sentinelChecking) return;
    _sentinelChecking = true;
    try {
      const cfg = await getConfig();
      if (!window.OnlineOrders || typeof OnlineOrders.getConfig !== 'function') return;
      const ooCfg = await OnlineOrders.getConfig();
      if (!ooCfg || !ooCfg.slug) return;

      const shopId = await (OnlineOrders.resolveShopId ? OnlineOrders.resolveShopId(ooCfg) : null);
      if (!shopId) return;

      const res = await fetch(`${ooCfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: {
          'apikey': ooCfg.key,
          'Authorization': `Bearer ${ooCfg.key}`
        },
        signal: AbortSignal.timeout(6000)
      });

      if (!res.ok) {
        if (!_isOffline) {
          _isOffline = true;
          updateTopbarIndicator(false);
          updateStatusBadge('offline', (typeof i18n !== 'undefined' && i18n.getLang && i18n.getLang() === 'ar') ? 'غير متصل بالسحابة' : 'Cloud Offline');
        }
        return;
      }

      // If we were offline and now fetch succeeded:
      if (_isOffline) {
        handleConnectionRestored();
        return;
      }

      const data = await res.json();
      if (!data || !data[0]) return;

      let bObj = {};
      try {
        bObj = typeof data[0].banner_url === 'string' ? JSON.parse(data[0].banner_url) : (data[0].banner_url || {});
      } catch(e) {}

      const cloudSeq = Number(bObj.cloud_sync_seq) || 0;
      const localSeq = Number(_lastSeenCloudSeq) || Number(localStorage.getItem('rs_cloud_sync_seq')) || 0;
      const cloudCustTime = bObj.customers_updated_at || '';
      const localCustTime = localStorage.getItem('rs_cloud_customers_updated_at') || '';
      const isNewCustTime = (cloudCustTime && cloudCustTime !== localCustTime);

      // Check if there is a new sequence from another node or if force sync is requested
      const isFromOtherNode = (!bObj.last_change_by || bObj.last_change_by !== cfg.nodeId);
      const isNewSeq = cloudSeq > localSeq;

      if ((isNewSeq && isFromOtherNode) || isNewCustTime || force) {
        console.log(`[BranchSync Sentinel] New cloud update detected! Cloud seq: ${cloudSeq}, local: ${localSeq}`);
        const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
        const changeDesc = bObj.last_change_desc || (bObj.last_change_type === 'customers' ? (isAR ? 'تحديث رصيد عميل' : 'Customer balance update') : (isAR ? 'تحديث أسعار الأصناف' : 'Item price update'));

        if (!force && typeof Utils !== 'undefined' && Utils.toast) {
          Utils.toast(isAR ? `⚡ تنبيه مزامنة: تم رصد تحديث من السيرفر (${changeDesc})! جاري المزامنة فوراً...` : `⚡ Sync Alert: New server update detected (${changeDesc})! Syncing immediately...`, 'info', 4000);
        }

        // Pull modified items delta
        if (typeof OnlineOrders.pullCloudDelta === 'function') {
          await OnlineOrders.pullCloudDelta();
        }

        // Pull / merge customers directly from bObj
        if (typeof OnlineOrders.pullCustomersFromCloud === 'function') {
          await OnlineOrders.pullCustomersFromCloud(bObj);
        }

        // Advance sequence
        if (cloudSeq > 0) {
          _lastSeenCloudSeq = cloudSeq;
          localStorage.setItem('rs_cloud_sync_seq', String(cloudSeq));
        }
        if (cloudCustTime) {
          localStorage.setItem('rs_cloud_customers_updated_at', cloudCustTime);
        }

        const nowIso = new Date().toISOString();
        localStorage.setItem('rs_last_cloud_sync', nowIso);
        if (typeof DB !== 'undefined') {
          try { await DB.setSetting('last_cloud_sync_time', nowIso); } catch(e) {}
        }
        const timeEl = document.getElementById('sync-last-cloud-time');
        if (timeEl) timeEl.textContent = formatSyncTime(nowIso);
        updateTopbarIndicator(true);

        if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'all' } }));
        }

        if (!force && typeof Utils !== 'undefined' && Utils.toast) {
          Utils.toast(isAR ? `✅ تم تحديث بيانات الفرع وتزامنها بنجاح مع السحابة!` : `✅ Branch synchronized successfully with Central Cloud!`, 'success', 3000);
        }
      } else if (isNewSeq && !isFromOtherNode) {
        // Our own update, just record the seq
        _lastSeenCloudSeq = cloudSeq;
        localStorage.setItem('rs_cloud_sync_seq', String(cloudSeq));
      }
    } catch(err) {
      if (err.name === 'AbortError' || err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError') || !navigator.onLine) {
        if (!_isOffline) {
          _isOffline = true;
          updateTopbarIndicator(false);
          updateStatusBadge('offline', (typeof i18n !== 'undefined' && i18n.getLang && i18n.getLang() === 'ar') ? 'غير متصل بالسحابة' : 'Cloud Offline');
        }
      }
    } finally {
      _sentinelChecking = false;
    }
  }

  // ── Real-Time SSE Listener ───────────────────────────────────────
  async function startListener() {
    const cfg = await getConfig();
    if (sseEventSource) {
      try { sseEventSource.close(); } catch(e) {}
      sseEventSource = null;
    }
    clearTimeout(reconnectTimeout);
    if (heartbeatInterval) {
      clearInterval(heartbeatInterval);
      heartbeatInterval = null;
    }
    if (autoSyncInterval) {
      clearInterval(autoSyncInterval);
      autoSyncInterval = null;
    }
    if (cloudDeltaInterval) {
      clearInterval(cloudDeltaInterval);
      cloudDeltaInterval = null;
    }

    // Auto-sync when internet connection is restored or app gains focus
    if (!window._rs_online_sync_listener) {
      window._rs_online_sync_listener = true;
      window.addEventListener('online', () => {
        console.log('[BranchSync] Internet connection restored. Triggering direct auto-sync...');
        handleConnectionRestored();
      });
      window.addEventListener('focus', () => {
        triggerCloudSentinelCheck(false);
      });
    }

    // If server, publish local table snapshots on startup and trigger cloud sync on boot
    if (cfg.role === 'server') {
      updateTopbarIndicator(false, null, true); // Hidden on server
      publishAllTablesToServer();
      updateStatusBadge('online', 'Server Active (Broadcasting)');
      
      // Auto-sync server to cloud on boot
      if (cfg.autoSync) {
        setTimeout(() => syncNow(true), 2000);
        autoSyncInterval = setInterval(() => {
          if (!isSyncing && typeof document !== 'undefined' && !document.hidden) {
            syncNow(true);
          }
        }, 60000); // Keep cloud updated every 60s
      }
      return;
    }

    // Node is a Branch or POS workstation -> Display connection circle indicator
    updateTopbarIndicator(false); // Initial state: red until ping/SSE succeeds

    // Client (POS or Branch) connects to Server SSE stream
    const baseUrl = getServerBaseUrl(cfg);
    const sseUrl = `${baseUrl}/api/sync/events?nodeId=${encodeURIComponent(cfg.nodeId)}&nodeName=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}`;

    // Client background heartbeat loop (every 15s) to guarantee server/cloud marks node Online & update topbar dot
    const sendHeartbeat = async () => {
      let lanSuccess = false;
      if (cfg.serverIp && cfg.serverIp !== '127.0.0.1') {
        try {
          const pingUrl = `${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(cfg.nodeId)}&name=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}`;
          const res = await fetch(pingUrl, { signal: AbortSignal.timeout(4000) });
          if (res.ok) lanSuccess = true;
        } catch(e) {}
      }

      // Also send heartbeat to Cloud Supabase for Remote Branches
      let cloudSuccess = false;
      if (window.OnlineOrders && typeof OnlineOrders.heartbeatBranchToCloud === 'function') {
        try {
          await OnlineOrders.heartbeatBranchToCloud(cfg);
          cloudSuccess = true;
        } catch(e) {}
      }

      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
      if (lanSuccess) {
        updateTopbarIndicator(true);
        updateStatusBadge('online', isAR ? `متصل بالسيرفر (${cfg.serverIp})` : `Connected to Server (${cfg.serverIp})`);
      } else if (cloudSuccess) {
        updateTopbarIndicator(true, isAR ? 'متصل بالسحابة المركزية' : 'Connected to Central Cloud');
        updateStatusBadge('online', isAR ? 'المزامنة السحابية متصلة ومحدثة' : 'Cloud Sync Connected');
      } else {
        updateTopbarIndicator(false);
      }
    };
    sendHeartbeat();
    heartbeatInterval = setInterval(sendHeartbeat, 15000);

    // Real-Time Cloud Sentinel & Direct Auto-Sync Poller
    // Runs constantly in background on Remote Branch stations
    if (window.OnlineOrders) {
      let tickCount = 0;
      cloudDeltaInterval = setInterval(async () => {
        if (!isSyncing) {
          tickCount++;
          // Fast sequence check every 3.5s for instant alerts
          await triggerCloudSentinelCheck(false);
          // Every 3 ticks (~10s), always pull product delta directly to catch any updates even if cloud seq didn't bump!
          if (tickCount % 3 === 0 && typeof OnlineOrders.pullCloudDelta === 'function') {
            await OnlineOrders.pullCloudDelta();
          }
        }
      }, 3500);

      // Instant Direct Auto-Sync on Startup (within 400ms)
      setTimeout(async () => {
        await triggerCloudSentinelCheck(true);
        if (typeof OnlineOrders.pullCloudDelta === 'function') {
          await OnlineOrders.pullCloudDelta();
        }
        if (typeof OnlineOrders.pullCustomersFromCloud === 'function') {
          await OnlineOrders.pullCustomersFromCloud();
        }
      }, 400);
    }

    // Client background periodic full sync (every 45s) if auto-sync is enabled
    if (cfg.autoSync) {
      autoSyncInterval = setInterval(() => {
        if (!isSyncing && typeof document !== 'undefined' && !document.hidden) {
          syncNow(true);
        }
      }, 45000);
    }

    // Only establish LAN SSE connection if a valid LAN IP is specified (not empty and not 127.0.0.1 on remote branch)
    if (cfg.serverIp && cfg.serverIp !== '127.0.0.1') {
      connectLanSSE(cfg);
    } else {
      // In Pure Cloud Sync mode (Remote Branch over internet): trigger initial sync
      if (cfg.autoSync) {
        setTimeout(() => syncNow(true), 2000);
      }
    }
  }

  function connectLanSSE(cfg) {
    if (!cfg.serverIp || cfg.serverIp === '127.0.0.1') return;
    if (sseEventSource) {
      try { sseEventSource.close(); } catch(e) {}
      sseEventSource = null;
    }
    clearTimeout(reconnectTimeout);
    const baseUrl = getServerBaseUrl(cfg);
    const sseUrl = `${baseUrl}/api/sync/events?nodeId=${encodeURIComponent(cfg.nodeId)}&nodeName=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}`;
    try {
      updateStatusBadge('connecting', 'Connecting to Server...');
      sseEventSource = new EventSource(sseUrl);

      sseEventSource.onopen = () => {
        updateStatusBadge('online', `Connected to Server (${cfg.serverIp})`);
        updateTopbarIndicator(true);
        if (cfg.autoSync) {
          syncNow(true);
        }
      };

      sseEventSource.onmessage = async (e) => {
        try {
          const payload = JSON.parse(e.data);
          handleIncomingSyncEvent(payload);
        } catch(err) {
          console.warn('Error parsing SSE sync message:', err);
        }
      };

      sseEventSource.onerror = () => {
        try { sseEventSource.close(); } catch(e) {}
        sseEventSource = null;
        reconnectTimeout = setTimeout(() => connectLanSSE(cfg), 10000);
      };
    } catch(err) {
      reconnectTimeout = setTimeout(() => connectLanSSE(cfg), 15000);
    }
  }

  async function handleIncomingSyncEvent(payload) {
    const isAR = i18n.getLang() === 'ar';
    const cfg = await getConfig();

    if (payload.event === 'table_updated') {
      const table = payload.table;
      if (cfg.autoSync && cfg.syncTables.includes(table)) {
        // Pull updated table from server
        await pullTableFromServer(table);
        Utils.toast(isAR ? `🔄 تم تحديث جدول (${table}) تلقائياً من السيرفر` : `🔄 Table (${table}) updated in real-time from server`, 'info');
      }
    } else if (payload.event === 'config_updated') {
      if (payload.config && payload.config.syncTables) {
        await DB.setSetting('sync_tables', payload.config.syncTables);
      }
    }
  }

  // ── Pull Table Data from Server ──────────────────────────────────
  async function pullTableFromServer(table) {
    const cfg = await getConfig();
    const baseUrl = getServerBaseUrl(cfg);
    try {
      const q = `?nodeId=${encodeURIComponent(cfg.nodeId)}&name=${encodeURIComponent(cfg.nodeName)}&role=${encodeURIComponent(cfg.role)}`;
      const res = await fetch(`${baseUrl}/api/sync/table/${table}${q}`);
      if (!res.ok) return false;
      const json = await res.json();
      if (json.success && Array.isArray(json.records)) {
        // Reconcile deletions: remove any local record not present in server snapshot
        try {
          const serverIdSet = new Set(
            json.records
              .map(r => (r && r.id != null) ? String(r.id) : null)
              .filter(Boolean)
          );
          const localRecords = await DB.getAll(table);
          if (Array.isArray(localRecords)) {
            for (const localItem of localRecords) {
              const lId = (localItem && localItem.id != null) ? String(localItem.id) : null;
              if (lId && !serverIdSet.has(lId)) {
                try {
                  await DB.remove(table, localItem.id);
                } catch(delErr) {}
              }
            }
          }
        } catch(cleanErr) {
          console.warn(`Error reconciling deletions for table ${table}:`, cleanErr);
        }

        // Bulk upsert into local IndexedDB
        for (const item of json.records) {
          try {
            await DB.put(table, item);
          } catch(e) {}
        }
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table } }));
        return true;
      }
    } catch(err) {
      console.warn(`Error pulling table ${table} from server:`, err);
    }
    return false;
  }

  // ── Publish Table Data to Server (Triggered when Server saves items) ─
  async function publishTableToServer(table) {
    const cfg = await getConfig();
    if (cfg.role !== 'server') return;

    try {
      const records = (await DB.getAll(table)) || [];
      const baseUrl = getServerBaseUrl(cfg);
      await fetch(`${baseUrl}/api/sync/table/${table}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ records })
      });
    } catch(err) {
      console.warn(`Error publishing table ${table}:`, err);
    }
  }

  async function publishAllTablesToServer() {
    const cfg = await getConfig();
    if (cfg.role !== 'server') return;
    for (const tbl of (cfg.syncTables || DEFAULT_TABLES)) {
      await publishTableToServer(tbl);
    }
  }

  // Hook called anywhere in the app when catalog items, customers, or transactions are edited
  async function notifyChange(table, item) {
    const cfg = await getConfig();
    if (cfg.role === 'server') {
      if (cfg.autoSync) {
        await publishTableToServer(table);
      }
    }
    // Automatically propagate single product update to Supabase Cloud for remote branches and storefront
    if (table === 'items' && item && window.OnlineOrders && typeof OnlineOrders.syncSingleProductToCloud === 'function') {
      OnlineOrders.syncSingleProductToCloud(item);
    }
    // Automatically propagate customer updates to Cloud
    if (table === 'customers' && window.OnlineOrders && typeof OnlineOrders.syncCustomersToCloud === 'function') {
      OnlineOrders.syncCustomersToCloud();
    }
    // Automatically sync sales to cloud
    if (table === 'sales' && window.OnlineOrders && typeof OnlineOrders.syncPosSalesToCloud === 'function') {
      OnlineOrders.syncPosSalesToCloud();
    }

    if (window.OnlineOrders && typeof OnlineOrders.broadcastCloudUpdate === 'function') {
      const desc = (item && (item.name || item.barcode)) ? (item.name || item.barcode) : table;
      OnlineOrders.broadcastCloudUpdate(table, desc);
    }

    const nowIso = new Date().toISOString();
    localStorage.setItem('rs_last_cloud_sync', nowIso);
    if (typeof DB !== 'undefined') {
      try { await DB.setSetting('last_cloud_sync_time', nowIso); } catch(e) {}
    }
    const timeEl = document.getElementById('sync-last-cloud-time');
    if (timeEl) timeEl.textContent = formatSyncTime(nowIso);
  }

  // ── Push Local Transactions to Server ────────────────────────────
  async function pushLocalTransactions() {
    const cfg = await getConfig();
    if (cfg.role === 'server') return true; // Server doesn't push to itself

    const baseUrl = getServerBaseUrl(cfg);
    try {
      const allSales = (await DB.getAll('sales')) || [];
      const allCashbox = (await DB.getAll('cashbox_sessions')) || [];

      // Filter recent sales (e.g. past 14 days) or sales matching this branch/node
      const localSales = allSales.filter(s => s.branch_id === cfg.branchId || s.terminal_id === cfg.nodeId || !s.syncNodeId);
      const localCashbox = allCashbox.filter(cb => cb.branch_id === cfg.branchId || cb.terminal_id === cfg.nodeId || !cb.syncNodeId);

      if (localSales.length === 0 && localCashbox.length === 0) return true;

      const res = await fetch(`${baseUrl}/api/sync/push-transactions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nodeId: cfg.nodeId,
          branchId: cfg.branchId,
          sales: localSales,
          cashboxSessions: localCashbox
        })
      });
      return res.ok;
    } catch(err) {
      console.warn('Error pushing local transactions to server:', err);
      return false;
    }
  }

  // ── Full Sync Now Action ─────────────────────────────────────────
  async function syncNow(silent = false) {
    if (isSyncing) return;
    isSyncing = true;
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const cfg = await getConfig();
    const btn = document.getElementById('btn-sync-now');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = `<span class="spinner" style="width:14px;height:14px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px"></span> ${isAR ? 'جارِ المزامنة...' : 'Syncing...'}`;
    }

    try {
      let cloudImportedCount = 0;
      if (cfg.role === 'server') {
        // Server publishes fresh snapshots of enabled tables
        await publishAllTablesToServer();
        if (window.OnlineOrders) {
          const ooCfg = (typeof OnlineOrders.getConfig === 'function') ? await OnlineOrders.getConfig() : null;
          if (ooCfg && ooCfg.slug) {
            if (typeof OnlineOrders.syncCustomersToCloud === 'function') await OnlineOrders.syncCustomersToCloud();
          }
        }
      } else {
        // 1. Try pulling from LAN Server if configured and not 127.0.0.1
        let pulledFromLan = false;
        if (cfg.serverIp && cfg.serverIp !== '127.0.0.1') {
          for (const tbl of (cfg.syncTables || DEFAULT_TABLES)) {
            const ok = await pullTableFromServer(tbl);
            if (ok && tbl === 'items') pulledFromLan = true;
          }
          await pushLocalTransactions();
        }

        // 2. Pure Cloud Sync via Supabase: Pull allowed catalog, categories, & customers from Cloud
        if (!pulledFromLan && window.OnlineOrders) {
          const ooCfg = (typeof OnlineOrders.getConfig === 'function') ? await OnlineOrders.getConfig() : null;
          if (ooCfg && ooCfg.slug) {
            // In silent periodic mode, pull fast delta (<100ms) to avoid downloading full catalog
            if (silent && typeof OnlineOrders.pullCloudDelta === 'function') {
              const deltaRes = await OnlineOrders.pullCloudDelta();
              if (deltaRes && deltaRes.success) cloudImportedCount = deltaRes.count || 0;
            } else if (typeof OnlineOrders.pullCatalogFromCloud === 'function') {
              const cloudRes = await OnlineOrders.pullCatalogFromCloud({ syncTables: cfg.syncTables });
              if (cloudRes && cloudRes.success) {
                cloudImportedCount = cloudRes.count || 0;
              }
            }
            // Pull customers from cloud if allowed
            if (cfg.syncTables.includes('customers') && typeof OnlineOrders.pullCustomersFromCloud === 'function') {
              await OnlineOrders.pullCustomersFromCloud();
            }
          }
        }
      }

      // Also trigger cloud sync to Supabase (Sales, Cashbox, Customers, and Branch Heartbeat)
      if (window.OnlineOrders) {
        try {
          if (typeof OnlineOrders.heartbeatBranchToCloud === 'function') {
            await OnlineOrders.heartbeatBranchToCloud(cfg);
          }
          if (typeof OnlineOrders.syncPosSalesToCloud === 'function') await OnlineOrders.syncPosSalesToCloud();
          if (typeof OnlineOrders.syncCashboxStatusToCloud === 'function') await OnlineOrders.syncCashboxStatusToCloud();
          if (cfg.syncTables.includes('customers') && typeof OnlineOrders.syncCustomersToCloud === 'function') {
            await OnlineOrders.syncCustomersToCloud();
          }
          if (typeof OnlineOrders.fetchOrders === 'function') await OnlineOrders.fetchOrders(true);
        } catch(cloudErr) {
          console.warn('Cloud sync error during syncNow:', cloudErr);
        }
      }

      const nowIso = new Date().toISOString();
      localStorage.setItem('rs_last_cloud_sync', nowIso);
      if (typeof DB !== 'undefined') {
        try { await DB.setSetting('last_cloud_sync_time', nowIso); } catch(e) {}
      }
      
      const timeEl = document.getElementById('sync-last-cloud-time');
      if (timeEl) timeEl.textContent = formatSyncTime(nowIso);

      if (!silent) {
        const extraMsg = cloudImportedCount > 0 ? (isAR ? ` (تم استيراد ${cloudImportedCount} صنفاً من السحابة)` : ` (${cloudImportedCount} items downloaded from Cloud)`) : '';
        Utils.toast(isAR ? `✅ اكتملت المزامنة الشاملة بنجاح مع السحابة المركزية${extraMsg}!` : `✅ Full sync completed with Central Cloud${extraMsg}!`, 'success');
      }
      updateStatusBadge('online', isAR ? 'متصل ومحدث' : 'Connected & Synced');
    } catch(err) {
      console.error('Sync failed:', err);
      if (!silent) Utils.toast(isAR ? '❌ فشلت المزامنة: ' + err.message : '❌ Sync failed: ' + err.message, 'danger');
      updateStatusBadge('offline', isAR ? 'تعذر الاتصال' : 'Connection failed');
    } finally {
      isSyncing = false;
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `🔄 ${isAR ? 'مزامنة الآن' : 'Sync Now'}`;
      }
    }
  }

  function formatSyncTime(isoStr) {
    if (!isoStr) return '—';
    try {
      const d = new Date(isoStr);
      if (isNaN(d.getTime())) return '—';
      const now = new Date();
      const diffSec = Math.floor((now.getTime() - d.getTime()) / 1000);
      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
      if (diffSec < 30) return isAR ? 'الآن (منذ لحظات)' : 'Just now';
      if (diffSec < 120) return isAR ? 'قبل دقيقة' : '1 min ago';
      if (diffSec < 3600) return isAR ? `قبل ${Math.floor(diffSec / 60)} دقيقة` : `${Math.floor(diffSec / 60)} mins ago`;
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' (' + d.toLocaleDateString() + ')';
    } catch(e) { return isoStr; }
  }

  async function updateTopbarIndicator(isConnected, labelText, forceHide = false) {
    const el = document.getElementById('topbar-branch-sync-indicator');
    if (!el) return;
    const cfg = await getConfig();

    // If POS is set up as a server: DO NOT SHOW THE CIRCLE AT ALL
    if (forceHide || cfg.role === 'server') {
      el.style.display = 'none';
      return;
    }

    // POS is set as branch or pos workstation: show circle
    el.style.display = 'inline-flex';
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? (i18n.getLang() === 'ar') : true;
    const dot = document.getElementById('topbar-branch-sync-dot');
    const txt = document.getElementById('topbar-branch-sync-text');

    if (isConnected) {
      if (dot) {
        dot.style.background = '#10b981';
        dot.style.boxShadow = '0 0 8px rgba(16, 185, 129, 0.9)';
      }
      if (txt) {
        txt.textContent = labelText || (isAR ? 'متصل بالسيرفر' : 'Connected to Server');
        txt.style.color = 'var(--text-primary)';
      }
      el.style.background = 'rgba(16, 185, 129, 0.12)';
      el.style.borderColor = 'rgba(16, 185, 129, 0.4)';
      el.title = isAR ? `متصل بالسيرفر المركزي (${cfg.serverIp})` : `Connected to Central Server (${cfg.serverIp})`;
    } else {
      if (dot) {
        dot.style.background = '#ef4444';
        dot.style.boxShadow = '0 0 8px rgba(239, 68, 68, 0.9)';
      }
      if (txt) {
        txt.textContent = labelText || (isAR ? 'غير متصل بالسيرفر' : 'Server Disconnected');
        txt.style.color = '#ef4444';
      }
      el.style.background = 'rgba(239, 68, 68, 0.12)';
      el.style.borderColor = 'rgba(239, 68, 68, 0.4)';
      el.title = isAR ? `تعذر الاتصال بالسيرفر المركزي (${cfg.serverIp})` : `Disconnected from Server (${cfg.serverIp})`;
    }
  }

  function updateStatusBadge(state, text) {
    const el = document.getElementById('sync-live-status-pill');
    if (el) {
      el.className = `status-pill ${state}`;
      el.innerHTML = `<span class="dot"></span> <span>${text}</span>`;
    }
    if (state === 'online') {
      updateTopbarIndicator(true, text);
    } else if (state === 'offline') {
      updateTopbarIndicator(false, text);
    }
  }

  // ── Render Management Page ───────────────────────────────────────
  async function render(container) {
    if (autoRefreshInterval) {
      clearInterval(autoRefreshInterval);
      autoRefreshInterval = null;
    }

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const cfg = await getConfig();

    // Fetch cloud settings & last sync timestamp
    let cloudSlug = 'shop101';
    let cloudUrl = 'https://mcebwpiswvwqcdwjpagy.supabase.co';
    let cloudKey = '';
    let autoPrint = false;
    let cloudPin = localStorage.getItem('redshark_cloud_pin') || '';
    let lastSyncTime = localStorage.getItem('rs_last_cloud_sync') || '';

    if (typeof DB !== 'undefined') {
      try {
        cloudSlug = await DB.getSetting('online_store_shop_slug', 'shop101');
        cloudUrl = await DB.getSetting('online_store_url', 'https://mcebwpiswvwqcdwjpagy.supabase.co');
        cloudKey = await DB.getSetting('online_store_key', '');
        autoPrint = await DB.getSetting('online_store_autoprint', false);
        cloudPin = await DB.getSetting('online_store_cloud_pin', cloudPin || (cloudSlug === 'shop101' ? '1234' : ''));
        const dbLastSync = await DB.getSetting('last_cloud_sync_time', null);
        if (dbLastSync) lastSyncTime = dbLastSync;
      } catch(e) {}
    }

    // Fetch server status info
    let serverInfo = { localIp: '127.0.0.1', port: 3000, serverUrl: '', connectedClients: 0 };
    try {
      const res = await fetch('/api/sync/status', { signal: AbortSignal.timeout(1500) });
      if (res.ok) serverInfo = await res.json();
    } catch(e) {}

    // Fetch registered nodes (Local LAN nodes)
    let registeredNodes = [];
    try {
      const res = await fetch('/api/sync/nodes', { signal: AbortSignal.timeout(1500) });
      if (res.ok) {
        const j = await res.json();
        registeredNodes = j.nodes || [];
      }
    } catch(e) {}

    // Merge with Cloud-Registered Remote Branches
    if (window.OnlineOrders && typeof OnlineOrders.fetchCloudConnectedBranches === 'function') {
      try {
        const cloudBranches = await OnlineOrders.fetchCloudConnectedBranches();
        for (const cb of cloudBranches) {
          const idx = registeredNodes.findIndex(n => n.nodeId === cb.nodeId);
          if (idx >= 0) {
            registeredNodes[idx] = {
              ...registeredNodes[idx],
              ...cb,
              ip: cb.ip || 'Cloud Supabase (Internet)',
              isOnline: cb.isOnline || registeredNodes[idx].isOnline
            };
          } else {
            registeredNodes.push({
              ...cb,
              ip: cb.ip || 'Cloud Supabase (Internet)'
            });
          }
        }
      } catch(e) {}
    }

    const roleBadgeHtml = cfg.role === 'server'
      ? `<span class="badge badge-success" style="font-size:0.85rem;padding:6px 14px;font-weight:900;border-radius:10px;box-shadow:0 2px 8px rgba(16,185,129,0.3)">🖥️ ${isAR ? 'الخادم الرئيسي (Main Server / HQ)' : 'Main Server / HQ'}</span>`
      : (cfg.role === 'branch'
        ? `<span class="badge badge-warning" style="font-size:0.85rem;padding:6px 14px;font-weight:900;border-radius:10px">🏬 ${isAR ? 'فرع خارجي (Remote Branch)' : 'Remote Branch'}</span>`
        : `<span class="badge badge-info" style="font-size:0.85rem;padding:6px 14px;font-weight:900;border-radius:10px">💻 ${isAR ? 'نقطة بيع ثانية (Local POS)' : 'Secondary POS'}</span>`);

    const formattedSyncTime = formatSyncTime(lastSyncTime);

    container.innerHTML = `
      <!-- UNIFIED HEADER & STATUS BAR -->
      <div class="card mb-4" style="background:linear-gradient(135deg, rgba(37,99,235,0.08) 0%, rgba(16,185,129,0.06) 100%);border:1.5px solid rgba(37,99,235,0.25);border-radius:16px;padding:20px">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px">
          <div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:6px">
              <span style="font-size:1.8rem">🌐</span>
              <h2 style="margin:0;font-size:1.35rem;font-weight:900">
                ${isAR ? 'الربط السحابي، الفروع، والمتجر الإلكتروني' : 'Cloud Sync, Branch Network & Online Storefront'}
              </h2>
              ${roleBadgeHtml}
            </div>
            <p style="margin:0;font-size:0.85rem;color:var(--text-muted);line-height:1.4">
              ${isAR 
                ? 'إدارة الربط المركزي مع Supabase والفروع المتعددة والمتجر السحابي بنفس المعرّف (Slug) لرؤية التقارير الشاملة.' 
                : 'Centralized Supabase cloud sync, multi-branch network & storefront sharing the same tenant slug.'}
            </p>
          </div>

          <!-- Quick Action Buttons -->
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <!-- Last Cloud Sync Badge -->
            <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:12px;padding:8px 14px;display:flex;align-items:center;gap:8px">
              <span style="font-size:1.1rem">🕒</span>
              <div style="text-align:start">
                <div style="font-size:0.7rem;color:var(--text-muted);font-weight:700">${isAR ? 'آخر مزامنة سحابية' : 'Last Cloud Sync'}</div>
                <div id="sync-last-cloud-time" style="font-size:0.85rem;font-weight:900;color:var(--primary)">${formattedSyncTime}</div>
              </div>
            </div>

            <!-- Sync Now Button -->
            <button id="btn-sync-now" class="btn btn-primary" onclick="BranchSync.syncNow()" style="font-weight:800;padding:9px 18px;display:flex;align-items:center;gap:8px;border-radius:12px">
              🔄 ${isAR ? 'مزامنة شاملة الآن' : 'Sync All Now'}
            </button>

            <!-- Push Catalog Button -->
            <button class="btn btn-secondary" onclick="if(window.OnlineOrders)OnlineOrders.syncCatalogToCloud()" style="font-weight:800;padding:9px 16px;display:flex;align-items:center;gap:8px;border-radius:12px" title="${isAR ? 'رفع الأصناف والأسعار الحالية للمتجر السحابي' : 'Upload POS catalog to storefront'}">
              🚀 ${isAR ? 'تحديث الكتالوج بالسحابة' : 'Push Catalog to Cloud'}
            </button>
          </div>
        </div>
      </div>

      <!-- MAIN CONFIGURATION GRID (2 COLUMNS) -->
      <div class="grid grid-2" style="gap:20px;margin-bottom:24px">
        
        <!-- CARD 1: CLOUD STOREFRONT & SUPABASE (SHARED SLUG) -->
        <div class="card" style="padding:22px;border-radius:16px;border:1px solid var(--border-color)">
          <div class="card-header" style="padding:0 0 14px;margin-bottom:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
            <div class="card-title" style="font-size:1.05rem;font-weight:900">
              ☁️ ${isAR ? 'المتجر الإلكتروني وقاعدة بيانات السحابة (Supabase)' : 'Online Storefront & Cloud Database'}
            </div>
            <span class="badge badge-primary" style="font-size:0.72rem">Central Cloud</span>
          </div>

          <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.3);border-radius:12px;padding:12px 14px;margin-bottom:16px;font-size:0.8rem;line-height:1.4">
            💡 <strong>${isAR ? 'معرّف المتجر الموحد (Store Slug):' : 'Unified Tenant Slug:'}</strong><br>
            <span style="color:var(--text-muted)">
              ${isAR ? 'جميع فروع المحل تتصل بنفس قاعدة البيانات باستخدام هذا المعرّف، مما يتيح لك رؤية تقارير كافة الفروع في صفحة المدير وتطبيق الهاتف.' : 'All branches connect to the same Supabase instance using this Slug, aggregating all sales into one central manager dashboard.'}
            </span>
          </div>

          <div class="form-group" style="margin-bottom:14px">
            <label class="form-label" style="font-weight:800;font-size:0.88rem">
              🏷️ ${isAR ? 'معرّف المتجر الموحد (Shop Slug)' : 'Unified Shop Identifier (Slug)'}
            </label>
            <input type="text" id="cfg-shop-slug" class="form-control" value="${Utils.sanitize(cloudSlug)}" placeholder="e.g. shop101" style="font-weight:900;font-size:1.1rem;font-family:monospace;letter-spacing:1px" oninput="BranchSync.updateStorefrontLinks(this.value)">
            <small style="color:var(--text-muted);font-size:0.72rem">${isAR ? 'المعرّف الموحد للمحل (نفس المعرّف لكافة الفروع)' : 'Unique slug for your merchant tenant (shared across all branches)'}</small>
          </div>

          <!-- Store Cloud PIN (Security Layer) -->
          <div class="form-group" style="margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
              <label class="form-label" style="font-weight:800;font-size:0.88rem;margin:0">
                🔒 ${isAR ? 'رمز الأمان السحابي للمتجر (Store Cloud PIN)' : 'Store Cloud Security PIN / Password'}
              </label>
              <span id="sync-pin-status-badge" class="badge badge-success" style="font-size:0.72rem;${cloudPin ? '' : 'display:none'}">✓ ${isAR ? 'محمي برمز سري' : 'PIN Protected'}</span>
            </div>
            <div style="position:relative">
              <input type="password" id="cfg-shop-pin" class="form-control" value="${Utils.sanitize(cloudPin)}" placeholder="e.g. 1234" style="font-weight:900;font-size:1.1rem;letter-spacing:2px;padding-inline-end:44px">
              <button type="button" onclick="const i=document.getElementById('cfg-shop-pin'); i.type=i.type==='password'?'text':'password'; this.textContent=i.type==='password'?'👁️':'🔒';" style="position:absolute;inset-inline-end:8px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1.1rem;padding:4px">👁️</button>
            </div>
            <small style="color:var(--text-muted);font-size:0.72rem">
              ${isAR ? '🛡️ كلمة مرور المتجر المعينة في بوابة الإدارة. تمنع أي جهاز خارجي من ربط نفس المعرّف أو التدخل في بيانات المحل دون إذن.' : '🛡️ Secret store password. Prevents unauthorized computers from connecting to this slug without owner permission.'}
            </small>
          </div>

          <!-- Direct Links Preview -->
          <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;background:var(--surface-2);border-radius:12px;padding:12px;border:1px solid var(--border-color)">
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.8rem">
              <span style="font-weight:700">🛍️ ${isAR ? 'رابط متجر الزبائن:' : 'Customer Store:'}</span>
              <a href="https://shop.redshark-ai.com/?shop=${encodeURIComponent(cloudSlug)}" id="sync-link-storefront" target="_blank" style="color:var(--primary);font-weight:800;text-decoration:none">
                https://shop.redshark-ai.com/?shop=${cloudSlug} ↗
              </a>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.8rem">
              <span style="font-weight:700">📱 ${isAR ? 'تطبيق المدير للهاتف:' : 'Mobile Admin App:'}</span>
              <a href="https://shop.redshark-ai.com/app?shop=${encodeURIComponent(cloudSlug)}" id="sync-link-adminapp" target="_blank" style="color:var(--primary);font-weight:800;text-decoration:none">
                https://shop.redshark-ai.com/app?shop=${cloudSlug} ↗
              </a>
            </div>
          </div>

          <!-- Auto-Print Toggle -->
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:var(--surface-2);border-radius:10px;margin-bottom:14px">
            <div>
              <div style="font-weight:700;font-size:0.85rem">${isAR ? 'طباعة الطلبات تلقائياً فور وصولها' : 'Auto-Print Incoming Online Orders'}</div>
              <div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'طباعة بون التوصيل مباشرة على طابعة الفواتير' : 'Print delivery slip immediately upon arrival'}</div>
            </div>
            <label class="toggle">
              <input type="checkbox" id="cfg-shop-autoprint" ${autoPrint ? 'checked' : ''}>
              <span class="toggle-slider"></span>
            </label>
          </div>

          <!-- Advanced Supabase Connection (Collapsible) -->
          <details style="background:rgba(0,0,0,0.02);border:1px solid var(--border-color);border-radius:10px;padding:10px;font-size:0.8rem">
            <summary style="font-weight:800;cursor:pointer;color:var(--text-muted)">⚙️ ${isAR ? 'إعدادات الاتصال المتقدمة (Supabase API)' : 'Advanced Supabase API Credentials'}</summary>
            <div style="margin-top:10px;display:flex;flex-direction:column;gap:10px">
              <div>
                <label style="font-size:0.75rem;font-weight:700">${isAR ? 'رابط خادم Supabase:' : 'Supabase Project URL:'}</label>
                <input type="text" id="cfg-shop-url" class="form-control" value="${Utils.sanitize(cloudUrl)}" style="font-family:monospace;font-size:0.8rem">
              </div>
              <div>
                <label style="font-size:0.75rem;font-weight:700">${isAR ? 'مفتاح الوصول (Anon Key - اختياري):' : 'Anon Public API Key (Optional):'}</label>
                <input type="password" id="cfg-shop-key" class="form-control" value="${Utils.sanitize(cloudKey)}" placeholder="Default system key used" style="font-family:monospace;font-size:0.8rem">
              </div>
            </div>
          </details>
        </div>

        <!-- CARD 2: MACHINE ROLE & BRANCH IDENTITY -->
        <div class="card" style="padding:22px;border-radius:16px;border:1px solid var(--border-color)">
          <div class="card-header" style="padding:0 0 14px;margin-bottom:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
            <div class="card-title" style="font-size:1.05rem;font-weight:900">
              ⚙️ ${isAR ? 'دور هذا الجهاز وهوية الفرع' : 'This Machine Role & Station Identity'}
            </div>
            <span class="badge badge-secondary" style="font-size:0.72rem">Local Setup</span>
          </div>

          <div style="margin-bottom:16px">
            <label style="font-size:0.85rem;font-weight:800;margin-bottom:8px;display:block">
              ${isAR ? 'اختر دور هذا الجهاز في المنظومة:' : 'Select This Machine Role:'}
            </label>
            <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:10px">
              <label class="role-selector-btn ${cfg.role === 'server' ? 'active' : ''}" style="cursor:pointer;border:1.5px solid ${cfg.role === 'server' ? 'var(--primary)' : 'var(--border-color)'};border-radius:12px;padding:12px;text-align:center;background:${cfg.role === 'server' ? 'rgba(59,130,246,0.1)' : 'transparent'}">
                <input type="radio" name="node_role" value="server" ${cfg.role === 'server' ? 'checked' : ''} onchange="BranchSync.onRoleChange('server')" style="display:none">
                <div style="font-size:1.5rem;margin-bottom:4px">🖥️</div>
                <div style="font-weight:900;font-size:0.85rem">${isAR ? 'سيرفر رئيسي' : 'Main Server'}</div>
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'الفرع المركزي HQ' : 'Central HQ'}</div>
              </label>

              <label class="role-selector-btn ${cfg.role === 'pos' ? 'active' : ''}" style="cursor:pointer;border:1.5px solid ${cfg.role === 'pos' ? 'var(--primary)' : 'var(--border-color)'};border-radius:12px;padding:12px;text-align:center;background:${cfg.role === 'pos' ? 'rgba(59,130,246,0.1)' : 'transparent'}">
                <input type="radio" name="node_role" value="pos" ${cfg.role === 'pos' ? 'checked' : ''} onchange="BranchSync.onRoleChange('pos')" style="display:none">
                <div style="font-size:1.5rem;margin-bottom:4px">💻</div>
                <div style="font-weight:900;font-size:0.85rem">${isAR ? 'كاشير إضافي' : 'Secondary POS'}</div>
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'بنفس المحل' : 'Same Store'}</div>
              </label>

              <label class="role-selector-btn ${cfg.role === 'branch' ? 'active' : ''}" style="cursor:pointer;border:1.5px solid ${cfg.role === 'branch' ? 'var(--primary)' : 'var(--border-color)'};border-radius:12px;padding:12px;text-align:center;background:${cfg.role === 'branch' ? 'rgba(59,130,246,0.1)' : 'transparent'}">
                <input type="radio" name="node_role" value="branch" ${cfg.role === 'branch' ? 'checked' : ''} onchange="BranchSync.onRoleChange('branch')" style="display:none">
                <div style="font-size:1.5rem;margin-bottom:4px">🏬</div>
                <div style="font-weight:900;font-size:0.85rem">${isAR ? 'فرع خارجي' : 'Remote Branch'}</div>
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR ? 'موقع منفصل' : 'Branch Store'}</div>
              </label>
            </div>
          </div>

          <div class="grid grid-2" style="gap:12px;margin-bottom:14px">
            <div>
              <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'اسم نقطة البيع / الكاشير' : 'Station / POS Name'}</label>
              <input type="text" id="cfg-node-name" class="form-control" value="${Utils.sanitize(cfg.nodeName || 'POS-1')}" placeholder="POS-1">
            </div>
            <div>
              <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'معرّف الفرع (Branch ID)' : 'Branch ID Code'}</label>
              <input type="text" id="cfg-branch-id" class="form-control" value="${Utils.sanitize(cfg.branchId || 'main')}" placeholder="main, branch-2">
            </div>
          </div>

          <div style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'معرّف الجهاز (Node ID)' : 'Station Node ID'}</label>
            <input type="text" id="cfg-node-id" class="form-control" value="${Utils.sanitize(cfg.nodeId || 'main')}" style="font-family:monospace;font-size:0.85rem">
          </div>

          <!-- Server Network Display (if server) -->
          <div id="server-ip-box" style="display:${cfg.role === 'server' ? 'block' : 'none'};background:rgba(59,130,246,0.06);border:1.5px solid rgba(59,130,246,0.25);padding:12px 14px;border-radius:12px">
            <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:4px">${isAR ? 'عنوان هذا السيرفر في الشبكة المحلية (LAN):' : 'Main Server LAN IP:'}</div>
            <div style="font-size:1.15rem;font-weight:900;font-family:monospace;color:var(--primary)">
              http://${serverInfo.localIp}:${serverInfo.port}
            </div>
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">
              ${isAR ? 'المحطات المتصلة حالياً بالسيرفر بالوقت الفعلي:' : 'Connected live stations:'} <strong>${serverInfo.connectedClients}</strong>
            </div>
          </div>

          <!-- Client IP setup (if pos or branch) -->
          <div id="client-ip-box" style="display:${cfg.role === 'server' ? 'none' : 'block'};background:rgba(255,255,255,0.04);padding:14px;border-radius:12px;border:1px dashed var(--border-color)">
            <div style="background:rgba(16,185,129,0.08);border:1.5px solid rgba(16,185,129,0.3);padding:10px 14px;border-radius:10px;margin-bottom:12px;display:flex;align-items:center;gap:10px">
              <span style="font-size:1.4rem">☁️</span>
              <div>
                <div style="font-weight:900;color:var(--success);font-size:0.85rem">
                  ${isAR ? 'المزامنة السحابية المباشرة مفعلة بالكامل عبر الإنترنت' : 'Direct Cloud Sync Active (Online via Supabase)'}
                </div>
                <div style="font-size:0.75rem;color:var(--text-muted)">
                  ${isAR ? 'يتصل فرعك تلقائياً بالسحابة المركزية باستخدام معرف المتجر (shop101). لا حاجة لعنوان IP إلا إذا كان الجهازان متصلين بنفس الراوتر المحلي.' : 'This branch automatically syncs via central cloud using your shop slug (shop101). Server IP is not needed over the internet.'}
                </div>
              </div>
            </div>

            <label class="form-label" style="font-weight:800;color:var(--text-secondary);font-size:0.8rem">
              🌐 ${isAR ? 'اختياري: عنوان السيرفر المحلي (فقط عند الاتصال بنفس شبكة الراوتر):' : 'Optional: Local Server IP (Only needed if sharing the same local Wi-Fi router):'}
            </label>
            <div style="display:flex;gap:8px;align-items:center">
              <input type="text" id="cfg-server-ip" class="form-control" value="${Utils.sanitize(cfg.serverIp)}" placeholder="Leave empty for Cloud Sync, or enter 192.168.1.75" style="font-family:monospace;font-size:0.9rem;font-weight:700">
              <input type="number" id="cfg-server-port" class="form-control" value="${cfg.serverPort || 3000}" style="width:80px;font-family:monospace">
              <button class="btn btn-secondary btn-sm" onclick="BranchSync.testServerConnection()" style="white-space:nowrap;font-weight:700">
                ⚡ ${isAR ? 'اختبار' : 'Test'}
              </button>
            </div>
            <div style="font-size:0.73rem;color:var(--text-muted);margin-top:6px;line-height:1.4">
              💡 ${isAR ? 'إذا كانت الفروع في مناطق مختلفة، اترك الحقل فارغاً واعتمد على المزامنة السحابية بنقرة زر (Sync Now).' : 'If branches are in different locations/networks, leave IP empty and simply click "Sync Now" to sync over the cloud.'}
            </div>
          </div>
        </div>

      </div>

      <!-- CARD 2.5: SELECT TABLES TO SYNC WITH BRANCHES -->
      <div class="card mb-4" style="padding:22px;border-radius:16px;border:1px solid var(--border-color);background:var(--surface)">
        <div class="card-header" style="padding:0 0 14px;margin-bottom:16px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <div>
            <div class="card-title" style="font-size:1.05rem;font-weight:900">
              📋 ${isAR ? 'تحديد جداول المزامنة مع الفروع (Tables to Sync)' : 'Branch Tables Synchronization Selection'}
            </div>
            <div style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">
              ${isAR 
                ? 'على سحابة Supabase، يتم حفظ ومزامنة كافة الجداول والمبيعات. هنا يمكنك تحديد ما يحق لهذا الفرع استلامه وتحديثه.' 
                : 'Supabase cloud always syncs all sales, cashbox & tables. Here you can choose which tables this branch receives.'}
            </div>
          </div>
          <span class="badge badge-primary" style="font-size:0.75rem;font-weight:700">
            ${isAR ? 'تحكم كامل بالجداول' : 'Branch Scope'}
          </span>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:12px;margin-bottom:12px">
          ${[
            { id: 'items', icon: '🏷️', nameAr: 'الأصناف والأسعار', nameEn: 'Items & Prices', descAr: 'مزامنة كافة المنتجات، الباركودات، وأسعار البيع', descEn: 'Sync all products, barcodes & prices' },
            { id: 'categories', icon: '📂', nameAr: 'التصنيفات والمجموعات', nameEn: 'Categories', descAr: 'مزامنة شجرة التصنيفات وأقسام المنتجات', descEn: 'Sync category hierarchy & sections' },
            { id: 'warehouses', icon: '🏬', nameAr: 'الفروع والمستودعات', nameEn: 'Stores & Branches', descAr: 'مزامنة بطاقات الفروع والمستودعات والتخصيص', descEn: 'Sync branch profiles & store locations' },
            { id: 'stock_transfers', icon: '🔄', nameAr: 'تحويلات المخزون بين الفروع', nameEn: 'Stock Transfers', descAr: 'مزامنة إيصالات وسجلات تحويل البضاعة', descEn: 'Sync inter-branch stock transfers' },
            { id: 'customers', icon: '👥', nameAr: 'الزبائن والعملاء والذمم', nameEn: 'Customers & Balances', descAr: 'مزامنة حسابات العملاء، الديون، وأرقام الهواتف', descEn: 'Sync customer accounts & balances' },
            { id: 'offers', icon: '🎁', nameAr: 'العروض والخصومات', nameEn: 'Offers & Promotions', descAr: 'مزامنة حملات الخصم والأسعار الترويجية', descEn: 'Sync promotional pricing & discounts' }
          ].map(t => {
            const checked = (cfg.syncTables || DEFAULT_TABLES).includes(t.id);
            return `
              <label style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:12px;border:1.5px solid ${checked ? 'var(--primary)' : 'var(--border-color)'};background:${checked ? 'rgba(59,130,246,0.06)' : 'var(--surface-2)'};cursor:pointer">
                <input type="checkbox" class="sync-table-checkbox" value="${t.id}" ${checked ? 'checked' : ''} style="margin-top:4px;width:18px;height:18px;cursor:pointer">
                <div>
                  <div style="font-weight:900;font-size:0.88rem;color:var(--text);display:flex;align-items:center;gap:6px">
                    <span>${t.icon}</span>
                    <span>${isAR ? t.nameAr : t.nameEn}</span>
                  </div>
                  <div style="font-size:0.73rem;color:var(--text-muted);margin-top:3px;line-height:1.3">
                    ${isAR ? t.descAr : t.descEn}
                  </div>
                </div>
              </label>
            `;
          }).join('')}
        </div>
      </div>

      <!-- CARD 3: REGISTERED STATIONS & BRANCHES (SERVER ONLY) -->
      ${cfg.role === 'server' ? `
      <div class="card mb-4" style="padding:22px;border-radius:16px;border:1px solid var(--border-color)">
        <div class="card-header" style="padding:0 0 14px;margin-bottom:14px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <div>
            <div class="card-title" style="font-size:1.05rem;font-weight:900">📡 ${isAR ? 'الفروع ونقاط البيع المتصلة بالسيرفر' : 'Connected Branch Stations & POS Terminals'}</div>
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'مراقبة حالة اتصال ومزامنة المحطات في الوقت الفعلي' : 'Real-time connectivity and transactions monitor'}</div>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-secondary btn-sm" onclick="BranchSync.refreshNodesTable()" style="font-weight:700">🔄 ${isAR ? 'تحديث القائمة' : 'Refresh'}</button>
            <button class="btn btn-primary btn-sm" onclick="BranchSync.openAddNodeModal()" style="font-weight:700">➕ ${isAR ? 'تسجيل محطة يدوياً' : 'Add Station'}</button>
          </div>
        </div>

        <div style="overflow-x:auto">
          <table class="table" style="width:100%;font-size:0.85rem">
            <thead>
              <tr style="background:var(--surface-2)">
                <th>${isAR ? 'معرف الجهاز' : 'Node ID'}</th>
                <th>${isAR ? 'الاسم' : 'Name'}</th>
                <th>${isAR ? 'النوع' : 'Role'}</th>
                <th>${isAR ? 'عنوان IP' : 'IP Address'}</th>
                <th>${isAR ? 'حالة الاتصال' : 'Status'}</th>
                <th>${isAR ? 'آخر ظهور' : 'Last Seen'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody id="sync-nodes-tbody">
              ${registeredNodes.length === 0 ? `
                <tr><td colspan="7" style="text-align:center;padding:26px;color:var(--text-muted)">${isAR ? 'لا توجد محطات إضافية متصلة حالياً. هذا الجهاز يعمل كسيرفر رئيسي.' : 'No additional stations connected yet.'}</td></tr>
              ` : registeredNodes.map(n => `
                <tr>
                  <td style="font-family:monospace;font-weight:800">${n.nodeId}</td>
                  <td style="font-weight:700">${n.name || '—'}</td>
                  <td><span class="badge ${n.role==='branch'?'badge-warning':'badge-info'}">${n.role==='branch'?(isAR?'فرع':'Branch'):(isAR?'نقطة بيع':'POS')}</span></td>
                  <td style="font-family:monospace;color:var(--primary)">${n.ip || '—'}</td>
                  <td>
                    <span class="badge ${n.isOnline?'badge-success':'badge-secondary'}" style="display:inline-flex;align-items:center;gap:6px">
                      <span style="width:6px;height:6px;border-radius:50%;background:${n.isOnline?'#10b981':'#6b7280'}"></span>
                      ${n.isOnline?(isAR?'متصل الآن':'Online'):(isAR?'غير متصل':'Offline')}
                    </span>
                  </td>
                  <td style="font-size:0.8rem;color:var(--text-muted)">${n.lastSeen ? new Date(n.lastSeen).toLocaleTimeString() : '—'}</td>
                  <td style="text-align:center">
                    <button class="btn btn-secondary btn-sm" onclick="BranchSync.pingNode('${n.nodeId}', '${n.ip}')" title="Refresh">🔄</button>
                    <button class="btn btn-danger btn-sm" onclick="BranchSync.deleteNode('${n.nodeId}')" title="Delete">🗑️</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
      ` : ''}

      <!-- BOTTOM UNIFIED SAVE BUTTON -->
      <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:16px;padding:18px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;box-shadow:0 4px 14px rgba(0,0,0,0.05)">
        <div style="font-size:0.85rem;color:var(--text-muted)">
          ℹ️ ${isAR ? 'حفظ كافة إعدادات السيرفر، الفروع، والمتجر الإلكتروني في قاعدة البيانات بنقرة واحدة.' : 'Saves all Cloud Supabase, Storefront and Branch settings in one click.'}
        </div>
        <button class="btn btn-primary" onclick="BranchSync.saveSettings()" style="font-weight:900;padding:12px 28px;font-size:1rem;border-radius:12px;box-shadow:0 4px 14px rgba(37,99,235,0.3)">
          💾 ${isAR ? 'حفظ كافة الإعدادات والربط السحابي' : 'Save All Cloud & Branch Settings'}
        </button>
      </div>
    `;

    // Start 15s table refresher
    autoRefreshInterval = setInterval(refreshNodesTable, 15000);
  }

  function updateStorefrontLinks(slug) {
    const s = encodeURIComponent((slug || '').trim() || 'shop101');
    const stLink = document.getElementById('sync-link-storefront');
    if (stLink) {
      stLink.href = 'https://shop.redshark-ai.com/?shop=' + s;
      stLink.textContent = 'https://shop.redshark-ai.com/?shop=' + (slug || 'shop101') + ' ↗';
    }
    const admLink = document.getElementById('sync-link-adminapp');
    if (admLink) {
      admLink.href = 'https://shop.redshark-ai.com/app?shop=' + s;
      admLink.textContent = 'https://shop.redshark-ai.com/app?shop=' + (slug || 'shop101') + ' ↗';
    }
  }

  // ── Auto-refresh live stations table ──────────────────────────────
  async function refreshNodesTable() {
    const isAR = i18n.getLang() === 'ar';
    try {
      const [resNodes, resStatus] = await Promise.all([
        fetch('/api/sync/nodes'),
        fetch('/api/sync/status')
      ]);

      if (resStatus.ok) {
        const s = await resStatus.json();
        const cntEl = document.getElementById('sync-connected-clients-count');
        if (cntEl) {
          cntEl.innerHTML = isAR
            ? `المحطات المتصلة حالياً بالسيرفر في الوقت الفعلي: <strong style="color:var(--primary);font-size:0.95rem">${s.connectedClients}</strong>`
            : `Active live connected client stations: <strong style="color:var(--primary);font-size:0.95rem">${s.connectedClients}</strong>`;
        }
      }

      if (resNodes.ok) {
        const data = await resNodes.json();
        let nodes = data.nodes || [];

        // Merge with live Cloud-Connected Remote Branches from Supabase
        if (window.OnlineOrders && typeof OnlineOrders.fetchCloudConnectedBranches === 'function') {
          try {
            const cloudBranches = await OnlineOrders.fetchCloudConnectedBranches();
            for (const cb of cloudBranches) {
              const idx = nodes.findIndex(n => n.nodeId === cb.nodeId);
              if (idx >= 0) {
                nodes[idx] = {
                  ...nodes[idx],
                  ...cb,
                  // If cloud reports it online or has newer lastSeen, reflect it
                  isOnline: cb.isOnline || nodes[idx].isOnline,
                  ip: cb.ip || 'Cloud Supabase (Internet)'
                };
              } else {
                nodes.push({
                  ...cb,
                  ip: cb.ip || 'Cloud Supabase (Internet)'
                });
              }
            }
          } catch(e) {}
        }

        const tbody = document.getElementById('sync-nodes-tbody');
        if (tbody) {
          if (nodes.length === 0) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted)">${isAR ? 'لا توجد محطات مسجلة بعد. عند اتصال أي نقطة بيع أو فرع بالسيرفر ستظهر هنا تلقائياً.' : 'No stations registered yet.'}</td></tr>`;
          } else {
            tbody.innerHTML = nodes.map(n => `
              <tr>
                <td style="font-family:monospace;font-weight:800">${n.nodeId}</td>
                <td style="font-weight:700">${n.name || '—'}</td>
                <td>
                  <span class="badge ${n.role === 'branch' ? 'badge-warning' : 'badge-info'}" style="font-size:0.75rem">
                    ${n.role === 'branch' ? (isAR ? 'فرع' : 'Branch') : (isAR ? 'نقطة بيع' : 'POS')}
                  </span>
                </td>
                <td style="font-family:monospace;color:var(--primary)">${n.ip || '—'}</td>
                <td>
                  <span class="badge ${n.isOnline ? 'badge-success' : 'badge-secondary'}" style="display:inline-flex;align-items:center;gap:6px">
                    <span style="width:6px;height:6px;border-radius:50%;background:${n.isOnline ? '#10b981' : '#6b7280'}"></span>
                    ${n.isOnline ? (isAR ? 'متصل الآن' : 'Online') : (isAR ? 'غير متصل' : 'Offline')}
                  </span>
                </td>
                <td style="font-size:0.8rem;color:var(--text-muted)">${n.lastSeen ? new Date(n.lastSeen).toLocaleTimeString() : '—'}</td>
                <td style="text-align:center">
                  <button class="btn btn-secondary btn-sm" onclick="BranchSync.pingNode('${n.nodeId}', '${n.ip}')" title="Refresh">🔄</button>
                  <button class="btn btn-danger btn-sm" onclick="BranchSync.deleteNode('${n.nodeId}')" title="Delete">🗑️</button>
                </td>
              </tr>`).join('');
          }
        }
      }
    } catch (e) {}
  }

  // ── Handlers ─────────────────────────────────────────────────────
  function onRoleChange(newRole) {
    document.querySelectorAll('.role-selector-btn').forEach(btn => btn.classList.remove('active'));
    const target = document.querySelector(`input[name="node_role"][value="${newRole}"]`);
    if (target) {
      target.checked = true;
      target.closest('.role-selector-btn')?.classList.add('active');
    }
    const clientBox = document.getElementById('client-ip-box');
    const serverBox = document.getElementById('server-ip-box');
    if (clientBox) clientBox.style.display = newRole === 'server' ? 'none' : 'block';
    if (serverBox) serverBox.style.display = newRole === 'server' ? 'block' : 'none';
  }

  async function saveSettings() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const roleRadio = document.querySelector('input[name="node_role"]:checked');
    const role = roleRadio ? roleRadio.value : 'server';
    const nodeId = document.getElementById('cfg-node-id')?.value.trim() || 'main';
    const nodeName = document.getElementById('cfg-node-name')?.value.trim() || 'Main Store';
    const branchId = document.getElementById('cfg-branch-id')?.value.trim() || 'main';
    const serverIp = document.getElementById('cfg-server-ip')?.value.trim() || '';
    const serverPort = parseInt(document.getElementById('cfg-server-port')?.value) || 3000;

    // Cloud Storefront settings
    const shopSlug = document.getElementById('cfg-shop-slug')?.value.trim() || 'shop101';
    const shopPin = document.getElementById('cfg-shop-pin')?.value.trim() || '';
    const shopUrl = document.getElementById('cfg-shop-url')?.value.trim() || 'https://mcebwpiswvwqcdwjpagy.supabase.co';
    const shopKey = document.getElementById('cfg-shop-key')?.value.trim() || '';
    const shopAutoPrint = document.getElementById('cfg-shop-autoprint')?.checked ?? false;

    // ── SECURITY VERIFICATION: Verify Cloud PIN with Supabase ──
    const apiKey = shopKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg';
    try {
      const checkRes = await fetch(`${shopUrl}/rest/v1/tenants?slug=eq.${encodeURIComponent(shopSlug)}&select=id,shop_name,banner_url`, {
        headers: { "apikey": apiKey, "Authorization": "Bearer " + apiKey },
        signal: AbortSignal.timeout(5000)
      });
      if (checkRes.ok) {
        const tenants = await checkRes.json();
        if (tenants && tenants.length > 0) {
          const t = tenants[0];
          let expectedPwd = '';
          try {
            const bannerObj = typeof t.banner_url === 'string' ? JSON.parse(t.banner_url) : (t.banner_url || {});
            expectedPwd = bannerObj.admin_password || '';
          } catch(e) {}

          if (expectedPwd && expectedPwd.length > 0) {
            if (shopPin !== expectedPwd) {
              const err = isAR
                ? `⛔ خطأ أمني: رمز الأمان السحابي (Store Cloud PIN) غير صحيح للمعرّف "${shopSlug}"! تم منع الربط لحماية بيانات وسجلات المتجر.`
                : `⛔ Security Error: Invalid Store Cloud PIN for "${shopSlug}"! Connection denied.`;
              Utils.toast(err, 'danger', 8000);
              return; // REJECT AND STOP SAVING!
            }
          }
        }
      }
    } catch(secErr) {
      console.warn('[BranchSync] Security PIN check warning:', secErr);
    }

    // Save to DB
    await DB.setSetting('sync_node_role', role);
    await DB.setSetting('sync_node_id', nodeId);
    await DB.setSetting('sync_node_name', nodeName);
    await DB.setSetting('sync_branch_id', branchId);
    await DB.setSetting('sync_server_ip', serverIp);
    await DB.setSetting('sync_server_port', serverPort);
    await DB.setSetting('pos_terminal_name', nodeName);

    await DB.setSetting('online_store_shop_slug', shopSlug);
    await DB.setSetting('online_store_cloud_pin', shopPin);
    localStorage.setItem('redshark_cloud_pin', shopPin);
    await DB.setSetting('online_store_url', shopUrl);
    await DB.setSetting('online_store_key', shopKey);
    await DB.setSetting('online_store_autoprint', shopAutoPrint);

    localStorage.setItem('redshark_shop_slug', shopSlug);
    localStorage.setItem('redshark_pos_terminal', nodeName);

    // Save selected sync tables for this branch
    const tableCheckboxes = document.querySelectorAll('.sync-table-checkbox:checked');
    if (tableCheckboxes.length > 0) {
      const selectedTables = Array.from(tableCheckboxes).map(c => c.value);
      await DB.setSetting('sync_tables', selectedTables);
    }

    // If client, immediately ping server
    if (role !== 'server') {
      try {
        const baseUrl = getServerBaseUrl({ serverIp, serverPort, role });
        const pingUrl = `${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(nodeId)}&name=${encodeURIComponent(nodeName)}&role=${encodeURIComponent(role)}`;
        await fetch(pingUrl, { signal: AbortSignal.timeout(4000) });
      } catch(e) {}
    } else {
      try {
        await fetch('/api/sync/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nodeRole: role, nodeId, nodeName, branchId, serverIp, serverPort, shopSlug, shopUrl })
        });
      } catch(e) {}
    }

    Utils.toast(isAR ? '✅ تم حفظ كافة إعدادات الفرع والربط السحابي بنجاح!' : '✅ All Cloud & Branch settings saved successfully!', 'success');
    await startListener();
    const embedContainer = document.getElementById('settings-branches-embed-container');
    if (embedContainer) {
      render(embedContainer);
    }
  }

  async function saveTablesConfig() {
    const isAR = i18n.getLang() === 'ar';
    const checkboxes = document.querySelectorAll('.sync-table-checkbox:checked');
    const selected = Array.from(checkboxes).map(c => c.value);

    await DB.setSetting('sync_tables', selected);
    try {
      await fetch('/api/sync/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ syncTables: selected })
      });
    } catch(e) {}

    Utils.toast(isAR ? '✅ تم حفظ جداول المزامنة المحددة' : '✅ Sync tables updated', 'success');
    const embedContainer = document.getElementById('settings-branches-embed-container');
    if (embedContainer && embedContainer.offsetParent !== null) {
      render(embedContainer);
    } else {
      App.renderPage('multi-pos');
    }
  }

  async function testServerConnection() {
    const isAR = i18n.getLang() === 'ar';
    const ip = document.getElementById('cfg-server-ip')?.value.trim();
    const port = document.getElementById('cfg-server-port')?.value.trim() || 3000;
    const nodeId = document.getElementById('cfg-node-id')?.value.trim() || 'BRANCH';
    const nodeName = document.getElementById('cfg-node-name')?.value.trim() || nodeId;
    const roleRadio = document.querySelector('input[name="node_role"]:checked');
    const role = roleRadio ? roleRadio.value : 'branch';

    if (!ip) return Utils.toast(isAR ? 'يرجى إدخال عنوان IP أو رابط السيرفر' : 'Please enter server IP or URL', 'warning');

    const baseUrl = getServerBaseUrl({ serverIp: ip, serverPort: port, role });

    try {
      // Send ping with identity so the server registers this node as Online right away
      const pingUrl = `${baseUrl}/api/sync/ping?nodeId=${encodeURIComponent(nodeId)}&name=${encodeURIComponent(nodeName)}&role=${encodeURIComponent(role)}`;
      const res = await fetch(pingUrl, { signal: AbortSignal.timeout(6000) });
      if (res.ok) {
        const j = await res.json();
        Utils.toast(isAR ? `✅ الاتصال ناجح وتم تسجيل الجهاز (${nodeId}) كـ متصل على السيرفر!` : `✅ Connected & Registered node (${nodeId}) on Server!`, 'success');
        updateStatusBadge('online', isAR ? 'متصل بالسيرفر' : 'Connected to Server');
      } else {
        Utils.toast(isAR ? '❌ تعذر الاتصال: السيرفر أعاد استجابة غير صحيحة' : '❌ Server returned error', 'danger');
      }
    } catch(err) {
      Utils.toast(isAR ? `❌ فشل الاتصال بالسيرفر على ${baseUrl}` : `❌ Failed to connect to ${baseUrl}`, 'danger');
    }
  }

  function openAddNodeModal() {
    const modal = document.getElementById('modal-register-node');
    if (modal) modal.style.display = 'flex';
  }

  function closeAddNodeModal() {
    const modal = document.getElementById('modal-register-node');
    if (modal) modal.style.display = 'none';
  }

  async function saveNewNode() {
    const isAR = i18n.getLang() === 'ar';
    const nodeId = document.getElementById('modal-node-id')?.value.trim();
    const name = document.getElementById('modal-node-name')?.value.trim();
    const role = document.getElementById('modal-node-role')?.value || 'pos';
    const ip = document.getElementById('modal-node-ip')?.value.trim();

    if (!nodeId || !name) {
      return Utils.toast(isAR ? 'يرجى إدخال المعرف والاسم' : 'Please enter ID and Name', 'warning');
    }

    try {
      await fetch('/api/sync/nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'save', node: { nodeId, name, role, ip } })
      });
      closeAddNodeModal();
      Utils.toast(isAR ? '✅ تم تسجيل المحطة بنجاح' : '✅ Station registered successfully', 'success');
      refreshNodesTable();
    } catch(err) {
      Utils.toast(isAR ? 'خطأ أثناء حفظ المحطة' : 'Error saving node', 'danger');
    }
  }

  async function deleteNode(nodeId) {
    const isAR = i18n.getLang() === 'ar';
    if (!confirm(isAR ? `هل أنت متأكد من حذف المحطة ${nodeId}؟` : `Are you sure you want to remove station ${nodeId}?`)) return;
    try {
      // 1. Delete from local server registered nodes
      await fetch('/api/sync/nodes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', node: { nodeId } })
      });

      // 2. Delete from Cloud Supabase connected branches (so it doesn't reappear)
      if (window.OnlineOrders && typeof OnlineOrders.removeCloudConnectedBranch === 'function') {
        await OnlineOrders.removeCloudConnectedBranch(nodeId);
      }

      Utils.toast(isAR ? 'تم حذف المحطة بنجاح' : 'Station removed successfully', 'success');
      await refreshNodesTable();
    } catch(e) {
      console.warn('Error deleting node:', e);
      Utils.toast(isAR ? 'خطأ أثناء حذف المحطة' : 'Error removing station', 'danger');
    }
  }

  async function pingNode(nodeId, ip) {
    const isAR = i18n.getLang() === 'ar';
    Utils.toast(isAR ? `📡 فحص اتصال ${nodeId}...` : `📡 Checking ${nodeId}...`, 'info');
    await refreshNodesTable();
  }

  async function toggleAutoSync(enabled) {
    const isAR = i18n.getLang() === 'ar';
    await DB.setSetting('sync_auto_enabled', !!enabled);
    Utils.toast(isAR 
      ? (enabled ? '✅ تم تفعيل المزامنة التلقائية اللحظية والدورية' : '⏸️ تم تعطيل المزامنة التلقائية (المزامنة ستكون يدوية فقط عبر زر مزامنة الآن)')
      : (enabled ? '✅ Real-time auto-sync enabled' : '⏸️ Auto-sync disabled (Manual sync via button only)'),
      'success'
    );
    startListener();
    const container = document.getElementById('page-content');
    if (container && document.getElementById('cfg-auto-sync-toggle')) {
      render(container);
    }
  }

  return {
    getConfig,
    isServer,
    getEffectiveBranchId,
    getEffectiveNodeId,
    startListener,
    updateTopbarIndicator,
    syncNow,
    notifyChange,
    pushLocalTransactions,
    render,
    onRoleChange,
    saveSettings,
    updateStorefrontLinks,
    saveTablesConfig,
    testServerConnection,
    openAddNodeModal,
    closeAddNodeModal,
    saveNewNode,
    deleteNode,
    pingNode,
    refreshNodesTable,
    toggleAutoSync,
    triggerCloudSentinelCheck
  };
})();
