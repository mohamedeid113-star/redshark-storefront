/* ================================================================
   Red Shark POS — Restaurant & F&B Management Module Suite
   Full-Page Hub: Tables Floor, Delivery Dispatch Hub, Takeaway,
   Multi-Station KDS, Reservations, Bill Splitting & Recipe BOM
   ================================================================ */

const Restaurant = (() => {
  let activeTab = 'tables'; // 'tables', 'delivery', 'takeaway', 'kds', 'reservations', 'settings'
  let activeZoneId = 'all';
  let deliveryFilter = 'active'; // 'active', 'cooking', 'ready', 'on_the_way', 'delivered', 'unpaid', 'paid', 'all'
  let deliverySearch = '';
  let takeawayFilter = 'all';
  let kdsStationFilter = 'all';
  let refreshTimer = null;

  // Live real-time cross-tab and cross-component sync
  let syncChannel = null;
  try {
    syncChannel = new BroadcastChannel('redshark_restaurant_live_sync');
    syncChannel.onmessage = () => {
      const openModal = document.querySelector('.modal-overlay.open') || 
                        document.getElementById('new-delivery-modal') ||
                        (document.getElementById('restaurant-modals-container') && document.getElementById('restaurant-modals-container').children.length > 0);
      const isTyping = document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA' || document.activeElement.tagName === 'SELECT');
      if (document.getElementById('restaurant-tab-body') && !openModal && !isTyping) {
        Restaurant.render();
      }
    };
  } catch(e) {}

  function broadcastLiveSync() {
    try {
      if (syncChannel) syncChannel.postMessage({ timestamp: Date.now() });
    } catch(e) {}
  }

  function switchTab(tab) {
    activeTab = tab;
    render();
  }

  async function render() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const content = document.getElementById('page-content');
    if (!content) return;

    // Fetch necessary data
    const zones = await DB.getAll('restaurant_zones') || [];
    const tables = await DB.getAll('restaurant_tables') || [];
    const reservations = await DB.getAll('restaurant_reservations') || [];
    const deliveries = await DB.getAll('restaurant_delivery_orders') || [];
    const activeCurrency = await DB.getSetting('currency_1', 'USD');
    const secCurrency = await DB.getSetting('currency_2', 'LBP');
    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;

    // Counts for Nav Badges
    const occupiedTables = tables.filter(t => t.status === 'occupied' || t.status === 'billed').length;
    const activeDeliveries = deliveries.filter(d => (!d.order_type || d.order_type === 'delivery') && d.status !== 'delivered' && d.status !== 'cancelled').length;
    const unpaidDeliveries = deliveries.filter(d => (!d.order_type || d.order_type === 'delivery') && !d.is_paid && d.payment_status !== 'paid' && d.status !== 'cancelled').length;
    const activeTakeaways = deliveries.filter(d => d.order_type === 'takeaway' && d.status !== 'delivered' && d.status !== 'completed' && d.status !== 'cancelled').length;
    const activeKDSTickets = tables.filter(t => (t.status === 'occupied' || t.status === 'billed') && t.current_order?.items?.length).length;
    const upcomingReservations = reservations.filter(r => r.status === 'confirmed').length;

    content.innerHTML = `
    <div class="animate-fade" style="padding-bottom:40px">
      
      <!-- Top Restaurant Header & Full-Page View Switcher -->
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;flex-wrap:wrap;gap:14px">
        <div>
          <h1 style="font-size:1.6rem;font-weight:900;margin:0;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.8rem">🍽️</span> 
            <span>${isAR ? 'مركز إدارة المطعم والخدمات' : 'Restaurant & F&B Management Hub'}</span>
          </h1>
          <p style="font-size:0.84rem;color:var(--text-muted);margin-top:4px">
            ${isAR ? 'الصالة والطاولات، مركز طلبات الدليفري والسفري، شاشة المطبخ، الحجوزات والتكاليف' : 'Dine-in floor, delivery dispatch hub, takeaway counter, live kitchen KDS & reservations'}
          </p>
        </div>

        <!-- Secondary Action Buttons -->
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
          ${activeTab === 'tables' ? `
            <button class="btn btn-secondary btn-sm" onclick="Restaurant.openMergeTablesModal()" title="${isAR ? 'دمج الطاولات' : 'Merge Tables'}">
              <span>🔗 ${isAR ? 'دمج طاولات' : 'Merge Tables'}</span>
            </button>
            <button class="btn btn-secondary btn-sm" onclick="Restaurant.openZoneForm()">
              <span>🌿 ${isAR ? 'الصالات' : 'Zones'}</span>
            </button>
            <button class="btn btn-primary btn-sm" onclick="Restaurant.openTableForm()">
              <span>➕ ${isAR ? 'طاولة جديدة' : 'New Table'}</span>
            </button>
          ` : activeTab === 'delivery' ? `
            <button class="btn btn-primary btn-sm" onclick="Restaurant.openNewDeliveryModal()" style="font-weight:800">
              <span>➕ ${isAR ? 'طلب دليفري جديد' : 'New Delivery Order'}</span>
            </button>
          ` : activeTab === 'takeaway' ? `
            <button class="btn btn-primary btn-sm" onclick="Restaurant.openQuickTakeawayPOS()" style="font-weight:800">
              <span>🛒 ${isAR ? 'طلب سفري جديد (POS)' : 'New Takeaway Order'}</span>
            </button>
          ` : activeTab === 'reservations' ? `
            <button class="btn btn-primary btn-sm" onclick="Restaurant.openNewReservationForm()" style="font-weight:800">
              <span>➕ ${isAR ? 'تسجيل حجز' : 'Book Table'}</span>
            </button>
          ` : ''}
        </div>
      </div>

      <!-- Main Navigation Tabs Bar -->
      <div style="display:flex;gap:10px;margin-bottom:22px;overflow-x:auto;padding-bottom:6px;border-bottom:1px solid var(--border-color)">
        
        <button class="restaurant-nav-pill ${activeTab === 'tables' ? 'active' : ''}" onclick="Restaurant.switchTab('tables')">
          <span>🍽️ ${isAR ? 'الصالة والطاولات' : 'Dine-In & Tables'}</span>
          ${occupiedTables > 0 ? `<span class="badge" style="background:rgba(239,68,68,0.3);color:#fca5a5">${occupiedTables}</span>` : ''}
        </button>

        <button class="restaurant-nav-pill ${activeTab === 'delivery' ? 'active' : ''}" onclick="Restaurant.switchTab('delivery')">
          <span>🛵 ${isAR ? 'طلبات الدليفري والتوصيل' : 'Delivery Dispatch Hub'}</span>
          ${activeDeliveries > 0 ? `<span class="badge" style="background:rgba(245,158,11,0.3);color:#fde047">${activeDeliveries}</span>` : ''}
          ${unpaidDeliveries > 0 ? `<span class="badge" style="background:rgba(239,68,68,0.4);color:#fca5a5" title="${isAR ? 'غير مدفوع' : 'Unpaid COD'}">💳 ${unpaidDeliveries}</span>` : ''}
        </button>

        <button class="restaurant-nav-pill ${activeTab === 'takeaway' ? 'active' : ''}" onclick="Restaurant.switchTab('takeaway')">
          <span>🛍️ ${isAR ? 'الطلبات السفري (Takeaway)' : 'Takeaway & Pickup'}</span>
          ${activeTakeaways > 0 ? `<span class="badge" style="background:rgba(6,182,212,0.3);color:#67e8f9">${activeTakeaways}</span>` : ''}
        </button>

        <button class="restaurant-nav-pill ${activeTab === 'kds' ? 'active' : ''}" onclick="Restaurant.switchTab('kds')">
          <span>🍳 ${isAR ? 'شاشة المطبخ (KDS)' : 'Kitchen Screen (KDS)'}</span>
          ${activeKDSTickets > 0 ? `<span class="badge" style="background:rgba(16,185,129,0.3);color:#6ee7b7">${activeKDSTickets}</span>` : ''}
        </button>

        <button class="restaurant-nav-pill ${activeTab === 'reservations' ? 'active' : ''}" onclick="Restaurant.switchTab('reservations')">
          <span>📅 ${isAR ? 'سجل الحجوزات' : 'Reservations'}</span>
          ${upcomingReservations > 0 ? `<span class="badge" style="background:rgba(59,130,246,0.3);color:#93c5fd">${upcomingReservations}</span>` : ''}
        </button>

        <button class="restaurant-nav-pill ${activeTab === 'settings' ? 'active' : ''}" onclick="Restaurant.switchTab('settings')">
          <span>⚙️ ${isAR ? 'الوصفات والخيارات' : 'BOM & Modifiers'}</span>
        </button>

      </div>

      <!-- Active Tab Content Renderer -->
      <div id="restaurant-tab-body">
        ${activeTab === 'tables' ? renderTablesView(zones, tables, reservations, activeCurrency, secCurrency, rate, isAR)
        : activeTab === 'delivery' ? renderDeliveryView(deliveries, activeCurrency, secCurrency, rate, isAR)
        : activeTab === 'takeaway' ? renderTakeawayView(deliveries, activeCurrency, secCurrency, rate, isAR)
        : activeTab === 'kds' ? renderKDSView(tables, isAR)
        : activeTab === 'reservations' ? renderReservationsView(reservations, tables, isAR)
        : renderSettingsView(isAR)}
      </div>

      <!-- Modals Container -->
      <div id="restaurant-modals-container"></div>
    </div>`;

    // Periodic timer for table elapsed times & SLA delivery counters
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(() => {
      // Never auto-refresh if a modal is open or the user is typing/interacting with an input
      const openModal = document.querySelector('.modal-overlay.open') || 
                         document.getElementById('new-delivery-modal') ||
                         (document.getElementById('restaurant-modals-container') && document.getElementById('restaurant-modals-container').children.length > 0);
      const isTyping = document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA' || document.activeElement.tagName === 'SELECT');
      
      if (document.getElementById('restaurant-tab-body') && !openModal && !isTyping) {
        Restaurant.render();
      }
    }, 6000);
  }

  // ══════════════════════════════════════════════════════════════════
  // 1. DINE-IN / TABLES VIEW
  // ══════════════════════════════════════════════════════════════════
  function renderTablesView(zones, tables, reservations, activeCurrency, secCurrency, rate, isAR) {
    const filteredTables = activeZoneId === 'all' 
      ? tables 
      : tables.filter(t => String(t.zone_id) === String(activeZoneId));

    const totalTables = tables.length;
    const occupiedTables = tables.filter(t => t.status === 'occupied').length;
    const billedTables = tables.filter(t => t.status === 'billed').length;
    const reservedTables = tables.filter(t => t.status === 'reserved').length;
    const freeTables = tables.filter(t => !t.status || t.status === 'free').length;
    const totalGuests = tables.filter(t => t.status === 'occupied').reduce((sum, t) => sum + (t.current_order?.guest_count || t.guest_count || 2), 0);
    const activeRevenue = tables.filter(t => t.status === 'occupied' || t.status === 'billed').reduce((sum, t) => sum + (t.current_order?.total || 0), 0);

    return `
      <!-- Live Floor Stats Bar -->
      <div class="grid grid-4" style="gap:14px;margin-bottom:20px">
        <div class="card" style="padding:14px 18px;display:flex;align-items:center;gap:14px;border-inline-start:4px solid var(--success)">
          <div style="width:42px;height:42px;border-radius:10px;background:rgba(16,185,129,0.15);color:var(--success);display:flex;align-items:center;justify-content:center;font-size:1.3rem">
            🟢
          </div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'طاولات شاغرة' : 'Available Tables'}</div>
            <div style="font-size:1.4rem;font-weight:900;color:var(--text-primary)">${freeTables} <span style="font-size:0.8rem;color:var(--text-muted);font-weight:500">/ ${totalTables}</span></div>
          </div>
        </div>

        <div class="card" style="padding:14px 18px;display:flex;align-items:center;gap:14px;border-inline-start:4px solid var(--danger)">
          <div style="width:42px;height:42px;border-radius:10px;background:rgba(239,68,68,0.15);color:var(--danger);display:flex;align-items:center;justify-content:center;font-size:1.3rem">
            🔴
          </div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'طاولات مشغولة' : 'Occupied Tables'}</div>
            <div style="font-size:1.4rem;font-weight:900;color:var(--danger)">${occupiedTables} <span style="font-size:0.8rem;color:var(--text-muted);font-weight:500">(${totalGuests} ${isAR ? 'ضيوف' : 'Guests'})</span></div>
          </div>
        </div>

        <div class="card" style="padding:14px 18px;display:flex;align-items:center;gap:14px;border-inline-start:4px solid var(--warning)">
          <div style="width:42px;height:42px;border-radius:10px;background:rgba(245,158,11,0.15);color:var(--warning);display:flex;align-items:center;justify-content:center;font-size:1.3rem">
            🟡
          </div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'حساب مبدئي / محجوز' : 'Billed / Reserved'}</div>
            <div style="font-size:1.4rem;font-weight:900;color:var(--warning)">${billedTables + reservedTables}</div>
          </div>
        </div>

        <div class="card" style="padding:14px 18px;display:flex;align-items:center;gap:14px;border-inline-start:4px solid var(--primary)">
          <div style="width:42px;height:42px;border-radius:10px;background:rgba(239,68,68,0.15);color:var(--primary);display:flex;align-items:center;justify-content:center;font-size:1.3rem">
            💵
          </div>
          <div>
            <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'إجمالي الطلبات الحية' : 'Live Active Revenue'}</div>
            <div style="font-size:1.3rem;font-weight:900;color:var(--primary)">$${activeRevenue.toFixed(2)}</div>
            <div style="font-size:0.7rem;color:var(--text-secondary)">${Utils.formatMoney(Utils.calcSecondaryPrice(activeRevenue, activeCurrency, secCurrency, rate), secCurrency)}</div>
          </div>
        </div>
      </div>

      <!-- Zone Switcher Filter Bar -->
      <div style="display:flex;gap:8px;margin-bottom:20px;overflow-x:auto;padding-bottom:6px;align-items:center">
        <button class="btn ${activeZoneId === 'all' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.switchZone('all')" style="border-radius:10px;font-weight:700">
          <span>🏠 ${isAR ? 'جميع الصالات' : 'All Dining Areas'} (${totalTables})</span>
        </button>
        ${zones.map(z => {
          const countInZone = tables.filter(t => String(t.zone_id) === String(z.id)).length;
          const occInZone = tables.filter(t => String(t.zone_id) === String(z.id) && t.status === 'occupied').length;
          const zName = isAR ? (z.name_ar || z.name) : z.name;
          const isSel = String(activeZoneId) === String(z.id);

          return `
          <button class="btn ${isSel ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.switchZone('${z.id}')" style="border-radius:10px;font-weight:700">
            <span>${z.icon || '🛋️'} ${Utils.sanitize(zName)}</span>
            <span class="badge" style="background:${occInZone > 0 ? 'rgba(239,68,68,0.3)' : 'rgba(255,255,255,0.1)'};color:${occInZone > 0 ? '#fca5a5' : '#cbd5e1'};font-size:0.7rem;margin-inline-start:4px">
              ${occInZone > 0 ? `${occInZone} ${isAR ? 'مشغول' : 'occ'}` : countInZone}
            </span>
          </button>`;
        }).join('')}
      </div>

      <!-- Visual Tables Floor Grid -->
      <div class="grid grid-4" style="gap:16px" id="tables-grid">
        ${filteredTables.map(t => {
          const zoneObj = zones.find(z => String(z.id) === String(t.zone_id));
          const zoneTitle = zoneObj ? (isAR ? (zoneObj.name_ar || zoneObj.name) : zoneObj.name) : '';
          const status = t.status || 'free';
          const order = t.current_order || null;
          const seatedMinutes = t.seated_at ? Math.max(1, Math.round((Date.now() - new Date(t.seated_at).getTime()) / 60000)) : null;

          let borderColor = 'var(--border-color)';
          let statusBadge = `<span class="badge badge-success" style="font-size:0.75rem">🟢 ${isAR ? 'شاغرة' : 'Available'}</span>`;
          let cardBg = 'var(--surface)';

          if (t.merged_with) {
            borderColor = '#a855f7';
            statusBadge = `<span class="badge" style="background:rgba(168,85,247,0.2);color:#c084fc;font-size:0.75rem">🔗 ${isAR ? 'مدمجة مع' : 'Merged with'} T${t.merged_with}</span>`;
            cardBg = 'linear-gradient(180deg, rgba(168,85,247,0.06) 0%, var(--surface) 100%)';
          } else if (status === 'occupied') {
            borderColor = '#ef4444';
            statusBadge = `<span class="badge badge-danger" style="font-size:0.75rem">🔴 ${isAR ? 'مشغولة' : 'Occupied'}</span>`;
            cardBg = 'linear-gradient(180deg, rgba(239,68,68,0.06) 0%, var(--surface) 100%)';
          } else if (status === 'billed') {
            borderColor = '#f59e0b';
            statusBadge = `<span class="badge badge-warning" style="font-size:0.75rem">🟡 ${isAR ? 'تم الحساب' : 'Billed'}</span>`;
            cardBg = 'linear-gradient(180deg, rgba(245,158,11,0.08) 0%, var(--surface) 100%)';
          } else if (status === 'reserved') {
            borderColor = '#3b82f6';
            statusBadge = `<span class="badge badge-primary" style="font-size:0.75rem">🔵 ${isAR ? 'محجوزة' : 'Reserved'}</span>`;
            cardBg = 'linear-gradient(180deg, rgba(59,130,246,0.08) 0%, var(--surface) 100%)';
          }

          const orderTotal = order ? (order.total || 0) : 0;

          return `
          <div class="card table-card" style="padding:16px;border-radius:16px;border:2px solid ${borderColor};background:${cardBg};box-shadow:var(--shadow-sm);display:flex;flex-direction:column;justify-content:space-between;gap:12px;position:relative;transition:all 0.22s ease">
            
            <!-- Table Card Header -->
            <div>
              <div style="display:flex;justify-content:space-between;align-items:flex-start">
                <div>
                  <div style="font-size:1.35rem;font-weight:900;color:var(--text-primary);letter-spacing:-0.5px">
                    ${Utils.sanitize(t.table_number || t.name)}
                  </div>
                  <div style="font-size:0.76rem;color:var(--text-muted);margin-top:2px">
                    ${zoneObj?.icon || '🛋️'} ${Utils.sanitize(zoneTitle)} • 👥 ${t.capacity || 4} ${isAR ? 'كراسي' : 'Seats'}
                  </div>
                </div>
                <div>${statusBadge}</div>
              </div>

              <!-- Live Info per Status -->
              ${(status === 'occupied' || status === 'billed') && !t.merged_with ? `
              <div style="margin-top:12px;padding:10px 12px;border-radius:10px;background:rgba(0,0,0,0.25);border:1px solid rgba(255,255,255,0.06)">
                <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.78rem;color:var(--text-secondary)">
                  <span>⏱️ ${seatedMinutes} ${isAR ? 'دقيقة' : 'mins'}</span>
                  <span>👤 ${order?.waiter_name || t.waiter_name || (isAR ? 'الويتر' : 'Waiter')}</span>
                </div>
                <div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:6px;border-top:1px dashed rgba(255,255,255,0.1);padding-top:6px">
                  <span style="font-size:0.76rem;color:var(--text-muted);font-weight:600">${isAR ? 'الحساب الحالي:' : 'Current Bill:'}</span>
                  <span style="font-size:1.15rem;font-weight:900;color:var(--primary)">$${orderTotal.toFixed(2)}</span>
                </div>
                <div style="text-align:right;font-size:0.72rem;color:var(--brand-cyan);font-weight:700">
                  ${Utils.formatMoney(Utils.calcSecondaryPrice(orderTotal, 'USD', secCurrency, rate), secCurrency)}
                </div>
              </div>` : (status === 'reserved' ? `
              <div style="margin-top:12px;padding:10px 12px;border-radius:10px;background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.25);font-size:0.8rem">
                <div style="font-weight:800;color:#93c5fd">👤 ${Utils.sanitize(t.reservation_guest || (isAR ? 'حجز مسبق' : 'Reserved Guest'))}</div>
                <div style="color:var(--text-muted);font-size:0.74rem;margin-top:2px">⏰ ${t.reservation_time || ''} • 👥 ${t.reservation_pax || t.capacity} pax</div>
              </div>` : (t.merged_with ? `
              <div style="margin-top:14px;min-height:54px;display:flex;align-items:center;justify-content:center;color:#c084fc;font-size:0.8rem;border:1px dashed #a855f7;border-radius:10px">
                🔗 ${isAR ? `مدمجة مع الطاولة ${t.merged_with}` : `Attached to Table ${t.merged_with}`}
              </div>` : `
              <div style="margin-top:14px;min-height:54px;display:flex;align-items:center;justify-content:center;color:var(--text-muted);font-size:0.8rem;border:1px dashed var(--border-color);border-radius:10px">
                ✨ ${isAR ? 'الطاولة جاهزة للضيوف' : 'Ready for New Guests'}
              </div>`))}
            </div>

            <!-- Table Card Footer Action Buttons -->
            <div style="border-top:1px solid var(--border-color);padding-top:10px;display:flex;gap:6px;align-items:center;justify-content:space-between">
              ${status === 'free' && !t.merged_with ? `
              <button class="btn btn-primary btn-sm" onclick="Restaurant.openTableOrder(${t.id})" style="flex:1;font-weight:800;border-radius:8px">
                <span>🍽️ ${isAR ? 'فتح طاولة' : 'Open Order'}</span>
              </button>
              <button class="btn btn-secondary btn-sm" onclick="Restaurant.quickReserveTable(${t.id})" style="padding:6px 8px" title="${isAR ? 'حجز هذه الطاولة' : 'Reserve Table'}">
                📅
              </button>
              <button class="btn btn-ghost btn-sm" onclick="Restaurant.openTableForm(${t.id})" style="padding:6px 8px" title="${isAR ? 'تعديل بيانات الطاولة' : 'Edit Table'}">
                ✏️
              </button>` : (status === 'reserved' ? `
              <button class="btn btn-primary btn-sm" onclick="Restaurant.seatReservedGuest(${t.id})" style="flex:1;font-weight:800;border-radius:8px">
                <span>✅ ${isAR ? 'تسكين الضيوف' : 'Seat Guest'}</span>
              </button>
              <button class="btn btn-ghost btn-sm" onclick="Restaurant.cancelTableReservation(${t.id})" style="color:var(--danger);padding:6px 8px" title="${isAR ? 'إلغاء الحجز' : 'Cancel Reservation'}">
                ✕
              </button>` : (t.merged_with ? `
              <button class="btn btn-secondary btn-sm" style="flex:1;border-radius:8px" onclick="Restaurant.unmergeTable(${t.id})">
                🔓 ${isAR ? 'فك الدمج' : 'Unlink Table'}
              </button>` : `
              <div style="display:flex;gap:4px;width:100%;flex-wrap:wrap">
                <button class="btn btn-primary btn-sm" onclick="Restaurant.openTableOrder(${t.id})" style="flex:1;font-weight:800;border-radius:8px" title="${isAR ? 'إضافة أصناف أو عرض الطلب' : 'Add Items / View Order'}">
                  <span>🛒 ${isAR ? 'الطلب' : 'Order'}</span>
                </button>
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.printGuestCheck(${t.id})" style="padding:5px 8px;border-radius:8px" title="${isAR ? 'طباعة حساب مبدئي للزبون' : 'Print Guest Bill (Check)'}">
                  <span>🧾</span>
                </button>
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.openTransferModal(${t.id})" style="padding:5px 8px;border-radius:8px" title="${isAR ? 'نقل الطلب لطاولة أخرى' : 'Transfer to Another Table'}">
                  <span>🔀</span>
                </button>
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.openSplitBillModal(${t.id})" style="padding:5px 8px;border-radius:8px" title="${isAR ? 'تقسيم الحساب' : 'Split Bill'}">
                  <span>✂️</span>
                </button>
                <button class="btn btn-ghost btn-sm" onclick="Restaurant.freeTablePrompt(${t.id})" style="color:var(--danger);padding:5px 8px;border-radius:8px" title="${isAR ? 'إخلاء الطاولة' : 'Force Free Table'}">
                  <span>✕</span>
                </button>
              </div>`))}
            </div>

          </div>`;
        }).join('')}
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════
  // 2. DELIVERY DISPATCH HUB FULL-PAGE VIEW
  // ══════════════════════════════════════════════════════════════════
  function renderDeliveryView(allDeliveries, activeCurrency, secCurrency, rate, isAR) {
    // Filter down to delivery orders only
    const deliveries = allDeliveries.filter(d => !d.order_type || d.order_type === 'delivery');

    // Stats calculations
    const totalDeliveries = deliveries.length;
    const activeCount = deliveries.filter(d => d.status !== 'delivered' && d.status !== 'cancelled').length;
    const cookingCount = deliveries.filter(d => d.status === 'cooking' || !d.status).length;
    const onTheWayCount = deliveries.filter(d => d.status === 'on_the_way' || d.status === 'out_for_delivery').length;
    const deliveredCount = deliveries.filter(d => d.status === 'delivered').length;
    
    const unpaidList = deliveries.filter(d => !d.is_paid && d.payment_status !== 'paid' && d.status !== 'cancelled');
    const unpaidTotal = unpaidList.reduce((sum, d) => sum + (parseFloat(d.total || d.total_amount) || 0) + (parseFloat(d.delivery_fee) || 0), 0);
    const paidList = deliveries.filter(d => (d.is_paid || d.payment_status === 'paid') && d.status !== 'cancelled');
    const paidTotal = paidList.reduce((sum, d) => sum + (parseFloat(d.total || d.total_amount) || 0) + (parseFloat(d.delivery_fee) || 0), 0);

    // Apply Filter & Search
    let filtered = deliveries;
    if (deliveryFilter === 'active') filtered = filtered.filter(d => d.status !== 'delivered' && d.status !== 'cancelled');
    else if (deliveryFilter === 'cooking') filtered = filtered.filter(d => d.status === 'cooking' || !d.status);
    else if (deliveryFilter === 'ready') filtered = filtered.filter(d => d.status === 'ready');
    else if (deliveryFilter === 'on_the_way') filtered = filtered.filter(d => d.status === 'on_the_way' || d.status === 'out_for_delivery');
    else if (deliveryFilter === 'delivered') filtered = filtered.filter(d => d.status === 'delivered');
    else if (deliveryFilter === 'unpaid') filtered = filtered.filter(d => !d.is_paid && d.payment_status !== 'paid' && d.status !== 'cancelled');
    else if (deliveryFilter === 'paid') filtered = filtered.filter(d => (d.is_paid || d.payment_status === 'paid') && d.status !== 'cancelled');

    if (deliverySearch.trim()) {
      const q = deliverySearch.toLowerCase().trim();
      filtered = filtered.filter(d => 
        (d.customer_name || '').toLowerCase().includes(q) ||
        (d.phone || '').toLowerCase().includes(q) ||
        (d.address || '').toLowerCase().includes(q) ||
        (d.driver || '').toLowerCase().includes(q) ||
        String(d.id).includes(q)
      );
    }

    // Sort: Active first (newest), then delivered
    filtered.sort((a, b) => {
      if (a.status === 'delivered' && b.status !== 'delivered') return 1;
      if (a.status !== 'delivered' && b.status === 'delivered') return -1;
      return new Date(b.created_at || 0) - new Date(a.created_at || 0);
    });

    return `
      <!-- Delivery KPI Statistics Bar -->
      <div class="grid grid-5" style="gap:12px;margin-bottom:20px">
        <div class="card" style="padding:14px;border-inline-start:4px solid var(--primary);display:flex;align-items:center;gap:12px">
          <div style="width:38px;height:38px;border-radius:10px;background:rgba(239,68,68,0.15);color:var(--primary);display:flex;align-items:center;justify-content:center;font-size:1.2rem">🛵</div>
          <div>
            <div style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'الطلبات النشطة' : 'Active Deliveries'}</div>
            <div style="font-size:1.3rem;font-weight:900;color:var(--text-primary)">${activeCount} <span style="font-size:0.75rem;color:var(--text-muted)">/ ${totalDeliveries}</span></div>
          </div>
        </div>

        <div class="card" style="padding:14px;border-inline-start:4px solid #f59e0b;display:flex;align-items:center;gap:12px">
          <div style="width:38px;height:38px;border-radius:10px;background:rgba(245,158,11,0.15);color:#f59e0b;display:flex;align-items:center;justify-content:center;font-size:1.2rem">🍳</div>
          <div>
            <div style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'قيد الطهي والمطبخ' : 'In Preparation'}</div>
            <div style="font-size:1.3rem;font-weight:900;color:#f59e0b">${cookingCount}</div>
          </div>
        </div>

        <div class="card" style="padding:14px;border-inline-start:4px solid #06b6d4;display:flex;align-items:center;gap:12px">
          <div style="width:38px;height:38px;border-radius:10px;background:rgba(6,182,212,0.15);color:#06b6d4;display:flex;align-items:center;justify-content:center;font-size:1.2rem">🚀</div>
          <div>
            <div style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'في الطريق مع السائق' : 'Out for Delivery'}</div>
            <div style="font-size:1.3rem;font-weight:900;color:#06b6d4">${onTheWayCount}</div>
          </div>
        </div>

        <div class="card" style="padding:14px;border-inline-start:4px solid #ef4444;display:flex;align-items:center;gap:12px">
          <div style="width:38px;height:38px;border-radius:10px;background:rgba(239,68,68,0.15);color:#ef4444;display:flex;align-items:center;justify-content:center;font-size:1.2rem">⚠️</div>
          <div>
            <div style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'غير مدفوع (COD لتحصيله)' : 'Unpaid (COD to Collect)'}</div>
            <div style="font-size:1.2rem;font-weight:900;color:#ef4444">$${unpaidTotal.toFixed(2)}</div>
            <div style="font-size:0.68rem;color:var(--text-muted)">${unpaidList.length} ${isAR ? 'طلبات غير مسددة' : 'unpaid orders'}</div>
          </div>
        </div>

        <div class="card" style="padding:14px;border-inline-start:4px solid #10b981;display:flex;align-items:center;gap:12px">
          <div style="width:38px;height:38px;border-radius:10px;background:rgba(16,185,129,0.15);color:#10b981;display:flex;align-items:center;justify-content:center;font-size:1.2rem">✅</div>
          <div>
            <div style="font-size:0.72rem;color:var(--text-muted);font-weight:700">${isAR ? 'إجمالي المحصل / مسلّم' : 'Delivered / Paid'}</div>
            <div style="font-size:1.2rem;font-weight:900;color:#10b981">$${paidTotal.toFixed(2)}</div>
            <div style="font-size:0.68rem;color:var(--text-muted)">${deliveredCount} ${isAR ? 'تم تسليمها' : 'delivered'}</div>
          </div>
        </div>
      </div>

      <!-- Filter, Search & Actions Bar -->
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap;background:var(--surface);padding:12px 16px;border-radius:14px;border:1px solid var(--border-color)">
        
        <!-- Status Filter Buttons -->
        <div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
          <button class="btn ${deliveryFilter === 'active' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setDeliveryFilter('active')" style="border-radius:8px">
            🛵 ${isAR ? 'الطلبات النشطة' : 'Active Orders'} (${activeCount})
          </button>
          <button class="btn ${deliveryFilter === 'cooking' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setDeliveryFilter('cooking')" style="border-radius:8px">
            🍳 ${isAR ? 'في المطبخ' : 'In Kitchen'} (${cookingCount})
          </button>
          <button class="btn ${deliveryFilter === 'on_the_way' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setDeliveryFilter('on_the_way')" style="border-radius:8px">
            🚀 ${isAR ? 'في الطريق' : 'On The Way'} (${onTheWayCount})
          </button>
          <button class="btn ${deliveryFilter === 'unpaid' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setDeliveryFilter('unpaid')" style="border-radius:8px;border-color:rgba(239,68,68,0.4)">
            🔴 ${isAR ? 'غير مدفوع (COD)' : 'Unpaid (COD)'} (${unpaidList.length})
          </button>
          <button class="btn ${deliveryFilter === 'delivered' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setDeliveryFilter('delivered')" style="border-radius:8px">
            ✅ ${isAR ? 'تم التسليم / الأرشيف' : 'Delivered History'} (${deliveredCount})
          </button>
          <button class="btn ${deliveryFilter === 'all' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setDeliveryFilter('all')" style="border-radius:8px">
            🌐 ${isAR ? 'كل السجلات' : 'All Records'} (${deliveries.length})
          </button>
        </div>

        <!-- Search & New Order Action -->
        <div style="display:flex;gap:8px;align-items:center;flex:1;max-width:380px">
          <input type="text" class="form-control" placeholder="${isAR ? '🔍 ابحث برقم الطلب، الزبون، الهاتف، السائق...' : '🔍 Search by order #, name, phone, driver...'}" 
            value="${Utils.sanitize(deliverySearch)}" 
            oninput="Restaurant.setDeliverySearch(this.value)"
            style="border-radius:8px;font-size:0.85rem">
          <button class="btn btn-primary btn-sm" onclick="Restaurant.openNewDeliveryModal()" style="font-weight:800;white-space:nowrap;padding:8px 14px;border-radius:8px">
            ➕ ${isAR ? 'طلب جديد' : 'New Order'}
          </button>
        </div>

      </div>

      <!-- Live Delivery Orders Grid -->
      <div class="grid grid-3" style="gap:16px" id="delivery-cards-grid">
        ${filtered.map(d => {
          const isPaid = d.is_paid || d.payment_status === 'paid';
          const status = d.status || 'cooking';
          const itemsTotal = parseFloat(d.total || d.total_amount) || 0;
          const delFee = parseFloat(d.delivery_fee) || 0;
          const grandTotal = itemsTotal + delFee;

          // Elapsed SLA Time Calculation
          const createdTime = d.created_at ? new Date(d.created_at).getTime() : Date.now();
          const elapsedMinutes = Math.max(1, Math.round((Date.now() - createdTime) / 60000));
          
          let slaBadge = `<span class="sla-badge sla-badge-normal">⏱️ ${elapsedMinutes}m</span>`;
          if (status !== 'delivered' && status !== 'cancelled') {
            if (elapsedMinutes >= 35) {
              slaBadge = `<span class="sla-badge sla-badge-urgent">🔥 ${elapsedMinutes}m (${isAR ? 'تأخير عالي' : 'High Delay'})</span>`;
            } else if (elapsedMinutes >= 20) {
              slaBadge = `<span class="sla-badge sla-badge-warning">⏱️ ${elapsedMinutes}m</span>`;
            }
          } else if (status === 'delivered') {
            slaBadge = `<span class="sla-badge" style="background:rgba(16,185,129,0.15);color:#10b981">✔️ ${isAR ? 'مكتمل' : 'Delivered'}</span>`;
          }

          // Payment Status Badge
          let payBadge = isPaid 
            ? `<span class="pay-badge-paid">🟢 ${isAR ? 'مدفوع' : 'PAID'} (${d.payment_method || 'Cash'})</span>`
            : `<span class="pay-badge-unpaid">🔴 ${isAR ? 'غير مدفوع (COD)' : 'UNPAID (COD)'}</span>`;

          // Delivery Status Details
          let statusBadge = '';
          if (status === 'cooking') {
            statusBadge = `<span class="badge" style="background:rgba(245,158,11,0.2);color:#fde047;font-size:0.78rem">🍳 ${isAR ? 'قيد الطهي' : 'In Kitchen'}</span>`;
          } else if (status === 'ready') {
            statusBadge = `<span class="badge" style="background:rgba(168,85,247,0.2);color:#c084fc;font-size:0.78rem">📦 ${isAR ? 'جاهز للتسليم' : 'Ready / Packed'}</span>`;
          } else if (status === 'on_the_way' || status === 'out_for_delivery') {
            statusBadge = `<span class="badge" style="background:rgba(6,182,212,0.2);color:#67e8f9;font-size:0.78rem">🛵 ${isAR ? 'في الطريق' : 'Out for Delivery'}</span>`;
          } else if (status === 'delivered') {
            statusBadge = `<span class="badge badge-success" style="font-size:0.78rem">✅ ${isAR ? 'تم التسليم' : 'Delivered'}</span>`;
          } else {
            statusBadge = `<span class="badge badge-secondary" style="font-size:0.78rem">${status}</span>`;
          }

          // Customer Phone clean for direct WhatsApp
          const rawPhone = (d.phone || '').replace(/[^0-9+]/g, '');

          // Items parsed
          let orderItems = [];
          if (Array.isArray(d.items)) {
            orderItems = d.items;
          } else if (typeof d.items === 'string') {
            try { orderItems = JSON.parse(d.items); } catch(e) {}
          }

          return `
          <div class="delivery-order-card" style="${status === 'delivered' ? 'opacity:0.85;border-color:rgba(16,185,129,0.3)' : ''}">
            
            <!-- Card Header: Order # & Status & SLA -->
            <div>
              <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:1px solid var(--border-color);padding-bottom:10px;margin-bottom:10px">
                <div>
                  <div style="display:flex;align-items:center;gap:8px">
                    <span style="font-size:1.25rem;font-weight:900;color:var(--text-primary)">#DEL-${d.id}</span>
                    ${statusBadge}
                  </div>
                  <div style="font-size:0.72rem;color:var(--text-muted);margin-top:2px">
                    📅 ${new Date(d.created_at || Date.now()).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} • ${Utils.formatDate(d.created_at || Date.now())}
                  </div>
                </div>
                <div>${slaBadge}</div>
              </div>

              <!-- Customer Info Box -->
              <div style="background:rgba(0,0,0,0.22);padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,0.05);margin-bottom:10px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                  <span style="font-weight:900;font-size:0.95rem;color:var(--text-primary)">👤 ${Utils.sanitize(d.customer_name || 'Guest')}</span>
                  
                  <!-- Direct WhatsApp & Phone actions -->
                  <div style="display:flex;gap:4px">
                    ${rawPhone ? `
                    <a href="https://wa.me/${rawPhone}" target="_blank" class="btn btn-ghost btn-sm" style="padding:2px 6px;color:#22c55e;font-size:0.8rem" title="WhatsApp">
                      💬
                    </a>
                    <a href="tel:${rawPhone}" class="btn btn-ghost btn-sm" style="padding:2px 6px;color:#38bdf8;font-size:0.8rem" title="Call">
                      📞
                    </a>` : ''}
                  </div>
                </div>

                <div style="font-size:0.78rem;color:var(--text-muted);margin-top:2px">
                  📞 ${Utils.sanitize(d.phone || '-')}
                </div>
                <div style="font-size:0.78rem;color:var(--text-secondary);margin-top:4px;display:flex;align-items:flex-start;gap:4px">
                  <span>📍</span> <span style="line-height:1.3">${Utils.sanitize(d.address || (isAR ? 'لا يوجد عنوان محدد' : 'No address specified'))}</span>
                </div>
              </div>

              <!-- Assigned Courier / Driver -->
              <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 10px;background:rgba(255,255,255,0.03);border-radius:8px;margin-bottom:10px;font-size:0.8rem">
                <span style="color:var(--text-muted)">🛵 ${isAR ? 'السائق / المندوب:' : 'Assigned Driver:'}</span>
                <span style="font-weight:800;color:var(--brand-cyan);cursor:pointer" onclick="Restaurant.reassignDriverPrompt(${d.id})" title="${isAR ? 'انقر لتغيير السائق' : 'Click to change driver'}">
                  ${Utils.sanitize(d.driver || (isAR ? 'غير معين (اضغط للتعيين)' : 'Unassigned (Click)'))} ✏️
                </span>
              </div>

              <!-- Order Items Summary (Pills or List) -->
              ${orderItems.length ? `
              <div style="max-height:90px;overflow-y:auto;background:rgba(0,0,0,0.15);padding:8px 10px;border-radius:8px;margin-bottom:10px;font-size:0.78rem;border:1px solid rgba(255,255,255,0.04)">
                ${orderItems.map(it => `
                <div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px dashed rgba(255,255,255,0.04)">
                  <span><strong>${it.qty || it.quantity || 1}x</strong> ${Utils.sanitize(it.name || it.name_en || it.name_ar || 'Item')}</span>
                  <span style="color:var(--text-muted)">$${((it.price || 0) * (it.qty || it.quantity || 1)).toFixed(2)}</span>
                </div>`).join('')}
              </div>` : ''}

              <!-- Payment & Financials Box -->
              <div style="background:rgba(0,0,0,0.25);padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,0.06);margin-bottom:12px">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                  <span style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'حالة الدفع:' : 'Payment Status:'}</span>
                  <div>${payBadge}</div>
                </div>

                <div style="display:flex;justify-content:space-between;align-items:baseline;border-top:1px dashed rgba(255,255,255,0.1);padding-top:6px">
                  <div>
                    <span style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'المجموع شامل التوصيل:' : 'Total Incl. Delivery:'}</span>
                    <div style="font-size:0.7rem;color:var(--text-muted)">(+$${delFee.toFixed(2)} fee)</div>
                  </div>
                  <div style="text-align:right">
                    <span style="font-size:1.25rem;font-weight:900;color:var(--primary)">$${grandTotal.toFixed(2)}</span>
                    <div style="font-size:0.72rem;color:var(--brand-cyan);font-weight:700">
                      ${Utils.formatMoney(Utils.calcSecondaryPrice(grandTotal, 'USD', secCurrency, rate), secCurrency)}
                    </div>
                  </div>
                </div>
              </div>

              <!-- Status Progress Stepper -->
              <div class="restaurant-stepper" style="margin-bottom:12px">
                <div class="restaurant-step ${status === 'cooking' ? 'active' : (status === 'ready' || status === 'on_the_way' || status === 'delivered' ? 'completed' : '')}">
                  <span>🍳</span> <span>${isAR ? 'تحضير' : 'Prep'}</span>
                </div>
                <span style="opacity:0.3;font-size:0.7rem">➔</span>
                <div class="restaurant-step ${status === 'ready' ? 'active' : (status === 'on_the_way' || status === 'delivered' ? 'completed' : '')}">
                  <span>📦</span> <span>${isAR ? 'جاهز' : 'Ready'}</span>
                </div>
                <span style="opacity:0.3;font-size:0.7rem">➔</span>
                <div class="restaurant-step ${status === 'on_the_way' || status === 'out_for_delivery' ? 'active' : (status === 'delivered' ? 'completed' : '')}">
                  <span>🛵</span> <span>${isAR ? 'طريق' : 'Way'}</span>
                </div>
                <span style="opacity:0.3;font-size:0.7rem">➔</span>
                <div class="restaurant-step ${status === 'delivered' ? 'completed active' : ''}">
                  <span>✅</span> <span>${isAR ? 'تم' : 'Done'}</span>
                </div>
              </div>

            </div>

            <!-- Card Actions Toolbar -->
            <div style="border-top:1px solid var(--border-color);padding-top:10px;display:flex;flex-direction:column;gap:6px">
              
              <!-- Primary Next-Step Action -->
              <div style="display:flex;gap:6px">
                ${status === 'cooking' ? `
                  <button class="btn btn-primary btn-sm" onclick="Restaurant.updateDeliveryStatus(${d.id}, 'ready')" style="flex:1;font-weight:800;border-radius:8px">
                    📦 ${isAR ? 'تحديد كـ جاهز للتسليم' : 'Mark as Ready'}
                  </button>
                ` : status === 'ready' ? `
                  <button class="btn btn-primary btn-sm" onclick="Restaurant.updateDeliveryStatus(${d.id}, 'on_the_way')" style="flex:1;font-weight:800;border-radius:8px">
                    🛵 ${isAR ? 'إرسال مع السائق' : 'Send Out with Driver'}
                  </button>
                ` : status === 'on_the_way' || status === 'out_for_delivery' ? `
                  <button class="btn btn-primary btn-sm" onclick="Restaurant.updateDeliveryStatus(${d.id}, 'delivered')" style="flex:1;font-weight:800;border-radius:8px;background:var(--success);border-color:var(--success)">
                    ✅ ${isAR ? 'تأكيد التسليم للزبون' : 'Mark as Delivered'}
                  </button>
                ` : `
                  <div style="flex:1;text-align:center;font-size:0.8rem;color:var(--success);font-weight:800;padding:6px">
                    ✔️ ${isAR ? 'الطلب مكتمل ومسلّم' : 'Order Delivered'}
                  </div>
                `}

                <!-- Settle Payment Button if Unpaid -->
                ${!isPaid && status !== 'cancelled' ? `
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.openSettlePaymentModal(${d.id})" style="font-weight:800;border-radius:8px;border-color:rgba(239,68,68,0.4);color:#fca5a5" title="${isAR ? 'تسجيل تحصيل المبلغ' : 'Collect / Settle Payment'}">
                  💳 ${isAR ? 'تسديد' : 'Pay'}
                </button>` : ''}
              </div>

              <!-- Secondary Helper Buttons -->
              <div style="display:flex;gap:6px;justify-content:space-between">
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.openDeliveryDetailsModal(${d.id})" style="flex:1;border-radius:8px;font-size:0.78rem;font-weight:700" title="${isAR ? 'عرض تفاصيل الطلب والأصناف' : 'View / Reopen Order Details'}">
                  👁️ ${isAR ? 'معاينة' : 'Details'}
                </button>
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.openNewDeliveryModal(${d.id})" style="flex:1;border-radius:8px;font-size:0.78rem;font-weight:700" title="${isAR ? 'تعديل الأصناف والملاحظات والعنوان' : 'Edit Order, Items & Notes'}">
                  ✏️ ${isAR ? 'تعديل' : 'Edit'}
                </button>
                <button class="btn btn-secondary btn-sm" onclick="Restaurant.printDeliveryDispatchTicket(${d.id})" style="border-radius:8px;font-size:0.78rem" title="${isAR ? 'طباعة بون التوصيل للسائق' : 'Print Driver Dispatch Slip'}">
                  🧾 ${isAR ? 'بون' : 'Print'}
                </button>
                <button class="btn btn-ghost btn-sm" onclick="Restaurant.cancelDeliveryOrder(${d.id})" style="color:var(--danger);padding:4px 8px;border-radius:8px" title="${isAR ? 'إلغاء الطلب' : 'Cancel Order'}">
                  ✕
                </button>
              </div>

            </div>

          </div>`;
        }).join('')}

        ${!filtered.length ? `
        <div style="grid-column:1/-1;text-align:center;padding:80px 20px;color:var(--text-muted);background:var(--surface);border-radius:18px;border:1px dashed var(--border-color)">
          <span style="font-size:3rem">🛵</span>
          <h3 style="margin-top:12px;font-weight:800">${isAR ? 'لا توجد طلبات توصيل مطابقة' : 'No matching delivery orders found'}</h3>
          <p style="font-size:0.85rem;margin-top:4px">${isAR ? 'يمكنك تسجيل طلب دليفري جديد عبر الزر أعلاه' : 'You can create a new phone or online delivery order above'}</p>
          <button class="btn btn-primary" onclick="Restaurant.openNewDeliveryModal()" style="margin-top:12px;font-weight:800">
            ➕ ${isAR ? 'طلب دليفري جديد' : 'New Delivery Order'}
          </button>
        </div>` : ''}
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════
  // 3. TAKEAWAY & COUNTER PICKUP FULL-PAGE VIEW
  // ══════════════════════════════════════════════════════════════════
  function renderTakeawayView(allDeliveries, activeCurrency, secCurrency, rate, isAR) {
    const takeaways = allDeliveries.filter(d => d.order_type === 'takeaway');
    const activeTakeaways = takeaways.filter(d => d.status !== 'delivered' && d.status !== 'completed' && d.status !== 'cancelled');

    return `
      <!-- Takeaway Header & Quick Create -->
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap;background:var(--surface);padding:14px 20px;border-radius:14px;border:1px solid var(--border-color)">
        <div>
          <h3 style="margin:0;font-size:1.15rem;font-weight:900">🛍️ ${isAR ? 'طابور طلبات السفري والاستلام' : 'Takeaway & Counter Pickup Queue'}</h3>
          <span style="font-size:0.78rem;color:var(--text-muted)">${activeTakeaways.length} ${isAR ? 'طلبات نشطة بانتظار التسليم' : 'Active orders in queue'}</span>
        </div>
        <button class="btn btn-primary" onclick="Restaurant.openQuickTakeawayPOS()" style="font-weight:800">
          🛒 ${isAR ? '➕ فتح كاشير السفري السريع' : '➕ New Takeaway Sale (POS)'}
        </button>
      </div>

      <!-- Takeaway Grid -->
      <div class="grid grid-3" style="gap:16px">
        ${takeaways.map(t => {
          const isPaid = t.is_paid || t.payment_status === 'paid';
          const status = t.status || 'cooking';
          const total = parseFloat(t.total || t.total_amount) || 0;

          let orderItems = [];
          if (Array.isArray(t.items)) orderItems = t.items;
          else if (typeof t.items === 'string') {
            try { orderItems = JSON.parse(t.items); } catch(e) {}
          }

          return `
          <div class="card" style="padding:16px;border-radius:16px;border:1px solid var(--border-color);display:flex;flex-direction:column;justify-content:space-between;gap:12px">
            <div>
              <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:10px">
                <div>
                  <span style="font-size:1.25rem;font-weight:900">#TK-${t.id}</span>
                  <div style="font-size:0.72rem;color:var(--text-muted)">${new Date(t.created_at || Date.now()).toLocaleTimeString()}</div>
                </div>
                <span class="badge ${isPaid ? 'badge-success' : 'badge-warning'}">
                  ${isPaid ? (isAR ? '🟢 مدفوع' : 'PAID') : (isAR ? '🟡 غير مدفوع' : 'UNPAID')}
                </span>
              </div>

              <div style="margin-top:10px;font-size:0.88rem;font-weight:800">
                👤 ${Utils.sanitize(t.customer_name || (isAR ? 'زبون سفري' : 'Walk-in Customer'))}
                ${t.phone ? `<span style="font-size:0.75rem;color:var(--text-muted);display:block">📞 ${t.phone}</span>` : ''}
              </div>

              <!-- Items -->
              ${orderItems.length ? `
              <div style="margin-top:10px;background:rgba(0,0,0,0.2);padding:8px 10px;border-radius:8px;font-size:0.78rem">
                ${orderItems.map(it => `
                <div style="display:flex;justify-content:space-between;padding:2px 0">
                  <span><strong>${it.qty || it.quantity || 1}x</strong> ${Utils.sanitize(it.name || it.name_en || it.name_ar || 'Item')}</span>
                  <span>$${((it.price || 0) * (it.qty || it.quantity || 1)).toFixed(2)}</span>
                </div>`).join('')}
              </div>` : ''}

              <div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:12px;padding-top:8px;border-top:1px dashed var(--border-color)">
                <span style="font-size:0.8rem;color:var(--text-muted)">${isAR ? 'المجموع:' : 'Total:'}</span>
                <span style="font-size:1.2rem;font-weight:900;color:var(--primary)">$${total.toFixed(2)}</span>
              </div>
            </div>

            <div style="border-top:1px solid var(--border-color);padding-top:10px;display:flex;gap:6px">
              ${status !== 'completed' && status !== 'delivered' ? `
              <button class="btn btn-primary btn-sm" onclick="Restaurant.updateDeliveryStatus(${t.id}, 'completed')" style="flex:1;font-weight:800;border-radius:8px">
                ✅ ${isAR ? 'تسليم للزبون' : 'Mark Picked Up'}
              </button>` : `
              <div style="flex:1;text-align:center;font-size:0.8rem;color:var(--success);font-weight:800;padding:6px">
                ✔️ ${isAR ? 'تم الاستلام' : 'Completed'}
              </div>`}
            </div>
          </div>`;
        }).join('')}

        ${!takeaways.length ? `
        <div style="grid-column:1/-1;text-align:center;padding:60px 20px;color:var(--text-muted)">
          <span style="font-size:3rem">🛍️</span>
          <h3 style="margin-top:12px">${isAR ? 'لا توجد طلبات سفري حالية' : 'No active takeaway orders'}</h3>
        </div>` : ''}
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════
  // 4. KITCHEN DISPLAY (KDS) FULL-PAGE VIEW
  // ══════════════════════════════════════════════════════════════════
  function renderKDSView(tables, isAR) {
    const activeOrders = tables.filter(t => (t.status === 'occupied' || t.status === 'billed') && t.current_order?.items?.length);

    return `
      <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:18px;overflow:hidden">
        <div style="padding:14px 20px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
          <div>
            <h3 style="margin:0;font-size:1.2rem;font-weight:900">🍳 ${isAR ? 'شاشة عرض المطبخ المباشرة (KDS)' : 'Live Multi-Station KDS Screen'}</h3>
            <span style="font-size:0.78rem;color:var(--text-muted)">${activeOrders.length} ${isAR ? 'طلبات قيد التحضير والطهي' : 'Active kitchen tickets'}</span>
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn ${kdsStationFilter === 'all' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setKdsStation('all')">
              🌐 ${isAR ? 'كل المحطات' : 'All'}
            </button>
            <button class="btn ${kdsStationFilter === 'kitchen' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setKdsStation('kitchen')">
              🍳 ${isAR ? 'المطبخ' : 'Kitchen'}
            </button>
            <button class="btn ${kdsStationFilter === 'bar' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setKdsStation('bar')">
              🍹 ${isAR ? 'البار' : 'Bar'}
            </button>
            <button class="btn btn-secondary btn-sm" onclick="Restaurant.openKitchenDisplay()" title="${isAR ? 'ملء الشاشة' : 'Fullscreen'}">
              ⛶ ${isAR ? 'ملء الشاشة' : 'Fullscreen'}
            </button>
          </div>
        </div>

        <div style="padding:20px;display:grid;grid-template-columns:repeat(auto-fill, minmax(310px, 1fr));gap:16px">
          ${activeOrders.map(t => {
            const ord = t.current_order;
            const seatedMins = t.seated_at ? Math.max(1, Math.round((Date.now() - new Date(t.seated_at).getTime()) / 60000)) : 1;
            
            let cardBorder = '#10b981';
            let timerBadge = 'badge-success';
            if (seatedMins >= 20) {
              cardBorder = '#ef4444';
              timerBadge = 'badge-danger';
            } else if (seatedMins >= 10) {
              cardBorder = '#f59e0b';
              timerBadge = 'badge-warning';
            }

            return `
            <div class="card" style="padding:16px;border-radius:16px;border:2px solid ${cardBorder};background:var(--bg-base);display:flex;flex-direction:column;justify-content:space-between">
              <div>
                <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:10px;margin-bottom:12px">
                  <div>
                    <span style="font-size:1.3rem;font-weight:900">Table ${t.table_number}</span>
                    <div style="font-size:0.75rem;color:var(--text-muted)">👤 ${ord.waiter_name || 'Staff'}</div>
                  </div>
                  <span class="badge ${timerBadge}" style="font-size:0.85rem;font-weight:900">⏱️ ${seatedMins}m</span>
                </div>

                <div style="display:flex;flex-direction:column;gap:8px">
                  ${(ord.items || []).map((it, idx) => `
                  <div style="display:flex;align-items:flex-start;gap:8px;padding:4px 0" id="kds-item-${t.id}-${idx}">
                    <input type="checkbox" style="width:18px;height:18px;cursor:pointer;margin-top:2px" onchange="Restaurant.toggleKdsItemCheck(this, 'kds-item-${t.id}-${idx}')">
                    <div style="flex:1">
                      <div style="font-size:0.95rem;font-weight:800">
                        <span style="color:var(--primary);font-weight:900">${it.quantity || 1}x</span> ${Utils.sanitize(it.name || it.item_name)}
                      </div>
                      ${it.notes ? `<div style="font-size:0.78rem;color:#fca5a5;font-weight:700">⤷ ${Utils.sanitize(it.notes)}</div>` : ''}
                    </div>
                  </div>`).join('')}
                </div>
              </div>

              <div style="margin-top:16px;border-top:1px solid var(--border-color);padding-top:10px">
                <button class="btn btn-primary btn-sm" style="width:100%;font-weight:900" onclick="Restaurant.markOrderReady(${t.id})">
                  ✅ ${isAR ? 'جاهز للتسليم (BUMP)' : 'BUMP / ORDER READY'}
                </button>
              </div>
            </div>`;
          }).join('')}

          ${!activeOrders.length ? `
          <div style="grid-column:1/-1;text-align:center;padding:60px 20px;color:var(--text-muted)">
            <span style="font-size:3rem">✨</span>
            <h3 style="margin-top:10px">${isAR ? 'لا توجد طلبات معلقة في المطبخ' : 'All orders completed! Kitchen queue is clean'}</h3>
          </div>` : ''}
        </div>
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════
  // 5. RESERVATIONS FULL-PAGE VIEW
  // ══════════════════════════════════════════════════════════════════
  function renderReservationsView(reservations, tables, isAR) {
    return `
      <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:18px;padding:20px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;flex-wrap:wrap;gap:10px">
          <div>
            <h3 style="margin:0;font-size:1.2rem;font-weight:900">📅 ${isAR ? 'سجل حجوزات المطعم' : 'Restaurant Reservations Diary'}</h3>
            <span style="font-size:0.78rem;color:var(--text-muted)">${reservations.length} ${isAR ? 'حجوزات مسجلة' : 'Bookings in diary'}</span>
          </div>
          <button class="btn btn-primary btn-sm" onclick="Restaurant.openReservationsModal()" style="font-weight:800">
            ➕ ${isAR ? 'حجز جديد' : 'New Booking'}
          </button>
        </div>

        <div style="border:1px solid var(--border-color);border-radius:12px;overflow:hidden">
          <table style="width:100%;border-collapse:collapse;font-size:0.86rem">
            <thead style="background:rgba(0,0,0,0.2);border-bottom:1px solid var(--border-color)">
              <tr>
                <th style="padding:10px 14px;text-align:left">${isAR ? 'الضيف' : 'Guest'}</th>
                <th style="padding:10px 14px;text-align:left">${isAR ? 'الهاتف' : 'Phone'}</th>
                <th style="padding:10px 14px;text-align:center">${isAR ? 'العدد' : 'Pax'}</th>
                <th style="padding:10px 14px">${isAR ? 'الموعد' : 'Date & Time'}</th>
                <th style="padding:10px 14px">${isAR ? 'الطاولة' : 'Table'}</th>
                <th style="padding:10px 14px;text-align:center">${isAR ? 'الحالة' : 'Status'}</th>
                <th style="padding:10px 14px;text-align:right">${isAR ? 'الإجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody>
              ${reservations.map(r => {
                const tObj = tables.find(t => String(t.id) === String(r.table_id));
                const tLabel = tObj ? `Table ${tObj.table_number}` : (isAR ? 'غير محددة' : 'Any Table');
                const isConfirmed = r.status === 'confirmed' || !r.status;

                return `
                <tr style="border-bottom:1px solid rgba(255,255,255,0.05)">
                  <td style="padding:10px 14px;font-weight:800">${Utils.sanitize(r.guest_name)}</td>
                  <td style="padding:10px 14px;color:var(--text-muted)">${Utils.sanitize(r.guest_phone || '-')}</td>
                  <td style="padding:10px 14px;text-align:center">👥 ${r.pax || 2}</td>
                  <td style="padding:10px 14px">${new Date(r.reservation_time || Date.now()).toLocaleString()}</td>
                  <td style="padding:10px 14px">${tLabel}</td>
                  <td style="padding:10px 14px;text-align:center">
                    <span class="badge ${isConfirmed ? 'badge-primary' : (r.status === 'seated' ? 'badge-success' : 'badge-danger')}">
                      ${r.status || 'confirmed'}
                    </span>
                  </td>
                  <td style="padding:10px 14px;text-align:right">
                    ${isConfirmed ? `
                    <button class="btn btn-primary btn-sm" onclick="Restaurant.seatReservationFromDiary(${r.id})" style="padding:4px 8px;font-size:0.75rem">
                      ✅ ${isAR ? 'تسكين' : 'Seat'}
                    </button>
                    <button class="btn btn-ghost btn-sm" onclick="Restaurant.cancelReservation(${r.id})" style="color:var(--danger);padding:4px 8px">
                      ✕
                    </button>` : `
                    <button class="btn btn-ghost btn-sm" onclick="Restaurant.deleteReservation(${r.id})" style="color:var(--danger);padding:4px 8px">
                      🗑️
                    </button>`}
                  </td>
                </tr>`;
              }).join('')}
              ${!reservations.length ? `<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted)">${isAR ? 'لا توجد حجوزات مسجلة' : 'No reservations recorded yet'}</td></tr>` : ''}
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════
  // 6. SETTINGS & BOM VIEW
  // ══════════════════════════════════════════════════════════════════
  function renderSettingsView(isAR) {
    return `
      <div class="grid grid-3" style="gap:16px">
        <div class="card" style="padding:20px;border-radius:16px;text-align:center">
          <div style="font-size:2.4rem;margin-bottom:8px">🌿</div>
          <h3 style="margin:0 0 6px 0;font-weight:900">${isAR ? 'إدارة الصالات والزونات' : 'Dining Zones & Areas'}</h3>
          <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:14px">
            ${isAR ? 'تهيئة أقسام الصالة، التراس، الجلسات العائلية وقسم الـ VIP' : 'Configure main hall, outdoor terrace, family lounge and VIP sections'}
          </p>
          <button class="btn btn-primary btn-sm" onclick="Restaurant.openZoneForm()" style="width:100%;font-weight:800">
            🌿 ${isAR ? 'فتح إدارة الصالات' : 'Manage Zones'}
          </button>
        </div>

        <div class="card" style="padding:20px;border-radius:16px;text-align:center">
          <div style="font-size:2.4rem;margin-bottom:8px">🏷️</div>
          <h3 style="margin:0 0 6px 0;font-weight:900">${isAR ? 'خيارات وتفضيلات الأطباق' : 'Item Modifiers & Customization'}</h3>
          <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:14px">
            ${isAR ? 'إضافة خيارات الأصناف (زيادة جبنة، صوص إضافي، درجة الاستواء)' : 'Configure kitchen dish options (extra cheese, sauce on side, cooking degree)'}
          </p>
          <button class="btn btn-primary btn-sm" onclick="Restaurant.openModifiersModal()" style="width:100%;font-weight:800">
            🏷️ ${isAR ? 'فتح إدارة الخيارات' : 'Manage Modifiers'}
          </button>
        </div>

        <div class="card" style="padding:20px;border-radius:16px;text-align:center">
          <div style="font-size:2.4rem;margin-bottom:8px">🧪</div>
          <h3 style="margin:0 0 6px 0;font-weight:900">${isAR ? 'الوصفات وتكلفة الأطباق (BOM)' : 'Recipe & Food Cost BOM'}</h3>
          <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:14px">
            ${isAR ? 'ربط الأطباق بمكونات المخزون لخصم المواد الأولية تلقائياً وحساب التكلفة' : 'Link menu dishes to raw inventory ingredients for automatic deduction & margin analysis'}
          </p>
          <button class="btn btn-primary btn-sm" onclick="Restaurant.openRecipeManager()" style="width:100%;font-weight:800">
            🧪 ${isAR ? 'فتح إدارة الوصفات' : 'Recipe Costing BOM'}
          </button>
        </div>
      </div>
    `;
  }

  // ══════════════════════════════════════════════════════════════════
  // HELPER ACTIONS & METHODS
  // ══════════════════════════════════════════════════════════════════
  function switchZone(zoneId) {
    activeZoneId = zoneId;
    render();
  }

  function setDeliveryFilter(flt) {
    deliveryFilter = flt;
    render();
  }

  function setDeliverySearch(val) {
    deliverySearch = val;
    render();
  }

  // Open POS bound to a specific table
  async function openTableOrder(tableId) {
    const table = await DB.get('restaurant_tables', tableId);
    if (!table) return;

    if (!table.status || table.status === 'free') {
      const currentUser = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : { username: 'Cashier' };
      table.status = 'occupied';
      table.seated_at = new Date().toISOString();
      table.waiter_id = currentUser.id || 1;
      table.waiter_name = currentUser.full_name || currentUser.username || 'Staff';
      table.guest_count = table.capacity || 2;
      table.current_order = {
        table_id: table.id,
        table_number: table.table_number,
        waiter_name: table.waiter_name,
        guest_count: table.guest_count,
        items: [],
        subtotal: 0,
        tax: 0,
        discount: 0,
        total: 0,
        created_at: new Date().toISOString()
      };
      await DB.update('restaurant_tables', table);
    }

    sessionStorage.removeItem('redshark_delivery_id');
    sessionStorage.removeItem('redshark_takeaway_id');
    sessionStorage.setItem('redshark_active_table_id', String(table.id));
    sessionStorage.setItem('redshark_order_type', 'dine_in');

    if (typeof App !== 'undefined' && App.navigate) {
      App.navigate('pos');
    } else {
      window.location.hash = '#pos';
    }
  }

  // Open POS in Takeaway Mode
  function openQuickTakeawayPOS() {
    sessionStorage.removeItem('redshark_active_table_id');
    sessionStorage.removeItem('redshark_delivery_id');
    sessionStorage.setItem('redshark_order_type', 'takeaway');
    if (typeof App !== 'undefined' && App.navigate) {
      App.navigate('pos');
    } else {
      window.location.hash = '#pos';
    }
  }

  // State for new delivery order item builder
  let _ndOrderItems = [];
  let _ndCustomerList = [];
  let _ndItemList = [];

  // Delivery: Open New Delivery Creator or Edit Modal with Embedded Items Builder & Customer Auto-Fill
  async function openNewDeliveryModal(existingDeliveryId = null) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    _ndCustomerList = await DB.getAll('customers') || [];
    _ndItemList = await DB.getAll('items', i => i.status !== 'inactive') || [];
    const categories = await DB.getAll('categories') || [];
    const drivers = await DB.getAll('users') || [];
    
    window._ndEditDeliveryId = existingDeliveryId;
    let existingDel = null;
    _ndOrderItems = [];

    if (existingDeliveryId) {
      existingDel = await DB.get('restaurant_delivery_orders', existingDeliveryId);
      if (existingDel) {
        if (Array.isArray(existingDel.items)) {
          _ndOrderItems = JSON.parse(JSON.stringify(existingDel.items));
        } else if (typeof existingDel.items === 'string') {
          try { _ndOrderItems = JSON.parse(existingDel.items); } catch(e) {}
        }
      }
    }

    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const secCurrency = await DB.getSetting('currency_2', 'LBP');

    const modalHtml = `
    <div class="modal-overlay open" id="new-delivery-modal" style="z-index:9999;backdrop-filter:blur(10px)">
      <div class="modal" onclick="event.stopPropagation()" style="max-width:980px;width:95vw;max-height:92vh;border-radius:20px;display:flex;flex-direction:column;overflow:hidden;background:var(--bg-base);border:1px solid var(--border-color);box-shadow:var(--shadow-xl)">
        
        <!-- Header -->
        <div class="modal-header" style="background:var(--surface);padding:14px 22px;border-bottom:1px solid var(--border-color)">
          <div class="modal-title" style="font-weight:900;font-size:1.25rem;display:flex;align-items:center;gap:10px">
            <span>🛵</span> <span>${existingDeliveryId ? (isAR ? `تعديل طلب التوصيل #DEL-${existingDeliveryId}` : `Edit Delivery Order #DEL-${existingDeliveryId}`) : (isAR ? 'تسجيل وإعداد طلب دليفري جديد' : 'New Delivery Order & Menu Builder')}</span>
          </div>
          <button type="button" class="btn-icon" onclick="document.getElementById('new-delivery-modal').remove()">✕</button>
        </div>

        <form onsubmit="Restaurant.saveNewDeliveryOrder(event)" style="display:flex;flex-direction:column;flex:1;overflow:hidden">
          
          <div class="modal-body" style="padding:18px 22px;flex:1;overflow-y:auto;display:grid;grid-template-columns:1.05fr 1.35fr;gap:20px">
            
            <!-- LEFT COLUMN: Customer & Logistics -->
            <div style="display:flex;flex-direction:column;gap:12px;background:var(--surface);padding:16px;border-radius:14px;border:1px solid var(--border-color)">
              
              <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--border-color);padding-bottom:8px">
                <span>👤</span> ${isAR ? 'بيانات الزبون وعنوان التوصيل' : 'Customer & Delivery Info'}
              </div>

              <!-- Customer Live Search Dropdown -->
              <div class="form-group" style="position:relative;margin:0">
                <label class="form-label" style="font-weight:700;font-size:0.8rem;color:var(--brand-cyan)">
                  🔍 ${isAR ? 'بحث بالاسم أو رقم الهاتف للزبائن المسجلين' : 'Search Customer by Name or Phone'}
                </label>
                <input type="text" id="nd-cust-search" class="form-control" 
                  placeholder="${isAR ? 'اكتب اسم أو رقم هاتف للبحث التلقائي...' : 'Type name or phone for instant lookup...'}" 
                  oninput="Restaurant.onDeliveryCustomerSearch(this.value)"
                  autocomplete="off" style="border-color:rgba(6,182,212,0.4)">
                
                <!-- Autocomplete Dropdown List -->
                <div id="nd-cust-suggestions" style="display:none;position:absolute;top:100%;left:0;right:0;max-height:180px;overflow-y:auto;background:var(--surface);border:1px solid var(--border-color);border-radius:8px;box-shadow:var(--shadow-lg);z-index:100;margin-top:4px">
                </div>
              </div>

              <!-- Customer Name & Phone -->
              <div class="form-grid" style="gap:10px;margin:0">
                <div class="form-group" style="margin:0">
                  <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'اسم الزبون *' : 'Customer Name *'}</label>
                  <input type="text" id="nd-name" class="form-control" placeholder="${isAR ? 'اسم الزبون' : 'Customer Name'}" value="${Utils.sanitize(existingDel?.customer_name || '')}" required>
                </div>
                <div class="form-group" style="margin:0">
                  <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'رقم الهاتف *' : 'Phone Number *'}</label>
                  <input type="tel" id="nd-phone" class="form-control" placeholder="e.g. 70 123456" value="${Utils.sanitize(existingDel?.phone || '')}" required oninput="Restaurant.onDeliveryPhoneInput(this.value)">
                </div>
              </div>

              <!-- Full Delivery Address -->
              <div class="form-group" style="margin:0">
                <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'عنوان التوصيل بالتفصيل *' : 'Full Delivery Address & Landmark *'}</label>
                <textarea id="nd-address" class="form-control" rows="2" placeholder="${isAR ? 'المنطقة، الشارع، البناية، الطابق، تفاصيل الموقع...' : 'Area, street, building, floor, landmark notes...'}" required style="font-size:0.85rem">${Utils.sanitize(existingDel?.address || '')}</textarea>
              </div>

              <!-- General Delivery Notes -->
              <div class="form-group" style="margin:0">
                <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'ملاحظات عامة للتوصيل (مثال: رن الجرس مرتين)' : 'Order / Delivery Note (e.g. Ring bell twice)'}</label>
                <input type="text" id="nd-order-notes" class="form-control" placeholder="${isAR ? 'ملاحظات خاصة بالتوصيل...' : 'Special instructions for delivery...'}" value="${Utils.sanitize(existingDel?.notes || '')}">
              </div>

              <!-- Assigned Driver & Fee -->
              <div class="form-grid" style="gap:10px;margin:0">
                <div class="form-group" style="margin:0">
                  <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'السائق / المندوب' : 'Assigned Driver'}</label>
                  <input type="text" id="nd-driver" class="form-control" placeholder="${isAR ? 'اسم السائق' : 'Driver Name'}" value="${Utils.sanitize(existingDel?.driver || '')}" list="nd-driver-list">
                  <datalist id="nd-driver-list">
                    ${drivers.map(u => `<option value="${Utils.sanitize(u.full_name || u.username)}">`).join('')}
                  </datalist>
                </div>
                <div class="form-group" style="margin:0">
                  <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'رسوم التوصيل ($)' : 'Delivery Fee ($)'}</label>
                  <input type="number" id="nd-fee" class="form-control" value="${existingDel?.delivery_fee !== undefined ? existingDel.delivery_fee : '2.00'}" step="0.5" min="0" oninput="Restaurant.updateDeliveryTotals()">
                </div>
              </div>

              <!-- Payment Status -->
              <div class="form-group" style="margin:0">
                <label class="form-label" style="font-weight:700;font-size:0.8rem">${isAR ? 'حالة الدفع' : 'Payment Status'}</label>
                <select id="nd-pay-status" class="form-control" style="font-weight:700">
                  <option value="unpaid" ${(!existingDel || (!existingDel.is_paid && existingDel.payment_status !== 'paid')) ? 'selected' : ''}>🔴 ${isAR ? 'الدفع عند الاستلام (COD - غير مدفوع)' : 'Cash on Delivery (Unpaid COD)'}</option>
                  <option value="paid" ${(existingDel && (existingDel.is_paid || existingDel.payment_status === 'paid')) ? 'selected' : ''}>🟢 ${isAR ? 'مدفوع مسبقاً (Prepaid)' : 'Prepaid (Paid)'}</option>
                </select>
              </div>

            </div>

            <!-- RIGHT COLUMN: Embedded Menu & Items Builder -->
            <div style="display:flex;flex-direction:column;gap:12px;background:var(--surface);padding:16px;border-radius:14px;border:1px solid var(--border-color)">
              
              <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:8px">
                <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary);display:flex;align-items:center;gap:8px">
                  <span>🍽️</span> ${isAR ? 'إضافة وتعديل أطباق وأصناف الطلب' : 'Add & Edit Order Items'}
                </div>
                <span class="badge badge-primary" id="nd-items-count-badge">0 items</span>
              </div>

              <!-- Items Search & Quick Category Filter -->
              <div style="display:flex;gap:8px">
                <input type="text" id="nd-item-search" class="form-control form-control-sm" 
                  placeholder="${isAR ? '🔍 ابحث عن صنف لإضافته...' : '🔍 Search item to add...'}" 
                  oninput="Restaurant.renderDeliveryItemPicker(this.value)"
                  style="border-radius:8px;font-size:0.82rem">
                <select id="nd-cat-filter" class="form-control form-control-sm" style="width:120px;border-radius:8px" onchange="Restaurant.renderDeliveryItemPicker()">
                  <option value="">${isAR ? 'كل الأقسام' : 'All Categories'}</option>
                  ${categories.map(c => `<option value="${c.id}">${Utils.sanitize(isAR ? (c.name_ar||c.name) : (c.name||c.name_ar))}</option>`).join('')}
                </select>
              </div>

              <!-- Quick Menu Item Buttons Grid (Adaptive Light & Dark Mode) -->
              <div id="nd-items-picker-grid" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(130px, 1fr));gap:6px;max-height:130px;overflow-y:auto;background:var(--surface-2);padding:8px;border-radius:10px;border:1px solid var(--border-color)">
                <!-- Rendered dynamically -->
              </div>

              <!-- Live Selected Order Cart List (Adaptive Light & Dark Mode) -->
              <div style="font-weight:700;font-size:0.8rem;color:var(--text-muted);margin-top:2px">
                ${isAR ? 'قائمة أصناف الطلب الحالية:' : 'Selected Order Items:'}
              </div>
              <div id="nd-cart-items-list" style="flex:1;max-height:160px;overflow-y:auto;background:var(--surface-2);border-radius:10px;padding:8px;border:1px solid var(--border-color)">
                <!-- Cart rows rendered dynamically -->
              </div>

              <!-- Financials Summary Box -->
              <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:10px 14px;display:flex;justify-content:space-between;align-items:center">
                <div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'المجموع + التوصيل:' : 'Total with Delivery:'}</div>
                  <div style="font-size:0.8rem;color:var(--brand-cyan);font-weight:700" id="nd-secondary-total">0 ${secCurrency}</div>
                </div>
                <div style="text-align:right">
                  <div style="font-size:1.35rem;font-weight:900;color:var(--primary)" id="nd-grand-total">$2.00</div>
                </div>
              </div>

            </div>

          </div>

          <!-- Modal Footer Actions -->
          <div class="modal-footer" style="background:var(--surface);padding:14px 22px;border-top:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;gap:10px">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('new-delivery-modal').remove()">
              ${isAR ? 'إلغاء' : 'Cancel'}
            </button>
            <div style="display:flex;gap:10px">
              ${!existingDeliveryId ? `
              <button type="submit" class="btn btn-secondary" name="action" value="open_pos" style="font-weight:800">
                🛒 ${isAR ? 'فتح في الكاشير POS' : 'Open in Full POS'}
              </button>` : ''}
              <button type="submit" class="btn btn-primary" name="action" value="save_only" style="font-weight:900;padding:8px 22px">
                💾 ${existingDeliveryId ? (isAR ? 'حفظ التعديلات' : 'Save Changes') : (isAR ? 'حفظ وإرسال للمطبخ' : 'Save & Send to Kitchen')}
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
    renderDeliveryItemPicker();
    renderDeliveryCart();
  }

  // Delivery Customer Search & Auto-Fill Suggestions
  function onDeliveryCustomerSearch(query) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const suggestionsEl = document.getElementById('nd-cust-suggestions');
    if (!suggestionsEl) return;

    const q = (query || '').trim().toLowerCase();
    if (!q) {
      suggestionsEl.style.display = 'none';
      return;
    }

    const matches = _ndCustomerList.filter(c => 
      (c.name || c.full_name || '').toLowerCase().includes(q) ||
      (c.phone || '').replace(/[^0-9]/g, '').includes(q.replace(/[^0-9]/g, ''))
    );

    if (!matches.length) {
      suggestionsEl.style.display = 'none';
      return;
    }

    suggestionsEl.style.display = 'block';
    suggestionsEl.innerHTML = matches.slice(0, 6).map(c => `
      <div style="padding:8px 12px;border-bottom:1px solid var(--border-color);cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-size:0.82rem" 
           onmouseover="this.style.background='var(--surface-2)'" 
           onmouseout="this.style.background='transparent'"
           onclick="Restaurant.selectDeliveryCustomer(${c.id})">
        <div>
          <strong style="color:var(--text-primary)">👤 ${Utils.sanitize(c.name || c.full_name)}</strong>
          <div style="font-size:0.72rem;color:var(--text-muted)">📍 ${Utils.sanitize(c.address || (isAR ? 'لا يوجد عنوان' : 'No address'))}</div>
        </div>
        <span style="color:var(--brand-cyan);font-family:monospace;font-weight:700">📞 ${c.phone || '-'}</span>
      </div>
    `).join('');
  }

  function selectDeliveryCustomer(customerId) {
    const cust = _ndCustomerList.find(c => c.id === customerId);
    if (!cust) return;

    document.getElementById('nd-name').value = cust.name || cust.full_name || '';
    document.getElementById('nd-phone').value = cust.phone || '';
    document.getElementById('nd-address').value = cust.address || '';
    document.getElementById('nd-cust-search').value = cust.name || cust.full_name || '';
    document.getElementById('nd-cust-suggestions').style.display = 'none';
  }

  function onDeliveryPhoneInput(phoneVal) {
    const clean = (phoneVal || '').replace(/[^0-9]/g, '');
    if (clean.length >= 6) {
      const match = _ndCustomerList.find(c => (c.phone || '').replace(/[^0-9]/g, '').includes(clean));
      if (match) {
        if (!document.getElementById('nd-name').value) {
          document.getElementById('nd-name').value = match.name || match.full_name || '';
        }
        if (!document.getElementById('nd-address').value) {
          document.getElementById('nd-address').value = match.address || '';
        }
      }
    }
  }

  // Render Item Picker grid inside Delivery Modal
  function renderDeliveryItemPicker(query = '') {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const grid = document.getElementById('nd-items-picker-grid');
    if (!grid) return;

    const catId = document.getElementById('nd-cat-filter')?.value || '';
    const q = (query || document.getElementById('nd-item-search')?.value || '').toLowerCase().trim();

    const filtered = _ndItemList.filter(it => {
      const matchQ = !q || (it.name_en || '').toLowerCase().includes(q) || (it.name_ar || '').toLowerCase().includes(q) || (it.item_code || '').toLowerCase().includes(q);
      const matchCat = !catId || String(it.category_id) === String(catId);
      return matchQ && matchCat;
    });

    if (!filtered.length) {
      grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:12px;color:var(--text-muted);font-size:0.75rem">${isAR ? 'لا توجد أصناف مطابقة' : 'No matching items'}</div>`;
      return;
    }

    grid.innerHTML = filtered.slice(0, 18).map(it => {
      const price = parseFloat(it.price || it.selling_price) || 0;
      const name = isAR ? (it.name_ar || it.name_en) : (it.name_en || it.name_ar);

      return `
      <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:6px 8px;cursor:pointer;display:flex;flex-direction:column;justify-content:space-between;transition:all 0.15s;color:var(--text-primary)"
           onmouseover="this.style.borderColor='var(--primary)';this.style.background='rgba(239,68,68,0.08)'"
           onmouseout="this.style.borderColor='var(--border-color)';this.style.background='var(--surface)'"
           onclick="Restaurant.addDeliveryItem(${it.id})">
        <div style="font-size:0.78rem;font-weight:700;line-height:1.2;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${Utils.sanitize(name)}">
          ${Utils.sanitize(name)}
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:800;color:var(--primary);font-size:0.82rem">$${price.toFixed(2)}</span>
          <span style="font-size:0.7rem;color:var(--brand-cyan);font-weight:800">+ Add</span>
        </div>
      </div>`;
    }).join('');
  }

  // Add Item to Delivery Order
  function addDeliveryItem(itemId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const it = _ndItemList.find(i => i.id === itemId);
    if (!it) return;

    const existing = _ndOrderItems.find(i => i.item_id === itemId);
    if (existing) {
      existing.qty += 1;
      existing.total = existing.qty * existing.price;
    } else {
      const price = parseFloat(it.price || it.selling_price) || 0;
      _ndOrderItems.push({
        item_id: it.id,
        name: isAR ? (it.name_ar || it.name_en) : (it.name_en || it.name_ar),
        name_en: it.name_en,
        name_ar: it.name_ar,
        price: price,
        qty: 1,
        total: price,
        notes: ''
      });
    }

    renderDeliveryCart();
  }

  function updateDeliveryItemQty(index, delta) {
    if (!_ndOrderItems[index]) return;
    _ndOrderItems[index].qty += delta;
    if (_ndOrderItems[index].qty <= 0) {
      _ndOrderItems.splice(index, 1);
    } else {
      _ndOrderItems[index].total = _ndOrderItems[index].qty * _ndOrderItems[index].price;
    }
    renderDeliveryCart();
  }

  function updateDeliveryItemNote(index, noteVal) {
    if (!_ndOrderItems[index]) return;
    _ndOrderItems[index].notes = noteVal;
  }

  function removeDeliveryItem(index) {
    _ndOrderItems.splice(index, 1);
    renderDeliveryCart();
  }

  function renderDeliveryCart() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const list = document.getElementById('nd-cart-items-list');
    const badge = document.getElementById('nd-items-count-badge');
    if (!list) return;

    if (badge) {
      const totalCount = _ndOrderItems.reduce((acc, it) => acc + it.qty, 0);
      badge.textContent = `${totalCount} ${isAR ? 'أصناف' : 'items'}`;
    }

    if (!_ndOrderItems.length) {
      list.innerHTML = `<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:0.78rem">${isAR ? 'لم تتم إضافة أي أطباق بعد. انقر على أي صنف أعلاه لإضافته.' : 'No items added yet. Click any item above to add.'}</div>`;
      updateDeliveryTotals();
      return;
    }

    list.innerHTML = _ndOrderItems.map((it, idx) => `
      <div style="display:flex;flex-direction:column;padding:8px 10px;background:var(--surface);border:1px solid var(--border-color);border-radius:8px;margin-bottom:6px;box-shadow:0 1px 3px rgba(0,0,0,0.03)">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="flex:1;overflow:hidden;padding-right:8px">
            <div style="font-weight:700;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${Utils.sanitize(it.name)}</div>
            <div style="font-size:0.75rem;color:var(--text-muted)">$${parseFloat(it.price || 0).toFixed(2)} each</div>
          </div>

          <div style="display:flex;align-items:center;gap:6px">
            <button type="button" class="btn btn-ghost btn-sm" onclick="Restaurant.updateDeliveryItemQty(${idx}, -1)" style="padding:1px 8px;font-size:0.85rem;background:var(--surface-2);border:1px solid var(--border-color);color:var(--text-primary);border-radius:4px">-</button>
            <span style="font-weight:800;font-size:0.88rem;min-width:20px;text-align:center;color:var(--text-primary)">${it.qty}</span>
            <button type="button" class="btn btn-ghost btn-sm" onclick="Restaurant.updateDeliveryItemQty(${idx}, 1)" style="padding:1px 8px;font-size:0.85rem;background:var(--surface-2);border:1px solid var(--border-color);color:var(--text-primary);border-radius:4px">+</button>
            
            <span style="font-weight:800;color:var(--primary);min-width:55px;text-align:right;font-size:0.9rem">$${parseFloat(it.total || 0).toFixed(2)}</span>
            <button type="button" class="btn btn-ghost btn-sm" onclick="Restaurant.removeDeliveryItem(${idx})" style="color:var(--danger);padding:2px 6px">✕</button>
          </div>
        </div>

        <!-- Per-Item Note Input -->
        <input type="text" class="form-control form-control-sm" 
          value="${Utils.sanitize(it.notes || '')}" 
          placeholder="${isAR ? '📝 ملاحظة خاصة بالصنف (مثال: بدون بصل)...' : '📝 Item note (e.g. Extra sauce, no onions)...'}" 
          oninput="Restaurant.updateDeliveryItemNote(${idx}, this.value)"
          style="margin-top:6px;font-size:0.74rem;padding:3px 8px;border-radius:6px;background:var(--surface-2);border:1px solid var(--border-color);color:var(--text-primary)">
      </div>
    `).join('');

    updateDeliveryTotals();
  }

  async function updateDeliveryTotals() {
    const fee = parseFloat(document.getElementById('nd-fee')?.value) || 0;
    const subtotal = _ndOrderItems.reduce((acc, it) => acc + (it.total || 0), 0);
    const grandTotal = subtotal + fee;

    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const secCurrency = await DB.getSetting('currency_2', 'LBP');

    const grandEl = document.getElementById('nd-grand-total');
    const secEl = document.getElementById('nd-secondary-total');

    if (grandEl) grandEl.textContent = `$${grandTotal.toFixed(2)}`;
    if (secEl) secEl.textContent = Utils.formatMoney(Utils.calcSecondaryPrice(grandTotal, 'USD', secCurrency, rate), secCurrency);
  }

  async function saveNewDeliveryOrder(e) {
    e.preventDefault();
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const submitBtn = e.submitter;
    const action = submitBtn ? submitBtn.value : 'save_only';

    const name = document.getElementById('nd-name').value.trim();
    const phone = document.getElementById('nd-phone').value.trim();
    const driver = document.getElementById('nd-driver').value.trim();
    const address = document.getElementById('nd-address').value.trim();
    const fee = parseFloat(document.getElementById('nd-fee').value) || 0;
    const payStatus = document.getElementById('nd-pay-status').value;

    const subtotal = _ndOrderItems.reduce((acc, it) => acc + (it.total || 0), 0);
    const grandTotal = subtotal + fee;

    const deliveryRecord = {
      order_type: 'delivery',
      customer_name: name,
      phone: phone,
      driver: driver,
      address: address,
      delivery_fee: fee,
      is_paid: payStatus === 'paid',
      payment_status: payStatus,
      status: 'cooking',
      items: _ndOrderItems,
      subtotal: subtotal,
      total: grandTotal,
      total_amount: grandTotal,
      created_at: new Date().toISOString()
    };

    const deliveryId = await DB.add('restaurant_delivery_orders', deliveryRecord);
    document.getElementById('new-delivery-modal')?.remove();
    Utils.showToast(isAR ? `تم تسجيل طلب التوصيل #DEL-${deliveryId}` : `Delivery order #DEL-${deliveryId} created`, 'success');

    if (action === 'open_pos') {
      openDeliveryInPOS(deliveryId);
    } else {
      render();
    }
  }

  // Open Delivery Order in POS
  async function openDeliveryInPOS(deliveryId) {
    const del = await DB.get('restaurant_delivery_orders', deliveryId);
    if (!del) return;

    sessionStorage.removeItem('redshark_active_table_id');
    sessionStorage.removeItem('redshark_takeaway_id');
    sessionStorage.setItem('redshark_delivery_id', String(del.id));
    sessionStorage.setItem('redshark_order_type', 'delivery');

    if (typeof App !== 'undefined' && App.navigate) {
      App.navigate('pos');
    } else {
      window.location.hash = '#pos';
    }
  }

  // Update Delivery Order Status
  async function updateDeliveryStatus(id, newStatus) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const del = await DB.get('restaurant_delivery_orders', id);
    if (!del) return;

    del.status = newStatus;
    if (newStatus === 'delivered') {
      del.delivered_at = new Date().toISOString();
    }
    await DB.update('restaurant_delivery_orders', del);
    Utils.showToast(isAR ? `تم تحديث حالة الطلب #DEL-${id}` : `Order #DEL-${id} status updated`, 'success');
    render();
  }

  // Open Delivery Details Modal with items, customer info, and reopen in POS action
  async function openDeliveryDetailsModal(deliveryId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const del = await DB.get('restaurant_delivery_orders', deliveryId);
    if (!del) return;

    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const secCurrency = await DB.getSetting('currency_2', 'LBP');
    const itemsTotal = parseFloat(del.total || del.total_amount) || 0;
    const fee = parseFloat(del.delivery_fee) || 0;
    const grandTotal = itemsTotal + fee;
    const isPaid = del.is_paid || del.payment_status === 'paid';

    let orderItems = [];
    if (Array.isArray(del.items)) orderItems = del.items;
    else if (typeof del.items === 'string') {
      try { orderItems = JSON.parse(del.items); } catch(e) {}
    }

    const modalHtml = `
    <div class="modal-overlay open" id="delivery-details-modal" style="z-index:9999;backdrop-filter:blur(8px)">
      <div class="modal" style="max-width:620px;width:92vw;border-radius:18px;background:var(--bg-base);border:1px solid var(--border-color);overflow:hidden">
        <div class="modal-header" style="background:var(--surface);padding:16px 20px;border-bottom:1px solid var(--border-color)">
          <div class="modal-title" style="font-weight:900;font-size:1.2rem;display:flex;align-items:center;gap:10px">
            <span>🛵</span> <span>${isAR ? 'تفاصيل ومعاينة طلب التوصيل' : 'Delivery Order Details'} #DEL-${del.id}</span>
          </div>
          <button class="btn-icon" onclick="document.getElementById('delivery-details-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:20px;display:flex;flex-direction:column;gap:14px;max-height:80vh;overflow-y:auto">
          
          <!-- Customer & Address Info -->
          <div style="background:var(--surface);padding:14px;border-radius:12px;border:1px solid var(--border-color);display:grid;grid-template-columns:1fr 1fr;gap:10px;font-size:0.85rem">
            <div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الزبون:' : 'Customer:'}</div>
              <div style="font-weight:800;font-size:0.95rem;color:var(--text-primary)">👤 ${Utils.sanitize(del.customer_name || 'Guest')}</div>
            </div>
            <div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الهاتف:' : 'Phone:'}</div>
              <div style="font-weight:800;color:var(--brand-cyan)">📞 ${Utils.sanitize(del.phone || '-')}</div>
            </div>
            <div style="grid-column:1/-1">
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'عنوان التوصيل:' : 'Delivery Address:'}</div>
              <div style="font-weight:700;color:var(--text-secondary);margin-top:2px">📍 ${Utils.sanitize(del.address || '-')}</div>
            </div>
            <div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'السائق المعين:' : 'Assigned Driver:'}</div>
              <div style="font-weight:800">${Utils.sanitize(del.driver || (isAR ? 'غير معين' : 'Unassigned'))}</div>
            </div>
            <div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'حالة الدفع:' : 'Payment Status:'}</div>
              <div>${isPaid ? `<span style="color:#10b981;font-weight:800">🟢 ${isAR ? 'مدفوع مسبقاً' : 'PAID (Prepaid)'}</span>` : `<span style="color:#ef4444;font-weight:800">🔴 ${isAR ? 'غير مدفوع (تحصيل عند الاستلام COD)' : 'UNPAID (Collect COD)'}</span>`}</div>
            </div>
          </div>

          <!-- Order Items Table -->
          <div>
            <div style="font-weight:800;font-size:0.9rem;margin-bottom:8px;display:flex;justify-content:space-between">
              <span>🍽️ ${isAR ? 'أصناف الطلب:' : 'Order Items:'}</span>
              <span style="font-size:0.78rem;color:var(--text-muted)">${orderItems.length} items</span>
            </div>
            <div style="border:1px solid var(--border-color);border-radius:10px;overflow:hidden;max-height:180px;overflow-y:auto">
              <table style="width:100%;border-collapse:collapse;font-size:0.82rem">
                <thead style="background:var(--surface-2);border-bottom:1px solid var(--border-color)">
                  <tr>
                    <th style="padding:8px 12px;text-align:left">${isAR ? 'الصنف' : 'Item'}</th>
                    <th style="padding:8px 12px;text-align:center">Qty</th>
                    <th style="padding:8px 12px;text-align:right">Price</th>
                    <th style="padding:8px 12px;text-align:right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${orderItems.map(it => `
                  <tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
                    <td style="padding:8px 12px;font-weight:700">
                      ${Utils.sanitize(it.name || it.name_en || it.name_ar || 'Item')}
                      ${it.notes ? `<div style="font-size:0.72rem;color:#fca5a5">⤷ ${Utils.sanitize(it.notes)}</div>` : ''}
                    </td>
                    <td style="padding:8px 12px;text-align:center;font-weight:800">${it.qty || it.quantity || 1}</td>
                    <td style="padding:8px 12px;text-align:right">$${parseFloat(it.price || 0).toFixed(2)}</td>
                    <td style="padding:8px 12px;text-align:right;font-weight:800;color:var(--primary)">$${((it.price || 0) * (it.qty || it.quantity || 1)).toFixed(2)}</td>
                  </tr>`).join('')}
                  ${!orderItems.length ? `<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-muted)">${isAR ? 'لا توجد أصناف في هذا الطلب' : 'No items attached to order'}</td></tr>` : ''}
                </tbody>
              </table>
            </div>
          </div>

          <!-- Total Breakdown -->
          <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:12px 16px;display:flex;justify-content:space-between;align-items:center">
            <div>
              <div style="font-size:0.78rem;color:var(--text-muted)">${isAR ? 'رسوم التوصيل:' : 'Delivery Fee:'} $${fee.toFixed(2)}</div>
              <div style="font-size:0.85rem;color:var(--brand-cyan);font-weight:800">${Utils.formatMoney(Utils.calcSecondaryPrice(grandTotal, 'USD', secCurrency, rate), secCurrency)}</div>
            </div>
            <div style="text-align:right">
              <span style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الإجمالي العام:' : 'Grand Total:'}</span>
              <div style="font-size:1.4rem;font-weight:900;color:var(--primary)">$${grandTotal.toFixed(2)}</div>
            </div>
          </div>

        </div>
        <div class="modal-footer" style="padding:14px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('delivery-details-modal').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
          
          <div style="display:flex;gap:6px">
            <button class="btn btn-secondary" onclick="document.getElementById('delivery-details-modal').remove(); Restaurant.openNewDeliveryModal(${del.id})">
              ✏️ ${isAR ? 'تعديل الطلب والملاحظات' : 'Edit Order & Notes'}
            </button>
            <button class="btn btn-secondary" onclick="document.getElementById('delivery-details-modal').remove(); Restaurant.printDeliveryDispatchTicket(${del.id})">
              🖨️ ${isAR ? 'طباعة البون' : 'Print Slip'}
            </button>
            ${!isPaid ? `
            <button class="btn btn-secondary" onclick="document.getElementById('delivery-details-modal').remove(); Restaurant.openSettlePaymentModal(${del.id})" style="border-color:rgba(239,68,68,0.4);color:#fca5a5">
              💳 ${isAR ? 'تسديد COD' : 'Settle COD'}
            </button>` : ''}
            <button class="btn btn-primary" onclick="document.getElementById('delivery-details-modal').remove(); Restaurant.openDeliveryInPOS(${del.id})" style="font-weight:800">
              🛒 ${isAR ? 'فتح في POS' : 'Open in POS'}
            </button>
          </div>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  // Quick Settle Payment Modal for Unpaid Delivery Orders
  async function openSettlePaymentModal(deliveryId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const del = await DB.get('restaurant_delivery_orders', deliveryId);
    if (!del) return;

    const itemsTotal = parseFloat(del.total || del.total_amount) || 0;
    const fee = parseFloat(del.delivery_fee) || 0;
    const grandTotal = itemsTotal + fee;
    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const secCurrency = await DB.getSetting('currency_2', 'LBP');

    const modalHtml = `
    <div class="modal-overlay open" id="settle-pay-modal">
      <div class="modal" style="max-width:460px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:900;font-size:1.15rem">💳 ${isAR ? 'تسديد وتحصيل حساب التوصيل' : 'Settle Delivery Payment'} #DEL-${del.id}</div>
          <button class="btn-icon" onclick="document.getElementById('settle-pay-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px;display:flex;flex-direction:column;gap:12px">
          
          <div style="background:rgba(239,68,68,0.1);padding:12px 16px;border-radius:12px;border:1px solid rgba(239,68,68,0.25);display:flex;justify-content:space-between;align-items:baseline">
            <span style="font-weight:700">${isAR ? 'المبلغ المطلوب تحصيله:' : 'Amount to Collect:'}</span>
            <div style="text-align:right">
              <span style="font-size:1.4rem;font-weight:900;color:var(--primary)">$${grandTotal.toFixed(2)}</span>
              <div style="font-size:0.75rem;color:var(--brand-cyan);font-weight:700">${Utils.formatMoney(Utils.calcSecondaryPrice(grandTotal, 'USD', secCurrency, rate), secCurrency)}</div>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" style="font-weight:700">${isAR ? 'طريقة الدفع المستلمة' : 'Payment Method'}</label>
            <select id="settle-pay-method" class="form-control" style="font-size:0.95rem;padding:8px">
              <option value="Cash">💵 ${isAR ? 'نقدي (كاش)' : 'Cash'}</option>
              <option value="Card">💳 ${isAR ? 'بطاقة بنكية / فيزا' : 'Credit / Debit Card'}</option>
              <option value="Online">📲 ${isAR ? 'تحويل إلكتروني / Wish Money' : 'Online / Digital Transfer'}</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label" style="font-weight:700">${isAR ? 'تحديث حالة التوصيل أيضاً؟' : 'Also mark as Delivered?'}</label>
            <select id="settle-del-status" class="form-control">
              <option value="delivered">✅ ${isAR ? 'نعم، تم التسليم للزبون' : 'Yes, mark as Delivered'}</option>
              <option value="keep">🔄 ${isAR ? 'إبقاء الحالة الحالية' : 'Keep current delivery status'}</option>
            </select>
          </div>

        </div>
        <div class="modal-footer" style="padding:14px 22px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('settle-pay-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Restaurant.executeSettlePayment(${del.id})" style="font-weight:800">
            💾 ${isAR ? 'تأكيد التسديد' : 'Confirm Payment'}
          </button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function executeSettlePayment(deliveryId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const del = await DB.get('restaurant_delivery_orders', deliveryId);
    if (!del) return;

    const payMethod = document.getElementById('settle-pay-method').value;
    const delStatusChoice = document.getElementById('settle-del-status').value;

    del.is_paid = true;
    del.payment_status = 'paid';
    del.payment_method = payMethod;
    del.paid_at = new Date().toISOString();

    if (delStatusChoice === 'delivered') {
      del.status = 'delivered';
      del.delivered_at = new Date().toISOString();
    }

    await DB.update('restaurant_delivery_orders', del);

    // Record in cashbox if CashBox exists
    const grandTotal = (parseFloat(del.total || del.total_amount) || 0) + (parseFloat(del.delivery_fee) || 0);
    if (window.CashBox && typeof CashBox.recordSale === 'function' && payMethod === 'Cash') {
      await CashBox.recordSale(grandTotal, `Delivery Payment #DEL-${del.id}`);
    }

    document.getElementById('settle-pay-modal')?.remove();
    Utils.showToast(isAR ? `تم تسديد حساب الطلب #DEL-${deliveryId} بنجاح` : `Payment settled for #DEL-${deliveryId}`, 'success');
    render();
  }

  // Prompt to reassign driver
  async function reassignDriverPrompt(deliveryId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const del = await DB.get('restaurant_delivery_orders', deliveryId);
    if (!del) return;

    const newDriver = prompt(isAR ? 'اسم السائق / المندوب:' : 'Assigned Driver Name:', del.driver || '');
    if (newDriver !== null) {
      del.driver = newDriver.trim();
      await DB.update('restaurant_delivery_orders', del);
      render();
    }
  }

  // Cancel Delivery Order
  async function cancelDeliveryOrder(id) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    if (!confirm(isAR ? 'هل أنت متأكد من إلغاء هذا الطلب؟' : 'Are you sure you want to cancel this delivery order?')) return;

    const del = await DB.get('restaurant_delivery_orders', id);
    if (del) {
      del.status = 'cancelled';
      await DB.update('restaurant_delivery_orders', del);
      Utils.showToast(isAR ? 'تم إلغاء الطلب' : 'Order cancelled', 'info');
      render();
    }
  }

  // Print Delivery Dispatch Ticket for Driver
  async function printDeliveryDispatchTicket(deliveryId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const del = await DB.get('restaurant_delivery_orders', deliveryId);
    if (!del) return;

    const company = await DB.getSetting('company_name', 'Red Shark Restaurant');
    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const secCurrency = await DB.getSetting('currency_2', 'LBP');

    const itemsTotal = parseFloat(del.total || del.total_amount) || 0;
    const fee = parseFloat(del.delivery_fee) || 0;
    const grandTotal = itemsTotal + fee;
    const isPaid = del.is_paid || del.payment_status === 'paid';

    let orderItems = [];
    if (Array.isArray(del.items)) orderItems = del.items;
    else if (typeof del.items === 'string') {
      try { orderItems = JSON.parse(del.items); } catch(e) {}
    }

    const receiptHtml = `
      <div style="font-family:'Courier New', monospace;width:280px;margin:0 auto;padding:10px;font-size:12px;color:#000;text-align:center">
        <h2 style="margin:0;font-size:16px;font-weight:900">${Utils.sanitize(company)}</h2>
        <div style="font-size:11px;font-weight:700">*** ${isAR ? 'بون توصيل طلب (DELIVERY DISPATCH)' : 'DELIVERY DISPATCH SLIP'} ***</div>
        <div style="font-size:14px;font-weight:900;margin:6px 0;border:2px solid #000;padding:4px">
          ORDER #DEL-${del.id}
        </div>

        <div style="border-top:1px dashed #000;border-bottom:1px dashed #000;padding:6px 0;margin:6px 0;text-align:left;font-size:11px">
          <div><strong>${isAR ? 'الزبون:' : 'Customer:'}</strong> ${Utils.sanitize(del.customer_name)}</div>
          <div><strong>${isAR ? 'الهاتف:' : 'Phone:'}</strong> ${Utils.sanitize(del.phone)}</div>
          <div><strong>${isAR ? 'العنوان:' : 'Address:'}</strong> ${Utils.sanitize(del.address)}</div>
          <div><strong>${isAR ? 'السائق:' : 'Driver:'}</strong> ${Utils.sanitize(del.driver || 'Unassigned')}</div>
          <div><strong>${isAR ? 'التاريخ:' : 'Time:'}</strong> ${new Date(del.created_at || Date.now()).toLocaleString()}</div>
        </div>

        <table style="width:100%;border-collapse:collapse;font-size:11px;text-align:left;margin-top:6px">
          <thead>
            <tr style="border-bottom:1px solid #000">
              <th>${isAR ? 'الصنف' : 'Item'}</th>
              <th style="text-align:center">Qty</th>
              <th style="text-align:right">Price</th>
            </tr>
          </thead>
          <tbody>
            ${orderItems.map(it => `
            <tr>
              <td style="padding:3px 0">
                <div>${Utils.sanitize(it.name || it.name_en || it.name_ar)}</div>
                ${it.notes ? `<div style="font-size:9px">⤷ ${Utils.sanitize(it.notes)}</div>` : ''}
              </td>
              <td style="text-align:center;padding:3px 0">${it.qty || it.quantity || 1}</td>
              <td style="text-align:right;padding:3px 0">$${((it.price || 0) * (it.qty || it.quantity || 1)).toFixed(2)}</td>
            </tr>`).join('')}
          </tbody>
        </table>

        <div style="border-top:1px dashed #000;margin-top:8px;padding-top:6px;text-align:right">
          <div style="display:flex;justify-content:space-between;font-size:11px">
            <span>${isAR ? 'قيمة الأصناف:' : 'Subtotal:'}</span>
            <span>$${itemsTotal.toFixed(2)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:11px">
            <span>${isAR ? 'رسوم التوصيل:' : 'Delivery Fee:'}</span>
            <span>$${fee.toFixed(2)}</span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:14px;font-weight:900;border-top:1px solid #000;padding-top:4px;margin-top:4px">
            <span>${isAR ? 'الإجمالي:' : 'Grand Total:'}</span>
            <span>$${grandTotal.toFixed(2)}</span>
          </div>
          <div style="font-size:12px;font-weight:700;margin-top:2px">
            ${Utils.formatMoney(Utils.calcSecondaryPrice(grandTotal, 'USD', secCurrency, rate), secCurrency)}
          </div>
        </div>

        <div style="margin-top:10px;padding:6px;border:2px dashed #000;font-size:12px;font-weight:900">
          ${isPaid ? `🟢 *** ${isAR ? 'تم الدفع مسبقاً (PAID)' : 'PREPAID / ALREADY PAID'} ***` : `🔴 *** ${isAR ? `تحصيل كاش عند الاستلام: $${grandTotal.toFixed(2)}` : `COLLECT COD: $${grandTotal.toFixed(2)}`} ***`}
        </div>

        <div style="margin-top:12px;font-size:10px">
          ${isAR ? 'شكراً لطلبكم • نأمل أن ينال إعجابكم' : 'Thank you for your order!'}
        </div>
      </div>
    `;

    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'fixed';
    printFrame.style.right = '0';
    printFrame.style.bottom = '0';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = '0';
    document.body.appendChild(printFrame);
    
    const doc = printFrame.contentWindow.document;
    doc.open();
    doc.write(`<html><head><title>Dispatch #DEL-${del.id}</title></head><body>${receiptHtml}</body></html>`);
    doc.close();
    
    setTimeout(() => {
      printFrame.contentWindow.focus();
      printFrame.contentWindow.print();
      setTimeout(() => document.body.removeChild(printFrame), 1000);
    }, 300);

    Utils.showToast(isAR ? `تمت طباعة بون التوصيل للطلب #DEL-${del.id}` : `Dispatch slip printed for #DEL-${del.id}`, 'success');
  }

  // Print Preliminary Guest Check (Bill)
  async function printGuestCheck(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const table = await DB.get('restaurant_tables', tableId);
    if (!table || !table.current_order) {
      Utils.showToast(isAR ? 'لا يوجد طلب نشط لهذه الطاولة' : 'No active order on this table', 'warning');
      return;
    }

    table.status = 'billed';
    await DB.update('restaurant_tables', table);

    const company = await DB.getSetting('company_name', 'Red Shark Restaurant');
    const secCurrency = await DB.getSetting('currency_2', 'LBP');
    const rate = parseFloat(await DB.getSetting('exchange_rate', 89500)) || 89500;
    const order = table.current_order;

    const receiptHtml = `
      <div style="font-family:'Courier New', monospace;width:280px;margin:0 auto;padding:10px;font-size:12px;color:#000;text-align:center">
        <h2 style="margin:0;font-size:16px;font-weight:900">${Utils.sanitize(company)}</h2>
        <div style="font-size:11px;margin-top:2px;font-weight:700">*** ${isAR ? 'حساب مبدئي للزبون' : 'GUEST CHECK (PRE-BILL)'} ***</div>
        <div style="border-top:1px dashed #000;border-bottom:1px dashed #000;padding:6px 0;margin:8px 0;text-align:left;font-size:11px">
          <div><strong>${isAR ? 'الطاولة:' : 'Table:'}</strong> ${table.table_number}</div>
          <div><strong>${isAR ? 'الويتر:' : 'Waiter:'}</strong> ${order.waiter_name || 'Staff'}</div>
          <div><strong>${isAR ? 'التاريخ والوقت:' : 'Date:'}</strong> ${new Date().toLocaleString()}</div>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:11px;text-align:left">
          <thead>
            <tr style="border-bottom:1px solid #000">
              <th>${isAR ? 'الصنف' : 'Item'}</th>
              <th style="text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>
              <th style="text-align:right">${isAR ? 'السعر' : 'Price'}</th>
            </tr>
          </thead>
          <tbody>
            ${(order.items || []).map(item => `
            <tr>
              <td style="padding:3px 0">
                <div>${Utils.sanitize(item.name || item.item_name)}</div>
                ${item.notes ? `<div style="font-size:9px;color:#555">⤷ ${item.notes}</div>` : ''}
              </td>
              <td style="text-align:center;padding:3px 0">${item.quantity || item.qty || 1}</td>
              <td style="text-align:right;padding:3px 0">$${((item.price || 0) * (item.quantity || item.qty || 1)).toFixed(2)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
        <div style="border-top:1px dashed #000;margin-top:8px;padding-top:6px;text-align:right">
          <div style="font-size:14px;font-weight:900">
            <span>${isAR ? 'الإجمالي:' : 'Total:'} </span>
            <span>$${(order.total || 0).toFixed(2)}</span>
          </div>
          <div style="font-size:12px;font-weight:700;margin-top:2px">
            ${Utils.formatMoney(Utils.calcSecondaryPrice(order.total || 0, 'USD', secCurrency, rate), secCurrency)}
          </div>
        </div>
        <div style="margin-top:14px;font-size:10px;border-top:1px solid #ccc;padding-top:4px">
          ${isAR ? 'هذا ليس إيصالاً نهائياً - شكراً لزيارتكم' : 'Not a final fiscal tax invoice • Thank you!'}
        </div>
      </div>
    `;

    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'fixed';
    printFrame.style.right = '0';
    printFrame.style.bottom = '0';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = '0';
    document.body.appendChild(printFrame);
    
    const doc = printFrame.contentWindow.document;
    doc.open();
    doc.write(`<html><head><title>Guest Check - Table ${table.table_number}</title></head><body>${receiptHtml}</body></html>`);
    doc.close();
    
    setTimeout(() => {
      printFrame.contentWindow.focus();
      printFrame.contentWindow.print();
      setTimeout(() => document.body.removeChild(printFrame), 1000);
    }, 300);

    Utils.showToast(isAR ? `تم طباعة حساب الطاولة ${table.table_number}` : `Guest bill printed for Table ${table.table_number}`, 'success');
    render();
  }

  // Transfer Table Modal
  async function openTransferModal(fromTableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const fromTable = await DB.get('restaurant_tables', fromTableId);
    if (!fromTable) return;

    const allTables = await DB.getAll('restaurant_tables') || [];
    const freeTables = allTables.filter(t => t.id !== fromTable.id && (!t.status || t.status === 'free') && !t.merged_with);

    if (!freeTables.length) {
      Utils.showToast(isAR ? 'لا توجد طاولات شاغرة لنقل الطلب إليها' : 'No available free tables to transfer to', 'warning');
      return;
    }

    const modalHtml = `
    <div class="modal-overlay open" id="transfer-table-modal">
      <div class="modal" style="max-width:440px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">🔀 ${isAR ? 'نقل الطلب لطاولة أخرى' : 'Transfer Table Order'}</div>
          <button class="btn-icon" onclick="document.getElementById('transfer-table-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:16px 20px">
          <p style="font-size:0.86rem;color:var(--text-muted);margin-bottom:14px">
            ${isAR ? `نقل الحساب والطلبات من الطاولة <strong>${fromTable.table_number}</strong> إلى:` : `Transfer active order from <strong>Table ${fromTable.table_number}</strong> to:`}
          </p>
          <div class="form-group">
            <label class="form-label" style="font-weight:700">${isAR ? 'اختر الطاولة الشاغرة الجديدة' : 'Select Target Free Table'}</label>
            <select class="form-control" id="target-table-select" style="font-size:0.95rem;padding:10px">
              ${freeTables.map(t => `<option value="${t.id}">${t.table_number} (${t.name}) - ${t.capacity} ${isAR ? 'كراسي' : 'Seats'}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('transfer-table-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Restaurant.executeTransfer(${fromTable.id})">🔀 ${isAR ? 'تأكيد النقل' : 'Confirm Transfer'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function executeTransfer(fromTableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const targetId = parseInt(document.getElementById('target-table-select').value, 10);
    if (!targetId) return;

    const fromTable = await DB.get('restaurant_tables', fromTableId);
    const toTable = await DB.get('restaurant_tables', targetId);
    if (!fromTable || !toTable) return;

    toTable.status = fromTable.status;
    toTable.seated_at = fromTable.seated_at;
    toTable.waiter_id = fromTable.waiter_id;
    toTable.waiter_name = fromTable.waiter_name;
    toTable.guest_count = fromTable.guest_count;
    toTable.current_order = fromTable.current_order;
    if (toTable.current_order) {
      toTable.current_order.table_id = toTable.id;
      toTable.current_order.table_number = toTable.table_number;
    }

    fromTable.status = 'free';
    fromTable.seated_at = null;
    fromTable.waiter_name = null;
    fromTable.current_order = null;

    await DB.update('restaurant_tables', toTable);
    await DB.update('restaurant_tables', fromTable);

    document.getElementById('transfer-table-modal')?.remove();
    Utils.showToast(isAR ? `تم نقل الطلب بنجاح إلى الطاولة ${toTable.table_number}` : `Order transferred to Table ${toTable.table_number}`, 'success');
    render();
  }

  // Force Free / Clear Table
  async function freeTablePrompt(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const table = await DB.get('restaurant_tables', tableId);
    if (!table) return;

    if (!confirm(isAR ? `هل أنت متأكد من إخلاء وتفريغ الطاولة ${table.table_number}؟` : `Are you sure you want to free and clear Table ${table.table_number}?`)) return;

    table.status = 'free';
    table.seated_at = null;
    table.current_order = null;
    table.merged_with = null;
    await DB.update('restaurant_tables', table);
    Utils.showToast(isAR ? `تم تفريغ الطاولة ${table.table_number}` : `Table ${table.table_number} cleared`, 'info');
    render();
  }

  // Table Merging / Linking Modal
  async function openMergeTablesModal() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const allTables = await DB.getAll('restaurant_tables') || [];
    const masterCandidates = allTables.filter(t => !t.merged_with);
    const secondaryCandidates = allTables.filter(t => !t.merged_with && (!t.status || t.status === 'free'));

    const modalHtml = `
    <div class="modal-overlay open" id="merge-tables-modal">
      <div class="modal" style="max-width:480px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">🔗 ${isAR ? 'دمج طاولات لمجموعة كبيرة' : 'Merge Tables (Party Joining)'}</div>
          <button class="btn-icon" onclick="document.getElementById('merge-tables-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px">
          <p style="font-size:0.84rem;color:var(--text-muted);margin-bottom:14px">
            ${isAR ? 'اختر الطاولة الرئيسية التي تحتوي على الحساب، والطاولة الثانوية المراد ضمها إليها:' : 'Select the primary master table with the active bill, and the secondary table to join:'}
          </p>
          <div class="form-group mb-3">
            <label class="form-label" style="font-weight:700">${isAR ? 'الطاولة الأساسية (Master Table)' : 'Primary Master Table'}</label>
            <select class="form-control" id="merge-master-select">
              ${masterCandidates.map(t => `<option value="${t.id}">Table ${t.table_number} (${t.status || 'free'})</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" style="font-weight:700">${isAR ? 'الطاولة المراد دمجها وإلحاقها' : 'Secondary Table to Merge'}</label>
            <select class="form-control" id="merge-secondary-select">
              ${secondaryCandidates.map(t => `<option value="${t.id}">Table ${t.table_number} (${t.capacity} seats)</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('merge-tables-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Restaurant.executeMergeTables()">🔗 ${isAR ? 'تأكيد الدمج' : 'Merge Tables'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function executeMergeTables() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const masterId = parseInt(document.getElementById('merge-master-select').value, 10);
    const secId = parseInt(document.getElementById('merge-secondary-select').value, 10);

    if (masterId === secId) {
      Utils.showToast(isAR ? 'لا يمكن دمج نفس الطاولة مع نفسها' : 'Cannot merge table with itself', 'warning');
      return;
    }

    const masterTable = await DB.get('restaurant_tables', masterId);
    const secTable = await DB.get('restaurant_tables', secId);

    if (!masterTable || !secTable) return;

    secTable.merged_with = masterTable.table_number;
    secTable.status = 'occupied';
    await DB.update('restaurant_tables', secTable);

    document.getElementById('merge-tables-modal')?.remove();
    Utils.showToast(isAR ? `تم دمج الطاولة ${secTable.table_number} مع ${masterTable.table_number}` : `Table ${secTable.table_number} merged with ${masterTable.table_number}`, 'success');
    render();
  }

  async function unmergeTable(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const table = await DB.get('restaurant_tables', tableId);
    if (!table) return;

    table.merged_with = null;
    table.status = 'free';
    await DB.update('restaurant_tables', table);
    Utils.showToast(isAR ? `تم فك دمج الطاولة ${table.table_number}` : `Table ${table.table_number} unlinked`, 'info');
    render();
  }

  // Reservations Management Modals
  async function openReservationsModal() {
    openNewReservationForm();
  }

  async function openNewReservationForm() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const tables = await DB.getAll('restaurant_tables') || [];

    const modalHtml = `
    <div class="modal-overlay open" id="reservations-modal">
      <div class="modal" style="max-width:540px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:900;font-size:1.15rem">📅 ${isAR ? 'إضافة حجز جديد' : 'New Table Booking'}</div>
          <button class="btn-icon" onclick="document.getElementById('reservations-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px;display:flex;flex-direction:column;gap:12px">
          <div class="form-group">
            <label class="form-label" style="font-weight:700">${isAR ? 'اسم الضيف *' : 'Guest Name *'}</label>
            <input type="text" id="res-guest-name" class="form-control" placeholder="${isAR ? 'اسم صاحب الحجز' : 'Guest Name'}" required>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'رقم الهاتف' : 'Phone Number'}</label>
              <input type="tel" id="res-guest-phone" class="form-control" placeholder="Phone">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'عدد الضيوف' : 'Guests Count (Pax)'}</label>
              <input type="number" id="res-pax" class="form-control" value="2" min="1">
            </div>
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'موعد الحجز' : 'Date & Time'}</label>
              <input type="datetime-local" id="res-time" class="form-control" value="${new Date(Date.now() + 3600000).toISOString().slice(0, 16)}">
            </div>
            <div class="form-group">
              <label class="form-label" style="font-weight:700">${isAR ? 'طاولة محددة (اختياري)' : 'Specific Table'}</label>
              <select id="res-table-id" class="form-control">
                <option value="">${isAR ? '-- أي طاولة متاحة --' : '-- Any Free Table --'}</option>
                ${tables.map(t => `<option value="${t.id}">Table ${t.table_number} (${t.capacity} seats)</option>`).join('')}
              </select>
            </div>
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('reservations-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="Restaurant.saveNewReservation()">💾 ${isAR ? 'تسجيل الحجز' : 'Save Booking'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function saveNewReservation() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const guestName = document.getElementById('res-guest-name').value.trim();
    if (!guestName) {
      Utils.showToast(isAR ? 'يرجى إدخال اسم الضيف' : 'Please enter guest name', 'warning');
      return;
    }
    const phone = document.getElementById('res-guest-phone').value.trim();
    const pax = parseInt(document.getElementById('res-pax').value, 10) || 2;
    const time = document.getElementById('res-time').value;
    const tableId = document.getElementById('res-table-id').value;

    const resRecord = {
      guest_name: guestName,
      guest_phone: phone,
      pax: pax,
      reservation_time: time,
      table_id: tableId ? parseInt(tableId, 10) : null,
      status: 'confirmed',
      created_at: new Date().toISOString()
    };

    await DB.add('restaurant_reservations', resRecord);

    if (tableId) {
      const table = await DB.get('restaurant_tables', parseInt(tableId, 10));
      if (table && (!table.status || table.status === 'free')) {
        table.status = 'reserved';
        table.reservation_guest = guestName;
        table.reservation_time = new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        table.reservation_pax = pax;
        await DB.update('restaurant_tables', table);
      }
    }

    document.getElementById('reservations-modal')?.remove();
    Utils.showToast(isAR ? 'تم تسجيل الحجز بنجاح' : 'Reservation booked successfully', 'success');
    render();
  }

  async function quickReserveTable(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const guestName = prompt(isAR ? 'اسم صاحب الحجز:' : 'Guest Name for reservation:');
    if (!guestName) return;

    const table = await DB.get('restaurant_tables', tableId);
    if (!table) return;

    table.status = 'reserved';
    table.reservation_guest = guestName;
    table.reservation_time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    table.reservation_pax = table.capacity || 4;
    await DB.update('restaurant_tables', table);

    await DB.add('restaurant_reservations', {
      guest_name: guestName,
      table_id: table.id,
      pax: table.capacity || 4,
      reservation_time: new Date().toISOString(),
      status: 'confirmed'
    });

    Utils.showToast(isAR ? `تم حجز الطاولة ${table.table_number}` : `Table ${table.table_number} reserved`, 'success');
    render();
  }

  async function seatReservedGuest(tableId) {
    const table = await DB.get('restaurant_tables', tableId);
    if (!table) return;

    table.status = 'free';
    table.reservation_guest = null;
    table.reservation_time = null;
    table.reservation_pax = null;
    await DB.update('restaurant_tables', table);

    await openTableOrder(tableId);
  }

  async function seatReservationFromDiary(resId) {
    const res = await DB.get('restaurant_reservations', resId);
    if (!res) return;

    let targetTableId = res.table_id;
    if (!targetTableId) {
      const allTables = await DB.getAll('restaurant_tables') || [];
      const free = allTables.find(t => !t.status || t.status === 'free');
      if (!free) {
        Utils.showToast('No free table available right now', 'warning');
        return;
      }
      targetTableId = free.id;
    }

    res.status = 'seated';
    await DB.update('restaurant_reservations', res);
    await openTableOrder(targetTableId);
  }

  async function cancelTableReservation(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const table = await DB.get('restaurant_tables', tableId);
    if (!table) return;

    table.status = 'free';
    table.reservation_guest = null;
    table.reservation_time = null;
    table.reservation_pax = null;
    await DB.update('restaurant_tables', table);
    Utils.showToast(isAR ? 'تم إلغاء الحجز' : 'Reservation cancelled', 'info');
    render();
  }

  async function cancelReservation(resId) {
    const res = await DB.get('restaurant_reservations', resId);
    if (res) {
      res.status = 'cancelled';
      await DB.update('restaurant_reservations', res);
      render();
    }
  }

  async function deleteReservation(resId) {
    await DB.remove('restaurant_reservations', resId);
    render();
  }

  // Fullscreen Kitchen Display Modal
  async function openKitchenDisplay() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const tables = await DB.getAll('restaurant_tables') || [];
    const activeOrders = tables.filter(t => (t.status === 'occupied' || t.status === 'billed') && t.current_order?.items?.length);

    const kdsHtml = `
    <div class="modal-overlay open" id="kds-screen-modal" style="z-index:9999;background:rgba(5,7,15,0.96);backdrop-filter:blur(20px)">
      <div style="width:96vw;height:94vh;background:var(--bg-base);border:1px solid var(--border-color);border-radius:20px;display:flex;flex-direction:column;overflow:hidden">
        
        <div style="padding:14px 24px;border-bottom:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;background:var(--surface);flex-wrap:wrap;gap:10px">
          <div style="display:flex;align-items:center;gap:14px">
            <span style="font-size:1.8rem">🍳</span>
            <div>
              <h2 style="margin:0;font-size:1.35rem;font-weight:900">${isAR ? 'شاشة المطبخ والبار المباشرة (KDS)' : 'Live Kitchen & Bar Display System (KDS)'}</h2>
              <span style="font-size:0.78rem;color:var(--text-muted)">${activeOrders.length} ${isAR ? 'طلبات قيد الطهي والتحضير' : 'Active Orders in Preparation'}</span>
            </div>
          </div>

          <div style="display:flex;gap:6px;align-items:center">
            <button class="btn ${kdsStationFilter === 'all' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setKdsStation('all')">
              🌐 ${isAR ? 'كل المحطات' : 'All Stations'}
            </button>
            <button class="btn ${kdsStationFilter === 'kitchen' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setKdsStation('kitchen')">
              🍳 ${isAR ? 'المطبخ الساخن' : 'Hot Kitchen'}
            </button>
            <button class="btn ${kdsStationFilter === 'bar' ? 'btn-primary' : 'btn-secondary'} btn-sm" onclick="Restaurant.setKdsStation('bar')">
              🍹 ${isAR ? 'محطة البار والمشروبات' : 'Bar & Drinks'}
            </button>
            <button class="btn btn-ghost btn-sm" onclick="document.getElementById('kds-screen-modal').remove()" style="margin-inline-start:12px;font-weight:800">
              ✕ ${isAR ? 'إغلاق' : 'Close'}
            </button>
          </div>
        </div>

        <div style="flex:1;overflow-y:auto;padding:20px;display:grid;grid-template-columns:repeat(auto-fill, minmax(310px, 1fr));gap:16px" id="kds-grid-container">
          ${activeOrders.map(t => {
            const ord = t.current_order;
            const seatedMins = t.seated_at ? Math.max(1, Math.round((Date.now() - new Date(t.seated_at).getTime()) / 60000)) : 1;
            
            let cardBorder = '#10b981';
            let timerBadge = 'badge-success';
            if (seatedMins >= 20) {
              cardBorder = '#ef4444';
              timerBadge = 'badge-danger';
            } else if (seatedMins >= 10) {
              cardBorder = '#f59e0b';
              timerBadge = 'badge-warning';
            }

            return `
            <div class="card" style="padding:16px;border-radius:16px;border:2px solid ${cardBorder};background:var(--surface);display:flex;flex-direction:column;justify-content:space-between;box-shadow:var(--shadow-md)">
              <div>
                <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:10px;margin-bottom:12px">
                  <div>
                    <span style="font-size:1.3rem;font-weight:900">Table ${t.table_number}</span>
                    <div style="font-size:0.75rem;color:var(--text-muted)">👤 ${ord.waiter_name || 'Staff'}</div>
                  </div>
                  <span class="badge ${timerBadge}" style="font-size:0.85rem;font-weight:900;padding:4px 8px">⏱️ ${seatedMins}m</span>
                </div>

                <div style="display:flex;flex-direction:column;gap:10px">
                  ${(ord.items || []).map((it, idx) => `
                  <div style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;border-bottom:1px dashed rgba(255,255,255,0.05)" id="kds-item-modal-${t.id}-${idx}">
                    <input type="checkbox" style="width:18px;height:18px;cursor:pointer;margin-top:2px" onchange="Restaurant.toggleKdsItemCheck(this, 'kds-item-modal-${t.id}-${idx}')">
                    <div style="flex:1">
                      <div style="font-size:0.96rem;font-weight:800">
                        <span style="color:var(--primary);font-weight:900">${it.quantity || 1}x</span> ${Utils.sanitize(it.name || it.item_name)}
                      </div>
                      ${it.notes ? `<div style="font-size:0.8rem;color:#fca5a5;font-weight:700">⤷ ${Utils.sanitize(it.notes)}</div>` : ''}
                    </div>
                  </div>`).join('')}
                </div>
              </div>

              <div style="margin-top:16px;border-top:1px solid var(--border-color);padding-top:12px">
                <button class="btn btn-primary btn-sm" style="width:100%;font-weight:900;padding:10px" onclick="Restaurant.markOrderReady(${t.id})">
                  ✅ ${isAR ? 'جاهز للتسليم (BUMP)' : 'BUMP / ORDER READY'}
                </button>
              </div>
            </div>`;
          }).join('')}
          ${!activeOrders.length ? `
          <div style="grid-column:1/-1;text-align:center;padding:100px 20px;color:var(--text-muted)">
            <span style="font-size:3.5rem">✨</span>
            <h3 style="margin-top:12px">${isAR ? 'لا توجد طلبات معلقة في المطبخ حالياً' : 'All orders completed! Kitchen queue is clean'}</h3>
          </div>` : ''}
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = kdsHtml;
  }

  function setKdsStation(st) {
    kdsStationFilter = st;
    render();
  }

  function toggleKdsItemCheck(checkbox, elemId) {
    const el = document.getElementById(elemId);
    if (el) {
      el.style.opacity = checkbox.checked ? '0.4' : '1';
      el.style.textDecoration = checkbox.checked ? 'line-through' : 'none';
    }
  }

  function markOrderReady(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    Utils.showToast(isAR ? '✅ تم تجهيز الطلب وإشعار الويتر' : '✅ Order bumped as Ready! Waiter notified', 'success');
  }

  // Bill Splitting Modal
  async function openSplitBillModal(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const table = await DB.get('restaurant_tables', tableId);
    if (!table || !table.current_order || !(table.current_order.items || []).length) {
      Utils.showToast(isAR ? 'لا توجد أصناف في الطلب لتقسيمها' : 'No items in active order to split', 'warning');
      return;
    }

    const order = table.current_order;
    const total = order.total || 0;

    const modalHtml = `
    <div class="modal-overlay open" id="split-bill-modal">
      <div class="modal" style="max-width:620px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">✂️ ${isAR ? 'تقسيم الحساب' : 'Split Bill'} — Table ${table.table_number}</div>
          <button class="btn-icon" onclick="document.getElementById('split-bill-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px">
          
          <div style="display:flex;justify-content:space-between;align-items:center;background:rgba(239,68,68,0.1);padding:14px 18px;border-radius:12px;border:1px solid rgba(239,68,68,0.25);margin-bottom:16px">
            <span style="font-weight:700">${isAR ? 'إجمالي الحساب الإجمالي:' : 'Total Bill Amount:'}</span>
            <span style="font-size:1.4rem;font-weight:900;color:var(--primary)">$${total.toFixed(2)}</span>
          </div>

          <div style="display:flex;gap:8px;margin-bottom:16px;border-bottom:1px solid var(--border-color);padding-bottom:10px">
            <button class="btn btn-primary btn-sm" id="tab-equal-split" onclick="Restaurant.switchSplitTab('equal')">
              👥 ${isAR ? 'تقسيم متساوي (حسب عدد الأشخاص)' : 'Equal Shares'}
            </button>
            <button class="btn btn-secondary btn-sm" id="tab-item-split" onclick="Restaurant.switchSplitTab('item')">
              🧾 ${isAR ? 'تقسيم حسب الأصناف والضيوف' : 'Itemized Split by Guest'}
            </button>
          </div>

          <div id="equal-split-section">
            <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap">
              <button class="btn btn-secondary btn-sm" onclick="Restaurant.calcEqualSplit(${total}, 2)">2 ${isAR ? 'أشخاص' : 'Ways'}</button>
              <button class="btn btn-secondary btn-sm" onclick="Restaurant.calcEqualSplit(${total}, 3)">3 ${isAR ? 'أشخاص' : 'Ways'}</button>
              <button class="btn btn-secondary btn-sm" onclick="Restaurant.calcEqualSplit(${total}, 4)">4 ${isAR ? 'أشخاص' : 'Ways'}</button>
              <button class="btn btn-secondary btn-sm" onclick="Restaurant.calcEqualSplit(${total}, 5)">5 ${isAR ? 'أشخاص' : 'Ways'}</button>
            </div>
            <div id="split-calc-result" style="font-size:1.05rem;font-weight:800;color:var(--brand-cyan);padding:10px 14px;background:rgba(6,182,212,0.1);border-radius:10px;border:1px solid rgba(6,182,212,0.2)">
              👉 ${isAR ? `كل شخص يدفع:` : `Each Person Pays:`} <span style="font-size:1.25rem;color:var(--primary)">$${(total/2).toFixed(2)}</span> (2 ${isAR ? 'حصص' : 'Shares'})
            </div>
          </div>

          <div id="item-split-section" style="display:none">
            <div style="max-height:220px;overflow-y:auto;border:1px solid var(--border-color);border-radius:10px;padding:10px">
              ${(order.items || []).map((it, idx) => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05)">
                <div>
                  <div style="font-weight:700;font-size:0.9rem">${it.quantity || 1}x ${Utils.sanitize(it.name)}</div>
                  <div style="font-size:0.75rem;color:var(--text-muted)">$${((it.price || 0) * (it.quantity || 1)).toFixed(2)}</div>
                </div>
                <select class="form-control" style="width:130px;font-size:0.8rem;padding:4px 8px">
                  <option value="1">Guest 1</option>
                  <option value="2">Guest 2</option>
                  <option value="3">Guest 3</option>
                </select>
              </div>`).join('')}
            </div>
          </div>

        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('split-bill-modal').remove()">${isAR ? 'إلغاء' : 'Close'}</button>
          <button class="btn btn-primary" onclick="Restaurant.printSplitReceipts(${table.id})">🖨️ ${isAR ? 'طباعة وصولات التقسيم' : 'Print Split Checks'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  function switchSplitTab(mode) {
    const equalSec = document.getElementById('equal-split-section');
    const itemSec = document.getElementById('item-split-section');
    const tabEq = document.getElementById('tab-equal-split');
    const tabIt = document.getElementById('tab-item-split');

    if (mode === 'equal') {
      equalSec.style.display = 'block';
      itemSec.style.display = 'none';
      tabEq.className = 'btn btn-primary btn-sm';
      tabIt.className = 'btn btn-secondary btn-sm';
    } else {
      equalSec.style.display = 'none';
      itemSec.style.display = 'block';
      tabEq.className = 'btn btn-secondary btn-sm';
      tabIt.className = 'btn btn-primary btn-sm';
    }
  }

  function calcEqualSplit(total, parts) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const splitAmount = (total / parts).toFixed(2);
    document.getElementById('split-calc-result').innerHTML = `
      👉 ${isAR ? `كل شخص يدفع:` : `Each Person Pays:`} <span style="font-size:1.25rem;color:var(--primary)">$${splitAmount}</span> (${parts} ${isAR ? 'حصص متساوية' : 'Equal Shares'})
    `;
  }

  function printSplitReceipts(tableId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    Utils.showToast(isAR ? 'تم إرسال فواتير التقسيم للطباعة' : 'Split checks sent to printer', 'success');
    document.getElementById('split-bill-modal')?.remove();
  }

  // Modifiers & Recipe Management Modals
  async function openModifiersModal() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const modifiers = await DB.getAll('item_modifiers') || [];

    const modalHtml = `
    <div class="modal-overlay open" id="modifiers-modal">
      <div class="modal" style="max-width:580px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">🏷️ ${isAR ? 'خيارات ومعدلات الأطباق (Modifiers)' : 'Item Modifiers & Customizations'}</div>
          <button class="btn-icon" onclick="document.getElementById('modifiers-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px">
          <div style="display:flex;gap:8px;margin-bottom:14px">
            <input type="text" id="new-mod-name-en" class="form-control" placeholder="Modifier Name EN (e.g. Extra Cheese)">
            <input type="text" id="new-mod-name-ar" class="form-control" placeholder="الاسم بالعربي (مثال: جبنة زيادة)">
            <input type="number" id="new-mod-price" class="form-control" placeholder="+$ Price" style="width:100px" value="1.00">
            <button class="btn btn-primary" onclick="Restaurant.saveNewModifier()">➕</button>
          </div>
          <div style="max-height:240px;overflow-y:auto;border:1px solid var(--border-color);border-radius:12px;padding:8px">
            ${modifiers.map(m => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border-bottom:1px solid rgba(255,255,255,0.05)">
              <div>
                <span style="font-weight:700">${m.name_en}</span> / <span style="color:var(--text-muted)">${m.name_ar}</span>
              </div>
              <div style="display:flex;align-items:center;gap:10px">
                <span class="badge badge-primary">+$${(m.price || 0).toFixed(2)}</span>
                <button class="btn btn-ghost btn-sm" onclick="Restaurant.deleteModifier(${m.id})" style="color:var(--danger)">🗑️</button>
              </div>
            </div>`).join('')}
            ${!modifiers.length ? `<div style="text-align:center;padding:20px;color:var(--text-muted)">${isAR ? 'لا توجد خيارات مضافة' : 'No custom modifiers configured'}</div>` : ''}
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end">
          <button class="btn btn-secondary" onclick="document.getElementById('modifiers-modal').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function saveNewModifier() {
    const nameEn = document.getElementById('new-mod-name-en').value.trim();
    const nameAr = document.getElementById('new-mod-name-ar').value.trim();
    const price = parseFloat(document.getElementById('new-mod-price').value) || 0;

    if (!nameEn) return;

    await DB.add('item_modifiers', {
      name_en: nameEn,
      name_ar: nameAr || nameEn,
      price: price
    });

    openModifiersModal();
  }

  async function deleteModifier(id) {
    await DB.remove('item_modifiers', id);
    openModifiersModal();
  }

  // Recipe Manager
  async function openRecipeManager() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const items = await DB.getAll('items') || [];

    const modalHtml = `
    <div class="modal-overlay open" id="recipe-manager-modal">
      <div class="modal" style="max-width:760px;border-radius:18px;max-height:90vh;display:flex;flex-direction:column">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.2rem">🧪 ${isAR ? 'إدارة الوصفات وتكلفة الأطباق (Recipe BOM)' : 'Recipe & Food Costing BOM'}</div>
          <button class="btn-icon" onclick="document.getElementById('recipe-manager-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px;overflow-y:auto;flex:1">
          <p style="font-size:0.84rem;color:var(--text-muted);margin-bottom:16px">
            ${isAR ? 'ربط الأطباق بمكونات المخزون لخصم المواد الأولية تلقائياً وحساب نسبة تكلفة الطعام (Food Cost %):' : 'Link dishes to raw inventory ingredients for automatic deduction & food cost margin analysis:'}
          </p>

          <div style="border:1px solid var(--border-color);border-radius:12px;overflow:hidden">
            <table style="width:100%;border-collapse:collapse;font-size:0.86rem">
              <thead style="background:var(--surface);border-bottom:1px solid var(--border-color)">
                <tr>
                  <th style="padding:10px 12px;text-align:left">${isAR ? 'الطبق / الصنف' : 'Dish / Item'}</th>
                  <th style="padding:10px 12px;text-align:right">${isAR ? 'سعر البيع' : 'Selling Price'}</th>
                  <th style="padding:10px 12px;text-align:right">${isAR ? 'تكلفة المكونات' : 'Est. Food Cost'}</th>
                  <th style="padding:10px 12px;text-align:center">${isAR ? 'هامش الربح' : 'Margin %'}</th>
                  <th style="padding:10px 12px;text-align:right">${isAR ? 'الإجراء' : 'Action'}</th>
                </tr>
              </thead>
              <tbody>
                ${items.slice(0, 15).map(it => {
                  const sPrice = parseFloat(it.price || it.unit_price) || 0;
                  const cCost = parseFloat(it.cost_price) || (sPrice * 0.35);
                  const margin = sPrice > 0 ? (((sPrice - cCost) / sPrice) * 100).toFixed(1) : 0;

                  return `
                  <tr style="border-bottom:1px solid rgba(255,255,255,0.05)">
                    <td style="padding:10px 12px;font-weight:700">${Utils.sanitize(it.name_en || it.name)}</td>
                    <td style="padding:10px 12px;text-align:right">$${sPrice.toFixed(2)}</td>
                    <td style="padding:10px 12px;text-align:right;color:var(--brand-cyan)">$${cCost.toFixed(2)}</td>
                    <td style="padding:10px 12px;text-align:center">
                      <span class="badge ${margin > 50 ? 'badge-success' : 'badge-warning'}">${margin}%</span>
                    </td>
                    <td style="padding:10px 12px;text-align:right">
                      <button class="btn btn-secondary btn-sm" onclick="Utils.showToast('Recipe BOM linked', 'success')">
                        ✏️ ${isAR ? 'تعديل المكونات' : 'Edit BOM'}
                      </button>
                    </td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>

        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end">
          <button class="btn btn-secondary" onclick="document.getElementById('recipe-manager-modal').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  // Create / Edit Table Modal
  async function openTableForm(tableId = null) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const table = tableId ? await DB.get('restaurant_tables', tableId) : { table_number: '', name: '', capacity: 4, shape: 'square', zone_id: 1 };
    const zones = await DB.getAll('restaurant_zones') || [];

    const modalHtml = `
    <div class="modal-overlay open" id="table-form-modal">
      <div class="modal" style="max-width:480px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">
            ${tableId ? (isAR ? 'تعديل بيانات الطاولة' : 'Edit Table') : (isAR ? 'إضافة طاولة جديدة' : 'Add New Table')}
          </div>
          <button class="btn-icon" onclick="document.getElementById('table-form-modal').remove()">✕</button>
        </div>
        <form onsubmit="Restaurant.saveTableForm(event, ${tableId || 'null'})">
          <div class="modal-body" style="padding:18px 22px;display:flex;flex-direction:column;gap:12px">
            <div class="form-grid">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'رقم / كود الطاولة *' : 'Table Number/Code *'}</label>
                <input type="text" class="form-control" id="tf-number" value="${table.table_number || ''}" placeholder="e.g. T1, VIP-2" required>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'عدد الكراسي / السعة *' : 'Seat Capacity *'}</label>
                <input type="number" class="form-control" id="tf-capacity" value="${table.capacity || 4}" min="1" max="50" required>
              </div>
            </div>

            <div class="form-grid">
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'الصالـة / الزون' : 'Dining Zone'}</label>
                <select class="form-control" id="tf-zone">
                  ${zones.map(z => `<option value="${z.id}" ${String(z.id) === String(table.zone_id) ? 'selected' : ''}>${z.icon || ''} ${z.name}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label" style="font-weight:700">${isAR ? 'شكل الطاولة' : 'Table Shape'}</label>
                <select class="form-control" id="tf-shape">
                  <option value="square" ${table.shape === 'square' ? 'selected' : ''}>⬛ ${isAR ? 'مربعة' : 'Square'}</option>
                  <option value="round" ${table.shape === 'round' ? 'selected' : ''}>🟢 ${isAR ? 'دائرية' : 'Round'}</option>
                  <option value="rectangle" ${table.shape === 'rectangle' ? 'selected' : ''}>▭ ${isAR ? 'مستطيلة' : 'Rectangle'}</option>
                </select>
              </div>
            </div>
          </div>
          <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('table-form-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button type="submit" class="btn btn-primary">💾 ${isAR ? 'حفظ الطاولة' : 'Save Table'}</button>
          </div>
        </form>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function saveTableForm(e, tableId) {
    e.preventDefault();
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const tableNumber = document.getElementById('tf-number').value.trim();
    const capacity = parseInt(document.getElementById('tf-capacity').value, 10) || 4;
    const zoneId = parseInt(document.getElementById('tf-zone').value, 10) || 1;
    const shape = document.getElementById('tf-shape').value || 'square';

    if (tableId) {
      const existing = await DB.get('restaurant_tables', tableId);
      if (existing) {
        existing.table_number = tableNumber;
        existing.capacity = capacity;
        existing.zone_id = zoneId;
        existing.shape = shape;
        await DB.update('restaurant_tables', existing);
      }
    } else {
      await DB.add('restaurant_tables', {
        table_number: tableNumber,
        name: `Table ${tableNumber}`,
        capacity: capacity,
        zone_id: zoneId,
        shape: shape,
        status: 'free',
        current_order: null
      });
    }

    document.getElementById('table-form-modal')?.remove();
    Utils.showToast(isAR ? 'تم حفظ الطاولة بنجاح' : 'Table saved successfully', 'success');
    render();
  }

  // Zone Management Modal
  async function openZoneForm() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const zones = await DB.getAll('restaurant_zones') || [];

    const modalHtml = `
    <div class="modal-overlay open" id="zone-manage-modal">
      <div class="modal" style="max-width:540px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.15rem">🌿 ${isAR ? 'إدارة الصالات والزونات' : 'Dining Zones & Sections'}</div>
          <button class="btn-icon" onclick="document.getElementById('zone-manage-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px 22px">
          <div style="display:flex;gap:8px;margin-bottom:14px">
            <input type="text" id="new-zone-name" class="form-control" placeholder="${isAR ? 'اسم الصالة الجديدة' : 'New Zone Name'}" style="flex:1">
            <button class="btn btn-primary" onclick="Restaurant.addNewZone()">➕ ${isAR ? 'إضافة' : 'Add'}</button>
          </div>

          <div style="max-height:220px;overflow-y:auto;border:1px solid var(--border-color);border-radius:12px;padding:8px">
            ${zones.map(z => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border-bottom:1px solid rgba(255,255,255,0.05)">
              <span style="font-weight:700">${z.icon || '🛋️'} ${Utils.sanitize(z.name)}</span>
              <button class="btn btn-ghost btn-sm" onclick="Restaurant.deleteZone(${z.id})" style="color:var(--danger)">🗑️</button>
            </div>`).join('')}
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end">
          <button class="btn btn-secondary" onclick="document.getElementById('zone-manage-modal').remove()">${isAR ? 'إغلاق' : 'Close'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('restaurant-modals-container').innerHTML = modalHtml;
  }

  async function addNewZone() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    const name = document.getElementById('new-zone-name').value.trim();
    if (!name) return;

    await DB.add('restaurant_zones', {
      name: name,
      name_ar: name,
      icon: '🛋️',
      active: true,
      sort_order: 99
    });

    document.getElementById('new-zone-name').value = '';
    Utils.showToast(isAR ? 'تمت إضافة الصالة بنجاح' : 'Zone added successfully', 'success');
    openZoneForm();
    render();
  }

  async function deleteZone(zoneId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar') || localStorage.getItem('nexpos_lang') === 'ar';
    if (!confirm(isAR ? 'هل تريد حذف هذه الصالة؟' : 'Delete this zone?')) return;
    await DB.remove('restaurant_zones', zoneId);
    openZoneForm();
    render();
  }

  return {
    render,
    broadcastLiveSync,
    switchTab,
    switchZone,
    setDeliveryFilter,
    setDeliverySearch,
    openTableOrder,
    openQuickTakeawayPOS,
    openNewDeliveryModal,
    saveNewDeliveryOrder,
    openDeliveryInPOS,
    onDeliveryCustomerSearch,
    selectDeliveryCustomer,
    onDeliveryPhoneInput,
    renderDeliveryItemPicker,
    addDeliveryItem,
    updateDeliveryItemQty,
    updateDeliveryItemNote,
    removeDeliveryItem,
    updateDeliveryTotals,
    updateDeliveryStatus,
    openDeliveryDetailsModal,
    openSettlePaymentModal,
    executeSettlePayment,
    reassignDriverPrompt,
    cancelDeliveryOrder,
    printDeliveryDispatchTicket,
    printGuestCheck,
    openTransferModal,
    executeTransfer,
    freeTablePrompt,
    openMergeTablesModal,
    executeMergeTables,
    unmergeTable,
    openReservationsModal,
    openNewReservationForm,
    saveNewReservation,
    quickReserveTable,
    seatReservedGuest,
    seatReservationFromDiary,
    cancelTableReservation,
    cancelReservation,
    deleteReservation,
    openKitchenDisplay,
    setKdsStation,
    toggleKdsItemCheck,
    markOrderReady,
    openSplitBillModal,
    switchSplitTab,
    calcEqualSplit,
    printSplitReceipts,
    openModifiersModal,
    saveNewModifier,
    deleteModifier,
    openRecipeManager,
    openTableForm,
    saveTableForm,
    openZoneForm,
    addNewZone,
    deleteZone
  };
})();

window.Restaurant = Restaurant;
