/* ================================================================
   NexPOS — Dashboard Module
   ================================================================ */

const Dashboard = (() => {

  async function render(container) {
    const lang = i18n.getLang();
    const isAR = lang === 'ar';

    // Load data
    const [sales, items, customers, employees] = await Promise.all([
      DB.getAll('sales'),
      DB.getAll('items'),
      DB.getAll('customers'),
      DB.getAll('employees')
    ]);

    const todaySales = sales.filter(s => s.created_at && s.created_at.startsWith(Utils.today()));
    const todayRevenue = todaySales.reduce((sum, s) => sum + (s.grand_total || 0), 0);
    const totalItems = items.length;
    const lowStockItems = items.filter(i => i.stock_qty !== undefined && i.min_qty !== undefined && i.stock_qty <= i.min_qty);

    // Build 7-day chart data
    const chartData = buildChartData(sales);

    container.innerHTML = `
    <div class="animate-slide">
      <!-- ── DAILY QUICK ACTION HUB (Elderly & Touch Friendly Direct Access) ── -->
      <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:16px;padding:20px;margin-bottom:24px;box-shadow:0 4px 20px rgba(0,0,0,0.06)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:8px">
          <div>
            <h2 style="font-size:1.15rem;font-weight:900;color:var(--text-primary);display:flex;align-items:center;gap:8px;margin:0 0 4px">
              <span style="font-size:1.35rem">🚀</span>
              <span>${isAR ? 'الوصول السريع للعمليات اليومية' : 'Daily Operations Quick Hub'}</span>
            </h2>
            <p style="margin:0;font-size:0.83rem;color:var(--text-muted)">
              ${isAR ? 'روابط مباشرة وسهلة للعمليات الأساسية بدون الحاجة للبحث في القوائم الجانبية' : 'Direct 1-click shortcuts to everyday tasks — simple, large & easy for all users'}
            </p>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:0.75rem;font-weight:800;background:rgba(239,68,68,0.12);color:#ef4444;border:1px solid rgba(239,68,68,0.25);padding:4px 10px;border-radius:20px">
              ⚡ ${isAR ? 'الوصول بنقرة واحدة' : '1-Click Access'}
            </span>
          </div>
        </div>

        <div class="quick-hub-grid">
          <!-- 1. POS Cockpit -->
          <div class="quick-hub-card" onclick="App.navigate('pos')" style="--card-accent:#ef4444;--card-bg:rgba(239,68,68,0.12);--card-border:rgba(239,68,68,0.3)">
            <div class="quick-hub-icon">🛒</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'نقطة البيع (الكاشير)' : 'POS Cockpit'}</div>
              <div class="quick-hub-desc">${isAR ? 'بدء فاتورة بيع جديدة ومسح الباركود' : 'Start sale ticket & barcode checkout'}</div>
            </div>
          </div>

          <!-- 2. Customer Statement of Account -->
          <div class="quick-hub-card" onclick="App.navigate('customer-statement')" style="--card-accent:#3b82f6;--card-bg:rgba(59,130,246,0.12);--card-border:rgba(59,130,246,0.3)">
            <div class="quick-hub-icon">👤</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'كشف حساب الزبائن' : 'Customer Statement'}</div>
              <div class="quick-hub-desc">${isAR ? 'أرصدة الديون، الفواتير، وطباعة الكشف' : 'Customer balances, ledger & print statement'}</div>
            </div>
          </div>

          <!-- 3. Supplier Statement of Account -->
          <div class="quick-hub-card" onclick="App.navigate('supplier-statement')" style="--card-accent:#10b981;--card-bg:rgba(16,185,129,0.12);--card-border:rgba(16,185,129,0.3)">
            <div class="quick-hub-icon">🏢</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'كشف حساب الموردين' : 'Supplier Statement'}</div>
              <div class="quick-hub-desc">${isAR ? 'مطابقة فواتير الشراء والدفعات والذمم' : 'Vendor ledger, purchase bills & payments'}</div>
            </div>
          </div>

          <!-- 4. Products & Stock -->
          <div class="quick-hub-card" onclick="App.navigate('items')" style="--card-accent:#f59e0b;--card-bg:rgba(245,158,11,0.12);--card-border:rgba(245,158,11,0.3)">
            <div class="quick-hub-icon">📦</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'الأصناف والأسعار' : 'Products & Catalog'}</div>
              <div class="quick-hub-desc">${isAR ? 'إضافة أصناف وتعديل الأسعار والمخزون' : 'Add products, update prices & stock limits'}</div>
            </div>
          </div>

          <!-- 5. Purchase Invoices -->
          <div class="quick-hub-card" onclick="App.navigate('purchase-invoice')" style="--card-accent:#8b5cf6;--card-bg:rgba(139,92,246,0.12);--card-border:rgba(139,92,246,0.3)">
            <div class="quick-hub-icon">📥</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'فواتير الشراء والإدخال' : 'Purchases & Bills'}</div>
              <div class="quick-hub-desc">${isAR ? 'تسجيل فواتير الشراء واستلام البضاعة' : 'Record purchase bills & vendor deliveries'}</div>
            </div>
          </div>

          <!-- 6. Cashbox & Movements -->
          <div class="quick-hub-card" onclick="App.navigate('cashbox')" style="--card-accent:#06b6d4;--card-bg:rgba(6,182,212,0.12);--card-border:rgba(6,182,212,0.3)">
            <div class="quick-hub-icon">💵</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'الصندوق واليومية' : 'Cashbox & Shifts'}</div>
              <div class="quick-hub-desc">${isAR ? 'تسليم الوردية، قبض، وسحب مصاريف' : 'Shift handover, cash in/out & petty cash'}</div>
            </div>
          </div>

          <!-- 7. Daily Sales & Profit -->
          <div class="quick-hub-card" onclick="App.navigate('reports')" style="--card-accent:#f43f5e;--card-bg:rgba(244,63,94,0.12);--card-border:rgba(244,63,94,0.3)">
            <div class="quick-hub-icon">📊</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'تقارير المبيعات والأرباح' : 'Daily Sales & Profit'}</div>
              <div class="quick-hub-desc">${isAR ? 'ملخص الأرباح، المبيعات، والإقرارات' : 'Daily revenue, profit margins & summaries'}</div>
            </div>
          </div>

          <!-- 8. System Settings & Backup -->
          <div class="quick-hub-card" onclick="App.navigate('settings')" style="--card-accent:#64748b;--card-bg:rgba(100,116,139,0.12);--card-border:rgba(100,116,139,0.3)">
            <div class="quick-hub-icon">⚙️</div>
            <div class="quick-hub-info">
              <div class="quick-hub-title">${isAR ? 'إعدادات النظام والنسخ' : 'Settings & Backup'}</div>
              <div class="quick-hub-desc">${isAR ? 'سعر الصرف، الطابعات، والنسخ الاحتياطي' : 'Exchange rates, printers & system backup'}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- KPI Cards -->
      <div class="grid grid-4 mb-4">
        <div class="stat-card primary">
          <div class="stat-icon primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/>
            </svg>
          </div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'مبيعات اليوم' : "Today's Sales"}</div>
            <div class="stat-value">${Utils.formatMoney(todayRevenue)}</div>
            <div class="stat-change up">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="18 15 12 9 6 15"/></svg>
              ${todaySales.length} ${isAR ? 'معاملة' : 'transactions'}
            </div>
          </div>
        </div>

        <div class="stat-card success">
          <div class="stat-icon success">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
            </svg>
          </div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'إجمالي الإيرادات' : 'Total Revenue'}</div>
            <div class="stat-value">${Utils.formatMoney(sales.reduce((s,t)=>s+(t.grand_total||0),0))}</div>
            <div class="stat-change up">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="18 15 12 9 6 15"/></svg>
              ${isAR ? 'كل الوقت' : 'All time'}
            </div>
          </div>
        </div>

        <div class="stat-card warning">
          <div class="stat-icon warning">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
            </svg>
          </div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'إجمالي الأصناف' : 'Total Items'}</div>
            <div class="stat-value">${totalItems.toLocaleString()}</div>
            <div class="stat-change ${lowStockItems.length > 0 ? 'down' : 'up'}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="${lowStockItems.length > 0 ? '18 9 12 15 6 9' : '18 15 12 9 6 15'}"/></svg>
              ${lowStockItems.length} ${isAR ? 'نقص في المخزون' : 'low stock'}
            </div>
          </div>
        </div>

        <div class="stat-card purple">
          <div class="stat-icon purple">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>
              <path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>
            </svg>
          </div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'العملاء' : 'Customers'}</div>
            <div class="stat-value">${customers.length.toLocaleString()}</div>
            <div class="stat-change up">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="18 15 12 9 6 15"/></svg>
              ${employees.length} ${isAR ? 'موظف' : 'employees'}
            </div>
          </div>
        </div>
      </div>

      <!-- Charts + Quick Actions Row -->
      <div class="grid grid-3 mb-4" style="grid-template-columns:2fr 1fr">

        <!-- Sales Chart -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
              ${isAR ? 'نظرة عامة على المبيعات' : 'Sales Overview'}
            </div>
            <select class="form-control" style="width:auto;font-size:0.75rem" id="chart-period">
              <option value="7">${isAR ? 'آخر 7 أيام' : 'Last 7 Days'}</option>
              <option value="30">${isAR ? 'آخر 30 يوم' : 'Last 30 Days'}</option>
            </select>
          </div>
          <canvas id="sales-chart" height="200"></canvas>
        </div>

        <!-- Quick Actions -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
              ${isAR ? 'إجراءات سريعة' : 'Quick Actions'}
            </div>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px">
            <button class="btn btn-primary btn-block" onclick="App.navigate('pos')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/></svg>
              ${isAR ? 'بيع جديد' : 'New Sale'}
            </button>
            <button class="btn btn-secondary btn-block" onclick="App.navigate('purchase-order')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
              ${isAR ? 'أمر شراء جديد' : 'New Purchase Order'}
            </button>
            <button class="btn btn-secondary btn-block" onclick="App.navigate('items')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              ${isAR ? 'إضافة صنف' : 'Add New Item'}
            </button>
            <button class="btn btn-secondary btn-block" onclick="App.navigate('customers')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              ${isAR ? 'إضافة عميل' : 'Add Customer'}
            </button>
            <button class="btn btn-secondary btn-block" onclick="App.navigate('reports')">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
              ${isAR ? 'عرض التقارير' : 'View Reports'}
            </button>
          </div>
        </div>
      </div>

      <!-- Bottom Row -->
      <div class="grid grid-2">

        <!-- Recent Transactions -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              ${isAR ? 'آخر المعاملات' : 'Recent Transactions'}
            </div>
            <button class="btn btn-ghost btn-sm" onclick="App.navigate('sales-invoice')">
              ${isAR ? 'عرض الكل' : 'View All'}
            </button>
          </div>
          ${sales.length === 0 ? `
            <div class="empty-state">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/></svg>
              <h3>${isAR ? 'لا توجد معاملات' : 'No transactions yet'}</h3>
              <p>${isAR ? 'ابدأ ببيعتك الأولى' : 'Start your first sale'}</p>
            </div>` : `
          <div class="table-wrapper">
            <table>
              <thead><tr>
                <th>${isAR ? 'الرقم' : 'Ref'}</th>
                <th>${isAR ? 'العميل' : 'Customer'}</th>
                <th>${isAR ? 'المبلغ' : 'Amount'}</th>
                <th>${isAR ? 'الحالة' : 'Status'}</th>
                <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
              </tr></thead>
              <tbody>
                ${sales.slice(-10).reverse().map(s => `
                  <tr>
                    <td><span style="font-weight:600;color:var(--primary)">${s.ref || '#'}</span></td>
                    <td>${Utils.truncate(s.customer_name || (isAR ? 'عميل عابر' : 'Walk-in'), 20)}</td>
                    <td style="font-weight:700">${Utils.formatMoney(s.grand_total)}</td>
                    <td><span class="badge badge-success">Paid</span></td>
                    <td style="font-size:0.75rem;color:var(--text-muted);white-space:nowrap">${Utils.formatDateTime(s.created_at)}</td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>`}
        </div>

        <!-- Low Stock Alerts -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              ${isAR ? 'تنبيهات المخزون' : 'Stock Alerts'}
              ${lowStockItems.length > 0 ? `<span class="badge badge-warning">${lowStockItems.length}</span>` : ''}
            </div>
            <button class="btn btn-ghost btn-sm" onclick="App.navigate('items')">
              ${isAR ? 'عرض الكل' : 'View All'}
            </button>
          </div>
          ${lowStockItems.length === 0 ? `
            <div class="empty-state">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
              <h3 style="color:var(--success)">${isAR ? 'المخزون جيد!' : 'Stock levels OK!'}</h3>
              <p>${isAR ? 'لا توجد أصناف بمخزون منخفض' : 'No low stock items'}</p>
            </div>` : `
          <div class="table-wrapper">
            <table>
              <thead><tr>
                <th>${isAR ? 'الصنف' : 'Item'}</th>
                <th>${isAR ? 'المتوفر' : 'In Stock'}</th>
                <th>${isAR ? 'الحد الأدنى' : 'Min'}</th>
                <th>${isAR ? 'الإجراء' : 'Action'}</th>
              </tr></thead>
              <tbody>
                ${lowStockItems.slice(0,8).map(i => `
                  <tr>
                    <td>
                      <div style="font-weight:600;font-size:0.82rem">${Utils.truncate(lang === 'ar' ? (i.name_ar||i.name_en) : (i.name_en||i.name_ar), 22)}</div>
                      <div style="font-size:0.72rem;color:var(--text-muted)">${i.item_code||''}</div>
                    </td>
                    <td><span style="font-weight:700;color:${i.stock_qty <= 0 ? 'var(--danger)' : 'var(--warning)'}">${i.stock_qty || 0}</span></td>
                    <td style="color:var(--text-muted)">${i.min_qty || 0}</td>
                    <td>
                      <button class="btn btn-warning btn-sm" onclick="App.navigate('purchase-order')">
                        ${isAR ? 'طلب' : 'Reorder'}
                      </button>
                    </td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>`}
        </div>
      </div>
    </div>`;

    // Render chart
    renderChart(chartData);
  }

  function buildChartData(sales) {
    const days = 7;
    const labels = [];
    const data   = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      labels.push(d.toLocaleDateString('en-GB', { month: 'short', day: 'numeric' }));
      const dayTotal = sales
        .filter(s => s.created_at && s.created_at.startsWith(dateStr))
        .reduce((sum, s) => sum + (s.grand_total || 0), 0);
      data.push(dayTotal);
    }
    return { labels, data };
  }

  function renderChart({ labels, data }) {
    const canvas = document.getElementById('sales-chart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // Simple canvas chart
    const w = canvas.offsetWidth || 400;
    const h = 200;
    canvas.width  = w;
    canvas.height = h;

    const pad     = { top: 20, right: 20, bottom: 40, left: 60 };
    const plotW   = w - pad.left - pad.right;
    const plotH   = h - pad.top  - pad.bottom;
    const maxVal  = Math.max(...data, 1);
    const isDark  = document.documentElement.getAttribute('data-theme') !== 'light';

    const primaryColor  = isDark ? '#00B4D8' : '#0055CC';
    const gridColor     = isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.06)';
    const textColor     = isDark ? '#9CA3AF' : '#6B7280';
    const areaColor1    = primaryColor;

    ctx.clearRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = gridColor;
    ctx.lineWidth   = 1;
    for (let i = 0; i <= 4; i++) {
      const y = pad.top + plotH * (1 - i / 4);
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(pad.left + plotW, y);
      ctx.stroke();
      // Label
      ctx.fillStyle   = textColor;
      ctx.font        = '10px Inter, sans-serif';
      ctx.textAlign   = 'right';
      ctx.fillText(Utils.formatMoney(maxVal * i / 4, null, 0), pad.left - 6, y + 3);
    }

    // Points
    const pts = data.map((v, idx) => ({
      x: pad.left + (idx / (data.length - 1)) * plotW,
      y: pad.top  + plotH * (1 - v / maxVal)
    }));

    // Area fill
    const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + plotH);
    grad.addColorStop(0, isDark ? 'rgba(0,180,216,0.3)' : 'rgba(0,85,204,0.2)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pad.top + plotH);
    pts.forEach(p => ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length - 1].x, pad.top + plotH);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.strokeStyle = primaryColor;
    ctx.lineWidth   = 2.5;
    ctx.lineJoin    = 'round';
    ctx.lineCap     = 'round';
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.stroke();

    // Dots
    pts.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
      ctx.fillStyle   = primaryColor;
      ctx.fill();
      ctx.strokeStyle = isDark ? '#111827' : '#fff';
      ctx.lineWidth   = 2;
      ctx.stroke();
    });

    // X Labels
    labels.forEach((lbl, idx) => {
      ctx.fillStyle  = textColor;
      ctx.font       = '10px Inter, sans-serif';
      ctx.textAlign  = 'center';
      ctx.fillText(lbl, pts[idx].x, h - pad.bottom + 18);
    });
  }

  return { render };
})();

window.Dashboard = Dashboard;
