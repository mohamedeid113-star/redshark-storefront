/* ================================================================
   NexPOS — Cash Box / Shift Management Module
   ================================================================ */

const CashBox = (() => {

  // ── i18n helpers ─────────────────────────────────────────────
  const isAR  = () => i18n.getLang() === 'ar';
  const t     = (en, ar) => isAR() ? ar : en;
  const fmt   = (n)  => Utils.formatCurrency(n);
  const nowTS = ()   => new Date().toISOString();
  const stamp = ()   => new Date().toLocaleString('en-US');
  const todayStr = () => new Date().toLocaleDateString('en-GB');

  // ── Modal helpers (inject HTML into body, bypass Utils.openModal) ─
  function _showModal(html, maxWidth = '480px') {
    let overlay = document.getElementById('cb-modal-overlay');
    if (overlay) overlay.remove();
    overlay = document.createElement('div');
    overlay.className = 'modal-overlay open';
    overlay.id = 'cb-modal-overlay';
    overlay.innerHTML = `<div class="modal" style="max-width:${maxWidth}">${html}</div>`;
    // Close on backdrop click
    overlay.addEventListener('click', e => { if (e.target === overlay) _closeModal(); });
    document.body.appendChild(overlay);
  }

  function _closeModal() {
    const m = document.getElementById('cb-modal-overlay');
    if (m) m.remove();
  }

  // ── DB helpers ───────────────────────────────────────────────
  const getTerminalId = () => localStorage.getItem('redshark_pos_terminal') || 'POS-1';

  async function getSessions() {
    let local = (await DB.getAll('cashbox_sessions')) || [];
    try {
      if (window.BranchSync && typeof BranchSync.isServer === 'function' && await BranchSync.isServer()) {
        const res = await fetch('/api/sync/transactions');
        if (res.ok) {
          const j = await res.json();
          if (Array.isArray(j.cashboxSessions) && j.cashboxSessions.length > 0) {
            const map = new Map();
            local.forEach(s => map.set(String(s.id || s.session_id), s));
            for (const cs of j.cashboxSessions) {
              const k = String(cs.id || cs.session_id);
              if (!map.has(k)) {
                local.push(cs);
                map.set(k, cs);
              }
            }
          }
        }
      }
    } catch(e) {}
    return local;
  }
  async function getMovements() { return DB.getAll('cashbox_movements'); }

  async function getActiveSession(terminalId = null) {
    const term = terminalId || getTerminalId();
    const sessions = await getSessions();
    const openSessions = sessions.filter(s => s.status === 'open');
    if (!openSessions.length) return null;
    return openSessions.find(s => (s.terminal_id || 'POS-1') === term) || openSessions[0];
  }

  async function getSessionMovements(sessionId) {
    const all = await getMovements();
    return all.filter(m => m.session_id === sessionId);
  }

  // ─────────────────────────────────────────────────────────────
  //  MAIN render
  // ─────────────────────────────────────────────────────────────
  async function render(container) {
    const session = await getActiveSession();
    container.innerHTML = `<div class="animate-slide" id="cashbox-root">${await _buildHub(session)}</div>`;
    _bindHubEvents();
  }

  async function _buildHub(session) {
    const currentTerm = session?.terminal_id || getTerminalId();
    const isOpen = !!session;
    let movements = isOpen ? await getSessionMovements(session.id) : [];
    const cashIn    = movements.filter(m => m.type === 'in').reduce((s,m)=>s+m.amount,0);
    const cashOut   = movements.filter(m => m.type === 'out').reduce((s,m)=>s+m.amount,0);
    const salesCash = movements.filter(m => m.type === 'sale').reduce((s,m)=>s+m.amount,0);
    const balance   = isOpen ? (session.opening_amount + salesCash + cashIn - cashOut) : 0;

    return `
    <div class="page-header">
      <div class="page-header-left">
        <h1>${t('Cash Box','إدارة الصندوق النقدي')}</h1>
        <div class="breadcrumb">${t('POS','نقطة البيع')} › ${t('Cash Box','الصندوق')}</div>
        <div style="display:flex;align-items:center;gap:8px;margin-top:8px;background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.25);border-radius:8px;padding:5px 12px;width:fit-content">
          <span style="font-size:1.05rem">🖥️</span>
          <span style="font-size:0.8rem;font-weight:700;color:var(--text-primary)">${t('Terminal:','جهاز البيع:')}</span>
          <span class="badge badge-primary" style="font-size:0.8rem;font-weight:800">${Utils.sanitize(currentTerm)}</span>
          <button class="btn btn-ghost btn-sm" onclick="CashBox.showTerminalSwitchModal()" style="font-size:0.7rem;padding:1px 6px">${t('Switch','تبديل')}</button>
        </div>
      </div>
      <div class="page-actions">
        ${isOpen ? `
          <button class="btn btn-warning" id="cb-handover-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 014-4h14M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>
            ${t('Shift Handover','تسليم الوردية')}
          </button>
          <button class="btn btn-danger" id="cb-close-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9l6 6M15 9l-6 6"/></svg>
            ${t('Close Box','إغلاق الصندوق')}
          </button>` : `
          <button class="btn btn-success" id="cb-open-btn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
            ${t('Open Box / Start Shift','فتح الصندوق / بدء الوردية')}
          </button>`}
      </div>
    </div>

    ${!isOpen ? `
    <div style="text-align:center;padding:60px 20px">
      <div style="font-size:5rem;margin-bottom:16px">🔒</div>
      <h2 style="color:var(--text-muted);margin-bottom:8px">${t('Box is Closed','الصندوق مغلق')}</h2>
      <p style="color:var(--text-muted);margin-bottom:28px">${t('Start a shift to accept payments and track cash.','ابدأ وردية لقبول المدفوعات وتتبع النقد.')}</p>
      <button class="btn btn-success btn-lg" id="cb-open-btn2">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
        ${t('Open Cash Box','فتح الصندوق')}
      </button>
    </div>` : `
    <div class="stats-grid grid-6" style="margin-bottom:12px">
      <div class="stat-card" style="border-top:3px solid var(--success)">
        <div class="stat-label">${t('Current Balance','الرصيد الحالي')}</div>
        <div class="stat-value" style="color:var(--success)">${fmt(balance)}</div>
        <div class="stat-sub">${t('Live cash in drawer','النقد الحالي في الصندوق')}</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--primary)">
        <div class="stat-label">${t('Opening Amount','مبلغ الفتح')}</div>
        <div class="stat-value">${fmt(session.opening_amount)}</div>
        <div class="stat-sub">${t('Shift started','بدأت الوردية')} ${new Date(session.opened_at).toLocaleTimeString()}</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--accent)">
        <div class="stat-label">${t('Cash Sales','مبيعات نقدية')}</div>
        <div class="stat-value" style="color:var(--accent)">${fmt(salesCash)}</div>
        <div class="stat-sub">${movements.filter(m=>m.type==='sale').length} ${t('transactions','معاملة')}</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--success)">
        <div class="stat-label">${t('Cash In','إدخال نقد')}</div>
        <div class="stat-value" style="color:var(--success)">+${fmt(cashIn)}</div>
        <div class="stat-sub">${movements.filter(m=>m.type==='in').length} ${t('entries','قيود')}</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--danger)">
        <div class="stat-label">${t('Cash Out','سحب نقد')}</div>
        <div class="stat-value" style="color:var(--danger)">-${fmt(cashOut)}</div>
        <div class="stat-sub">${movements.filter(m=>m.type==='out').length} ${t('entries','قيود')}</div>
      </div>
      <div class="stat-card" style="border-top:3px solid var(--warning)">
        <div class="stat-label">${t('Cashier','أمين الصندوق')}</div>
        <div class="stat-value" style="font-size:0.95rem;font-weight:700">${Utils.sanitize(session.cashier_name||'—')}</div>
        <div class="stat-sub">${t('Active shift','وردية نشطة')}</div>
      </div>
    </div>

    <div class="grid grid-2" style="margin-bottom:12px;gap:10px">
      <button class="btn btn-primary" style="padding:10px 16px;font-size:0.9rem;gap:8px" id="cb-cashin-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        ${t('Cash In — Add Money','إدخال نقد للصندوق')}
      </button>
      <button class="btn btn-secondary" style="padding:10px 16px;font-size:0.9rem;gap:8px" id="cb-cashout-btn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><line x1="5" y1="12" x2="19" y2="12"/></svg>
        ${t('Cash Out — Withdraw','سحب نقد من الصندوق')}
      </button>
    </div>

    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="16" height="16"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          ${t('Shift Movements','حركات الوردية')}
        </div>
        <button class="btn btn-secondary btn-sm" onclick="CashBox.printShiftReport()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          ${t('Print Report','طباعة تقرير')}
        </button>
      </div>
      <div class="table-wrapper">
        <table class="data-table">
          <thead><tr>
            <th>${t('Time','الوقت')}</th>
            <th>${t('Type','النوع')}</th>
            <th>${t('Description','الوصف')}</th>
            <th>${t('Amount','المبلغ')}</th>
            <th>${t('Cashier','الكاشير')}</th>
          </tr></thead>
          <tbody>
            ${movements.length === 0
              ? `<tr><td colspan="5" class="empty-state">${t('No movements yet','لا توجد حركات بعد')}</td></tr>`
              : movements.slice().reverse().map(m => `<tr>
                <td style="font-size:0.8rem">${new Date(m.created_at).toLocaleTimeString()}</td>
                <td><span class="badge badge-${m.type==='sale'?'info':m.type==='in'?'success':'danger'}">${
                  m.type==='sale'?t('Sale','بيع'):m.type==='in'?t('Cash In','إدخال'):t('Cash Out','سحب')
                }</span></td>
                <td>${Utils.sanitize(m.description||'—')}</td>
                <td style="font-weight:700;color:${m.type==='out'?'var(--danger)':'var(--success)'}">
                  ${m.type==='out'?'-':'+'} ${fmt(m.amount)}
                </td>
                <td>${Utils.sanitize(m.cashier||'—')}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`}`;
  }

  function _bindHubEvents() {
    document.getElementById('cb-open-btn')?.addEventListener('click', showOpenModal);
    document.getElementById('cb-open-btn2')?.addEventListener('click', showOpenModal);
    document.getElementById('cb-close-btn')?.addEventListener('click', showCloseModal);
    document.getElementById('cb-handover-btn')?.addEventListener('click', showHandoverModal);
    document.getElementById('cb-cashin-btn')?.addEventListener('click', () => showMovementModal('in'));
    document.getElementById('cb-cashout-btn')?.addEventListener('click', () => showMovementModal('out'));
  }

  // ── OPEN SHIFT ───────────────────────────────────────────────
  function showOpenModal() {
    const user = Auth.getUser();
    const currentTerm = getTerminalId();
    _showModal(`
      <div class="modal-header">
        <h3>${t('Open Cash Box','فتح الصندوق النقدي')}</h3>
        <button class="modal-close" onclick="CashBox._close()">✕</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">${t('POS Terminal / Workstation','نقطة / جهاز البيع')}</label>
          <input type="text" class="form-control" id="cb-terminal"
            value="${Utils.sanitize(currentTerm)}"
            placeholder="e.g. POS-1, POS-2"
            style="font-size:1.05rem;font-weight:700">
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:3px">
            ${t('Each POS machine in the shop has its own independent drawer and shift.','لكل جهاز كاشير في المحل صندوق ووردية مستقلة.')}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${t('Cashier Name','اسم الكاشير')}</label>
          <input type="text" class="form-control" id="cb-cashier"
            value="${Utils.sanitize(user?.full_name || user?.username || '')}"
            style="font-size:1rem">
        </div>
        <div class="form-group">
          <label class="form-label">${t('Opening Cash Amount','مبلغ الفتح النقدي')}</label>
          <input type="number" class="form-control" id="cb-opening" value="0" min="0" step="0.01"
            style="font-size:1.4rem;font-weight:700;text-align:center">
          <div style="font-size:0.75rem;color:var(--text-muted);margin-top:6px">
            ${t('Count the physical cash in the drawer and enter the total.','عد النقد الموجود في الصندوق وأدخل المجموع.')}
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${t('Notes','ملاحظات')}</label>
          <input type="text" class="form-control" id="cb-open-notes"
            placeholder="${t('Optional...','اختياري...')}">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="CashBox._close()">${t('Cancel','إلغاء')}</button>
        <button class="btn btn-success" onclick="CashBox._confirmOpen()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
          ${t('Open Box','فتح الصندوق')}
        </button>
      </div>`);
    setTimeout(() => document.getElementById('cb-opening')?.focus(), 100);
  }

  async function _confirmOpen() {
    const terminal = document.getElementById('cb-terminal')?.value.trim() || getTerminalId();
    const cashier = document.getElementById('cb-cashier')?.value.trim();
    const opening = parseFloat(document.getElementById('cb-opening')?.value) || 0;
    const notes   = document.getElementById('cb-open-notes')?.value.trim();
    if (!cashier) { Utils.toast(t('Enter cashier name','أدخل اسم الكاشير'), 'error'); return; }

    localStorage.setItem('redshark_pos_terminal', terminal);

    await DB.add('cashbox_sessions', {
      terminal_id:    terminal,
      cashier_name:   cashier,
      opening_amount: opening,
      status:         'open',
      opened_at:      nowTS(),
      closed_at:      null,
      closing_amount: null,
      difference:     null,
      notes,
    });
    _closeModal();
    Utils.toast(t('Cash box opened!','تم فتح الصندوق!'), 'success');
    await _refresh();
  }

  // ── CASH IN / OUT ────────────────────────────────────────────
  function showMovementModal(type) {
    const isIn = type === 'in';
    _showModal(`
      <div class="modal-header" style="border-bottom:3px solid ${isIn?'var(--success)':'var(--danger)'}">
        <h3 style="color:${isIn?'var(--success)':'var(--danger)'}">${isIn?t('Cash In — Add Money','إدخال نقد للصندوق'):t('Cash Out — Withdraw','سحب نقد من الصندوق')}</h3>
        <button class="modal-close" onclick="CashBox._close()">✕</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">${t('Amount','المبلغ')}</label>
          <input type="number" class="form-control" id="cb-move-amount" min="0.01" step="0.01"
            style="font-size:1.5rem;font-weight:700;text-align:center;color:${isIn?'var(--success)':'var(--danger)'}"
            placeholder="0.00">
        </div>
        <div class="form-group">
          <label class="form-label">${t('Reason / Description','السبب / الوصف')}</label>
          <input type="text" class="form-control" id="cb-move-desc"
            placeholder="${isIn?t('e.g. Bank withdrawal, petty cash top-up','مثال: سحب بنكي، تعبئة صندوق'):t('e.g. Petty cash expense, supplier payment','مثال: مصاريف نثرية، دفعة للمورد')}">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="CashBox._close()">${t('Cancel','إلغاء')}</button>
        <button class="btn btn-${isIn?'success':'danger'}" onclick="CashBox._confirmMovement('${type}')">
          ${isIn?t('Add Cash','إضافة نقد'):t('Withdraw','سحب')}
        </button>
      </div>`);
    setTimeout(() => document.getElementById('cb-move-amount')?.focus(), 100);
  }

  async function _confirmMovement(type) {
    const session = await getActiveSession();
    if (!session) { Utils.toast(t('No open session','لا توجد وردية مفتوحة'), 'error'); return; }
    const amount = parseFloat(document.getElementById('cb-move-amount')?.value);
    const desc   = document.getElementById('cb-move-desc')?.value.trim();
    if (!amount || amount <= 0) { Utils.toast(t('Enter a valid amount','أدخل مبلغاً صحيحاً'), 'error'); return; }
    const user = Auth.getUser();
    await DB.add('cashbox_movements', {
      session_id: session.id, type, amount, description: desc,
      cashier: user?.full_name || user?.username, created_at: nowTS(),
    });
    _closeModal();
    Utils.toast(type==='in'?t('Cash added','تم إضافة النقد'):t('Cash withdrawn','تم سحب النقد'), 'success');
    await _refresh();
  }

  // ── HANDOVER ─────────────────────────────────────────────────
  async function showHandoverModal() {
    const session = await getActiveSession();
    if (!session) return;
    const movements = await getSessionMovements(session.id);
    const cashIn    = movements.filter(m=>m.type==='in').reduce((s,m)=>s+m.amount,0);
    const cashOut   = movements.filter(m=>m.type==='out').reduce((s,m)=>s+m.amount,0);
    const salesCash = movements.filter(m=>m.type==='sale').reduce((s,m)=>s+m.amount,0);
    const expected  = session.opening_amount + salesCash + cashIn - cashOut;

    _showModal(`
      <div class="modal-header">
        <h3>${t('Shift Handover','تسليم الوردية')}</h3>
        <button class="modal-close" onclick="CashBox._close()">✕</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--surface-2);border-radius:10px;padding:14px;margin-bottom:16px;font-size:0.85rem">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <div><span style="color:var(--text-muted)">${t('Current Cashier','الكاشير الحالي')}:</span> <strong>${Utils.sanitize(session.cashier_name)}</strong></div>
            <div><span style="color:var(--text-muted)">${t('Expected','المتوقع')}:</span> <strong style="color:var(--success)">${fmt(expected)}</strong></div>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${t('New Cashier Name','اسم الكاشير الجديد')}</label>
          <input type="text" class="form-control" id="cb-new-cashier"
            placeholder="${t('Enter new cashier name','أدخل اسم الكاشير الجديد')}">
        </div>
        <div class="form-group">
          <label class="form-label">${t('Actual Cash Count','العد الفعلي للنقد')}</label>
          <input type="number" class="form-control" id="cb-handover-count" value="${expected.toFixed(2)}"
            min="0" step="0.01" style="font-size:1.3rem;font-weight:700;text-align:center">
        </div>
        <div class="form-group">
          <label class="form-label">${t('Handover Notes','ملاحظات التسليم')}</label>
          <textarea class="form-control" id="cb-handover-notes" rows="2"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="CashBox._close()">${t('Cancel','إلغاء')}</button>
        <button class="btn btn-warning" onclick="CashBox._confirmHandover(${session.id},${expected})">
          ${t('Confirm Handover','تأكيد التسليم')}
        </button>
      </div>`);
  }

  async function _confirmHandover(sessionId, expected) {
    const newCashier = document.getElementById('cb-new-cashier')?.value.trim();
    const count      = parseFloat(document.getElementById('cb-handover-count')?.value) || 0;
    const notes      = document.getElementById('cb-handover-notes')?.value.trim();
    if (!newCashier) { Utils.toast(t('Enter new cashier name','أدخل اسم الكاشير الجديد'), 'error'); return; }
    const session = await DB.get('cashbox_sessions', sessionId);
    await DB.put('cashbox_sessions', { ...session, status:'handover', closed_at:nowTS(), closing_amount:count, difference:count-expected, notes });
    await DB.add('cashbox_sessions', {
      cashier_name:session.cashier_name.replace(session.cashier_name, newCashier),
      opening_amount:count, status:'open', opened_at:nowTS(),
      closed_at:null, closing_amount:null, difference:null,
      notes:`${t('Handover from','تسليم من')} ${session.cashier_name}`,
    });
    // Fix: set cashier_name to newCashier
    const sessions = await getSessions();
    const newS = sessions[sessions.length-1];
    if (newS) await DB.put('cashbox_sessions', { ...newS, cashier_name: newCashier });
    _closeModal();
    Utils.toast(t('Shift handed over!','تم تسليم الوردية!'), 'success');
    await _refresh();
  }

  // ── CLOSE BOX ────────────────────────────────────────────────
  async function showCloseModal() {
    const session   = await getActiveSession();
    if (!session) return;
    const movements = await getSessionMovements(session.id);
    const cashIn    = movements.filter(m=>m.type==='in').reduce((s,m)=>s+m.amount,0);
    const cashOut   = movements.filter(m=>m.type==='out').reduce((s,m)=>s+m.amount,0);
    const salesCash = movements.filter(m=>m.type==='sale').reduce((s,m)=>s+m.amount,0);
    const expected  = session.opening_amount + salesCash + cashIn - cashOut;

    _showModal(`
      <div class="modal-header" style="border-bottom:3px solid var(--danger)">
        <h3>${t('Close Cash Box','إغلاق الصندوق النقدي')}</h3>
        <button class="modal-close" onclick="CashBox._close()">✕</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--surface-2);border-radius:10px;padding:14px;margin-bottom:16px">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:0.85rem">
            <div style="padding:8px;background:var(--surface);border-radius:6px">
              <div style="color:var(--text-muted)">${t('Opening','الفتح')}</div>
              <div style="font-weight:700">${fmt(session.opening_amount)}</div>
            </div>
            <div style="padding:8px;background:var(--surface);border-radius:6px">
              <div style="color:var(--text-muted)">${t('Cash Sales','مبيعات')}</div>
              <div style="font-weight:700;color:var(--accent)">${fmt(salesCash)}</div>
            </div>
            <div style="padding:8px;background:var(--surface);border-radius:6px">
              <div style="color:var(--text-muted)">${t('Cash In','إدخال')}</div>
              <div style="font-weight:700;color:var(--success)">+${fmt(cashIn)}</div>
            </div>
            <div style="padding:8px;background:var(--surface);border-radius:6px">
              <div style="color:var(--text-muted)">${t('Cash Out','سحب')}</div>
              <div style="font-weight:700;color:var(--danger)">-${fmt(cashOut)}</div>
            </div>
          </div>
          <div style="margin-top:10px;padding:10px;background:var(--primary-alpha);border-radius:8px;text-align:center;border:1px solid var(--primary)">
            <div style="font-size:0.75rem;color:var(--text-muted)">${t('Expected in Drawer','المتوقع في الصندوق')}</div>
            <div style="font-size:1.4rem;font-weight:800;color:var(--primary)">${fmt(expected)}</div>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${t('Actual Cash Count','العد الفعلي للنقد')}</label>
          <input type="number" class="form-control" id="cb-closing-count" value="${expected.toFixed(2)}"
            min="0" step="0.01" style="font-size:1.3rem;font-weight:700;text-align:center"
            oninput="CashBox._updateDiff(${expected})">
          <div id="cb-diff-display" style="text-align:center;margin-top:8px;font-size:0.9rem;font-weight:600"></div>
        </div>
        <div class="form-group">
          <label class="form-label">${t('Closing Notes','ملاحظات الإغلاق')}</label>
          <textarea class="form-control" id="cb-close-notes" rows="2"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="CashBox._close()">${t('Cancel','إلغاء')}</button>
        <button class="btn btn-danger" onclick="CashBox._confirmClose(${session.id},${expected})">
          ${t('Close Box','إغلاق الصندوق')}
        </button>
      </div>`);
    setTimeout(() => _updateDiff(expected), 50);
  }

  function _updateDiff(expected) {
    const count = parseFloat(document.getElementById('cb-closing-count')?.value) || 0;
    const diff  = count - expected;
    const el    = document.getElementById('cb-diff-display');
    if (!el) return;
    el.innerHTML = diff === 0
      ? `<span style="color:var(--success)">✓ ${t('Amount matches','المبلغ مطابق')}</span>`
      : diff > 0
        ? `<span style="color:var(--warning)">▲ ${t('Surplus','فائض')}: +${fmt(Math.abs(diff))}</span>`
        : `<span style="color:var(--danger)">▼ ${t('Shortage','عجز')}: -${fmt(Math.abs(diff))}</span>`;
  }

  async function _confirmClose(sessionId, expected) {
    const count = parseFloat(document.getElementById('cb-closing-count')?.value) || 0;
    const notes = document.getElementById('cb-close-notes')?.value.trim();
    const diff  = count - expected;
    const session = await DB.get('cashbox_sessions', sessionId);
    await DB.put('cashbox_sessions', { ...session, status:'closed', closed_at:nowTS(), closing_amount:count, difference:diff, notes });
    _closeModal();
    Utils.toast(t('Cash box closed!','تم إغلاق الصندوق!'), 'success');
    await _refresh();
    setTimeout(() => _printCloseReport(session, count, expected, diff), 300);
  }

  // ── PRINT ────────────────────────────────────────────────────
  async function printShiftReport() {
    const session = await getActiveSession();
    if (!session) { Utils.toast(t('No active session','لا توجد وردية مفتوحة'), 'warning'); return; }
    const movements = await getSessionMovements(session.id);
    const cashIn    = movements.filter(m=>m.type==='in').reduce((s,m)=>s+m.amount,0);
    const cashOut   = movements.filter(m=>m.type==='out').reduce((s,m)=>s+m.amount,0);
    const salesCash = movements.filter(m=>m.type==='sale').reduce((s,m)=>s+m.amount,0);
    const balance   = session.opening_amount + salesCash + cashIn - cashOut;
    const company   = await DB.getSetting('company_name','Store');
    const size      = await DB.getSetting('receipt_size','80mm');
    const html      = _buildReceiptHTML(company, session, movements, salesCash, cashIn, cashOut, balance, size);
    Utils.printElement(html, t('Shift Report','تقرير الوردية'), size==='80mm'?'80mm auto':'A4');
  }

  async function _printCloseReport(session, count, expected, diff) {
    const movements = await getSessionMovements(session.id);
    const cashIn    = movements.filter(m=>m.type==='in').reduce((s,m)=>s+m.amount,0);
    const cashOut   = movements.filter(m=>m.type==='out').reduce((s,m)=>s+m.amount,0);
    const salesCash = movements.filter(m=>m.type==='sale').reduce((s,m)=>s+m.amount,0);
    const company   = await DB.getSetting('company_name','Store');
    const size      = await DB.getSetting('receipt_size','80mm');
    const html      = _buildReceiptHTML(company, session, movements, salesCash, cashIn, cashOut, count, size, {count, expected, diff});
    Utils.printElement(html, t('Box Close Report','تقرير إغلاق الصندوق'), size==='80mm'?'80mm auto':'A4');
  }

  async function printSessionReport(sessionId) {
    const session   = await DB.get('cashbox_sessions', sessionId);
    if (!session) return;
    const movements = await getSessionMovements(sessionId);
    const cashIn    = movements.filter(m=>m.type==='in').reduce((s,m)=>s+m.amount,0);
    const cashOut   = movements.filter(m=>m.type==='out').reduce((s,m)=>s+m.amount,0);
    const salesCash = movements.filter(m=>m.type==='sale').reduce((s,m)=>s+m.amount,0);
    const balance   = session.opening_amount + salesCash + cashIn - cashOut;
    const company   = await DB.getSetting('company_name','Store');
    const size      = await DB.getSetting('receipt_size','80mm');
    const closeInfo = session.closing_amount!==null ? {count:session.closing_amount, expected:balance, diff:session.difference} : null;
    const html      = _buildReceiptHTML(company, session, movements, salesCash, cashIn, cashOut, balance, size, closeInfo);
    Utils.printElement(html, t('Session Report','تقرير الوردية'), size==='80mm'?'80mm auto':'A4');
  }

  function _buildReceiptHTML(company, session, movements, salesCash, cashIn, cashOut, balance, size, closeInfo) {
    const narrow = size==='80mm'||size==='58mm';
    const w = narrow ? 'width:74mm' : 'max-width:190mm;margin:auto';
    const fs = (n) => `font-size:${narrow ? Math.max(11, n * 0.95) : n}px`;
    return `<div style="${w};font-family:'Segoe UI','Tahoma','Arial','Cairo',sans-serif;padding:${narrow?'2mm':'10mm'};color:#000;font-weight:600">
      <div style="text-align:center;border-bottom:2px dashed #000;padding-bottom:8px;margin-bottom:10px">
        <div style="font-size:15px;font-weight:900">${Utils.sanitize(company)}</div>
        <div style="font-size:13px;font-weight:800;margin:4px 0">${closeInfo?t('BOX CLOSE REPORT','تقرير إغلاق الصندوق'):t('SHIFT REPORT','تقرير الوردية')}</div>
        <div style="font-size:10.5px;color:#000">${stamp()}</div>
      </div>
      <div style="margin-bottom:8px;font-size:11px">
        <div style="display:flex;justify-content:space-between"><span>${t('Cashier','الكاشير')}:</span><strong>${Utils.sanitize(session.cashier_name)}</strong></div>
        <div style="display:flex;justify-content:space-between"><span>${t('Started','البداية')}:</span><strong>${new Date(session.opened_at).toLocaleTimeString()}</strong></div>
      </div>
      <div style="border-top:1.5px dashed #000;padding-top:8px;margin-bottom:8px;font-size:11px">
        <div style="display:flex;justify-content:space-between"><span>${t('Opening','الفتح')}</span><span style="font-weight:700">${fmt(session.opening_amount)}</span></div>
        <div style="display:flex;justify-content:space-between"><span>${t('Cash Sales','مبيعات نقدية')}</span><span style="font-weight:700">+${fmt(salesCash)}</span></div>
        <div style="display:flex;justify-content:space-between"><span>${t('Cash In','إدخال')}</span><span style="font-weight:700">+${fmt(cashIn)}</span></div>
        <div style="display:flex;justify-content:space-between"><span>${t('Cash Out','سحب')}</span><span style="font-weight:700">-${fmt(cashOut)}</span></div>
      </div>
      <div style="border-top:2px solid #000;padding-top:6px;margin-bottom:8px">
        <div style="font-size:14px;display:flex;justify-content:space-between;font-weight:900"><span>${t('BALANCE','الرصيد')}</span><span>${fmt(balance)}</span></div>
      </div>
      ${closeInfo ? `<div style="border-top:1.5px dashed #000;padding-top:6px;font-size:11px">
        <div style="display:flex;justify-content:space-between"><span>${t('Physical Count','العد الفعلي')}</span><span style="font-weight:700">${fmt(closeInfo.count)}</span></div>
        <div style="display:flex;justify-content:space-between;font-weight:800;color:#000">
          <span>${t('Difference','الفرق')}</span><span>${closeInfo.diff>=0?'+':''}${fmt(closeInfo.diff)}</span>
        </div>
      </div>` : ''}
      <div style="text-align:center;margin-top:10px;font-size:10px;color:#000;border-top:1px dashed #000;padding-top:4px">${movements.length} ${t('movements','حركة')} • ${todayStr()}</div>
    </div>`;
  }

  // ── BOX MANAGEMENT ───────────────────────────────────────────
  let _mgmtTermFilter = 'all';

  async function renderManagement(container, filterTerm = null) {
    if (filterTerm !== null) _mgmtTermFilter = filterTerm;
    let allSessions = (await getSessions()).slice().reverse();
    const movements = await getMovements();

    // Check if this machine is Server or Client Station for Data Isolation
    let isServerNode = true;
    let myBranch = 'main';
    let myNode = getTerminalId();
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      try {
        const cfg = await BranchSync.getConfig();
        isServerNode = (cfg.role === 'server');
        myBranch = cfg.branchId || 'main';
        myNode = cfg.nodeId || getTerminalId();
      } catch(e) {}
    }

    // Strict Isolation: Client station or branch only sees its own sessions even if admin!
    if (!isServerNode) {
      allSessions = allSessions.filter(s => (s.terminal_id === myNode || s.branch_id === myBranch || s.syncBranchId === myBranch));
      _mgmtTermFilter = myNode;
    }

    // Unique terminals list (including remote branches and workstations)
    const termSet = new Set(allSessions.map(s => s.syncBranchId || s.syncNodeId || s.terminal_id || myNode));
    termSet.add(myNode);
    const termList = Array.from(termSet);

    const sessions = _mgmtTermFilter === 'all' 
      ? allSessions 
      : allSessions.filter(s => (s.syncBranchId === _mgmtTermFilter || s.syncNodeId === _mgmtTermFilter || (s.terminal_id || 'POS-1') === _mgmtTermFilter));

    container.innerHTML = `<div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${t('Box Management','إدارة الصندوق')}</h1>
          <div class="breadcrumb">${t('Cash Box','الصندوق')} › ${t('All Sessions','كل الورديات')}</div>
        </div>
        <div class="page-actions" style="display:flex;align-items:center;gap:10px">
          <label style="font-size:0.85rem;font-weight:700">${t('Filter by Terminal:','تصفية بالجهاز:')}</label>
          <select class="form-control" style="width:auto;font-weight:700" onchange="CashBox.filterMgmtByTerminal(this.value)">
            <option value="all" ${_mgmtTermFilter === 'all' ? 'selected' : ''}>-- ${t('All Terminals','كافة الأجهزة')} --</option>
            ${termList.map(tName => `<option value="${Utils.sanitize(tName)}" ${_mgmtTermFilter === tName ? 'selected' : ''}>🖥️ ${Utils.sanitize(tName)}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="card">
        <div class="table-wrapper">
          <table class="data-table">
            <thead><tr>
              <th>#</th>
              <th>${t('Terminal','الجهاز')}</th>
              <th>${t('Cashier','الكاشير')}</th>
              <th>${t('Status','الحالة')}</th>
              <th>${t('Opened','الفتح')}</th>
              <th>${t('Closed','الإغلاق')}</th>
              <th>${t('Opening','الفتح')}</th>
              <th>${t('Sales','مبيعات')}</th>
              <th>${t('Balance','الرصيد')}</th>
              <th>${t('Count','العد')}</th>
              <th>${t('Diff','الفرق')}</th>
              <th></th>
            </tr></thead>
            <tbody>
              ${sessions.length===0
                ? `<tr><td colspan="12" class="empty-state">${t('No sessions found','لا توجد ورديات')}</td></tr>`
                : sessions.map(s=>{
                    const mvs   = movements.filter(m=>m.session_id===s.id);
                    const sales = s.total_sales != null ? s.total_sales : mvs.filter(m=>m.type==='sale').reduce((x,m)=>x+m.amount,0);
                    const cin   = mvs.filter(m=>m.type==='in').reduce((x,m)=>x+m.amount,0);
                    const cout  = mvs.filter(m=>m.type==='out').reduce((x,m)=>x+m.amount,0);
                    const bal   = (s.closing_amount !== null && s.closing_amount !== undefined) ? s.closing_amount : (s.opening_amount+sales+cin-cout);
                    const badgeCls = s.status==='open'?'success':s.status==='handover'?'warning':'danger';
                    const statusLabel = s.status==='open'?t('Open','مفتوح'):s.status==='handover'?t('Handover','تسليم'):t('Closed','مغلق');
                    const termLabel = s.syncBranchId ? `${s.syncBranchId} (${s.terminal_id || s.syncNodeId || 'POS'})` : (s.terminal_id || s.syncNodeId || 'POS-1');
                    return `<tr>
                      <td>${s.id}</td>
                      <td><span class="badge badge-primary" style="font-weight:800">🖥️ ${Utils.sanitize(termLabel)}</span></td>
                      <td><strong>${Utils.sanitize(s.cashier_name)}</strong></td>
                      <td><span class="badge badge-${badgeCls}">${statusLabel}</span></td>
                      <td style="font-size:0.8rem">${new Date(s.opened_at).toLocaleString()}</td>
                      <td style="font-size:0.8rem">${s.closed_at?new Date(s.closed_at).toLocaleString():'—'}</td>
                      <td>${fmt(s.opening_amount)}</td>
                      <td style="color:var(--accent)">${fmt(sales)}</td>
                      <td style="font-weight:700">${fmt(bal)}</td>
                      <td>${s.closing_amount!==null?fmt(s.closing_amount):'—'}</td>
                      <td style="font-weight:700;color:${s.difference===0?'var(--success)':s.difference>0?'var(--warning)':'var(--danger)'}">
                        ${s.difference!==null?(s.difference>=0?'+':'')+fmt(s.difference):'—'}
                      </td>
                      <td>
                        <button class="btn btn-secondary btn-sm" onclick="CashBox.printSessionReport(${s.id})">
                          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                        </button>
                      </td>
                    </tr>`;}).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  }

  // ── REPORTS ──────────────────────────────────────────────────
  async function renderReports(container) {
    let sessions  = await getSessions();
    let movements = await getMovements();

    // Data isolation for client stations/branches
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      try {
        const cfg = await BranchSync.getConfig();
        if (cfg.role !== 'server') {
          const myBranch = cfg.branchId || 'main';
          const myNode = cfg.nodeId || getTerminalId();
          sessions = sessions.filter(s => (s.terminal_id === myNode || s.branch_id === myBranch || s.syncBranchId === myBranch));
          const allowedSessionIds = new Set(sessions.map(s => s.id));
          movements = movements.filter(m => allowedSessionIds.has(m.session_id) || m.terminal_id === myNode);
        }
      } catch(e) {}
    }

    const closed    = sessions.filter(s=>s.status!=='open');
    const totalSales= movements.filter(m=>m.type==='sale').reduce((s,m)=>s+m.amount,0);
    const totalIn   = movements.filter(m=>m.type==='in').reduce((s,m)=>s+m.amount,0);
    const totalOut  = movements.filter(m=>m.type==='out').reduce((s,m)=>s+m.amount,0);
    const totalDiff = closed.reduce((s,sess)=>s+(sess.difference||0),0);

    container.innerHTML = `<div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${t('Cash Box Reports','تقارير الصندوق')}</h1>
        </div>
      </div>
      <div class="stats-grid grid-6" style="margin-bottom:12px">
        <div class="stat-card" style="border-top:3px solid var(--accent)">
          <div class="stat-label">${t('Total Cash Sales','إجمالي المبيعات النقدية')}</div>
          <div class="stat-value">${fmt(totalSales)}</div>
        </div>
        <div class="stat-card" style="border-top:3px solid var(--success)">
          <div class="stat-label">${t('Total Cash In','إجمالي الإدخالات')}</div>
          <div class="stat-value" style="color:var(--success)">+${fmt(totalIn)}</div>
        </div>
        <div class="stat-card" style="border-top:3px solid var(--danger)">
          <div class="stat-label">${t('Total Cash Out','إجمالي السحوبات')}</div>
          <div class="stat-value" style="color:var(--danger)">-${fmt(totalOut)}</div>
        </div>
        <div class="stat-card" style="border-top:3px solid ${totalDiff>=0?'var(--success)':'var(--danger)'}">
          <div class="stat-label">${t('Total Discrepancy','إجمالي الفروقات')}</div>
          <div class="stat-value" style="color:${totalDiff>=0?'var(--success)':'var(--danger)'}">${totalDiff>=0?'+':''}${fmt(totalDiff)}</div>
        </div>
        <div class="stat-card" style="border-top:3px solid var(--primary)">
          <div class="stat-label">${t('Total Sessions','إجمالي الورديات')}</div>
          <div class="stat-value">${sessions.length}</div>
        </div>
        <div class="stat-card" style="border-top:3px solid var(--warning)">
          <div class="stat-label">${t('Closed Sessions','ورديات مغلقة')}</div>
          <div class="stat-value">${closed.length}</div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><div class="card-title">${t('All Cash Movements','كل حركات الصندوق')}</div></div>
        <div class="table-wrapper">
          <table class="data-table">
            <thead><tr>
              <th>${t('Date','التاريخ')}</th><th>${t('Type','النوع')}</th>
              <th>${t('Description','الوصف')}</th><th>${t('Amount','المبلغ')}</th>
              <th>${t('Cashier','الكاشير')}</th><th>${t('Session #','الوردية')}</th>
            </tr></thead>
            <tbody>
              ${movements.length===0
                ? `<tr><td colspan="6" class="empty-state">${t('No movements','لا توجد حركات')}</td></tr>`
                : movements.slice().reverse().map(m=>`<tr>
                    <td style="font-size:0.8rem">${new Date(m.created_at).toLocaleString()}</td>
                    <td><span class="badge badge-${m.type==='sale'?'info':m.type==='in'?'success':'danger'}">${
                      m.type==='sale'?t('Sale','بيع'):m.type==='in'?t('In','إدخال'):t('Out','سحب')
                    }</span></td>
                    <td>${Utils.sanitize(m.description||'—')}</td>
                    <td style="font-weight:700;color:${m.type==='out'?'var(--danger)':'var(--success)'}">
                      ${m.type==='out'?'-':'+'} ${fmt(m.amount)}
                    </td>
                    <td>${Utils.sanitize(m.cashier||'—')}</td>
                    <td>#${m.session_id}</td>
                  </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  }

  // ── Internal refresh ─────────────────────────────────────────
  async function _refresh() {
    const content = document.getElementById('page-content');
    if (content) await render(content);
  }

  function showTerminalSwitchModal() {
    const cur = getTerminalId();
    _showModal(`
      <div class="modal-header">
        <h3>${t('Switch Station / Terminal','تغيير جهاز / نقطة البيع')}</h3>
        <button class="modal-close" onclick="CashBox._close()">✕</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">${t('This Workstation Identifier','اسم أو معرّف هذا الجهاز')}</label>
          <input type="text" class="form-control" id="cb-switch-term-input" value="${Utils.sanitize(cur)}" placeholder="e.g. POS-1, POS-2" style="font-size:1.2rem;font-weight:800;text-align:center">
          <div style="font-size:0.75rem;color:var(--text-muted);margin-top:6px">
            ${t('Sets the local terminal identifier for this PC. Shifts and sales will be recorded under this register.','يحدد اسم هذا الجهاز للتمييز بين أجهزة الكاشير داخل المحل.')}
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="CashBox._close()">${t('Cancel','إلغاء')}</button>
        <button class="btn btn-primary" onclick="CashBox._confirmSwitchTerminal()">
          ${t('Save Terminal','حفظ الجهاز')}
        </button>
      </div>
    `);
  }

  async function _confirmSwitchTerminal() {
    const val = document.getElementById('cb-switch-term-input')?.value.trim();
    if (!val) return;
    localStorage.setItem('redshark_pos_terminal', val);
    await DB.setSetting('pos_terminal_name', val);
    _closeModal();
    Utils.toast(`${t('Terminal set to','تم تعيين الجهاز:')} ${val}`, 'success');
    await _refresh();
  }

  // ── Public API ───────────────────────────────────────────────
  return {
    render, renderManagement, renderReports,
    showOpenModal, showMovementModal, showHandoverModal, showCloseModal,
    showTerminalSwitchModal, _confirmSwitchTerminal,
    filterMgmtByTerminal(term) {
      const container = document.getElementById('page-content');
      if (container) renderManagement(container, term);
    },
    printShiftReport, printSessionReport,
    // Called from modal buttons (global scope)
    _confirmOpen, _confirmMovement, _confirmHandover, _confirmClose,
    _updateDiff, _close: _closeModal,
    getActiveSession,
    getTerminalId,
    // Called by POS when a cash sale completes
    async recordSale(amount, description) {
      const currentTerm = getTerminalId();
      let session = await getActiveSession(currentTerm);
      const user  = Auth.getUser();
      const cashierName = user?.full_name || user?.username || 'Cashier';

      if (!session) {
        // Auto-open active session for current shift if cashier hadn't opened manually
        const newSession = {
          terminal_id: currentTerm,
          cashier_id: user?.id || 1,
          cashier_name: cashierName,
          opening_amount: 0,
          opened_at: nowTS(),
          status: 'open',
          closing_amount: null,
          difference: null,
          notes: `Auto-opened on ${currentTerm} POS cash transaction`
        };
        const sessionId = await DB.add('cashbox_sessions', newSession);
        session = { ...newSession, id: sessionId };
      }

      const isRefund = amount < 0;
      const absAmt   = Math.abs(amount);

      await DB.add('cashbox_movements', {
        session_id: session.id,
        terminal_id: currentTerm,
        type: isRefund ? 'out' : 'sale',
        amount: absAmt,
        description: description || (isRefund ? t('POS Refund','مرتجع نقطة البيع') : t('POS Sale','بيع نقطة البيع')),
        cashier: cashierName,
        created_at: nowTS(),
      });

      // Refresh CashBox view if visible
      if (document.getElementById('cashbox-root')) {
        const content = document.getElementById('page-content');
        if (content) await render(content);
      }
    },
  };
})();

window.CashBox = CashBox;
