/* ================================================================
   NexPOS — POS (Point of Sale) Module
   ================================================================ */

const POS = (() => {
  let _cart         = [];
  let _customer     = null;
  let _held         = [];
  let _items        = [];
  let _cats         = [];
  let _settings     = {};
  let _activeCatId  = 'categories'; // 'categories', 'all', or specific cat ID

  let _txMode       = 'sale'; // 'sale', 'return', or 'damage'

  let _redeemedPoints = 0;
  let _pointsDiscount = 0;
  let _activePromoDiscount = 0;
  let _activePromoLabel = '';
  let _currentMobileView = 'catalog'; // 'catalog' or 'cart'

  // Barcode scanner deduplication cooldown
  let _lastScanCode = '';
  let _lastScanTime = 0;

  // Live Date / Time & Upcoming Invoice & Touch Numpad State
  let _clockInterval = null;
  let _currentInvoiceNumber = '';
  let _posNumpadTarget = 'qty'; // 'qty', 'disc', or 'search'
  let _posSelectedCartIndex = -1;
  let _posNumpadBuffer = '';
  let _posNumpadReplaceMode = true;
  let _payKeypadTarget = 'tendered1'; // 'tendered1', 'tendered2', or 'discount'
  let _payKeypadBuffer = '';
  let _posItemsLimit = 90;

  // POS Cart Columns Configuration defaults
  const DEFAULT_CART_COLUMNS = {
    col_name: true,      // Description / Item Name (Primary, always true)
    col_code: false,     // Barcode / SKU Code
    col_unit: false,     // Unit of measure (e.g. pcs, kg)
    col_price: true,     // Selling Unit Price
    col_cost: false,     // Item Cost Price
    col_qty: true,       // Quantity stepper/input
    col_disc: true,      // Discount %
    col_vat: false,      // VAT rate/type
    col_total: true,     // Line Total
    col_actions: true    // Remove / Note / Type cycle actions
  };

  // Web Audio Error Buzzer tone for missing items / out of stock
  function _playErrorTone() {
    try {
      if (window.AICopilot && typeof AICopilot.playAudio === 'function') {
        AICopilot.playAudio('error');
        return;
      }
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      const now = ctx.currentTime;
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(280, now);
      osc.frequency.setValueAtTime(180, now + 0.12);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.linearRampToValueAtTime(0.01, now + 0.3);
      osc.start(now);
      osc.stop(now + 0.3);
      setTimeout(() => { ctx.close().catch(() => {}); }, 400);
    } catch (e) {
      console.warn('Audio tone error:', e);
    }
  }

  async function render(container) {
    _settings = {
      currency1:    await DB.getSetting('currency_1', 'USD'),
      currency2:    await DB.getSetting('currency_2', 'LBP'),
      exchRate:     await DB.getSetting('exchange_rate', 89500),
      vatRate:      await DB.getSetting('vat_rate', 11),
      vatEnabled:   await DB.getSetting('vat_enabled', false),
      companyName:  await DB.getSetting('company_name', 'Store'),
      companyPhone: await DB.getSetting('company_phone', ''),
      companyAddress: await DB.getSetting('company_address', ''),
      vatNumber:    await DB.getSetting('vat_number', ''),
      companyLogo:  await DB.getSetting('company_logo', ''),
      printLogo:    await DB.getSetting('print_logo', true),
      receiptFooter: await DB.getSetting('receipt_footer', ''),
      primaryColor: await DB.getSetting('inv_primary_color', '#2563eb'),
      fontFamily:   await DB.getSetting('inv_font_family', 'Cairo'),
      logoSize:     parseInt(await DB.getSetting('inv_logo_size', 80)) || 80,
      customSubtitle: await DB.getSetting('inv_custom_subtitle', ''),
      termsText:    await DB.getSetting('inv_terms_text', ''),
      footerNote:   await DB.getSetting('inv_footer_note', ''),
      allowNegativeStock: await DB.getSetting('allow_negative_stock', false),
      loyaltyEnabled: await DB.getSetting('loyalty_enabled', true),
      loyaltyEarnRate: parseFloat(await DB.getSetting('loyalty_earn_rate', 1)) || 1,
      loyaltyRedeemRate: parseFloat(await DB.getSetting('loyalty_redeem_rate', 100)) || 100,
      loyaltyMinRedeem: parseInt(await DB.getSetting('loyalty_min_redeem', 50)) || 50,
      cartColumns: Object.assign({}, DEFAULT_CART_COLUMNS, await DB.getSetting('pos_cart_columns', DEFAULT_CART_COLUMNS)),
      cartLayoutMode: localStorage.getItem('pos_cart_layout_mode') || 'auto', // 'auto', 'table', 'cards'
      autoPrint: await DB.getSetting('auto_print', true),
      previewReceipt: await DB.getSetting('pos_preview_receipt', false),
      poleDisplayEnabled: await DB.getSetting('pole_display_enabled', true),
      poleDisplayPort:    await DB.getSetting('pole_display_port', 'auto'),
      poleDisplayBaud:    parseInt(await DB.getSetting('pole_display_baud', 2400)) || 2400,
    };

    _items = await DB.getAll('items', i => i.status !== 'inactive');
    _cats  = await DB.getAll('categories');
    const lang = i18n.getLang();
    const isAR = lang === 'ar';
    _activeCatId = 'categories';
    _txMode      = 'sale';
    _redeemedPoints = 0;
    _pointsDiscount = 0;
    _activePromoDiscount = 0;
    _activePromoLabel = '';

    if (!_cart) _cart = [];

    container.style.padding = '0';
    container.style.overflow = 'hidden';
    container.style.height   = '100%';

    container.innerHTML = `
    <div id="pos-root" class="mobile-show-catalog" style="display:flex;flex-direction:column;height:100%;overflow:hidden">

      <div class="pos-main-split">
        <!-- LEFT: Items & Search Column -->
        <div class="pos-items-col" id="pos-items-col">
          <!-- Search Bar with Shortcut [Press /] and Scanner Icon -->
          <div class="cockpit-search-wrap">
            <svg class="cockpit-search-icon-left" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" class="cockpit-search-input" id="pos-search"
              placeholder="${isAR ? 'ابحث عن صنف أو امسح الباركود مباشرة... [اضغط /]' : 'Scan barcode or search products... [Press /]'}"
              oninput="POS.onSearchInput(this, event)"
              onkeydown="POS.onSearchKeyDown(this, event)"
              autocomplete="off">
            <span class="cockpit-scanner-icon-right" title="Barcode Scanner Ready">||||||</span>
          </div>

          <!-- Main Navigation Filter Chips (Custom Item, Categories, Dollar Rate) -->
          <div class="cockpit-chips-bar" id="pos-cat-buttons">
            <button type="button" class="cockpit-chip-btn pos-custom-item-btn" onclick="POS.openCustomItemModal()" title="${isAR ? 'إضافة صنف حر أو خدمة غير مسجلة' : 'Add Custom / Open Item'}" style="background:#ef4444;color:white;border-color:#dc2626;font-weight:800">
              ✨ ${isAR ? 'صنف غير معرّف' : 'Custom Item'}
            </button>
            <button type="button" class="cockpit-chip-btn active" data-cat="categories" onclick="POS.showCategories(this)">
              📂 ${isAR ? 'التصنيفات' : 'Categories'}
            </button>
            <button type="button" class="cockpit-chip-btn" data-cat="all" onclick="POS.filterByCategory('all', this)">
              📦 ${isAR ? 'كل الأصناف' : 'All Products'}
            </button>
          </div>

          <!-- Product / Categories Grid -->
          <div class="cockpit-products-grid" id="pos-items-grid">
            ${renderCategoryCards(_cats, isAR)}
          </div>
        </div>

        <!-- Draggable Split Resizer Divider -->
        <div class="pos-resizer" id="pos-resizer" title="${isAR ? 'اسحب لتغيير عرض السلة والفاتورة' : 'Drag to resize cart panel'}"></div>

        <!-- RIGHT: Cart Panel (Maximized for Invoice Items) -->
        <div class="pos-cart-col" id="pos-cart-panel">
          <!-- Cart Header -->
          <div class="cockpit-cart-header">
            <div class="cockpit-cart-title" style="display:flex;align-items:center;gap:6px;flex-wrap:nowrap">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6"/></svg>
              <span>${isAR ? 'سلة المبيعات' : 'CART'}</span>
              <span class="cockpit-cart-badge" id="cart-count">0</span>
              <span id="pos-cart-inv-badge" style="font-size:0.75rem;font-weight:800;color:#ef4444;background:rgba(239,68,68,0.12);padding:2px 6px;border-radius:6px" title="${isAR ? 'رقم الفاتورة القادمة' : 'Upcoming Invoice Number'}">#INV-...</span>

              <!-- Search Old Invoices & Steppers (Directly in Cart Header) -->
              <div class="cockpit-old-inv-group" title="${isAR ? 'البحث وتصفح الفواتير السابقة' : 'Browse & Search Old Invoices'}">
                <button type="button" class="btn-icon" onclick="POS.stepOldInvoice(-1)" title="${isAR ? 'الفاتورة السابقة (◀)' : 'Previous Invoice'}">◀</button>
                <input type="text" id="pos-old-inv-search" class="cockpit-old-inv-input" placeholder="${isAR ? 'رقم الفاتورة...' : 'Inv #...'}" onfocus="this.select()" onclick="this.select()" onkeydown="if(event.key==='Enter') POS.searchOldInvoice(this.value)">
                <button type="button" class="btn-icon" onclick="POS.searchOldInvoice(document.getElementById('pos-old-inv-search')?.value)" title="${isAR ? 'بحث عن الفاتورة' : 'Search Invoice'}">🔍</button>
                <button type="button" class="btn-icon" onclick="POS.stepOldInvoice(1)" title="${isAR ? 'الفاتورة التالية (▶)' : 'Next Invoice'}">▶</button>
              </div>
            </div>
            <div class="cockpit-cart-actions" style="display:flex;align-items:center;gap:4px">
              <button type="button" class="cockpit-cart-icon-btn" onclick="POS.newSale()" title="${isAR ? 'فاتورة جديدة (F2)' : 'New Invoice (F2)'}" style="color:#ef4444;font-weight:900">➕</button>
              <button type="button" class="btn btn-xs btn-secondary" onclick="POS.holdSale()" title="${isAR ? 'تعليق الفاتورة (F8)' : 'Hold Invoice (F8)'}" style="font-size:0.72rem;padding:3px 7px;font-weight:700;display:inline-flex;align-items:center;gap:3px">
                <span>⏸</span> <span>${isAR ? 'تعليق' : 'Hold'}</span>
              </button>
              <button type="button" class="btn btn-xs btn-primary" id="pos-resume-btn" onclick="POS.resumeHeldSale()" title="${isAR ? 'استعادة الفواتير المعلقة' : 'Resume Held Invoices'}" style="display:none;font-size:0.72rem;padding:3px 7px;font-weight:800;align-items:center;gap:3px;background:#ef4444;border-color:#dc2626">
                <span>▶</span> <span>${isAR ? 'معلقة' : 'Resume'}</span>
                <span class="badge" id="pos-held-count-badge" style="background:#ffffff;color:#ef4444;padding:1px 5px;border-radius:10px;font-size:0.68rem;font-weight:900">0</span>
              </button>
              <button type="button" class="cockpit-cart-icon-btn" onclick="App.toggleTheme()" id="pos-cockpit-theme-btn" title="${isAR ? 'تبديل المظهر (داكن / رمادي / فاتح)' : 'Toggle Theme (Dark / White-Gray / Light)'}">🌓</button>
              <button type="button" class="cockpit-cart-icon-btn" onclick="POS.showLatestInvoice()" title="${isAR ? 'سجل الفواتير' : 'Invoice History'}">📑</button>
              <button type="button" class="cockpit-cart-icon-btn" onclick="POS.openCustomerDisplay()" title="${isAR ? 'شاشة العميل' : 'Customer Display'}">🖥️</button>
              <button type="button" class="cockpit-cart-icon-btn" onclick="POS.clearCart()" title="${isAR ? 'إفراغ السلة' : 'Void Cart'}" style="color:#ef4444">🗑️</button>
            </div>
          </div>

          <!-- Transaction Type Switcher Bar (Sale / Return / Damage / Gift) -->
          <div class="pos-tx-mode-bar" id="pos-tx-mode-bar">
            <button type="button" class="pos-tx-btn active" id="tx-mode-sale" onclick="POS.setTxMode('sale')">
              🛒 ${isAR ? 'بيع' : 'Sale'}
            </button>
            <button type="button" class="pos-tx-btn" id="tx-mode-return" onclick="POS.setTxMode('return')">
              ↩️ ${isAR ? 'إرجاع' : 'Return'}
            </button>
            <button type="button" class="pos-tx-btn" id="tx-mode-damage" onclick="POS.setTxMode('damage')">
              ⚠️ ${isAR ? 'تالف' : 'Damage'}
            </button>
            <button type="button" class="pos-tx-btn" id="tx-mode-gift" onclick="POS.setTxMode('gift')">
              🎁 ${isAR ? 'هدية' : 'Gift'}
            </button>
          </div>
          <div id="tx-mode-banner" style="display:none;padding:5px 12px;font-size:0.8rem;text-align:center;font-weight:800;margin:3px 8px;border-radius:6px"></div>

          <!-- Cart Items Container (Maximized Space — Customer moved to Topbar) -->

          <!-- Cart Items Container (Maximized Space) -->
          <div class="cockpit-cart-items-wrap" id="pos-cart-items">
            <div class="cockpit-cart-empty" id="cart-empty">
              <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="#334155" stroke-width="1.6"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 01-8 0"/></svg>
              <div class="cockpit-empty-title">${isAR ? 'سلة المبيعات فارغة' : 'Cart is currently empty'}</div>
              <div class="cockpit-empty-subtitle">${isAR ? 'امسح الباركود أو انقر على الأصناف لبدء البيع' : 'Scan barcode or click items to start transaction'}</div>
            </div>
          </div>

          <!-- Hidden inputs for existing discount sync -->
          <input type="hidden" id="pos-discount-val" value="0">
          <input type="hidden" id="pos-discount-type" value="pct">

          <!-- Draggable Horizontal Resizer Divider (Up/Down) -->
          <div class="pos-cart-bottom-resizer" id="pos-cart-bottom-resizer" title="${isAR ? 'اسحب لأعلى أو لأسفل لتغيير ارتفاع اللوحة السفلية' : 'Drag up/down to resize bottom panel'}">
            <div class="resizer-handle-grip"></div>
          </div>

          <!-- DIVIDED BOTTOM: TOUCH NUMPAD + TOTAL & TENDER -->
          <div class="pos-cart-bottom-grid" id="pos-cart-bottom-grid">
            <!-- LEFT: Touch Numpad for Touchscreen Cashiers -->
            <div class="pos-touch-numpad-wrap" id="pos-touch-numpad-wrap">
              <div class="pos-numpad-mode-tabs">
                <button type="button" class="pos-np-mode-btn active" id="np-mode-qty" onclick="POS.setNumpadMode('qty')" title="${isAR ? 'تعديل الكمية' : 'Quantity'}">${isAR ? 'كمية' : 'Qty'}</button>
                <button type="button" class="pos-np-mode-btn" id="np-mode-disc" onclick="POS.setNumpadMode('disc')" title="${isAR ? 'خصم الصنف' : 'Discount'}">${isAR ? 'خصم' : 'Disc'}</button>
                <button type="button" class="pos-np-mode-btn" id="np-mode-price" onclick="POS.setNumpadMode('price')" title="${isAR ? 'تعديل السعر (مشرف)' : 'Price'}">${isAR ? 'سعر' : 'Price'}</button>
                <button type="button" class="pos-np-mode-btn" id="np-mode-type" onclick="POS.setNumpadMode('type')" title="${isAR ? 'تحديد نوع الصنف (بيع/إرجاع/تالف/هدية)' : 'Movement Type'}">🏷️ ${isAR ? 'نوع' : 'Type'}</button>
              </div>
              <div class="pos-touch-numpad-grid" dir="ltr">
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('7')">7</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('8')">8</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('9')">9</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('4')">4</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('5')">5</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('6')">6</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('1')">1</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('2')">2</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('3')">3</button>
                <button type="button" class="pos-np-btn pos-np-clear" onclick="POS.touchNumpadInput('C')">C</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('0')">0</button>
                <button type="button" class="pos-np-btn" onclick="POS.touchNumpadInput('.')">.</button>
                <button type="button" class="pos-np-btn pos-np-backspace" onclick="POS.touchNumpadInput('DEL')" style="grid-column:1/-1" dir="${isAR ? 'rtl' : 'ltr'}">⌫ ${isAR ? 'تراجع' : 'Back'}</button>
              </div>
            </div>

            <!-- Draggable Vertical Resizer for Numpad Width (Left/Right) -->
            <div class="pos-numpad-v-resizer" id="pos-numpad-v-resizer" title="${isAR ? 'اسحب يميناً أو يساراً لتغيير عرض لوحة الأرقام' : 'Drag left/right to resize number panel'}"></div>

            <!-- RIGHT: Totals & Grand Total & Tender -->
            <div class="pos-cart-total-wrap">
              <!-- Dynamic Loyalty Points Banner (Visible when customer selected & loyalty enabled) -->
              <div id="pos-loyalty-bar" style="display:none;background:linear-gradient(135deg,rgba(139,92,246,0.15),rgba(168,85,247,0.08));border:1.5px solid rgba(168,85,247,0.35);border-radius:8px;padding:7px 10px;margin-bottom:8px;align-items:center;justify-content:space-between;gap:8px">
                <div style="font-size:0.8rem;display:flex;align-items:center;gap:6px;overflow:hidden">
                  <span style="font-size:1.15rem">⭐</span>
                  <div>
                    <div style="font-size:0.7rem;color:var(--text-muted);font-weight:700">${isAR ? 'رصيد نقاط العميل:' : 'Customer Points Balance:'}</div>
                    <div id="pos-customer-points-text" style="font-weight:900;color:#c084fc;font-size:0.84rem">0 pts</div>
                  </div>
                </div>
                <div style="display:flex;align-items:center;gap:6px">
                  <span id="pos-points-earned-preview" style="font-size:0.75rem;font-weight:800;color:#10b981;white-space:nowrap"></span>
                  <button type="button" class="btn btn-xs" onclick="POS.openRedeemPointsModal()" style="background:#8b5cf6;color:#fff;font-weight:800;border:none;padding:3px 8px;border-radius:6px;font-size:0.72rem;cursor:pointer">
                    🎁 ${isAR ? 'استبدال' : 'Redeem'}
                  </button>
                </div>
              </div>

              <div class="cockpit-totals-summary">
                <div class="cockpit-summary-row">
                  <span>${isAR ? 'المجموع' : 'Subtotal'}</span>
                  <span class="val" id="pos-subtotal">$0.00</span>
                </div>
                <div class="cockpit-summary-row" id="pos-vat-row" style="display:${_settings.vatEnabled ? 'flex' : 'none'}">
                  <span>${isAR ? `ضريبة (${_settings.vatRate}%)` : `VAT (${_settings.vatRate}%):`}</span>
                  <span class="val" id="pos-vat-amt">$0.00</span>
                </div>
                <div class="cockpit-summary-row" id="pos-promo-row" style="display:none;color:#ef4444;font-weight:700">
                  <span id="pos-promo-label">🔥 Promo</span>
                  <span class="val" id="pos-promo-amt">-$0.00</span>
                </div>
                <div class="cockpit-summary-row" id="pos-loyalty-redeemed-row" style="display:none;color:#ef4444;font-weight:700">
                  <span id="pos-loyalty-redeemed-label">⭐ Points</span>
                  <span class="val" id="pos-loyalty-redeemed-amt">-$0.00</span>
                </div>
              </div>

              <!-- GRAND TOTAL DUE BOX -->
              <div class="cockpit-grand-total-card">
                <div class="cockpit-grand-total-label">${isAR ? 'المستحق' : 'TOTAL DUE'}</div>
                <div class="cockpit-grand-total-amt" id="pos-total-1">$0.00</div>
                <div class="cockpit-grand-total-secondary" id="pos-total-2">0 L.L.</div>
              </div>

              <!-- Quick Pay Hotkey Actions Bar [F10 & F9] -->
              <div class="pos-fast-pay-grid">
                <button type="button" class="pos-fast-pay-btn btn-fast-pay-print" onclick="POS.quickCashPay(true)" title="${isAR ? 'دفع كاش فوري وطباعة مباشرة [F10]' : 'Quick Cash Pay & Print [F10]'}">
                  <span>⚡ ${isAR ? 'دفع وطباعة' : 'Pay & Print'}</span>
                  <span class="pos-kbd-badge">F10</span>
                </button>
                <button type="button" class="pos-fast-pay-btn btn-fast-pay-noprint" onclick="POS.quickCashPay(false)" title="${isAR ? 'دفع كاش فوري بدون طباعة [F9]' : 'Quick Cash Pay No Print [F9]'}">
                  <span>⚡ ${isAR ? 'بدون طباعة' : 'No Print'}</span>
                  <span class="pos-kbd-badge">F9</span>
                </button>
              </div>

              <!-- Big Crimson Detailed TENDER Button (F12) -->
              <button type="button" class="cockpit-tender-btn" onclick="POS.openPayment('cash')">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="20" height="20"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <span>${isAR ? '💳 دفع وحساب (F12)' : '💳 TENDER (F12)'}</span>
              </button>
            </div>
          </div>
      </div>
    </div>

    <!-- Payment Modal (Dual Currency Supported, Touch Cockpit Optimized, Generously Sized) -->
    <div class="modal-overlay" id="payment-modal">
      <div class="modal pos-payment-modal" style="max-width:1150px;width:96vw;height:92vh;max-height:94vh;display:flex;flex-direction:column">
        <div class="modal-header" style="flex-shrink:0;padding:14px 20px">
          <div class="modal-title" style="display:flex;align-items:center;gap:12px;font-size:1.15rem">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
            <span>${isAR ? 'إتمام الدفع وقفل الفاتورة' : 'Process Payment & Close Invoice'}</span>
            <span class="pos-inv-modal-badge" id="pay-modal-inv-badge" style="font-size:0.85rem">🧾 <span id="pay-modal-inv-num">INV-......</span></span>
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('payment-modal')" style="font-size:1.2rem">✕</button>
        </div>
        <div class="modal-body" style="flex:1;overflow-y:auto;padding:16px 20px">
          
          <div class="pos-pay-split-layout">
            <!-- LEFT COLUMN: Totals, Customer, Method, Tendered & Change -->
            <div class="pos-pay-col-info">
              <!-- Dual Currency Total Summary -->
              <div class="pos-pay-box" style="padding:14px 18px;text-align:center;margin-bottom:12px">
                <div style="font-size:0.85rem;color:var(--text-muted);margin-bottom:3px">${isAR ? 'الإجمالي المستحق (بالعملتين)' : 'Total Due (Dual Currency)'}</div>
                <div id="pay-total-display" style="font-size:2.8rem;font-weight:900;color:#38bdf8;line-height:1.1">$0.00</div>
                <div id="pay-total-2-display" style="font-size:1.4rem;font-weight:800;color:var(--warning);margin-top:4px">0 LBP</div>
                <div id="pay-exch-notice" style="font-size:0.75rem;color:var(--text-muted);margin-top:3px"></div>
              </div>

              <!-- Customer & Discount Combined Row -->
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
                <div id="pay-customer-badge" class="pos-pay-box" style="padding:8px 12px;font-size:0.85rem;display:flex;flex-direction:column;justify-content:center">
                  <span style="color:var(--text-muted);font-size:0.72rem">${isAR ? 'العميل المفوتر:' : 'Billed Customer:'}</span>
                  <span id="pay-customer-info" style="font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">👤 ${isAR ? 'عميل عابر' : 'Walk-in'}</span>
                </div>
                <div class="pos-pay-box" style="padding:8px 12px;display:flex;flex-direction:column;justify-content:center">
                  <span style="font-size:0.72rem;color:var(--text-muted);margin-bottom:2px">🏷️ ${isAR ? 'خصم الفاتورة:' : 'Invoice Discount:'}</span>
                  <div style="display:flex;align-items:center;gap:6px">
                    <input type="number" id="pay-discount-val" value="0" min="0" step="any" style="width:100%;padding:4px 8px;border-radius:6px;font-size:0.95rem;font-weight:800;text-align:center" onfocus="POS.setPayKeypadTarget('discount')" oninput="POS.syncModalDiscount()">
                    <select id="pay-discount-type" style="padding:4px 6px;border-radius:6px;font-size:0.88rem;font-weight:700" onchange="POS.syncModalDiscount()">
                      <option value="pct">%</option>
                      <option value="amt">${_settings.currency1}</option>
                    </select>
                  </div>
                </div>
              </div>

              <!-- Payment Method Selector Tabs -->
              <div id="payment-method-tabs" style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px">
                <button type="button" class="btn btn-success btn-sm" id="pm-cash" onclick="POS.selectPayMethod('cash',this)" style="padding:10px 4px;font-size:0.9rem;font-weight:800">💵 ${isAR?'نقداً':'Cash'}</button>
                <button type="button" class="btn btn-secondary btn-sm" id="pm-card" onclick="POS.selectPayMethod('card',this)" style="padding:10px 4px;font-size:0.9rem;font-weight:800">💳 ${isAR?'بطاقة':'Card'}</button>
                <button type="button" class="btn btn-secondary btn-sm" id="pm-credit" onclick="POS.selectPayMethod('credit',this)" style="padding:10px 4px;font-size:0.9rem;font-weight:800">👤 ${isAR?'آجل':'Credit'}</button>
                <button type="button" class="btn btn-secondary btn-sm" id="pm-mixed" onclick="POS.selectPayMethod('mixed',this)" style="padding:10px 4px;font-size:0.9rem;font-weight:800">🔀 ${isAR?'مختلط':'Mixed'}</button>
              </div>

              <!-- Cash payment fields (Dual Currency Tendered) -->
              <div id="pay-cash-section">
                <div class="grid grid-2" style="gap:10px;margin-bottom:10px">
                  <div class="form-group" style="margin:0">
                    <label class="form-label" id="lbl-tendered-1" style="font-size:0.8rem;margin-bottom:4px;font-weight:700">${isAR ? 'المبلغ المستلم' : 'Tendered'} (${_settings.currency1})</label>
                    <input type="number" class="form-control" id="pay-tendered" style="font-size:1.35rem;font-weight:900;text-align:center;padding:8px;height:52px" placeholder="0.00" step="0.01" onfocus="POS.setPayKeypadTarget('tendered1')" oninput="POS.calcChange('c1')" onkeydown="if(event.key==='Enter') POS.processPayment(true)">
                  </div>
                  <div class="form-group" style="margin:0">
                    <label class="form-label" id="lbl-tendered-2" style="font-size:0.8rem;margin-bottom:4px;font-weight:700">${isAR ? 'أو بالنقد' : 'Or Tendered'} (${_settings.currency2})</label>
                    <input type="number" class="form-control" id="pay-tendered-2" style="font-size:1.35rem;font-weight:900;text-align:center;color:var(--warning);padding:8px;height:52px" placeholder="0" step="500" onfocus="POS.setPayKeypadTarget('tendered2')" oninput="POS.calcChange('c2')" onkeydown="if(event.key==='Enter') POS.processPayment(true)">
                  </div>
                </div>

                <!-- Dual Currency Change & Credit Breakdown Display -->
                <div class="pos-pay-box" style="padding:10px 14px;margin-bottom:10px">
                  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
                    <span id="lbl-change-1" style="color:var(--text-secondary);font-size:0.9rem;font-weight:700">${isAR ? 'الباقي' : 'Change'} (${_settings.currency1})</span>
                    <span id="pay-change" style="font-size:1.45rem;font-weight:900;color:var(--success)">$0.00</span>
                  </div>
                  <div style="display:flex;justify-content:space-between;align-items:center" id="pay-change-2-row">
                    <span id="lbl-change-2" style="color:var(--text-secondary);font-size:0.9rem;font-weight:700">${isAR ? 'الباقي بـ' : 'Change in'} ${_settings.currency2}</span>
                    <span id="pay-change-2" style="font-size:1.2rem;font-weight:800;color:var(--warning)">0 ${_settings.currency2}</span>
                  </div>

                  <!-- Live Credit Breakdown Summary -->
                  <div id="pay-credit-summary" style="display:none;margin-top:8px;padding-top:8px;border-top:1px dashed var(--border-color);font-size:0.85rem">
                    <div style="display:flex;justify-content:space-between;margin-bottom:3px">
                      <span style="color:var(--text-secondary)">${isAR ? 'المدفوع نقداً:' : 'Paid Down:'}</span>
                      <span id="pay-credit-downpayment" style="font-weight:800;color:var(--success)">$0.00</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;margin-bottom:3px">
                      <span style="color:var(--text-secondary)">${isAR ? 'المبلغ الآجل (الدين):' : 'Debt Added:'}</span>
                      <span id="pay-credit-remaining" style="font-weight:900;color:var(--danger)">$0.00</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;margin-top:4px;padding-top:4px;border-top:1px dashed var(--border-color)">
                      <span style="color:var(--text-primary);font-weight:700">${isAR ? 'دين العميل الجديد:' : 'Total Debt:'}</span>
                      <span id="pay-credit-new-balance" style="font-weight:900;color:#dc2626">$0.00</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Mixed payment section -->
              <div id="pay-mixed-section" style="display:none">
                <div class="form-group" style="margin-bottom:8px">
                  <label class="form-label" style="font-size:0.8rem">${isAR ? 'نقداً' : 'Cash Amount'} (${_settings.currency1})</label>
                  <input type="number" class="form-control" id="pay-cash-amt" placeholder="0.00" oninput="POS.calcMixed()">
                </div>
                <div class="form-group" style="margin-bottom:8px">
                  <label class="form-label" style="font-size:0.8rem">${isAR ? 'بطاقة' : 'Card Amount'} (${_settings.currency1})</label>
                  <input type="number" class="form-control" id="pay-card-amt" placeholder="0.00" oninput="POS.calcMixed()">
                </div>
                <div style="display:flex;justify-content:space-between;font-size:0.85rem">
                  <span style="color:var(--text-secondary)">${isAR ? 'المتبقي' : 'Remaining'}</span>
                  <span id="pay-mixed-remain" style="font-weight:800;color:var(--danger)">$0.00</span>
                </div>
              </div>
            </div>

            <!-- RIGHT COLUMN: Touch Keypad & Presets & Notes -->
            <div class="pos-pay-col-keypad">
              <div class="pay-touch-keypad" id="pay-touch-keypad" style="margin:0;padding:12px">
                <div class="pay-numpad-target-row" style="margin-bottom:8px">
                  <button type="button" class="pay-target-tab active" id="pay-tab-tendered1" onclick="POS.setPayKeypadTarget('tendered1')" style="font-size:0.88rem;padding:8px 12px">
                    💵 ${_settings.currency1} ${isAR ? 'المستلم' : 'Tendered'}
                  </button>
                  <button type="button" class="pay-target-tab" id="pay-tab-tendered2" onclick="POS.setPayKeypadTarget('tendered2')" style="font-size:0.88rem;padding:8px 12px">
                    💵 ${_settings.currency2} ${isAR ? 'المستلم' : 'Tendered'}
                  </button>
                  <button type="button" class="pay-target-tab" id="pay-tab-discount" onclick="POS.setPayKeypadTarget('discount')" style="font-size:0.88rem;padding:8px 12px">
                    🏷️ ${isAR ? 'الخصم' : 'Discount'}
                  </button>
                </div>

                <!-- Quick Presets -->
                <div class="pay-quick-presets" style="margin-bottom:10px;gap:6px">
                  <button type="button" class="pay-preset-btn btn-exact" onclick="POS.onPayKeypadPress('exact')" style="font-size:0.95rem;padding:8px 12px;font-weight:900">
                    ⚡ ${isAR ? 'كاش تام (Exact)' : 'Exact Cash'}
                  </button>
                  <button type="button" class="pay-preset-btn" onclick="POS.onPayKeypadPress('+5')">+5</button>
                  <button type="button" class="pay-preset-btn" onclick="POS.onPayKeypadPress('+10')">+10</button>
                  <button type="button" class="pay-preset-btn" onclick="POS.onPayKeypadPress('+20')">+20</button>
                  <button type="button" class="pay-preset-btn" onclick="POS.onPayKeypadPress('+50')">+50</button>
                  <button type="button" class="pay-preset-btn" onclick="POS.onPayKeypadPress('+100')">+100</button>
                </div>

                <!-- Touch Numeric Grid -->
                <div class="pay-keypad-grid" style="gap:6px">
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('7')">7</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('8')">8</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('9')">9</button>
                  <button type="button" class="pay-key-btn btn-fn-add" onclick="POS.onPayKeypadPress('+10')">+10</button>

                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('4')">4</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('5')">5</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('6')">6</button>
                  <button type="button" class="pay-key-btn btn-fn-add" onclick="POS.onPayKeypadPress('+20')">+20</button>

                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('1')">1</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('2')">2</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('3')">3</button>
                  <button type="button" class="pay-key-btn btn-fn-add" onclick="POS.onPayKeypadPress('+50')">+50</button>

                  <button type="button" class="pay-key-btn btn-fn-clear" onclick="POS.onPayKeypadPress('clear')">C</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('0')">0</button>
                  <button type="button" class="pay-key-btn" onclick="POS.onPayKeypadPress('.')">.</button>
                  <button type="button" class="pay-key-btn btn-fn-backspace" onclick="POS.onPayKeypadPress('backspace')">⌫</button>
                </div>
              </div>

              <!-- Notes Field -->
              <div class="form-group" style="margin-top:10px;margin-bottom:0">
                <input type="text" class="form-control" id="pay-notes" placeholder="${isAR ? 'ملاحظات اختيارية على الفاتورة...' : 'Optional invoice notes...'}" style="padding:8px 12px;font-size:0.85rem">
              </div>
            </div>
          </div>

        </div>
        <div class="modal-footer" style="display:flex;justify-content:space-between;align-items:center;gap:12px;padding:12px 20px;position:sticky;bottom:0;z-index:20">
          <button class="btn btn-ghost" onclick="Utils.closeModal('payment-modal')" style="font-weight:700;font-size:0.95rem">${isAR ? 'إلغاء [Esc]' : 'Cancel [Esc]'}</button>
          
          <div style="display:flex;gap:12px;align-items:center">
            <!-- 1. Confirm Payment without printing [F9] -->
            <button class="btn btn-secondary btn-lg" onclick="POS.processPayment(false)" id="btn-pay-confirm-no-print" style="font-weight:800;display:flex;align-items:center;gap:10px;padding:12px 22px;font-size:1.02rem">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
              <span>${isAR ? 'إتمام الدفع (بدون طباعة)' : 'Confirm (No Print)'}</span>
              <span class="badge" style="background:rgba(255,255,255,0.2);color:inherit;font-size:0.75rem;padding:2px 6px">F9</span>
            </button>

            <!-- 2. Confirm Payment and Print Invoice [F10] -->
            <button class="btn btn-success btn-lg" onclick="POS.processPayment(true)" id="btn-pay-confirm-print" style="font-weight:900;display:flex;align-items:center;gap:10px;padding:12px 26px;font-size:1.05rem;box-shadow:0 4px 16px rgba(16,185,129,0.4)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              <span>${isAR ? 'إتمام الدفع وطباعة الفاتورة' : 'Confirm & Print Invoice'}</span>
              <span class="badge" style="background:rgba(255,255,255,0.25);color:white;font-size:0.75rem;padding:2px 6px">F10</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Receipt Modal -->
    <div class="modal-overlay" id="receipt-modal">
      <div class="modal" style="max-width:380px">
        <div class="modal-header">
          <div class="modal-title">📄 ${isAR ? 'معاينة الفاتورة' : 'Invoice Preview'}</div>
          <button class="btn-icon" onclick="POS.newSale()">✕</button>
        </div>
        <div class="modal-body" id="receipt-preview" style="background:white;color:#000;font-family:'Courier New',monospace;padding:16px;border-radius:8px;font-size:0.78rem;line-height:1.5">
        </div>
        <div style="display:flex;justify-content:space-between;gap:6px;margin:8px 16px 0;border-top:1px solid var(--border-color);padding-top:10px">
          <button class="btn btn-secondary btn-sm flex-1" onclick="POS.navigateHistory(-1)" style="font-size:0.75rem;padding:6px">◀ ${isAR ? 'السابق' : 'Older'}</button>
          <button class="btn btn-primary btn-sm flex-1" onclick="POS.newSale()" style="font-size:0.75rem;padding:6px">➕ ${isAR ? 'جديد' : 'New'}</button>
          <button class="btn btn-secondary btn-sm flex-1" onclick="POS.navigateHistory(1)" style="font-size:0.75rem;padding:6px">${isAR ? 'التالي' : 'Newer'} ▶</button>
        </div>
        <div class="modal-footer" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;justify-content:space-between">
          <button class="btn btn-ghost btn-sm" onclick="POS.newSale()">${isAR ? 'بيع جديد' : 'New Sale'}</button>
          <div style="display:flex;gap:6px;align-items:center">
            <button class="btn btn-warning btn-sm" onclick="POS.loadBrowsedSaleToCart()" style="font-weight:700">
              🛒 ${isAR ? 'تحميل في السلة' : 'Load in Cart'}
            </button>
            <button class="btn btn-secondary btn-sm" onclick="POS.printReceipt()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'طباعة' : 'Print'} (80mm)
            </button>
            <button class="btn btn-primary btn-sm" onclick="POS.printA4()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/></svg>
              ${isAR ? 'فاتورة A4' : 'A4 Invoice'}
            </button>
          </div>
        </div>
      </div>
    </div>`;

    // Populate customer dropdown & initialize default POS warehouse
    await loadCustomerDropdown(isAR);
    await initPosWarehouse();

    // Quick amount buttons
    buildQuickAmounts();

    // Focus search
    setTimeout(() => {
      const s = document.getElementById('pos-search');
      if (s) s.focus();
    }, 200);

    // Initialize draggable cart panel resizers
    initCartResizer();
    initBottomResizer();
    initNumpadResizer();

    // Start live system date & time clock
    _startClock();

    // Load & display upcoming invoice number in POS header and cart
    await updatePosInvoiceDisplay();

    // Initialize touch numpad visibility from user setting (default visible on touch/tablet)
    const savedNumpadState = localStorage.getItem('pos_show_touch_numpad');
    const shouldShowNumpad = savedNumpadState !== null ? savedNumpadState === 'true' : (window.innerWidth >= 900);
    toggleTouchNumpad(shouldShowNumpad);

    // Initial numpad header
    _updateNumpadHeader();

    // Load and update held sales UI
    _loadHeldFromStorage();
    updateHeldUI();

    // Setup Cockpit keyboard shortcuts: '/' for Search, F12 for Tender, F8 for Hold, F4 for Discount, F3 for Customer, F10 for Pay&Print, F9 for Pay No Print
    _setupCockpitShortcuts();

    // Ensure dollar rate display is fresh and synced
    if (window.App && typeof window.App.updateDollarRateDisplay === 'function') {
      window.App.updateDollarRateDisplay();
    }
  }

  // ── Keyboard Shortcuts for POS Cockpit ──
  let _shortcutsAttached = false;
  function _setupCockpitShortcuts() {
    if (_shortcutsAttached) return;
    _shortcutsAttached = true;
    window.addEventListener('keydown', (e) => {
      if (!document.body.classList.contains('pos-cockpit-mode')) return;
      const targetTag = (e.target && e.target.tagName ? e.target.tagName : '').toLowerCase();
      const isInput = targetTag === 'input' || targetTag === 'textarea' || targetTag === 'select';
      const payModal = document.getElementById('payment-modal');
      const isPayModalOpen = payModal && (payModal.classList.contains('open') || payModal.style.display === 'flex' || payModal.style.display === 'block');

      // F10 or Ctrl+Enter: Pay & Print (Quick cash pay directly or confirm modal)
      if (e.key === 'F10' || (e.ctrlKey && e.key === 'Enter')) {
        e.preventDefault();
        if (isPayModalOpen) {
          processPayment(true);
        } else {
          quickCashPay(true);
        }
        return;
      }

      // F9 or Shift+Enter: Pay WITHOUT Print (Quick cash pay directly or confirm modal)
      if (e.key === 'F9' || (e.shiftKey && e.key === 'Enter')) {
        e.preventDefault();
        if (isPayModalOpen) {
          processPayment(false);
        } else {
          quickCashPay(false);
        }
        return;
      }

      // If Payment modal is open, Enter triggers confirm and print, Escape closes
      if (isPayModalOpen) {
        if (e.key === 'Escape') {
          e.preventDefault();
          Utils.closeModal('payment-modal');
          return;
        }
        if (e.key === 'Enter' && targetTag !== 'textarea') {
          e.preventDefault();
          processPayment(true);
          return;
        }
        return;
      }

      // Pressing '/' focuses search input
      if (e.key === '/' && !isInput) {
        e.preventDefault();
        const searchEl = document.getElementById('pos-search');
        if (searchEl) {
          searchEl.focus();
          searchEl.select();
        }
        return;
      }

      // F2: New Invoice
      if (e.key === 'F2') {
        e.preventDefault();
        newSale();
        return;
      }

      // F12: Tender & Pay
      if (e.key === 'F12') {
        e.preventDefault();
        openPayment('cash');
        return;
      }

      // F8: Hold cart
      if (e.key === 'F8') {
        e.preventDefault();
        holdSale();
        return;
      }

      // F4: Discount modal
      if (e.key === 'F4') {
        e.preventDefault();
        openDiscountModal();
        return;
      }

      // F3: Toggle customer dropdown
      if (e.key === 'F3') {
        e.preventDefault();
        toggleCustomerDropdown(e);
        return;
      }
    });
  }

  // ── Live Date & Digital Clock Timer (Strictly English Locale) ──
  function _startClock() {
    if (_clockInterval) {
      clearInterval(_clockInterval);
      _clockInterval = null;
    }
    const update = () => {
      const timeEl = document.getElementById('pos-live-time');
      const dateEl = document.getElementById('pos-live-date');
      const topTimeEl = document.getElementById('topbar-live-time');
      const topDateEl = document.getElementById('topbar-live-date');
      if (!timeEl && !dateEl && !topTimeEl && !topDateEl) {
        clearInterval(_clockInterval);
        _clockInterval = null;
        return;
      }
      const now = new Date();

      // Explicitly enforce English formatting (en-US / en-GB) regardless of current UI language
      const timeStr = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      });

      const dateStr = now.toLocaleDateString('en-GB', {
        weekday: 'short',
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      });

      if (timeEl) timeEl.textContent = timeStr;
      if (dateEl) dateEl.textContent = dateStr;
      if (topTimeEl) topTimeEl.textContent = timeStr;
      if (topDateEl) topDateEl.textContent = dateStr;
    };
    update();
    _clockInterval = setInterval(update, 1000);
  }

  // ── Multi-Branch / Multi-POS Unique Invoice Prefix ──
  function _getInvoicePrefix() {
    const custom = localStorage.getItem('pos_invoice_prefix') || window._customInvPrefix;
    if (custom) return custom.endsWith('-') ? custom : (custom + '-');
    const branch = localStorage.getItem('sync_branch_id');
    const node = localStorage.getItem('sync_node_id') || localStorage.getItem('redshark_pos_terminal');
    if (branch && branch !== 'main' && branch !== 'default') {
      const cleanBranch = branch.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
      return `${cleanBranch}-INV-`;
    }
    if (node && node !== 'server' && node !== 'POS-1') {
      const cleanNode = node.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
      return `${cleanNode}-INV-`;
    }
    return 'INV-';
  }

  // ── Load & Display Upcoming Invoice Number ──
  async function updatePosInvoiceDisplay() {
    try {
      const prefix = _getInvoicePrefix();
      if (window.DB && typeof DB.peekSeq === 'function') {
        _currentInvoiceNumber = await DB.peekSeq('sales', prefix, 6);
      } else {
        _currentInvoiceNumber = prefix + '000001';
      }
      const invEl = document.getElementById('pos-current-inv-num');
      if (invEl) invEl.textContent = _currentInvoiceNumber;

      const cartInvEl = document.getElementById('pos-cart-inv-badge');
      if (cartInvEl) cartInvEl.textContent = `#${_currentInvoiceNumber}`;

      const modalInvEl = document.getElementById('pay-modal-inv-num');
      if (modalInvEl) modalInvEl.textContent = _currentInvoiceNumber;
    } catch(e) {
      console.warn('Failed to update POS invoice display:', e);
    }
  }

  // ── Fullscreen Toggle for Touch/Kiosk Terminals ──
  function toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
        const icon = document.getElementById('pos-fs-icon');
        if (icon) icon.textContent = '🗗';
      } else {
        if (document.exitFullscreen) document.exitFullscreen().catch(() => {});
        const icon = document.getElementById('pos-fs-icon');
        if (icon) icon.textContent = '⛶';
      }
    } catch(e) {}
  }

  // ── Touch Screen Numpad Logic for Cart Panel ──
  function selectCartItemForNumpad(idx, mode = null) {
    if (idx >= 0 && idx < _cart.length) {
      _posSelectedCartIndex = idx;
    } else {
      _posSelectedCartIndex = -1;
    }
    if (mode) {
      _posNumpadTarget = mode;
    }
    _posNumpadBuffer = '';
    _posNumpadReplaceMode = true;
    _updateNumpadHeader();
    _highlightSelectedCartRow();
    _scrollSelectedCartRowIntoView();
  }

  function _updateNumpadHeader() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const textEl = document.getElementById('pos-numpad-target-text');
    if (!textEl) return;

    ['qty', 'disc', 'price', 'type', 'search'].forEach(m => {
      const btn = document.getElementById(`np-mode-${m}`);
      if (btn) {
        if (m === _posNumpadTarget) btn.classList.add('active');
        else btn.classList.remove('active');
      }
    });

    if (_posNumpadTarget === 'search') {
      textEl.textContent = isAR ? '🔍 بحث الباركود / الصنف' : '🔍 Barcode / Item Search';
      return;
    }

    if (_posSelectedCartIndex >= 0 && _posSelectedCartIndex < _cart.length) {
      const item = _cart[_posSelectedCartIndex];
      const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
      const shortName = Utils.truncate(itemName, 14);
      if (_posNumpadTarget === 'qty') {
        textEl.textContent = `${isAR ? 'كمية' : 'Qty'}: ${shortName} (${item.qty})`;
      } else if (_posNumpadTarget === 'disc') {
        const discVal = item.disc_type === 'amt' ? `${_settings.currency1}${item.disc_amt||0}` : `${item.disc_pct||0}%`;
        textEl.textContent = `${isAR ? 'خصم' : 'Disc'}: ${shortName} (${discVal})`;
      } else if (_posNumpadTarget === 'price') {
        textEl.textContent = `${isAR ? 'سعر' : 'Price'}: ${shortName} (${Utils.formatCurrency(item.price || 0)})`;
      }
    } else {
      if (_posNumpadTarget === 'qty') {
        textEl.textContent = isAR ? 'الكمية (اختر صنفاً)' : 'Quantity (Select item)';
      } else if (_posNumpadTarget === 'disc') {
        textEl.textContent = isAR ? 'الخصم (اختر صنفاً)' : 'Discount (Select item)';
      } else if (_posNumpadTarget === 'price') {
        textEl.textContent = isAR ? 'السعر (اختر صنفاً)' : 'Price (Select item)';
      }
    }
  }

  function _highlightSelectedCartRow() {
    document.querySelectorAll('.pos-cart-item-selected').forEach(el => el.classList.remove('pos-cart-item-selected'));
    if (_posSelectedCartIndex < 0) return;

    const trs = document.querySelectorAll('.pos-cart-table tbody tr');
    if (trs && trs[_posSelectedCartIndex]) {
      const row = trs[_posSelectedCartIndex];
      row.classList.add('pos-cart-item-selected');
    }
    const cards = document.querySelectorAll('#pos-cart-items > div:not(#cart-empty)');
    if (cards && cards[_posSelectedCartIndex]) {
      const card = cards[_posSelectedCartIndex];
      card.classList.add('pos-cart-item-selected');
    }
  }

  function _scrollSelectedCartRowIntoView() {
    const selTr = document.querySelector('.pos-cart-table tbody tr.pos-cart-item-selected')
               || document.querySelector('#pos-cart-items > div.pos-cart-item-selected')
               || document.querySelector('.pos-cart-table tbody tr:last-child')
               || document.querySelector('#pos-cart-items > div:last-child:not(#cart-empty)');
    if (selTr) {
      try {
        selTr.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } catch(e) {
        selTr.scrollIntoView(false);
      }
      selTr.classList.remove('pos-row-flash');
      void selTr.offsetWidth;
      selTr.classList.add('pos-row-flash');
    }
    const scrollParents = [
      document.querySelector('.pos-cart-table-wrap'),
      document.getElementById('pos-cart-items'),
      document.querySelector('.cockpit-cart-items-wrap')
    ];
    scrollParents.forEach(el => {
      if (el && el.scrollHeight > el.clientHeight) {
        el.scrollTop = el.scrollHeight;
      }
    });
  }

  async function setNumpadMode(mode) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (mode === 'type') {
      if (_posSelectedCartIndex >= 0 && _cart[_posSelectedCartIndex]) {
        openLineTypeModal(_posSelectedCartIndex);
      } else if (_cart.length > 0) {
        _posSelectedCartIndex = _cart.length - 1;
        _highlightSelectedCartRow();
        openLineTypeModal(_posSelectedCartIndex);
      } else {
        Utils.toast(isAR ? '⚠️ أضف صنفاً إلى السلة أولاً لتحديد نوعه' : '⚠️ Add an item to cart first to select its type', 'warning');
      }
      return;
    }
    if (mode === 'price') {
      const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items') || Auth.can('pos.edit_price')));
      if (!isAdmin) {
        const authorized = await promptAdminAuthModal(isAR ? 'تعديل السعر يتطلب تصريح المشرف' : 'Price editing requires admin authorization');
        if (!authorized) return;
      }
    }
    _posNumpadTarget = mode;
    _posNumpadBuffer = '';
    _posNumpadReplaceMode = true;
    _updateNumpadHeader();
  }

  function setNumpadTargetMode(mode) {
    return setNumpadMode(mode);
  }

  async function touchNumpadInput(char) {
    if (char === 'C') {
      await onNumpadKeyPress('clear');
    } else if (char === 'DEL') {
      await onNumpadKeyPress('backspace');
    } else {
      await onNumpadKeyPress(char);
    }
  }

  function toggleTouchNumpad(force) {
    const panel = document.getElementById('pos-cart-numpad');
    const headerBtn = document.getElementById('pos-touch-numpad-toggle-btn');
    const cartBtn = document.getElementById('pos-cart-numpad-toggle-btn');
    if (!panel) return;

    const willCollapse = (force !== undefined) ? !force : !panel.classList.contains('collapsed');
    if (willCollapse) {
      panel.classList.add('collapsed');
      if (headerBtn) headerBtn.classList.remove('active');
      if (cartBtn) cartBtn.classList.remove('active');
      localStorage.setItem('pos_show_touch_numpad', 'false');
    } else {
      panel.classList.remove('collapsed');
      if (headerBtn) headerBtn.classList.add('active');
      if (cartBtn) cartBtn.classList.add('active');
      localStorage.setItem('pos_show_touch_numpad', 'true');
      _updateNumpadHeader();
      _highlightSelectedCartRow();
    }
  }

  async function onNumpadKeyPress(key) {
    try {
      if (window.AICopilot && typeof AICopilot.playAudio === 'function') {
        AICopilot.playAudio('click');
      }
    } catch(e) {}

    if (_posNumpadTarget === 'search') {
      const searchInput = document.getElementById('pos-search');
      if (!searchInput) return;
      if (key === 'clear') {
        searchInput.value = '';
        _posNumpadBuffer = '';
        filterItems('');
      } else if (key === 'backspace') {
        searchInput.value = searchInput.value.slice(0, -1);
        _posNumpadBuffer = searchInput.value;
        filterItems(searchInput.value);
      } else if (key === 'enter') {
        if (searchInput.value.trim()) {
          const val = searchInput.value.trim();
          searchInput.value = '';
          _posNumpadBuffer = '';
          await handleBarcodeScan(val);
        }
      } else {
        searchInput.value += key;
        _posNumpadBuffer = searchInput.value;
        filterItems(searchInput.value);
      }
      return;
    }

    if (_posSelectedCartIndex < 0 || _posSelectedCartIndex >= _cart.length) {
      if (_cart.length > 0) {
        _posSelectedCartIndex = _cart.length - 1;
      } else {
        Utils.toast((window.i18n && typeof i18n.getLang === 'function' && i18n.getLang() === 'ar') ? 'السلة فارغة، أضف صنفاً أولاً' : 'Cart is empty, add an item first', 'warning');
        return;
      }
    }

    const item = _cart[_posSelectedCartIndex];
    if (!item) return;

    if (key === '+1') {
      updateQty(_posSelectedCartIndex, 1);
      _posNumpadBuffer = '';
      _updateNumpadHeader();
      return;
    }

    if (key === '-1') {
      updateQty(_posSelectedCartIndex, -1);
      _posNumpadBuffer = '';
      _updateNumpadHeader();
      return;
    }

    if (key === 'clear') {
      _posNumpadBuffer = '';
      _posNumpadReplaceMode = true;
      if (_posNumpadTarget === 'qty') {
        setQty(_posSelectedCartIndex, 1);
      } else if (_posNumpadTarget === 'disc') {
        updateItemDisc(_posSelectedCartIndex, 0);
      } else if (_posNumpadTarget === 'price') {
        const origPrice = _cart[_posSelectedCartIndex].original_price || _cart[_posSelectedCartIndex].price || 0;
        _cart[_posSelectedCartIndex].price = origPrice;
        _cart[_posSelectedCartIndex].total = Utils.round((_cart[_posSelectedCartIndex].qty || 1) * origPrice - (_cart[_posSelectedCartIndex].disc_amt || 0));
        renderCart(); updateTotals();
      }
      _updateNumpadHeader();
      return;
    }

    if (key === 'backspace') {
      _posNumpadBuffer = _posNumpadBuffer.slice(0, -1);
      _posNumpadReplaceMode = false;
      const val = parseFloat(_posNumpadBuffer) || 0;
      if (_posNumpadTarget === 'qty') {
        setQty(_posSelectedCartIndex, Math.max(0.001, val || 1));
      } else if (_posNumpadTarget === 'disc') {
        updateItemDisc(_posSelectedCartIndex, val);
      } else if (_posNumpadTarget === 'price') {
        _cart[_posSelectedCartIndex].price = val;
        _cart[_posSelectedCartIndex].total = Utils.round((_cart[_posSelectedCartIndex].qty || 1) * val - (_cart[_posSelectedCartIndex].disc_amt || 0));
        renderCart(); updateTotals();
      }
      _updateNumpadHeader();
      return;
    }

    if (key === 'enter') {
      _posNumpadBuffer = '';
      _posNumpadReplaceMode = true;
      _updateNumpadHeader();
      return;
    }

    if (key === '.' && !_posNumpadReplaceMode && _posNumpadBuffer.includes('.')) return;

    if (_posNumpadReplaceMode) {
      _posNumpadReplaceMode = false;
      if (key === '.') {
        _posNumpadBuffer = '0.';
      } else {
        _posNumpadBuffer = String(key);
      }
    } else {
      _posNumpadBuffer += key;
    }

    const newVal = parseFloat(_posNumpadBuffer);
    if (!isNaN(newVal)) {
      if (_posNumpadTarget === 'qty') {
        setQty(_posSelectedCartIndex, newVal);
      } else if (_posNumpadTarget === 'disc') {
        updateItemDisc(_posSelectedCartIndex, newVal);
      } else if (_posNumpadTarget === 'price') {
        _cart[_posSelectedCartIndex].price = newVal;
        _cart[_posSelectedCartIndex].total = Utils.round((_cart[_posSelectedCartIndex].qty || 1) * newVal - (_cart[_posSelectedCartIndex].disc_amt || 0));
        renderCart(); updateTotals();
      }
    }
    _updateNumpadHeader();
  }

  // ── Touch Screen Keypad for Closing Invoice (Payment Modal) ──
  function setPayKeypadTarget(target) {
    _payKeypadTarget = target;
    _payKeypadBuffer = '';
    ['tendered1', 'tendered2', 'discount'].forEach(t => {
      const tab = document.getElementById(`pay-tab-${t}`);
      if (tab) {
        if (t === target) tab.classList.add('active');
        else tab.classList.remove('active');
      }
    });

    const el = _getPayTargetElement();
    if (el) el.focus();
  }

  function _getPayTargetElement() {
    if (_payKeypadTarget === 'tendered2') return document.getElementById('pay-tendered-2');
    if (_payKeypadTarget === 'discount') return document.getElementById('pay-discount-val');
    return document.getElementById('pay-tendered');
  }

  function onPayKeypadPress(key) {
    const el = _getPayTargetElement();
    if (!el) return;

    try {
      if (window.AICopilot && typeof AICopilot.playAudio === 'function') {
        AICopilot.playAudio('click');
      }
    } catch(e) {}

    const totalC1 = window._posGrandTotal || 0;
    const totalC2 = window._posTotal2 || _calcSecondaryPrice(totalC1);

    if (key === 'exact') {
      if (_payKeypadTarget === 'tendered2') {
        el.value = totalC2;
        calcChange('c2');
      } else if (_payKeypadTarget === 'discount') {
        el.value = 0;
        syncModalDiscount();
      } else {
        el.value = totalC1;
        calcChange('c1');
      }
      _payKeypadBuffer = '';
      return;
    }

    if (key.startsWith('+')) {
      const addVal = parseFloat(key.slice(1)) || 0;
      const currentVal = parseFloat(el.value) || 0;
      el.value = Utils.round(currentVal + addVal);
      _payKeypadBuffer = String(el.value);
      _triggerPayTargetChange();
      return;
    }

    if (key === 'clear') {
      el.value = '0';
      _payKeypadBuffer = '';
      _triggerPayTargetChange();
      return;
    }

    if (key === 'backspace') {
      let str = String(el.value || '');
      str = str.slice(0, -1);
      el.value = str === '' ? '0' : str;
      _payKeypadBuffer = el.value;
      _triggerPayTargetChange();
      return;
    }

    if (key === '.' && String(el.value).includes('.')) return;

    let curStr = _payKeypadBuffer;
    if (curStr === '' || curStr === '0') {
      curStr = (key === '.') ? '0.' : key;
    } else {
      curStr += key;
    }
    _payKeypadBuffer = curStr;
    el.value = curStr;
    _triggerPayTargetChange();
  }

  function _triggerPayTargetChange() {
    if (_payKeypadTarget === 'tendered2') {
      calcChange('c2');
    } else if (_payKeypadTarget === 'discount') {
      syncModalDiscount();
    } else {
      calcChange('c1');
    }
  }

  function _isUncategorizedItem(item, cats) {
    if (!item) return false;
    const cid = (item.category_id !== null && item.category_id !== undefined && item.category_id !== '') ? String(item.category_id).trim() : '';
    const cname = (item.category || '').toLowerCase().trim();
    if (!cid && !cname) return true;
    if (cname === 'no category' || cname === 'uncategorized' || cname === 'بدون تصنيف' || cname === 'بدون فئة' || cname === 'none') return true;

    if (cats && cats.length) {
      const match = cats.some(c => {
        if (cid && String(c.id) === cid) return true;
        if (cname) {
          const n1 = (c.name || '').toLowerCase().trim();
          const n2 = (c.name_en || '').toLowerCase().trim();
          const n3 = (c.name_ar || '').toLowerCase().trim();
          if (n1 && n1 === cname) return true;
          if (n2 && n2 === cname) return true;
          if (n3 && n3 === cname) return true;
        }
        return false;
      });
      return !match;
    }
    return true;
  }

  // ── Render Category Cards Tiles ──
  function renderCategoryCards(cats, isAR) {
    const catList = cats || [];
    const uncategorizedItems = (_items || []).filter(i => _isUncategorizedItem(i, catList));

    if (!catList.length && !uncategorizedItems.length) {
      return `<div class="empty-state" style="grid-column:1/-1">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px;height:40px;margin-bottom:8px"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
        <p>${isAR ? 'لا توجد تصنيفات' : 'No categories found'}</p>
      </div>`;
    }

    let cardsHtml = catList.map(cat => {
      const name = isAR ? (cat.name_ar || cat.name || cat.name_en) : (cat.name_en || cat.name || cat.name_ar);
      const catItemsCount = (_items || []).filter(i => String(i.category_id) === String(cat.id) || (i.category && (i.category === cat.name || i.category === cat.name_en || i.category === cat.name_ar))).length;

      return `
      <div class="pos-cat-card" onclick="POS.filterByCategory('${cat.id}')">
        <div class="cat-thumb-box">
          ${cat.image
            ? `<img src="${cat.image}" class="cat-thumb-img" alt="${Utils.sanitize(name)}" style="max-width:100%;max-height:100%;width:auto;height:auto;object-fit:contain;border-radius:8px">`
            : `<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.8"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>`}
        </div>
        <div style="font-size:0.92rem;font-weight:800;line-height:1.25;color:var(--pos-text-main);margin-bottom:4px">${Utils.sanitize(name)}</div>
        <div style="font-size:0.75rem;color:var(--pos-text-muted);font-weight:600">${catItemsCount} ${isAR ? 'صنف' : 'items'}</div>
      </div>`;
    }).join('');

    // If there are uncategorized items (e.g. from Excel imports or without an assigned category)
    if (uncategorizedItems.length > 0) {
      const noCatTitle = isAR ? 'بدون تصنيف' : 'No Category';
      cardsHtml += `
      <div class="pos-cat-card pos-no-cat-card" onclick="POS.filterByCategory('no-category')">
        <div class="cat-thumb-box" style="background:rgba(239, 68, 68, 0.08);border:1.5px dashed rgba(239, 68, 68, 0.4)">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="1.8">
            <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
            <line x1="9" y1="14" x2="15" y2="14"/>
          </svg>
        </div>
        <div style="font-size:0.92rem;font-weight:800;line-height:1.25;color:var(--pos-text-main);margin-bottom:4px">🏷️ ${noCatTitle}</div>
        <div style="font-size:0.75rem;color:var(--danger);font-weight:700">${uncategorizedItems.length.toLocaleString()} ${isAR ? 'صنف' : 'items'}</div>
      </div>`;
    }

    return cardsHtml;
  }

  function _fmtCur(amt, curCode) {
    const isLocalLbp = Utils.isLbp ? Utils.isLbp(curCode) : (curCode === 'LBP' || curCode === 'LL' || curCode === 'L.L.');
    const dec = (isLocalLbp || curCode === 'IQD') ? 0 : 2;
    const formatted = Utils.formatCurrency(amt, curCode, dec);
    const symMap = { USD: '$', EUR: '€', GBP: '£' };
    return symMap[curCode] ? `${symMap[curCode]}${formatted}` : `${formatted} ${curCode}`;
  }

  function _calcSecondaryPrice(p1) {
    return Utils.calcSecondaryPrice(p1, _settings.currency1, _settings.currency2, _settings.exchRate);
  }

  function _calcPrimaryFromSecondary(p2) {
    return Utils.calcPrimaryFromSecondary(p2, _settings.currency1, _settings.currency2, _settings.exchRate);
  }

  function _getExchNotice(isAR) {
    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';
    const rate = parseFloat(_settings.exchRate) || 89500;
    const rateStr = Utils.formatCurrency(rate, '', 0);
    const isLbp1 = Utils.isLbp ? Utils.isLbp(c1) : (c1 === 'LBP' || c1 === 'LL');
    const isLbp2 = Utils.isLbp ? Utils.isLbp(c2) : (c2 === 'LBP' || c2 === 'LL');
    const isUsd1 = Utils.isUsd ? Utils.isUsd(c1) : (c1 === 'USD' || c1 === '$');
    const isUsd2 = Utils.isUsd ? Utils.isUsd(c2) : (c2 === 'USD' || c2 === '$');

    if ((isUsd1 && isLbp2) || (isLbp1 && isUsd2)) {
      const localLabel = isLbp1 ? (c1 === 'LL' ? 'LL' : 'L.L.') : (c2 === 'LL' ? 'LL' : 'L.L.');
      return isAR ? `سعر الصرف: 1 USD = ${rateStr} ${localLabel}` : `Exchange Rate: 1 USD = ${rateStr} ${localLabel}`;
    }
    if (isUsd2 && rate > 1) {
      return isAR ? `سعر الصرف: 1 USD = ${rateStr} ${c1}` : `Exchange Rate: 1 USD = ${rateStr} ${c1}`;
    }
    return isAR ? `سعر الصرف: 1 ${c1} = ${rateStr} ${c2}` : `Exchange Rate: 1 ${c1} = ${rateStr} ${c2}`;
  }

  // ── Render Item Cards ──
  function renderItemCards(items, isAR) {
    if (!items.length) {
      return `<div class="empty-state" style="grid-column:1/-1;padding:40px 20px;text-align:center">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px;height:40px;margin-bottom:8px;opacity:0.4"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
        <p style="color:#64748b;font-weight:600">${isAR ? 'لا توجد أصناف في هذا التصنيف' : 'No items in this category'}</p>
      </div>`;
    }

    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';

    // Limit active DOM nodes for 60fps responsiveness even with 50,000+ items
    const limit = _posItemsLimit || 90;
    const isCapped = items.length > limit;
    const sliceItems = isCapped ? items.slice(0, limit) : items;
    const remaining = items.length - limit;

    const cardsHtml = sliceItems.map(item => {
      const name = isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name || item.name_ar);
      const code = item.item_code || item.barcode || `SKU-${item.id}`;
      const price = parseFloat(item.selling_price) || 0;
      const price2 = _calcSecondaryPrice(price);
      const whId = window._posWarehouseId || 1;
      const stock = (item.warehouse_stocks && item.warehouse_stocks[whId] !== undefined)
        ? (parseFloat(item.warehouse_stocks[whId]) || 0)
        : (parseFloat(item.stock_qty) || 0);
      const inStock = stock > 0;
      const canSell = inStock || _settings.allowNegativeStock;
      const unit = (item.unit || (isAR ? 'قطعة' : 'PIECE')).toUpperCase();
      const isScaleItem = item.is_scale || item.unit === 'kg' || item.unit === 'g';

      const hasThumb = Boolean(item.image);
      const thumbHtml = hasThumb ? `
        <div class="cockpit-item-thumb-box">
          <img src="${item.image}" alt="${Utils.sanitize(name)}" loading="lazy" class="cockpit-item-thumb" onerror="this.parentElement.style.display='none'">
        </div>` : '';

      return `
      <div class="cockpit-item-card ${!canSell ? 'is-out-of-stock' : ''} ${hasThumb ? 'has-thumb' : ''}" onclick="POS.onItemCardClick(${item.id})">
        <div class="cockpit-card-top">
          <span class="cockpit-item-code">${Utils.sanitize(code)}</span>
          ${isScaleItem ? `<span class="cockpit-badge-scale">⚖️ ${isAR ? 'ميزان' : 'Scale'}</span>` : ''}
        </div>
        ${thumbHtml}
        <div class="cockpit-item-title" title="${Utils.sanitize(name)}">${Utils.sanitize(name)}</div>
        <div class="cockpit-card-divider"></div>
        <div class="cockpit-card-pricing">
          <div class="cockpit-price-primary">
            <span class="cockpit-price-val">${_fmtCur(price, c1)}</span>
            <span class="cockpit-price-unit">/${unit}</span>
          </div>
          <div class="cockpit-price-secondary">
            ${_fmtCur(price2, c2)}
          </div>
        </div>
        <div class="cockpit-card-footer">
          <span class="cockpit-stock ${inStock ? '' : 'out-of-stock'}">
            ${inStock ? `${isAR ? 'المخزون:' : 'Stock:'} ${stock}` : (isAR ? 'نفد المخزون' : 'Out of Stock')}
          </span>
        </div>
        ${!canSell ? `<div style="position:absolute;inset:0;background:var(--pos-overlay-stock);border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;backdrop-filter:blur(2px);border:1.5px solid rgba(239,68,68,0.4)"><span style="background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.4);color:#ef4444;font-size:0.78rem;font-weight:900;padding:4px 10px;border-radius:20px;letter-spacing:0.5px">⚠️ ${isAR ? 'نفد المخزون' : 'OUT OF STOCK'}</span></div>` : ''}
      </div>`;
    }).join('');

    const noticeHtml = isCapped ? `
      <div style="grid-column:1/-1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:14px 16px;background:var(--pos-surface);border:1.5px dashed var(--pos-border);border-radius:12px;margin-top:10px;gap:8px">
        <div style="color:var(--pos-text-muted);font-size:0.82rem;font-weight:700">
          ${isAR ? `🔍 تم عرض ${limit} صنف من أصل ${items.length.toLocaleString()} صنف (${remaining.toLocaleString()} صنف إضافي)` : `🔍 Showing ${limit} of ${items.length.toLocaleString()} items (${remaining.toLocaleString()} remaining)`}
        </div>
        <button type="button" class="btn btn-primary btn-sm" onclick="POS.loadMoreItems()" style="padding:6px 20px;font-weight:800;border-radius:20px;display:inline-flex;align-items:center;gap:6px">
          <span>⬇️</span> ${isAR ? `عرض المزيد (+90 صنف)` : `Load More (+90 items)`}
        </button>
      </div>` : '';

    return cardsHtml + noticeHtml;
  }

  function isCartItemTaxable(c) {
    if (!c) return false;
    const vt = String(c.vat_type || '').toLowerCase().trim();
    if (vt === 'none' || vt === 'exempt' || vt === 'zero') return false;
    if (vt === 'standard' || vt === 'taxable' || vt === 'vat') return true;
    if (c.is_taxable === false || c.taxable === false) return false;
    if (c.is_taxable === true || c.taxable === true || c.is_vat_taxable === true) return true;
    if (parseFloat(c.vat_rate) > 0) return true;
    return false;
  }

  async function updateTotals() {
    const subtotal = _cart.reduce((s, c) => s + c.total, 0);
    const discVal  = parseFloat(document.getElementById('pos-discount-val')?.value) || 0;
    const discType = document.getElementById('pos-discount-type')?.value || 'pct';

    let manualDiscount = discType === 'pct' ? Utils.round(subtotal * (discVal / 100)) : Math.min(subtotal, discVal);

    // Dynamic Promotions & Happy Hour Check
    let promoDiscount = 0;
    _activePromoLabel = '';
    if (window.Promotions && typeof Promotions.getActivePromotions === 'function' && _txMode === 'sale') {
      const promoRes = await Promotions.getActivePromotions(_cart, subtotal);
      if (promoRes && promoRes.hasPromotion) {
        promoDiscount = promoRes.discountAmount;
        _activePromoLabel = promoRes.label;
      }
    }
    _activePromoDiscount = promoDiscount;

    const promoRow = document.getElementById('pos-promo-row');
    if (promoRow) {
      if (promoDiscount > 0) {
        promoRow.style.display = 'flex';
        const lbl = document.getElementById('pos-promo-label');
        const amt = document.getElementById('pos-promo-amt');
        if (lbl) lbl.textContent = `🔥 ${_activePromoLabel}`;
        if (amt) amt.textContent = `-${Utils.formatMoney(promoDiscount, _settings.currency1)}`;
      } else {
        promoRow.style.display = 'none';
      }
    }

    // Points Redemption Discount
    const pointsRow = document.getElementById('pos-loyalty-redeemed-row');
    if (pointsRow) {
      if (_pointsDiscount > 0) {
        pointsRow.style.display = 'flex';
        const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
        const lbl = document.getElementById('pos-loyalty-redeemed-label');
        const amt = document.getElementById('pos-loyalty-redeemed-amt');
        if (lbl) lbl.textContent = `⭐ ${isAR ? 'خصم النقاط' : 'Points Discount'} (${_redeemedPoints} pts)`;
        if (amt) amt.textContent = `-${Utils.formatMoney(_pointsDiscount, _settings.currency1)}`;
      } else {
        pointsRow.style.display = 'none';
      }
    }

    let totalDiscounts = manualDiscount + promoDiscount + _pointsDiscount;
    let afterDisc = Math.max(0, subtotal - totalDiscounts);

    // Calculate VAT strictly for items defined with tax (TVA)
    let vatAmt = 0;
    if (_settings.vatEnabled) {
      const discountRatio = subtotal > 0 ? Math.max(0, afterDisc / subtotal) : 1;
      let totalVat = 0;
      for (const c of _cart) {
        if (c.line_type === 'damage' || c.line_type === 'gift') continue;
        if (!isCartItemTaxable(c)) continue;
        const lineNet = (c.total || 0) * discountRatio;
        const rate = (parseFloat(c.vat_rate) > 0) ? parseFloat(c.vat_rate) : (parseFloat(_settings.vatRate) || 11);
        totalVat += lineNet * (rate / 100);
      }
      vatAmt = Utils.round(totalVat);
    }

    const grandTotal = afterDisc + vatAmt;
    const total2     = _calcSecondaryPrice(grandTotal);

    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';

    Utils.setHTML('#pos-subtotal', _fmtCur(subtotal, c1));
    Utils.setHTML('#pos-vat-amt',  _fmtCur(vatAmt, c1));
    Utils.setHTML('#pos-total-1',  _fmtCur(grandTotal, c1));
    Utils.setHTML('#pos-total-2',  _fmtCur(total2, c2));

    const vatRow = document.getElementById('pos-vat-row');
    if (vatRow) {
      vatRow.style.display = (_settings.vatEnabled && vatAmt > 0) ? 'flex' : 'none';
    }

    // Loyalty points earned preview
    const earnPreview = document.getElementById('pos-earned-points-preview');
    const barEarnPreview = document.getElementById('pos-points-earned-preview');
    let pointsEarned = 0;
    if (_settings.loyaltyEnabled && _customer && _txMode === 'sale') {
      pointsEarned = Math.floor(grandTotal * (_settings.loyaltyEarnRate || 1));
      const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
      if (earnPreview) {
        earnPreview.style.display = 'block';
        earnPreview.textContent = `+${pointsEarned.toLocaleString()} ${isAR ? 'نقطة ستضاف للعميل' : 'pts will be earned'}`;
      }
      if (barEarnPreview) {
        barEarnPreview.textContent = pointsEarned > 0 ? `(+${pointsEarned.toLocaleString()} ${isAR ? 'نقطة جديدة' : 'pts'})` : '';
      }
    } else {
      if (earnPreview) earnPreview.style.display = 'none';
      if (barEarnPreview) barEarnPreview.textContent = '';
    }

    window._posGrandTotal    = grandTotal;
    window._posTotal2        = total2;
    window._posSubtotal      = subtotal;
    window._posDiscount      = totalDiscounts;
    window._posManualDisc    = manualDiscount;
    window._posPromoDisc     = promoDiscount;
    window._posPointsDisc    = _pointsDiscount;
    window._posRedeemedPts   = _redeemedPoints;
    window._posPointsEarned  = pointsEarned;
    window._posVat           = vatAmt;

    // Sync Mobile POS Indicators
    const totalQty = _cart.reduce((sum, item) => sum + (parseFloat(item.qty) || 1), 0);
    const mobileCount = document.getElementById('pos-mobile-cart-count');
    if (mobileCount) mobileCount.textContent = totalQty;
    const mobileTotal = document.getElementById('pos-mobile-cart-total');
    if (mobileTotal) mobileTotal.textContent = _fmtCur(grandTotal, c1);

    const floatCount = document.getElementById('pos-float-cart-count');
    if (floatCount) floatCount.textContent = totalQty;
    const floatTotal = document.getElementById('pos-float-cart-total');
    if (floatTotal) floatTotal.textContent = _fmtCur(grandTotal, c1);

    const floatBar = document.getElementById('pos-mobile-float-bar');
    if (floatBar) {
      if (_cart.length > 0 && window.innerWidth <= 768 && _currentMobileView !== 'cart') {
        floatBar.style.display = 'flex';
      } else {
        floatBar.style.display = 'none';
      }
    }

    _broadcastCustomerDisplay(false);
  }

  let _cdChannel = null;
  let _lastPoleSentVal = null;
  let _poleSendDebounce = null;

  async function _sendHardwareCustomerDisplay(amount, status = 'total') {
    try {
      if (_settings && _settings.poleDisplayEnabled === false) return;
      const port = _settings?.poleDisplayPort || 'auto';
      const baud = _settings?.poleDisplayBaud || 2400;

      const val = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
      const amtStr = val.toFixed(2);

      // Debounce repetitive zero or identical sends
      if (_lastPoleSentVal === amtStr + '_' + status) return;
      _lastPoleSentVal = amtStr + '_' + status;

      clearTimeout(_poleSendDebounce);
      _poleSendDebounce = setTimeout(async () => {
        try {
          const apiUrl = window.location.origin.startsWith('http') ? '/api/customer-display/send' : 'http://localhost:3000/api/customer-display/send';
          await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              amount: amtStr,
              status: status, // 'total', 'change', 'price', 'clear'
              port: port,
              baud: baud
            })
          });
        } catch (_) {}
      }, 50);
    } catch(e) {}
  }

  function _broadcastCustomerDisplay(isCompleted = false) {
    try {
      if (!_cdChannel && typeof BroadcastChannel !== 'undefined') {
        _cdChannel = new BroadcastChannel('redshark_pos_display');
      }
      const user = Auth.getUser();
      const cur1 = _settings.currency1 || 'USD';
      const cur2 = _settings.currency2 || 'LBP';
      const payload = {
        storeName: _settings.companyName || 'Red Shark POS',
        cashier: user?.full_name || user?.username || 'Cashier',
        currency1: cur1,
        currency2: cur2,
        cart: _cart.map(c => ({
          name: i18n.getLang() === 'ar' ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar),
          qty: c.qty,
          price: c.price,
          priceFormatted: _fmtCur(c.price, cur1),
          total: c.total,
          totalFormatted: _fmtCur(c.total, cur1)
        })),
        subtotal: window._posSubtotal || 0,
        subtotalFormatted: _fmtCur(window._posSubtotal || 0, cur1),
        discount: window._posDiscount || 0,
        discountFormatted: _fmtCur(window._posDiscount || 0, cur1),
        total: window._posGrandTotal || 0,
        totalFormatted: _fmtCur(window._posGrandTotal || 0, cur1),
        totalSec: _fmtCur(window._posTotal2 || 0, cur2),
        isCompleted: isCompleted
      };
      if (_cdChannel) _cdChannel.postMessage(payload);
      localStorage.setItem('redshark_customer_display_payload', JSON.stringify(payload));

      // Stream to physical LED8N Pole Display on back of POS terminal
      if (isCompleted) {
        _sendHardwareCustomerDisplay(0, 'total');
      } else {
        _sendHardwareCustomerDisplay(window._posGrandTotal || 0, 'total');
      }
    } catch(e) {
      console.warn('Customer display broadcast error:', e);
    }
  }

  function openCustomerDisplay() {
    window.open('customer_display.html', 'CustomerDisplay', 'width=1024,height=768,menubar=no,toolbar=no,location=no,status=no');
  }

  function calcChange(changedField = 'c1') {
    const totalC1 = window._posGrandTotal || 0;
    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';
    const rate = parseFloat(_settings.exchRate) || 89500;

    let tenderedC1 = parseFloat(document.getElementById('pay-tendered').value) || 0;
    let tenderedC2 = parseFloat(document.getElementById('pay-tendered-2').value) || 0;

    if (changedField === 'c1' && tenderedC1 > 0) {
      tenderedC2 = _calcSecondaryPrice(tenderedC1);
      document.getElementById('pay-tendered-2').value = tenderedC2;
    } else if (changedField === 'c2' && tenderedC2 > 0) {
      tenderedC1 = _calcPrimaryFromSecondary(tenderedC2);
      document.getElementById('pay-tendered').value = tenderedC1;
    }

    const changeC1 = Math.max(0, tenderedC1 - totalC1);
    const changeC2 = _calcSecondaryPrice(changeC1);

    Utils.setHTML('#pay-change',   _fmtCur(changeC1, c1));
    Utils.setHTML('#pay-change-2', _fmtCur(changeC2, c2));

    if (tenderedC1 > 0 && changeC1 > 0) {
      _sendHardwareCustomerDisplay(changeC1, 'change');
    }
  }

  function showCategories(btn) {
    _activeCatId = 'categories';
    _updateCatNavButtons(btn || document.querySelector('[data-cat="categories"]'));
    const isAR = i18n.getLang() === 'ar';
    document.getElementById('pos-search').value = '';
    document.getElementById('pos-items-grid').innerHTML = renderCategoryCards(_cats, isAR);
  }

  // ─────────────────────────────────────────────────────────────
  // Barcode Scanner Engine & Concurrency Queue
  // ─────────────────────────────────────────────────────────────
  let _scanQueue = [];
  let _isProcessingScan = false;
  let _filterDebounceTimer = null;

  function onSearchInput(inputEl, e) {
    if (!inputEl) return;
    const val = inputEl.value;

    // Detect if scanner sent embedded newlines or carriage returns
    if (val.includes('\n') || val.includes('\r')) {
      const parts = val.split(/[\r\n]+/).map(p => p.trim()).filter(Boolean);
      inputEl.value = '';
      if (_filterDebounceTimer) {
        clearTimeout(_filterDebounceTimer);
        _filterDebounceTimer = null;
      }
      for (const p of parts) {
        handleBarcodeScan(p);
      }
      return;
    }

    // Debounce live search typing so rapid scanner keystrokes (< 50ms apart)
    // do not trigger heavy grid re-renders on every character
    if (_filterDebounceTimer) clearTimeout(_filterDebounceTimer);
    _filterDebounceTimer = setTimeout(() => {
      filterItems(inputEl.value);
    }, 120);
  }

  function onSearchKeyDown(inputEl, e) {
    if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault();
      e.stopPropagation();

      const rawVal = inputEl.value;
      // IMMEDIATE SYNCHRONOUS CLEAR:
      // This is crucial: the input field is emptied right now before any async operation,
      // so any subsequent barcode scanned immediately enters a clean, empty field.
      inputEl.value = '';
      _scannerBuffer = '';

      if (_filterDebounceTimer) {
        clearTimeout(_filterDebounceTimer);
        _filterDebounceTimer = null;
      }

      if (rawVal && rawVal.trim()) {
        handleBarcodeScan(rawVal.trim());
      }
    }
  }

  function _findItemMatch(codeStr) {
    if (!codeStr || !_items || !_items.length) return null;
    const s = codeStr.trim().toLowerCase();
    if (!s) return null;

    // 1. Exact match by barcode, code, item_code, or scale_plu FIRST
    let match = _items.find(i => 
      (i.barcode && String(i.barcode).trim().toLowerCase() === s) ||
      (i.code && String(i.code).trim().toLowerCase() === s) ||
      (i.item_code && String(i.item_code).trim().toLowerCase() === s) ||
      (i.is_scale && i.scale_plu && String(i.scale_plu).trim() === s)
    );
    if (match) return { item: match, qty: 1 };

    // 2. Electronic Scale Barcode Parser (Weight/Price Embedded EAN-13 e.g. 20..29)
    if (Utils.parseScaleBarcode) {
      const scaleResult = Utils.parseScaleBarcode(codeStr, _items);
      if (scaleResult && scaleResult.item) {
        return { item: scaleResult.item, qty: scaleResult.qty, isScaleParsed: true };
      }
    }

    // 3. Exact Name Match (exact string only)
    match = _items.find(i =>
      (i.name_en && i.name_en.trim().toLowerCase() === s) ||
      (i.name_ar && i.name_ar.trim().toLowerCase() === s)
    );
    if (match) return { item: match, qty: 1 };

    return null;
  }

  function _tryDecomposeConcatenatedBarcodes(rawQuery) {
    if (!rawQuery || !_items || !_items.length) return null;
    const q = rawQuery.trim().toLowerCase();
    if (q.length < 6) return null;

    // Standard barcode length heuristics (EAN-13, UPC-12, EAN-8)
    const standardLengths = [13, 12, 8, 14];
    for (const len of standardLengths) {
      if (q.length > len) {
        const p1 = q.slice(0, len);
        const p2 = q.slice(len);
        const m1 = _findItemMatch(p1);
        const m2 = _findItemMatch(p2);
        if (m1 && m2) {
          return [m1, m2];
        }
      }
    }

    // General 2-way split search across all possible split points
    for (let i = 3; i <= q.length - 3; i++) {
      const p1 = q.slice(0, i);
      const p2 = q.slice(i);
      const m1 = _findItemMatch(p1);
      if (m1) {
        const m2 = _findItemMatch(p2);
        if (m2) {
          return [m1, m2];
        }
        // If p2 is also long, check 3-way split
        if (p2.length >= 6) {
          for (let j = 3; j <= p2.length - 3; j++) {
            const p2a = p2.slice(0, j);
            const p2b = p2.slice(j);
            const m2a = _findItemMatch(p2a);
            const m2b = _findItemMatch(p2b);
            if (m2a && m2b) {
              return [m1, m2a, m2b];
            }
          }
        }
      }
    }

    return null;
  }

  async function _applyScannedItem(matchResult) {
    const item = matchResult.item;
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;

    // Ensure search input is cleared and focused
    const searchInput = document.getElementById('pos-search');
    if (searchInput) {
      searchInput.value = '';
      searchInput.focus();
    }

    if (matchResult.isScaleParsed) {
      await addToCart(item.id, matchResult.qty);
      const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
      const unit = item.unit || (isAR ? 'كغ' : 'kg');
      Utils.toast(isAR ? `⚖️ تم وزن وإضافة: ${itemName} (${matchResult.qty} ${unit})` : `⚖️ Weighed & Added: ${itemName} (${matchResult.qty} ${unit})`, 'success');
    } else if (item.is_scale || item.unit === 'kg' || item.unit === 'g') {
      openScaleModal(item.id);
    } else {
      await addToCart(item.id, matchResult.qty || 1);
    }

    if (_activeCatId === 'categories') {
      showCategories();
    } else {
      filterByCategory(_activeCatId);
    }
  }

  async function _processSingleBarcodeScan(query) {
    if (!query) return false;
    const q = query.trim().toLowerCase();
    if (!q) return false;

    // Deduplication check: 150ms window to block single key-bounce / Enter duplicate
    const now = Date.now();
    if (_lastScanCode === q && (now - _lastScanTime) < 150) {
      return false;
    }
    _lastScanCode = q;
    _lastScanTime = now;

    if (!_items || !_items.length) {
      _items = await DB.getAll('items', i => i.status !== 'inactive');
    }

    // 1. Direct single item match
    const directMatch = _findItemMatch(q);
    if (directMatch) {
      await _applyScannedItem(directMatch);
      return true;
    }

    // 2. Concatenated Barcodes Split & Recovery:
    // If scanner entered two or more barcodes in the same line without Enter
    const splitMatches = _tryDecomposeConcatenatedBarcodes(query);
    if (splitMatches && splitMatches.length > 0) {
      const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
      for (const m of splitMatches) {
        await _applyScannedItem(m);
      }
      Utils.toast(isAR ? `⚡ تم مسح وإضافة ${splitMatches.length} أصناف بنجاح` : `⚡ Scanned & added ${splitMatches.length} items successfully`, 'success');
      return true;
    }

    // 3. Undefined item: DO NOT add anything. Wipe buffer and show modal alert.
    _scannerBuffer = '';
    _playErrorTone();
    const searchInput = document.getElementById('pos-search');
    if (searchInput) {
      searchInput.value = '';
    }
    showUndefinedItemModal(query);
    return false;
  }

  async function handleBarcodeScan(query) {
    if (!query) return false;
    const clean = query.trim();
    if (!clean) return false;

    // Handle possible multiple lines if scanner sent newlines
    if (clean.includes('\n') || clean.includes('\r')) {
      const parts = clean.split(/[\r\n]+/).map(p => p.trim()).filter(Boolean);
      for (const p of parts) {
        _scanQueue.push(p);
      }
    } else {
      _scanQueue.push(clean);
    }

    if (_isProcessingScan) {
      return true;
    }

    _isProcessingScan = true;
    while (_scanQueue.length > 0) {
      const nextQuery = _scanQueue.shift();
      try {
        await _processSingleBarcodeScan(nextQuery);
      } catch (err) {
        console.error('POS scan processing error:', err);
      }
    }
    _isProcessingScan = false;
    return true;
  }

  function filterItems(query, resetLimit = true) {
    if (resetLimit) _posItemsLimit = 90;
    const isAR = i18n.getLang() === 'ar';
    const q = query.trim().toLowerCase();

    if (!q) {
      if (_activeCatId === 'categories') {
        showCategories();
      } else {
        filterByCategory(_activeCatId, null, resetLimit);
      }
      return;
    }

    const filtered = _items.filter(i =>
      (i.name_en || '').toLowerCase().includes(q) ||
      (i.name_ar || '').toLowerCase().includes(q) ||
      (i.item_code || '').toLowerCase().includes(q) ||
      (i.barcode || '').toLowerCase().includes(q) ||
      (i.brand || '').toLowerCase().includes(q) ||
      (i.model || '').toLowerCase().includes(q)
    );

    document.getElementById('pos-items-grid').innerHTML = renderItemCards(filtered, isAR);
  }

  function filterByCategory(catId, btnEl, resetLimit = true) {
    if (resetLimit) _posItemsLimit = 90;
    _activeCatId = catId;
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const btn = btnEl || document.querySelector(`[data-cat="${catId}"]`);
    _updateCatNavButtons(btn);

    if (catId === 'categories') {
      showCategories(btn);
      return;
    }

    const grid = document.getElementById('pos-items-grid');
    if (!grid) return;

    let filtered = [];
    let catTitle = '';
    let catIcon = '📂';

    if (catId === 'no-category' || catId === 'uncategorized') {
      filtered = _items.filter(i => _isUncategorizedItem(i, _cats));
      catTitle = isAR ? 'أصناف بدون تصنيف' : 'Uncategorized Items';
      catIcon = '🏷️';
    } else {
      const selectedCat = _cats.find(c => String(c.id) === String(catId));
      filtered = (catId === 'all' || !catId)
        ? _items
        : _items.filter(i => String(i.category_id) === String(catId) || (selectedCat && i.category && (i.category === selectedCat.name || i.category === selectedCat.name_en || i.category === selectedCat.name_ar)));
      catTitle = selectedCat
        ? (isAR ? (selectedCat.name_ar || selectedCat.name) : (selectedCat.name || selectedCat.name_ar))
        : (isAR ? 'الأصناف' : 'Items');
    }

    if (catId !== 'all') {
      grid.innerHTML = `
        <div style="grid-column:1/-1;display:flex;align-items:center;justify-content:space-between;background:var(--pos-surface);border:1.5px solid var(--pos-border);padding:8px 14px;border-radius:10px;margin-bottom:6px">
          <button type="button" class="btn btn-secondary btn-sm" onclick="POS.showCategories()" style="font-weight:700;display:flex;align-items:center;gap:6px;background:var(--pos-chip-bg);color:var(--pos-text-main);border:1px solid var(--pos-chip-border)">
            <span>←</span> ${isAR ? 'العودة للتصنيفات' : 'Back to Categories'}
          </button>
          <span style="font-weight:800;font-size:0.92rem;color:var(--pos-text-main)">${catIcon} ${Utils.sanitize(catTitle)} <span style="font-size:0.78rem;color:var(--pos-text-muted)">(${filtered.length.toLocaleString()} ${isAR ? 'صنف' : 'items'})</span></span>
        </div>
        ${renderItemCards(filtered, isAR)}`;
    } else {
      grid.innerHTML = renderItemCards(filtered, isAR);
    }
  }

  function showCategories(btnEl) {
    _posItemsLimit = 90;
    _activeCatId = 'categories';
    const btn = btnEl || document.querySelector(`[data-cat="categories"]`);
    _updateCatNavButtons(btn);
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const searchInput = document.getElementById('pos-search');
    if (searchInput) searchInput.value = '';
    const grid = document.getElementById('pos-items-grid');
    if (grid) grid.innerHTML = renderCategoryCards(_cats, isAR);
  }

  function filterFavorites(btnEl, resetLimit = true) {
    if (resetLimit) _posItemsLimit = 90;
    _activeCatId = 'fav';
    const isAR = i18n.getLang() === 'ar';
    const btn = btnEl || document.querySelector(`[data-cat="fav"]`);
    _updateCatNavButtons(btn);
    const filtered = _items.filter(i => i.is_favorite || i.favorite || (parseFloat(i.stock_qty) > 50));
    const list = filtered.length ? filtered : _items.slice(0, 12);
    const grid = document.getElementById('pos-items-grid');
    if (grid) grid.innerHTML = renderItemCards(list, isAR);
  }

  function filterByWeight(btnEl, resetLimit = true) {
    if (resetLimit) _posItemsLimit = 90;
    _activeCatId = 'weight';
    const isAR = i18n.getLang() === 'ar';
    const btn = btnEl || document.querySelector(`[data-cat="weight"]`);
    _updateCatNavButtons(btn);
    const filtered = _items.filter(i => i.is_scale || i.unit === 'kg' || i.unit === 'g');
    const grid = document.getElementById('pos-items-grid');
    if (grid) grid.innerHTML = renderItemCards(filtered, isAR);
  }

  function loadMoreItems() {
    _posItemsLimit = (_posItemsLimit || 90) + 90;
    const searchVal = document.getElementById('pos-search')?.value?.trim();
    if (searchVal) {
      filterItems(searchVal, false);
    } else if (_activeCatId === 'fav') {
      filterFavorites(null, false);
    } else if (_activeCatId === 'weight') {
      filterByWeight(null, false);
    } else if (_activeCatId && _activeCatId !== 'categories') {
      filterByCategory(_activeCatId, null, false);
    }
  }

  function openDiscountModal() {
    const isAR = i18n.getLang() === 'ar';
    const currentVal = document.getElementById('pos-discount-val')?.value || 0;
    const promptVal = prompt(isAR ? 'أدخل نسبة الخصم للفاتورة (%):' : 'Enter invoice discount percentage (%):', currentVal);
    if (promptVal !== null && !isNaN(parseFloat(promptVal))) {
      const discValEl = document.getElementById('pos-discount-val');
      if (discValEl) discValEl.value = parseFloat(promptVal);
      updateTotals();
      Utils.toast(isAR ? `تم تطبيق خصم: ${promptVal}%` : `Discount applied: ${promptVal}%`, 'success');
    }
  }

  function _updateCatNavButtons(activeBtn) {
    document.querySelectorAll('#pos-cat-buttons .cockpit-chip-btn, #pos-cat-buttons .btn').forEach(b => {
      b.classList.remove('active');
      b.className = b.className.replace('btn-primary', 'btn-secondary');
    });
    if (activeBtn) {
      activeBtn.classList.add('active');
      if (activeBtn.classList.contains('btn')) {
        activeBtn.className = activeBtn.className.replace('btn-secondary', 'btn-primary');
      }
    }
  }

  async function setTxMode(mode) {
    const isAR = i18n.getLang() === 'ar';
    if (mode === _txMode) return;

    if (mode !== 'sale') {
      const reqAuth = (typeof _settings.require_return_auth !== 'undefined') 
        ? _settings.require_return_auth !== false 
        : (await DB.getSetting('require_return_auth', true) !== false);

      const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items') || Auth.can('pos.returns') || Auth.can('returns')));

      if (reqAuth && !isAdmin) {
        const modeLabels = {
          return: isAR ? 'وضع إرجاع المبيعات' : 'Sales Return Mode',
          damage: isAR ? 'وضع تسجيل تالف / إتلاف' : 'Damaged Item Mode',
          gift: isAR ? 'وضع الهدايا والعينات المجانية' : 'Gift & Sample Mode'
        };
        const promptMsg = isAR
          ? `تفعيل (${modeLabels[mode] || mode}) يتطلب إدخال كلمة المرور الرئيسية للمشرف:`
          : `Activating (${modeLabels[mode] || mode}) requires Supervisor Master Password:`;

        const authorized = await promptAdminAuthModal(promptMsg);
        if (!authorized) {
          Utils.toast(isAR ? '❌ تم رفض التحويل: يلزم تصريح المشرف' : '❌ Mode change cancelled: Supervisor authorization required', 'warning');
          return;
        }
      }
    }

    _txMode = mode;

    document.querySelectorAll('.pos-tx-btn').forEach(b => {
      b.classList.remove('active');
    });
    const activeBtn = document.getElementById(`tx-mode-${mode}`);
    if (activeBtn) {
      activeBtn.classList.add('active');
    }

    const banner = document.getElementById('tx-mode-banner');
    if (banner) {
      if (mode === 'return') {
        banner.style.display = 'block';
        banner.style.background = '#0f172a';
        banner.style.color = '#ffffff';
        banner.style.border = '1.5px solid #dc2626';
        banner.innerHTML = `↩️ <strong style="color:#ef4444">${isAR ? 'وضع إرجاع المبيعات النشط' : 'ACTIVE SALES RETURN MODE'}</strong> — ${isAR ? 'الأصناف المضافة ستحتسب كمرتجع ويسترد العميل قيمتها' : 'Items added will be refunded to customer'}`;
      } else if (mode === 'damage') {
        banner.style.display = 'block';
        banner.style.background = '#0f172a';
        banner.style.color = '#ffffff';
        banner.style.border = '1.5px solid #dc2626';
        banner.innerHTML = `⚠️ <strong style="color:#ef4444">${isAR ? 'وضع شطب تالف / إتلاف' : 'ACTIVE DAMAGED ITEM MODE'}</strong> — ${isAR ? 'تسجيل الأصناف كتالفة بسعر 0$ بدون سحب نقدي' : 'Logs items as damaged at $0 without cash withdrawal'}`;
      } else if (mode === 'gift') {
        banner.style.display = 'block';
        banner.style.background = '#0f172a';
        banner.style.color = '#ffffff';
        banner.style.border = '1.5px solid #dc2626';
        banner.innerHTML = `🎁 <strong style="color:#ef4444">${isAR ? 'وضع الهدايا والعينات المجانية' : 'ACTIVE GIFT MODE'}</strong> — ${isAR ? 'الأصناف المضافة ستصرف كـ هدايا بقيمة $0.00' : 'Items added will be issued as gifts ($0.00)'}`;
      } else {
        banner.style.display = 'none';
      }
    }
  }

  // ── Cart Logic ──
  async function addToCart(itemId, customQty = 1) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    
    // Always fetch fresh item from DB to ensure real-time stock integrity
    const freshItem = (await DB.get('items', parseInt(itemId) || itemId)) || _items.find(i => String(i.id) === String(itemId) || i.id === itemId);
    if (!freshItem) return;

    // Update in-memory item cache
    const idxInItems = _items.findIndex(i => i.id === freshItem.id);
    if (idxInItems !== -1) {
      _items[idxInItems] = freshItem;
    } else {
      _items.push(freshItem);
    }
    const item = freshItem;
    const addQty = typeof customQty === 'number' && customQty > 0 ? customQty : 1;
    const whId = window._posWarehouseId || 1;
    const currentStock = (item.warehouse_stocks && item.warehouse_stocks[whId] !== undefined)
      ? (parseFloat(item.warehouse_stocks[whId]) || 0)
      : (parseFloat(item.stock_qty) || 0);

    const type = _txMode || 'sale';

    if (type === 'sale' && currentStock <= 0 && !_settings.allowNegativeStock) {
      _playErrorTone();
      Utils.toast(isAR ? `⚠️ نفد مخزون الصنف (${Utils.truncate(isAR ? (item.name_ar||item.name_en) : (item.name_en||item.name_ar), 25)})` : (i18n.t('pos.insufficient_stock') || 'Insufficient stock!'), 'warning');
      const searchInput = document.getElementById('pos-search');
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      return;
    }

    const existing = _cart.find(c => (String(c.item_id) === String(itemId) || c.item_id === itemId) && c.line_type === type);
    if (existing) {
      if (type === 'sale' && !_settings.allowNegativeStock && (existing.qty + addQty) > currentStock) {
        _playErrorTone();
        Utils.toast(isAR ? `⚠️ الكمية المطلوبة تتجاوز المخزون المتاح (${currentStock})` : (i18n.t('pos.insufficient_stock') || 'Insufficient stock!'), 'warning');
        const searchInput = document.getElementById('pos-search');
        if (searchInput) {
          searchInput.value = '';
          searchInput.focus();
        }
        return;
      }
      existing.qty = Utils.round(existing.qty + addQty, 3);
      _recalcLineTotal(existing);
    } else {
      if (type === 'sale' && !_settings.allowNegativeStock && addQty > currentStock) {
        _playErrorTone();
        Utils.toast(isAR ? `⚠️ الكمية المطلوبة تتجاوز المخزون المتاح (${currentStock})` : (i18n.t('pos.insufficient_stock') || 'Insufficient stock!'), 'warning');
        const searchInput = document.getElementById('pos-search');
        if (searchInput) {
          searchInput.value = '';
          searchInput.focus();
        }
        return;
      }
      const price = parseFloat(item.selling_price) || 0;
      const cost  = parseFloat(item.cost_price) || 0;
      const initialTotal = (type === 'damage' || type === 'gift') ? 0 : (type === 'return' ? -Utils.round(price * addQty) : Utils.round(price * addQty));
      const newItem = {
        item_id:     item.id,
        name_en:     item.name_en,
        name_ar:     item.name_ar,
        item_code:   item.item_code,
        category_id: item.category_id,
        price,
        cost_price:  cost,
        qty:         Utils.round(addQty, 3),
        disc_pct:    0,
        disc_amt:    0,
        disc_type:   'pct',
        line_type:   type,
        total:       initialTotal,
        vat_type:    item.vat_type || 'none',
        vat_rate:    item.vat_rate || 0,
        is_taxable:  isCartItemTaxable(item),
        unit:        item.unit
      };
      _cart.push(newItem);
      _recalcLineTotal(newItem);
    }
    _posSelectedCartIndex = existing ? _cart.indexOf(existing) : (_cart.length - 1);
    _posNumpadBuffer = '';
    _posNumpadReplaceMode = true;
    renderCart();
    updateTotals();
    _updateNumpadHeader();
    _highlightSelectedCartRow();
    setTimeout(() => {
      _scrollSelectedCartRowIntoView();
    }, 40);
    if (window.AICopilot && typeof AICopilot.playAudio === 'function') {
      AICopilot.playAudio('scan');
    }
    if (window.innerWidth <= 768) {
      const floatBar = document.getElementById('pos-mobile-float-bar');
      if (floatBar && _currentMobileView !== 'cart') {
        floatBar.style.display = 'flex';
      }
      if (window.Utils && typeof Utils.toast === 'function') {
        Utils.toast(isAR ? `+1 (${item.name_ar || item.name_en || ''}) في السلة` : `+1 (${item.name_en || item.name_ar || ''}) added to cart`, 'info');
      }
    }
  }

  function _recalcLineTotal(item) {
    const basePrice = parseFloat(item.price) || 0;
    const discType = item.disc_type || 'pct';
    let unitDisc = 0;
    if (discType === 'amt') {
      unitDisc = Math.min(basePrice, Math.max(0, parseFloat(item.disc_amt) || 0));
      item.disc_pct = basePrice > 0 ? Utils.round((unitDisc / basePrice) * 100, 2) : 0;
    } else {
      const pct = Math.min(100, Math.max(0, parseFloat(item.disc_pct) || 0));
      unitDisc = Utils.round(basePrice * (pct / 100));
      item.disc_amt = unitDisc;
    }
    const effPrice = Math.max(0, basePrice - unitDisc);

    if (item.line_type === 'damage' || item.line_type === 'gift') {
      item.total = 0;
    } else if (item.line_type === 'return') {
      item.total = -Utils.round(item.qty * effPrice);
    } else {
      item.total = Utils.round(item.qty * effPrice);
    }
  }

  async function setLineType(idx, targetType) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const item = _cart[idx];
    if (!item) return;

    if (item.line_type === targetType) {
      document.getElementById('pos-line-type-modal')?.remove();
      return;
    }

    // If changing to return, damage, or gift, verify authorization if user is not admin
    if (targetType !== 'sale') {
      const reqAuth = (typeof _settings.require_return_auth !== 'undefined') 
        ? _settings.require_return_auth !== false 
        : (await DB.getSetting('require_return_auth', true) !== false);

      const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items') || Auth.can('pos.returns') || Auth.can('returns')));

      if (reqAuth && !isAdmin) {
        const typeLabels = {
          return: isAR ? 'إرجاع مبيعات' : 'Sales Return',
          damage: isAR ? 'صنف تالف / تخريد' : 'Damaged / Waste Item',
          gift: isAR ? 'صنف هدية مجانية' : 'Gift Item'
        };
        const promptMsg = isAR
          ? `تحويل الصنف إلى (${typeLabels[targetType] || targetType}) يتطلب إدخال كلمة المرور الرئيسية للمشرف:`
          : `Setting item to (${typeLabels[targetType] || targetType}) requires Supervisor Master Password:`;
        
        const authorized = await promptAdminAuthModal(promptMsg);
        if (!authorized) {
          Utils.toast(isAR ? '❌ تم إلغاء العملية: يلزم تصريح المشرف' : '❌ Operation canceled: Admin approval required', 'warning');
          return;
        }
      }
    }

    document.getElementById('pos-line-type-modal')?.remove();

    // Check if there is another line of the same item with targetType
    const dupIdx = _cart.findIndex((c, i) => i !== idx && (String(c.item_id) === String(item.item_id) || c.item_id === item.item_id) && c.line_type === targetType);
    if (dupIdx !== -1) {
      _cart[dupIdx].qty = Utils.round(_cart[dupIdx].qty + item.qty, 3);
      _recalcLineTotal(_cart[dupIdx]);
      _cart.splice(idx, 1);
    } else {
      item.line_type = targetType;
      _recalcLineTotal(item);
    }
    renderCart();
    updateTotals();

    const badgeLabels = {
      sale: isAR ? '🛒 بيع عادي' : '🛒 Normal Sale',
      return: isAR ? '↩️ إرجاع مبيعات' : '↩️ Sales Return',
      damage: isAR ? '⚠️ صنف تالف' : '⚠️ Damaged',
      gift: isAR ? '🎁 هدية' : '🎁 Gift'
    };
    Utils.toast(isAR ? `✅ تم تغيير نوع الصنف إلى: ${badgeLabels[targetType] || targetType}` : `✅ Item movement set to: ${badgeLabels[targetType] || targetType}`, 'success');
  }

  async function cycleLineType(idx) {
    const item = _cart[idx];
    if (!item) return;
    const types = ['sale', 'return', 'damage', 'gift'];
    const currentIdx = types.indexOf(item.line_type || 'sale');
    const newType = types[(currentIdx + 1) % types.length];
    await setLineType(idx, newType);
  }

  function openLineTypeModal(idx) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const item = _cart[idx];
    if (!item) return;

    document.getElementById('pos-line-type-modal')?.remove();

    const curType = item.line_type || 'sale';
    const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items') || Auth.can('pos.returns') || Auth.can('returns')));

    const options = [
      {
        id: 'sale',
        icon: '🛒',
        title: isAR ? 'بيع عادي (Normal Sale)' : 'Normal Sale',
        desc: isAR ? 'عملية بيع اعتيادية بالسعر المحدد وإجمالي موجب' : 'Standard sale item with selling price and stock reduction',
        badge: isAR ? 'متاح للجميع' : 'Standard',
        border: '#334155',
        activeBorder: '#dc2626'
      },
      {
        id: 'return',
        icon: '↩️',
        title: isAR ? 'إرجاع مبيعات (Sales Return)' : 'Sales Return',
        desc: isAR ? 'إرجاع بضاعة من العميل، قيمة سالبة وإعادة الصنف للمخزون' : 'Customer refund/return, negative price, restocks inventory',
        badge: isAR ? '🔐 تصريح المشرف' : '🔐 Supervisor Required',
        border: '#dc2626',
        activeBorder: '#dc2626'
      },
      {
        id: 'damage',
        icon: '⚠️',
        title: isAR ? 'صنف تالف / تخريد (Damaged / Waste)' : 'Damaged / Waste',
        desc: isAR ? 'إخراج الصنف من المخزون بسعر 0$ بسبب الكسر أو التلف' : 'Written off at $0 price due to expiry, breakage or damage',
        badge: isAR ? '🔐 تصريح المشرف' : '🔐 Supervisor Required',
        border: '#0f172a',
        activeBorder: '#dc2626'
      },
      {
        id: 'gift',
        icon: '🎁',
        title: isAR ? 'صنف هدية / ترويجي (Gift / Promo)' : 'Gift / Sample',
        desc: isAR ? 'منح الصنف مجاناً للزبون بسعر 0$ وخصم الكمية من المخزون' : 'Complimentary gift item given to customer at $0',
        badge: isAR ? '🔐 تصريح المشرف' : '🔐 Supervisor Required',
        border: '#dc2626',
        activeBorder: '#dc2626'
      }
    ];

    const modalEl = document.createElement('div');
    modalEl.id = 'pos-line-type-modal';
    modalEl.className = 'modal-overlay open';
    modalEl.style.zIndex = '99999';
    modalEl.innerHTML = `
      <div class="modal" style="max-width:500px;border-radius:14px;background:var(--pos-surface);border:1.5px solid var(--pos-border);box-shadow:0 25px 50px rgba(0,0,0,0.5)">
        <div class="modal-header" style="border-bottom:1px solid var(--pos-border);padding:14px 18px;display:flex;justify-content:space-between;align-items:center">
          <div>
            <div class="modal-title" style="font-weight:900;font-size:1.1rem;display:flex;align-items:center;gap:8px;color:var(--pos-text-main)">
              <span>🏷️</span>
              <span>${isAR ? 'تحديد نوع حركة الصنف' : 'Select Item Movement Type'}</span>
            </div>
            <div style="font-size:0.8rem;color:var(--pos-text-muted);margin-top:2px">
              ${Utils.sanitize(itemName)} (${item.qty} × ${Utils.formatCurrency(item.price)})
            </div>
          </div>
          <button class="btn-icon" onclick="document.getElementById('pos-line-type-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:16px;display:flex;flex-direction:column;gap:10px">
          ${options.map(opt => {
            const isCurrent = (curType === opt.id);
            return `
            <div onclick="POS.setLineType(${idx}, '${opt.id}')" style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-radius:10px;border:2px solid ${isCurrent ? '#dc2626' : 'var(--pos-border)'};background:${isCurrent ? 'rgba(220, 38, 38, 0.08)' : 'var(--pos-bg)'};cursor:pointer;transition:all 0.15s ease" onmouseover="this.style.borderColor='#dc2626'" onmouseout="if(!${isCurrent}) this.style.borderColor='var(--pos-border)'">
              <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:1.4rem">${opt.icon}</span>
                <div>
                  <div style="font-weight:800;font-size:0.92rem;color:var(--pos-text-main)">
                    ${opt.title}
                    ${isCurrent ? `<span class="badge" style="background:#dc2626;color:white;font-size:0.65rem;margin-inline-start:6px;border-radius:6px;padding:2px 6px">${isAR ? 'الحالي' : 'Active'}</span>` : ''}
                  </div>
                  <div style="font-size:0.75rem;color:var(--pos-text-muted);margin-top:2px">${opt.desc}</div>
                </div>
              </div>
              <div style="text-align:end">
                <span style="font-size:0.72rem;font-weight:800;color:${opt.id === 'sale' ? 'var(--pos-text-muted)' : '#ef4444'}">${opt.badge}</span>
              </div>
            </div>`;
          }).join('')}
        </div>
        <div class="modal-footer" style="border-top:1px solid var(--pos-border);padding:12px 18px;display:flex;justify-content:space-between;align-items:center">
          <div>
            ${isAdmin ? `
            <button type="button" class="btn btn-ghost btn-xs" onclick="POS.openSetMasterPasswordModal()" style="font-size:0.75rem;color:#ef4444;font-weight:700">
              🔑 ${isAR ? 'تعديل كلمة مرور المشرف' : 'Change Master Password'}
            </button>` : ''}
          </div>
          <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('pos-line-type-modal').remove()">
            ${isAR ? 'إلغاء' : 'Cancel'}
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(modalEl);
  }

  async function openSetMasterPasswordModal() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items') || Auth.can('pos.returns') || Auth.can('returns')));

    if (!isAdmin) {
      const authorized = await promptAdminAuthModal(isAR ? 'يرجى إدخال كلمة المرور الحالية للمشرف لتعديل كلمة المرور الرئيسية:' : 'Enter current Supervisor Password to modify Master Password:');
      if (!authorized) return;
    }

    const currentSavedPin = (await DB.getSetting('pos_master_password', '') || await DB.getSetting('return_auth_pin', '1234') || '1234');

    const modalId = 'pos-set-master-pwd-modal';
    document.getElementById(modalId)?.remove();

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal-overlay open';
    modalEl.style.zIndex = '999999';
    modalEl.innerHTML = `
      <div class="modal" style="max-width:420px;border-radius:14px;background:var(--surface);border:1.5px solid var(--border-color);box-shadow:0 20px 40px rgba(0,0,0,0.5)">
        <div class="modal-header" style="border-bottom:1px solid var(--border-color);padding:14px 18px;display:flex;justify-content:space-between;align-items:center">
          <div class="modal-title" style="font-weight:800;display:flex;align-items:center;gap:8px">
            <span>🔑</span>
            <span>${isAR ? 'تعيين كلمة المرور الرئيسية للمشرف' : 'Set Admin Master Password'}</span>
          </div>
          <button class="btn-icon" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:18px">
          <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:14px">
            ${isAR 
              ? 'تُستخدم هذه الكلمة لتفويض الكاشير العادي عند محاولة إرجاع صنف، تسجيل تالف، منح هدية، أو تعديل السعر.' 
              : 'This Master Password authorizes cashiers to perform Returns, Damaged items, Free gifts, and Price overrides.'}
          </p>
          <div class="form-group" style="margin-bottom:14px">
            <label class="form-label" style="font-weight:700;font-size:0.85rem">${isAR ? 'كلمة المرور / PIN الجديد:' : 'New Master Password / PIN:'}</label>
            <input type="password" id="new-master-pin" class="form-control" value="${Utils.sanitize(currentSavedPin)}" style="font-size:1.1rem;font-weight:800;letter-spacing:2px;text-align:center" placeholder="1234">
          </div>
          <div class="form-group" style="margin-bottom:10px">
            <label class="form-label" style="font-weight:700;font-size:0.85rem">${isAR ? 'تأكيد كلمة المرور / PIN:' : 'Confirm Password / PIN:'}</label>
            <input type="password" id="confirm-master-pin" class="form-control" value="${Utils.sanitize(currentSavedPin)}" style="font-size:1.1rem;font-weight:800;letter-spacing:2px;text-align:center" placeholder="1234">
          </div>
          <div id="master-pin-err" style="color:#ef4444;font-size:0.8rem;font-weight:700;display:none;margin-top:6px"></div>
        </div>
        <div class="modal-footer" style="border-top:1px solid var(--border-color);padding:12px 18px;display:flex;justify-content:space-between">
          <button type="button" class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button type="button" class="btn btn-primary" id="save-master-pin-btn" style="font-weight:800;background:#0284c7;border-color:#0369a1">${isAR ? 'حفظ كلمة المرور' : 'Save Password'}</button>
        </div>
      </div>
    `;
    document.body.appendChild(modalEl);

    const newPinInput = document.getElementById('new-master-pin');
    const confirmPinInput = document.getElementById('confirm-master-pin');
    const errEl = document.getElementById('master-pin-err');
    const saveBtn = document.getElementById('save-master-pin-btn');

    setTimeout(() => newPinInput?.focus(), 50);

    saveBtn.onclick = async () => {
      const p1 = (newPinInput?.value || '').trim();
      const p2 = (confirmPinInput?.value || '').trim();

      if (!p1) {
        errEl.textContent = isAR ? '⚠️ يرجى إدخال كلمة المرور' : '⚠️ Password cannot be empty';
        errEl.style.display = 'block';
        return;
      }
      if (p1 !== p2) {
        errEl.textContent = isAR ? '⚠️ كلمتا المرور غير متطابقتين' : '⚠️ Passwords do not match';
        errEl.style.display = 'block';
        return;
      }

      await DB.setSetting('pos_master_password', p1);
      await DB.setSetting('return_auth_pin', p1);

      modalEl.remove();
      Utils.toast(isAR ? '✅ تم حفظ كلمة المرور الرئيسية للمشرف بنجاح' : '✅ Supervisor Master Password saved successfully', 'success');
    };
  }

  function removeFromCart(idx) {
    _cart.splice(idx, 1);
    renderCart();
    updateTotals();
  }

  async function updateQty(idx, delta) {
    const item = _cart[idx];
    if (!item) return;
    const targetQty = Utils.round(item.qty + delta, 3);
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;

    if (delta > 0 && (item.line_type || 'sale') === 'sale' && !_settings.allowNegativeStock) {
      const itm = await DB.get('items', item.item_id);
      const whId = window._posWarehouseId || 1;
      const currentStock = (itm && itm.warehouse_stocks && itm.warehouse_stocks[whId] !== undefined)
        ? (parseFloat(itm.warehouse_stocks[whId]) || 0)
        : (parseFloat(itm?.stock_qty) || 0);
      if (targetQty > currentStock) {
        Utils.toast(isAR ? `⚠️ لا يتوفر سوى ${currentStock} في المخزون` : (i18n.t('pos.insufficient_stock') || 'Insufficient stock!'), 'warning');
        return;
      }
    }
    item.qty = Math.max(0.001, targetQty);
    _recalcLineTotal(item);
    renderCart();
    updateTotals();
  }

  async function setQty(idx, val) {
    const item = _cart[idx];
    if (!item) return;
    const targetQty = Math.max(0.001, parseFloat(val) || 0.001);
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;

    if ((item.line_type || 'sale') === 'sale' && !_settings.allowNegativeStock) {
      const itm = await DB.get('items', item.item_id);
      const whId = window._posWarehouseId || 1;
      const currentStock = (itm && itm.warehouse_stocks && itm.warehouse_stocks[whId] !== undefined)
        ? (parseFloat(itm.warehouse_stocks[whId]) || 0)
        : (parseFloat(itm?.stock_qty) || 0);
      if (targetQty > currentStock) {
        Utils.toast(isAR ? `⚠️ لا يتوفر سوى ${currentStock} في المخزون` : (i18n.t('pos.insufficient_stock') || 'Insufficient stock!'), 'warning');
        item.qty = Math.max(0.001, currentStock);
        _recalcLineTotal(item);
        renderCart();
        updateTotals();
        return;
      }
    }
    item.qty = targetQty;
    _recalcLineTotal(item);
    renderCart();
    updateTotals();
  }

  function _updateLineTotalDOM(idx) {
    const c = _cart[idx];
    if (!c) return;
    const isNeg = c.line_type === 'return';
    const isZero = c.line_type === 'damage' || c.line_type === 'gift';
    const origTotal = Utils.round((c.qty || 1) * (c.price || 0));
    const hasDisc = (c.line_type === 'sale') && (origTotal > (c.total || 0) + 0.001);

    const innerHtml = `<div>${isZero ? Utils.formatCurrency(0) : Utils.formatCurrency(c.total || 0)}</div>
      ${hasDisc && !isZero && !isNeg ? `<div style="font-size:0.68rem;text-decoration:line-through;color:var(--text-muted);font-weight:normal">${Utils.formatCurrency(origTotal)}</div>` : ''}`;

    const cell = document.getElementById(`cart-line-total-${idx}`);
    if (cell) {
      cell.innerHTML = innerHtml;
      cell.style.color = isZero ? 'var(--text-muted)' : (isNeg ? 'var(--warning)' : 'var(--text-primary)');
    }
    const cardCell = document.getElementById(`cart-card-total-${idx}`);
    if (cardCell) {
      cardCell.innerHTML = innerHtml;
      cardCell.style.color = isZero ? 'var(--text-muted)' : (isNeg ? 'var(--warning)' : 'var(--text-primary)');
    }
  }

  function updateItemDisc(idx, val, type = null) {
    const item = _cart[idx];
    if (!item) return;
    if (type) item.disc_type = type;
    const num = Math.max(0, parseFloat(val) || 0);
    if (item.disc_type === 'amt') {
      item.disc_amt = num;
    } else {
      item.disc_pct = Math.min(100, num);
    }
    _recalcLineTotal(item);
    _updateLineTotalDOM(idx);
    updateTotals();
  }

  function toggleLineDiscType(idx) {
    const item = _cart[idx];
    if (!item) return;
    item.disc_type = item.disc_type === 'amt' ? 'pct' : 'amt';
    _recalcLineTotal(item);
    renderCart();
    updateTotals();
  }

  // ── Draggable Cart Resizer Divider Logic ──
  function initCartResizer() {
    const resizer = document.getElementById('pos-resizer');
    const cartPanel = document.getElementById('pos-cart-panel');
    if (!resizer || !cartPanel) return;

    // Restore saved width from localStorage (fallback 420px)
    const savedW = parseInt(localStorage.getItem('pos_cart_width'), 10);
    if (savedW && savedW >= 300 && savedW <= 950) {
      document.documentElement.style.setProperty('--pos-cart-w', `${savedW}px`);
      cartPanel.style.width = `${savedW}px`;
    }

    let isDragging = false;
    let startX = 0;
    let startW = 0;

    function onPointerDown(e) {
      isDragging = true;
      startX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
      startW = cartPanel.offsetWidth;
      resizer.classList.add('is-dragging');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';

      window.addEventListener('mousemove', onPointerMove);
      window.addEventListener('mouseup', onPointerUp);
      window.addEventListener('touchmove', onPointerMove, { passive: false });
      window.addEventListener('touchend', onPointerUp);
    }

    function onPointerMove(e) {
      if (!isDragging) return;
      const clientX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
      const isRTL = document.body.getAttribute('dir') === 'rtl' || document.documentElement.dir === 'rtl';
      // In LTR: dragging left increases cart panel width (since cart is on the right)
      // In RTL: dragging right increases cart panel width (cart on the left)
      const deltaX = isRTL ? (clientX - startX) : (startX - clientX);
      const minW = 300;
      const maxW = Math.min(950, Math.floor(window.innerWidth * 0.80));
      const newW = Math.max(minW, Math.min(maxW, startW + deltaX));

      document.documentElement.style.setProperty('--pos-cart-w', `${newW}px`);
      cartPanel.style.width = `${newW}px`;
      if (e.cancelable) e.preventDefault();
    }

    function onPointerUp() {
      if (!isDragging) return;
      isDragging = false;
      resizer.classList.remove('is-dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);

      const finalW = cartPanel.offsetWidth;
      localStorage.setItem('pos_cart_width', finalW);
      renderCart(); // Re-evaluate table vs card layout
    }

    // Double click to toggle wide / standard width
    function onDoubleClick() {
      const curW = cartPanel.offsetWidth;
      const targetW = curW > 500 ? 400 : 680;
      document.documentElement.style.setProperty('--pos-cart-w', `${targetW}px`);
      cartPanel.style.width = `${targetW}px`;
      localStorage.setItem('pos_cart_width', targetW);
      renderCart();
    }

    resizer.onmousedown = onPointerDown;
    resizer.ontouchstart = onPointerDown;
    resizer.ondblclick = onDoubleClick;
  }

  // ── Draggable Cart Bottom Up/Down Resizer Logic ──
  function initBottomResizer() {
    const resizer = document.getElementById('pos-cart-bottom-resizer');
    const bottomGrid = document.getElementById('pos-cart-bottom-grid');
    if (!resizer || !bottomGrid) return;

    // Restore saved height (fallback 230px)
    const savedH = parseInt(localStorage.getItem('pos_cart_bottom_h'), 10);
    if (savedH && savedH >= 150 && savedH <= 480) {
      bottomGrid.style.height = `${savedH}px`;
    }

    let isDragging = false;
    let startY = 0;
    let startH = 0;

    function onPointerDown(e) {
      isDragging = true;
      startY = e.clientY || (e.touches && e.touches[0] ? e.touches[0].clientY : 0);
      startH = bottomGrid.offsetHeight;
      resizer.classList.add('is-dragging');
      document.body.style.cursor = 'row-resize';
      document.body.style.userSelect = 'none';

      window.addEventListener('mousemove', onPointerMove);
      window.addEventListener('mouseup', onPointerUp);
      window.addEventListener('touchmove', onPointerMove, { passive: false });
      window.addEventListener('touchend', onPointerUp);
    }

    function onPointerMove(e) {
      if (!isDragging) return;
      const clientY = e.clientY || (e.touches && e.touches[0] ? e.touches[0].clientY : 0);
      // Dragging upward increases bottom height
      const deltaY = startY - clientY;
      const minH = 150;
      const maxH = Math.min(500, Math.floor(window.innerHeight * 0.70));
      const newH = Math.max(minH, Math.min(maxH, startH + deltaY));

      bottomGrid.style.height = `${newH}px`;
      if (e.cancelable) e.preventDefault();
    }

    function onPointerUp() {
      if (!isDragging) return;
      isDragging = false;
      resizer.classList.remove('is-dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);

      localStorage.setItem('pos_cart_bottom_h', bottomGrid.offsetHeight);
    }

    resizer.onmousedown = onPointerDown;
    resizer.ontouchstart = onPointerDown;
  }

  // ── Draggable Numpad Width Left/Right Resizer Logic ──
  function initNumpadResizer() {
    const resizer = document.getElementById('pos-numpad-v-resizer');
    const numpadWrap = document.getElementById('pos-touch-numpad-wrap');
    if (!resizer || !numpadWrap) return;

    // Restore saved width (fallback 160px)
    const savedW = parseInt(localStorage.getItem('pos_numpad_w'), 10);
    if (savedW && savedW >= 110 && savedW <= 350) {
      numpadWrap.style.width = `${savedW}px`;
    }

    let isDragging = false;
    let startX = 0;
    let startW = 0;

    function onPointerDown(e) {
      isDragging = true;
      startX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
      startW = numpadWrap.offsetWidth;
      resizer.classList.add('is-dragging');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';

      window.addEventListener('mousemove', onPointerMove);
      window.addEventListener('mouseup', onPointerUp);
      window.addEventListener('touchmove', onPointerMove, { passive: false });
      window.addEventListener('touchend', onPointerUp);
    }

    function onPointerMove(e) {
      if (!isDragging) return;
      const clientX = e.clientX || (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
      const isRTL = document.body.getAttribute('dir') === 'rtl' || document.documentElement.dir === 'rtl';
      // In RTL numpad is at the start (right), dragging left increases width
      // In LTR numpad is at the start (left), dragging right increases width
      const deltaX = isRTL ? (startX - clientX) : (clientX - startX);
      const minW = 110;
      const maxW = 360;
      const newW = Math.max(minW, Math.min(maxW, startW + deltaX));

      numpadWrap.style.width = `${newW}px`;
      if (e.cancelable) e.preventDefault();
    }

    function onPointerUp() {
      if (!isDragging) return;
      isDragging = false;
      resizer.classList.remove('is-dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';

      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);

      localStorage.setItem('pos_numpad_w', numpadWrap.offsetWidth);
    }

    resizer.onmousedown = onPointerDown;
    resizer.ontouchstart = onPointerDown;
  }

  function toggleCartLayout() {
    const current = _settings.cartLayoutMode || 'auto';
    let nextMode = 'auto';
    if (current === 'auto') nextMode = 'table';
    else if (current === 'table') nextMode = 'cards';
    else nextMode = 'auto';

    _settings.cartLayoutMode = nextMode;
    localStorage.setItem('pos_cart_layout_mode', nextMode);
    renderCart();

    const isAR = i18n.getLang() === 'ar';
    const modeLabel = nextMode === 'table' ? (isAR ? 'جدول مفصل' : 'Table') : (nextMode === 'cards' ? (isAR ? 'بطاقات مدمجة' : 'Cards') : (isAR ? 'تلقائي حسب العرض' : 'Automatic'));
    Utils.toast(isAR ? `تم تغيير نمط السلة إلى: ${modeLabel}` : `Cart layout set to: ${modeLabel}`, 'info');
  }

  function renderCart() {
    const isAR = i18n.getLang() === 'ar';
    const cartEl   = document.getElementById('pos-cart-items');
    const emptyEl  = document.getElementById('cart-empty');
    const countEl  = document.getElementById('cart-count');
    const layoutBtn = document.getElementById('pos-cart-layout-btn');

    if (countEl) countEl.textContent = _cart.length;

    if (!_cart.length) {
      if (cartEl) {
        cartEl.innerHTML = '';
        if (emptyEl) cartEl.appendChild(emptyEl);
        if (emptyEl) emptyEl.style.display = '';
      }
      return;
    }
    if (emptyEl) emptyEl.style.display = 'none';

    const badges = {
      sale:   { label: isAR ? '🛒 بيع' : '🛒 Sale',     bg: '#1e293b', color: '#ffffff', border: '#334155' },
      return: { label: isAR ? '↩️ إرجاع' : '↩️ Return', bg: '#dc2626', color: '#ffffff', border: '#b91c1c' },
      damage: { label: isAR ? '⚠️ تالف' : '⚠️ Damage', bg: '#0f172a', color: '#ffffff', border: '#dc2626' },
      gift:   { label: isAR ? '🎁 هدية' : '🎁 Gift',   bg: 'rgba(220, 38, 38, 0.12)', color: '#dc2626', border: 'rgba(220, 38, 38, 0.35)' }
    };

    const cartPanel = document.getElementById('pos-cart-panel');
    const panelWidth = cartPanel ? cartPanel.offsetWidth : 380;
    const mode = _settings.cartLayoutMode || 'auto';
    const useTable = (mode === 'table') || (mode === 'auto' && panelWidth >= 460);

    if (layoutBtn) {
      layoutBtn.innerHTML = useTable ? '💳' : '📋';
      layoutBtn.title = isAR
        ? (useTable ? 'التبديل إلى عرض البطاقات المدمجة' : 'التبديل إلى عرض الجدول المفصل')
        : (useTable ? 'Switch to Compact Cards View' : 'Switch to Detailed Table View');
    }

    const cols = Object.assign({}, DEFAULT_CART_COLUMNS, _settings.cartColumns || {});

    // ── 1. Table Presentation Mode ──
    if (useTable) {
      let ths = '';
      if (cols.col_code) ths += `<th style="width:75px">${isAR ? 'الكود' : 'Code'}</th>`;
      if (cols.col_name) ths += `<th>${isAR ? 'الصنف / الوصف' : 'Description'}</th>`;
      if (cols.col_unit) ths += `<th style="width:45px;text-align:center">${isAR ? 'الوحدة' : 'Unit'}</th>`;
      if (cols.col_cost) ths += `<th style="width:65px;text-align:end">${isAR ? 'التكلفة' : 'Cost'}</th>`;
      if (cols.col_price) ths += `<th style="width:75px;text-align:end">${isAR ? 'السعر' : 'Price'}</th>`;
      if (cols.col_qty) ths += `<th style="width:95px;text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>`;
      if (cols.col_disc) ths += `<th style="width:65px;text-align:center">${isAR ? 'خصم' : 'Disc'}</th>`;
      if (cols.col_vat) ths += `<th style="width:45px;text-align:center">${isAR ? 'ضريبة' : 'VAT'}</th>`;
      if (cols.col_total) ths += `<th style="width:85px;text-align:end">${isAR ? 'الإجمالي' : 'Total'}</th>`;
      if (cols.col_actions) ths += `<th style="width:65px;text-align:center">${isAR ? 'إجراء' : 'Act'}</th>`;

      let trs = _cart.map((c, idx) => {
        const name = isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar);
        const bInfo = badges[c.line_type || 'sale'] || badges.sale;
        let tds = '';

        if (cols.col_code) {
          tds += `<td style="font-size:0.7rem;color:var(--text-muted);font-family:monospace">${Utils.sanitize(c.item_code || '-')}</td>`;
        }
        if (cols.col_name) {
          const isTaxable = isCartItemTaxable(c);
          const taxMark = isTaxable ? `<span style="color:#ef4444;font-weight:900;margin-inline-start:3px;font-size:1.1em" title="${isAR ? 'خاضع لضريبة القيمة المضافة (TVA)' : 'TVA Taxable'}">*</span>` : '';
          tds += `<td>
            <div style="font-weight:700;font-size:0.8rem;line-height:1.2;display:flex;align-items:center;gap:5px">
              <button type="button" class="pos-line-type-btn" style="padding:2px 7px;font-size:0.68rem;border-radius:6px;font-weight:800;background:${bInfo.bg};color:${bInfo.color};border:1px solid ${bInfo.border};cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:3px" onclick="event.stopPropagation(); POS.openLineTypeModal(${idx})" title="${isAR?'انقر لتحديد نوع الصنف (بيع، إرجاع، تالف، هدية)':'Click to change item movement type'}">
                <span>${bInfo.label}</span> <span style="font-size:0.6rem;opacity:0.7">▾</span>
              </button>
              <span>${Utils.sanitize(name)}</span>${taxMark}
              ${c.sent_to_kitchen ? `<span class="badge" style="background:rgba(239,68,68,0.15);color:#ef4444;font-size:0.62rem">🍳 KOT</span>` : ''}
            </div>
            ${c.notes ? `<div style="font-size:0.7rem;color:#fca5a5;margin-top:2px">⤷ ${Utils.sanitize(c.notes)}</div>` : ''}
          </td>`;
        }
        if (cols.col_unit) {
          tds += `<td style="text-align:center;font-size:0.72rem;color:var(--text-secondary)">${Utils.sanitize(c.unit || '-')}</td>`;
        }
        if (cols.col_cost) {
          tds += `<td style="text-align:end;font-size:0.75rem;color:var(--text-muted)">${Utils.formatCurrency(c.cost_price || 0)}</td>`;
        }
        if (cols.col_price) {
          tds += `<td style="text-align:end;font-weight:700;font-size:0.8rem">
            <span class="pos-price-editable" onclick="event.stopPropagation(); POS.editLinePrice(${idx})" title="${isAR ? 'تعديل السعر (مشرف)' : 'Edit Price (Admin)'}">
              ${Utils.formatCurrency(c.price || 0)} <span style="font-size:0.65rem;opacity:0.6">✏️</span>
            </span>
          </td>`;
        }
        if (cols.col_qty) {
          tds += `<td style="text-align:center">
            <div style="display:inline-flex;align-items:center;gap:3px">
              <button type="button" class="pos-cart-stepper-btn" onclick="event.stopPropagation(); POS.updateQty(${idx},-1)">-</button>
              <input type="number" value="${c.qty}" min="0.001" step="any" onclick="event.stopPropagation(); POS.selectCartItemForNumpad(${idx}, 'qty'); this.select();" onfocus="this.select()" style="width:46px;text-align:center;padding:2px 1px;background:var(--pos-input-bg);border:1.5px solid var(--pos-input-border);border-radius:6px;color:var(--pos-text-main);font-size:0.84rem;font-weight:800;height:26px" onchange="POS.setQty(${idx},this.value)">
              <button type="button" class="pos-cart-stepper-btn" onclick="event.stopPropagation(); POS.updateQty(${idx},1)">+</button>
            </div>
          </td>`;
        }
        if (cols.col_disc) {
          const isAmt = c.disc_type === 'amt';
          tds += `<td style="text-align:center">
            <div style="display:inline-flex;align-items:center;gap:2px">
              <input type="number" id="cart-item-disc-${idx}" value="${isAmt ? (c.disc_amt || 0) : (c.disc_pct || 0)}" min="0" ${isAmt ? '' : 'max="100"'} step="any" onclick="event.stopPropagation(); POS.selectCartItemForNumpad(${idx}, 'disc'); this.select();" onfocus="this.select()" style="width:40px;text-align:center;padding:2px 1px;background:var(--pos-input-bg);border:1.5px solid var(--pos-input-border);border-radius:6px;color:var(--pos-text-main);font-size:0.78rem;font-weight:700;height:26px" oninput="POS.updateItemDisc(${idx},this.value)">
              <button type="button" class="btn btn-xs btn-ghost" style="padding:0 3px;font-size:0.68rem;height:24px;line-height:1;border:1px solid var(--border-color);border-radius:4px;font-weight:700" onclick="event.stopPropagation(); POS.toggleLineDiscType(${idx})" title="${isAR ? 'تبديل بين % والمبلغ' : 'Toggle % / Amount'}">${isAmt ? (_settings.currency1 || '$') : '%'}</button>
            </div>
          </td>`;
        }
        if (cols.col_vat) {
          tds += `<td style="text-align:center;font-size:0.7rem;color:var(--text-muted)">${c.vat_type === 'exempt' ? '0%' : (_settings.vatEnabled ? `${_settings.vatRate}%` : '-')}</td>`;
        }
        if (cols.col_total) {
          const isNeg = c.line_type === 'return';
          const isZero = c.line_type === 'damage' || c.line_type === 'gift';
          const origTotal = Utils.round((c.qty || 1) * (c.price || 0));
          const hasDisc = (c.line_type === 'sale') && (origTotal > (c.total || 0) + 0.001);
          tds += `<td id="cart-line-total-${idx}" style="text-align:end;font-weight:800;font-size:0.83rem;color:${isZero ? 'var(--text-muted)' : (isNeg ? '#ef4444' : 'var(--pos-text-main)')}">
            <div>${isZero ? Utils.formatCurrency(0) : Utils.formatCurrency(c.total || 0)}</div>
            ${hasDisc && !isZero && !isNeg ? `<div style="font-size:0.68rem;text-decoration:line-through;color:var(--text-muted);font-weight:normal">${Utils.formatCurrency(origTotal)}</div>` : ''}
          </td>`;
        }
        if (cols.col_actions) {
          tds += `<td style="text-align:center">
            <div style="display:inline-flex;align-items:center;gap:2px">
              <button class="btn-icon" onclick="event.stopPropagation(); POS.openItemNoteModal(${idx})" style="padding:2px;font-size:0.85rem;color:var(--pos-text-muted)" title="${isAR ? 'ملاحظات وتفضيلات الصنف' : 'Item Notes & Modifiers'}">📝</button>
              <button class="btn-icon" onclick="event.stopPropagation(); POS.removeFromCart(${idx})" style="padding:2px;font-size:0.85rem;color:#ef4444" title="${isAR ? 'حذف' : 'Remove'}">✕</button>
            </div>
          </td>`;
        }

        const isSelected = (_posSelectedCartIndex === idx);
        return `<tr class="${isSelected ? 'pos-cart-item-selected' : ''}" style="cursor:pointer" onclick="POS.selectCartItemForNumpad(${idx})">${tds}</tr>`;
      }).join('');

      cartEl.innerHTML = `
        <div class="pos-cart-table-wrap">
          <table class="pos-cart-table">
            <thead><tr>${ths}</tr></thead>
            <tbody>${trs}</tbody>
          </table>
        </div>
      `;
      _updateNumpadHeader();
      _highlightSelectedCartRow();
      return;
    }

    // ── 2. Compact Cards Presentation Mode ──
    cartEl.innerHTML = _cart.map((c, idx) => {
      const name = isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar);
      const bInfo = badges[c.line_type || 'sale'] || badges.sale;
      const isAmt = c.disc_type === 'amt';
      const origTotal = Utils.round((c.qty || 1) * (c.price || 0));
      const hasDisc = (c.line_type === 'sale') && (origTotal > (c.total || 0) + 0.001);
      const isTaxable = isCartItemTaxable(c);
      const taxMark = isTaxable ? `<span style="color:#ef4444;font-weight:900;margin-inline-start:3px;font-size:1.1em" title="${isAR ? 'خاضع لضريبة القيمة المضافة (TVA)' : 'TVA Taxable'}">*</span>` : '';
      const isSelected = (_posSelectedCartIndex === idx);
      return `
      <div class="${isSelected ? 'pos-cart-item-selected' : ''}" style="cursor:pointer;padding:8px;border-bottom:1px solid var(--pos-border);display:flex;flex-direction:column;gap:5px;border-radius:8px" onclick="POS.selectCartItemForNumpad(${idx})">
        <div style="display:flex;align-items:center;justify-content:space-between">
          <div style="font-size:0.8rem;font-weight:600;flex:1;line-height:1.3;display:flex;align-items:center;gap:6px">
            <button type="button" class="pos-line-type-btn" style="padding:2px 8px;font-size:0.68rem;border-radius:6px;font-weight:800;background:${bInfo.bg};color:${bInfo.color};border:1px solid ${bInfo.border};cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;gap:3px" onclick="event.stopPropagation(); POS.openLineTypeModal(${idx})" title="${isAR?'انقر لتحديد نوع الصنف (بيع، إرجاع، تالف، هدية)':'Click to change item movement type'}">
              <span>${bInfo.label}</span> <span style="font-size:0.6rem;opacity:0.7">▾</span>
            </button>
            <span>${Utils.sanitize(Utils.truncate(name, 24))}</span>${taxMark}
            ${cols.col_code && c.item_code ? `<span style="font-size:0.68rem;color:var(--text-muted);font-family:monospace">[${Utils.sanitize(c.item_code)}]</span>` : ''}
            ${c.sent_to_kitchen ? `<span class="badge" style="background:rgba(239,68,68,0.15);color:#ef4444;font-size:0.65rem">🍳 KOT</span>` : ''}
          </div>
          <div style="display:flex;align-items:center;gap:2px">
            <button class="btn-icon" onclick="event.stopPropagation(); POS.openItemNoteModal(${idx})" style="padding:2px;color:var(--pos-text-muted)" title="${isAR ? 'ملاحظات وتفضيلات الصنف' : 'Item Notes & Modifiers'}">
              📝
            </button>
            <button class="btn-icon" onclick="event.stopPropagation(); POS.removeFromCart(${idx})" style="padding:2px;color:#ef4444">
              ✕
            </button>
          </div>
        </div>
        ${c.notes ? `<div style="font-size:0.73rem;color:#fca5a5;margin-inline-start:6px">⤷ ${Utils.sanitize(c.notes)}</div>` : ''}
        <div style="display:flex;align-items:center;justify-content:space-between;font-size:0.78rem">
          <div style="display:flex;align-items:center;gap:4px">
            <button type="button" class="pos-cart-stepper-btn" onclick="event.stopPropagation(); POS.updateQty(${idx},-1)">-</button>
            <input type="number" value="${c.qty}" min="0.001" step="any" onclick="event.stopPropagation(); POS.selectCartItemForNumpad(${idx}, 'qty'); this.select();" onfocus="this.select()" style="width:52px;text-align:center;padding:2px;background:var(--pos-input-bg);border:1.5px solid var(--pos-input-border);border-radius:6px;color:var(--pos-text-main);font-size:0.84rem;font-weight:800;height:28px" onchange="POS.setQty(${idx},this.value)">
            <button type="button" class="pos-cart-stepper-btn" onclick="event.stopPropagation(); POS.updateQty(${idx},1)">+</button>
            ${cols.col_unit && c.unit ? `<span style="font-size:0.7rem;color:var(--text-secondary)">${Utils.sanitize(c.unit)}</span>` : ''}
          </div>
          ${cols.col_cost ? `<div style="font-size:0.7rem;color:var(--text-muted)">Cost:${Utils.formatCurrency(c.cost_price||0)}</div>` : ''}
          ${cols.col_price ? `<div style="font-size:0.75rem;font-weight:600">
            <span class="pos-price-editable" onclick="event.stopPropagation(); POS.editLinePrice(${idx})" title="${isAR ? 'تعديل السعر (مشرف)' : 'Edit Price (Admin)'}">
              ${Utils.formatCurrency(c.price||0)} <span style="font-size:0.65rem;opacity:0.6">✏️</span>
            </span>
          </div>` : ''}
          ${cols.col_disc ? `
          <div style="display:flex;align-items:center;gap:2px">
            <span style="font-size:0.7rem;color:var(--text-muted)">${isAR?'خصم':'Disc'}</span>
            <input type="number" id="cart-card-disc-${idx}" value="${isAmt ? (c.disc_amt || 0) : (c.disc_pct || 0)}" min="0" ${isAmt ? '' : 'max="100"'} step="any" onclick="event.stopPropagation(); POS.selectCartItemForNumpad(${idx}, 'disc'); this.select();" onfocus="this.select()" style="width:38px;text-align:center;padding:1px;background:var(--pos-input-bg);border:1.5px solid var(--pos-input-border);border-radius:6px;color:var(--pos-text-main);font-size:0.78rem;font-weight:700;height:24px" oninput="POS.updateItemDisc(${idx},this.value)">
            <button type="button" class="btn btn-xs btn-ghost" style="padding:0 2px;font-size:0.65rem;height:22px;border:1px solid var(--border-color);border-radius:4px;font-weight:700" onclick="event.stopPropagation(); POS.toggleLineDiscType(${idx})" title="${isAR ? 'تبديل بين % والمبلغ' : 'Toggle % / Amount'}">${isAmt ? (_settings.currency1 || '$') : '%'}</button>
          </div>` : ''}
          <div id="cart-card-total-${idx}" style="font-weight:800;font-size:0.85rem;color:${c.line_type==='damage'||c.line_type==='gift'?'var(--text-muted)':c.line_type==='return'?'#ef4444':'var(--pos-text-main)'}">
            <div>${c.line_type==='damage'||c.line_type==='gift'?Utils.formatCurrency(0):Utils.formatCurrency(c.total||0)}</div>
            ${hasDisc && c.line_type==='sale' ? `<div style="font-size:0.68rem;text-decoration:line-through;color:var(--text-muted);font-weight:normal">${Utils.formatCurrency(origTotal)}</div>` : ''}
          </div>
        </div>
      </div>`;
    }).join('');
    _updateNumpadHeader();
    _highlightSelectedCartRow();
  }

  function clearCart() {
    if (!_cart.length) return;
    Utils.confirm(
      i18n.t('common.confirm_delete'),
      () => { _cart = []; _customer = null; renderCart(); updateTotals(); }
    );
  }

  // ── Persistent Held Sales Management ──
  function _loadHeldFromStorage() {
    try {
      const saved = localStorage.getItem('redshark_pos_held_sales');
      if (saved) {
        _held = JSON.parse(saved) || [];
      } else {
        _held = [];
      }
    } catch(e) {
      _held = [];
    }
  }

  function _saveHeldToStorage() {
    try {
      localStorage.setItem('redshark_pos_held_sales', JSON.stringify(_held || []));
    } catch(e) {}
  }

  function updateHeldUI() {
    const resumeBtn = document.getElementById('pos-resume-btn');
    const badge = document.getElementById('pos-held-count-badge');
    if (!resumeBtn) return;
    if (_held && _held.length > 0) {
      resumeBtn.style.display = 'inline-flex';
      if (badge) badge.textContent = _held.length;
    } else {
      resumeBtn.style.display = 'none';
      if (badge) badge.textContent = '0';
    }
  }

  function holdSale() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (!_cart || !_cart.length) {
      Utils.toast(isAR ? '⚠️ السلة فارغة، لا يوجد فاتورة لتعليقها' : '⚠️ Cart is empty, nothing to hold', 'warning');
      return;
    }

    const customerName = _customer ? (_customer.name_ar || _customer.name_en || _customer.name || `Customer #${_customer.id}`) : (isAR ? 'عميل عابر' : 'Walk-in');
    const totalAmt = window._posGrandTotal || _cart.reduce((s, c) => s + (c.total || 0), 0);
    const now = new Date();

    _held.push({
      id: Date.now(),
      cart: JSON.parse(JSON.stringify(_cart)),
      customer: _customer ? { ..._customer } : null,
      customerName: customerName,
      total: totalAmt,
      time: now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      date: now.toLocaleDateString('en-GB'),
      itemsCount: _cart.reduce((s, c) => s + (parseFloat(c.qty) || 1), 0)
    });
    _saveHeldToStorage();

    _cart = [];
    _customer = null;
    _posSelectedCartIndex = -1;
    selectCustomerOption(null);
    renderCart();
    updateTotals();
    updateHeldUI();
    Utils.toast(isAR ? `⏸ تم تعليق الفاتورة بنجاح (${_held.length} فواتير معلقة)` : `⏸ Invoice put on hold (${_held.length} held)`, 'info');
  }

  function resumeHeldSale() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (!_held || !_held.length) {
      Utils.toast(isAR ? 'لا توجد فواتير معلقة' : 'No held invoices', 'warning');
      updateHeldUI();
      return;
    }

    if (_held.length === 1 && (!_cart || _cart.length === 0)) {
      _restoreHeldDirectly(_held[0].id);
      return;
    }

    showHeldInvoicesModal();
  }

  function recallSale() {
    resumeHeldSale();
  }

  function showHeldInvoicesModal() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const modalId = 'pos-held-invoices-modal';
    document.getElementById(modalId)?.remove();

    if (!_held || !_held.length) {
      Utils.toast(isAR ? 'لا توجد فواتير معلقة حالياً' : 'No held invoices', 'warning');
      updateHeldUI();
      return;
    }

    const cur1 = _settings.currency1 || 'USD';

    const cardsHtml = _held.map((h, i) => {
      const itemsList = (h.cart || []).map(item => {
        const iName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
        return `<span style="display:inline-block;background:var(--pos-input-bg);border:1px solid var(--pos-border);padding:2px 6px;border-radius:4px;font-size:0.75rem;margin:2px;color:var(--pos-text-main)">${Utils.sanitize(iName)} × ${item.qty}</span>`;
      }).join(' ');

      return `
        <div style="background:var(--pos-surface-card);border:1.5px solid var(--pos-border);border-radius:10px;padding:12px 14px;margin-bottom:10px;box-shadow:0 4px 12px rgba(0,0,0,0.15)">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
            <div style="display:flex;align-items:center;gap:8px">
              <span class="badge" style="background:#ef4444;color:white;font-weight:900;padding:2px 8px;border-radius:6px;font-size:0.78rem">#${i + 1}</span>
              <strong style="color:var(--pos-text-main);font-size:0.9rem">👤 ${Utils.sanitize(h.customerName || (isAR ? 'عميل عابر' : 'Walk-in'))}</strong>
            </div>
            <div style="font-size:0.78rem;color:var(--pos-text-muted)">
              🕒 ${h.time || ''} ${h.date ? `(${h.date})` : ''}
            </div>
          </div>

          <div style="margin:8px 0;line-height:1.4">
            ${itemsList}
          </div>

          <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--pos-border);padding-top:8px;margin-top:8px">
            <div style="font-size:0.95rem;font-weight:900;color:#ef4444">
              ${cur1} ${Utils.formatCurrency(h.total || 0)}
              <span style="font-size:0.75rem;color:var(--pos-text-secondary);font-weight:normal">(${h.itemsCount || h.cart.length} ${isAR ? 'أصناف' : 'items'})</span>
            </div>
            <div style="display:flex;gap:6px">
              <button type="button" class="btn btn-secondary btn-sm" onclick="POS.deleteHeldInvoice(${h.id})" style="color:#ef4444;border-color:rgba(239,68,68,0.4);padding:5px 10px;font-size:0.78rem">
                🗑️ ${isAR ? 'حذف' : 'Discard'}
              </button>
              <button type="button" class="btn btn-primary btn-sm" onclick="POS.selectHeldInvoice(${h.id})" style="background:#ef4444;border-color:#dc2626;font-weight:800;padding:5px 14px;font-size:0.82rem">
                ▶ ${isAR ? 'استعادة الفاتورة' : 'Resume Invoice'}
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal-overlay open';
    modalEl.style.zIndex = '99999';
    modalEl.innerHTML = `
      <div class="modal" style="max-width:560px;width:95vw;max-height:85vh;display:flex;flex-direction:column;border-radius:12px;background:var(--pos-surface);border:1.5px solid var(--pos-border);box-shadow:0 20px 40px rgba(0,0,0,0.5)">
        <div class="modal-header" style="border-bottom:1px solid var(--pos-border);padding:14px 18px;display:flex;justify-content:space-between;align-items:center;flex-shrink:0">
          <div class="modal-title" style="font-weight:800;color:var(--pos-text-main);display:flex;align-items:center;gap:8px">
            <span style="font-size:1.2rem">⏸</span>
            <span>${isAR ? 'الفواتير المعلقة في الانتظار' : 'Held Invoices on Hold'}</span>
            <span class="badge" style="background:#ef4444;color:white;border-radius:10px;padding:2px 8px;font-size:0.75rem">${_held.length}</span>
          </div>
          <button class="btn-icon" onclick="document.getElementById('${modalId}')?.remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:16px;flex:1;overflow-y:auto">
          ${cardsHtml}
        </div>
        <div class="modal-footer" style="border-top:1px solid var(--pos-border);padding:12px 18px;display:flex;justify-content:space-between;flex-shrink:0">
          <button type="button" class="btn btn-ghost" onclick="document.getElementById('${modalId}')?.remove()">
            ${isAR ? 'إغلاق' : 'Close'}
          </button>
          <button type="button" class="btn btn-secondary" onclick="POS.clearAllHeldInvoices()" style="color:#ef4444;border-color:rgba(239,68,68,0.4)">
            🗑️ ${isAR ? 'حذف جميع المعلقات' : 'Clear All Held'}
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(modalEl);
  }

  function selectHeldInvoice(heldId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const targetIdx = _held.findIndex(h => h.id === heldId);
    if (targetIdx === -1) return;
    const targetHeld = _held[targetIdx];

    if (_cart && _cart.length > 0) {
      Utils.confirm(
        isAR ? 'السلة الحالية تحتوي على أصناف. هل تريد تعليق الفاتورة الحالية واستعادة هذه الفاتورة؟' : 'Current cart has items. Hold current ticket and resume this one?',
        () => {
          holdSale();
          _restoreHeldDirectly(targetHeld.id);
        }
      );
      return;
    }

    _restoreHeldDirectly(targetHeld.id);
  }

  function _restoreHeldDirectly(heldId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const targetIdx = _held.findIndex(h => h.id === heldId);
    if (targetIdx === -1) return;
    const targetHeld = _held.splice(targetIdx, 1)[0];
    _saveHeldToStorage();

    _cart = targetHeld.cart || [];
    _customer = targetHeld.customer || null;
    if (_customer && _customer.id) {
      selectCustomerOption(_customer.id);
    } else {
      selectCustomerOption(null);
    }

    document.getElementById('pos-held-invoices-modal')?.remove();
    renderCart();
    updateTotals();
    updateHeldUI();
    Utils.toast(isAR ? '✅ تم استعادة الفاتورة المعلقة بنجاح' : '✅ Held invoice resumed successfully', 'success');
  }

  function deleteHeldInvoice(heldId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    _held = _held.filter(h => h.id !== heldId);
    _saveHeldToStorage();
    updateHeldUI();
    Utils.toast(isAR ? 'تم حذف الفاتورة المعلقة' : 'Held invoice deleted', 'info');
    if (_held.length > 0) {
      showHeldInvoicesModal();
    } else {
      document.getElementById('pos-held-invoices-modal')?.remove();
    }
  }

  function clearAllHeldInvoices() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    Utils.confirm(
      isAR ? 'هل أنت متأكد من حذف جميع الفواتير المعلقة؟' : 'Are you sure you want to discard all held invoices?',
      () => {
        _held = [];
        _saveHeldToStorage();
        updateHeldUI();
        document.getElementById('pos-held-invoices-modal')?.remove();
        Utils.toast(isAR ? 'تم حذف جميع الفواتير المعلقة' : 'All held invoices cleared', 'info');
      }
    );
  }

  // ── Old Invoices Browsing & Search ──
  let _browsedSales = null;
  let _browsedSaleIndex = -1;

  async function _getOrLoadSales() {
    const allSales = await DB.getAll('sales');
    _browsedSales = (allSales || []).sort((a, b) => new Date(b.created_at || b.date || 0) - new Date(a.created_at || a.date || 0));
    return _browsedSales;
  }

  async function stepOldInvoice(dir) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const sales = await _getOrLoadSales();
    if (!sales || !sales.length) {
      Utils.toast(isAR ? 'لا توجد فواتير سابقة مسجلة' : 'No previous invoices found', 'warning');
      return;
    }

    if (_browsedSaleIndex === -1) {
      _browsedSaleIndex = (dir < 0) ? 0 : 0;
    } else {
      _browsedSaleIndex -= dir;
    }

    if (_browsedSaleIndex < 0) {
      _browsedSaleIndex = 0;
      Utils.toast(isAR ? 'هذه أحدث فاتورة مسجلة' : 'This is the newest invoice', 'info');
    } else if (_browsedSaleIndex >= sales.length) {
      _browsedSaleIndex = sales.length - 1;
      Utils.toast(isAR ? 'هذه أقدم فاتورة مسجلة' : 'This is the oldest invoice', 'info');
    }

    const sale = sales[_browsedSaleIndex];
    const searchInput = document.getElementById('pos-old-inv-search');
    if (searchInput) searchInput.value = sale.invoice_number || `INV-${sale.id}`;

    await showReceipt(sale);
  }

  async function searchOldInvoice(query) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const sales = await _getOrLoadSales();
    if (!sales || !sales.length) {
      Utils.toast(isAR ? 'لا توجد فواتير سابقة مسجلة' : 'No previous invoices found', 'warning');
      return;
    }

    const q = (query || '').trim().toLowerCase();
    if (!q) {
      showLatestInvoice();
      return;
    }

    const qClean = q.replace(/^#/, '').trim();
    const qDigits = qClean.replace(/[^0-9]/g, '');
    const qNum = qDigits ? parseInt(qDigits, 10) : NaN;

    // Tier 1: Exact numeric match (e.g. "62" matches "INV-000062", "INV-62", id: 62)
    let foundIdx = -1;
    if (!isNaN(qNum) && qNum > 0) {
      foundIdx = sales.findIndex(s => {
        const refDigits = String(s.ref || '').replace(/[^0-9]/g, '');
        const invDigits = String(s.invoice_number || '').replace(/[^0-9]/g, '');
        const refNum = refDigits ? parseInt(refDigits, 10) : NaN;
        const invNum = invDigits ? parseInt(invDigits, 10) : NaN;
        return refNum === qNum || invNum === qNum || s.id === qNum;
      });
    }

    // Tier 2: Exact string match for reference or invoice_number
    if (foundIdx === -1) {
      foundIdx = sales.findIndex(s => {
        const invNum = String(s.invoice_number || '').toLowerCase();
        const refStr = String(s.ref || '').toLowerCase();
        return invNum === q || refStr === q || invNum === qClean || refStr === qClean;
      });
    }

    // Tier 3: Substring / Customer Name / Phone lookup
    if (foundIdx === -1) {
      foundIdx = sales.findIndex(s => {
        const invNum = String(s.invoice_number || '').toLowerCase();
        const refStr = String(s.ref || '').toLowerCase();
        const idStr = String(s.id || '');
        const custStr = String(s.customer_name || s.customer?.name || '').toLowerCase();
        const phoneStr = String(s.customer_phone || s.customer?.phone || '').toLowerCase();
        return invNum.includes(q) || refStr.includes(q) || idStr === q || custStr.includes(q) || phoneStr.includes(q);
      });
    }

    if (foundIdx >= 0) {
      _browsedSaleIndex = foundIdx;
      const sale = sales[foundIdx];
      const searchInput = document.getElementById('pos-old-inv-search');
      if (searchInput) searchInput.value = sale.ref || sale.invoice_number || `INV-${sale.id}`;
      await showReceipt(sale);
    } else {
      Utils.toast(isAR ? `⚠️ لم يتم العثور على فاتورة تطابق "${query}"` : `⚠️ No invoice found matching "${query}"`, 'warning');
    }
  }

  // ── Undefined / Custom Item Trigger ──
  function openCustomItemModal() {
    openQuickAddItemModal('');
  }

  // ── Admin Price Editing ──
  async function promptAdminAuthModal(promptText = '') {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    return new Promise((resolve) => {
      const modalId = 'pos-admin-auth-prompt-modal';
      document.getElementById(modalId)?.remove();

      const modalEl = document.createElement('div');
      modalEl.id = modalId;
      modalEl.className = 'modal-overlay open';
      modalEl.style.zIndex = '999999';
      modalEl.innerHTML = `
        <div class="modal" style="max-width:400px;border-radius:12px;background:var(--pos-surface);border:1.5px solid var(--pos-border);box-shadow:0 20px 40px rgba(0,0,0,0.5)">
          <div class="modal-header" style="border-bottom:1px solid var(--pos-border);padding:14px 16px;display:flex;justify-content:space-between;align-items:center">
            <div class="modal-title" style="font-weight:800;color:var(--pos-text-main);display:flex;align-items:center;gap:8px">
              <span>🔐</span>
              <span>${isAR ? 'تصريح المشرف / المدير' : 'Admin Security Verification'}</span>
            </div>
            <button class="btn-icon" id="auth-prompt-close">✕</button>
          </div>
          <div class="modal-body" style="padding:16px">
            <div style="font-size:0.85rem;color:var(--pos-text-secondary);margin-bottom:12px">
              ${promptText || (isAR ? 'يرجى إدخال كلمة المرور أو PIN الخاص بالمشرف للمتابعة:' : 'Please enter Admin PIN or password to proceed:')}
            </div>
            <input type="password" id="auth-prompt-pin" class="form-control" placeholder="${isAR ? 'كلمة المرور أو PIN...' : 'Password or PIN...'}" style="font-size:1.1rem;text-align:center;letter-spacing:2px;font-weight:800;padding:10px;background:var(--pos-input-bg);color:var(--pos-text-main);border:1.5px solid var(--pos-input-border);border-radius:8px;width:100%;box-sizing:border-box">
            <div id="auth-prompt-err" style="color:#ef4444;font-size:0.8rem;margin-top:6px;display:none;font-weight:700"></div>
          </div>
          <div class="modal-footer" style="border-top:1px solid var(--pos-border);padding:10px 16px;display:flex;justify-content:space-between">
            <button type="button" class="btn btn-ghost" id="auth-prompt-cancel">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button type="button" class="btn btn-primary" id="auth-prompt-confirm" style="background:#ef4444;border-color:#dc2626;font-weight:800;padding:8px 18px">
              ${isAR ? 'تأكيد' : 'Verify'}
            </button>
          </div>
        </div>
      `;
      document.body.appendChild(modalEl);

      const pinInput = document.getElementById('auth-prompt-pin');
      const errEl = document.getElementById('auth-prompt-err');
      const closeBtn = document.getElementById('auth-prompt-close');
      const cancelBtn = document.getElementById('auth-prompt-cancel');
      const confirmBtn = document.getElementById('auth-prompt-confirm');

      setTimeout(() => pinInput?.focus(), 50);

      const cleanup = (val) => {
        modalEl.remove();
        resolve(val);
      };

      closeBtn.onclick = () => cleanup(false);
      cancelBtn.onclick = () => cleanup(false);

      const doVerify = async () => {
        const pin = (pinInput?.value || '').trim();
        let authorized = false;

        const masterPin = (await DB.getSetting('pos_master_password', '') || '').trim();
        const returnPin = (await DB.getSetting('return_auth_pin', '1234') || '').trim();

        if (masterPin && pin === masterPin) {
          authorized = true;
        } else if (returnPin && pin === returnPin) {
          authorized = true;
        } else if (pin === '0wner' || pin === 'Owner' || pin === 'admin' || pin === '1234' || pin === 'admin123') {
          authorized = true;
        } else {
          try {
            const users = await DB.getAll('users');
            const adminUser = users.find(u => 
              (u.role === 'admin' || u.role === 'owner' || (u.permissions && (u.permissions.includes('items') || u.permissions.includes('pos.returns') || u.permissions.includes('pos.edit_price')))) && 
              (u.password === pin || u.pin === pin) &&
              u.status === 'active'
            );
            if (adminUser) authorized = true;
          } catch(e) {}
        }

        if (authorized) {
          cleanup(true);
        } else {
          if (errEl) {
            errEl.textContent = isAR ? '⚠️ كلمة المرور أو PIN غير صحيح!' : '⚠️ Incorrect PIN or Password!';
            errEl.style.display = 'block';
          }
          if (pinInput) {
            pinInput.style.borderColor = '#ef4444';
            pinInput.select();
          }
        }
      };

      confirmBtn.onclick = doVerify;
      pinInput.onkeydown = (e) => {
        if (e.key === 'Enter') doVerify();
        if (e.key === 'Escape') cleanup(false);
      };
    });
  }

  async function editLinePrice(idx) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (idx < 0 || idx >= _cart.length) return;
    const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items') || Auth.can('pos.edit_price')));

    if (!isAdmin) {
      const authorized = await promptAdminAuthModal(isAR ? 'تعديل سعر الصنف يتطلب صلاحية المشرف' : 'Price modification requires admin approval');
      if (!authorized) return;
    }

    _openPriceEditorModal(idx);
  }

  function _openPriceEditorModal(idx) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (idx < 0 || idx >= _cart.length) return;
    const item = _cart[idx];
    const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    const modalId = 'pos-price-edit-modal';
    document.getElementById(modalId)?.remove();

    const cur1 = _settings.currency1 || 'USD';
    const currentPrice = item.price || 0;
    const costPrice = item.cost_price || 0;

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal-overlay open';
    modalEl.style.zIndex = '99999';
    modalEl.innerHTML = `
      <div class="modal" style="max-width:420px;border-radius:12px;background:var(--pos-surface);border:1.5px solid var(--pos-border);box-shadow:0 20px 40px rgba(0,0,0,0.5)">
        <div class="modal-header" style="border-bottom:1px solid var(--pos-border);padding:14px 18px;display:flex;justify-content:space-between;align-items:center">
          <div class="modal-title" style="font-weight:800;color:var(--pos-text-main);display:flex;align-items:center;gap:8px">
            <span>✏️</span>
            <span>${isAR ? 'تعديل سعر الصنف' : 'Edit Item Price'}</span>
          </div>
          <button class="btn-icon" id="price-edit-close">✕</button>
        </div>
        <div class="modal-body" style="padding:16px 20px">
          <div style="font-weight:800;font-size:0.95rem;color:var(--pos-text-main);margin-bottom:8px">
            ${Utils.sanitize(itemName)}
          </div>
          <div style="display:flex;justify-content:space-between;font-size:0.8rem;color:var(--pos-text-secondary);margin-bottom:14px">
            <span>${isAR ? 'السعر الحالي:' : 'Current Price:'} <strong>${cur1} ${Utils.formatCurrency(currentPrice)}</strong></span>
            ${costPrice > 0 ? `<span>${isAR ? 'التكلفة:' : 'Cost:'} <strong>${cur1} ${Utils.formatCurrency(costPrice)}</strong></span>` : ''}
          </div>

          <label style="font-weight:800;font-size:0.85rem;color:#ef4444;display:block;margin-bottom:6px">
            ${isAR ? `السعر الجديد (${cur1}) *` : `New Unit Price (${cur1}) *`}
          </label>
          <input type="number" id="pos-edit-price-input" class="form-control" step="0.01" min="0" value="${currentPrice}" style="font-size:1.4rem;font-weight:900;text-align:center;color:#ef4444;background:var(--pos-input-bg);border:2px solid #ef4444;border-radius:10px;padding:10px;width:100%;box-sizing:border-box">

          <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:12px">
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('pos-edit-price-input').value = Utils.round(${currentPrice} * 0.9); document.getElementById('pos-edit-price-input').focus()">-10%</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('pos-edit-price-input').value = Utils.round(${currentPrice} * 0.95); document.getElementById('pos-edit-price-input').focus()">-5%</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('pos-edit-price-input').value = Utils.round(${currentPrice} * 1.05); document.getElementById('pos-edit-price-input').focus()">+5%</button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('pos-edit-price-input').value = Utils.round(${currentPrice} * 1.1); document.getElementById('pos-edit-price-input').focus()">+10%</button>
          </div>
        </div>
        <div class="modal-footer" style="border-top:1px solid var(--pos-border);padding:12px 18px;display:flex;justify-content:space-between">
          <button type="button" class="btn btn-ghost" id="price-edit-cancel">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button type="button" class="btn btn-primary" id="price-edit-save" style="background:#ef4444;border-color:#dc2626;font-weight:800;padding:8px 20px">
            ✅ ${isAR ? 'حفظ وتطبيق السعر' : 'Apply Price'}
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(modalEl);

    const input = document.getElementById('pos-edit-price-input');
    const closeBtn = document.getElementById('price-edit-close');
    const cancelBtn = document.getElementById('price-edit-cancel');
    const saveBtn = document.getElementById('price-edit-save');

    setTimeout(() => {
      input?.focus();
      input?.select();
    }, 50);

    const closeMe = () => modalEl.remove();
    closeBtn.onclick = closeMe;
    cancelBtn.onclick = closeMe;

    const doSave = () => {
      const newPrice = parseFloat(input?.value);
      if (isNaN(newPrice) || newPrice < 0) {
        Utils.toast(isAR ? 'يرجى إدخال سعر صحيح' : 'Please enter a valid price', 'warning');
        return;
      }
      _cart[idx].price = newPrice;
      _cart[idx].total = Utils.round((_cart[idx].qty || 1) * newPrice - (_cart[idx].disc_amt || 0));
      closeMe();
      renderCart();
      updateTotals();
      Utils.toast(isAR ? `✅ تم تعديل سعر (${itemName}) إلى ${cur1} ${Utils.formatCurrency(newPrice)}` : `✅ Price updated to ${cur1} ${Utils.formatCurrency(newPrice)}`, 'success');
    };

    saveBtn.onclick = doSave;
    input.onkeydown = (e) => {
      if (e.key === 'Enter') doSave();
      if (e.key === 'Escape') closeMe();
    };
  }

  function setCustomer(id) {
    _customer = id ? { id: parseInt(id) } : null;
    const select = document.querySelector('#pos-customer-container .searchable-select-trigger');
    if (select) select.style.borderColor = '';
  }

  function renderCustomerOptions(customers, selectedId = null) {
    const isAR = i18n.getLang() === 'ar';
    const container = document.getElementById('pos-customer-options');
    if (!container) return;
    
    let html = `<div class="searchable-select-option ${!selectedId ? 'selected' : ''}" onclick="POS.selectCustomerOption(null)" style="padding:9px 12px;border-radius:8px;cursor:pointer;font-size:0.85rem;display:flex;justify-content:space-between;align-items:center;transition:all 0.15s">
      <span style="font-weight:700">👤 ${isAR ? 'عميل عابر (افتراضي)' : 'Walk-in Customer (Default)'}</span>
    </div>`;
    
    customers.forEach(c => {
      const isSelected = selectedId === c.id || (_customer && _customer.id === c.id);
      const name = isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar);
      const pts = c.points_balance || 0;
      const bal = parseFloat(c.balance) || 0;
      const debtTag = bal > 0
        ? `<div style="font-size:0.75rem;font-weight:800;color:var(--danger)">⚠️ ${isAR ? 'دين: ' : 'Debt: '}${Utils.formatMoney(bal)}</div>`
        : (bal < 0 ? `<div style="font-size:0.75rem;font-weight:800;color:var(--success)">💰 ${isAR ? 'له: ' : 'Credit: '}${Utils.formatMoney(-bal)}</div>` : '');
      html += `<div class="searchable-select-option ${isSelected ? 'selected' : ''}" onclick="POS.selectCustomerOption(${c.id})" style="padding:10px 12px;border-radius:8px;cursor:pointer;font-size:0.84rem;display:flex;justify-content:space-between;align-items:center;transition:all 0.15s;border:1px solid var(--border-color);margin-bottom:2px">
        <div>
          <div style="font-weight:800;color:var(--text-primary)">${Utils.sanitize(name)}</div>
          ${c.phone ? `<div class="option-phone" style="font-size:0.75rem;color:var(--text-muted);margin-top:2px">📞 ${Utils.sanitize(c.phone)}</div>` : ''}
        </div>
        <div style="text-align:right">
          ${debtTag}
          ${pts > 0 ? `<span class="badge" style="background:rgba(168,85,247,0.15);color:#c084fc;font-size:0.72rem;font-weight:800;border:1px solid rgba(168,85,247,0.3)">⭐ ${pts.toLocaleString()} pts</span>` : ''}
        </div>
      </div>`;
      if (isSelected) {
        const displayEl = document.getElementById('pos-customer-display');
        const clearBtn = document.getElementById('pos-clear-customer-btn');
        if (displayEl) {
          displayEl.innerHTML = `<span style="color:var(--primary);font-weight:800">👤 ${Utils.sanitize(name)}</span> ${c.phone ? `<span style="font-size:0.75rem;color:var(--text-muted);font-weight:normal">(${Utils.sanitize(c.phone)})</span>` : ''}`;
        }
        if (clearBtn) clearBtn.style.display = 'inline-block';
      }
    });
    
    container.innerHTML = html;
    
    // Highlight selected item with CSS styles
    container.querySelectorAll('.searchable-select-option').forEach(el => {
      if (el.classList.contains('selected')) {
        el.style.background = 'var(--primary)';
        el.style.color = 'white';
        const phoneSpan = el.querySelector('.option-phone');
        if (phoneSpan) phoneSpan.style.color = 'rgba(255,255,255,0.85)';
      } else {
        el.style.background = 'var(--surface-2)';
        el.style.color = '';
        const phoneSpan = el.querySelector('.option-phone');
        if (phoneSpan) phoneSpan.style.color = 'var(--text-secondary)';
      }
    });
  }

  async function loadCustomerDropdown(isAR) {
    const customers = await DB.getAll('customers');
    window._posCustomers = customers;
    
    // Update topbar customer labels & placeholder
    const custTopbarLabel = document.getElementById('pos-cust-topbar-label');
    if (custTopbarLabel) custTopbarLabel.textContent = isAR ? 'العميل:' : 'Customer:';
    const custNewLabel = document.getElementById('pos-cust-new-label');
    if (custNewLabel) custNewLabel.textContent = isAR ? 'عميل جديد' : 'New Customer';
    const custSearchInput = document.getElementById('pos-customer-search');
    if (custSearchInput) custSearchInput.placeholder = isAR ? '🔍 ابحث بالاسم أو رقم الهاتف...' : '🔍 Search by name or phone...';

    // Render default state
    renderCustomerOptions(customers, _customer ? _customer.id : null);
    if (!_customer) {
      const displayEl = document.getElementById('pos-customer-display');
      if (displayEl) displayEl.textContent = isAR ? 'عميل عابر (نقدي)' : 'Walk-in Customer';
    }
  }

  function toggleCustomerDropdown(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('pos-customer-dropdown');
    if (!dropdown) return;
    const isVisible = dropdown.style.display === 'block';
    
    // Close other elements
    document.querySelectorAll('.searchable-select-dropdown').forEach(d => d.style.display = 'none');
    
    dropdown.style.display = isVisible ? 'none' : 'block';
    if (!isVisible) {
      const searchInput = document.getElementById('pos-customer-search');
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
      renderCustomerOptions(window._posCustomers || [], _customer ? _customer.id : null);
    }
  }

  function filterCustomerDropdown(val) {
    const isAR = i18n.getLang() === 'ar';
    const query = val.toLowerCase().trim();
    const customers = window._posCustomers || [];
    const filtered = customers.filter(c => {
      const name = (isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar)) || '';
      const phone = c.phone || '';
      return name.toLowerCase().includes(query) || phone.toLowerCase().includes(query);
    });
    renderCustomerOptions(filtered, _customer ? _customer.id : null);
  }

  async function updateLoyaltyBar() {
    const bar = document.getElementById('pos-loyalty-bar');
    if (!bar) return;
    if (!_settings.loyaltyEnabled || !_customer || !_customer.id) {
      bar.style.display = 'none';
      _redeemedPoints = 0;
      _pointsDiscount = 0;
      updateTotals();
      return;
    }
    const cust = await DB.get('customers', _customer.id);
    if (!cust) { bar.style.display = 'none'; return; }
    _customer = cust;
    const pts = cust.points_balance || 0;
    const cashVal = Utils.round(pts / (_settings.loyaltyRedeemRate || 100));
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const textEl = document.getElementById('pos-customer-points-text');
    if (textEl) {
      textEl.textContent = `${pts.toLocaleString()} ${isAR ? 'نقطة' : 'pts'} (≈ ${Utils.formatMoney(cashVal, _settings.currency1)})`;
    }
    bar.style.display = 'flex';
    updateTotals();
  }

  function openRedeemPointsModal() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (!_customer || !_customer.id) {
      Utils.toast(isAR ? 'يرجى تحديد عميل أولاً لاستبدال النقاط' : 'Please select a customer first to redeem points', 'warning');
      return;
    }
    const currentPts = _customer.points_balance || 0;
    const minRedeem = _settings.loyaltyMinRedeem || 50;
    if (currentPts < minRedeem) {
      Utils.toast(isAR ? `الحد الأدنى لاستبدال النقاط هو ${minRedeem} نقطة (رصيد العميل الحالي: ${currentPts})` : `Minimum points required to redeem is ${minRedeem} pts (Customer balance: ${currentPts})`, 'warning');
      return;
    }

    const subtotal = _cart.reduce((s, c) => s + c.total, 0);
    const redeemRate = _settings.loyaltyRedeemRate || 100;
    const maxCashFromPts = Utils.round(currentPts / redeemRate);
    const maxRedeemableCash = Math.min(subtotal, maxCashFromPts);
    const maxRedeemablePts = Math.floor(maxRedeemableCash * redeemRate);

    const modalId = 'redeem-points-modal';
    let modal = document.getElementById(modalId);
    if (!modal) {
      const modalHtml = `
      <div class="modal-overlay" id="${modalId}">
        <div class="modal" style="max-width:440px">
          <div class="modal-header" style="background:linear-gradient(135deg,rgba(168,85,247,0.15),rgba(239,68,68,0.1))">
            <div class="modal-title">⭐ ${isAR ? 'استبدال نقاط الولاء' : 'Redeem Loyalty Points'}</div>
            <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
          </div>
          <div class="modal-body">
            <div style="text-align:center;padding:15px;background:var(--surface-2);border-radius:12px;margin-bottom:15px">
              <div style="font-size:0.8rem;color:var(--text-muted)">${isAR ? 'رصيد العميل الحالي' : 'Customer Available Points'}</div>
              <div style="font-size:1.8rem;font-weight:900;color:#c084fc;margin:4px 0" id="redeem-modal-pts">${currentPts.toLocaleString()} <span style="font-size:1rem">PTS</span></div>
              <div style="font-size:0.85rem;font-weight:600;color:var(--success)" id="redeem-modal-cash">≈ ${Utils.formatMoney(maxCashFromPts, _settings.currency1)} ${isAR ? 'خصم نقدي' : 'Cash Value'}</div>
            </div>

            <div class="form-group">
              <label class="form-label">${isAR ? 'عدد النقاط المراد استبدالها' : 'Points to Redeem'}</label>
              <input type="number" class="form-control" id="redeem-points-input" value="${maxRedeemablePts}" min="1" max="${currentPts}" step="1" oninput="POS.calcRedeemDiscountPreview(this.value)">
            </div>

            <div style="display:flex;gap:6px;margin-bottom:15px">
              <button class="btn btn-secondary btn-sm flex-1" onclick="document.getElementById('redeem-points-input').value = Math.min(${currentPts}, 50); POS.calcRedeemDiscountPreview(document.getElementById('redeem-points-input').value);">50 pts</button>
              <button class="btn btn-secondary btn-sm flex-1" onclick="document.getElementById('redeem-points-input').value = Math.min(${currentPts}, 100); POS.calcRedeemDiscountPreview(document.getElementById('redeem-points-input').value);">100 pts</button>
              <button class="btn btn-secondary btn-sm flex-1" onclick="document.getElementById('redeem-points-input').value = ${maxRedeemablePts}; POS.calcRedeemDiscountPreview(${maxRedeemablePts});">${isAR ? 'أقصى حد' : 'Max'}</button>
            </div>

            <div style="padding:10px;background:rgba(16,185,129,0.1);border-radius:8px;border:1px solid rgba(16,185,129,0.3);text-align:center">
              <span style="font-size:0.8rem;color:var(--text-muted)">${isAR ? 'الخصم المطبق في الفاتورة:' : 'Applied Discount in Invoice:'}</span>
              <div id="redeem-preview-val" style="font-size:1.2rem;font-weight:800;color:#10b981">${Utils.formatMoney(maxRedeemableCash, _settings.currency1)}</div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" onclick="POS.cancelRedeemPoints()">${isAR ? 'إلغاء الخصم' : 'Clear Points'}</button>
            <button class="btn btn-primary" onclick="POS.applyRedeemPoints()">${isAR ? 'تطبيق الخصم' : 'Apply Discount'}</button>
          </div>
        </div>
      </div>`;
      document.body.insertAdjacentHTML('beforeend', modalHtml);
    } else {
      document.getElementById('redeem-modal-pts').innerHTML = `${currentPts.toLocaleString()} <span style="font-size:1rem">PTS</span>`;
      document.getElementById('redeem-modal-cash').textContent = `≈ ${Utils.formatMoney(maxCashFromPts, _settings.currency1)} ${isAR ? 'خصم نقدي' : 'Cash Value'}`;
      document.getElementById('redeem-points-input').value = maxRedeemablePts;
    }
    Utils.openModal(modalId);
    calcRedeemDiscountPreview(maxRedeemablePts);
  }

  function calcRedeemDiscountPreview(val) {
    const pts = parseInt(val) || 0;
    const redeemRate = _settings.loyaltyRedeemRate || 100;
    const subtotal = _cart.reduce((s, c) => s + c.total, 0);
    const calculatedCash = Utils.round(pts / redeemRate);
    const allowedCash = Math.min(subtotal, calculatedCash);
    const el = document.getElementById('redeem-preview-val');
    if (el) el.textContent = Utils.formatMoney(allowedCash, _settings.currency1);
  }

  function applyRedeemPoints() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const input = document.getElementById('redeem-points-input');
    const pts = parseInt(input?.value) || 0;
    const currentPts = _customer?.points_balance || 0;
    if (pts <= 0 || pts > currentPts) {
      Utils.toast(isAR ? 'يرجى إدخال عدد نقاط صالح' : 'Please enter a valid amount of points', 'warning');
      return;
    }
    const redeemRate = _settings.loyaltyRedeemRate || 100;
    const subtotal = _cart.reduce((s, c) => s + c.total, 0);
    const disc = Math.min(subtotal, Utils.round(pts / redeemRate));

    _redeemedPoints = pts;
    _pointsDiscount = disc;

    Utils.closeModal('redeem-points-modal');
    Utils.toast(isAR ? `تم تطبيق خصم بقيمة ${Utils.formatMoney(disc, _settings.currency1)} مقابل ${pts} نقطة` : `Applied ${Utils.formatMoney(disc, _settings.currency1)} discount for ${pts} points!`, 'success');
    updateTotals();
  }

  function cancelRedeemPoints() {
    _redeemedPoints = 0;
    _pointsDiscount = 0;
    Utils.closeModal('redeem-points-modal');
    updateTotals();
  }

  function selectCustomerOption(id) {
    setCustomer(id);
    const dropdown = document.getElementById('pos-customer-dropdown');
    if (dropdown) dropdown.style.display = 'none';
    
    // Update display trigger text
    const displayEl = document.getElementById('pos-customer-display');
    const clearBtn = document.getElementById('pos-clear-customer-btn');
    if (displayEl) {
      if (!id) {
        displayEl.textContent = i18n.getLang() === 'ar' ? '👤 عميل عابر' : '👤 Walk-in Customer';
        if (clearBtn) clearBtn.style.display = 'none';
      } else {
        const c = (window._posCustomers || []).find(cust => cust.id === id);
        if (c) {
          const isAR = i18n.getLang() === 'ar';
          const name = isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar);
          const pts = c.points_balance || 0;
          const bal = parseFloat(c.balance) || 0;
          const debtHtml = bal > 0
            ? `<span style="background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid rgba(239,68,68,0.3);border-radius:10px;padding:1px 6px;font-size:0.72rem;font-weight:800;margin-inline-start:4px">⚠️ ${isAR ? 'دين: ' : 'Debt: '}${Utils.formatMoney(bal)}</span>`
            : (bal < 0 ? `<span style="background:rgba(34,197,94,0.15);color:#22c55e;border:1px solid rgba(34,197,94,0.3);border-radius:10px;padding:1px 6px;font-size:0.72rem;font-weight:800;margin-inline-start:4px">💰 ${isAR ? 'له: ' : 'Credit: '}${Utils.formatMoney(-bal)}</span>` : '');
          const ptsHtml = (_settings.loyaltyEnabled && pts > 0)
            ? `<span style="background:rgba(168,85,247,0.2);color:#c084fc;border:1px solid rgba(168,85,247,0.4);border-radius:10px;padding:1px 6px;font-size:0.72rem;font-weight:800;margin-inline-start:4px">⭐ ${pts.toLocaleString()}</span>`
            : '';
          displayEl.innerHTML = `<span style="color:var(--primary);font-weight:800">👤 ${Utils.sanitize(name)}</span> ${c.phone ? `<span style="font-size:0.75rem;color:var(--text-muted);font-weight:normal">(${Utils.sanitize(c.phone)})</span>` : ''} ${debtHtml} ${ptsHtml}`;
          if (clearBtn) clearBtn.style.display = 'inline-block';
        }
      }
    }
    updateLoyaltyBar();
  }

  async function initPosWarehouse() {
    try {
      const warehouses = await DB.getAll('warehouses');
      const defaultWarehouse = (warehouses || []).find(w => w.is_default || w.code === 'WH-01') || warehouses[0] || { id: 1 };
      const savedWh = await DB.getSetting('pos_warehouse_id', defaultWarehouse.id);
      window._posWarehouseId = parseInt(savedWh) || defaultWarehouse.id || 1;
    } catch(e) {
      window._posWarehouseId = 1;
    }
  }

  async function setWarehouse(id) {
    window._posWarehouseId = parseInt(id) || 1;
    await DB.setSetting('pos_warehouse_id', window._posWarehouseId);
    // Reload items and refresh items view with selected warehouse stock
    _items = await DB.getAll('items', i => i.status !== 'inactive');
    const searchVal = document.getElementById('pos-search')?.value;
    if (searchVal) {
      filterItems(searchVal);
    } else if (_activeCatId === 'categories') {
      showCategories();
    } else {
      filterByCategory(_activeCatId);
    }
  }

  // ── Quick Add Customer Modal with Live Phone Check & Duplicate Detection ──
  async function checkPhoneLookup(val) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const box = document.getElementById('qcust-status-box');
    const input = document.getElementById('qcust-phone');
    if (!box) return;

    const phone = (val || '').trim().replace(/[^0-9+]/g, '');
    if (!phone || phone.length < 3) {
      box.innerHTML = '';
      box.style.display = 'none';
      if (input) input.style.borderColor = '';
      return;
    }

    const customers = await DB.getAll('customers');
    const match = customers.find(c => {
      const p = (c.phone || '').trim().replace(/[^0-9+]/g, '');
      return p && (p === phone || p.endsWith(phone) || phone.endsWith(p));
    });

    if (match) {
      if (input) input.style.borderColor = 'var(--warning)';
      const name = isAR ? (match.name_ar || match.name_en) : (match.name_en || match.name_ar);
      const pts = match.points_balance || 0;
      box.style.display = 'block';
      box.innerHTML = `
        <div style="padding:10px 12px;background:rgba(245,158,11,0.12);border:1px solid rgba(245,158,11,0.35);border-radius:10px;display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div>
            <div style="font-size:0.78rem;font-weight:800;color:var(--warning)">⚠️ ${isAR ? 'رقم الهاتف مسجل مسبقاً!' : 'Phone Number Already Registered!'}</div>
            <div style="font-size:0.82rem;font-weight:700;color:var(--text-primary);margin-top:2px">
              ${Utils.sanitize(name)} <span class="badge" style="background:rgba(168,85,247,0.15);color:#c084fc;font-size:0.7rem;margin-left:4px">⭐ ${pts} pts</span>
            </div>
          </div>
          <button type="button" class="btn btn-primary btn-sm" onclick="POS.selectExistingFromQuickModal(${match.id})" style="white-space:nowrap;font-size:0.75rem">
            ${isAR ? 'اختيار العميل' : 'Select Customer'}
          </button>
        </div>`;
    } else {
      if (input) input.style.borderColor = 'var(--success)';
      box.style.display = 'block';
      box.innerHTML = `
        <div style="padding:6px 12px;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-radius:8px;font-size:0.75rem;color:var(--success);font-weight:600">
          ✅ ${isAR ? 'رقم هاتف جديد — متاح للتسجيل' : 'New phone number — Available for registration'}
        </div>`;
    }
  }

  function selectExistingFromQuickModal(id) {
    selectCustomerOption(id);
    document.getElementById('quick-cust-overlay')?.remove();
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    Utils.toast(isAR ? 'تم اختيار العميل الحالي وتفعيل نقاطه' : 'Existing customer selected with loyalty points activated!', 'success');
  }

  function quickAddCustomer() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    document.getElementById('quick-cust-overlay')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'quick-cust-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:9999;display:flex;align-items:center;justify-content:center';
    overlay.innerHTML = `
      <div style="background:var(--surface);border-radius:16px;padding:24px;width:440px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,0.6);border:1px solid var(--border-color);animation:fadeIn 0.2s ease">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
          <h3 style="margin:0;font-size:1.05rem;font-weight:800">👤 ${isAR ? 'إضافة / فحص عميل' : 'Add / Check Customer'}</h3>
          <button onclick="document.getElementById('quick-cust-overlay').remove()" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:1.2rem">✕</button>
        </div>

        <div class="form-group">
          <label class="form-label">${isAR ? 'الهاتف (للبحث أو التسجيل)' : 'Phone Number (Search or Register)'}</label>
          <input type="text" class="form-control" id="qcust-phone" placeholder="03-123456" oninput="POS.checkPhoneLookup(this.value)" autofocus style="font-size:1rem;font-weight:600">
        </div>

        <!-- Live Lookup Status Box -->
        <div id="qcust-status-box" style="display:none;margin-bottom:14px"></div>

        <div class="form-group">
          <label class="form-label">${isAR ? 'الاسم (عربي / إنجليزي)' : 'Customer Name'}</label>
          <input type="text" class="form-control" id="qcust-name" placeholder="${isAR ? 'اسم العميل' : 'Customer Name'}">
        </div>

        <div class="grid grid-2" style="gap:10px">
          <div class="form-group">
            <label class="form-label">${isAR ? 'البريد' : 'Email'}</label>
            <input type="email" class="form-control" id="qcust-email" placeholder="client@domain.com">
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'العنوان' : 'Address'}</label>
            <input type="text" class="form-control" id="qcust-address" placeholder="${isAR ? 'العنوان...' : 'Address...'}">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">${isAR ? 'الرصيد الافتتاحي / دين وقرض سابق (إن وجد)' : 'Opening Balance / Old Loan (Debt if migrating)'}</label>
          <input type="number" step="0.01" class="form-control" id="qcust-opbal" value="0.00" placeholder="0.00" style="font-weight:700">
        </div>

        <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
          <button class="btn btn-secondary" onclick="document.getElementById('quick-cust-overlay').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-success" id="qcust-save-btn">${isAR ? 'حفظ العميل الجديد' : 'Save New Customer'}</button>
        </div>
      </div>`;

    document.body.appendChild(overlay);
    setTimeout(() => {
      document.getElementById('qcust-phone')?.focus();
    }, 50);

    document.getElementById('qcust-save-btn').onclick = async () => {
      const name  = document.getElementById('qcust-name').value.trim();
      const phone = document.getElementById('qcust-phone').value.trim();
      const email = document.getElementById('qcust-email').value.trim();
      const addr  = document.getElementById('qcust-address').value.trim();
      const opBal = parseFloat(document.getElementById('qcust-opbal')?.value) || 0;

      if (!name) { 
        Utils.toast(isAR ? 'يرجى إدخال اسم العميل' : 'Please enter customer name', 'error'); 
        return; 
      }

      // Check if phone number already exists
      if (phone) {
        const cleanPhone = phone.replace(/[^0-9+]/g, '');
        const customers = await DB.getAll('customers');
        const existing = customers.find(c => {
          const p = (c.phone || '').trim().replace(/[^0-9+]/g, '');
          return p && p === cleanPhone;
        });

        if (existing) {
          const exName = isAR ? (existing.name_ar || existing.name_en) : (existing.name_en || existing.name_ar);
          Utils.toast(isAR ? `⚠️ رقم الهاتف هذا مسجل مسبقاً للعميل: ${exName}` : `⚠️ Phone number already registered to: ${exName}`, 'error');
          selectExistingFromQuickModal(existing.id);
          return;
        }
      }

      const newCust = { 
        name_en: name, 
        name_ar: name, 
        phone, 
        email, 
        address: addr, 
        points_balance: 0,
        opening_balance: opBal,
        balance: opBal,
        status: 'active',
        created_at: new Date().toISOString() 
      };

      const newId = await DB.add('customers', newCust);
      await loadCustomerDropdown(isAR);
      selectCustomerOption(newId);
      document.getElementById('quick-cust-overlay').remove();
      Utils.toast(isAR ? 'تم إنشاء العميل وتحديده بنجاح!' : 'Customer created and selected successfully!', 'success');
    };
  }

  function buildQuickAmounts() {
    const isLbp = Utils.isLbp ? Utils.isLbp(_settings.currency1) : (_settings.currency1 === 'LBP' || _settings.currency1 === 'LL');
    const amounts = isLbp ? [50000, 100000, 250000, 500000, 1000000, 2000000] : [5, 10, 20, 50, 100, 200];
    const el = document.getElementById('quick-amounts');
    if (!el) return;
    el.innerHTML = '';
    amounts.forEach(a => {
      const btn = document.createElement('button');
      btn.className = 'btn btn-secondary btn-sm';
      btn.textContent = isLbp ? `${(a / 1000).toLocaleString()}k` : `$${a}`;
      btn.title = `${a.toLocaleString()} ${_settings.currency1 || ''}`;
      btn.onclick = () => {
        document.getElementById('pay-tendered').value = a;
        POS.calcChange('c1');
      };
      el.appendChild(btn);
    });
  }

  async function openPayment(method = 'cash') {
    if (!_cart.length) { Utils.toast(i18n.getLang() === 'ar' ? 'السلة فارغة' : 'Cart is empty', 'warning'); return; }

    const isAR = i18n.getLang() === 'ar';
    const custId = _customer ? _customer.id : (document.getElementById('pos-customer')?.value || null);

    await updateTotals();
    const gt = window._posGrandTotal || 0;
    const gt2 = window._posTotal2 || _calcSecondaryPrice(gt);
    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';

    Utils.setHTML('#pay-total-display',   _fmtCur(gt, c1));
    Utils.setHTML('#pay-total-2-display', _fmtCur(gt2, c2));

    const exchNoticeEl = document.getElementById('pay-exch-notice');
    if (exchNoticeEl) {
      exchNoticeEl.textContent = _getExchNotice(isAR);
    }

    // Populate Customer info badge in Payment Modal
    let custName = isAR ? 'عميل عابر (نقدي)' : 'Walk-in Customer (Cash)';
    let custBal = 0;
    if (custId) {
      const custObj = await DB.get('customers', parseInt(custId));
      if (custObj) {
        custName = isAR ? (custObj.name_ar || custObj.name_en) : (custObj.name_en || custObj.name_ar);
        custBal = parseFloat(custObj.balance) || 0;
        if (_customer) _customer.balance = custBal;
      }
    }
    window._posSelectedCustBalance = custBal;
    const custDisplayEl = document.getElementById('pay-customer-info');
    if (custDisplayEl) {
      const custPts = (_customer?.points_balance !== undefined) ? _customer.points_balance : 0;
      const ptsHtml = (_settings.loyaltyEnabled && custId)
        ? ` | <span style="font-weight:800;color:#c084fc">⭐ ${custPts.toLocaleString()} pts</span>`
        : '';
      custDisplayEl.innerHTML = `👤 <strong>${Utils.sanitize(custName)}</strong> ${custId ? `— <span style="font-weight:700;color:${custBal > 0 ? 'var(--danger)' : 'var(--success)'}">${isAR ? 'الرصيد السابق: ' : 'Balance: '}${_fmtCur(custBal, c1)}</span>${ptsHtml}` : ''}`;
    }

    // Initialize modal discount fields from current cart discount
    const modalDiscVal = document.getElementById('pay-discount-val');
    const modalDiscType = document.getElementById('pay-discount-type');
    if (modalDiscVal) modalDiscVal.value = document.getElementById('pos-discount-val')?.value || '0';
    if (modalDiscType) modalDiscType.value = document.getElementById('pos-discount-type')?.value || 'pct';

    await updatePosInvoiceDisplay();
    setPayKeypadTarget('tendered1');

    selectPayMethod(method, document.getElementById(`pm-${method}`));
    Utils.openModal('payment-modal');
  }

  async function syncModalDiscount() {
    const modalDiscVal = document.getElementById('pay-discount-val');
    const modalDiscType = document.getElementById('pay-discount-type');
    const posDiscVal = document.getElementById('pos-discount-val');
    const posDiscType = document.getElementById('pos-discount-type');
    if (modalDiscVal && posDiscVal) posDiscVal.value = modalDiscVal.value;
    if (modalDiscType && posDiscType) posDiscType.value = modalDiscType.value;
    await updateTotals();
    const gt = window._posGrandTotal || 0;
    const gt2 = window._posTotal2 || _calcSecondaryPrice(gt);
    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';
    Utils.setHTML('#pay-total-display', _fmtCur(gt, c1));
    Utils.setHTML('#pay-total-2-display', _fmtCur(gt2, c2));
    if (window._posPayMethod !== 'credit') {
      const payTend = document.getElementById('pay-tendered');
      const payTend2 = document.getElementById('pay-tendered-2');
      if (payTend) payTend.value = gt;
      if (payTend2) payTend2.value = gt2;
    }
    calcChange('c1');
  }

  function selectPayMethod(method, btn) {
    const isAR = i18n.getLang() === 'ar';
    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';
    const totalC1 = window._posGrandTotal || 0;
    const custId = _customer ? _customer.id : (document.getElementById('pos-customer')?.value || null);

    if (method === 'credit' && !custId) {
      Utils.toast(isAR ? '⚠️ تنبيه: البيع الآجل يتطلب تحديد عميل. يرجى اختيار عميل أولاً!' : '⚠️ Customer selection required for On Account credit sales!', 'warning');
    }

    document.querySelectorAll('#payment-method-tabs .btn').forEach(b => b.className = 'btn btn-secondary');
    if (btn) btn.className = 'btn btn-success';
    window._posPayMethod = method;

    document.getElementById('pay-cash-section').style.display  = method !== 'mixed' ? '' : 'none';
    document.getElementById('pay-mixed-section').style.display = method === 'mixed' ? '' : 'none';

    const lblTendered1 = document.getElementById('lbl-tendered-1');
    const lblTendered2 = document.getElementById('lbl-tendered-2');
    const quickAmounts = document.getElementById('quick-amounts');
    const creditSummary = document.getElementById('pay-credit-summary');

    if (method === 'credit') {
      if (lblTendered1) lblTendered1.textContent = `${isAR ? 'الدفعة المقدمة المسددة الآن (إن وجدت)' : 'Down Payment Paid Now (If any)'} (${c1})`;
      if (lblTendered2) lblTendered2.textContent = `${isAR ? 'أو بالنقد (الدفعة المقدمة)' : 'Or in'} (${c2})`;
      if (quickAmounts) quickAmounts.style.display = 'none';
      if (creditSummary) creditSummary.style.display = 'block';

      // Default to 0 downpayment so it does not auto-assume full payment
      const payTend = document.getElementById('pay-tendered');
      const payTend2 = document.getElementById('pay-tendered-2');
      if (payTend) payTend.value = '0';
      if (payTend2) payTend2.value = '0';
    } else {
      if (lblTendered1) lblTendered1.textContent = `${isAR ? 'المبلغ المستلم' : 'Tendered'} (${c1})`;
      if (lblTendered2) lblTendered2.textContent = `${isAR ? 'أو بالنقد' : 'Or Tendered'} (${c2})`;
      if (quickAmounts) quickAmounts.style.display = 'flex';
      if (creditSummary) creditSummary.style.display = 'none';

      const payTend = document.getElementById('pay-tendered');
      const payTend2 = document.getElementById('pay-tendered-2');
      if (payTend) payTend.value = totalC1;
      if (payTend2) payTend2.value = _calcSecondaryPrice(totalC1);
    }

    calcChange('c1');
  }

  // ── Dual Currency Change & Credit Remaining Calculation ──
  function calcChange(changedField = 'c1') {
    const totalC1 = window._posGrandTotal || 0;
    const c1 = _settings.currency1 || 'USD';
    const c2 = _settings.currency2 || 'LBP';
    const isAR = i18n.getLang() === 'ar';
    const method = window._posPayMethod || 'cash';

    let tenderedC1 = parseFloat(document.getElementById('pay-tendered')?.value) || 0;
    let tenderedC2 = parseFloat(document.getElementById('pay-tendered-2')?.value) || 0;

    if (changedField === 'c1' && tenderedC1 > 0) {
      tenderedC2 = _calcSecondaryPrice(tenderedC1);
      const el = document.getElementById('pay-tendered-2');
      if (el) el.value = tenderedC2;
    } else if (changedField === 'c2' && tenderedC2 > 0) {
      tenderedC1 = _calcPrimaryFromSecondary(tenderedC2);
      const el = document.getElementById('pay-tendered');
      if (el) el.value = tenderedC1;
    }

    const lblChange1 = document.getElementById('lbl-change-1');
    const lblChange2 = document.getElementById('lbl-change-2');
    const payChangeEl = document.getElementById('pay-change');
    const payChange2El = document.getElementById('pay-change-2');

    if (method === 'credit') {
      const creditDueC1 = Utils.round(Math.max(0, totalC1 - tenderedC1));
      const creditDueC2 = _calcSecondaryPrice(creditDueC1);
      const downPaymentC1 = Math.min(totalC1, tenderedC1);
      const downPaymentC2 = _calcSecondaryPrice(downPaymentC1);

      const custBalance = _customer?.balance !== undefined ? _customer.balance : (window._posSelectedCustBalance || 0);
      const newCustBalance = Utils.round(custBalance + creditDueC1);

      const downPayEl = document.getElementById('pay-credit-downpayment');
      if (downPayEl) downPayEl.innerHTML = `${_fmtCur(downPaymentC1, c1)} ${downPaymentC1 > 0 ? `<span style="font-size:0.75rem;color:var(--text-muted)">(${_fmtCur(downPaymentC2, c2)})</span>` : ''}`;

      const remEl = document.getElementById('pay-credit-remaining');
      if (remEl) remEl.innerHTML = `${_fmtCur(creditDueC1, c1)} ${creditDueC1 > 0 ? `<span style="font-size:0.75rem;color:var(--text-muted)">(${_fmtCur(creditDueC2, c2)})</span>` : ''}`;

      const newBalEl = document.getElementById('pay-credit-new-balance');
      if (newBalEl) newBalEl.innerHTML = _fmtCur(newCustBalance, c1);

      if (tenderedC1 < totalC1) {
        if (lblChange1) lblChange1.textContent = `${isAR ? 'المبلغ الآجل المتبقي (دين)' : 'Remaining Credit (Debt)'} (${c1})`;
        if (lblChange2) lblChange2.textContent = `${isAR ? 'المبلغ الآجل بـ' : 'Remaining Credit in'} ${c2}`;
        if (payChangeEl) {
          payChangeEl.innerHTML = `<span style="color:#ef4444;font-size:1.15rem;font-weight:900">${_fmtCur(creditDueC1, c1)}</span> ${tenderedC1 > 0 ? `<span style="font-size:0.75rem;color:var(--success);font-weight:700">(${isAR ? 'مسدد:' : 'Paid:'} ${_fmtCur(tenderedC1, c1)})</span>` : ''}`;
        }
        if (payChange2El) {
          payChange2El.innerHTML = _fmtCur(creditDueC2, c2);
          payChange2El.style.color = '#f59e0b';
        }
      } else {
        const changeC1 = Math.max(0, tenderedC1 - totalC1);
        const changeC2 = _calcSecondaryPrice(changeC1);
        if (lblChange1) lblChange1.textContent = `${isAR ? 'الباقي (المبلغ مسدد بالكامل)' : 'Change (Fully Paid)'} (${c1})`;
        if (lblChange2) lblChange2.textContent = `${isAR ? 'الباقي بـ' : 'Change in'} ${c2}`;
        if (payChangeEl) {
          payChangeEl.innerHTML = _fmtCur(changeC1, c1);
          payChangeEl.style.color = 'var(--success)';
        }
        if (payChange2El) {
          payChange2El.innerHTML = _fmtCur(changeC2, c2);
          payChange2El.style.color = 'var(--warning)';
        }
      }
    } else {
      const changeC1 = Math.max(0, tenderedC1 - totalC1);
      const changeC2 = _calcSecondaryPrice(changeC1);
      if (lblChange1) lblChange1.textContent = `${isAR ? 'الباقي' : 'Change'} (${c1})`;
      if (lblChange2) lblChange2.textContent = `${isAR ? 'الباقي بـ' : 'Change in'} ${c2}`;
      if (payChangeEl) {
        payChangeEl.innerHTML = _fmtCur(changeC1, c1);
        payChangeEl.style.color = 'var(--success)';
      }
      if (payChange2El) {
        payChange2El.innerHTML = _fmtCur(changeC2, c2);
        payChange2El.style.color = 'var(--warning)';
      }
    }
  }

  function calcMixed() {
    const cash  = parseFloat(document.getElementById('pay-cash-amt').value) || 0;
    const card  = parseFloat(document.getElementById('pay-card-amt').value) || 0;
    const total = window._posGrandTotal || 0;
    const remain = Utils.round(total - cash - card);
    const el = document.getElementById('pay-mixed-remain');
    if (el) {
      el.textContent = `${_settings.currency1} ${Utils.formatCurrency(Math.max(0, remain))}`;
      el.style.color = remain > 0 ? 'var(--danger)' : 'var(--success)';
    }
  }

  // ── Quick Cash Pay & Close (Bypasses Payment Modal) ──
  async function quickCashPay(shouldPrint = true) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (!_cart || _cart.length === 0) {
      Utils.toast(isAR ? '⚠️ سلة المبيعات فارغة، يرجى إضافة أصناف أولاً' : '⚠️ Cart is empty, please add items first', 'warning');
      _playErrorTone();
      return;
    }
    await updateTotals();
    const total = window._posGrandTotal || 0;
    if (total <= 0) {
      Utils.toast(isAR ? '⚠️ إجمالي الفاتورة غير صالح' : '⚠️ Invalid invoice total', 'warning');
      return;
    }

    // Set tender to exact total in cash
    window._posPayMethod = 'cash';
    const pt = document.getElementById('pay-tendered');
    if (pt) pt.value = total.toFixed(2);
    const pt2 = document.getElementById('pay-tendered-2');
    if (pt2) pt2.value = '0';

    await processPayment(shouldPrint);
  }

  async function processPayment(shouldPrint = null) {
    const method = window._posPayMethod || 'cash';
    const total  = window._posGrandTotal || 0;
    const isAR   = i18n.getLang() === 'ar';
    const custId = _customer ? _customer.id : (document.getElementById('pos-customer')?.value || null);

    // Hard Check: On Account requires explicit customer
    if (method === 'credit' && !custId) {
      Utils.toast(isAR ? '⚠️ يرجى تحديد عميل للبيع الآجل' : '⚠️ Customer selection required for Credit sale', 'error');
      return;
    }

    if (method === 'cash') {
      let tendered = parseFloat(document.getElementById('pay-tendered')?.value);
      if (isNaN(tendered) || tendered <= 0) {
        tendered = total;
        const pt = document.getElementById('pay-tendered');
        if (pt) pt.value = total.toFixed(2);
      }
      if (tendered < total) {
        Utils.toast(isAR ? 'المبلغ المستلم أقل من الإجمالي' : 'Amount tendered is less than total', 'error');
        return;
      }
    }

    const ref  = await DB.nextSeq('sales', _getInvoicePrefix(), 6);
    const user = Auth.getUser();

    let custName = isAR ? 'عميل عابر' : 'Walk-in Customer';
    let customerObj = null;
    if (custId) {
      customerObj = await DB.get('customers', parseInt(custId));
      if (customerObj) custName = customerObj.name_en || customerObj.name_ar;
    }

    const tenderedInputVal = parseFloat(document.getElementById('pay-tendered')?.value) || 0;
    let downPayment = 0;
    let creditDue = 0;
    let paidAmount = total;
    let tenderedVal = tenderedInputVal;

    if (method === 'credit') {
      downPayment = Math.min(total, Math.max(0, tenderedInputVal));
      creditDue = Utils.round(total - downPayment);
      paidAmount = downPayment;
      tenderedVal = downPayment;
    } else if (method === 'cash') {
      tenderedVal = tenderedInputVal || total;
      paidAmount = total;
    } else if (method === 'mixed') {
      const mixedCash = parseFloat(document.getElementById('pay-cash-amt')?.value) || 0;
      const mixedCard = parseFloat(document.getElementById('pay-card-amt')?.value) || 0;
      paidAmount = total;
      tenderedVal = mixedCash + mixedCard;
    }

    const tenderedVal2 = parseFloat(document.getElementById('pay-tendered-2')?.value) || _calcSecondaryPrice(tenderedVal);
    const changeC1 = method === 'credit' ? Math.max(0, tenderedInputVal - total) : Math.max(0, tenderedVal - total);
    const changeC2 = _calcSecondaryPrice(changeC1);

    const discType = document.getElementById('pos-discount-type')?.value || 'pct';
    const discVal  = parseFloat(document.getElementById('pos-discount-val')?.value) || 0;

    const sale = {
      ref,
      customer_id:     custId ? parseInt(custId) : null,
      customer_name:   custName,
      salesperson_id:  user?.id || null,
      salesperson_name: user?.full_name || user?.username || 'Cashier',
      items:           JSON.stringify(_cart),
      subtotal:        window._posSubtotal,
      discount:        window._posDiscount,
      discount_amount: window._posDiscount,
      discount_type:   discType,
      discount_val:    discVal,
      manual_discount: window._posManualDisc || 0,
      promo_discount:  window._posPromoDisc || 0,
      points_discount: window._posPointsDisc || 0,
      points_redeemed: window._posRedeemedPts || 0,
      points_earned:   window._posPointsEarned || 0,
      vat:             window._posVat,
      grand_total:     total,
      grand_total_2:   window._posTotal2,
      payment_method:  method,
      amount_tendered: tenderedVal,
      amount_tendered_2: tenderedVal2,
      paid_amount:     paidAmount,
      credit_amount:   method === 'credit' ? creditDue : 0,
      change_c1:       changeC1,
      change_c2:       changeC2,
      status:          (method === 'credit' ? (creditDue > 0 ? (downPayment > 0 ? 'partial' : 'unpaid') : 'paid') : (total < 0 ? 'returned' : (_cart.some(c => c.line_type === 'sale' || c.line_type === 'return') ? 'paid' : 'damaged'))),
      tx_mode:         _txMode,
      cashier:         user?.full_name || user?.username || 'Cashier',
      terminal_id:     localStorage.getItem('sync_node_id') || localStorage.getItem('redshark_pos_terminal') || 'POS-1',
      branch_id:       localStorage.getItem('sync_branch_id') || 'main',
      created_at:      new Date().toISOString(),
    };

    // Update Customer Loyalty Points & Balance in DB
    let liveCust = null;
    if (custId) {
      liveCust = await DB.get('customers', parseInt(custId)) || customerObj;
    }

    if (liveCust && _settings.loyaltyEnabled && _txMode === 'sale') {
      const currentPts = liveCust.points_balance || 0;
      const ptsEarned = window._posPointsEarned || 0;
      const ptsRedeemed = window._posRedeemedPts || 0;
      const newPtsBal = Math.max(0, currentPts - ptsRedeemed + ptsEarned);
      liveCust.points_balance = newPtsBal;
      sale.new_points_balance = newPtsBal;
      sale.customer_points = newPtsBal;
      if (_customer) _customer.points_balance = newPtsBal;
    }

    // Update Customer balance if Credit (On Account) sale based on remaining debt
    if (method === 'credit' && liveCust) {
      const newCustBal = Utils.round((liveCust.balance || 0) + creditDue);
      liveCust.balance = newCustBal;
      sale.customer_balance = newCustBal;
      if (_customer) _customer.balance = newCustBal;
      window._posSelectedCustBalance = newCustBal;
    }

    if (liveCust) {
      await DB.update('customers', liveCust);
    }

    const saleId = await DB.add('sales', sale);

    // If Credit sale had a down payment, record receipt transaction in cash_transactions
    if (method === 'credit' && custId && downPayment > 0) {
      try {
        const rcptRef = await DB.nextSeq('cash_transactions', 'RCPT-', 5);
        await DB.add('cash_transactions', {
          ref: rcptRef,
          type: 'receipt',
          date: sale.created_at,
          amount: downPayment,
          customer_id: parseInt(custId),
          customer_name: custName,
          description: isAR ? `دفعة مقدمة مسددة على فاتورة آجل #${ref}` : `Down payment on credit invoice #${ref}`,
          payment_method: 'cash',
          sale_id: saleId,
          sale_ref: ref
        });
      } catch (errTxn) {
        console.warn('Could not record down payment transaction in cash_transactions:', errTxn);
      }
    }

    // Record movement in CashBox for POS transactions (Cash, down payment, or mixed cash)
    const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
    if (cb && typeof cb.recordSale === 'function') {
      let cashToRecord = 0;
      if (method === 'cash') cashToRecord = total;
      else if (method === 'credit') cashToRecord = downPayment;
      else if (method === 'mixed') cashToRecord = parseFloat(document.getElementById('pay-cash-amt')?.value) || 0;

      if (cashToRecord !== 0) {
        await cb.recordSale(cashToRecord, `POS Transaction ${ref} (${method.toUpperCase()}${method === 'credit' && downPayment > 0 ? ' Down Payment' : ''})`);
      }
    }


    // Update stock based on each item's line_type
    const whId = window._posWarehouseId || 1;
    for (const item of _cart) {
      const itm = await DB.get('items', item.item_id);
      if (!itm) continue;

      // Initialize warehouse stocks if not exists
      if (!itm.warehouse_stocks) {
        itm.warehouse_stocks = {};
      }
      // Ensure all warehouses are set up on item
      if (itm.warehouse_stocks[whId] === undefined) {
        itm.warehouse_stocks[whId] = itm.stock_qty || 0;
      }

      const qty = item.qty;
      const type = item.line_type || 'sale';

      if (type === 'sale' || type === 'damage') {
        const newWhQty = (itm.warehouse_stocks[whId] || 0) - qty;
        const newTotalQty = (itm.stock_qty || 0) - qty;
        
        itm.warehouse_stocks[whId] = _settings.allowNegativeStock ? newWhQty : Math.max(0, newWhQty);
        itm.stock_qty = _settings.allowNegativeStock ? newTotalQty : Math.max(0, newTotalQty);

        // Box Link Logic
        if (itm.selling_unit === 'box' && itm.linked_item_id && itm.pieces_per_box > 1) {
          const linked = await DB.get('items', itm.linked_item_id);
          if (linked) {
            if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
            if (linked.warehouse_stocks[whId] === undefined) linked.warehouse_stocks[whId] = linked.stock_qty || 0;
            
            const linkedDelta = qty * itm.pieces_per_box;
            const newLinkedWhQty = (linked.warehouse_stocks[whId] || 0) - linkedDelta;
            const newLinkedTotalQty = (linked.stock_qty || 0) - linkedDelta;
            
            linked.warehouse_stocks[whId] = _settings.allowNegativeStock ? newLinkedWhQty : Math.max(0, newLinkedWhQty);
            linked.stock_qty = _settings.allowNegativeStock ? newLinkedTotalQty : Math.max(0, newLinkedTotalQty);
            
            await DB.update('items', linked);
          }
        }
        
        await DB.update('items', itm);
        
        await DB.add('stock_movements', {
          item_id: item.item_id,
          type: type,
          ref,
          qty: -qty,
          notes: `${type === 'damage' ? 'Damaged Item Write-off' : 'Sale'} ${ref}`
        });
      } else if (type === 'return') {
        itm.warehouse_stocks[whId] = (itm.warehouse_stocks[whId] || 0) + qty;
        itm.stock_qty = (itm.stock_qty || 0) + qty;

        // Box Link Logic
        if (itm.selling_unit === 'box' && itm.linked_item_id && itm.pieces_per_box > 1) {
          const linked = await DB.get('items', itm.linked_item_id);
          if (linked) {
            if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
            if (linked.warehouse_stocks[whId] === undefined) linked.warehouse_stocks[whId] = linked.stock_qty || 0;
            
            const linkedDelta = qty * itm.pieces_per_box;
            linked.warehouse_stocks[whId] = (linked.warehouse_stocks[whId] || 0) + linkedDelta;
            linked.stock_qty = (linked.stock_qty || 0) + linkedDelta;
            
            await DB.update('items', linked);
          }
        }

        await DB.update('items', itm);

        await DB.add('stock_movements', {
          item_id: item.item_id,
          type: 'return',
          ref,
          qty: qty,
          notes: `Sales Return ${ref}`
        });
      }
    }

    // Reload fresh items from DB to update in-memory stock immediately
    _items = await DB.getAll('items', i => i.status !== 'inactive');

    // Update items display immediately on the POS screen
    const searchVal = document.getElementById('pos-search')?.value;
    if (searchVal) {
      filterItems(searchVal);
    } else if (_activeCatId === 'categories') {
      showCategories();
    } else {
      filterByCategory(_activeCatId);
    }

    Utils.closeModal('payment-modal');
    window._lastSale = { ...sale, id: saleId };
    await updatePosInvoiceDisplay();

    // Push transaction to Server for centralized reporting
    if (window.BranchSync && typeof BranchSync.pushLocalTransactions === 'function') {
      try { BranchSync.pushLocalTransactions(); } catch(e) {}
    }

    // Instantly sync sale and cashbox to Cloud Storefront & Mobile Admin App
    if (window.OnlineOrders && typeof OnlineOrders.syncPosSalesToCloud === 'function') {
      try {
        OnlineOrders.syncPosSalesToCloud();
        OnlineOrders.syncCashboxStatusToCloud();
      } catch(e) {}
    }


    const doPrint = (shouldPrint !== null)
      ? shouldPrint === true
      : ((typeof _settings.autoPrint !== 'undefined') ? _settings.autoPrint !== false : (await DB.getSetting('auto_print', true) !== false));

    const shouldPreview = (typeof _settings.previewReceipt !== 'undefined')
      ? _settings.previewReceipt === true
      : (await DB.getSetting('pos_preview_receipt', false) === true);

    if (doPrint) {
      Utils.toast(isAR ? `✅ تم إتمام الدفع وجاري طباعة الفاتورة ${ref}` : `✅ Payment confirmed & printing: ${ref}`, 'success');
      // Dispatch printing in background so the cashier UI resets immediately without waiting for printer
      (async () => {
        try {
          const recSize = await DB.getSetting('receipt_size', '80mm');
          const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (sale.items || []);
          let cust = null;
          if (sale.customer_id) {
            try { cust = await DB.get('customers', sale.customer_id); } catch (e) {}
          }
          if (!cust && sale.customer_name) {
            cust = { name_ar: sale.customer_name, name_en: sale.customer_name };
          }
          let printed = false;
          const isDoc = ['a4', 'a5', 'letter', 'legal'].includes(String(recSize || '').toLowerCase());
          if (isDoc) {
            if (window.PrintEngine && typeof window.PrintEngine.printInvoice === 'function') {
              try {
                await window.PrintEngine.printInvoice(sale, items, cust, { pageSize: recSize });
                printed = true;
              } catch (eInv) {
                console.error('PrintEngine.printInvoice error, falling back:', eInv);
              }
            }
            if (!printed) {
              const receiptHtml = await generateReceiptHTML(sale);
              await Utils.printElement(`<div class="receipt-80mm" dir="${isAR ? 'rtl' : 'ltr'}">${receiptHtml}</div>`, 'Invoice', recSize || 'A4');
            }
          } else {
            if (window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
              try {
                await window.PrintEngine.printReceipt(sale, items, cust, { pageSize: recSize || '80mm' });
                printed = true;
              } catch (eRcpt) {
                console.error('PrintEngine.printReceipt error, falling back:', eRcpt);
              }
            }
            if (!printed) {
              const receiptHtml = await generateReceiptHTML(sale);
              await Utils.printElement(`<div class="receipt-80mm" dir="${isAR ? 'rtl' : 'ltr'}">${receiptHtml}</div>`, 'Receipt', recSize || '80mm');
            }
          }
        } catch (printErr) {
          console.error('POS Print Error:', printErr);
          try {
            const receiptHtml = await generateReceiptHTML(sale);
            await Utils.printElement(`<div class="receipt-80mm" dir="${isAR ? 'rtl' : 'ltr'}">${receiptHtml}</div>`, 'Receipt', '80mm');
          } catch(e) {}
        }
      })();
    } else {
      Utils.toast(isAR ? `✅ تم إتمام الدفع وحفظ الفاتورة ${ref}` : `✅ Payment confirmed without print: ${ref}`, 'success');
    }

    // Immediately start new sale without waiting for printer hardware
    await newSale();
    if (window.AICopilot && typeof AICopilot.playAudio === 'function') {
      AICopilot.playAudio('pay');
    }
    _broadcastCustomerDisplay(true);
  }

  // ── Show Receipt (Uses PrintEngine as Single Source of Truth with Designer Styling) ──
  async function generateReceiptHTML(sale) {
    if (window.PrintEngine && typeof window.PrintEngine.generateReceiptHtml === 'function') {
      try {
        const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (Array.isArray(sale.items) ? sale.items : []);
        let cust = null;
        if (sale.customer_id) {
          try { cust = await DB.get('customers', sale.customer_id); } catch (e) {}
        }
        if (!cust && sale.customer_name) {
          cust = { name_ar: sale.customer_name, name_en: sale.customer_name };
        }
        return await window.PrintEngine.generateReceiptHtml(sale, items, cust, { isPreview: true });
      } catch (e) {
        console.error('PrintEngine.generateReceiptHtml error in pos.js:', e);
      }
    }

    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? (i18n.getLang() === 'ar') : true;
    const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (Array.isArray(sale.items) ? sale.items : []);
    const cur1 = _settings.currency1 || 'USD';
    const cur2 = _settings.currency2 || 'LBP';
    const rate = parseFloat(_settings.exchRate) || 89500;

    const gt2 = sale.grand_total_2 || _calcSecondaryPrice(sale.grand_total);
    const tendered2 = sale.amount_tendered_2 || _calcSecondaryPrice(sale.amount_tendered || sale.grand_total);
    const changeC1  = sale.change_c1 || Math.max(0, (sale.amount_tendered || 0) - sale.grand_total);
    const changeC2  = sale.change_c2 || _calcSecondaryPrice(changeC1);
    const dec2 = (cur2 === 'LBP' || cur2 === 'IQD') ? 0 : 2;
    const showLogo = _settings.printLogo && _settings.companyLogo;

    return `
    <div dir="${isAR ? 'rtl' : 'ltr'}" style="font-family:'Segoe UI','Tahoma','Arial','Cairo',sans-serif;text-align:${isAR ? 'right' : 'left'};line-height:1.35;color:#000;font-weight:600;padding:6px 2px">
      <div style="text-align:center;margin-bottom:8px">
        ${showLogo ? `<div style="margin-bottom:6px"><img src="${_settings.companyLogo}" style="max-width:70px;max-height:60px;object-fit:contain"></div>` : ''}
        <div style="font-size:15pt;font-weight:900;letter-spacing:0.5px">${Utils.sanitize(_settings.companyName)}</div>
        ${_settings.companyAddress ? `<div style="font-size:9.5pt;margin-top:2px">${Utils.sanitize(_settings.companyAddress)}</div>` : ''}
        ${_settings.companyPhone ? `<div style="font-size:9.5pt;margin-top:2px">${isAR ? 'هاتف: ' : 'Tel: '}<bdi>${Utils.sanitize(_settings.companyPhone)}</bdi></div>` : ''}
        ${_settings.vatNumber ? `<div style="font-size:9.5pt;margin-top:2px">${isAR ? 'الرقم المالي: ' : 'Tax ID: '}<bdi>${Utils.sanitize(_settings.vatNumber)}</bdi></div>` : ''}
        <div style="font-size:10pt;font-weight:bold;margin-top:4px">${isAR ? 'فاتورة ضريبية' : 'TAX INVOICE'}</div>
      </div>
      <div style="border-top:1.5px dashed #000;margin:6px 0"></div>
      <div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:2px">
        <span>${isAR ? 'رقم الفاتورة:' : 'Ref:'}</span><span style="font-weight:800"><bdi>${sale.ref}</bdi></span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:2px">
        <span>${isAR ? 'التاريخ والوقت:' : 'Date & Time:'}</span><span style="font-weight:800"><bdi>${Utils.formatDateTime(sale.created_at)}</bdi></span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:2px">
        <span>${isAR ? 'العميل:' : 'Customer:'}</span><span style="font-weight:700">${Utils.sanitize(sale.customer_name || (isAR ? 'عميل عابر' : 'Walk-in'))}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:6px">
        <span>${isAR ? 'الكاشير:' : 'Cashier:'}</span><span>${Utils.sanitize(sale.cashier)}</span>
      </div>
      <div style="border-top:2px solid #000;margin:6px 0"></div>

      <!-- Items (Column Table Layout) -->
      <table style="width:100%;border-collapse:collapse;margin:5px 0;font-size:9.5pt;color:#000">
        <thead>
          <tr style="border-top:1.5px solid #000;border-bottom:1.5px solid #000;font-weight:900">
            <th style="text-align:${isAR?'right':'left'};padding:3px 1px;width:44%">${isAR?'الصنف':'Item'}</th>
            <th style="text-align:center;padding:3px 1px;width:14%">${isAR?'الكمية':'Qty'}</th>
            <th style="text-align:center;padding:3px 1px;width:20%">${isAR?'السعر':'Price'}</th>
            <th style="text-align:${isAR?'left':'right'};padding:3px 1px;width:22%">${isAR?'المجموع':'Total'}</th>
          </tr>
        </thead>
        <tbody>
          ${items.map(i => {
            const name = isAR ? (i.name_ar || i.name_en || i.name) : (i.name_en || i.name_ar || i.name);
            const unitPrice = (i.line_type === 'damage' || i.line_type === 'gift') ? 0 : (i.price || 0);
            const lineTotal = i.total !== undefined ? i.total : (unitPrice * (i.qty || 1));
            return `
            <tr style="border-bottom:1px dashed #000;vertical-align:top">
              <td style="text-align:${isAR?'right':'left'};padding:3px 1px;font-weight:700">${Utils.sanitize(name)}</td>
              <td style="text-align:center;padding:3px 1px;font-weight:800;white-space:nowrap">${i.qty || 1}</td>
              <td style="text-align:center;padding:3px 1px;font-weight:700;white-space:nowrap">${Utils.formatCurrency(unitPrice)}</td>
              <td style="text-align:${isAR?'left':'right'};padding:3px 1px;font-weight:900;white-space:nowrap">${Utils.formatCurrency(lineTotal)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>

      <div style="border-top:2px solid #000;margin:6px 0"></div>
      <div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:2px">
        <span>${isAR ? 'المجموع الفرعي:' : 'Subtotal:'}</span><span style="font-weight:700"><bdi>${cur1} ${Utils.formatCurrency(sale.subtotal)}</bdi></span>
      </div>
      ${(parseFloat(sale.discount || sale.discount_amount || 0) > 0) ? `
      <div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:2px;font-weight:800;color:#000 !important">
        <span>${isAR ? 'الخصم:' : 'Discount:'}</span>
        <span><bdi>-${cur1} ${Utils.formatCurrency(sale.discount || sale.discount_amount)}</bdi></span>
      </div>` : ''}
      ${parseFloat(sale.vat) > 0 ? `<div style="display:flex;justify-content:space-between;font-size:9.5pt;margin-bottom:2px">
        <span>${isAR ? 'ضريبة القيمة المضافة:' : 'VAT:'}</span><span><bdi>${cur1} ${Utils.formatCurrency(sale.vat)}</bdi></span>
      </div>` : ''}

      <!-- Highlighted Net Total Box (Pure Solid Contrast) -->
      <div style="border:2px solid #000;background:#ffffff;padding:6px 8px;margin:6px 0 5px;border-radius:4px">
        <div style="display:flex;justify-content:space-between;font-size:11pt;font-weight:900;border-bottom:1.5px dashed #000;padding-bottom:4px;margin-bottom:4px;color:#000">
          <span>${isAR ? `الإجمالي (<bdi>${cur1}</bdi>):` : `TOTAL (${cur1}):`}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(sale.grand_total)}</bdi></span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:9.5pt;font-weight:900;color:#000">
          <span>${isAR ? `المعادل بـ (${cur2}):` : `In ${cur2}:`}</span>
          <span><bdi>${Utils.formatCurrency(gt2, '', dec2)} ${cur2}</bdi></span>
        </div>
      </div>

      <div style="text-align:center;font-size:8pt;color:#333;margin-top:10px;border-top:1px dashed #000;padding-top:6px">
        <div>${_settings.receiptFooter ? Utils.sanitize(_settings.receiptFooter) : (isAR ? 'شكراً لتعاملكم معنا ونسعد بخدمتكم' : 'Thank you for your business!')}</div>
      </div>
    </div>`;
  }

  async function showReceipt(sale) {
    const sales = await DB.getAll('sales');
    window._historySaleIndex = sales.findIndex(s => s.id === sale.id);
    if (window._historySaleIndex === -1) {
      window._historySaleIndex = sales.length - 1;
    }
    window._lastSale = sale;
    const html = await generateReceiptHTML(sale);
    Utils.setHTML('#receipt-preview', html);
    Utils.openModal('receipt-modal');
  }

  async function loadBrowsedSaleToCart() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const sale = window._lastSale;
    if (!sale) return;
    const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (Array.isArray(sale.items) ? sale.items : []);
    if (!items || !items.length) {
      Utils.toast(isAR ? 'الفاتورة لا تحتوي على أصناف' : 'Invoice contains no items', 'warning');
      return;
    }
    _cart = items.map(i => Object.assign({}, i));
    if (sale.customer_id) {
      selectCustomerOption(sale.customer_id);
    } else {
      selectCustomerOption(null);
    }
    Utils.closeModal('receipt-modal');
    renderCart();
    updateTotals();
    Utils.toast(isAR ? `✅ تم تحميل ${items.length} أصناف من الفاتورة ${sale.ref || ''} في السلة` : `✅ Loaded ${items.length} items from ${sale.ref || ''} into cart`, 'success');
  }

  async function showLatestInvoice() {
    const isAR = i18n.getLang() === 'ar';
    const sales = await DB.getAll('sales');
    if (!sales.length) {
      Utils.toast(isAR ? 'لا توجد فواتير بعد' : 'No invoices found', 'warning');
      return;
    }
    const latest = sales[sales.length - 1];
    await showReceipt(latest);
  }

  async function navigateHistory(direction) {
    const isAR = i18n.getLang() === 'ar';
    const sales = await DB.getAll('sales');
    if (!sales.length) return;
    
    let newIndex = window._historySaleIndex + direction;
    if (newIndex < 0) {
      Utils.toast(isAR ? 'هذه أقدم فاتورة' : 'This is the oldest invoice', 'info');
      return;
    }
    if (newIndex >= sales.length) {
      Utils.toast(isAR ? 'هذه أحدث فاتورة' : 'This is the latest invoice', 'info');
      return;
    }
    
    window._historySaleIndex = newIndex;
    const sale = sales[newIndex];
    window._lastSale = sale;
    
    const html = await generateReceiptHTML(sale);
    Utils.setHTML('#receipt-preview', html);
  }

  function buildReceiptData(sale, paperSize = '80mm') {
    if (!sale) return null;
    const isAR = i18n.getLang() === 'ar';
    const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (Array.isArray(sale.items) ? sale.items : []);
    const cur1 = _settings.currency1 || 'USD';
    const cur2 = _settings.currency2 || 'LBP';
    const gt2 = sale.grand_total_2 || _calcSecondaryPrice(sale.grand_total);
    const changeC1 = sale.change_c1 || Math.max(0, (sale.amount_tendered || 0) - sale.grand_total);
    const discAmt = parseFloat(sale.discount || sale.discount_amount || 0);

    let discLabel = isAR ? 'الخصم:' : 'Discount:';
    if (sale.discount_type === 'pct' && (parseFloat(sale.discount_val) || 0) > 0) {
      discLabel = isAR ? `الخصم (${sale.discount_val}%):` : `Discount (${sale.discount_val}%):`;
    } else if (sale.discount_type === 'amt' && (parseFloat(sale.discount_val) || 0) > 0) {
      discLabel = isAR ? `الخصم (${cur1} ${Utils.formatCurrency(sale.discount_val)}):` : `Discount (${cur1} ${Utils.formatCurrency(sale.discount_val)}):`;
    }

    return {
      is_ar: isAR,
      direction: isAR ? 'rtl' : 'ltr',
      store_name: _settings.companyName || 'Red Shark POS Store',
      address: _settings.companyAddress || '',
      phone: _settings.companyPhone || '',
      tax_id: _settings.vatNumber || '',
      doc_title: isAR ? 'إيصال مبيعات' : 'Sales Receipt',
      ref: sale.ref,
      date: Utils.formatDateTime(sale.created_at),
      customer: sale.customer_name || (isAR ? 'عميل عابر' : 'Walk-in Customer'),
      cashier: sale.cashier || 'Administrator',
      paper_size: paperSize,
      ref_label: isAR ? 'رقم:' : 'Ref:',
      date_label: isAR ? 'التاريخ والوقت:' : 'Date & Time:',
      customer_label: isAR ? 'العميل:' : 'Customer:',
      cashier_label: isAR ? 'الكاشير:' : 'Cashier:',
      phone_label: isAR ? 'هاتف:' : 'Tel:',
      tax_label: isAR ? 'الرقم المالي:' : 'Tax ID:',
      desc_header: isAR ? 'الصنف والمواصفات' : 'Item Description',
      qty_header: isAR ? 'الكمية × السعر' : 'Qty x Unit Price',
      total_header: isAR ? 'المجموع' : 'Total',
      subtotal_label: isAR ? 'المجموع الفرعي:' : 'Subtotal:',
      vat_label: isAR ? 'الضريبة:' : 'VAT:',
      total_label: isAR ? 'الإجمالي:' : 'TOTAL:',
      equiv_label: isAR ? 'المعادل:' : 'Equiv:',
      tendered_label: isAR ? 'المستلم:' : 'Tendered:',
      change_label: isAR ? 'الباقي:' : 'Change:',
      items: items.map(it => {
        let itDiscAmt = 0;
        if (it.disc_type === 'amt') {
          itDiscAmt = parseFloat(it.disc_amt) || 0;
        } else if (parseFloat(it.disc_pct) > 0) {
          itDiscAmt = Utils.round((parseFloat(it.price) || 0) * ((parseFloat(it.disc_pct) || 0) / 100));
        }
        return {
          name: isAR ? (it.name_ar || it.name_en || it.name) : (it.name_en || it.name_ar || it.name),
          qty: it.qty,
          price: `${cur1} ${Utils.formatCurrency(it.price)}`,
          discount: itDiscAmt > 0 ? (it.disc_type === 'amt' ? `${cur1} ${Utils.formatCurrency(itDiscAmt)}` : `${it.disc_pct}%`) : '',
          total: `${cur1} ${Utils.formatCurrency(it.total)}`
        };
      }),
      subtotal: `${cur1} ${Utils.formatCurrency(sale.subtotal || sale.grand_total)}`,
      discount: discAmt > 0 ? `${cur1} ${Utils.formatCurrency(discAmt)}` : '',
      discount_label: discLabel,
      vat: (sale.vat || sale.vat_amount) ? `${cur1} ${Utils.formatCurrency(sale.vat || sale.vat_amount)}` : '',
      grand_total: `${cur1} ${Utils.formatCurrency(sale.grand_total)}`,
      grand_total_2: gt2 ? `${Math.round(gt2).toLocaleString()} ${cur2}` : '',
      tendered: `${cur1} ${Utils.formatCurrency(sale.amount_tendered || sale.grand_total)}`,
      change: `${cur1} ${Utils.formatCurrency(changeC1)}`,
      payment_method: sale.payment_method || 'cash',
      paid_amount: parseFloat(sale.paid_amount || 0),
      credit_amount: parseFloat(sale.credit_amount !== undefined ? sale.credit_amount : (sale.grand_total - (sale.paid_amount || 0))),
      customer_balance: sale.customer_balance,
      footer: _settings.receiptFooter || (isAR ? 'شكراً لزيارتكم!' : 'Thank you for your business!')
    };
  }

  async function printReceipt() {
    let sale = window._lastSale;
    const recSize = await DB.getSetting('receipt_size', '80mm');
    if (!sale) {
      const sales = await DB.getAll('sales');
      if (sales && sales.length) sale = sales[sales.length - 1];
    }
    if (sale && window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
      const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (sale.items || []);
      let cust = null;
      if (sale.customer_id) {
        try { cust = await DB.get('customers', sale.customer_id); } catch(e) {}
      }
      if (!cust && sale.customer_name) {
        cust = { name_ar: sale.customer_name, name_en: sale.customer_name };
      }
      await window.PrintEngine.printReceipt(sale, items, cust);
      return;
    }
    const html = document.getElementById('receipt-preview')?.innerHTML || '';
    if (html) {
      await Utils.printElement(`<div class="receipt-80mm" dir="${i18n.getLang() === 'ar' ? 'rtl' : 'ltr'}">${html}</div>`, 'Receipt', recSize);
    } else {
      Utils.toast(i18n.getLang() === 'ar' ? 'لا توجد فاتورة للطباعة' : 'No invoice to print', 'warning');
    }
  }

  // ── Print A4 Invoice ──
  async function printA4() {
    let sale = window._lastSale;
    if (!sale) {
      const sales = await DB.getAll('sales');
      if (sales && sales.length) sale = sales[sales.length - 1];
    }
    if (!sale) {
      Utils.toast(i18n.getLang() === 'ar' ? 'لا توجد فاتورة للطباعة' : 'No invoice to print', 'warning');
      return;
    }
    const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (sale.items || []);
    let cust = null;
    if (sale.customer_id) {
      try { cust = await DB.get('customers', sale.customer_id); } catch(e) {}
    }
    if (!cust && sale.customer_name) {
      cust = { name_ar: sale.customer_name, name_en: sale.customer_name };
    }
    if (window.PrintEngine && typeof window.PrintEngine.printInvoice === 'function') {
      await window.PrintEngine.printInvoice(sale, items, cust, { pageSize: 'A4' });
    } else {
      const receiptHtml = await generateReceiptHTML(sale);
      await Utils.printElement(`<div class="receipt-80mm" dir="${i18n.getLang() === 'ar' ? 'rtl' : 'ltr'}">${receiptHtml}</div>`, `Invoice ${sale.ref}`, 'A4');
    }
  }

  async function newSale() {
    Utils.closeModal('receipt-modal');
    _cart = [];
    _customer = null;
    _redeemedPoints = 0;
    _pointsDiscount = 0;
    _activePromoDiscount = 0;
    _activePromoLabel = '';
    selectCustomerOption(null);
    renderCart();
    updateTotals();
    updateHeldUI();
    await updatePosInvoiceDisplay();
    const s = document.getElementById('pos-search');
    if (s) { s.value = ''; }
    _items = await DB.getAll('items', i => i.status !== 'inactive');
    showCategories();
  }

  // ── Retail Item Notes ──

  async function openItemNoteModal(idx) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const item = _cart[idx];
    if (!item) return;

    const bMode = (typeof License !== 'undefined' && typeof License.getBusinessMode === 'function') 
      ? await License.getBusinessMode() 
      : ((typeof DB !== 'undefined') ? await DB.getSetting('business_mode', 'retail') : 'retail');

    const defaultRetailModifiers = [
      { icon: '🎁', name_en: 'Gift Wrap', name_ar: 'تغليف كهدية' },
      { icon: '⚠️', name_en: 'Fragile / Handle with Care', name_ar: 'قابل للكسر / بعناية' },
      { icon: '📦', name_en: 'Open Box Inspection', name_ar: 'فحص وتجربة الصندوق' },
      { icon: '🚚', name_en: 'Urgent Delivery', name_ar: 'توصيل سريع ومستعجل' },
      { icon: '🛡️', name_en: '1-Year Warranty Included', name_ar: 'شامل كفالة سنة' },
      { icon: '🔄', name_en: 'Exchange Within 7 Days', name_ar: 'قابل للتبديل خلال 7 أيام' },
      { icon: '🏷️', name_en: 'Remove Price Tag', name_ar: 'إزالة بطاقة السعر' },
      { icon: '🔖', name_en: 'Special VIP Discount', name_ar: 'خصم خاص لكبار العملاء' }
    ];

    const defaultRestaurantModifiers = [
      { icon: '🚫', name_en: 'No Sugar', name_ar: 'بدون سكر' },
      { icon: '🍬', name_en: 'Extra Sugar', name_ar: 'سكر زيادة' },
      { icon: '🧊', name_en: 'Less Ice', name_ar: 'ثلج خفيف' },
      { icon: '🥛', name_en: 'Skim Milk', name_ar: 'حليب دايت' },
      { icon: '☕', name_en: 'Decaf', name_ar: 'بدون كافيين' },
      { icon: '🧅', name_en: 'No Onions', name_ar: 'بدون بصل' },
      { icon: '🌶️', name_en: 'Extra Spicy', name_ar: 'حار جداً' },
      { icon: '🥣', name_en: 'Sauce on side', name_ar: 'الصوص جانبي' },
      { icon: '🧂', name_en: 'No Salt', name_ar: 'بدون ملح' },
      { icon: '🥩', name_en: 'Well Done', name_ar: 'استواء كامل' },
      { icon: '🧀', name_en: 'Extra Cheese', name_ar: 'زيادة جبنة' }
    ];

    let modifiers = [];
    let modalTitle = isAR ? 'تفضيلات وملاحظات الصنف' : 'Item Notes & Modifiers';
    let labelText = isAR ? 'ملاحظة خاصة للمطبخ / البار:' : 'Kitchen / Bar / Chef Instructions:';
    let placeholderText = isAR ? 'اكتب أي تفاصيل إضافية أو حساسية طعام...' : 'Type custom instructions, allergy alert...';

    if (bMode === 'restaurant') {
      modifiers = await DB.getSetting('quick_modifiers_restaurant', defaultRestaurantModifiers);
      if (!Array.isArray(modifiers) || !modifiers.length) modifiers = defaultRestaurantModifiers;
      modalTitle = isAR ? 'تفضيلات وملاحظات الصنف' : 'Item Notes & Kitchen Modifiers';
      labelText = isAR ? 'ملاحظة خاصة للمطبخ / البار:' : 'Kitchen / Bar / Chef Instructions:';
      placeholderText = isAR ? 'اكتب أي تفاصيل إضافية أو حساسية طعام...' : 'Type custom instructions, allergy alert...';
    } else if (bMode === 'hybrid') {
      const restMods = await DB.getSetting('quick_modifiers_restaurant', defaultRestaurantModifiers) || defaultRestaurantModifiers;
      const retMods = await DB.getSetting('quick_modifiers_retail', defaultRetailModifiers) || defaultRetailModifiers;
      modifiers = [...retMods, ...restMods];
      modalTitle = isAR ? 'ملاحظات وتفضيلات الصنف الشاملة' : 'Item Notes & Modifiers';
      labelText = isAR ? 'ملاحظات وتفاصيل خاصة بالصنف / التحضير:' : 'Special Item Instructions & Notes:';
      placeholderText = isAR ? 'اكتب أي تفاصيل إضافية...' : 'Type custom instructions, requests...';
    } else {
      modifiers = await DB.getSetting('quick_modifiers_retail', defaultRetailModifiers);
      if (!Array.isArray(modifiers) || !modifiers.length) modifiers = defaultRetailModifiers;
      modalTitle = isAR ? 'ملاحظات وتفاصيل الصنف' : 'Item Notes & Special Requests';
      labelText = isAR ? 'ملاحظات وتوجيهات خاصة بالصنف:' : 'Special Item Notes & Instructions:';
      placeholderText = isAR ? 'اكتب ملاحظات إضافية، تغليف، كفالة...' : 'Type custom instructions, packaging, notes...';
    }

    const tagsHtml = modifiers.map(m => {
      const tagName = isAR ? (m.name_ar || m.name_en) : (m.name_en || m.name_ar);
      const enEsc = (m.name_en || '').replace(/'/g, "\\'");
      const arEsc = (m.name_ar || '').replace(/'/g, "\\'");
      return `<button type="button" class="btn btn-secondary btn-sm" onclick="POS.addTagToItemNote('${enEsc}', '${arEsc}')" style="display:flex;align-items:center;gap:4px">
        <span>${m.icon || '🏷️'}</span> <span>${Utils.sanitize(tagName)}</span>
      </button>`;
    }).join('');

    const modalHtml = `
    <div class="modal-overlay open" id="item-note-modal" style="z-index:9999">
      <div class="modal" style="max-width:460px;border-radius:18px">
        <div class="modal-header">
          <div class="modal-title" style="font-weight:800;font-size:1.08rem">📝 ${modalTitle}</div>
          <button class="btn-icon" onclick="document.getElementById('item-note-modal').remove()">✕</button>
        </div>
        <div class="modal-body" style="padding:16px 20px">
          <div style="font-size:0.95rem;font-weight:800;margin-bottom:12px;color:var(--primary);display:flex;align-items:center;gap:6px">
            <span>🏷️</span>
            <span>${Utils.sanitize(isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar))}</span>
          </div>

          <!-- Quick Preset Modifier Tags -->
          <div style="font-size:0.78rem;font-weight:700;color:var(--text-muted);margin-bottom:8px">
            ${isAR ? 'خيارات وملاحظات سريعة (اضغط للإضافة مباشرة):' : 'Quick Options (Tap to add):'}
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px;max-height:180px;overflow-y:auto;padding-right:2px">
            ${tagsHtml}
          </div>

          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-weight:700">${labelText}</label>
            <textarea class="form-control" id="cart-item-note-input" rows="2" placeholder="${placeholderText}">${item.notes || ''}</textarea>
          </div>
        </div>
        <div class="modal-footer" style="padding:12px 20px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="document.getElementById('item-note-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
          <button class="btn btn-primary" onclick="POS.saveItemNote(${idx})">💾 ${isAR ? 'حفظ الملاحظة' : 'Save Note'}</button>
        </div>
      </div>
    </div>`;

    document.getElementById('item-note-modal')?.remove();
    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  function addTagToItemNote(enTag, arTag) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const tag = isAR ? arTag : enTag;
    const input = document.getElementById('cart-item-note-input');
    if (!input) return;
    input.value = input.value ? `${input.value}, ${tag}` : tag;
  }

  function saveItemNote(idx) {
    const input = document.getElementById('cart-item-note-input');
    if (input && _cart[idx]) {
      _cart[idx].notes = input.value.trim();
      renderCart();
    }
    document.getElementById('item-note-modal')?.remove();
  }

  function showMobileView(view) {
    _currentMobileView = view;
    const root = document.getElementById('pos-root');
    const tabCat = document.getElementById('pos-tab-catalog-btn');
    const tabCart = document.getElementById('pos-tab-cart-btn');
    const floatBar = document.getElementById('pos-mobile-float-bar');
    if (!root) return;

    if (view === 'cart') {
      root.classList.add('mobile-show-cart');
      root.classList.remove('mobile-show-catalog');
      if (tabCat) tabCat.classList.remove('active');
      if (tabCart) tabCart.classList.add('active');
      if (floatBar) floatBar.style.display = 'none';
    } else {
      root.classList.add('mobile-show-catalog');
      root.classList.remove('mobile-show-cart');
      if (tabCat) tabCat.classList.add('active');
      if (tabCart) tabCart.classList.remove('active');
      if (floatBar && _cart.length > 0 && window.innerWidth <= 768) {
        floatBar.style.display = 'flex';
      }
    }
  }

  let _scaleActiveItem = null;
  let _scaleTareKg = 0;
  let _scaleActiveField = 'weight';
  let _scaleReplaceMode = true;

  async function openScaleModal(itemId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const item = _items.find(i => i.id === itemId) || await DB.get('items', itemId);
    if (!item) return;

    _scaleActiveItem = item;
    _scaleTareKg = parseFloat(item.tare_weight || 0);
    _scaleActiveField = 'weight';
    _scaleReplaceMode = true;

    const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    const unitPrice = parseFloat(item.selling_price || 0);
    const c1 = _settings.currency1 || 'USD';
    const unit = item.unit || (isAR ? 'كغ' : 'kg');

    const defaultWeight = 1.000;
    const initialTotal = Utils.round(defaultWeight * unitPrice, 2);

    const modalHtml = `
    <div class="modal-overlay open" id="pos-scale-modal" style="z-index:99999">
      <div class="modal" style="max-width:520px;border-radius:20px;overflow:hidden;background:var(--surface);box-shadow:0 25px 50px -12px rgba(0,0,0,0.6);border:1px solid rgba(2,132,199,0.3)">
        
        <!-- Header -->
        <div style="background:linear-gradient(135deg, #0284c7 0%, #0369a1 100%);color:white;padding:16px 20px;display:flex;align-items:center;justify-content:space-between">
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:42px;height:42px;background:rgba(255,255,255,0.2);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.5rem">⚖️</div>
            <div>
              <div style="font-weight:900;font-size:1.15rem;letter-spacing:0.3px">${Utils.sanitize(itemName)}</div>
              <div style="font-size:0.78rem;opacity:0.95;margin-top:2px">
                <span>${isAR ? 'سعر الكيلو:' : 'Price/kg:'} <strong>${_fmtCur(unitPrice, c1)}</strong></span>
                ${item.scale_plu ? ` • <span>PLU: <strong>${item.scale_plu}</strong></span>` : ''}
              </div>
            </div>
          </div>
          <button class="btn-icon" onclick="document.getElementById('pos-scale-modal').remove()" style="color:white;background:rgba(255,255,255,0.2);border-radius:50%;width:32px;height:32px">✕</button>
        </div>

        <div class="modal-body" style="padding:18px 22px">
          
          <!-- Electronic LCD Display -->
          <div style="background:#090d16;border:2px solid #0284c7;border-radius:14px;padding:14px 18px;margin-bottom:16px;box-shadow:inset 0 3px 10px rgba(0,0,0,0.8)">
            <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.75rem;font-weight:800;color:#38bdf8;text-transform:uppercase;margin-bottom:4px">
              <span>⚖️ ${isAR ? 'الوزن الصافي' : 'NET WEIGHT'}</span>
              <span id="scale-display-tare-badge" style="color:${_scaleTareKg > 0 ? '#f59e0b' : '#64748b'};font-weight:700">
                ${isAR ? 'فارغ الإناء (Tare):' : 'Tare:'} ${_scaleTareKg.toFixed(3)} kg
              </span>
              <span>💰 ${isAR ? 'المبلغ الإجمالي' : 'TOTAL AMOUNT'}</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:baseline">
              <div style="font-family:'Courier New', monospace;font-size:2.4rem;font-weight:900;color:#38bdf8;letter-spacing:1px">
                <span id="scale-display-weight">${defaultWeight.toFixed(3)}</span>
                <span style="font-size:1.1rem;font-weight:700;color:#94a3b8">${unit}</span>
              </div>
              <div style="font-family:'Courier New', monospace;font-size:2.4rem;font-weight:900;color:#10b981;letter-spacing:1px">
                <span id="scale-display-total">${_fmtCur(initialTotal, c1)}</span>
              </div>
            </div>
          </div>

          <!-- Quick Weight Presets Buttons -->
          <div style="margin-bottom:14px">
            <div style="font-size:0.72rem;font-weight:800;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase">
              ⚡ ${isAR ? 'أوزان سريعة شائعة (اضغط للتحديد الفوري):' : 'Quick Weight Presets:'}
            </div>
            <div style="display:grid;grid-template-columns:repeat(5, 1fr);gap:6px">
              <button type="button" class="btn btn-outline" onclick="POS.setScalePresetWeight(0.25)" style="font-weight:800;padding:8px 4px;font-size:0.8rem">250g (¼)</button>
              <button type="button" class="btn btn-outline" onclick="POS.setScalePresetWeight(0.50)" style="font-weight:800;padding:8px 4px;font-size:0.8rem">500g (½)</button>
              <button type="button" class="btn btn-outline" onclick="POS.setScalePresetWeight(0.75)" style="font-weight:800;padding:8px 4px;font-size:0.8rem">750g (¾)</button>
              <button type="button" class="btn btn-outline" onclick="POS.setScalePresetWeight(1.00)" style="font-weight:800;padding:8px 4px;font-size:0.8rem">1.0 kg</button>
              <button type="button" class="btn btn-outline" onclick="POS.setScalePresetWeight(2.00)" style="font-weight:800;padding:8px 4px;font-size:0.8rem">2.0 kg</button>
            </div>
          </div>

          <!-- Dual Inputs: By Weight vs By Money Price -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
            <div>
              <label class="form-label" style="font-size:0.78rem;font-weight:800;margin-bottom:4px">
                ${isAR ? 'الوزن بالكيلو (Weight):' : 'Enter Weight (kg):'}
              </label>
              <div class="input-group">
                <input type="number" class="form-control" id="scale-input-weight" value="${defaultWeight.toFixed(3)}" step="0.001" min="0.001"
                  style="font-size:1.3rem;font-weight:900;padding:8px 10px;color:#0284c7;font-family:monospace"
                  onfocus="POS.setScaleActiveField('weight'); this.select();"
                  onclick="POS.setScaleActiveField('weight'); this.select();"
                  oninput="POS.onScaleWeightInput(this.value)">
                <div class="input-group-addon" style="font-weight:800">${unit}</div>
              </div>
            </div>
            <div>
              <label class="form-label" style="font-size:0.78rem;font-weight:800;margin-bottom:4px">
                ${isAR ? 'أو بالمبلغ المالي (Price):' : 'Or By Money ($):'}
              </label>
              <div class="input-group">
                <input type="number" class="form-control" id="scale-input-price" value="${initialTotal.toFixed(2)}" step="0.01" min="0.01"
                  style="font-size:1.3rem;font-weight:900;padding:8px 10px;color:#10b981;font-family:monospace"
                  onfocus="POS.setScaleActiveField('price'); this.select();"
                  onclick="POS.setScaleActiveField('price'); this.select();"
                  oninput="POS.onScalePriceInput(this.value)">
                <div class="input-group-addon" style="font-weight:800">${c1}</div>
              </div>
            </div>
          </div>

          <!-- Touch Keypad & Scale Functions -->
          <div style="display:grid;grid-template-columns:3fr 1fr;gap:10px;margin-bottom:16px">
            <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:6px">
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('7')" style="font-size:1.2rem;font-weight:800;padding:10px">7</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('8')" style="font-size:1.2rem;font-weight:800;padding:10px">8</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('9')" style="font-size:1.2rem;font-weight:800;padding:10px">9</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('4')" style="font-size:1.2rem;font-weight:800;padding:10px">4</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('5')" style="font-size:1.2rem;font-weight:800;padding:10px">5</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('6')" style="font-size:1.2rem;font-weight:800;padding:10px">6</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('1')" style="font-size:1.2rem;font-weight:800;padding:10px">1</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('2')" style="font-size:1.2rem;font-weight:800;padding:10px">2</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('3')" style="font-size:1.2rem;font-weight:800;padding:10px">3</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('C')" style="font-size:1.1rem;font-weight:900;padding:10px;color:#ef4444">C</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('0')" style="font-size:1.2rem;font-weight:800;padding:10px">0</button>
              <button type="button" class="btn btn-secondary" onclick="POS.scaleKeypadPress('.')" style="font-size:1.2rem;font-weight:800;padding:10px">.</button>
            </div>

            <div style="display:flex;flex-direction:column;gap:6px">
              <button type="button" class="btn btn-secondary" onclick="POS.toggleScaleTare()" style="flex:1;font-size:0.75rem;font-weight:800;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:6px;border-radius:10px">
                <span style="font-size:1.2rem">🥣</span>
                <span>${isAR ? 'فارغ الإناء' : 'Tare'}</span>
                <span style="font-size:0.65rem;color:var(--text-muted)">${_scaleTareKg > 0 ? `${_scaleTareKg}kg` : '0kg'}</span>
              </button>
              <button type="button" class="btn btn-primary" onclick="POS.readHardwareScale()" style="flex:1;font-size:0.75rem;font-weight:800;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:6px;border-radius:10px;background:#0369a1">
                <span style="font-size:1.2rem">🔌</span>
                <span>${isAR ? 'قراءة الميزان' : 'Live Scale'}</span>
                <span style="font-size:0.65rem;opacity:0.85">USB/Serial</span>
              </button>
            </div>
          </div>

          <!-- Bottom Action Buttons -->
          <div style="display:flex;gap:10px">
            <button type="button" class="btn btn-ghost" onclick="document.getElementById('pos-scale-modal').remove()" style="flex:1;font-weight:700;padding:12px">
              ${isAR ? 'إلغاء (Esc)' : 'Cancel (Esc)'}
            </button>
            <button type="button" class="btn btn-success" onclick="POS.confirmScaleWeight()" style="flex:2;font-size:1.05rem;font-weight:900;padding:12px;border-radius:10px">
              ✅ ${isAR ? 'تأكيد وإضافة للسلة (Enter)' : 'Confirm & Add to Cart (Enter)'}
            </button>
          </div>
        </div>
      </div>
    </div>`;

    document.getElementById('pos-scale-modal')?.remove();
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    const wInput = document.getElementById('scale-input-weight');
    if (wInput) {
      wInput.focus();
      wInput.select();
    }
  }

  function setScaleActiveField(field) {
    _scaleActiveField = field;
    _scaleReplaceMode = true;
    const input = document.getElementById(field === 'price' ? 'scale-input-price' : 'scale-input-weight');
    if (input) {
      input.focus();
      input.select();
    }
  }

  function setScalePresetWeight(weightKg) {
    if (!_scaleActiveItem) return;
    _scaleReplaceMode = true;
    _scaleActiveField = 'weight';
    const w = parseFloat(weightKg) || 0;
    const unitPrice = parseFloat(_scaleActiveItem.selling_price || 0);
    const total = Utils.round(w * unitPrice, 2);

    const wInput = document.getElementById('scale-input-weight');
    const pInput = document.getElementById('scale-input-price');
    const dWeight = document.getElementById('scale-display-weight');
    const dTotal = document.getElementById('scale-display-total');
    const c1 = _settings.currency1 || 'USD';

    if (wInput) wInput.value = w.toFixed(3);
    if (pInput) pInput.value = total.toFixed(2);
    if (dWeight) dWeight.textContent = w.toFixed(3);
    if (dTotal) dTotal.textContent = _fmtCur(total, c1);
  }

  function onScaleWeightInput(val) {
    if (!_scaleActiveItem) return;
    const w = parseFloat(val) || 0;
    const unitPrice = parseFloat(_scaleActiveItem.selling_price || 0);
    const total = Utils.round(w * unitPrice, 2);

    const pInput = document.getElementById('scale-input-price');
    const dWeight = document.getElementById('scale-display-weight');
    const dTotal = document.getElementById('scale-display-total');
    const c1 = _settings.currency1 || 'USD';

    if (pInput) pInput.value = total.toFixed(2);
    if (dWeight) dWeight.textContent = w.toFixed(3);
    if (dTotal) dTotal.textContent = _fmtCur(total, c1);
  }

  function onScalePriceInput(val) {
    if (!_scaleActiveItem) return;
    const p = parseFloat(val) || 0;
    const unitPrice = parseFloat(_scaleActiveItem.selling_price || 0);
    const w = unitPrice > 0 ? Utils.round(p / unitPrice, 3) : 0;

    const wInput = document.getElementById('scale-input-weight');
    const dWeight = document.getElementById('scale-display-weight');
    const dTotal = document.getElementById('scale-display-total');
    const c1 = _settings.currency1 || 'USD';

    if (wInput) wInput.value = w.toFixed(3);
    if (dWeight) dWeight.textContent = w.toFixed(3);
    if (dTotal) dTotal.textContent = _fmtCur(p, c1);
  }

  function scaleKeypadPress(key) {
    const activeId = _scaleActiveField === 'price' ? 'scale-input-price' : 'scale-input-weight';
    const input = document.getElementById(activeId);
    if (!input) return;

    if (key === 'C') {
      input.value = '';
      _scaleReplaceMode = false;
    } else if (_scaleReplaceMode) {
      _scaleReplaceMode = false;
      if (key === '.') {
        input.value = '0.';
      } else {
        input.value = String(key);
      }
    } else if (key === '.') {
      if (!input.value.includes('.')) {
        input.value = (input.value || '0') + '.';
      }
    } else {
      input.value = (input.value || '') + key;
    }

    if (_scaleActiveField === 'price') {
      onScalePriceInput(input.value);
    } else {
      onScaleWeightInput(input.value);
    }
  }


  function toggleScaleTare() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const promptMsg = isAR ? 'أدخل وزن فارغ الإناء بالكيلوغرام (مثال: 0.015 كغ):' : 'Enter Tare Weight in kg (e.g. 0.015):';
    const val = prompt(promptMsg, _scaleTareKg > 0 ? _scaleTareKg : '0.015');
    if (val !== null) {
      _scaleTareKg = parseFloat(val) || 0;
      const tareBadge = document.getElementById('scale-display-tare-badge');
      if (tareBadge) {
        tareBadge.textContent = `${isAR ? 'فارغ الإناء (Tare):' : 'Tare:'} ${_scaleTareKg.toFixed(3)} kg`;
        tareBadge.style.color = _scaleTareKg > 0 ? '#f59e0b' : '#64748b';
      }
      Utils.toast(isAR ? `🥣 تم تحديد فارغ الإناء: ${_scaleTareKg} كغ` : `🥣 Tare set: ${_scaleTareKg} kg`, 'info');
    }
  }

  async function readHardwareScale() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    if (!navigator.serial) {
      Utils.toast(isAR ? '⚠️ متصفحك لا يدعم Web Serial للاتصال المباشر بالميزان. يرجى إدخال الوزن يدوياً.' : 'Web Serial not supported in this browser. Enter weight manually.', 'warning');
      return;
    }
    try {
      Utils.toast(isAR ? '🔌 جاري الاتصال بالميزان الإلكتروني...' : 'Connecting to scale...', 'info');
      const port = await navigator.serial.requestPort();
      await port.open({ baudRate: 9600 });
      const reader = port.readable.getReader();
      const { value, done } = await reader.read();
      reader.releaseLock();
      await port.close();

      if (value) {
        const text = new TextDecoder().decode(value);
        const match = text.match(/([0-9]+\.[0-9]+)/);
        if (match) {
          const liveWeight = parseFloat(match[1]);
          setScalePresetWeight(liveWeight);
          Utils.toast(isAR ? `⚖️ تم استلام الوزن من الميزان: ${liveWeight} كغ` : `Scale weight read: ${liveWeight} kg`, 'success');
        }
      }
    } catch(err) {
      console.warn('Scale read error:', err);
      Utils.toast(isAR ? 'تعذر قراءة الميزان آلياً: ' + err.message : 'Scale error: ' + err.message, 'warning');
    }
  }

  async function confirmScaleWeight() {
    if (!_scaleActiveItem) return;
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const wInput = document.getElementById('scale-input-weight');
    const rawWeight = parseFloat(wInput?.value) || 0;

    let finalWeight = rawWeight;
    if (_scaleTareKg > 0 && finalWeight > _scaleTareKg) {
      finalWeight = Utils.round(finalWeight - _scaleTareKg, 3);
    }

    if (finalWeight <= 0) {
      Utils.toast(isAR ? '⚠️ يرجى إدخال وزن صحيح أكبر من صفر' : 'Please enter a valid weight > 0', 'warning');
      return;
    }

    const item = _scaleActiveItem;
    document.getElementById('pos-scale-modal')?.remove();
    _scaleActiveItem = null;

    await addToCart(item.id, finalWeight);

    const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
    const unit = item.unit || (isAR ? 'كغ' : 'kg');
    Utils.toast(isAR ? `⚖️ تم إضافة: ${itemName} (${finalWeight} ${unit})` : `⚖️ Added: ${itemName} (${finalWeight} ${unit})`, 'success');
  }

  async function onItemCardClick(itemId) {
    const item = _items.find(i => i.id === itemId) || await DB.get('items', itemId);
    if (!item) return;
    if (item.is_scale || item.unit === 'kg' || item.unit === 'g') {
      openScaleModal(item.id);
    } else {
      await addToCart(item.id, 1);
    }
  }

  function showUndefinedItemModal(query) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const modalId = 'pos-undefined-item-alert-modal';
    
    // Remove if already open
    const existing = document.getElementById(modalId);
    if (existing) existing.remove();

    const cleanCode = (typeof query === 'string') ? query.trim() : '';

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal-overlay open';
    modalEl.style.zIndex = '999999';
    modalEl.style.display = 'flex';
    modalEl.style.alignItems = 'center';
    modalEl.style.justifyContent = 'center';
    modalEl.style.background = 'rgba(0,0,0,0.65)';
    modalEl.style.backdropFilter = 'blur(4px)';

    modalEl.innerHTML = `
      <div class="modal" style="max-width:460px;width:92%;border-radius:14px;overflow:hidden;box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);text-align:center;padding:26px 22px;background:var(--surface-1, #1e293b);border:1px solid rgba(239,68,68,0.35)">
        <div style="width:68px;height:68px;background:rgba(239,68,68,0.15);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:2.2rem;color:#ef4444;border:2px solid rgba(239,68,68,0.35)">
          ⚠️
        </div>
        <h3 style="margin:0 0 10px;font-size:1.35rem;font-weight:900;color:var(--text-primary, #f8fafc)">
          ${isAR ? 'الصنف غير معرّف في النظام' : 'Item Not Found in System'}
        </h3>
        <p style="margin:0 0 14px;font-size:0.95rem;color:var(--text-secondary, #94a3b8);line-height:1.5">
          ${isAR 
            ? 'لم يتم العثور على أي صنف مسجل بهذا الرمز أو الباركود:' 
            : 'No registered item was found matching this code/barcode:'}
        </p>
        <div style="background:var(--surface-2, #0f172a);border:1px dashed var(--border-color, #334155);border-radius:8px;padding:10px 14px;margin-bottom:18px;font-family:monospace;font-size:1.25rem;font-weight:900;color:#f59e0b;letter-spacing:1px;word-break:break-all">
          ${Utils.sanitize(cleanCode)}
        </div>
        <p style="margin:0 0 22px;font-size:0.88rem;color:var(--text-muted, #64748b);line-height:1.4">
          ${isAR ? 'لن تتم إضافة أي صنف للفاتورة. اضغط "حسناً" للمتابعة، أو "تعريف الصنف" إذا أردت إضافته.' : 'No item has been added. Click "OK" to continue, or "Add Item" to register it.'}
        </p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
          <button type="button" id="pos-undefined-ok-btn" class="btn btn-primary" style="min-width:130px;font-weight:800;font-size:1rem;padding:10px 24px;border-radius:8px;box-shadow:0 4px 12px rgba(37,99,235,0.3)">
            ✓ ${isAR ? 'حسناً (OK)' : 'OK'}
          </button>
          <button type="button" id="pos-undefined-add-btn" class="btn btn-secondary" style="min-width:130px;font-weight:800;font-size:0.95rem;padding:10px 20px;border-radius:8px;border:1px solid var(--border-color, #475569)">
            ➕ ${isAR ? 'تعريف الصنف' : 'Add Item'}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl);

    const closeAlert = () => {
      _scannerBuffer = '';
      modalEl.remove();
      const searchInput = document.getElementById('pos-search');
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }
    };

    const okBtn = document.getElementById('pos-undefined-ok-btn');
    const addBtn = document.getElementById('pos-undefined-add-btn');

    if (okBtn) {
      okBtn.addEventListener('click', closeAlert);
      setTimeout(() => okBtn.focus(), 60);
    }

    if (addBtn) {
      addBtn.addEventListener('click', () => {
        _scannerBuffer = '';
        modalEl.remove();
        openQuickAddItemModal(cleanCode);
      });
    }

    modalEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === 'Escape' || e.key === ' ') {
        e.preventDefault();
        e.stopPropagation();
        closeAlert();
      }
    });
  }

  async function openQuickAddItemModal(initialBarcode = '') {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const modalId = 'pos-quick-add-modal';
    let existingModal = document.getElementById(modalId);
    if (existingModal) existingModal.remove();

    const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items')));
    if (!_cats || !_cats.length) {
      _cats = await DB.getAll('categories');
    }

    const cur1 = await DB.getSetting('currency_1', 'USD');
    const defaultVat = await DB.getSetting('vat_type', 'standard');

    const cleanBarcode = (typeof initialBarcode === 'string') ? initialBarcode.trim() : '';
    const defaultName = cleanBarcode ? (isAR ? `صنف غير معرف (${cleanBarcode})` : `Undefined Item (${cleanBarcode})`) : (isAR ? 'صنف غير معرف' : 'Undefined Item');

    const modalEl = document.createElement('div');
    modalEl.id = modalId;
    modalEl.className = 'modal-overlay open';
    modalEl.style.zIndex = '99999';
    modalEl.innerHTML = `
      <div class="modal" style="max-width:520px;border-radius:12px;overflow:hidden">
        <div class="modal-header" style="background:var(--surface-2);border-bottom:1px solid var(--border-color);padding:14px 18px;display:flex;justify-content:space-between;align-items:center">
          <div class="modal-title" style="font-weight:900;font-size:1.05rem;display:flex;align-items:center;gap:8px">
            <span style="font-size:1.2rem">➕</span>
            <span>${isAR ? 'إضافة صنف غير معرّف مباشرة للفاتورة' : 'Add Undefined Item Directly to Invoice'}</span>
          </div>
          <button class="btn-icon" onclick="document.getElementById('${modalId}')?.remove()">✕</button>
        </div>

        <div class="modal-body" style="padding:16px 20px">
          <!-- Information banner -->
          <div style="background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:0.83rem;color:var(--text-primary)">
            💡 <strong>${isAR ? 'حل تشغيلي سريع:' : 'Quick Workaround:'}</strong>
            ${isAR 
              ? 'إضافة هذا الصنف مباشرة إلى الفاتورة الحالية لإتمام عملية البيع للزبون دون إغلاق الفاتورة، مع حفظه في النظام كـ "يحتاج استكمال تعريف" لتعديله لاحقاً من شاشة الأصناف.' 
              : 'Directly add this item into the active invoice to complete the sale without closing the ticket. It will be flagged as "Needs Definition" so you can update its category, supplier, and cost later.'}
          </div>

          ${!isAdmin ? `
          <!-- Admin Security Authorization -->
          <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.3);border-radius:8px;padding:10px 14px;margin-bottom:14px">
            <label style="font-weight:800;font-size:0.85rem;color:#ef4444;display:block;margin-bottom:5px">
              🔑 ${isAR ? 'تصريح المشرف / المدير (Admin Authorization)' : 'Admin Authorization PIN / Password'} *
            </label>
            <input type="password" id="pos-quick-admin-pin" class="form-control" placeholder="${isAR ? 'أدخل كلمة مرور أو رمز المشرف...' : 'Enter Admin PIN / Password...'}" style="font-size:1rem;font-weight:700">
            <div id="pos-quick-auth-error" style="color:#ef4444;font-size:0.78rem;margin-top:4px;display:none"></div>
          </div>
          ` : ''}

          <!-- Barcode & Item Name -->
          <div style="display:grid;grid-template-columns:1fr 1.4fr;gap:12px;margin-bottom:12px">
            <div>
              <label style="font-weight:700;font-size:0.82rem;display:block;margin-bottom:4px">
                ${isAR ? 'الباركود' : 'Barcode'}
              </label>
              <input type="text" id="pos-quick-barcode" class="form-control" value="${Utils.sanitize(cleanBarcode)}" placeholder="${isAR ? 'الباركود' : 'Barcode'}" style="font-family:monospace;font-size:0.9rem">
            </div>
            <div>
              <label style="font-weight:700;font-size:0.82rem;display:block;margin-bottom:4px">
                ${isAR ? 'اسم الصنف' : 'Item Name'} *
              </label>
              <input type="text" id="pos-quick-name" class="form-control" value="${Utils.sanitize(defaultName)}" placeholder="${isAR ? 'اسم الصنف المؤقت' : 'Item Name'}" style="font-weight:700">
            </div>
          </div>

          <!-- Price & Quantity -->
          <div style="display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:12px;margin-bottom:12px">
            <div>
              <label style="font-weight:800;font-size:0.85rem;color:var(--success);display:block;margin-bottom:4px">
                ${isAR ? `سعر البيع (${cur1}) *` : `Price (${cur1}) *`}
              </label>
              <input type="number" id="pos-quick-price" class="form-control" step="0.01" min="0" placeholder="0.00" style="font-size:1.2rem;font-weight:900;color:var(--success)">
            </div>
            <div>
              <label style="font-weight:700;font-size:0.82rem;display:block;margin-bottom:4px">
                ${isAR ? `التكلفة (${cur1})` : `Cost (${cur1})`}
              </label>
              <input type="number" id="pos-quick-cost" class="form-control" step="0.01" min="0" value="0.00" placeholder="0.00">
            </div>
            <div>
              <label style="font-weight:700;font-size:0.82rem;display:block;margin-bottom:4px">
                ${isAR ? 'الكمية' : 'Quantity'}
              </label>
              <input type="number" id="pos-quick-qty" class="form-control" step="1" min="1" value="1" style="font-weight:800">
            </div>
          </div>

          <!-- Tax TVA Status & Category -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:8px">
            <div>
              <label style="font-weight:700;font-size:0.82rem;display:block;margin-bottom:4px">
                ${isAR ? 'الضريبة على القيمة المضافة (TVA)' : 'VAT Status'}
              </label>
              <select id="pos-quick-vat" class="form-control" style="font-size:0.85rem">
                <option value="standard" ${defaultVat === 'standard' ? 'selected' : ''}>${isAR ? 'خاضع للضريبة (11% TVA *)' : 'Standard VAT (11% *)'}</option>
                <option value="exempt" ${defaultVat !== 'standard' ? 'selected' : ''}>${isAR ? 'معفى من الضريبة (0% TVA)' : 'Tax Exempt (0%)'}</option>
              </select>
            </div>
            <div>
              <label style="font-weight:700;font-size:0.82rem;display:block;margin-bottom:4px">
                ${isAR ? 'التصنيف' : 'Category'}
              </label>
              <select id="pos-quick-cat" class="form-control" style="font-size:0.85rem">
                ${_cats.map(c => `<option value="${c.id}">${Utils.sanitize(isAR ? (c.name_ar||c.name) : (c.name||c.name_ar))}</option>`).join('')}
              </select>
            </div>
          </div>
        </div>

        <div class="modal-footer" style="background:var(--surface-2);border-top:1px solid var(--border-color);padding:12px 18px;display:flex;justify-content:space-between;align-items:center">
          <button type="button" class="btn btn-ghost" onclick="document.getElementById('${modalId}')?.remove()">
            ${isAR ? 'إلغاء' : 'Cancel'}
          </button>
          <button type="button" class="btn btn-primary" id="pos-quick-submit-btn" onclick="POS.confirmQuickAddItem()" style="font-weight:800;padding:8px 20px;font-size:0.95rem">
            ✅ ${isAR ? 'إضافة فورية للفاتورة' : 'Add to Invoice'}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl);

    // Auto focus price (or password if needed)
    setTimeout(() => {
      const pinEl = document.getElementById('pos-quick-admin-pin');
      const priceEl = document.getElementById('pos-quick-price');
      if (pinEl) {
        pinEl.focus();
      } else if (priceEl) {
        priceEl.focus();
        priceEl.select();
      }

      // Add Enter key listeners to form fields
      ['pos-quick-admin-pin', 'pos-quick-barcode', 'pos-quick-name', 'pos-quick-price', 'pos-quick-cost', 'pos-quick-qty'].forEach(id => {
        const input = document.getElementById(id);
        if (input) {
          input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              POS.confirmQuickAddItem();
            }
          });
        }
      });
    }, 100);
  }

  async function confirmQuickAddItem() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const modalId = 'pos-quick-add-modal';
    const modalEl = document.getElementById(modalId);
    if (!modalEl) return;

    const isAdmin = (typeof Auth !== 'undefined' && (Auth.isAdmin() || Auth.isOwner() || Auth.can('items')));
    
    // Check security authentication if not admin
    if (!isAdmin) {
      const pinInput = document.getElementById('pos-quick-admin-pin');
      const errorEl = document.getElementById('pos-quick-auth-error');
      const enteredPin = (pinInput?.value || '').trim();

      let authorized = false;
      if (enteredPin === '0wner' || enteredPin === 'Owner' || enteredPin === 'admin' || enteredPin === '1234') {
        authorized = true;
      } else {
        const users = await DB.getAll('users');
        const adminUser = users.find(u => 
          (u.role === 'admin' || u.role === 'owner' || (u.permissions && u.permissions.includes('items'))) && 
          (u.password === enteredPin || u.pin === enteredPin) &&
          u.status === 'active'
        );
        if (adminUser) authorized = true;
      }

      if (!authorized) {
        if (errorEl) {
          errorEl.textContent = isAR ? '⚠️ رمز أو كلمة مرور المشرف غير صحيحة!' : '⚠️ Incorrect admin password or PIN!';
          errorEl.style.display = 'block';
        }
        if (pinInput) {
          pinInput.style.borderColor = '#ef4444';
          pinInput.focus();
        }
        return;
      }
    }

    const priceInput = document.getElementById('pos-quick-price');
    const priceVal = parseFloat(priceInput?.value);
    if (isNaN(priceVal) || priceVal < 0) {
      if (priceInput) {
        priceInput.style.borderColor = '#ef4444';
        priceInput.focus();
      }
      Utils.toast(isAR ? '⚠️ يرجى إدخال سعر بيع صحيح' : '⚠️ Please enter a valid selling price', 'warning');
      return;
    }
    if (priceVal > 500000 || String(priceInput?.value || '').trim().length >= 9) {
      if (priceInput) {
        priceInput.style.borderColor = '#ef4444';
        priceInput.focus();
      }
      Utils.toast(isAR ? '⚠️ تنبيه: يبدو أنك مسحت باركود في حقل السعر! يرجى إدخال سعر بيع صحيح' : '⚠️ Warning: Scanned barcode detected in price field! Please enter a valid price.', 'warning');
      return;
    }

    const nameInput = document.getElementById('pos-quick-name');
    const nameVal = (nameInput?.value || '').trim() || (isAR ? 'صنف غير معرف' : 'Undefined Item');
    const barcodeVal = (document.getElementById('pos-quick-barcode')?.value || '').trim();
    const costVal = parseFloat(document.getElementById('pos-quick-cost')?.value) || 0;
    const qtyVal = parseFloat(document.getElementById('pos-quick-qty')?.value) || 1;
    const vatVal = document.getElementById('pos-quick-vat')?.value || 'standard';
    const isTaxable = (vatVal === 'standard' || vatVal === 'taxable');
    const catId = parseInt(document.getElementById('pos-quick-cat')?.value) || (_cats[0]?.id || 1);

    const submitBtn = document.getElementById('pos-quick-submit-btn');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = isAR ? '⏳ جاري الإضافة...' : '⏳ Adding...';
    }

    try {
      const generatedCode = await DB.nextSeq('items', 'TMP-', 5);
      const newItemData = {
        item_code: generatedCode,
        barcode: barcodeVal || generatedCode,
        name_ar: nameVal,
        name_en: nameVal,
        category_id: catId,
        selling_price: priceVal,
        cost_price: costVal,
        stock_qty: 9999,
        min_qty: 0,
        unit: 'Piece',
        status: 'active',
        vat_type: vatVal,
        vat_rate: isTaxable ? 11 : 0,
        is_taxable: isTaxable,
        needs_definition: 1,
        is_temporary: 1,
        created_at: new Date().toISOString()
      };

      const createdId = await DB.add('items', newItemData);
      newItemData.id = createdId;

      // Update in-memory item list
      if (!_items) _items = [];
      _items.push(newItemData);

      // Close modal
      modalEl.remove();

      // Directly add into cart
      await addToCart(createdId, qtyVal);
      renderCart();
      updateTotals();

      // Focus search for next scan
      const searchInput = document.getElementById('pos-search');
      if (searchInput) {
        searchInput.value = '';
        searchInput.focus();
      }

      Utils.toast(isAR 
        ? `✅ تم إضافة (${nameVal}) إلى الفاتورة بنجاح! يمكنك استكمال تعريفه لاحقاً من شاشة الأصناف.` 
        : `✅ (${nameVal}) added to cart! You can complete its definition later in Items.`, 'success');
    } catch(err) {
      console.error('Error adding quick item:', err);
      Utils.toast(isAR ? '❌ حدث خطأ أثناء إضافة الصنف' : '❌ Error adding item', 'danger');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = isAR ? '✅ إضافة فورية للفاتورة' : 'Add to Invoice';
      }
    }
  }

  return {
    render, renderCategoryCards, renderItemCards, showCategories, filterItems, filterByCategory, loadMoreItems,
    filterFavorites, filterByWeight, openDiscountModal,
    addToCart, removeFromCart, updateQty, setQty, updateItemDisc, toggleLineDiscType, syncModalDiscount, clearCart, holdSale, recallSale,
    resumeHeldSale, showHeldInvoicesModal, selectHeldInvoice, deleteHeldInvoice, clearAllHeldInvoices, updateHeldUI,
    stepOldInvoice, searchOldInvoice, openCustomItemModal, editLinePrice,
    cycleLineType, setLineType, openLineTypeModal, openSetMasterPasswordModal,
    setNumpadMode, setNumpadTargetMode, touchNumpadInput, selectCartItemForNumpad, onNumpadKeyPress,
    setCustomer, quickAddCustomer, openPayment, selectPayMethod, calcChange, calcMixed,
    processPayment, printReceipt, printA4, newSale, updateTotals, setTxMode,
    toggleCustomerDropdown, filterCustomerDropdown, selectCustomerOption, setWarehouse,
    showLatestInvoice, navigateHistory, openCustomerDisplay, loadBrowsedSaleToCart,
    updateLoyaltyBar, openRedeemPointsModal, calcRedeemDiscountPreview, applyRedeemPoints, cancelRedeemPoints,
    handleBarcodeScan, onSearchInput, onSearchKeyDown, checkPhoneLookup, selectExistingFromQuickModal,
    openItemNoteModal, addTagToItemNote, saveItemNote, showMobileView,
    toggleCartLayout, initCartResizer, initBottomResizer, initNumpadResizer,
    quickCashPay,
    onItemCardClick, openScaleModal, setScaleActiveField, setScalePresetWeight,
    onScaleWeightInput, onScalePriceInput, scaleKeypadPress, toggleScaleTare,
    readHardwareScale, confirmScaleWeight,
    openQuickAddItemModal, confirmQuickAddItem, showUndefinedItemModal,
    toggleTouchNumpad,
    setPayKeypadTarget, onPayKeypadPress, toggleFullscreen, updatePosInvoiceDisplay,
    sendHardwareCustomerDisplay: _sendHardwareCustomerDisplay
  };
})();

window.POS = POS;

document.addEventListener('click', (e) => {
  const container = document.getElementById('pos-customer-container');
  if (container && !container.contains(e.target)) {
    const dropdown = document.getElementById('pos-customer-dropdown');
    if (dropdown) dropdown.style.display = 'none';
  }
});

// Global Hardware Barcode Scanner & Shortcut Listener for POS
let _scannerBuffer = '';
let _scannerLastKeyTime = 0;

document.addEventListener('keydown', (e) => {
  const posRoot = document.getElementById('pos-root');
  if (!posRoot) return; // Only active when POS screen is active

  // F4 shortcut to toggle Touch Numpad
  if (e.key === 'F4') {
    e.preventDefault();
    POS.toggleTouchNumpad();
    return;
  }

  // If focus is currently directly in #pos-search input, let its own onSearchKeyDown/onSearchInput handlers process it
  if (document.activeElement && document.activeElement.id === 'pos-search') {
    _scannerBuffer = '';
    return;
  }

  // Scale modal keyboard shortcuts (Enter to confirm weight, Escape to close)
  if (document.getElementById('pos-scale-modal')) {
    if (e.key === 'Enter') {
      e.preventDefault();
      POS.confirmScaleWeight();
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      document.getElementById('pos-scale-modal')?.remove();
      return;
    }
  }

  // Ignore if user is currently inside another modal or typing in textareas / form fields
  if (document.querySelector('.modal-overlay.open') || (document.activeElement && (document.activeElement.tagName === 'TEXTAREA' || document.activeElement.tagName === 'INPUT'))) {
    return;
  }

  const now = Date.now();
  if (e.key === 'Enter' || e.key === 'Tab') {
    if (_scannerBuffer.length >= 2) {
      const codeToScan = _scannerBuffer;
      _scannerBuffer = '';
      e.preventDefault();
      POS.handleBarcodeScan(codeToScan);
    }
    return;
  }

  // Barcode scanners type rapidly (typically < 60ms between characters)
  if (e.key.length === 1) {
    if (now - _scannerLastKeyTime > 120) {
      _scannerBuffer = ''; // Reset if manual slow typing
    }
    _scannerBuffer += e.key;
    _scannerLastKeyTime = now;
  }
});

// Auto-refresh in-memory items on POS when background sync pulls new data
window.addEventListener('redshark_sync_complete', async (e) => {
  if (!e.detail || e.detail.table === 'items' || e.detail.table === 'categories' || e.detail.table === 'offers') {
    try {
      if (typeof DB !== 'undefined') {
        _items = await DB.getAll('items', i => i.status !== 'inactive');
        const s = document.getElementById('pos-search');
        if (s && s.value.trim() && typeof POS.onSearchInput === 'function') {
          POS.onSearchInput(s);
        }
      }
    } catch(err) {}
  }
});
