/* ================================================================
   NexPOS — HR Module (Employees, Attendance, Leave, EOSG)
   ================================================================ */

const HR = (() => {

  // ── Employees ─────────────────────────────────────────────────
  async function renderEmployees(container) {
    const employees = await DB.getAll('employees');
    const departments = await DB.getAll('departments');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'الموظفون' : 'Employees'}</h1>
          <p>${isAR ? `${employees.length} موظف` : `${employees.length} employees`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="HR.openEmpForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'موظف جديد' : 'New Employee'}
          </button>
        </div>
      </div>

      <div class="toolbar">
        <div class="search-bar flex-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" placeholder="${isAR ? 'بحث...' : 'Search...'}" oninput="HR.searchEmployees(this.value)" style="padding-left:34px">
        </div>
        <select class="form-control" id="emp-dept-filter" style="width:160px" onchange="HR.filterEmployees()">
          <option value="">${isAR ? 'كل الأقسام' : 'All Depts'}</option>
          ${departments.map(d => `<option value="${d.id}">${isAR ? (d.name_ar||d.name) : (d.name||d.name_ar)}</option>`).join('')}
        </select>
        <select class="form-control" id="emp-status-filter" style="width:130px" onchange="HR.filterEmployees()">
          <option value="">${isAR ? 'كل الحالات' : 'All Status'}</option>
          <option value="active">${isAR ? 'نشط' : 'Active'}</option>
          <option value="inactive">${isAR ? 'غير نشط' : 'Inactive'}</option>
          <option value="terminated">${isAR ? 'منهي' : 'Terminated'}</option>
        </select>
      </div>

      <div class="grid grid-4" id="emp-grid">
        ${employees.map(e => empCard(e, departments, isAR)).join('') || `
        <div class="empty-state" style="grid-column:1/-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:40px;height:40px"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <h3>${isAR ? 'لا يوجد موظفون' : 'No employees yet'}</h3>
          <button class="btn btn-primary" onclick="HR.openEmpForm()">${isAR ? 'إضافة موظف' : 'Add Employee'}</button>
        </div>`}
      </div>
    </div>

    <!-- Employee Form Modal -->
    <div class="modal-overlay" id="emp-modal">
      <div class="modal modal-xl">
        <div class="modal-header">
          <div class="modal-title" id="emp-modal-title">${isAR ? 'موظف جديد' : 'New Employee'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('emp-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="tabs" id="emp-tabs">
            <div class="tab-item active" data-tab="tab-emp-basic">${isAR ? 'الأساسي' : 'Basic'}</div>
            <div class="tab-item" data-tab="tab-emp-job">${isAR ? 'الوظيفة' : 'Job'}</div>
            <div class="tab-item" data-tab="tab-emp-salary">${isAR ? 'الراتب' : 'Salary'}</div>
            <div class="tab-item" data-tab="tab-emp-docs">${isAR ? 'الوثائق' : 'Documents'}</div>
          </div>

          <div class="tab-content active" id="tab-emp-basic">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label">${isAR?'الاسم (عربي)':'Name (Arabic)'}</label>
                <input type="text" class="form-control" id="emp-name-ar" placeholder="الاسم الكامل" dir="rtl">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'الاسم (إنجليزي)':'Name (English)'}</label>
                <input type="text" class="form-control" id="emp-name-en" placeholder="Full name">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'رقم الموظف':'Employee ID'}</label>
                <input type="text" class="form-control" id="emp-code" placeholder="${isAR?'تلقائي':'Auto'}">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'الجنسية':'Nationality'}</label>
                <input type="text" class="form-control" id="emp-nationality">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'تاريخ الميلاد':'Date of Birth'}</label>
                <input type="date" class="form-control" id="emp-dob">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'الجنس':'Gender'}</label>
                <select class="form-control" id="emp-gender">
                  <option value="male">${isAR?'ذكر':'Male'}</option>
                  <option value="female">${isAR?'أنثى':'Female'}</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'رقم الهاتف':'Phone'}</label>
                <input type="text" class="form-control" id="emp-phone" placeholder="+961...">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'البريد الإلكتروني':'Email'}</label>
                <input type="email" class="form-control" id="emp-email" placeholder="email@domain.com">
              </div>
              <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">${isAR?'العنوان':'Address'}</label>
                <input type="text" class="form-control" id="emp-address">
              </div>
            </div>
          </div>

          <div class="tab-content" id="tab-emp-job">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label">${isAR?'القسم':'Department'}</label>
                <select class="form-control" id="emp-dept">
                  <option value="">--</option>
                  ${departments.map(d => `<option value="${d.id}">${isAR?(d.name_ar||d.name):(d.name||d.name_ar)}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'المنصب':'Position'}</label>
                <input type="text" class="form-control" id="emp-position">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'تاريخ التوظيف':'Join Date'}</label>
                <input type="date" class="form-control" id="emp-join-date" value="${Utils.today()}">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'نوع العقد':'Contract Type'}</label>
                <select class="form-control" id="emp-contract">
                  <option value="fulltime">${isAR?'دوام كامل':'Full-time'}</option>
                  <option value="parttime">${isAR?'دوام جزئي':'Part-time'}</option>
                  <option value="contract">${isAR?'عقد':'Contract'}</option>
                  <option value="internship">${isAR?'تدريب':'Internship'}</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'ساعات العمل/أسبوع':'Work Hours/Week'}</label>
                <input type="number" class="form-control" id="emp-hours" value="40">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'الحالة':'Status'}</label>
                <select class="form-control" id="emp-status">
                  <option value="active">${isAR?'نشط':'Active'}</option>
                  <option value="inactive">${isAR?'غير نشط':'Inactive'}</option>
                  <option value="on_leave">${isAR?'في إجازة':'On Leave'}</option>
                  <option value="terminated">${isAR?'منتهي':'Terminated'}</option>
                </select>
              </div>
            </div>
          </div>

          <div class="tab-content" id="tab-emp-salary">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label">${isAR?'الراتب الأساسي':'Basic Salary'}</label>
                <div class="input-group">
                  <input type="number" class="form-control" id="emp-basic-salary" placeholder="0.00" step="0.01" min="0">
                  <div class="input-group-addon">USD</div>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'بدل المواصلات':'Transport Allowance'}</label>
                <input type="number" class="form-control" id="emp-transport" placeholder="0.00" step="0.01" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'بدل السكن':'Housing Allowance'}</label>
                <input type="number" class="form-control" id="emp-housing" placeholder="0.00" step="0.01" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'بدلات أخرى':'Other Allowances'}</label>
                <input type="number" class="form-control" id="emp-other-allow" placeholder="0.00" step="0.01" min="0">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'نسبة NSSF%':'NSSF %'}</label>
                <input type="number" class="form-control" id="emp-nssf" placeholder="0" value="9">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'ضريبة الدخل%':'Income Tax %'}</label>
                <input type="number" class="form-control" id="emp-tax-pct" placeholder="0" value="0">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'معدل الراتب بالساعة (LBP)':'Hourly Rate (LBP)'}</label>
                <input type="number" class="form-control" id="emp-hourly-lbp" placeholder="0">
              </div>
            </div>
          </div>

          <div class="tab-content" id="tab-emp-docs">
            <div class="grid grid-2">
              <div class="form-group">
                <label class="form-label">${isAR?'رقم الهوية':'ID Number'}</label>
                <input type="text" class="form-control" id="emp-id-num">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'رقم جواز السفر':'Passport Number'}</label>
                <input type="text" class="form-control" id="emp-passport">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'انتهاء الجواز':'Passport Expiry'}</label>
                <input type="date" class="form-control" id="emp-passport-exp">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'رقم الضمان الاجتماعي':'NSSF Number'}</label>
                <input type="text" class="form-control" id="emp-nssf-num">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'رقم الحساب البنكي':'Bank Account'}</label>
                <input type="text" class="form-control" id="emp-bank-acc">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR?'اسم البنك':'Bank Name'}</label>
                <input type="text" class="form-control" id="emp-bank-name">
              </div>
              <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">${isAR?'ملاحظات':'Notes'}</label>
                <textarea class="form-control" id="emp-notes" rows="3"></textarea>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('emp-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="HR.saveEmployee()">${isAR?'حفظ':'Save'}</button>
        </div>
      </div>
    </div>`;

    Utils.initTabs('#emp-tabs');
    window._allEmployees = employees;
    window._allDepts = departments;
  }

  function empCard(emp, departments, isAR) {
    const dept = departments.find(d => d.id === emp.dept_id);
    const name = isAR ? (emp.name_ar||emp.name_en) : (emp.name_en||emp.name_ar);
    const statusColors = { active:'success', inactive:'secondary', on_leave:'warning', terminated:'danger' };
    const initial = (name||'?')[0].toUpperCase();
    return `
    <div class="card" style="padding:16px;cursor:pointer" onclick="HR.openEmpForm(${emp.id})">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
        <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--primary),var(--accent));display:flex;align-items:center;justify-content:center;font-size:1rem;font-weight:800;color:white;flex-shrink:0">${initial}</div>
        <div style="min-width:0">
          <div style="font-weight:700;font-size:0.88rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${Utils.truncate(name,22)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted)">${emp.position||'-'}</div>
        </div>
      </div>
      <div style="font-size:0.72rem;color:var(--text-secondary);margin-bottom:3px">
        📁 ${dept ? (isAR?(dept.name_ar||dept.name):(dept.name||dept.name_ar)) : '-'}
      </div>
      <div style="font-size:0.72rem;color:var(--text-secondary);margin-bottom:8px">
        📅 ${Utils.formatDate(emp.join_date)}
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span class="badge badge-${statusColors[emp.status]||'secondary'}">${emp.status||'active'}</span>
        <span style="font-weight:700;color:var(--success);font-size:0.8rem">${Utils.formatMoney(emp.basic_salary||0)}</span>
      </div>
    </div>`;
  }

  function searchEmployees(q) {
    const emps = window._allEmployees || [];
    const isAR = i18n.getLang() === 'ar';
    const depts = window._allDepts || [];
    const filtered = !q ? emps : emps.filter(e =>
      (e.name_en||'').toLowerCase().includes(q.toLowerCase()) ||
      (e.name_ar||'').toLowerCase().includes(q.toLowerCase()) ||
      (e.emp_code||'').toLowerCase().includes(q.toLowerCase())
    );
    document.getElementById('emp-grid').innerHTML = filtered.map(e => empCard(e, depts, isAR)).join('') ||
      `<div class="empty-state" style="grid-column:1/-1"><h3>${isAR?'لا نتائج':'No results'}</h3></div>`;
  }

  function filterEmployees() {
    const deptId = document.getElementById('emp-dept-filter')?.value;
    const status = document.getElementById('emp-status-filter')?.value;
    const emps   = window._allEmployees || [];
    const isAR   = i18n.getLang() === 'ar';
    const depts  = window._allDepts || [];
    const filtered = emps.filter(e => (!deptId || String(e.dept_id)===deptId) && (!status || e.status===status));
    document.getElementById('emp-grid').innerHTML = filtered.map(e => empCard(e, depts, isAR)).join('') ||
      `<div class="empty-state" style="grid-column:1/-1"><h3>${isAR?'لا نتائج':'No results'}</h3></div>`;
  }

  async function openEmpForm(id = null) {
    window._editEmpId = id;
    const isAR = i18n.getLang() === 'ar';
    document.getElementById('emp-modal-title').textContent = id ? (isAR?'تعديل الموظف':'Edit Employee') : (isAR?'موظف جديد':'New Employee');

    const fields = ['emp-name-ar','emp-name-en','emp-code','emp-nationality','emp-phone','emp-email',
      'emp-address','emp-position','emp-hours','emp-basic-salary','emp-transport','emp-housing',
      'emp-other-allow','emp-nssf','emp-tax-pct','emp-hourly-lbp','emp-id-num','emp-passport',
      'emp-passport-exp','emp-nssf-num','emp-bank-acc','emp-bank-name','emp-notes'];
    fields.forEach(f => { const el=document.getElementById(f); if(el) el.value=''; });
    document.getElementById('emp-hours').value = '40';
    document.getElementById('emp-nssf').value  = '9';

    if (id) {
      const emp = await DB.get('employees', id);
      if (emp) {
        const map = {
          'emp-name-ar': emp.name_ar, 'emp-name-en': emp.name_en, 'emp-code': emp.emp_code,
          'emp-nationality': emp.nationality, 'emp-phone': emp.phone, 'emp-email': emp.email,
          'emp-address': emp.address, 'emp-position': emp.position, 'emp-hours': emp.work_hours,
          'emp-basic-salary': emp.basic_salary, 'emp-transport': emp.transport, 'emp-housing': emp.housing,
          'emp-other-allow': emp.other_allowances, 'emp-nssf': emp.nssf_pct, 'emp-tax-pct': emp.tax_pct,
          'emp-hourly-lbp': emp.hourly_lbp, 'emp-id-num': emp.id_number, 'emp-passport': emp.passport,
          'emp-passport-exp': emp.passport_expiry, 'emp-nssf-num': emp.nssf_number, 'emp-bank-acc': emp.bank_account,
          'emp-bank-name': emp.bank_name, 'emp-notes': emp.notes,
        };
        Object.entries(map).forEach(([fid, val]) => { const el=document.getElementById(fid); if(el&&val!=null) el.value=val; });
        if (emp.gender)    document.getElementById('emp-gender').value = emp.gender;
        if (emp.status)    document.getElementById('emp-status').value = emp.status;
        if (emp.contract)  document.getElementById('emp-contract').value = emp.contract;
        if (emp.dept_id)   document.getElementById('emp-dept').value = emp.dept_id;
        if (emp.join_date) document.getElementById('emp-join-date').value = emp.join_date;
        if (emp.dob)       document.getElementById('emp-dob').value = emp.dob;
      }
    }
    Utils.openModal('emp-modal');
    document.querySelectorAll('#emp-tabs .tab-item').forEach((t,i) => t.classList.toggle('active', i===0));
    document.querySelectorAll('#emp-tabs ~ .tab-content').forEach((c,i) => c.classList.toggle('active', i===0));
  }

  async function saveEmployee() {
    const nameEn = document.getElementById('emp-name-en').value.trim();
    const nameAr = document.getElementById('emp-name-ar').value.trim();
    if (!nameEn && !nameAr) { Utils.toast(i18n.t('common.required'), 'warning'); return; }
    const data = {
      emp_code:        document.getElementById('emp-code').value.trim() || await DB.nextSeq('employees','EMP-',4),
      name_en:         nameEn, name_ar: nameAr,
      nationality:     document.getElementById('emp-nationality').value,
      dob:             document.getElementById('emp-dob').value,
      gender:          document.getElementById('emp-gender').value,
      phone:           document.getElementById('emp-phone').value,
      email:           document.getElementById('emp-email').value,
      address:         document.getElementById('emp-address').value,
      dept_id:         parseInt(document.getElementById('emp-dept').value)||null,
      position:        document.getElementById('emp-position').value,
      join_date:       document.getElementById('emp-join-date').value,
      contract:        document.getElementById('emp-contract').value,
      work_hours:      parseFloat(document.getElementById('emp-hours').value)||40,
      status:          document.getElementById('emp-status').value,
      basic_salary:    parseFloat(document.getElementById('emp-basic-salary').value)||0,
      transport:       parseFloat(document.getElementById('emp-transport').value)||0,
      housing:         parseFloat(document.getElementById('emp-housing').value)||0,
      other_allowances:parseFloat(document.getElementById('emp-other-allow').value)||0,
      nssf_pct:        parseFloat(document.getElementById('emp-nssf').value)||9,
      tax_pct:         parseFloat(document.getElementById('emp-tax-pct').value)||0,
      hourly_lbp:      parseFloat(document.getElementById('emp-hourly-lbp').value)||0,
      id_number:       document.getElementById('emp-id-num').value,
      passport:        document.getElementById('emp-passport').value,
      passport_expiry: document.getElementById('emp-passport-exp').value,
      nssf_number:     document.getElementById('emp-nssf-num').value,
      bank_account:    document.getElementById('emp-bank-acc').value,
      bank_name:       document.getElementById('emp-bank-name').value,
      notes:           document.getElementById('emp-notes').value,
    };
    try {
      if (window._editEmpId) await DB.update('employees', { ...data, id: window._editEmpId });
      else await DB.add('employees', data);
      Utils.closeModal('emp-modal');
      Utils.toast(i18n.t('common.saved'), 'success');
      await renderEmployees(document.getElementById('page-content'));
    } catch(e) { Utils.toast('Error: ' + e.message, 'error'); }
  }

  // ── Attendance ────────────────────────────────────────────────
  async function renderAttendance(container) {
    const attendance = await DB.getAll('attendance');
    const employees  = await DB.getAll('employees');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'الحضور والانصراف' : 'Attendance'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="HR.openAttForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'تسجيل حضور' : 'Record Attendance'}
          </button>
        </div>
      </div>

      <div class="toolbar mb-3">
        <input type="date" class="form-control" id="att-date-filter" value="${Utils.today()}" style="width:180px" onchange="HR.filterAttendance()">
        <select class="form-control" id="att-emp-filter" style="width:200px" onchange="HR.filterAttendance()">
          <option value="">${isAR ? 'كل الموظفين' : 'All Employees'}</option>
          ${employees.map(e => `<option value="${e.id}">${isAR?(e.name_ar||e.name_en):(e.name_en||e.name_ar)}</option>`).join('')}
        </select>
      </div>

      <div class="table-wrapper">
        <table id="att-table">
          <thead><tr>
            <th>${isAR?'الموظف':'Employee'}</th>
            <th>${isAR?'التاريخ':'Date'}</th>
            <th>${isAR?'وقت الحضور':'Check In'}</th>
            <th>${isAR?'وقت الانصراف':'Check Out'}</th>
            <th>${isAR?'ساعات العمل':'Hours'}</th>
            <th>${isAR?'الحالة':'Status'}</th>
            <th>${isAR?'إجراءات':'Actions'}</th>
          </tr></thead>
          <tbody id="att-tbody">
            ${renderAttRows(attendance, employees, isAR)}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Attendance Form -->
    <div class="modal-overlay" id="att-modal">
      <div class="modal" style="max-width:480px">
        <div class="modal-header">
          <div class="modal-title">${isAR?'تسجيل حضور':'Record Attendance'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('att-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">${isAR?'الموظف':'Employee'}</label>
            <select class="form-control" id="att-emp">
              <option value="">--</option>
              ${employees.map(e => `<option value="${e.id}">${isAR?(e.name_ar||e.name_en):(e.name_en||e.name_ar)}</option>`).join('')}
            </select>
          </div>
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'التاريخ':'Date'}</label>
              <input type="date" class="form-control" id="att-date" value="${Utils.today()}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'الحالة':'Status'}</label>
              <select class="form-control" id="att-status">
                <option value="present">${isAR?'حاضر':'Present'}</option>
                <option value="absent">${isAR?'غائب':'Absent'}</option>
                <option value="late">${isAR?'متأخر':'Late'}</option>
                <option value="half_day">${isAR?'نصف يوم':'Half Day'}</option>
                <option value="holiday">${isAR?'إجازة':'Holiday'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'وقت الحضور':'Check In'}</label>
              <input type="time" class="form-control" id="att-in" value="08:00">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'وقت الانصراف':'Check Out'}</label>
              <input type="time" class="form-control" id="att-out" value="17:00">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'ملاحظات':'Notes'}</label>
            <input type="text" class="form-control" id="att-notes">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('att-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="HR.saveAttendance()">${isAR?'حفظ':'Save'}</button>
        </div>
      </div>
    </div>`;

    window._allEmpsForAtt = employees;
    window._allAttendance = attendance;
  }

  function renderAttRows(attendance, employees, isAR) {
    if (!attendance.length) return `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد سجلات':'No records'}</td></tr>`;
    const colors = { present:'success', absent:'danger', late:'warning', half_day:'info', holiday:'secondary' };
    return attendance.slice().reverse().slice(0,50).map(a => {
      const emp = employees.find(e => e.id === a.employee_id);
      const empName = emp ? (isAR?(emp.name_ar||emp.name_en):(emp.name_en||emp.name_ar)) : '-';
      const checkIn  = a.check_in  || '-';
      const checkOut = a.check_out || '-';
      let hours = '-';
      if (a.check_in && a.check_out) {
        const diff = (new Date(`2000-01-01T${a.check_out}`) - new Date(`2000-01-01T${a.check_in}`)) / 3600000;
        hours = diff > 0 ? `${diff.toFixed(1)}h` : '-';
      }
      return `<tr>
        <td style="font-weight:600">${Utils.truncate(empName,25)}</td>
        <td style="font-size:0.78rem">${Utils.formatDate(a.date||a.created_at)}</td>
        <td>${checkIn}</td><td>${checkOut}</td><td>${hours}</td>
        <td><span class="badge badge-${colors[a.status]||'secondary'}">${a.status||'-'}</span></td>
        <td>
          <button class="btn btn-ghost btn-sm" onclick="HR.deleteAttendance(${a.id})" style="color:var(--danger)">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
          </button>
        </td>
      </tr>`;
    }).join('');
  }

  function openAttForm() { Utils.openModal('att-modal'); }

  async function saveAttendance() {
    const empId = parseInt(document.getElementById('att-emp').value);
    if (!empId) { Utils.toast(i18n.t('common.required'), 'warning'); return; }
    await DB.add('attendance', {
      employee_id: empId,
      date:        document.getElementById('att-date').value,
      status:      document.getElementById('att-status').value,
      check_in:    document.getElementById('att-in').value,
      check_out:   document.getElementById('att-out').value,
      notes:       document.getElementById('att-notes').value,
    });
    Utils.closeModal('att-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await renderAttendance(document.getElementById('page-content'));
  }

  function filterAttendance() {
    const date  = document.getElementById('att-date-filter')?.value;
    const empId = document.getElementById('att-emp-filter')?.value;
    const all   = window._allAttendance || [];
    const emps  = window._allEmpsForAtt || [];
    const isAR  = i18n.getLang() === 'ar';
    const filtered = all.filter(a =>
      (!date  || a.date === date) &&
      (!empId || String(a.employee_id) === empId)
    );
    document.getElementById('att-tbody').innerHTML = renderAttRows(filtered, emps, isAR);
  }

  function deleteAttendance(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('attendance', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      window._allAttendance = (window._allAttendance||[]).filter(a => a.id !== id);
      filterAttendance();
    });
  }

  // ── Leave ─────────────────────────────────────────────────────
  async function renderLeave(container) {
    const leaves = await DB.getAll('leave_requests');
    const employees = await DB.getAll('employees');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'طلبات الإجازات' : 'Leave Requests'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="HR.openLeaveForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'طلب إجازة' : 'New Leave Request'}
          </button>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR?'الموظف':'Employee'}</th>
            <th>${isAR?'نوع الإجازة':'Leave Type'}</th>
            <th>${isAR?'من':'From'}</th>
            <th>${isAR?'إلى':'To'}</th>
            <th>${isAR?'الأيام':'Days'}</th>
            <th>${isAR?'الحالة':'Status'}</th>
            <th>${isAR?'إجراءات':'Actions'}</th>
          </tr></thead>
          <tbody>
            ${leaves.slice().reverse().map(l => {
              const emp = employees.find(e => e.id === l.employee_id);
              const nm  = emp ? (isAR?(emp.name_ar||emp.name_en):(emp.name_en||emp.name_ar)) : '-';
              const days = l.from_date && l.to_date ? Math.ceil((new Date(l.to_date)-new Date(l.from_date))/(1000*60*60*24))+1 : '-';
              const clr = {pending:'warning', approved:'success', rejected:'danger'};
              return `<tr>
                <td style="font-weight:600">${Utils.truncate(nm,25)}</td>
                <td><span class="badge badge-secondary">${l.leave_type||'-'}</span></td>
                <td>${Utils.formatDate(l.from_date)}</td>
                <td>${Utils.formatDate(l.to_date)}</td>
                <td style="font-weight:700">${days}</td>
                <td><span class="badge badge-${clr[l.status]||'secondary'}">${l.status||'pending'}</span></td>
                <td style="display:flex;gap:4px">
                  ${l.status==='pending'?`
                  <button class="btn btn-success btn-sm" onclick="HR.approveLeave(${l.id})">${isAR?'قبول':'Approve'}</button>
                  <button class="btn btn-danger btn-sm" onclick="HR.rejectLeave(${l.id})">${isAR?'رفض':'Reject'}</button>` : ''}
                  <button class="btn btn-ghost btn-sm" onclick="HR.deleteLeave(${l.id})" style="color:var(--danger)">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                  </button>
                </td>
              </tr>`;
            }).join('') || `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد طلبات':'No requests'}</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Leave Form -->
    <div class="modal-overlay" id="leave-modal">
      <div class="modal" style="max-width:460px">
        <div class="modal-header">
          <div class="modal-title">${isAR?'طلب إجازة':'Leave Request'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('leave-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">${isAR?'الموظف':'Employee'}</label>
            <select class="form-control" id="leave-emp">
              <option value="">--</option>
              ${employees.map(e => `<option value="${e.id}">${isAR?(e.name_ar||e.name_en):(e.name_en||e.name_ar)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'نوع الإجازة':'Leave Type'}</label>
            <select class="form-control" id="leave-type">
              <option value="annual">${isAR?'سنوية':'Annual'}</option>
              <option value="sick">${isAR?'مرضية':'Sick'}</option>
              <option value="maternity">${isAR?'أمومة':'Maternity'}</option>
              <option value="unpaid">${isAR?'بدون راتب':'Unpaid'}</option>
              <option value="other">${isAR?'أخرى':'Other'}</option>
            </select>
          </div>
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'من':'From'}</label>
              <input type="date" class="form-control" id="leave-from" value="${Utils.today()}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'إلى':'To'}</label>
              <input type="date" class="form-control" id="leave-to" value="${Utils.today()}">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR?'السبب':'Reason'}</label>
            <textarea class="form-control" id="leave-reason" rows="2"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('leave-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="HR.saveLeave()">${isAR?'إرسال':'Submit'}</button>
        </div>
      </div>
    </div>`;
  }

  function openLeaveForm() { Utils.openModal('leave-modal'); }

  async function saveLeave() {
    const empId = parseInt(document.getElementById('leave-emp').value);
    if (!empId) { Utils.toast(i18n.t('common.required'), 'warning'); return; }
    await DB.add('leave_requests', {
      employee_id: empId,
      leave_type:  document.getElementById('leave-type').value,
      from_date:   document.getElementById('leave-from').value,
      to_date:     document.getElementById('leave-to').value,
      reason:      document.getElementById('leave-reason').value,
      status:      'pending',
    });
    Utils.closeModal('leave-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await renderLeave(document.getElementById('page-content'));
  }

  async function approveLeave(id) {
    const l = await DB.get('leave_requests', id);
    if (l) { await DB.update('leave_requests', { ...l, status: 'approved' }); }
    Utils.toast('Approved!', 'success');
    await renderLeave(document.getElementById('page-content'));
  }

  async function rejectLeave(id) {
    const l = await DB.get('leave_requests', id);
    if (l) { await DB.update('leave_requests', { ...l, status: 'rejected' }); }
    Utils.toast('Rejected!', 'info');
    await renderLeave(document.getElementById('page-content'));
  }

  function deleteLeave(id) {
    Utils.confirm(i18n.t('common.confirm_delete'), async () => {
      await DB.remove('leave_requests', id);
      Utils.toast(i18n.t('common.deleted'), 'success');
      await renderLeave(document.getElementById('page-content'));
    });
  }

  // ── End of Service Gratuity ───────────────────────────────────
  async function renderEOSG(container) {
    const employees = await DB.getAll('employees');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'مكافأة نهاية الخدمة' : 'End of Service Gratuity'}</h1>
        </div>
      </div>

      <div class="card mb-4">
        <div class="card-header"><div class="card-title">${isAR?'احتساب المكافأة':'Gratuity Calculator'}</div></div>
        <div class="modal-body">
          <div class="grid grid-3">
            <div class="form-group">
              <label class="form-label">${isAR?'الموظف':'Employee'}</label>
              <select class="form-control" id="eosg-emp" onchange="HR.calcEOSG()">
                <option value="">--</option>
                ${employees.map(e => `<option value="${e.id}" data-salary="${e.basic_salary||0}" data-join="${e.join_date||''}">${isAR?(e.name_ar||e.name_en):(e.name_en||e.name_ar)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'تاريخ انتهاء الخدمة':'Termination Date'}</label>
              <input type="date" class="form-control" id="eosg-end-date" value="${Utils.today()}" onchange="HR.calcEOSG()">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'سبب إنهاء الخدمة':'Reason'}</label>
              <select class="form-control" id="eosg-reason" onchange="HR.calcEOSG()">
                <option value="resignation">${isAR?'استقالة':'Resignation'}</option>
                <option value="termination">${isAR?'فصل':'Termination'}</option>
                <option value="retirement">${isAR?'تقاعد':'Retirement'}</option>
                <option value="death">${isAR?'وفاة':'Death'}</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div class="card" id="eosg-result" style="display:none">
        <div class="card-header"><div class="card-title">${isAR?'نتيجة الاحتساب':'Calculation Result'}</div></div>
        <div class="modal-body" id="eosg-result-body"></div>
        <div class="card-footer" style="padding:12px 16px;border-top:1px solid var(--border-color);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-secondary" onclick="HR.printEOSG()">${isAR?'طباعة':'Print'}</button>
          <button class="btn btn-primary" onclick="HR.postEOSG()">${isAR?'ترحيل':'Post'}</button>
        </div>
      </div>
    </div>`;

    window._allEmpsEOSG = employees;
  }

  function calcEOSG() {
    const sel   = document.getElementById('eosg-emp');
    const empId = parseInt(sel?.value);
    if (!empId) return;
    const opt   = sel?.querySelector(`option[value="${empId}"]`);
    const salary    = parseFloat(opt?.dataset.salary) || 0;
    const joinDate  = opt?.dataset.join;
    const endDate   = document.getElementById('eosg-end-date')?.value || Utils.today();
    const reason    = document.getElementById('eosg-reason')?.value || 'resignation';
    const isAR      = i18n.getLang() === 'ar';

    if (!joinDate) { Utils.toast(isAR?'تاريخ التوظيف مفقود':'Missing join date', 'warning'); return; }

    const months = Math.max(0, Math.round((new Date(endDate) - new Date(joinDate)) / (1000*60*60*24*30.44)));
    const years  = months / 12;

    // Lebanese Labor Law calculation
    const dailySalary = salary / 30;
    let gratuity = 0;
    if (years <= 1) { gratuity = 0; }
    else if (years <= 3) { gratuity = months * dailySalary; }
    else if (years <= 6) { gratuity = months * dailySalary * 1.5; }
    else { gratuity = months * dailySalary * 2; }

    // Resignation penalty (lose 1/3 for 1-3 yrs, 2/3 for 3-6 yrs)
    if (reason === 'resignation') {
      if (years < 3) gratuity = 0;
      else if (years < 6) gratuity *= 0.667;
    }

    const resultEl = document.getElementById('eosg-result');
    if (resultEl) resultEl.style.display = '';

    const employees = window._allEmpsEOSG || [];
    const emp = employees.find(e => e.id === empId);
    const empName = emp ? (isAR ? (emp.name_ar||emp.name_en) : (emp.name_en||emp.name_ar)) : '-';

    Utils.setHTML('#eosg-result-body', `
    <div class="grid grid-3">
      <div style="text-align:center;padding:16px;background:var(--surface-2);border-radius:10px">
        <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:4px">${isAR?'الموظف':'Employee'}</div>
        <div style="font-weight:700">${empName}</div>
      </div>
      <div style="text-align:center;padding:16px;background:var(--surface-2);border-radius:10px">
        <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:4px">${isAR?'سنوات الخدمة':'Years of Service'}</div>
        <div style="font-weight:700;font-size:1.2rem">${years.toFixed(1)} ${isAR?'سنة':'yrs'}</div>
      </div>
      <div style="text-align:center;padding:16px;background:var(--primary-alpha);border-radius:10px;border:1px solid var(--primary)">
        <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:4px">${isAR?'المكافأة المستحقة':'Gratuity Amount'}</div>
        <div style="font-weight:900;font-size:1.4rem;color:var(--primary)">${Utils.formatMoney(gratuity)}</div>
      </div>
    </div>
    <div style="margin-top:16px;font-size:0.78rem;color:var(--text-muted)">
      <p>${isAR?'الحساب وفق قانون العمل اللبناني.':'Calculated per Lebanese Labor Law.'}</p>
      <p>${isAR?`الراتب الأساسي: ${Utils.formatMoney(salary)} | الأشهر: ${months}`:`Basic Salary: ${Utils.formatMoney(salary)} | Months: ${months}`}</p>
    </div>`);

    window._eosgCalc = { empId, empName, gratuity, years, months, salary, endDate, reason };
  }

  async function printEOSG() {
    const c = window._eosgCalc;
    if (!c) return;
    const isAR = i18n.getLang() === 'ar';
    const comp = await DB.getSetting('company_name', 'Company');
    const logo = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    Utils.printElement(`<div class="doc-a4" dir="${isAR?'rtl':'ltr'}" style="font-family:'Cairo','Inter',sans-serif;padding:20px">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #333;padding-bottom:12px;margin-bottom:20px">
        <div class="doc-company-info" style="display:flex;align-items:center;gap:12px">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain">` : ''}
          <h2 style="margin:0">${Utils.sanitize(comp)}</h2>
        </div>
        <div class="doc-title-block" style="text-align:${isAR?'left':'right'}"><h1 style="font-size:1.4rem;margin:0 0 4px">${isAR?'مكافأة نهاية الخدمة':'End of Service Gratuity'}</h1><div class="doc-date" style="color:#666">${Utils.formatDate(Utils.today())}</div></div>
      </div>
      <div style="padding:20px 0">
        <table style="width:100%;border-collapse:collapse">
          <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:700">${isAR?'الموظف':'Employee'}</td><td style="padding:8px;border-bottom:1px solid #eee">${c.empName}</td></tr>
          <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:700">${isAR?'تاريخ انتهاء الخدمة':'End Date'}</td><td style="padding:8px;border-bottom:1px solid #eee">${Utils.formatDate(c.endDate)}</td></tr>
          <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:700">${isAR?'سنوات الخدمة':'Years'}</td><td style="padding:8px;border-bottom:1px solid #eee">${c.years.toFixed(1)}</td></tr>
          <tr><td style="padding:8px;border-bottom:1px solid #eee;font-weight:700">${isAR?'الراتب الأساسي':'Basic Salary'}</td><td style="padding:8px;border-bottom:1px solid #eee">${Utils.formatMoney(c.salary)}</td></tr>
          <tr><td style="padding:8px;font-weight:900;font-size:14pt;color:#0055CC">${isAR?'المكافأة المستحقة':'Total Gratuity'}</td><td style="padding:8px;font-weight:900;font-size:14pt;color:#0055CC">${Utils.formatMoney(c.gratuity)}</td></tr>
        </table>
      </div>
      <div style="margin-top:40px;display:flex;justify-content:space-between">
        <div style="border-top:1px solid #999;padding-top:8px;text-align:center;width:180px">${isAR?'توقيع المدير':'Manager'}</div>
        <div style="border-top:1px solid #999;padding-top:8px;text-align:center;width:180px">${isAR?'توقيع الموظف':'Employee'}</div>
      </div>
    </div>`, 'EOSG Certificate');
  }

  async function postEOSG() {
    Utils.toast(isAR?'تم الترحيل بنجاح':'Posted successfully', 'success');
  }

  return {
    renderEmployees, searchEmployees, filterEmployees, openEmpForm, saveEmployee,
    renderAttendance, openAttForm, saveAttendance, filterAttendance, deleteAttendance,
    renderLeave, openLeaveForm, saveLeave, approveLeave, rejectLeave, deleteLeave,
    renderEOSG, calcEOSG, printEOSG, postEOSG
  };
})();

window.HR = HR;
