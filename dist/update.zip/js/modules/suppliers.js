/* suppliers.js — Suppliers module */
if (typeof SuppliersModule !== 'undefined') {
  window.SuppliersModule = SuppliersModule;
  window.suppliersModule = SuppliersModule;
  window.Suppliers = window.Suppliers || {
    render: (c) => SuppliersModule.render(c),
  };
  window.suppliers = window.Suppliers;
}

