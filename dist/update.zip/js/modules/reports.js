/* ================================================================
   NexPOS — Reports Module
   ================================================================ */

const Reports = (() => {

  // ── Sales Report ──────────────────────────────────────────────
  // ── Helper to calculate Cost & Profit per Sale ──────────────
  async function _getEnrichedSales() {
    let sales = (await DB.getAll('sales')) || [];

    // Multi-POS & Branch Isolation / Centralization
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      try {
        const syncCfg = await BranchSync.getConfig();
        if (syncCfg.role !== 'server') {
          // Strict Branch Isolation: Client station or branch only sees its own data even if admin
          const myBranch = syncCfg.branchId || 'main';
          const myNode = syncCfg.nodeId;
          sales = sales.filter(s => (
            s.branch_id === myBranch || 
            s.syncBranchId === myBranch || 
            s.terminal_id === myNode || 
            s.syncNodeId === myNode || 
            (!s.branch_id && !s.syncBranchId)
          ));
        } else {
          // Main Server: Merge transactions pushed up by remote branches
          try {
            const res = await fetch('/api/sync/transactions');
            if (res.ok) {
              const j = await res.json();
              if (Array.isArray(j.sales) && j.sales.length > 0) {
                const existingMap = new Map();
                sales.forEach(s => existingMap.set(String(s.id || s.invoice_no), true));
                for (const bs of j.sales) {
                  const key = String(bs.id || bs.invoice_no);
                  if (!existingMap.has(key)) {
                    sales.push(bs);
                    existingMap.set(key, true);
                  }
                }
              }
              if (Array.isArray(j.cashboxSessions) && j.cashboxSessions.length > 0) {
                for (const cs of j.cashboxSessions) {
                  try { await DB.put('cashbox_sessions', cs); } catch(e) {}
                }
              }
            }
          } catch(e) {}
        }
      } catch(e) {}
    }

    const items = await DB.getAll('items');
    const cats  = await DB.getAll('categories');

    const itemMap = new Map();
    items.forEach(i => {
      if (i.id) itemMap.set(String(i.id), i);
      if (i.item_code) itemMap.set(String(i.item_code), i);
    });

    const catMap = new Map();
    cats.forEach(c => catMap.set(String(c.id), c));

    return sales.map(s => {
      let cartItems = [];
      try {
        cartItems = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []);
      } catch (e) {}

      let totalCost = 0;
      let totalRev  = parseFloat(s.grand_total) || 0;

      const enrichedItems = cartItems.map(ci => {
        let matched = itemMap.get(String(ci.item_id)) || itemMap.get(String(ci.item_code));
        let cost = parseFloat(ci.cost_price);
        if (isNaN(cost) || cost === 0) {
          cost = matched ? (parseFloat(matched.cost_price) || 0) : 0;
        }

        let catId = ci.category_id || matched?.category_id;
        let catObj = catId ? catMap.get(String(catId)) : null;
        let catName = catObj ? (i18n.getLang() === 'ar' ? (catObj.name_ar || catObj.name) : (catObj.name || catObj.name_ar)) : (i18n.getLang() === 'ar' ? 'غير مصنف' : 'Uncategorized');

        let qty = parseFloat(ci.qty) || 1;
        let price = parseFloat(ci.price) || 0;
        let discPct = parseFloat(ci.disc_pct) || 0;
        let discAmt = parseFloat(ci.disc_amt) || 0;
        let discType = ci.disc_type || 'pct';
        let unitDisc = discType === 'amt' ? Math.min(price, discAmt) : (price * (discPct / 100));
        let effPrice = Math.max(0, price - unitDisc);
        let type = ci.line_type || 'sale';

        let itemRev = 0;
        let itemCost = 0;
        let itemProfit = 0;

        if (type === 'sale') {
          itemRev = Utils.round(qty * effPrice);
          itemCost = Utils.round(qty * cost);
          itemProfit = Utils.round(itemRev - itemCost);
        } else if (type === 'return') {
          itemRev = -Utils.round(qty * effPrice);
          itemCost = -Utils.round(qty * cost);
          itemProfit = Utils.round(itemRev - itemCost);
        } else if (type === 'damage') {
          itemRev = 0;
          itemCost = Utils.round(qty * cost);
          itemProfit = -itemCost;
        } else if (type === 'gift') {
          itemRev = 0;
          itemCost = Utils.round(qty * cost);
          itemProfit = -itemCost;
        }

        totalCost += itemCost;

      
  function filterStockTable(q) {
    const table = document.getElementById('stock-report-table');
    if (!table) return;
    const rows = table.querySelectorAll('tbody tr');
    const term = (q || '').toLowerCase().trim();
    rows.forEach(r => {
      const txt = r.textContent.toLowerCase();
      r.style.display = txt.includes(term) ? '' : 'none';
    });
  }

  return {
    filterStockTable,
          ...ci,
          cost_price: cost,
          category_id: catId,
          category_name: catName,
          unit_discount: unitDisc,
          item_revenue: itemRev,
          item_cost: itemCost,
          item_profit: itemProfit
        };
      });

      totalCost = Utils.round(totalCost);
      const profit = Utils.round(totalRev - totalCost);
      const margin = totalRev > 0 ? Utils.round((profit / totalRev) * 100) : 0;
      const saleDisc = parseFloat(s.discount_amount || s.discount || s.manual_discount || 0);
      const subTot = parseFloat(s.subtotal || (totalRev + saleDisc)) || 0;

      return {
        ...s,
        total_discount: saleDisc,
        gross_sales: subTot,
        enriched_items: enrichedItems,
        total_cost: totalCost,
        net_profit: profit,
        margin_pct: margin
      };
    });
  }

  // ── Sales & Profit Report ─────────────────────────────────────
  async function renderSalesReport(container, defaultTab) {
    if (!container) container = document.getElementById('page-content');
    const enrichedSales = await _getEnrichedSales();
    const isAR = i18n.getLang() === 'ar';

    const today     = Utils.today();
    const thisMonth = today.slice(0, 7);

    window._enrichedSales = enrichedSales;
    window._repActiveSubTab = defaultTab || 'invoices';

    let isServerNode = true;
    let myBranch = 'main';
    let myNode = 'SRV-01';
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      try {
        const sc = await BranchSync.getConfig();
        isServerNode = (sc.role === 'server');
        myBranch = sc.branchId || 'main';
        myNode = sc.nodeId || 'SRV-01';
      } catch(e) {}
    }

    // Collect all available branches/stations in sales, cashbox sessions, and sync nodes
    const branchOptions = new Set();
    enrichedSales.forEach(s => {
      const b = s.syncBranchId || s.branch_id || s.syncNodeId || s.terminal_id;
      if (b && b !== 'undefined' && b !== 'null') branchOptions.add(b);
    });

    try {
      const sessions = (await DB.getAll('cashbox_sessions')) || [];
      sessions.forEach(s => {
        if (s.terminal_id) branchOptions.add(s.terminal_id);
      });
      const warehouses = (await DB.getAll('warehouses')) || [];
      warehouses.forEach(w => {
        if (w.name) branchOptions.add(w.name);
      });
      if (isServerNode) {
        const nRes = await fetch('/api/sync/nodes');
        if (nRes.ok) {
          const nj = await nRes.json();
          (nj.nodes || []).forEach(n => {
            if (n.nodeId) branchOptions.add(n.nodeId);
          });
        }
      }
    } catch(e) {}

    const isEmbedded = (container && container.id === 'master-report-render-target');

    const subTabsHtml = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:12px;background:var(--surface-card);padding:6px 10px;border-radius:12px;border:1px solid var(--border-color);flex-wrap:wrap">
        <button class="btn btn-sm ${window._repActiveSubTab === 'invoices' ? 'btn-primary' : 'btn-ghost'}" id="subtab-invoices" onclick="Reports.switchSubTab('invoices')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          🧾 ${isAR ? 'فواتير المبيعات' : 'Sales Invoices'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'top_products' ? 'btn-primary' : 'btn-ghost'}" id="subtab-top_products" onclick="Reports.switchSubTab('top_products')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          🏆 ${isAR ? 'الأكثر مبيعاً' : 'Top Products'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'items' ? 'btn-primary' : 'btn-ghost'}" id="subtab-items" onclick="Reports.switchSubTab('items')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          📦 ${isAR ? 'حسب الصنف' : 'By Item'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'categories' ? 'btn-primary' : 'btn-ghost'}" id="subtab-categories" onclick="Reports.switchSubTab('categories')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          📂 ${isAR ? 'حسب التصنيف' : 'By Category'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'customers' ? 'btn-primary' : 'btn-ghost'}" id="subtab-customers" onclick="Reports.switchSubTab('customers')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          👥 ${isAR ? 'حسب العميل' : 'By Customer'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'salespersons' ? 'btn-primary' : 'btn-ghost'}" id="subtab-salespersons" onclick="Reports.switchSubTab('salespersons')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          👤 ${isAR ? 'حسب البائع/الكاشير' : 'By Salesperson'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'daily' ? 'btn-primary' : 'btn-ghost'}" id="subtab-daily" onclick="Reports.switchSubTab('daily')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          📅 ${isAR ? 'ملخص يومي' : 'Daily Summary'}
        </button>
        <button class="btn btn-sm ${window._repActiveSubTab === 'returns' ? 'btn-primary' : 'btn-ghost'}" id="subtab-returns" onclick="Reports.switchSubTab('returns')" style="font-weight:700;border-radius:8px;padding:6px 14px">
          ↩️ ${isAR ? 'المرتجعات' : 'Returns'}
        </button>
      </div>
    `;

    const tableCardHtml = `
      <div class="card" id="sales-report-card" style="border-radius:14px;border:1px solid var(--border-color);overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,0.03)">
        <div class="card-header" style="display:flex;align-items:center;justify-content:space-between;padding:12px 18px;border-bottom:1px solid var(--border-color);background:var(--surface-card);flex-wrap:wrap;gap:10px">
          <div class="card-title" id="sales-report-title" style="font-weight:800;font-size:0.95rem;margin:0">
            ${isAR ? 'تفاصيل فواتير المبيعات والأرباح' : 'Invoice Details & Profit Breakdown'}
          </div>
          <div style="position:relative;min-width:240px">
            <input type="text" id="sales-rep-search" class="form-control form-control-sm" placeholder="${isAR ? '🔍 تصفية وبحث فوري...' : '🔍 Instant search...'}" oninput="Reports.filterTableRows(this.value)" style="height:32px;border-radius:8px;font-size:0.8rem">
          </div>
        </div>
        <div class="table-wrapper" id="rep-table-wrapper" style="max-height:calc(100vh - 360px);overflow-y:auto">
          <!-- populated dynamically -->
        </div>
      </div>
    `;

    if (isEmbedded) {
      container.innerHTML = `
      <div class="animate-slide">
        <!-- Live Dynamic KPI Cards -->
        <div class="grid grid-5 mb-3" id="rep-kpi-container" style="gap:10px">
          <!-- populated by loadSalesData -->
        </div>

        <!-- Sub Tabs -->
        ${subTabsHtml}

        <!-- Report Content Card -->
        ${tableCardHtml}
      </div>`;
    } else {
      container.innerHTML = `
      <div class="animate-slide">
        <div class="page-header">
          <div class="page-header-left" style="display:flex;align-items:center;gap:12px">
            <button class="btn btn-ghost btn-sm" onclick="Reports.render(document.getElementById('page-content'))" style="font-weight:700">← ${isAR ? 'مركز التقارير' : 'Reports Hub'}</button>
            <div>
              <h1>📊 ${isAR ? 'تقارير المبيعات والأرباح' : 'Sales & Profit Reports'}</h1>
              <p>${isAR ? 'تحليل المبيعات، المنتجات الأكثر مبيعاً، التكلفة، الأرباح، العملاء، والبائعين' : 'Comprehensive sales, top products, COGS, profit margins, customer & cashier analytics'}</p>
            </div>
          </div>
          <div class="page-actions">
            <button class="btn btn-success" onclick="Reports.openDailyDigestModal()" style="display:flex;align-items:center;gap:6px">
              <span>📱</span> ${isAR ? 'ملخص الإغلاق (واتساب)' : 'WhatsApp Daily Digest'}
            </button>
            <button class="btn btn-secondary" onclick="Reports.printSalesReport()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'طباعة' : 'Print'}
            </button>
            <button class="btn btn-primary" onclick="Reports.exportSalesReport()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              ${isAR ? 'تصدير' : 'Export'}
            </button>
          </div>
        </div>

        <!-- Filters & Date Range -->
        <div class="card mb-3" style="background:var(--surface-card);border:1px solid var(--border-color);border-radius:14px;padding:14px 18px">
          <div class="grid grid-4" style="align-items:flex-end;gap:12px">
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label" style="font-weight:800;font-size:0.8rem">${isAR ? 'من تاريخ' : 'From Date'}</label>
              <input type="date" class="form-control" id="rep-from" value="${thisMonth}-01" style="height:38px;border-radius:8px">
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label" style="font-weight:800;font-size:0.8rem">${isAR ? 'إلى تاريخ' : 'To Date'}</label>
              <input type="date" class="form-control" id="rep-to" value="${today}" style="height:38px;border-radius:8px">
            </div>
            <div class="form-group" style="margin-bottom:0">
              <label class="form-label" style="font-weight:800;font-size:0.8rem">${isAR ? 'تصفية حسب الفرع أو المحطة' : 'Branch / POS Station'}</label>
              ${isServerNode ? `
              <select class="form-control" id="rep-branch-filter" onchange="Reports.loadSalesData()" style="height:38px;border-radius:8px">
                <option value="all">🏢 ${isAR ? 'كافة الفروع والمحطات (تقرير مجمع)' : 'All Branches & Stations (Consolidated)'}</option>
                <option value="main">🖥️ ${isAR ? 'الفرع الرئيسي (السيرفر)' : 'Main Store (Server)'}</option>
                ${Array.from(branchOptions).filter(b => b !== 'main').map(b => `<option value="${b}">🏬 ${b}</option>`).join('')}
              </select>` : `
              <div style="height:38px;padding:8px 12px;background:rgba(255,255,255,0.04);border:1px solid var(--border-color);border-radius:8px;font-weight:800;color:var(--primary);font-size:0.85rem;display:flex;align-items:center">
                🏬 ${myBranch} (${myNode})
              </div>
              <input type="hidden" id="rep-branch-filter" value="${myBranch}">`}
            </div>
            <div class="form-group" style="margin-bottom:0">
              <button class="btn btn-primary" onclick="Reports.loadSalesData()" style="width:100%;height:38px;font-weight:800;border-radius:8px">
                ⚡ ${isAR ? 'عرض التقرير' : 'Run Report'}
              </button>
            </div>
          </div>
        </div>

        <!-- Live Dynamic KPI Cards -->
        <div class="grid grid-5 mb-3" id="rep-kpi-container" style="gap:10px">
          <!-- populated by loadSalesData -->
        </div>

        <!-- Sub Tabs -->
        ${subTabsHtml}

        <!-- Report Content Card -->
        ${tableCardHtml}
      </div>`;
    }

    loadSalesData();
  }

  function switchSubTab(tab) {
    window._repActiveSubTab = tab;
    _selectedMasterSub = tab;
    const subSelect = document.getElementById('master-rep-sub');
    if (subSelect && subSelect.value !== tab) {
      subSelect.value = tab;
    }

    ['invoices', 'top_products', 'items', 'categories', 'customers', 'salespersons', 'daily', 'returns'].forEach(t => {
      const btn = document.getElementById(`subtab-${t}`);
      if (btn) {
        if (t === tab) {
          btn.className = 'btn btn-sm btn-primary';
          btn.style.boxShadow = '0 2px 8px rgba(99,102,241,0.25)';
        } else {
          btn.className = 'btn btn-sm btn-ghost';
          btn.style.boxShadow = 'none';
        }
      }
    });
    loadSalesData();
  }

  async function loadSalesData() {
    const from = document.getElementById('rep-from')?.value;
    const to   = document.getElementById('rep-to')?.value;
    const branchFilter = document.getElementById('rep-branch-filter')?.value || 'all';
    const isAR = i18n.getLang() === 'ar';

    const allSales = window._enrichedSales || [];
    const sales = allSales.filter(s => {
      const date = (s.created_at || '').slice(0, 10);
      const matchDate = (!from || date >= from) && (!to || date <= to);
      if (!matchDate) return false;
      if (branchFilter && branchFilter !== 'all') {
        const b = s.syncBranchId || s.branch_id || s.syncNodeId || s.terminal_id;
        return b === branchFilter || (!b && branchFilter === 'main');
      }
      return true;
    });

    // Compute Totals for Date Range
    const totalSales  = sales.reduce((s, t) => s + (t.grand_total || 0), 0);
    const totalDiscounts = sales.reduce((s, t) => s + (t.total_discount || 0), 0);
    const totalCost   = sales.reduce((s, t) => s + (t.total_cost || 0), 0);
    const netProfit   = Utils.round(totalSales - totalCost);
    const marginPct   = totalSales > 0 ? Utils.round((netProfit / totalSales) * 100) : 0;

    // Render KPI Container
    const kpiEl = document.getElementById('rep-kpi-container');
    if (kpiEl) {
      kpiEl.innerHTML = `
        ${kpiCard(isAR ? 'إجمالي المبيعات' : 'Total Sales', totalSales, 'primary', '📊')}
        ${kpiCard(isAR ? 'إجمالي الخصومات' : 'Total Discounts', totalDiscounts, 'warning', '🏷️')}
        ${kpiCard(isAR ? 'إجمالي التكلفة (COGS)' : 'Total Cost (COGS)', totalCost, 'danger', '📦')}
        ${kpiCard(isAR ? 'صافي الربح' : 'Net Profit', netProfit, netProfit >= 0 ? 'success' : 'danger', '💰')}
        ${kpiCard(isAR ? 'هامش الربح %' : 'Profit Margin %', marginPct, marginPct >= 15 ? 'success' : 'warning', '📈', false, '%')}
      `;
    }

    const tab = window._repActiveSubTab || 'invoices';
    const wrapper = document.getElementById('rep-table-wrapper');
    const titleEl = document.getElementById('sales-report-title');

    if (tab === 'invoices') {
      if (titleEl) titleEl.textContent = isAR ? 'تفاصيل فواتير المبيعات والأرباح' : 'Sales Invoices & Profit Detail';
      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'الرقم والبنود' : 'Ref & Items'}</th>
            <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
            <th>${isAR ? 'العميل' : 'Customer'}</th>
            <th>${isAR ? 'طريقة الدفع' : 'Payment'}</th>
            <th>${isAR ? 'الخصم' : 'Discount'}</th>
            <th>${isAR ? 'إجمالي الفاتورة' : 'Invoice Total'}</th>
            <th>${isAR ? 'التكلفة' : 'Total Cost'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'هامش الربح' : 'Margin %'}</th>
          </tr></thead>
          <tbody id="sales-report-tbody">
            ${sales.length === 0
              ? `<tr><td colspan="9" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد مبيعات بالفترة المحددة' : 'No sales in selected range'}</td></tr>`
              : sales.slice().reverse().map((s, idx) => {
                const sDate = s.created_at || s.date;
                const dt = sDate ? new Date(sDate) : null;
                const dateStr = dt && !isNaN(dt.getTime()) ? dt.toLocaleDateString('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit' }) : (sDate || '-');
                const timeStr = dt && !isNaN(dt.getTime()) ? dt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }) : '';
                const itemsCount = (s.enriched_items || []).length;
                return `
              <tr style="cursor:pointer;transition:background 0.15s" onclick="Reports.toggleRowDetail('rep-inv-detail-${idx}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
                <td>
                  <div style="display:flex;align-items:center;gap:6px">
                    <button class="btn btn-ghost btn-sm" id="btn-rep-inv-detail-${idx}" style="padding:2px 6px;font-size:0.75rem;line-height:1;border-radius:4px" onclick="event.stopPropagation(); Reports.toggleRowDetail('rep-inv-detail-${idx}')" title="${isAR ? 'توسيع / طي بنود الفاتورة' : 'Expand / Collapse line items'}">▶</button>
                    <span style="font-weight:700;color:var(--primary)">${s.ref || '-'}</span>
                    <span class="badge badge-secondary" style="font-size:0.65rem;padding:2px 5px" title="${isAR ? 'عدد الأصناف' : 'Item count'}">${itemsCount} 📦</span>
                  </div>
                </td>
                <td>
                  <div style="font-weight:700;font-size:0.8rem">${dateStr}</div>
                  ${timeStr ? `<div style="font-size:0.7rem;color:var(--text-muted);margin-top:2px">🕒 ${timeStr}</div>` : ''}
                </td>
                <td>${Utils.truncate(s.customer_name || '-', 22)}</td>
                <td><span class="badge badge-secondary">${(s.payment_method || '-').toUpperCase()}</span></td>
                <td style="color:${(s.total_discount || 0) > 0 ? '#e11d48' : 'var(--text-muted)'};font-weight:${(s.total_discount || 0) > 0 ? '700' : 'normal'}">
                  ${(s.total_discount || 0) > 0 ? `-${Utils.formatMoney(s.total_discount)}` : '-'}
                </td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(s.grand_total || 0)}</td>
                <td style="color:var(--text-muted)">${Utils.formatMoney(s.total_cost || 0)}</td>
                <td style="font-weight:800;color:${(s.net_profit || 0) >= 0 ? 'var(--success)' : 'var(--danger)'}">
                  ${Utils.formatMoney(s.net_profit || 0)}
                </td>
                <td>
                  <span class="badge badge-${(s.margin_pct || 0) >= 15 ? 'success' : (s.margin_pct || 0) >= 0 ? 'warning' : 'danger'}">
                    ${s.margin_pct || 0}%
                  </span>
                </td>
              </tr>
              <!-- Expandable Line Items Sub-Table -->
              <tr id="rep-inv-detail-${idx}" style="display:none;background:var(--surface-2)">
                <td colspan="9" style="padding:12px 16px">
                  <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px;box-shadow:0 4px 12px rgba(0,0,0,0.1)">
                    <div style="font-weight:700;font-size:0.84rem;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:6px">
                      <span style="display:flex;align-items:center;gap:6px">
                        <span>📋</span> ${isAR ? 'تفاصيل بنود وأصناف الفاتورة' : 'Invoice Line Items Detail'}: <strong style="color:var(--primary)">${s.ref || '-'}</strong>
                      </span>
                      <span style="font-size:0.75rem;color:var(--text-muted)">${itemsCount} ${isAR ? 'أصناف مدرجة' : 'items recorded'}</span>
                    </div>
                    ${itemsCount === 0 ? `<div style="text-align:center;color:var(--text-muted);padding:10px;font-size:0.78rem">${isAR ? 'لا توجد تفاصيل أصناف محفوظة' : 'No line items recorded for this invoice'}</div>` : `
                    <table style="width:100%;font-size:0.78rem;border-collapse:collapse">
                      <thead>
                        <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted);text-align:left">
                          <th style="padding:6px">${isAR ? 'الصنف' : 'Item'}</th>
                          <th style="padding:6px">${isAR ? 'الحالة / النوع' : 'Status / Type'}</th>
                          <th style="padding:6px">${isAR ? 'الكمية' : 'Qty'}</th>
                          <th style="padding:6px">${isAR ? 'سعر البيع' : 'Unit Price'}</th>
                          <th style="padding:6px">${isAR ? 'الخصم' : 'Discount'}</th>
                          <th style="padding:6px">${isAR ? 'التكلفة' : 'Unit Cost'}</th>
                          <th style="padding:6px">${isAR ? 'إجمالي البيع' : 'Revenue'}</th>
                          <th style="padding:6px">${isAR ? 'إجمالي التكلفة' : 'Cost'}</th>
                          <th style="padding:6px">${isAR ? 'صافي الربح' : 'Net Profit'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${(s.enriched_items || []).map(item => {
                          const iName = isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name_ar || item.name);
                          const iType = item.line_type || (parseFloat(item.item_revenue) < 0 ? 'return' : 'sale');
                          const isRet = iType === 'return' || parseFloat(item.item_revenue) < 0;
                          return `
                          <tr style="border-bottom:1px solid rgba(255,255,255,0.05);${isRet ? 'background:rgba(239,68,68,0.08)' : ''}">
                            <td style="padding:6px;font-weight:600">
                              <div>${Utils.sanitize(iName || '-')}</div>
                              ${item.item_code ? `<span style="font-size:0.7rem;color:var(--text-muted)">[${item.item_code}]</span>` : ''}
                            </td>
                            <td style="padding:6px">
                              <span class="badge ${isRet ? 'badge-danger' : iType === 'damage' ? 'badge-warning' : iType === 'gift' ? 'badge-primary' : 'badge-success'}" style="font-size:0.7rem">
                                ${isRet ? (isAR ? '🔴 مرتجع' : '🔴 Return') : iType === 'damage' ? (isAR ? '🟠 تالف' : '🟠 Damaged') : iType === 'gift' ? (isAR ? '🎁 هدية' : '🎁 Gift') : (isAR ? '🟢 مبيع' : '🟢 Sale')}
                              </span>
                            </td>
                            <td style="padding:6px;font-weight:700">${item.qty || 1}</td>
                            <td style="padding:6px">${Utils.formatMoney(item.price || 0)}</td>
                            <td style="padding:6px;color:${item.unit_discount > 0 ? '#e11d48' : 'var(--text-muted)'};font-weight:${item.unit_discount > 0 ? '700' : 'normal'}">
                              ${item.unit_discount > 0 ? `-${Utils.formatMoney(item.unit_discount * (item.qty || 1))}` : '-'}
                            </td>
                            <td style="padding:6px;color:var(--text-muted)">${Utils.formatMoney(item.cost_price || 0)}</td>
                            <td style="padding:6px;font-weight:800;color:${isRet ? 'var(--danger)' : 'var(--primary)'}">${Utils.formatMoney(item.item_revenue || 0)}</td>
                            <td style="padding:6px;color:var(--text-muted)">${Utils.formatMoney(item.item_cost || 0)}</td>
                            <td style="padding:6px;font-weight:800;color:${(item.item_profit || 0) >= 0 ? 'var(--success)' : 'var(--danger)'}">
                              ${Utils.formatMoney(item.item_profit || 0)}
                            </td>
                          </tr>`;
                        }).join('')}
                      </tbody>
                    </table>`}
                  </div>
                </td>
              </tr>`;
              }).join('')}
          </tbody>
          <tfoot>
            <tr style="font-weight:900;background:var(--surface-2)">
              <td colspan="4">${isAR ? 'الإجمالي' : 'Total'}</td>
              <td style="color:var(--primary)">${Utils.formatMoney(totalSales)}</td>
              <td style="color:var(--text-muted)">${Utils.formatMoney(totalCost)}</td>
              <td style="color:${netProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(netProfit)}</td>
              <td>${marginPct}%</td>
            </tr>
          </tfoot>
        </table>`;
      }
    } else if (tab === 'top_products') {
      if (titleEl) titleEl.textContent = isAR ? '🏆 المنتجات الأكثر مبيعاً والأعلى تحقيقاً للأرباح' : '🏆 Top Selling Products & Profitability Ranking';

      const itemAgg = new Map();
      sales.forEach(s => {
        (s.enriched_items || []).forEach(ci => {
          const key = ci.item_code || String(ci.item_id) || ci.name || 'item';
          if (!itemAgg.has(key)) {
            itemAgg.set(key, {
              code: ci.item_code || '-',
              name: isAR ? (ci.name_ar || ci.name_en || ci.name) : (ci.name_en || ci.name_ar || ci.name),
              category: ci.category_name || '-',
              qty: 0,
              revenue: 0,
              cost: 0,
              profit: 0,
              txs: []
            });
          }
          const rec = itemAgg.get(key);
          const q = parseFloat(ci.qty) || 0;
          rec.qty += q;
          rec.revenue += ci.item_revenue || 0;
          rec.cost += ci.item_cost || 0;
          rec.profit += ci.item_profit || 0;
          rec.txs.push({
            ref: s.ref || '-',
            date: s.created_at || s.date,
            customer: s.customer_name || (isAR ? 'عميل نقدي' : 'Cash Customer'),
            qty: q,
            price: ci.price || 0,
            revenue: ci.item_revenue || 0,
            profit: ci.item_profit || 0
          });
        });
      });

      const topList = Array.from(itemAgg.values()).map(r => ({
        ...r,
        margin: r.revenue > 0 ? Utils.round((r.profit / r.revenue) * 100) : 0,
        avgPrice: r.qty > 0 ? Utils.round(r.revenue / r.qty) : 0,
        share: totalSales > 0 ? Utils.round((r.revenue / totalSales) * 100) : 0
      })).sort((a, b) => b.qty - a.qty || b.revenue - a.revenue);

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th style="width:65px">${isAR ? 'الترتيب' : 'Rank'}</th>
            <th>${isAR ? 'الرمز' : 'Code'}</th>
            <th>${isAR ? 'اسم المنتج' : 'Product Name'}</th>
            <th>${isAR ? 'التصنيف' : 'Category'}</th>
            <th>${isAR ? 'الكمية المباعة' : 'Qty Sold'}</th>
            <th>${isAR ? 'متوسط السعر' : 'Avg Price'}</th>
            <th>${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'هامش الربح' : 'Margin %'}</th>
            <th>${isAR ? 'حصة المبيعات' : 'Revenue Share'}</th>
          </tr></thead>
          <tbody>
            ${topList.length === 0
              ? `<tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد مبيعات بالفترة المحددة' : 'No sales data found in selected date range'}</td></tr>`
              : topList.map((p, idx) => {
                const rankBadge = idx === 0 ? '🥇 #1' : idx === 1 ? '🥈 #2' : idx === 2 ? '🥉 #3' : `#${idx + 1}`;
                const rankColor = idx === 0 ? 'color:#f59e0b;font-weight:900' : idx === 1 ? 'color:#94a3b8;font-weight:900' : idx === 2 ? 'color:#d97706;font-weight:900' : 'font-weight:700;color:var(--text-muted)';
                return `
                <tr style="cursor:pointer;${idx < 3 ? 'background:rgba(239,68,68,0.03)' : ''}" onclick="Reports.toggleRowDetail('rep-top-${idx}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
                  <td style="${rankColor};font-size:0.95rem">${rankBadge}</td>
                  <td style="font-weight:700;color:var(--primary);font-size:0.78rem">
                    <div style="display:flex;align-items:center;gap:4px">
                      <button class="btn btn-ghost btn-sm" id="btn-rep-top-${idx}" style="padding:1px 5px;font-size:0.72rem" onclick="event.stopPropagation(); Reports.toggleRowDetail('rep-top-${idx}')">▶</button>
                      <span>${p.code}</span>
                    </div>
                  </td>
                  <td style="font-weight:700;font-size:0.85rem">${Utils.truncate(p.name, 30)}</td>
                  <td style="font-size:0.78rem">${p.category}</td>
                  <td style="font-weight:900;color:var(--accent);font-size:0.95rem">${p.qty}</td>
                  <td>${Utils.formatMoney(p.avgPrice)}</td>
                  <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(p.revenue)}</td>
                  <td style="font-weight:800;color:${p.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(p.profit)}</td>
                  <td><span class="badge badge-${p.margin >= 15 ? 'success' : p.margin >= 0 ? 'warning' : 'danger'}">${p.margin}%</span></td>
                  <td>
                    <div style="display:flex;align-items:center;gap:6px">
                      <div style="flex:1;height:8px;background:var(--surface-2);border-radius:4px;overflow:hidden">
                        <div style="height:100%;width:${p.share}%;background:linear-gradient(90deg,var(--primary),#f59e0b);border-radius:4px"></div>
                      </div>
                      <span style="font-size:0.75rem;font-weight:700;width:35px">${p.share}%</span>
                    </div>
                  </td>
                </tr>
                <tr id="rep-top-${idx}" style="display:none;background:var(--surface-2)">
                  <td colspan="10" style="padding:12px 16px">
                    <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px">
                      <div style="font-weight:700;font-size:0.82rem;margin-bottom:8px">📦 ${isAR ? 'عمليات بيع الصنف' : 'Sales Transactions for'} <strong style="color:var(--primary)">${p.name}</strong> (${p.txs.length})</div>
                      <table style="width:100%;font-size:0.76rem">
                        <thead>
                          <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted)">
                            <th style="padding:4px">${isAR ? 'رقم الفاتورة' : 'Invoice Ref'}</th>
                            <th style="padding:4px">${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
                            <th style="padding:4px">${isAR ? 'العميل' : 'Customer'}</th>
                            <th style="padding:4px">${isAR ? 'الكمية' : 'Qty'}</th>
                            <th style="padding:4px">${isAR ? 'السعر' : 'Price'}</th>
                            <th style="padding:4px">${isAR ? 'إجمالي المبيعات' : 'Revenue'}</th>
                            <th style="padding:4px">${isAR ? 'الربح' : 'Profit'}</th>
                          </tr>
                        </thead>
                        <tbody>
                          ${p.txs.map(t => `
                          <tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
                            <td style="padding:4px;font-weight:700;color:var(--primary)">${t.ref}</td>
                            <td style="padding:4px">${Utils.formatDateTime(t.date)}</td>
                            <td style="padding:4px">${Utils.truncate(t.customer, 20)}</td>
                            <td style="padding:4px;font-weight:700">${t.qty}</td>
                            <td style="padding:4px">${Utils.formatMoney(t.price)}</td>
                            <td style="padding:4px;font-weight:800;color:var(--primary)">${Utils.formatMoney(t.revenue)}</td>
                            <td style="padding:4px;font-weight:800;color:${t.profit>=0?'var(--success)':'var(--danger)'}">${Utils.formatMoney(t.profit)}</td>
                          </tr>`).join('')}
                        </tbody>
                      </table>
                    </div>
                  </td>
                </tr>`;
              }).join('')}
          </tbody>
        </table>`;
      }
    } else if (tab === 'items') {
      if (titleEl) titleEl.textContent = isAR ? 'تقرير حركة وأرباح الأصناف' : 'Item Movement & Profit Breakdown';

      const itemAgg = new Map();
      sales.forEach(s => {
        (s.enriched_items || []).forEach(ci => {
          const key = ci.item_code || String(ci.item_id) || ci.name || 'item';
          if (!itemAgg.has(key)) {
            itemAgg.set(key, {
              code: ci.item_code || '-',
              name: isAR ? (ci.name_ar || ci.name_en || ci.name) : (ci.name_en || ci.name_ar || ci.name),
              category: ci.category_name || '-',
              qty: 0,
              revenue: 0,
              cost: 0,
              profit: 0,
              txs: []
            });
          }
          const rec = itemAgg.get(key);
          const q = parseFloat(ci.qty) || 0;
          rec.qty += q;
          rec.revenue += ci.item_revenue || 0;
          rec.cost += ci.item_cost || 0;
          rec.profit += ci.item_profit || 0;
          rec.txs.push({
            ref: s.ref || '-',
            date: s.created_at || s.date,
            customer: s.customer_name || (isAR ? 'عميل نقدي' : 'Cash Customer'),
            qty: q,
            price: ci.price || 0,
            revenue: ci.item_revenue || 0,
            profit: ci.item_profit || 0
          });
        });
      });

      const itemsList = Array.from(itemAgg.values()).map(r => ({
        ...r,
        margin: r.revenue > 0 ? Utils.round((r.profit / r.revenue) * 100) : 0,
        avgPrice: r.qty > 0 ? Utils.round(r.revenue / r.qty) : 0
      })).sort((a, b) => b.revenue - a.revenue);

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'رمز الصنف' : 'Code'}</th>
            <th>${isAR ? 'اسم الصنف' : 'Item Name'}</th>
            <th>${isAR ? 'التصنيف' : 'Category'}</th>
            <th>${isAR ? 'الكمية المباعة' : 'Qty Sold'}</th>
            <th>${isAR ? 'متوسط السعر' : 'Avg Price'}</th>
            <th>${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
            <th>${isAR ? 'إجمالي التكلفة' : 'Total Cost'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'هامش الربح' : 'Margin %'}</th>
          </tr></thead>
          <tbody>
            ${itemsList.length === 0
              ? `<tr><td colspan="9" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد حركة أصناف' : 'No item movements found'}</td></tr>`
              : itemsList.map((i, idx) => `
              <tr style="cursor:pointer;transition:background 0.15s" onclick="Reports.toggleRowDetail('rep-itm-${idx}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
                <td style="font-weight:700;color:var(--primary);font-size:0.78rem">
                  <div style="display:flex;align-items:center;gap:4px">
                    <button class="btn btn-ghost btn-sm" id="btn-rep-itm-${idx}" style="padding:1px 5px;font-size:0.72rem" onclick="event.stopPropagation(); Reports.toggleRowDetail('rep-itm-${idx}')">▶</button>
                    <span>${i.code}</span>
                  </div>
                </td>
                <td style="font-weight:600">${Utils.truncate(i.name, 28)}</td>
                <td style="font-size:0.78rem">${i.category}</td>
                <td style="font-weight:800;color:var(--accent)">${i.qty}</td>
                <td>${Utils.formatMoney(i.avgPrice)}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(i.revenue)}</td>
                <td style="color:var(--text-muted)">${Utils.formatMoney(i.cost)}</td>
                <td style="font-weight:800;color:${i.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(i.profit)}</td>
                <td><span class="badge badge-${i.margin >= 15 ? 'success' : i.margin >= 0 ? 'warning' : 'danger'}">${i.margin}%</span></td>
              </tr>
              <tr id="rep-itm-${idx}" style="display:none;background:var(--surface-2)">
                <td colspan="9" style="padding:12px 16px">
                  <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px">
                    <div style="font-weight:700;font-size:0.82rem;margin-bottom:8px">📦 ${isAR ? 'عمليات بيع الصنف' : 'Sales Transactions for'} <strong style="color:var(--primary)">${i.name}</strong> (${i.txs.length})</div>
                    <table style="width:100%;font-size:0.76rem">
                      <thead>
                        <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted)">
                          <th style="padding:4px">${isAR ? 'رقم الفاتورة' : 'Invoice Ref'}</th>
                          <th style="padding:4px">${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
                          <th style="padding:4px">${isAR ? 'العميل' : 'Customer'}</th>
                          <th style="padding:4px">${isAR ? 'الكمية' : 'Qty'}</th>
                          <th style="padding:4px">${isAR ? 'السعر' : 'Price'}</th>
                          <th style="padding:4px">${isAR ? 'إجمالي المبيعات' : 'Revenue'}</th>
                          <th style="padding:4px">${isAR ? 'الربح' : 'Profit'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${i.txs.map(t => `
                        <tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
                          <td style="padding:4px;font-weight:700;color:var(--primary)">${t.ref}</td>
                          <td style="padding:4px">${Utils.formatDateTime(t.date)}</td>
                          <td style="padding:4px">${Utils.truncate(t.customer, 20)}</td>
                          <td style="padding:4px;font-weight:700">${t.qty}</td>
                          <td style="padding:4px">${Utils.formatMoney(t.price)}</td>
                          <td style="padding:4px;font-weight:800;color:var(--primary)">${Utils.formatMoney(t.revenue)}</td>
                          <td style="padding:4px;font-weight:800;color:${t.profit>=0?'var(--success)':'var(--danger)'}">${Utils.formatMoney(t.profit)}</td>
                        </tr>`).join('')}
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      }
    } else if (tab === 'categories') {
      if (titleEl) titleEl.textContent = isAR ? 'تقرير حركة وأرباح التصنيفات' : 'Category Sales & Profit Breakdown';

      const catAgg = new Map();
      sales.forEach(s => {
        (s.enriched_items || []).forEach(ci => {
          const key = ci.category_name || (isAR ? 'غير مصنف' : 'Uncategorized');
          if (!catAgg.has(key)) {
            catAgg.set(key, {
              category: key,
              qty: 0,
              revenue: 0,
              cost: 0,
              profit: 0
            });
          }
          const rec = catAgg.get(key);
          rec.qty += parseFloat(ci.qty) || 0;
          rec.revenue += ci.item_revenue || 0;
          rec.cost += ci.item_cost || 0;
          rec.profit += ci.item_profit || 0;
        });
      });

      const catsList = Array.from(catAgg.values()).map(r => ({
        ...r,
        margin: r.revenue > 0 ? Utils.round((r.profit / r.revenue) * 100) : 0,
        share: totalSales > 0 ? Utils.round((r.revenue / totalSales) * 100) : 0
      })).sort((a, b) => b.revenue - a.revenue);

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'التصنيف' : 'Category'}</th>
            <th>${isAR ? 'قطع مباعة' : 'Items Sold'}</th>
            <th>${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
            <th>${isAR ? 'إجمالي التكلفة' : 'Total Cost'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'هامش الربح' : 'Margin %'}</th>
            <th>${isAR ? 'حصة المبيعات %' : 'Share %'}</th>
          </tr></thead>
          <tbody>
            ${catsList.length === 0
              ? `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات مبيعات تصنيفات' : 'No category sales data'}</td></tr>`
              : catsList.map(c => `
              <tr>
                <td style="font-weight:700;color:var(--primary)">${c.category}</td>
                <td style="font-weight:800">${c.qty}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(c.revenue)}</td>
                <td style="color:var(--text-muted)">${Utils.formatMoney(c.cost)}</td>
                <td style="font-weight:800;color:${c.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(c.profit)}</td>
                <td><span class="badge badge-${c.margin >= 15 ? 'success' : c.margin >= 0 ? 'warning' : 'danger'}">${c.margin}%</span></td>
                <td>
                  <div style="display:flex;align-items:center;gap:6px">
                    <div style="flex:1;height:8px;background:var(--surface-2);border-radius:4px;overflow:hidden">
                      <div style="height:100%;width:${c.share}%;background:var(--primary);border-radius:4px"></div>
                    </div>
                    <span style="font-size:0.75rem;font-weight:700;width:35px">${c.share}%</span>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      }
    } else if (tab === 'customers') {
      if (titleEl) titleEl.textContent = isAR ? 'تقرير المبيعات حسب العميل' : 'Sales By Customer Breakdown';

      const custAgg = new Map();
      sales.forEach(s => {
        const cName = s.customer_name || (isAR ? 'عميل نقدي' : 'Cash Customer');
        if (!custAgg.has(cName)) {
          custAgg.set(cName, { name: cName, count: 0, revenue: 0, cost: 0, profit: 0, lastDate: s.created_at, sales: [] });
        }
        const rec = custAgg.get(cName);
        rec.count++;
        rec.revenue += s.grand_total || 0;
        rec.cost += s.total_cost || 0;
        rec.profit += s.net_profit || 0;
        rec.sales.push(s);
        if ((s.created_at || '') > rec.lastDate) rec.lastDate = s.created_at;
      });

      const custList = Array.from(custAgg.values()).map(c => ({
        ...c,
        avgTicket: c.count > 0 ? Utils.round(c.revenue / c.count) : 0,
        margin: c.revenue > 0 ? Utils.round((c.profit / c.revenue) * 100) : 0
      })).sort((a, b) => b.revenue - a.revenue);

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'اسم العميل' : 'Customer Name'}</th>
            <th>${isAR ? 'عدد الفواتير' : 'Invoices'}</th>
            <th>${isAR ? 'إجمالي المشتريات' : 'Total Revenue'}</th>
            <th>${isAR ? 'متوسط الفاتورة' : 'Avg Ticket'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'هامش الربح' : 'Margin %'}</th>
            <th>${isAR ? 'آخر عملية' : 'Last Purchase'}</th>
          </tr></thead>
          <tbody>
            ${custList.length === 0
              ? `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات عملاء' : 'No customer sales found'}</td></tr>`
              : custList.map((c, idx) => `
              <tr style="cursor:pointer;transition:background 0.15s" onclick="Reports.toggleRowDetail('rep-cust-${idx}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
                <td>
                  <div style="display:flex;align-items:center;gap:6px">
                    <button class="btn btn-ghost btn-sm" id="btn-rep-cust-${idx}" style="padding:2px 6px;font-size:0.75rem;line-height:1;border-radius:4px" onclick="event.stopPropagation(); Reports.toggleRowDetail('rep-cust-${idx}')">▶</button>
                    <span style="font-weight:700;color:var(--primary)">👥 ${c.name}</span>
                  </div>
                </td>
                <td style="font-weight:800">${c.count}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(c.revenue)}</td>
                <td>${Utils.formatMoney(c.avgTicket)}</td>
                <td style="font-weight:800;color:${c.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(c.profit)}</td>
                <td><span class="badge badge-${c.margin >= 15 ? 'success' : c.margin >= 0 ? 'warning' : 'danger'}">${c.margin}%</span></td>
                <td style="font-size:0.78rem">${Utils.formatDate(c.lastDate)}</td>
              </tr>
              <tr id="rep-cust-${idx}" style="display:none;background:var(--surface-2)">
                <td colspan="7" style="padding:12px 16px">
                  <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px">
                    <div style="font-weight:700;font-size:0.82rem;margin-bottom:8px">📋 ${isAR ? 'فواتير العميل' : 'Invoices for'} <strong style="color:var(--primary)">${c.name}</strong> (${c.sales.length})</div>
                    <table style="width:100%;font-size:0.76rem">
                      <thead>
                        <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted)">
                          <th style="padding:4px">${isAR ? 'رقم الفاتورة' : 'Invoice Ref'}</th>
                          <th style="padding:4px">${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
                          <th style="padding:4px">${isAR ? 'طريقة الدفع' : 'Payment'}</th>
                          <th style="padding:4px">${isAR ? 'الإجمالي' : 'Total'}</th>
                          <th style="padding:4px">${isAR ? 'الربح' : 'Profit'}</th>
                          <th style="padding:4px">${isAR ? 'الأصناف' : 'Items'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${c.sales.map(s => `
                        <tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
                          <td style="padding:4px;font-weight:700;color:var(--primary)">${s.ref || '-'}</td>
                          <td style="padding:4px">${Utils.formatDateTime(s.created_at || s.date)}</td>
                          <td style="padding:4px"><span class="badge badge-secondary">${(s.payment_method || '-').toUpperCase()}</span></td>
                          <td style="padding:4px;font-weight:800;color:var(--primary)">${Utils.formatMoney(s.grand_total || 0)}</td>
                          <td style="padding:4px;font-weight:800;color:${(s.net_profit||0)>=0?'var(--success)':'var(--danger)'}">${Utils.formatMoney(s.net_profit || 0)}</td>
                          <td style="padding:4px;color:var(--text-secondary)">${(s.enriched_items || []).map(i => `${i.name || i.name_en || i.name_ar} (x${i.qty || 1})`).join(', ') || '-'}</td>
                        </tr>`).join('')}
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      }
    } else if (tab === 'salespersons') {
      if (titleEl) titleEl.textContent = isAR ? 'تقرير مبيعات وأداء البائعين والكاشير' : 'Sales By Salesperson & Cashier';

      const userAgg = new Map();
      sales.forEach(s => {
        const uName = s.user_name || s.cashier || (isAR ? 'كاشير عام' : 'Main Cashier');
        if (!userAgg.has(uName)) {
          userAgg.set(uName, { name: uName, count: 0, revenue: 0, cost: 0, profit: 0, cash: 0, card: 0, sales: [] });
        }
        const rec = userAgg.get(uName);
        rec.count++;
        rec.revenue += s.grand_total || 0;
        rec.cost += s.total_cost || 0;
        rec.profit += s.net_profit || 0;
        rec.sales.push(s);
        if (s.payment_method === 'cash') rec.cash += s.grand_total || 0;
        else if (s.payment_method === 'credit') {
          const down = parseFloat(s.paid_amount !== undefined ? s.paid_amount : (s.tendered || 0));
          rec.cash += Math.min(s.grand_total || 0, Math.max(0, down));
        }
        else rec.card += s.grand_total || 0;
      });

      const userList = Array.from(userAgg.values()).map(u => ({
        ...u,
        avgTicket: u.count > 0 ? Utils.round(u.revenue / u.count) : 0,
        margin: u.revenue > 0 ? Utils.round((u.profit / u.revenue) * 100) : 0
      })).sort((a, b) => b.revenue - a.revenue);

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'اسم البائع / الكاشير' : 'Salesperson / Cashier'}</th>
            <th>${isAR ? 'عدد الفواتير' : 'Invoices'}</th>
            <th>${isAR ? 'مبيعات الكاش' : 'Cash Total'}</th>
            <th>${isAR ? 'مبيعات البطاقات' : 'Card Total'}</th>
            <th>${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'متوسط الفاتورة' : 'Avg Ticket'}</th>
          </tr></thead>
          <tbody>
            ${userList.length === 0
              ? `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات' : 'No salesperson data found'}</td></tr>`
              : userList.map((u, idx) => `
              <tr style="cursor:pointer;transition:background 0.15s" onclick="Reports.toggleRowDetail('rep-user-${idx}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
                <td>
                  <div style="display:flex;align-items:center;gap:6px">
                    <button class="btn btn-ghost btn-sm" id="btn-rep-user-${idx}" style="padding:2px 6px;font-size:0.75rem;line-height:1;border-radius:4px" onclick="event.stopPropagation(); Reports.toggleRowDetail('rep-user-${idx}')">▶</button>
                    <span style="font-weight:700;color:var(--primary)">👤 ${u.name}</span>
                  </div>
                </td>
                <td style="font-weight:800">${u.count}</td>
                <td>${Utils.formatMoney(u.cash)}</td>
                <td>${Utils.formatMoney(u.card)}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(u.revenue)}</td>
                <td style="font-weight:800;color:${u.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(u.profit)}</td>
                <td style="font-weight:700">${Utils.formatMoney(u.avgTicket)}</td>
              </tr>
              <tr id="rep-user-${idx}" style="display:none;background:var(--surface-2)">
                <td colspan="7" style="padding:12px 16px">
                  <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px">
                    <div style="font-weight:700;font-size:0.82rem;margin-bottom:8px">📋 ${isAR ? 'فواتير البائع' : 'Invoices handled by'} <strong style="color:var(--primary)">${u.name}</strong> (${u.sales.length})</div>
                    <table style="width:100%;font-size:0.76rem">
                      <thead>
                        <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted)">
                          <th style="padding:4px">${isAR ? 'رقم الفاتورة' : 'Invoice Ref'}</th>
                          <th style="padding:4px">${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
                          <th style="padding:4px">${isAR ? 'العميل' : 'Customer'}</th>
                          <th style="padding:4px">${isAR ? 'طريقة الدفع' : 'Payment'}</th>
                          <th style="padding:4px">${isAR ? 'الإجمالي' : 'Total'}</th>
                          <th style="padding:4px">${isAR ? 'الربح' : 'Profit'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${u.sales.map(s => `
                        <tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
                          <td style="padding:4px;font-weight:700;color:var(--primary)">${s.ref || '-'}</td>
                          <td style="padding:4px">${Utils.formatDateTime(s.created_at || s.date)}</td>
                          <td style="padding:4px">${Utils.truncate(s.customer_name || '-', 20)}</td>
                          <td style="padding:4px"><span class="badge badge-secondary">${(s.payment_method || '-').toUpperCase()}</span></td>
                          <td style="padding:4px;font-weight:800;color:var(--primary)">${Utils.formatMoney(s.grand_total || 0)}</td>
                          <td style="padding:4px;font-weight:800;color:${(s.net_profit||0)>=0?'var(--success)':'var(--danger)'}">${Utils.formatMoney(s.net_profit || 0)}</td>
                        </tr>`).join('')}
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      }
    } else if (tab === 'daily') {
      if (titleEl) titleEl.textContent = isAR ? 'الملخص اليومي لحركة المبيعات' : 'Daily Sales Summary Ledger';

      const dayAgg = new Map();
      sales.forEach(s => {
        const d = (s.created_at || s.date || '').slice(0, 10) || 'Unknown';
        if (!dayAgg.has(d)) {
          dayAgg.set(d, { date: d, count: 0, revenue: 0, cost: 0, profit: 0, cash: 0, card: 0, discount: 0, sales: [] });
        }
        const rec = dayAgg.get(d);
        rec.count++;
        rec.revenue += s.grand_total || 0;
        rec.cost += s.total_cost || 0;
        rec.profit += s.net_profit || 0;
        rec.discount += (parseFloat(s.total_discount || s.discount_amount || s.discount || s.manual_discount || 0));
        rec.sales.push(s);
        if (s.payment_method === 'cash') rec.cash += s.grand_total || 0;
        else if (s.payment_method === 'credit') {
          const down = parseFloat(s.paid_amount !== undefined ? s.paid_amount : (s.tendered || 0));
          rec.cash += Math.min(s.grand_total || 0, Math.max(0, down));
        }
        else rec.card += s.grand_total || 0;
      });

      const dayList = Array.from(dayAgg.values()).map(d => ({
        ...d,
        avgTicket: d.count > 0 ? Utils.round(d.revenue / d.count) : 0,
        margin: d.revenue > 0 ? Utils.round((d.profit / d.revenue) * 100) : 0
      })).sort((a, b) => b.date.localeCompare(a.date));

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'التاريخ والعمليات' : 'Date & Invoices'}</th>
            <th>${isAR ? 'عدد الفواتير' : 'Invoices'}</th>
            <th>${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
            <th>${isAR ? 'الخصومات' : 'Discounts'}</th>
            <th>${isAR ? 'الكاش' : 'Cash'}</th>
            <th>${isAR ? 'البطاقات' : 'Cards'}</th>
            <th>${isAR ? 'إجمالي التكلفة' : 'Total Cost'}</th>
            <th>${isAR ? 'صافي الربح' : 'Net Profit'}</th>
            <th>${isAR ? 'هامش الربح' : 'Margin %'}</th>
          </tr></thead>
          <tbody>
            ${dayList.length === 0
              ? `<tr><td colspan="9" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات' : 'No daily sales data'}</td></tr>`
              : dayList.map((d, idx) => `
              <tr style="cursor:pointer;transition:background 0.15s" onclick="Reports.toggleRowDetail('rep-day-${idx}')" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='transparent'">
                <td>
                  <div style="display:flex;align-items:center;gap:6px">
                    <button class="btn btn-ghost btn-sm" id="btn-rep-day-${idx}" style="padding:2px 6px;font-size:0.75rem;line-height:1;border-radius:4px" onclick="event.stopPropagation(); Reports.toggleRowDetail('rep-day-${idx}')" title="${isAR ? 'توسيع / طي فواتير اليوم' : 'Expand / Collapse daily invoices'}">▶</button>
                    <span style="font-weight:700;color:var(--primary)">📅 ${d.date}</span>
                    <span class="badge badge-secondary" style="font-size:0.65rem;padding:2px 5px">${d.count} 🧾</span>
                  </div>
                </td>
                <td style="font-weight:800">${d.count}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(d.revenue)}</td>
                <td style="color:${d.discount > 0 ? '#e11d48' : 'var(--text-muted)'};font-weight:${d.discount > 0 ? '700' : 'normal'}">${d.discount > 0 ? `-${Utils.formatMoney(d.discount)}` : '-'}</td>
                <td>${Utils.formatMoney(d.cash)}</td>
                <td>${Utils.formatMoney(d.card)}</td>
                <td style="color:var(--text-muted)">${Utils.formatMoney(d.cost)}</td>
                <td style="font-weight:800;color:${d.profit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(d.profit)}</td>
                <td><span class="badge badge-${d.margin >= 15 ? 'success' : d.margin >= 0 ? 'warning' : 'danger'}">${d.margin}%</span></td>
              </tr>
              <!-- Expandable Daily Invoices Sub-Table -->
              <tr id="rep-day-${idx}" style="display:none;background:var(--surface-2)">
                <td colspan="9" style="padding:12px 16px">
                  <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:8px;padding:12px;box-shadow:0 4px 12px rgba(0,0,0,0.1)">
                    <div style="font-weight:700;font-size:0.84rem;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border-color);padding-bottom:6px">
                      <span style="display:flex;align-items:center;gap:6px">
                        <span>🧾</span> ${isAR ? 'فواتير يوم' : 'Invoices for'} <strong style="color:var(--primary)">${d.date}</strong>
                      </span>
                      <span style="font-size:0.75rem;color:var(--text-muted)">${d.count} ${isAR ? 'فواتير مسجلة' : 'invoices recorded'}</span>
                    </div>
                    <table style="width:100%;font-size:0.78rem;border-collapse:collapse">
                      <thead>
                        <tr style="border-bottom:1px solid var(--border-color);color:var(--text-muted);text-align:left">
                          <th style="padding:6px">${isAR ? 'رقم الفاتورة' : 'Invoice Ref'}</th>
                          <th style="padding:6px">${isAR ? 'الوقت' : 'Time'}</th>
                          <th style="padding:6px">${isAR ? 'العميل' : 'Customer'}</th>
                          <th style="padding:6px">${isAR ? 'طريقة الدفع' : 'Payment'}</th>
                          <th style="padding:6px">${isAR ? 'الخصم' : 'Discount'}</th>
                          <th style="padding:6px">${isAR ? 'إجمالي المبيعات' : 'Total'}</th>
                          <th style="padding:6px">${isAR ? 'التكلفة' : 'Cost'}</th>
                          <th style="padding:6px">${isAR ? 'صافي الربح' : 'Net Profit'}</th>
                          <th style="padding:6px">${isAR ? 'الأصناف' : 'Items'}</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${d.sales.map(s => {
                          const dt = s.created_at || s.date ? new Date(s.created_at || s.date) : null;
                          const timeStr = dt && !isNaN(dt.getTime()) ? dt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }) : '';
                          const itemsSummary = (s.enriched_items || []).map(i => `${i.name || i.name_en || i.name_ar} (x${i.qty || 1})`).join(', ') || '-';
                          return `
                          <tr style="border-bottom:1px solid rgba(255,255,255,0.05)">
                            <td style="padding:6px;font-weight:700;color:var(--primary)">${s.ref || '-'}</td>
                            <td style="padding:6px;font-size:0.72rem;color:var(--text-muted)">🕒 ${timeStr || '-'}</td>
                            <td style="padding:6px">${Utils.truncate(s.customer_name || (isAR ? 'عميل نقدي' : 'Cash Customer'), 20)}</td>
                            <td style="padding:6px"><span class="badge badge-secondary">${(s.payment_method || 'cash').toUpperCase()}</span></td>
                            <td style="padding:6px;color:${(s.total_discount || 0) > 0 ? '#e11d48' : 'var(--text-muted)'};font-weight:${(s.total_discount || 0) > 0 ? '700' : 'normal'}">
                              ${(s.total_discount || 0) > 0 ? `-${Utils.formatMoney(s.total_discount)}` : '-'}
                            </td>
                            <td style="padding:6px;font-weight:800;color:var(--primary)">${Utils.formatMoney(s.grand_total || 0)}</td>
                            <td style="padding:6px;color:var(--text-muted)">${Utils.formatMoney(s.total_cost || 0)}</td>
                            <td style="padding:6px;font-weight:800;color:${(s.net_profit || 0) >= 0 ? 'var(--success)' : 'var(--danger)'}">
                              ${Utils.formatMoney(s.net_profit || 0)}
                            </td>
                            <td style="padding:6px;font-size:0.72rem;color:var(--text-secondary);max-width:200px" title="${itemsSummary}">${Utils.truncate(itemsSummary, 35)}</td>
                          </tr>`;
                        }).join('')}
                      </tbody>
                    </table>
                  </div>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      }
    } else if (tab === 'returns') {
      if (titleEl) titleEl.textContent = isAR ? 'تقرير مرتجعات المبيعات واسترجاع الأموال' : 'Sales Returns & Refunds Report';

      const returnsList = [];
      sales.forEach(s => {
        (s.enriched_items || []).forEach(ci => {
          if (ci.line_type === 'return' || (parseFloat(ci.qty) < 0)) {
            returnsList.push({
              ref: s.ref,
              date: s.created_at,
              customer: s.customer_name || '-',
              code: ci.item_code || '-',
              name: isAR ? (ci.name_ar || ci.name_en || ci.name) : (ci.name_en || ci.name_ar || ci.name),
              qty: Math.abs(parseFloat(ci.qty) || 1),
              price: parseFloat(ci.price) || 0,
              totalRefund: Math.abs(ci.item_revenue || 0)
            });
          }
        });
      });

      if (wrapper) {
        wrapper.innerHTML = `
        <table>
          <thead><tr>
            <th>${isAR ? 'رقم الفاتورة' : 'Invoice Ref'}</th>
            <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
            <th>${isAR ? 'العميل' : 'Customer'}</th>
            <th>${isAR ? 'رمز الصنف' : 'Item Code'}</th>
            <th>${isAR ? 'اسم الصنف المرتجع' : 'Returned Item'}</th>
            <th>${isAR ? 'الكمية' : 'Qty'}</th>
            <th>${isAR ? 'سعر البيع' : 'Price'}</th>
            <th>${isAR ? 'إجمالي المسترجع' : 'Refund Amount'}</th>
          </tr></thead>
          <tbody>
            ${returnsList.length === 0
              ? `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد مرتجعات في الفترة المحددة' : 'No sales returns found in this date range'}</td></tr>`
              : returnsList.map(r => `
              <tr>
                <td style="font-weight:700;color:var(--danger)">${r.ref}</td>
                <td style="font-size:0.8rem">${Utils.formatDateTime(r.date)}</td>
                <td>${r.customer}</td>
                <td style="font-weight:700;font-size:0.78rem">${r.code}</td>
                <td style="font-weight:600">${r.name}</td>
                <td style="font-weight:800;color:var(--danger)">${r.qty}</td>
                <td>${Utils.formatMoney(r.price)}</td>
                <td style="font-weight:800;color:var(--danger)">${Utils.formatMoney(r.totalRefund)}</td>
              </tr>`).join('')}
          </tbody>
        </table>`;
      }
    }
  }

  async function printSalesReport() {
    const isAR = i18n.getLang() === 'ar';
    const wrapper = document.getElementById('rep-table-wrapper');
    const comp = await DB.getSetting('company_name', 'Store');
    const logo = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    Utils.printElement(`
    <div class="doc-a4" dir="${isAR ? 'rtl' : 'ltr'}" style="font-family:'Cairo','Inter',sans-serif;padding:20px">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #333;padding-bottom:12px;margin-bottom:20px">
        <div class="doc-company-info" style="display:flex;align-items:center;gap:12px">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain">` : ''}
          <h2 style="margin:0">${Utils.sanitize(comp)}</h2>
        </div>
        <div class="doc-title-block" style="text-align:${isAR?'left':'right'}"><h1 style="font-size:1.4rem;margin:0 0 4px">${isAR ? 'تقرير المبيعات والأرباح' : 'Sales & Profit Report'}</h1><div class="doc-date" style="color:#666">${Utils.formatDate(Utils.today())}</div></div>
      </div>
      ${wrapper?.innerHTML || ''}
    </div>`, 'Sales Report');
  }

  function exportSalesReport() {
    const sales = window._enrichedSales || [];
    Utils.exportCSV(sales.map(s => ({
      Ref: s.ref,
      Date: s.created_at,
      Customer: s.customer_name,
      PaymentMethod: s.payment_method,
      TotalSales: s.grand_total,
      TotalCost: s.total_cost,
      NetProfit: s.net_profit,
      MarginPct: `${s.margin_pct}%`
    })), 'sales_and_profit_report');
  }

  // ── Stock Report ──────────────────────────────────────────────
  let _stockActiveTab = 'levels';
  let _lastStockContainer = null;

  function switchStockTab(tab) {
    _stockActiveTab = tab;
    const content = _lastStockContainer || document.getElementById('master-report-render-target') || document.getElementById('page-content');
    renderStockReport(content, tab);
  }

  async function loadStockMovementLedger() {
    const isAR = i18n.getLang() === 'ar';
    const movements = await DB.getAll('stock_movements');
    const items = await DB.getAll('items');
    const cats = await DB.getAll('categories');
    
    const itemMap = new Map(items.map(i => [i.id, i]));
    const catMap = new Map(cats.map(c => [c.id, c]));
    
    // Gather filter inputs
    const fromDate = document.getElementById('st-mov-from')?.value;
    const toDate = document.getElementById('st-mov-to')?.value;
    const filterCatId = document.getElementById('st-mov-cat')?.value;
    const filterItemId = document.getElementById('st-mov-item')?.value;
    
    let filtered = [];
    
    let kpiMovements = 0;
    let kpiRevenue = 0;
    let kpiCOGS = 0;
    let kpiProfit = 0;
    
    for (const m of movements) {
      const itm = itemMap.get(m.item_id);
      if (!itm) continue;
      
      const cat = catMap.get(itm.category_id);
      
      // Category filter
      if (filterCatId && String(itm.category_id) !== String(filterCatId)) continue;
      
      // Item filter
      if (filterItemId && String(m.item_id) !== String(filterItemId)) continue;
      
      // Date filter
      const date = (m.created_at || '').slice(0, 10);
      if (fromDate && date < fromDate) continue;
      if (toDate && date > toDate) continue;
      
      const cost = parseFloat(itm.cost_price) || 0;
      const price = parseFloat(itm.selling_price || itm.price) || 0;
      const qty = parseFloat(m.qty) || 0;
      
      let revenue = 0;
      let profit = 0;
      let cogs = 0;
      
      // Profit logic based on movement type
      if (m.type === 'sale') {
        revenue = Math.abs(qty) * price;
        cogs = Math.abs(qty) * cost;
        profit = revenue - cogs;
        
        kpiRevenue += revenue;
        kpiCOGS += cogs;
        kpiProfit += profit;
      } else if (m.type === 'damage' || m.type === 'adj_out') {
        profit = -Math.abs(qty) * cost;
        kpiProfit += profit;
      } else if (m.type === 'return') {
        revenue = -qty * price;
        cogs = -qty * cost;
        profit = revenue - cogs;
        
        kpiRevenue += revenue;
        kpiCOGS += cogs;
        kpiProfit += profit;
      }
      
      kpiMovements++;
      
      filtered.push({
        ...m,
        item: itm,
        categoryName: cat ? (isAR ? (cat.name_ar || cat.name) : (cat.name || cat.name_ar)) : (isAR ? 'غير مصنف' : 'Uncategorized'),
        cost,
        price,
        revenue,
        profit
      });
    }
    
    // Sort reverse chronological
    filtered.sort((a,b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    
    // Update KPI UI
    const kpiEl = document.getElementById('st-mov-kpis');
    if (kpiEl) {
      kpiEl.innerHTML = `
      ${kpiCard(isAR?'إجمالي الحركات':'Total Movements', kpiMovements, 'primary', '🔄', false)}
      ${kpiCard(isAR?'إجمالي الإيرادات':'Sales Revenue', kpiRevenue, 'success', '💰')}
      ${kpiCard(isAR?'إجمالي التكلفة':'Cost of Goods', kpiCOGS, 'warning', '📉')}
      ${kpiCard(isAR?'صافي الربح / الخسارة':'Net Profit / Loss', kpiProfit, kpiProfit >= 0 ? 'success' : 'danger', '📊')}
      `;
    }
    
    // Update Table UI
    const bodyEl = document.getElementById('st-mov-table-body');
    if (bodyEl) {
      bodyEl.innerHTML = filtered.map(m => {
        const dateStr = Utils.formatDate(m.created_at);
        const name = isAR ? (m.item.name_ar || m.item.name_en) : (m.item.name_en || m.item.name_ar);
        const profitColor = m.profit > 0 ? 'var(--success)' : (m.profit < 0 ? 'var(--danger)' : 'var(--text-secondary)');
        const profitText = m.profit !== 0 ? Utils.formatMoney(m.profit) : '-';
        const qtyColor = m.qty > 0 ? 'var(--success)' : 'var(--danger)';
        const typeBadge = m.type === 'sale' ? 'success' : (m.type === 'purchase' ? 'primary' : (m.type === 'return' ? 'warning' : 'danger'));
        
        return `
        <tr>
          <td style="font-size:0.78rem">${dateStr}</td>
          <td>
            <div style="font-weight:600">${Utils.sanitize(name)}</div>
            <div style="font-size:0.7rem;color:var(--text-muted)">${m.item.item_code}</div>
          </td>
          <td>${Utils.sanitize(m.categoryName)}</td>
          <td><span class="badge badge-${typeBadge}">${m.type.toUpperCase()}</span></td>
          <td style="font-weight:600">${m.ref || '-'}</td>
          <td style="font-weight:700;color:${qtyColor}">${m.qty > 0 ? '+' : ''}${m.qty}</td>
          <td>${Utils.formatMoney(m.cost)}</td>
          <td>${m.type === 'sale' || m.type === 'return' ? Utils.formatMoney(m.price) : '-'}</td>
          <td style="font-weight:700;color:${profitColor}">${profitText}</td>
          <td style="font-size:0.75rem;color:var(--text-muted)">${m.notes || '-'}</td>
        </tr>`;
      }).join('') || `<tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد حركات مخزن مطابقة' : 'No matching stock movements found'}</td></tr>`;
    }
  }

  async function renderStockReport(container, defaultTab) {
    if (!container) container = document.getElementById('page-content');
    _lastStockContainer = container;
    if (defaultTab) _stockActiveTab = defaultTab;
    const items = await DB.getAll('items');
    const cats  = await DB.getAll('categories');
    const isAR  = i18n.getLang() === 'ar';

    window._itemsForReport = items;
    window._catsForReport  = cats;

    let tabControls = `
      <div style="display:flex;gap:8px;margin-bottom:16px;border-bottom:2px solid var(--border-color);padding-bottom:10px;flex-wrap:wrap">
        <button class="btn btn-${_stockActiveTab === 'levels' ? 'primary' : 'secondary'}" id="stock-tab-levels" onclick="Reports.switchStockTab('levels')">
          📦 ${isAR ? 'مستويات المخزون الحالي' : 'Stock Levels'}
        </button>
        <button class="btn btn-${_stockActiveTab === 'low_stock' ? 'primary' : 'secondary'}" id="stock-tab-low_stock" onclick="Reports.switchStockTab('low_stock')">
          ⚠️ ${isAR ? 'النواقص والمنخفض' : 'Low & Out of Stock'}
        </button>
        <button class="btn btn-${_stockActiveTab === 'movement' ? 'primary' : 'secondary'}" id="stock-tab-movement" onclick="Reports.switchStockTab('movement')">
          🔄 ${isAR ? 'حركة المخزون والأرباح' : 'Stock Movement & Profit'}
        </button>
        <button class="btn btn-${_stockActiveTab === 'valuation' ? 'primary' : 'secondary'}" id="stock-tab-valuation" onclick="Reports.switchStockTab('valuation')">
          💰 ${isAR ? 'تقييم المخزون المالي' : 'Stock Valuation'}
        </button>
      </div>
    `;

    if (_stockActiveTab === 'levels' || _stockActiveTab === 'low_stock' || _stockActiveTab === 'valuation') {
      const totalValue = items.reduce((s,i) => s+((parseFloat(i.stock_qty)||0)*(parseFloat(i.cost_price)||0)), 0);
      const totalSellingVal = items.reduce((s,i) => {
        const p = parseFloat(i.selling_price ?? i.price ?? 0) || 0;
        return s + ((parseFloat(i.stock_qty)||0) * p);
      }, 0);
      const lowStock   = items.filter(i => (parseFloat(i.stock_qty)||0) <= (parseFloat(i.min_qty)||0));
      const outStock   = items.filter(i => (parseFloat(i.stock_qty)||0) === 0);

      let displayItems = items;
      if (_stockActiveTab === 'low_stock') {
        displayItems = lowStock;
      }

      const isEmbedded = (container && container.id === 'master-report-render-target');

      container.innerHTML = `
      <div class="animate-slide">
        ${!isEmbedded ? `
        <div class="page-header">
          <div class="page-header-left" style="display:flex;align-items:center;gap:12px">
            <button class="btn btn-ghost btn-sm" onclick="Reports.render(document.getElementById('page-content'))" style="font-weight:700">← ${isAR ? 'مركز التقارير' : 'Reports Hub'}</button>
            <div>
              <h1>📦 ${isAR ? 'تقارير المخزون وحركة البضاعة' : 'Inventory & Stock Reports'}</h1>
              <p>${isAR ? 'مستويات المخزون، النواقص، التقييم المالي، وحركة البضاعة' : 'Stock on hand, reorder alerts, inventory valuation & ledger'}</p>
            </div>
          </div>
          <div class="page-actions">
            <button class="btn btn-secondary" onclick="Reports.printStockReport()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
              ${isAR ? 'طباعة' : 'Print'}
            </button>
            <button class="btn btn-primary" onclick="Reports.exportStockReport()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              ${isAR ? 'تصدير' : 'Export'}
            </button>
          </div>
        </div>
        ` : ''}

        ${tabControls}

        <div class="grid grid-4 mb-4">
          ${kpiCard(isAR?'إجمالي الأصناف':'Total Items', items.length, 'primary', '📦', false)}
          ${kpiCard(isAR?'قيمة المخزون بالتكلفة':'Stock Value (Cost)', totalValue, 'success', '💰')}
          ${kpiCard(isAR?'القيمة بسعر البيع':'Stock Value (Retail)', totalSellingVal, 'primary', '💵')}
          ${kpiCard(isAR?'أصناف منخفضة ونافدة':'Low / Out of Stock', lowStock.length, lowStock.length > 0 ? 'danger' : 'success', '⚠️', false)}
        </div>

        <div class="card">
          <div class="card-header">
            <div class="card-title">${_stockActiveTab === 'low_stock' ? (isAR ? 'الأصناف المنخفضة والنافدة التي تحتاج إعادة طلب' : 'Low & Out of Stock Items (Reorder Required)') : _stockActiveTab === 'valuation' ? (isAR ? 'التقييم المالي الشامل للمخزون' : 'Inventory Financial Valuation') : (isAR?'مستوى المخزون الحالي':'Stock Levels')}</div>
          </div>
          <div class="table-wrapper" id="stock-report-table">
            <table>
              <thead><tr>
                <th>${isAR?'الرمز':'Code'}</th>
                <th>${isAR?'الصنف':'Item'}</th>
                <th>${isAR?'التصنيف':'Category'}</th>
                <th>${isAR?'المخزون':'Stock'}</th>
                <th>${isAR?'سعر التكلفة':'Cost'}</th>
                <th>${isAR?'سعر البيع':'Price'}</th>
                <th>${isAR?'إجمالي التكلفة':'Cost Val'}</th>
                <th>${isAR?'إجمالي البيع':'Retail Val'}</th>
                <th>${isAR?'الحالة':'Status'}</th>
              </tr></thead>
              <tbody>
                ${displayItems.map(i => {
                  const cat  = cats.find(c => c.id === i.category_id);
                  const name = isAR ? (i.name_ar||i.name_en) : (i.name_en||i.name_ar);
                  const catName = cat ? (isAR?(cat.name_ar||cat.name):(cat.name||cat.name_ar)) : '-';
                  const qty  = parseFloat(i.stock_qty) || 0;
                  const displayQty = (i.is_scale || qty % 1 !== 0) ? Utils.round(qty, 3) : qty;
                  const min  = parseFloat(i.min_qty) || 0;
                  const costPrice = parseFloat(i.cost_price) || 0;
                  const sellPrice = parseFloat(i.selling_price ?? i.price ?? 0) || 0;
                  const costVal = Utils.round(qty * costPrice);
                  const sellVal = Utils.round(qty * sellPrice);
                  const isLow  = qty <= min && qty > 0;
                  const isOut  = qty === 0;
                  return `<tr>
                    <td style="font-weight:700;color:var(--primary);font-size:0.78rem">${i.item_code||'-'}</td>
                    <td style="font-weight:600;font-size:0.82rem">${Utils.truncate(name,30)}</td>
                    <td style="font-size:0.78rem">${catName}</td>
                    <td style="font-weight:800;color:${isOut?'var(--danger)':isLow?'var(--warning)':'var(--success)'}">
                      ${displayQty}
                      ${isLow && !isOut ? `<span style="color:var(--warning);font-size:0.7rem;margin-left:4px">⚠️</span>` : ''}
                    </td>
                    <td>${Utils.formatMoney(costPrice)}</td>
                    <td>${Utils.formatMoney(sellPrice)}</td>
                    <td style="font-weight:700">${Utils.formatMoney(costVal)}</td>
                    <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(sellVal)}</td>
                    <td>
                      <span class="badge badge-${isOut?'danger':isLow?'warning':'success'}">
                        ${isOut?(isAR?'نفد':'Out'):isLow?(isAR?'منخفض':'Low'):(isAR?'متوفر':'OK')}
                      </span>
                    </td>
                  </tr>`;
                }).join('')}
              </tbody>
              <tfoot>
                <tr style="font-weight:900;background:var(--surface-2)">
                  <td colspan="6">${isAR?'الإجمالي':'Total'}</td>
                  <td>${Utils.formatMoney(totalValue)}</td>
                  <td colspan="2" style="color:var(--primary)">${Utils.formatMoney(totalSellingVal)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>`;
    } else {
      const isEmbedded = (container && container.id === 'master-report-render-target');
      container.innerHTML = `
      <div class="animate-slide">
        ${!isEmbedded ? `
        <div class="page-header">
          <div class="page-header-left">
            <h1>${isAR ? 'حركة المخزون والأرباح' : 'Stock Movement Report'}</h1>
          </div>
        </div>
        ` : ''}

        ${tabControls}

        <!-- Movement Filters -->
        <div class="card mb-4">
          <div class="card-header"><div class="card-title">${isAR ? 'تصفية حركة المخزون' : 'Filter Stock Movement'}</div></div>
          <div class="modal-body">
            <div class="grid grid-4" style="gap:12px">
              <div class="form-group">
                <label class="form-label">${isAR ? 'من تاريخ' : 'From Date'}</label>
                <input type="date" class="form-control" id="st-mov-from">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR ? 'إلى تاريخ' : 'To Date'}</label>
                <input type="date" class="form-control" id="st-mov-to">
              </div>
              <div class="form-group">
                <label class="form-label">${isAR ? 'التصنيف' : 'Category'}</label>
                <select class="form-control" id="st-mov-cat">
                  <option value="">-- ${isAR ? 'الكل' : 'All'} --</option>
                  ${cats.map(c => `<option value="${c.id}">${isAR ? (c.name_ar||c.name) : (c.name||c.name_ar)}</option>`).join('')}
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">${isAR ? 'الصنف' : 'Item'}</label>
                <select class="form-control" id="st-mov-item">
                  <option value="">-- ${isAR ? 'الكل' : 'All'} --</option>
                  ${items.map(i => `<option value="${i.id}">[${i.item_code||''}] ${isAR ? (i.name_ar||i.name_en) : (i.name_en||i.name_ar)}</option>`).join('')}
                </select>
              </div>
            </div>
            <div style="display:flex;justify-content:flex-end;margin-top:12px">
              <button class="btn btn-primary" onclick="Reports.loadStockMovementLedger()">${isAR ? 'تطبيق التصفية' : 'Apply Filter'}</button>
            </div>
          </div>
        </div>

        <!-- Dynamic Movement KPIs -->
        <div class="grid grid-4 mb-4" id="st-mov-kpis">
          <!-- populated dynamically -->
        </div>

        <!-- Movement Ledger Card -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">${isAR ? 'دفتر حركة المخازن والأرباح' : 'Stock Movement & Profit Ledger'}</div>
          </div>
          <div class="table-wrapper">
            <table>
              <thead><tr>
                <th>${isAR?'التاريخ':'Date'}</th>
                <th>${isAR?'الصنف':'Item'}</th>
                <th>${isAR?'التصنيف':'Category'}</th>
                <th>${isAR?'الحركة':'Type'}</th>
                <th>${isAR?'المستند':'Ref'}</th>
                <th>${isAR?'الكمية':'Qty'}</th>
                <th>${isAR?'التكلفة':'Cost'}</th>
                <th>${isAR?'سعر البيع':'Sale Price'}</th>
                <th>${isAR?'الربح / الخسارة':'Profit/Loss'}</th>
                <th>${isAR?'تفاصيل':'Notes'}</th>
              </tr></thead>
              <tbody id="st-mov-table-body">
                <!-- populated dynamically -->
              </tbody>
            </table>
          </div>
        </div>
      </div>`;
      
      loadStockMovementLedger();
    }

    window._itemsForReport = items;
    window._catsForReport  = cats;
  }

  async function printStockReport() {
    const isAR = i18n.getLang() === 'ar';
    const tbody = document.querySelector('#stock-report-table table');
    const comp = await DB.getSetting('company_name', 'Store');
    const logo = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    Utils.printElement(`
    <div class="doc-a4" dir="${isAR?'rtl':'ltr'}" style="font-family:'Cairo','Inter',sans-serif;padding:20px">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #333;padding-bottom:12px;margin-bottom:20px">
        <div class="doc-company-info" style="display:flex;align-items:center;gap:12px">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain">` : ''}
          <h2 style="margin:0">${Utils.sanitize(comp)}</h2>
        </div>
        <div class="doc-title-block" style="text-align:${isAR?'left':'right'}"><h1 style="font-size:1.4rem;margin:0 0 4px">${isAR?'تقرير المخزون':'Stock Report'}</h1><div class="doc-date" style="color:#666">${Utils.formatDate(Utils.today())}</div></div>
      </div>
      ${tbody?.outerHTML||''}
    </div>`, 'Stock Report');
  }

  function exportStockReport() {
    const items = window._itemsForReport || [];
    const cats  = window._catsForReport  || [];
    Utils.exportCSV(items.map(i => {
      const cat = cats.find(c => c.id === i.category_id);
      const qty = parseFloat(i.stock_qty) || 0;
      const displayQty = (i.is_scale || qty % 1 !== 0) ? Utils.round(qty, 3) : qty;
      const cost = parseFloat(i.cost_price) || 0;
      const price = parseFloat(i.selling_price ?? i.price ?? 0) || 0;
      return { 
        Code: i.item_code, 
        Name: i.name_en || i.name_ar, 
        Category: cat?.name || cat?.name_ar || '-', 
        Stock: displayQty, 
        Min: i.min_qty || 0, 
        Cost: cost, 
        Price: price,
        CostValue: Utils.round(qty * cost),
        RetailValue: Utils.round(qty * price)
      };
    }), 'stock_report');
  }

  // ── Financial Reports Suite (P&L, Trial Balance, Balance Sheet, Cash Flow, VAT, Expenses) ──
  let _activeFinTab = 'pl';

  async function renderPLReport(container, defaultTab) {
    return renderFinanceReport(container, defaultTab || 'pl');
  }

  async function renderFinanceReport(container, defaultTab) {
    if (!container) container = document.getElementById('page-content');
    if (defaultTab) _activeFinTab = defaultTab;
    const isAR = i18n.getLang() === 'ar';
    const today = Utils.today();
    const firstDayOfYear = `${new Date().getFullYear()}-01-01`;
    const isEmbedded = (container && container.id === 'master-report-render-target');

    container.innerHTML = `
    <div class="animate-slide">
      ${!isEmbedded ? `
      <div class="page-header" style="margin-bottom:14px">
        <div class="page-header-left" style="display:flex;align-items:center;gap:12px">
          <button class="btn btn-ghost btn-sm" onclick="Reports.render(document.getElementById('page-content'))" style="font-weight:700">← ${isAR ? 'مركز التقارير' : 'Reports Hub'}</button>
          <div>
            <h1>💰 ${isAR ? 'التقارير والقوائم المالية الشاملة' : 'Financial Statements & Reports'}</h1>
            <p>${isAR ? 'بيان الأرباح والخسائر، ميزان المراجعة، الميزانية العمومية، التدفقات النقدية، الضريبة، والمصروفات' : 'Income Statement (P&L), Trial Balance, Balance Sheet, Cash Flow, VAT & Expense Audit'}</p>
          </div>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printFinanceReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportFinanceReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>
      ` : ''}

      <!-- Financial Sub Tabs -->
      <div style="display:flex;gap:8px;margin-bottom:16px;border-bottom:2px solid var(--border-color);padding-bottom:10px;flex-wrap:wrap">
        <button class="btn ${_activeFinTab === 'pl' ? 'btn-primary' : 'btn-secondary'}" id="fintab-pl" onclick="Reports.switchFinTab('pl')">
          📑 ${isAR ? 'الأرباح والخسائر (P&L)' : 'P&L Statement'}
        </button>
        <button class="btn ${_activeFinTab === 'trial_balance' ? 'btn-primary' : 'btn-secondary'}" id="fintab-trial_balance" onclick="Reports.switchFinTab('trial_balance')">
          ⚖️ ${isAR ? 'ميزان المراجعة' : 'Trial Balance'}
        </button>
        <button class="btn ${_activeFinTab === 'balance_sheet' ? 'btn-primary' : 'btn-secondary'}" id="fintab-balance_sheet" onclick="Reports.switchFinTab('balance_sheet')">
          🏛️ ${isAR ? 'الميزانية العمومية' : 'Balance Sheet'}
        </button>
        <button class="btn ${_activeFinTab === 'cash_flow' ? 'btn-primary' : 'btn-secondary'}" id="fintab-cash_flow" onclick="Reports.switchFinTab('cash_flow')">
          💵 ${isAR ? 'التدفقات النقدية' : 'Cash Flow'}
        </button>
        <button class="btn ${_activeFinTab === 'vat' ? 'btn-primary' : 'btn-secondary'}" id="fintab-vat" onclick="Reports.switchFinTab('vat')">
          ⚖️ ${isAR ? 'إقرار الضريبة (VAT)' : 'VAT Report'}
        </button>
        <button class="btn ${_activeFinTab === 'expenses' ? 'btn-primary' : 'btn-secondary'}" id="fintab-expenses" onclick="Reports.switchFinTab('expenses')">
          📉 ${isAR ? 'تحليل المصروفات' : 'Expenses Breakdown'}
        </button>
      </div>

      <!-- Date Range Filter -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
              <div class="form-group" style="margin-bottom:0">
                <label class="form-label" style="margin-bottom:2px;font-size:0.75rem">${isAR ? 'من تاريخ' : 'From'}</label>
                <input type="date" id="fin-rep-from" class="form-control" style="height:36px" value="${firstDayOfYear}">
              </div>
              <div class="form-group" style="margin-bottom:0">
                <label class="form-label" style="margin-bottom:2px;font-size:0.75rem">${isAR ? 'إلى تاريخ' : 'To'}</label>
                <input type="date" id="fin-rep-to" class="form-control" style="height:36px" value="${today}">
              </div>
              <div style="display:flex;align-items:flex-end">
                <button class="btn btn-primary" onclick="Reports.loadFinData()" style="height:36px;font-weight:700">
                  🔍 ${isAR ? 'تطبيق التصفية' : 'Apply Filter'}
                </button>
              </div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button class="btn btn-ghost btn-sm" onclick="Reports.setFinPreset('this_month')">${isAR ? 'هذا الشهر' : 'This Month'}</button>
              <button class="btn btn-ghost btn-sm" onclick="Reports.setFinPreset('last_month')">${isAR ? 'الشهر الماضي' : 'Last Month'}</button>
              <button class="btn btn-ghost btn-sm" onclick="Reports.setFinPreset('this_year')">${isAR ? 'هذه السنة' : 'This Year'}</button>
              <button class="btn btn-ghost btn-sm" onclick="Reports.setFinPreset('all')">${isAR ? 'الكل' : 'All Time'}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Live Dynamic Financial Content -->
      <div id="fin-report-target"></div>
    </div>`;

    await loadFinData();
  }

  function switchFinTab(tab) {
    _activeFinTab = tab;
    ['pl', 'trial_balance', 'balance_sheet', 'cash_flow', 'vat', 'expenses'].forEach(t => {
      const btn = document.getElementById(`fintab-${t}`);
      if (btn) {
        btn.className = `btn ${t === tab ? 'btn-primary' : 'btn-secondary'}`;
      }
    });
    // Sync combobox 2 if present
    const subSelect = document.getElementById('master-rep-sub');
    const typeSelect = document.getElementById('master-rep-type');
    if (subSelect && typeSelect && (typeSelect.value === 'finance' || typeSelect.value === 'pl')) {
      subSelect.value = tab;
      _selectedMasterSub = tab;
    }
    loadFinData();
  }

  function setFinPreset(preset) {
    const today = Utils.today();
    const fromEl = document.getElementById('fin-rep-from');
    const toEl = document.getElementById('fin-rep-to');
    if (!fromEl || !toEl) return;

    if (preset === 'this_month') {
      fromEl.value = `${today.slice(0, 7)}-01`;
      toEl.value = today;
    } else if (preset === 'last_month') {
      const dt = new Date();
      dt.setMonth(dt.getMonth() - 1);
      const lm = dt.toISOString().slice(0, 7);
      fromEl.value = `${lm}-01`;
      const lastDay = new Date(dt.getFullYear(), dt.getMonth() + 1, 0).getDate();
      toEl.value = `${lm}-${String(lastDay).padStart(2, '0')}`;
    } else if (preset === 'this_year') {
      fromEl.value = `${today.slice(0, 4)}-01-01`;
      toEl.value = today;
    } else if (preset === 'all') {
      fromEl.value = '2020-01-01';
      toEl.value = today;
    }
    loadFinData();
  }

  async function loadFinData() {
    const target = document.getElementById('fin-report-target');
    if (!target) return;
    const isAR = i18n.getLang() === 'ar';
    const from = document.getElementById('fin-rep-from')?.value || '2020-01-01';
    const to = document.getElementById('fin-rep-to')?.value || Utils.today();

    target.innerHTML = `<div style="text-align:center;padding:35px;color:var(--text-muted);font-weight:700">⏳ ${isAR ? 'جاري احتساب البيانات المالية...' : 'Calculating financial metrics...'}</div>`;

    // Fetch required datasets
    const posSales = (await DB.getAll('sales')) || [];
    const salesInvoices = (await DB.getAll('sales_invoice')) || [];
    const salesReturns = (await DB.getAll('sales_return')) || [];
    const purchaseInvoices = (await DB.getAll('purchase_invoices')) || [];
    const cashTxns = (await DB.getAll('cash_transactions')) || [];
    const bankTxns = (await DB.getAll('bank_transactions')) || [];
    const accounts = (await DB.getAll('accounts')) || [];
    const customers = (await DB.getAll('customers')) || [];
    const suppliers = (await DB.getAll('suppliers')) || [];
    const items = (await DB.getAll('items')) || [];

    // Filter within Date Range
    function inRange(d) {
      if (!d) return false;
      const dateStr = String(d).slice(0, 10);
      return dateStr >= from && dateStr <= to;
    }

    const filteredPos = posSales.filter(s => inRange(s.created_at || s.date) && s.status !== 'cancelled');
    const filteredInv = salesInvoices.filter(i => inRange(i.created_at || i.doc_date) && i.status !== 'cancelled' && i.status !== 'draft');
    const filteredRet = salesReturns.filter(r => inRange(r.created_at || r.doc_date) && r.status !== 'cancelled');
    const filteredPurchases = purchaseInvoices.filter(p => inRange(p.created_at || p.doc_date) && p.status !== 'cancelled' && p.status !== 'draft');
    const filteredCash = cashTxns.filter(t => inRange(t.date || t.created_at));
    const filteredBank = bankTxns.filter(t => inRange(t.date || t.created_at));

    // Calculate Sales Revenue safely
    let posRev = 0;
    let posCogs = 0;
    filteredPos.forEach(s => {
      posRev += (parseFloat(s.grand_total) || 0);
      let sItems = [];
      try {
        sItems = typeof s.items === 'string' ? JSON.parse(s.items) : (Array.isArray(s.items) ? s.items : []);
      } catch (e) { sItems = []; }
      sItems.forEach(it => {
        posCogs += (parseFloat(it.qty) || 0) * (parseFloat(it.cost_price) || 0);
      });
    });

    let invRev = 0;
    let invCogs = 0;
    filteredInv.forEach(i => {
      invRev += (parseFloat(i.base_grand_total !== undefined ? i.base_grand_total : i.grand_total) || 0);
      let iLines = [];
      try {
        iLines = typeof i.items_json === 'string' ? JSON.parse(i.items_json) : (Array.isArray(i.items) ? i.items : []);
      } catch (e) { iLines = []; }
      iLines.forEach(l => {
        invCogs += (parseFloat(l.qty) || 0) * (parseFloat(l.cost_price || l.cost) || 0);
      });
    });

    let retVal = 0;
    filteredRet.forEach(r => {
      retVal += (parseFloat(r.base_grand_total !== undefined ? r.base_grand_total : r.grand_total) || 0);
    });

    const grossSales = Utils.round(posRev + invRev);
    const netRevenue = Utils.round(grossSales - retVal);
    const totalCogs = Utils.round(posCogs + invCogs);
    const grossProfit = Utils.round(netRevenue - totalCogs);
    const grossMarginPct = netRevenue > 0 ? Utils.round((grossProfit / netRevenue) * 100) : 0;

    // Calculate Operating Expenses (cash + bank expenses, excluding supplier invoices already counted in purchases)
    const expenseTxns = [];
    filteredCash.forEach(t => {
      if (t.type === 'expense' && !t.supplier_id) {
        expenseTxns.push({
          date: t.date || t.created_at,
          ref: t.ref || `EXP-${t.id}`,
          category: t.category || (isAR ? 'مصروفات عامة' : 'General Expense'),
          amount: parseFloat(t.amount) || 0,
          description: t.notes || t.description || '-',
          method: isAR ? 'صندوق (كاش)' : 'Cash'
        });
      }
    });

    filteredBank.forEach(t => {
      if ((t.type === 'expense' || t.type === 'payment') && !t.supplier_id) {
        expenseTxns.push({
          date: t.date || t.created_at,
          ref: t.ref || `BNK-${t.id}`,
          category: t.category || (isAR ? 'مصاريف بنكية / عامة' : 'Bank / Operating Expense'),
          amount: parseFloat(t.amount) || 0,
          description: t.description || t.notes || '-',
          method: isAR ? 'تحويل / شيك' : 'Bank'
        });
      }
    });

    const totalExpenses = Utils.round(expenseTxns.reduce((s, e) => s + e.amount, 0));
    const netOperatingProfit = Utils.round(grossProfit - totalExpenses);
    const netMarginPct = netRevenue > 0 ? Utils.round((netOperatingProfit / netRevenue) * 100) : 0;

    // Group expenses by category
    const expenseCatMap = {};
    expenseTxns.forEach(e => {
      expenseCatMap[e.category] = (expenseCatMap[e.category] || 0) + e.amount;
    });

    window._finData = {
      grossSales, netRevenue, retVal, totalCogs, grossProfit, grossMarginPct,
      totalExpenses, netOperatingProfit, netMarginPct, expenseTxns, expenseCatMap,
      from, to
    };

    // ── Render specific tab content ──
    if (_activeFinTab === 'pl') {
      target.innerHTML = `
      <!-- P&L KPI Cards -->
      <div class="grid grid-5 mb-4" style="gap:12px">
        ${kpiCard(isAR ? 'صافي المبيعات' : 'Net Revenue', netRevenue, 'primary', '📈')}
        ${kpiCard(isAR ? 'تكلفة البضاعة (COGS)' : 'Cost of Goods', totalCogs, 'danger', '📦')}
        ${kpiCard(isAR ? 'إجمالي الربح' : 'Gross Profit', grossProfit, grossProfit >= 0 ? 'success' : 'danger', '💰')}
        ${kpiCard(isAR ? 'المصروفات التشغيلية' : 'Operating Expenses', totalExpenses, 'warning', '📉')}
        ${kpiCard(isAR ? 'صافي الربح التشغيلي' : 'Net Operating Profit', netOperatingProfit, netOperatingProfit >= 0 ? 'success' : 'danger', '🏆', false, '', true)}
      </div>

      <div class="grid grid-2" style="gap:16px">
        <!-- Income Statement Breakdown -->
        <div class="card">
          <div class="card-header" style="border-bottom:1px solid var(--border-color);padding-bottom:10px">
            <div class="card-title" style="font-size:1rem;font-weight:800">📋 ${isAR ? 'قائمة الدخل وبيان الأرباح والخسائر الشامل' : 'Income Statement Breakdown'}</div>
          </div>
          <div style="padding:14px">
            ${finRow(isAR ? 'إجمالي مبيعات نقاط البيع (POS)' : 'POS Retail Sales', posRev, 'primary')}
            ${finRow(isAR ? 'إجمالي فواتير المبيعات (Invoices)' : 'Sales Invoices Revenue', invRev, 'primary')}
            ${finRow(isAR ? '(-) مرتجعات المبيعات' : '(-) Sales Returns', -retVal, 'danger')}
            <div style="border-top:1.5px dashed var(--border-color);margin:6px 0"></div>
            ${finRow(isAR ? 'صافي الإيرادات التشغيلية' : 'Net Operating Revenue', netRevenue, 'primary', true)}
            ${finRow(isAR ? '(-) تكلفة البضاعة المباعة (COGS)' : '(-) Cost of Goods Sold', -totalCogs, 'danger')}
            <div style="border-top:2px solid var(--border-color);margin:6px 0"></div>
            ${finRow(isAR ? 'إجمالي الربح التجاري (Gross Profit)' : 'Gross Profit', grossProfit, grossProfit >= 0 ? 'success' : 'danger', true)}
            <div style="display:flex;justify-content:space-between;font-size:0.8rem;color:var(--text-muted);padding:2px 0">
              <span>${isAR ? 'هامش الربح الإجمالي:' : 'Gross Profit Margin:'}</span>
              <span style="font-weight:700">${grossMarginPct}%</span>
            </div>

            <div style="margin-top:14px;border-top:1.5px solid var(--border-color);padding-top:10px">
              <div style="font-weight:800;font-size:0.88rem;color:var(--text-secondary);margin-bottom:8px">📉 ${isAR ? 'المصروفات التشغيلية المخصومة:' : 'Operating Expenses Deducted:'}</div>
              ${Object.entries(expenseCatMap).map(([cat, amt]) => `
                <div style="display:flex;justify-content:space-between;padding:4px 0;font-size:0.84rem">
                  <span>• ${Utils.sanitize(cat)}</span>
                  <span style="color:var(--danger);font-weight:600">-${Utils.formatMoney(amt)}</span>
                </div>
              `).join('') || `<div style="font-size:0.8rem;color:var(--text-muted)">${isAR ? 'لا توجد مصروفات مسجلة بالفترة' : 'No expenses recorded in period'}</div>`}
              <div style="border-top:1.5px dashed var(--border-color);margin:6px 0"></div>
              ${finRow(isAR ? 'إجمالي المصروفات' : 'Total Operating Expenses', -totalExpenses, 'danger', true)}
            </div>

            <div style="margin-top:16px;background:var(--surface-2);border-radius:10px;padding:12px;border:1.5px solid ${netOperatingProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="font-size:1.05rem;font-weight:900">${isAR ? 'صافي الربح / (الخسارة) النهائي:' : 'Net Final Profit / (Loss):'}</span>
                <span style="font-size:1.3rem;font-weight:900;color:${netOperatingProfit >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(netOperatingProfit)}</span>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:0.8rem;color:var(--text-secondary);margin-top:4px">
                <span>${isAR ? 'صافي هامش الربح التشغيلي:' : 'Net Operating Profit Margin:'}</span>
                <span style="font-weight:800;color:${netMarginPct >= 0 ? 'var(--success)' : 'var(--danger)'}">${netMarginPct}%</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Monthly Trends & Visual Split -->
        <div class="card">
          <div class="card-header" style="border-bottom:1px solid var(--border-color);padding-bottom:10px">
            <div class="card-title" style="font-size:1rem;font-weight:800">📊 ${isAR ? 'المبيعات الشهرية ومقارنة الأرباح' : 'Monthly Performance Trend'}</div>
          </div>
          <div style="padding:14px">
            ${Array.from({ length: 12 }, (_, i) => {
              const year = from.slice(0, 4) || Utils.today().slice(0, 4);
              const m = `${year}-${String(i + 1).padStart(2, '0')}`;
              const mSales = posSales.filter(s => (s.created_at || '').startsWith(m)).reduce((s, t) => s + (parseFloat(t.grand_total) || 0), 0)
                           + salesInvoices.filter(si => (si.created_at || si.doc_date || '').startsWith(m) && si.status !== 'cancelled').reduce((s, t) => s + (parseFloat(t.base_grand_total || t.grand_total) || 0), 0);
              return { m, mSales };
            }).map(({ m, mSales }) => {
              const maxS = Math.max(1, netRevenue);
              const pct = Math.min(100, Utils.round((mSales / maxS) * 100));
              return `
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
                <span style="width:65px;font-size:0.78rem;font-weight:700;color:var(--text-secondary)">${m}</span>
                <div style="flex:1;height:18px;background:var(--surface-2);border-radius:8px;overflow:hidden">
                  <div style="height:100%;width:${pct}%;background:linear-gradient(90deg, #3b82f6, #10b981);border-radius:8px;transition:width 0.3s"></div>
                </div>
                <span style="width:110px;text-align:right;font-size:0.78rem;font-weight:800">${Utils.formatMoney(mSales)}</span>
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>`;
    } else if (_activeFinTab === 'trial_balance') {
      // Trial Balance calculation
      const tbRows = accounts.map(a => {
        let dr = 0;
        let cr = 0;
        const bal = parseFloat(a.balance) || 0;
        if (a.type === 'asset' || a.type === 'expense') {
          if (bal >= 0) dr = bal; else cr = Math.abs(bal);
        } else {
          if (bal >= 0) cr = bal; else dr = Math.abs(bal);
        }
        return { ...a, dr, cr };
      });

      // Add automatic system balances if accounts chart is partial
      if (tbRows.length === 0) {
        // Fallback live computed accounts
        const cashBal = filteredCash.reduce((s, t) => t.type === 'receipt' ? s + (parseFloat(t.amount) || 0) : s - (parseFloat(t.amount) || 0), 0);
        const bankBal = filteredBank.reduce((s, t) => t.type === 'receipt' ? s + (parseFloat(t.amount) || 0) : s - (parseFloat(t.amount) || 0), 0);
        const arBal = customers.reduce((s, c) => s + (parseFloat(c.balance) || 0), 0);
        const apBal = suppliers.reduce((s, sp) => s + (parseFloat(sp.balance) || 0), 0);
        const invVal = items.reduce((s, it) => s + ((parseFloat(it.stock_qty) || 0) * (parseFloat(it.cost_price) || 0)), 0);

        tbRows.push({ code: '1010', name: 'Cash on Hand', name_ar: 'الصندوق والنقدية', type: 'asset', dr: Math.max(0, cashBal), cr: Math.max(0, -cashBal) });
        tbRows.push({ code: '1020', name: 'Bank Accounts', name_ar: 'الحسابات البنكية', type: 'asset', dr: Math.max(0, bankBal), cr: Math.max(0, -bankBal) });
        tbRows.push({ code: '1030', name: 'Accounts Receivable', name_ar: 'الذمم المدينة (العملاء)', type: 'asset', dr: Math.max(0, arBal), cr: Math.max(0, -arBal) });
        tbRows.push({ code: '1040', name: 'Merchandise Inventory', name_ar: 'مخزون البضاعة', type: 'asset', dr: invVal, cr: 0 });
        tbRows.push({ code: '2010', name: 'Accounts Payable', name_ar: 'الذمم الدائنة (الموردين)', type: 'liability', dr: Math.max(0, -apBal), cr: Math.max(0, apBal) });
        tbRows.push({ code: '4010', name: 'Sales Revenue', name_ar: 'إيرادات المبيعات', type: 'revenue', dr: 0, cr: netRevenue });
        tbRows.push({ code: '5010', name: 'Cost of Goods Sold', name_ar: 'تكلفة البضاعة المباعة', type: 'expense', dr: totalCogs, cr: 0 });
        tbRows.push({ code: '5020', name: 'Operating Expenses', name_ar: 'المصروفات التشغيلية', type: 'expense', dr: totalExpenses, cr: 0 });
      }

      const totalDr = Utils.round(tbRows.reduce((s, r) => s + r.dr, 0));
      const totalCr = Utils.round(tbRows.reduce((s, r) => s + r.cr, 0));
      const isBalanced = Math.abs(totalDr - totalCr) < 0.05;

      target.innerHTML = `
      <div class="card mb-4" style="background:${isBalanced ? 'rgba(16,185,129,0.06)' : 'rgba(239,68,68,0.06)'};border:1.5px solid ${isBalanced ? 'var(--success)' : 'var(--danger)'}">
        <div style="padding:14px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:1.5rem">${isBalanced ? '✅' : '⚠️'}</span>
            <div>
              <div style="font-weight:900;font-size:1rem">${isBalanced ? (isAR ? 'ميزان المراجعة متوازن تماماً' : 'Trial Balance is Balanced') : (isAR ? 'يوجد فرق غير متوازن في الميزان' : 'Trial Balance Out of Balance')}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إجمالي المدين يطابق إجمالي الدائن وفقاً لمبادئ القيد المزدوج' : 'Double entry audit verified across all active accounts'}</div>
            </div>
          </div>
          <div style="font-size:0.95rem;font-weight:800">
            ${isAR ? 'الفرق:' : 'Variance:'} <span style="color:${isBalanced ? 'var(--success)' : 'var(--danger)'}">${Utils.formatMoney(Math.abs(totalDr - totalCr))}</span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الرمز' : 'Code'}</th>
                <th>${isAR ? 'اسم الحساب' : 'Account Name'}</th>
                <th>${isAR ? 'النوع' : 'Type'}</th>
                <th style="text-align:right">${isAR ? 'مدين (Debit)' : 'Debit'}</th>
                <th style="text-align:right">${isAR ? 'دائن (Credit)' : 'Credit'}</th>
              </tr>
            </thead>
            <tbody>
              ${tbRows.map(r => `
                <tr>
                  <td style="font-weight:700;color:var(--primary)">${r.code || '-'}</td>
                  <td style="font-weight:600">${isAR ? (r.name_ar || r.name) : (r.name || r.name_ar)}</td>
                  <td><span class="badge badge-secondary">${r.type}</span></td>
                  <td style="text-align:right;font-weight:700;color:${r.dr > 0 ? 'var(--danger)' : 'inherit'}">${r.dr > 0 ? Utils.formatMoney(r.dr) : '-'}</td>
                  <td style="text-align:right;font-weight:700;color:${r.cr > 0 ? 'var(--success)' : 'inherit'}">${r.cr > 0 ? Utils.formatMoney(r.cr) : '-'}</td>
                </tr>
              `).join('')}
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:900;background:var(--surface-2)">
                <td colspan="3">${isAR ? 'الإجمالي العام' : 'Totals'}</td>
                <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(totalDr)}</td>
                <td style="text-align:right;color:var(--success)">${Utils.formatMoney(totalCr)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>`;
    } else if (_activeFinTab === 'balance_sheet') {
      // Balance Sheet calculation
      const cashBal = filteredCash.reduce((s, t) => t.type === 'receipt' ? s + (parseFloat(t.amount) || 0) : s - (parseFloat(t.amount) || 0), 0);
      const bankBal = filteredBank.reduce((s, t) => t.type === 'receipt' ? s + (parseFloat(t.amount) || 0) : s - (parseFloat(t.amount) || 0), 0);
      const arBal = customers.reduce((s, c) => s + (parseFloat(c.balance) || 0), 0);
      const invVal = items.reduce((s, it) => s + ((parseFloat(it.stock_qty) || 0) * (parseFloat(it.cost_price) || 0)), 0);
      const totalAssets = Utils.round(Math.max(0, cashBal) + Math.max(0, bankBal) + Math.max(0, arBal) + invVal);

      const apBal = suppliers.reduce((s, sp) => s + (parseFloat(sp.balance) || 0), 0);
      const vatPayable = Utils.round((grossSales * 0.11) - (filteredPurchases.reduce((s, p) => s + (parseFloat(p.base_grand_total || p.grand_total) || 0), 0) * 0.11));
      const totalLiabilities = Utils.round(Math.max(0, apBal) + Math.max(0, vatPayable));

      const retainedEarnings = netOperatingProfit;
      const capital = Utils.round(Math.max(0, totalAssets - totalLiabilities - retainedEarnings));
      const totalEquity = Utils.round(capital + retainedEarnings);
      const totalLiabEquity = Utils.round(totalLiabilities + totalEquity);

      target.innerHTML = `
      <div class="grid grid-2" style="gap:16px">
        <!-- Assets Card -->
        <div class="card">
          <div class="card-header" style="background:rgba(59,130,246,0.08);padding:12px">
            <div class="card-title" style="font-weight:900;color:var(--primary);font-size:1.05rem">🏛️ ${isAR ? 'الأصول (Assets)' : 'Assets'}</div>
          </div>
          <div style="padding:14px">
            <div style="font-weight:800;color:var(--text-secondary);margin-bottom:8px">${isAR ? 'الأصول المتداولة (Current Assets):' : 'Current Assets:'}</div>
            ${finRow(isAR ? 'النقدية والصندوق' : 'Cash on Hand', Math.max(0, cashBal), 'success')}
            ${finRow(isAR ? 'الأرصدة البنكية' : 'Bank Balances', Math.max(0, bankBal), 'success')}
            ${finRow(isAR ? 'الذمم المدينة (ديون العملاء)' : 'Accounts Receivable (Customers)', Math.max(0, arBal), 'primary')}
            ${finRow(isAR ? 'تقييم المخزون بالتكلفة' : 'Merchandise Inventory at Cost', invVal, 'primary')}
            <div style="border-top:2px solid var(--border-color);margin:10px 0"></div>
            ${finRow(isAR ? 'إجمالي الأصول' : 'Total Assets', totalAssets, 'primary', true)}
          </div>
        </div>

        <!-- Liabilities & Equity Card -->
        <div class="card">
          <div class="card-header" style="background:rgba(239,68,68,0.08);padding:12px">
            <div class="card-title" style="font-weight:900;color:var(--danger);font-size:1.05rem">📑 ${isAR ? 'الخصوم وحقوق الملكية (Liabilities & Equity)' : 'Liabilities & Equity'}</div>
          </div>
          <div style="padding:14px">
            <div style="font-weight:800;color:var(--text-secondary);margin-bottom:8px">${isAR ? 'الخصوم المتداولة (Current Liabilities):' : 'Current Liabilities:'}</div>
            ${finRow(isAR ? 'الذمم الدائنة (مستحقات الموردين)' : 'Accounts Payable (Suppliers)', Math.max(0, apBal), 'danger')}
            ${finRow(isAR ? 'ضريبة القيمة المضافة المستحقة' : 'VAT Payable', Math.max(0, vatPayable), 'warning')}
            <div style="border-top:1.5px dashed var(--border-color);margin:6px 0"></div>
            ${finRow(isAR ? 'إجمالي الخصوم' : 'Total Liabilities', totalLiabilities, 'danger', true)}

            <div style="font-weight:800;color:var(--text-secondary);margin:14px 0 8px">${isAR ? 'حقوق الملكية (Equity):' : 'Owners Equity:'}</div>
            ${finRow(isAR ? 'رأس المال الافتتاحي' : 'Contributed Capital', capital, 'primary')}
            ${finRow(isAR ? 'الأرباح المحتجزة للفترة' : 'Period Retained Earnings', retainedEarnings, retainedEarnings >= 0 ? 'success' : 'danger')}
            <div style="border-top:1.5px dashed var(--border-color);margin:6px 0"></div>
            ${finRow(isAR ? 'إجمالي حقوق الملكية' : 'Total Equity', totalEquity, 'primary', true)}

            <div style="border-top:2px solid var(--border-color);margin:10px 0"></div>
            ${finRow(isAR ? 'إجمالي الخصوم وحقوق الملكية' : 'Total Liabilities & Equity', totalLiabEquity, 'primary', true)}
          </div>
        </div>
      </div>`;
    } else if (_activeFinTab === 'cash_flow') {
      // Cash Flow calculation
      const cashInSales = filteredPos.filter(s => s.payment_method === 'cash').reduce((s, t) => s + (parseFloat(t.grand_total) || 0), 0);
      const custReceipts = filteredCash.filter(t => t.type === 'receipt').reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
      const totalCashIn = Utils.round(cashInSales + custReceipts);

      const suppCashPayments = filteredCash.filter(t => t.supplier_id && (t.type === 'payment' || t.type === 'expense')).reduce((s, t) => s + (parseFloat(t.amount) || 0), 0);
      const expCashOut = totalExpenses;
      const totalCashOut = Utils.round(suppCashPayments + expCashOut);
      const netCashFlow = Utils.round(totalCashIn - totalCashOut);

      target.innerHTML = `
      <div class="grid grid-3 mb-4" style="gap:14px">
        ${kpiCard(isAR ? 'إجمالي المقبوضات النقدية' : 'Cash Inflows', totalCashIn, 'success', '📥')}
        ${kpiCard(isAR ? 'إجمالي المدفوعات النقدية' : 'Cash Outflows', totalCashOut, 'danger', '📤')}
        ${kpiCard(isAR ? 'صافي التدفق النقدي' : 'Net Cash Flow', netCashFlow, netCashFlow >= 0 ? 'success' : 'danger', '💵', false, '', true)}
      </div>

      <div class="card">
        <div class="card-header"><div class="card-title" style="font-weight:800">📋 ${isAR ? 'قائمة التدفقات النقدية التشغيلية' : 'Operating Cash Flow Statement'}</div></div>
        <div style="padding:16px">
          <div style="font-weight:800;color:var(--success);margin-bottom:8px">📥 ${isAR ? 'التدفقات النقدية الداخلة (الوارد):' : 'Cash Receipts & Inflows:'}</div>
          ${finRow(isAR ? 'المبيعات النقدية المقبوضة فورا' : 'Cash Sales Collections', cashInSales, 'success')}
          ${finRow(isAR ? 'إيصالات قبض ودفعات العملاء' : 'Customer Account Collections', custReceipts, 'success')}
          <div style="border-top:1.5px dashed var(--border-color);margin:6px 0"></div>
          ${finRow(isAR ? 'إجمالي الوارد' : 'Total Inflows', totalCashIn, 'success', true)}

          <div style="font-weight:800;color:var(--danger);margin:16px 0 8px">📤 ${isAR ? 'التدفقات النقدية الخارجة (الصادر):' : 'Cash Disbursements & Outflows:'}</div>
          ${finRow(isAR ? 'مدفوعات وسداد فواتير الموردين' : 'Supplier Payments', -suppCashPayments, 'danger')}
          ${finRow(isAR ? 'المصروفات التشغيلية المدفوعة' : 'Operating Expenses Paid', -expCashOut, 'danger')}
          <div style="border-top:1.5px dashed var(--border-color);margin:6px 0"></div>
          ${finRow(isAR ? 'إجمالي الصادر' : 'Total Outflows', -totalCashOut, 'danger', true)}

          <div style="border-top:2px solid var(--border-color);margin:14px 0"></div>
          ${finRow(isAR ? 'صافي التغير في النقدية' : 'Net Increase / (Decrease) in Cash', netCashFlow, netCashFlow >= 0 ? 'success' : 'danger', true)}
        </div>
      </div>`;
    } else if (_activeFinTab === 'vat') {
      const vatRate = parseFloat(await DB.getSetting('vat_rate', 11)) || 11;
      const salesTaxable = netRevenue;
      const vatOutput = Utils.round(salesTaxable * (vatRate / 100));

      const purchasesTaxable = filteredPurchases.reduce((s, p) => s + (parseFloat(p.base_grand_total || p.grand_total) || 0), 0);
      const vatInput = Utils.round(purchasesTaxable * (vatRate / 100));
      const netVatPayable = Utils.round(vatOutput - vatInput);

      target.innerHTML = `
      <div class="grid grid-4 mb-4" style="gap:12px">
        ${kpiCard(isAR ? 'معدل ضريبة VAT' : 'VAT Rate', `${vatRate}%`, 'primary', '⚖️', false)}
        ${kpiCard(isAR ? 'ضريبة المخرجات (المبيعات)' : 'Output VAT (Sales)', vatOutput, 'warning', '📈')}
        ${kpiCard(isAR ? 'ضريبة المدخلات (المشتريات)' : 'Input VAT (Purchases)', vatInput, 'info', '📉')}
        ${kpiCard(isAR ? 'صافي الضريبة المستحقة' : 'Net VAT Payable', netVatPayable, netVatPayable >= 0 ? 'danger' : 'success', '💰', false, '', true)}
      </div>

      <div class="card">
        <div class="card-header"><div class="card-title" style="font-weight:800">📋 ${isAR ? 'إقرار ضريبة القيمة المضافة الرسمي' : 'Official VAT Declaration Return'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'البند / البيان' : 'Item Description'}</th>
                <th style="text-align:right">${isAR ? 'المبلغ الخاضع للضريبة' : 'Taxable Base Amount'}</th>
                <th style="text-align:center">${isAR ? 'نسبة الضريبة' : 'Rate'}</th>
                <th style="text-align:right">${isAR ? 'مبلغ الضريبة' : 'VAT Amount'}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="font-weight:700">1. ${isAR ? 'المبيعات والخدمات الخاضعة للضريبة' : 'Taxable Sales & Services'}</td>
                <td style="text-align:right;font-weight:700">${Utils.formatMoney(salesTaxable)}</td>
                <td style="text-align:center">${vatRate}%</td>
                <td style="text-align:right;font-weight:800;color:var(--warning)">${Utils.formatMoney(vatOutput)}</td>
              </tr>
              <tr>
                <td style="font-weight:700">2. ${isAR ? 'المشتريات ونفقات الأعمال الخاضعة للضريبة' : 'Taxable Purchases & Operating Costs'}</td>
                <td style="text-align:right;font-weight:700">${Utils.formatMoney(purchasesTaxable)}</td>
                <td style="text-align:center">${vatRate}%</td>
                <td style="text-align:right;font-weight:800;color:var(--info)">${Utils.formatMoney(vatInput)}</td>
              </tr>
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:900;background:var(--surface-2);font-size:0.95rem">
                <td colspan="3">${isAR ? 'صافي الضريبة الواجب سدادها للخزينة' : 'Net VAT Due / Payable'}</td>
                <td style="text-align:right;color:${netVatPayable >= 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(netVatPayable)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>`;
    } else if (_activeFinTab === 'expenses') {
      target.innerHTML = `
      <div class="grid grid-3 mb-4" style="gap:12px">
        ${kpiCard(isAR ? 'إجمالي المصروفات' : 'Total Expenses', totalExpenses, 'danger', '📉')}
        ${kpiCard(isAR ? 'عدد سندات الصرف' : 'Expense Vouchers', expenseTxns.length, 'primary', '🧾', false)}
        ${kpiCard(isAR ? 'عدد بنود التصنيفات' : 'Expense Categories', Object.keys(expenseCatMap).length, 'info', '📂', false)}
      </div>

      <div class="grid grid-3 mb-4" style="gap:12px">
        ${Object.entries(expenseCatMap).map(([cat, amt]) => {
          const pct = totalExpenses > 0 ? Utils.round((amt / totalExpenses) * 100) : 0;
          return `
          <div class="card" style="padding:12px">
            <div style="font-size:0.78rem;color:var(--text-muted);margin-bottom:2px">${Utils.sanitize(cat)}</div>
            <div style="font-size:1.15rem;font-weight:800;color:var(--danger)">${Utils.formatMoney(amt)}</div>
            <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px">${pct}% ${isAR ? 'من إجمالي المصروفات' : 'of total'}</div>
          </div>`;
        }).join('')}
      </div>

      <div class="card">
        <div class="card-header"><div class="card-title" style="font-weight:800">📜 ${isAR ? 'سجل تفاصيل سندات المصروفات' : 'Expense Vouchers Audit Log'}</div></div>
        <div class="table-wrapper" style="max-height:420px;overflow-y:auto">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'التاريخ' : 'Date'}</th>
                <th>${isAR ? 'الرقم' : 'Ref #'}</th>
                <th>${isAR ? 'التصنيف' : 'Category'}</th>
                <th>${isAR ? 'البيان / الوصف' : 'Description'}</th>
                <th>${isAR ? 'طريقة الصرف' : 'Method'}</th>
                <th style="text-align:right">${isAR ? 'المبلغ' : 'Amount'}</th>
              </tr>
            </thead>
            <tbody>
              ${expenseTxns.map(e => `
                <tr>
                  <td style="font-size:0.78rem">${Utils.formatDate(e.date)}</td>
                  <td style="font-weight:700;color:var(--primary)">${e.ref}</td>
                  <td><span class="badge badge-secondary">${Utils.sanitize(e.category)}</span></td>
                  <td>${Utils.sanitize(e.description)}</td>
                  <td><span class="badge badge-info">${e.method}</span></td>
                  <td style="text-align:right;font-weight:800;color:var(--danger)">${Utils.formatMoney(e.amount)}</td>
                </tr>
              `).join('') || `<tr><td colspan="6" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد مصروفات مسجلة بالفترة' : 'No expenses recorded'}</td></tr>`}
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:900;background:var(--surface-2)">
                <td colspan="5">${isAR ? 'الإجمالي' : 'Total'}</td>
                <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(totalExpenses)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>`;
    }
  }

  function finRow(label, value, color, bold = false) {
    return `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;${bold ? 'font-weight:900;font-size:0.95rem' : 'font-size:0.86rem'}">
      <span>${label}</span>
      <span style="color:var(--${color});font-weight:800">${value < 0 ? `-${Utils.formatMoney(Math.abs(value))}` : Utils.formatMoney(value)}</span>
    </div>`;
  }

  async function printFinanceReport() {
    const isAR = i18n.getLang() === 'ar';
    const comp = await DB.getSetting('company_name', 'Store');
    const logo = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    const content = document.getElementById('fin-report-target');
    if (!content) return;

    Utils.printElement(`
    <div class="doc-a4" dir="${isAR ? 'rtl' : 'ltr'}" style="font-family:'Cairo','Inter',sans-serif;padding:24px">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #333;padding-bottom:12px;margin-bottom:20px">
        <div class="doc-company-info" style="display:flex;align-items:center;gap:12px">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain">` : ''}
          <h2 style="margin:0">${Utils.sanitize(comp)}</h2>
        </div>
        <div class="doc-title-block" style="text-align:${isAR ? 'left' : 'right'}">
          <h1 style="font-size:1.3rem;margin:0 0 4px">${isAR ? 'التقرير المالي' : 'Financial Statement'} (${_activeFinTab.toUpperCase()})</h1>
          <div class="doc-date" style="color:#666">${Utils.formatDate(Utils.today())}</div>
        </div>
      </div>
      ${content.innerHTML}
    </div>`, `Finance-${_activeFinTab}`);
  }

  function exportFinanceReport() {
    const d = window._finData || {};
    if (_activeFinTab === 'expenses') {
      Utils.exportCSV((d.expenseTxns || []).map(e => ({ Date: e.date, Ref: e.ref, Category: e.category, Amount: e.amount, Description: e.description, Method: e.method })), 'expenses_report');
    } else {
      Utils.exportCSV([
        { Metric: 'Gross Sales', Value: d.grossSales || 0 },
        { Metric: 'Sales Returns', Value: d.retVal || 0 },
        { Metric: 'Net Revenue', Value: d.netRevenue || 0 },
        { Metric: 'COGS', Value: d.totalCogs || 0 },
        { Metric: 'Gross Profit', Value: d.grossProfit || 0 },
        { Metric: 'Operating Expenses', Value: d.totalExpenses || 0 },
        { Metric: 'Net Operating Profit', Value: d.netOperatingProfit || 0 }
      ], `financial_${_activeFinTab}`);
    }
  }

  const printPLReport = printFinanceReport;
  const exportPLReport = exportFinanceReport;

  // ── Customer Ledger (Full Statement & Summary) ─────────────────
  let _selectedCustForLedger = null;

  async function renderCustomerLedger(container, defaultCustId = null) {
    if (!container) container = document.getElementById('page-content');
    const customers = (await DB.getAll('customers')) || [];
    const isAR = i18n.getLang() === 'ar';
    const isEmbedded = (container && container.id === 'master-report-render-target');

    container.innerHTML = `
    <div class="animate-slide">
      ${!isEmbedded ? `
      <div class="page-header" style="margin-bottom:14px">
        <div class="page-header-left" style="display:flex;align-items:center;gap:12px">
          <button class="btn btn-ghost btn-sm" onclick="Reports.render(document.getElementById('page-content'))" style="font-weight:700">← ${isAR ? 'مركز التقارير' : 'Reports Hub'}</button>
          <div>
            <h1>👥 ${isAR ? 'دفتر أستاذ وكشف حساب العملاء' : 'Customer Ledger & Statement'}</h1>
            <p>${isAR ? 'استعراض كشف الحساب التراكمي، المبيعات الآجلة، الدفعات، وأرصدة الديون' : 'Audit customer statements, sales invoices, receipts, and net balances'}</p>
          </div>
        </div>
      </div>
      ` : ''}

      <!-- Selector Bar -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:14px">
          <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
            <div class="form-group" style="margin-bottom:0;flex:1;max-width:400px">
              <label class="form-label" style="font-weight:800;font-size:0.82rem">${isAR ? 'اختر العميل لعرض كشف حسابه' : 'Select Customer for Statement'}</label>
              <select class="form-control" id="ledger-cust-select" onchange="Reports.loadCustomerLedger(this.value)">
                <option value="all">-- ${isAR ? 'جميع العملاء (جدول الأرصدة العام)' : 'All Customers (General Balances)'} --</option>
                ${customers.map(c => `
                  <option value="${c.id}" ${_selectedCustForLedger === c.id ? 'selected' : ''}>
                    ${isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar)} (الرصيد: ${Utils.formatMoney(c.balance || 0)})
                  </option>
                `).join('')}
              </select>
            </div>
            ${_selectedCustForLedger ? `
              <div style="display:flex;align-items:flex-end">
                <button class="btn btn-ghost" onclick="Reports.loadCustomerLedger('all')" style="font-weight:700">
                  ← ${isAR ? 'عرض كافة العملاء' : 'Back to All Customers'}
                </button>
              </div>
            ` : ''}
          </div>
        </div>
      </div>

      <!-- Live Customer Ledger Render Target -->
      <div id="cust-ledger-render-target"></div>
    </div>`;

    await loadCustomerLedger(_selectedCustForLedger || 'all');
  }

  async function loadCustomerLedger(custId) {
    const target = document.getElementById('cust-ledger-render-target');
    if (!target) return;
    const isAR = i18n.getLang() === 'ar';

    // Sync combobox 2 if in reports hub
    const subSelect = document.getElementById('master-rep-sub');
    const typeSelect = document.getElementById('master-rep-type');
    if (subSelect && typeSelect && typeSelect.value === 'customer-ledger') {
      subSelect.value = custId || 'all';
      _selectedMasterSub = custId || 'all';
    }

    if (!custId || custId === 'all') {
      // Render Summary Table of All Customers
      const customers = (await DB.getAll('customers')) || [];
      const totalReceivables = Utils.round(customers.reduce((s, c) => s + (parseFloat(c.balance) || 0), 0));
      const inDebtCount = customers.filter(c => (parseFloat(c.balance) || 0) > 0).length;

      target.innerHTML = `
      <div class="grid grid-3 mb-4" style="gap:12px">
        ${kpiCard(isAR ? 'إجمالي العملاء' : 'Total Customers', customers.length, 'primary', '👥', false)}
        ${kpiCard(isAR ? 'عملاء عليهم ديون مستحقة' : 'Customers In Debt', inDebtCount, inDebtCount > 0 ? 'danger' : 'success', '⚠️', false)}
        ${kpiCard(isAR ? 'إجمالي الديون والذمم المدينة' : 'Total Receivables', totalReceivables, totalReceivables > 0 ? 'danger' : 'success', '💰', false, '', true)}
      </div>

      <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
          <div class="card-title">📋 ${isAR ? 'دليل وأرصدة كافة العملاء' : 'All Customers Ledger & Balances'}</div>
          <input type="text" id="cust-ledger-search" class="form-control" placeholder="${isAR ? 'بحث عن عميل...' : 'Search customer...'}" style="max-width:240px;height:34px" oninput="Reports.filterCustSummaryTable(this.value)">
        </div>
        <div class="table-wrapper">
          <table id="cust-summary-table">
            <thead>
              <tr>
                <th>${isAR ? 'العميل' : 'Customer'}</th>
                <th>${isAR ? 'الهاتف' : 'Phone'}</th>
                <th style="text-align:right">${isAR ? 'حد الائتمان' : 'Credit Limit'}</th>
                <th style="text-align:right">${isAR ? 'الرصيد الحالي' : 'Current Balance'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody>
              ${customers.map(c => {
                const nm = isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar);
                const bal = parseFloat(c.balance) || 0;
                return `
                <tr data-name="${(nm || '').toLowerCase()} ${(c.phone || '').toLowerCase()}">
                  <td style="font-weight:700">${Utils.sanitize(nm)}</td>
                  <td style="font-family:monospace;color:var(--text-muted)">${Utils.sanitize(c.phone || '-')}</td>
                  <td style="text-align:right;color:var(--info)">${Utils.formatMoney(c.credit_limit || 0)}</td>
                  <td style="text-align:right;font-weight:900;color:${bal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(bal)}</td>
                  <td style="text-align:center">
                    <div style="display:flex;gap:4px;justify-content:center">
                      <button class="btn btn-info btn-sm" onclick="Reports.loadCustomerLedger(${c.id})" title="${isAR ? 'عرض كشف الحساب' : 'View Statement'}">
                        📄 ${isAR ? 'كشف حساب' : 'Statement'}
                      </button>
                      <button class="btn btn-success btn-sm" onclick="window.CustomersModule ? CustomersModule.openPaymentModal(${c.id}) : null" title="${isAR ? 'قبض دفعة' : 'Receive Payment'}">
                        💵 ${isAR ? 'قبض' : 'Pay'}
                      </button>
                    </div>
                  </td>
                </tr>`;
              }).join('') || `<tr><td colspan="5" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا يوجد عملاء' : 'No customers'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
    } else {
      // Render Specific Customer Statement of Account
      const id = parseInt(custId, 10);
      const cust = await DB.get('customers', id);
      if (!cust) return;

      const custName = isAR ? (cust.name_ar || cust.name_en) : (cust.name_en || cust.name_ar);
      const { ledger, totalDebit, totalCredit, runningBal } = await CustomersModule.buildCustomerLedger(id, isAR);

      target.innerHTML = `
      <!-- Customer Info Header Cards -->
      <div class="grid grid-4 mb-4" style="gap:12px">
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'اسم العميل' : 'Customer'}</div>
          <div style="font-weight:800;font-size:1.05rem;margin-top:2px">${Utils.sanitize(custName)}</div>
          <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px">📞 ${cust.phone || '-'}</div>
        </div>
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'حد الائتمان' : 'Credit Limit'}</div>
          <div style="font-weight:800;font-size:1.05rem;margin-top:2px;color:var(--info)">${Utils.formatMoney(cust.credit_limit || 0)}</div>
        </div>
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إجمالي المبيعات (مدين)' : 'Total Purchases (Debit)'}</div>
          <div style="font-weight:800;font-size:1.05rem;margin-top:2px;color:var(--danger)">${Utils.formatMoney(totalDebit)}</div>
        </div>
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'صافي الرصيد المستحق (الدين)' : 'Balance Due'}</div>
          <div style="font-weight:900;font-size:1.2rem;margin-top:2px;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</div>
        </div>
      </div>

      <!-- Action & Print Bar -->
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px">
        <div style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="Reports.loadCustomerLedger('all')">
            ← ${isAR ? 'العودة لكافة العملاء' : 'All Customers'}
          </button>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-success" onclick="window.CustomersModule ? CustomersModule.openPaymentModal(${id}) : null">
            💵 ${isAR ? 'قبض دفعة من العميل' : 'Receive Payment'}
          </button>
          <button class="btn btn-secondary" onclick="CustomersModule.printStatement(${id}, '80mm')">
            🧾 ${isAR ? 'طباعة إيصال (80mm)' : 'Thermal (80mm)'}
          </button>
          <button class="btn btn-primary" onclick="CustomersModule.printStatement(${id}, 'A4')">
            📄 ${isAR ? 'طباعة كشف A4' : 'A4 Statement'}
          </button>
        </div>
      </div>

      <!-- Statement Table -->
      <div class="card">
        <div class="table-wrapper" style="max-height:450px;overflow-y:auto">
          <table style="font-size:0.84rem">
            <thead>
              <tr>
                <th>${isAR ? 'التاريخ' : 'Date'}</th>
                <th>${isAR ? 'الرقم' : 'Ref #'}</th>
                <th>${isAR ? 'النوع / البيان' : 'Type / Ref'}</th>
                <th style="text-align:right">${isAR ? 'مدين (مبيعات)' : 'Debit'}</th>
                <th style="text-align:right">${isAR ? 'دائن (مدفوعات)' : 'Credit'}</th>
                <th style="text-align:right">${isAR ? 'الرصيد' : 'Balance'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody>
              ${ledger.map(l => `
                <tr>
                  <td style="font-size:0.78rem">${Utils.formatDate(l.date)}</td>
                  <td style="font-weight:700;color:var(--primary)">${l.ref}</td>
                  <td>${l.type}</td>
                  <td style="text-align:right;font-weight:600;color:${l.debit > 0 ? 'var(--danger)' : 'inherit'}">${l.debit > 0 ? Utils.formatMoney(l.debit) : '-'}</td>
                  <td style="text-align:right;font-weight:600;color:${l.credit > 0 ? 'var(--success)' : 'inherit'}">${l.credit > 0 ? Utils.formatMoney(l.credit) : '-'}</td>
                  <td style="text-align:right;font-weight:800">${Utils.formatMoney(l.balance)}</td>
                  <td>
                    <div style="display:flex;gap:4px;justify-content:center">
                      ${l.isPayment ? `
                        <button class="btn btn-ghost btn-sm" onclick="CustomersModule.openEditPaymentModal('${l.store}', ${l.id}, ${cust.id})" title="${isAR ? 'تعديل الدفعة' : 'Edit Payment'}">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button class="btn btn-ghost btn-sm" onclick="CustomersModule.deletePaymentTxn('${l.store}', ${l.id}, ${cust.id})" style="color:var(--danger)" title="${isAR ? 'إلغاء وحذف الدفعة' : 'Delete Payment'}">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                        </button>
                      ` : `
                        <button class="btn btn-ghost btn-sm" onclick="window.SalesModule ? SalesModule.openSalesDoc('${l.store}', ${l.id}) : null" title="${isAR ? 'عرض / تعديل الفاتورة' : 'View Doc'}">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                      `}
                    </div>
                  </td>
                </tr>
              `).join('') || `<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد حركات لـ هذا العميل' : 'No transactions'}</td></tr>`}
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:900;background:var(--surface-2)">
                <td colspan="3">${isAR ? 'الإجمالي' : 'Total'}</td>
                <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(totalDebit)}</td>
                <td style="text-align:right;color:var(--success)">${Utils.formatMoney(totalCredit)}</td>
                <td style="text-align:right;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>`;
    }
  }

  function filterCustSummaryTable(q) {
    const query = (q || '').toLowerCase();
    document.querySelectorAll('#cust-summary-table tbody tr').forEach(row => {
      row.style.display = !query || row.dataset.name?.includes(query) ? '' : 'none';
    });
  }

  // Backward-compatible loadLedger
  async function loadLedger() {
    const custId = document.getElementById('ledger-cust-select')?.value || document.getElementById('ledger-cust')?.value;
    await loadCustomerLedger(custId || 'all');
  }

  async function renderAttReport(container, subFilter = 'all') {
    const attendance = await DB.getAll('attendance');
    let employees  = (await DB.getAll('employees')) || [];
    const isAR = i18n.getLang() === 'ar';

    const present = attendance.filter(a => a.status === 'present').length;
    const absent  = attendance.filter(a => a.status === 'absent').length;
    const late    = attendance.filter(a => a.status === 'late').length;

    if (subFilter === 'present') {
      employees = employees.filter(emp => attendance.some(a => a.employee_id === emp.id && a.status === 'present'));
    } else if (subFilter === 'absent') {
      employees = employees.filter(emp => attendance.some(a => a.employee_id === emp.id && a.status === 'absent'));
    } else if (subFilter === 'late') {
      employees = employees.filter(emp => attendance.some(a => a.employee_id === emp.id && a.status === 'late'));
    }

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'تقرير الحضور والدوام' : 'Attendance Report'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Reports.exportAttReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR?'تصدير':'Export'}
          </button>
        </div>
      </div>
      <div class="grid grid-4 mb-4">
        ${kpiCard(isAR?'حاضر':'Present Days', present, 'success', '✅', false)}
        ${kpiCard(isAR?'غائب':'Absent Days', absent, 'danger', '❌', false)}
        ${kpiCard(isAR?'متأخر':'Late Days', late, 'warning', '⏰', false)}
        ${kpiCard(isAR?'إجمالي السجلات':'Total Records', attendance.length, 'primary', '📊', false)}
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR?'الموظف':'Employee'}</th>
            <th>${isAR?'حاضر':'Present'}</th>
            <th>${isAR?'غائب':'Absent'}</th>
            <th>${isAR?'متأخر':'Late'}</th>
            <th>${isAR?'إجازات':'Leave'}</th>
            <th>${isAR?'نسبة الحضور%':'Attendance %'}</th>
          </tr></thead>
          <tbody>
            ${employees.map(emp => {
              const empAtt = attendance.filter(a => a.employee_id === emp.id);
              const ep = empAtt.filter(a => a.status==='present').length;
              const ea = empAtt.filter(a => a.status==='absent').length;
              const el = empAtt.filter(a => a.status==='late').length;
              const eh = empAtt.filter(a => a.status==='holiday').length;
              const pct = empAtt.length > 0 ? Utils.round((ep/(ep+ea))*100) : 0;
              return `<tr>
                <td style="font-weight:600">${isAR?(emp.name_ar||emp.name_en):(emp.name_en||emp.name_ar)}</td>
                <td style="color:var(--success);font-weight:700">${ep}</td>
                <td style="color:var(--danger);font-weight:700">${ea}</td>
                <td style="color:var(--warning);font-weight:700">${el}</td>
                <td>${eh}</td>
                <td>
                  <div style="display:flex;align-items:center;gap:8px">
                    <div style="flex:1;height:8px;background:var(--surface-2);border-radius:4px">
                      <div style="height:100%;width:${pct}%;background:${pct>=80?'var(--success)':pct>=60?'var(--warning)':'var(--danger)'};border-radius:4px"></div>
                    </div>
                    <span style="font-weight:700;min-width:36px">${pct}%</span>
                  </div>
                </td>
              </tr>`;
            }).join('') || `<tr><td colspan="6" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد سجلات مطابقة' : 'No matching records'}</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>`;

    window._attForReport = attendance;
    window._empsForReport = employees;
  }

  function exportAttReport() {
    const att  = window._attForReport || [];
    Utils.exportCSV(att.map(a => ({ Employee: a.employee_id, Date: a.date, Status: a.status, CheckIn: a.check_in, CheckOut: a.check_out })), 'attendance_report');
  }

  // ── Supplier Ledger (Full Statement & Summary) ─────────────────
  let _selectedSuppForLedger = null;

  async function renderSupplierLedger(container, defaultSuppId = null) {
    if (!container) container = document.getElementById('page-content');
    if (window.SuppliersModule?.syncAllSupplierBalances) {
      try {
        await window.SuppliersModule.syncAllSupplierBalances();
      } catch (e) {
        console.warn('Sync supplier balances failed:', e);
      }
    }
    const suppliers = (await DB.getAll('suppliers')) || [];
    const isAR = i18n.getLang() === 'ar';
    const isEmbedded = (container && container.id === 'master-report-render-target');

    container.innerHTML = `
    <div class="animate-slide">
      ${!isEmbedded ? `
      <div class="page-header" style="margin-bottom:14px">
        <div class="page-header-left" style="display:flex;align-items:center;gap:12px">
          <button class="btn btn-ghost btn-sm" onclick="Reports.render(document.getElementById('page-content'))" style="font-weight:700">← ${isAR ? 'مركز التقارير' : 'Reports Hub'}</button>
          <div>
            <h1>🏭 ${isAR ? 'دفتر أستاذ وكشف حساب الموردين' : 'Supplier Ledger & Statement'}</h1>
            <p>${isAR ? 'استعراض كشف حساب المورد التفصيلي، فواتير الشراء، المدفوعات النقدية والبنكية، وأرصدة الذمم الدائنة' : 'Audit supplier statements of account, purchases, cash/bank payments & net payable balances'}</p>
          </div>
        </div>
      </div>
      ` : ''}

      <!-- Selector Bar -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:14px">
          <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap">
            <div class="form-group" style="margin-bottom:0;flex:1;max-width:400px">
              <label class="form-label" style="font-weight:800;font-size:0.82rem">${isAR ? 'اختر المورد لعرض كشف حسابه' : 'Select Supplier for Statement'}</label>
              <select class="form-control" id="ledger-supp-select" onchange="Reports.loadSupplierLedger(this.value)">
                <option value="all">-- ${isAR ? 'جميع الموردين (جدول الأرصدة العام)' : 'All Suppliers (General Balances)'} --</option>
                ${suppliers.map(s => `
                  <option value="${s.id}" ${_selectedSuppForLedger === s.id ? 'selected' : ''}>
                    ${isAR ? (s.name_ar || s.name_en) : (s.name_en || s.name_ar)} (الرصيد: ${Utils.formatMoney(s.balance || 0)})
                  </option>
                `).join('')}
              </select>
            </div>
            ${_selectedSuppForLedger ? `
              <div style="display:flex;align-items:flex-end">
                <button class="btn btn-ghost" onclick="Reports.loadSupplierLedger('all')" style="font-weight:700">
                  ← ${isAR ? 'عرض كافة الموردين' : 'Back to All Suppliers'}
                </button>
              </div>
            ` : ''}
          </div>
        </div>
      </div>

      <!-- Live Supplier Ledger Render Target -->
      <div id="supp-ledger-render-target"></div>
    </div>`;

    await loadSupplierLedger(_selectedSuppForLedger || 'all');
  }

  async function loadSupplierLedger(suppId) {
    const target = document.getElementById('supp-ledger-render-target');
    if (!target) return;
    const isAR = i18n.getLang() === 'ar';

    // Sync combobox 2 if in reports hub
    const subSelect = document.getElementById('master-rep-sub');
    const typeSelect = document.getElementById('master-rep-type');
    if (subSelect && typeSelect && typeSelect.value === 'supplier-ledger') {
      subSelect.value = suppId || 'all';
      _selectedMasterSub = suppId || 'all';
    }

    if (!suppId || suppId === 'all') {
      // Render Summary Table of All Suppliers
      const suppliers = (await DB.getAll('suppliers')) || [];
      const totalPurchases = Utils.round(suppliers.reduce((s, sp) => s + (parseFloat(sp.total_purchases) || 0), 0));
      const totalPaid = Utils.round(suppliers.reduce((s, sp) => s + (parseFloat(sp.total_paid) || 0), 0));
      const totalPayables = Utils.round(suppliers.reduce((s, sp) => s + (parseFloat(sp.balance) || 0), 0));

      target.innerHTML = `
      <div class="grid grid-3 mb-4" style="gap:12px">
        ${kpiCard(isAR ? 'إجمالي المشتريات من الموردين' : 'Total Purchases', totalPurchases, 'primary', '📦')}
        ${kpiCard(isAR ? 'إجمالي المسدد للموردين' : 'Total Paid to Suppliers', totalPaid, 'success', '💰')}
        ${kpiCard(isAR ? 'إجمالي الديون المستحقة للموردين' : 'Total Payables Due', totalPayables, totalPayables > 0 ? 'danger' : 'success', '📑', false, '', true)}
      </div>

      <div class="card">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
          <div class="card-title">📋 ${isAR ? 'دليل وأرصدة كافة الموردين' : 'All Suppliers Ledger & Balances'}</div>
          <input type="text" id="supp-ledger-search" class="form-control" placeholder="${isAR ? 'بحث عن مورد...' : 'Search supplier...'}" style="max-width:240px;height:34px" oninput="Reports.filterSuppSummaryTable(this.value)">
        </div>
        <div class="table-wrapper">
          <table id="supp-summary-table">
            <thead>
              <tr>
                <th>${isAR ? 'المورد' : 'Supplier'}</th>
                <th>${isAR ? 'الهاتف' : 'Phone'}</th>
                <th style="text-align:right">${isAR ? 'إجمالي المشتريات' : 'Total Purchases'}</th>
                <th style="text-align:right">${isAR ? 'إجمالي المسدد' : 'Total Paid'}</th>
                <th style="text-align:right">${isAR ? 'الرصيد المتبقي (المستحق)' : 'Net Balance Due'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody>
              ${suppliers.map(s => {
                const nm = isAR ? (s.name_ar || s.name_en) : (s.name_en || s.name_ar);
                const bal = parseFloat(s.balance) || 0;
                return `
                <tr data-name="${(nm || '').toLowerCase()} ${(s.phone || '').toLowerCase()}">
                  <td style="font-weight:700">${Utils.sanitize(nm)}</td>
                  <td style="font-family:monospace;color:var(--text-muted)">${Utils.sanitize(s.phone || '-')}</td>
                  <td style="text-align:right;color:var(--primary)">${Utils.formatMoney(s.total_purchases || 0)}</td>
                  <td style="text-align:right;color:var(--success)">${Utils.formatMoney(s.total_paid || 0)}</td>
                  <td style="text-align:right;font-weight:900;color:${bal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(bal)}</td>
                  <td style="text-align:center">
                    <div style="display:flex;gap:4px;justify-content:center">
                      <button class="btn btn-info btn-sm" onclick="Reports.loadSupplierLedger(${s.id})" title="${isAR ? 'عرض كشف الحساب' : 'View Statement'}">
                        📄 ${isAR ? 'كشف حساب' : 'Statement'}
                      </button>
                      <button class="btn btn-warning btn-sm" onclick="window.SuppliersModule ? SuppliersModule.openPaymentModal(${s.id}) : null" title="${isAR ? 'دفع للمورد' : 'Pay Supplier'}">
                        💵 ${isAR ? 'دفع' : 'Pay'}
                      </button>
                    </div>
                  </td>
                </tr>`;
              }).join('') || `<tr><td colspan="6" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا يوجد موردون' : 'No suppliers'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
    } else {
      // Render Specific Supplier Statement of Account (Matching Customer Statement structure!)
      const id = parseInt(suppId, 10);
      const supp = await DB.get('suppliers', id);
      if (!supp) return;

      const suppName = isAR ? (supp.name_ar || supp.name_en) : (supp.name_en || supp.name_ar);
      const { ledger, totalDebit, totalCredit, runningBal } = await SuppliersModule.buildSupplierLedger(id, isAR);

      target.innerHTML = `
      <!-- Supplier Info Header Cards -->
      <div class="grid grid-4 mb-4" style="gap:12px">
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'اسم المورد' : 'Supplier'}</div>
          <div style="font-weight:800;font-size:1.05rem;margin-top:2px">${Utils.sanitize(suppName)}</div>
          <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px">📞 ${supp.phone || '-'} ${supp.vat_number ? `| VAT: ${supp.vat_number}` : ''}</div>
        </div>
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'شروط الدفع / العملة' : 'Terms / Currency'}</div>
          <div style="font-weight:800;font-size:1.05rem;margin-top:2px;color:var(--info)">${supp.payment_terms || (isAR ? 'حسب الاتفاق' : 'Standard')} (${supp.currency || 'USD'})</div>
        </div>
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'إجمالي المشتريات (مدين)' : 'Total Purchases (+)'}</div>
          <div style="font-weight:800;font-size:1.05rem;margin-top:2px;color:var(--primary)">${Utils.formatMoney(totalDebit)}</div>
        </div>
        <div class="card" style="padding:12px">
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الرصيد المتبقي المستحق للمورد' : 'Net Balance Due'}</div>
          <div style="font-weight:900;font-size:1.2rem;margin-top:2px;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</div>
        </div>
      </div>

      <!-- Action & Print Bar -->
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px">
        <div style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="Reports.loadSupplierLedger('all')">
            ← ${isAR ? 'العودة لكافة الموردين' : 'All Suppliers'}
          </button>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-warning" onclick="window.SuppliersModule ? SuppliersModule.openPaymentModal(${id}) : null">
            💵 ${isAR ? 'سداد دفعة للمورد' : 'Pay Supplier'}
          </button>
          <button class="btn btn-secondary" onclick="SuppliersModule.printStatement(${id}, '80mm')">
            🧾 ${isAR ? 'طباعة إيصال (80mm)' : 'Thermal (80mm)'}
          </button>
          <button class="btn btn-primary" onclick="SuppliersModule.printStatement(${id}, 'A4')">
            📄 ${isAR ? 'طباعة كشف A4' : 'A4 Statement'}
          </button>
        </div>
      </div>

      <!-- Statement Table -->
      <div class="card">
        <div class="table-wrapper" style="max-height:450px;overflow-y:auto">
          <table style="font-size:0.84rem">
            <thead>
              <tr>
                <th>${isAR ? 'التاريخ' : 'Date'}</th>
                <th>${isAR ? 'الرقم' : 'Ref #'}</th>
                <th>${isAR ? 'النوع / البيان' : 'Type / Description'}</th>
                <th style="text-align:right">${isAR ? 'مشتريات (+)' : 'Purchases (+)'}</th>
                <th style="text-align:right">${isAR ? 'مدفوعات/مرتجع (-)' : 'Payments/Returns (-)'}</th>
                <th style="text-align:right">${isAR ? 'الرصيد' : 'Balance'}</th>
                <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody>
              ${ledger.map(l => `
                <tr>
                  <td style="font-size:0.78rem">${Utils.formatDate(l.date)}</td>
                  <td style="font-weight:700;color:var(--primary)">${l.ref}</td>
                  <td>${l.type}</td>
                  <td style="text-align:right;font-weight:600;color:${l.debit > 0 ? 'var(--danger)' : 'inherit'}">${l.debit > 0 ? Utils.formatMoney(l.debit) : '-'}</td>
                  <td style="text-align:right;font-weight:600;color:${l.credit > 0 ? 'var(--success)' : 'inherit'}">${l.credit > 0 ? Utils.formatMoney(l.credit) : '-'}</td>
                  <td style="text-align:right;font-weight:800">${Utils.formatMoney(l.balance)}</td>
                  <td>
                    <div style="display:flex;gap:4px;justify-content:center">
                      ${(l.isPayment && (l.store === 'cash_transactions' || l.store === 'bank_transactions')) ? `
                        <button class="btn btn-ghost btn-sm" onclick="SuppliersModule.openEditPaymentModal('${l.store}', ${l.id}, ${supp.id})" title="${isAR ? 'تعديل الدفعة' : 'Edit Payment'}">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button class="btn btn-ghost btn-sm" onclick="SuppliersModule.deletePaymentTxn('${l.store}', ${l.id}, ${supp.id})" style="color:var(--danger)" title="${isAR ? 'إلغاء وحذف الدفعة' : 'Delete Payment'}">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                        </button>
                      ` : (l.store === 'purchase_invoices' || l.store === 'purchase_returns') ? `
                        <button class="btn btn-ghost btn-sm" onclick="window.Purchasing ? Purchasing.openDoc('${l.store}', ${l.id}) : null" title="${isAR ? 'عرض / تعديل الفاتورة' : 'View / Edit Doc'}">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                      ` : ''}
                    </div>
                  </td>
                </tr>
              `).join('') || `<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد حركات لـ هذا المورد' : 'No transactions'}</td></tr>`}
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:900;background:var(--surface-2)">
                <td colspan="3">${isAR ? 'الإجمالي' : 'Total'}</td>
                <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(totalDebit)}</td>
                <td style="text-align:right;color:var(--success)">${Utils.formatMoney(totalCredit)}</td>
                <td style="text-align:right;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>`;
    }
  }

  function filterSuppSummaryTable(q) {
    const query = (q || '').toLowerCase();
    document.querySelectorAll('#supp-summary-table tbody tr').forEach(row => {
      row.style.display = !query || row.dataset.name?.includes(query) ? '' : 'none';
    });
  }

  // ── Reports Hub (main landing page) ──────────────────────────
  let _currentReport = null;

  const REPORT_BADGE_AR_MAP = {
    'Daily Summary': 'ملخص يومي',
    'By Item': 'حسب الصنف',
    'By Customer': 'حسب العميل',
    'By Salesperson': 'حسب البائع',
    'Top Products': 'الأكثر مبيعاً',
    'Return Report': 'المرتجعات',
    'Stock on Hand': 'المخزون الحالي',
    'Stock Movement': 'حركة المخزون',
    'Low Stock': 'مخزون منخفض',
    'Damaged Items': 'البضاعة التالفة',
    'Stock Valuation': 'تقييم المخزون',
    'P&L Statement': 'الأرباح والخسائر',
    'Trial Balance': 'ميزان المراجعة',
    'Balance Sheet': 'الميزانية العمومية',
    'Cash Flow': 'التدفقات النقدية',
    'VAT Report': 'تقرير الضريبة',
    'Statement': 'كشف الحساب',
    'Aging Report': 'تقرير الاستحقاق',
    'Balance Summary': 'ملخص الأرصدة',
    'Top Customers': 'أهم العملاء',
    'Payment History': 'سجل المدفوعات',
    'AP Summary': 'ملخص الذمم الدائنة',
    'Attendance': 'الحضور والانصراف',
    'Payroll Summary': 'ملخص الرواتب',
    'Leave Report': 'تقرير الإجازات',
    'EOSG Report': 'مكافأة نهاية الخدمة',
    'All Branches': 'كافة الفروع',
    'Stock Matrix': 'مصفوفة المخزون',
    'Rebalance Alert': 'تنبيهات الموازنة',
    'Valuation': 'تقييم القيمة',
    'Tickets Summary': 'ملخص التذاكر',
    'Technicians Profit': 'أرباح الفنيين',
    'Parts Cost': 'تكلفة قطع الغيار',
    'Net Labor': 'صافي أجور العمل',
    'Cash vs Card': 'كاش مقابل شبكة',
    'Shift Close': 'إغلاق الوردية',
    'Cash Shortage': 'عجز وزيادة الصندوق',
    'Payment Audit': 'تدقيق المدفوعات',
    'Dead Stock': 'الرواكد التامة',
    'Locked Capital': 'رأس المال المجمد',
    'Zero Sales': 'مبيعات صفرية',
    'Clearance Alert': 'تنبيه التصفية',
    'Top Spenders': 'الأعلى إنفاقاً',
    'Most Profitable': 'الأعلى ربحية',
    'Visit Frequency': 'تكرار الزيارات',
    'Credit Status': 'حالة الائتمان',
    'Free Items': 'أصناف مجانية',
    'Promo Samples': 'عينات ترويجية',
    'Retail Impact': 'أثر البيع بالتجزئة',
    'Stock Card': 'كارت الصنف',
    'Running Balance': 'الرصيد التراكمي',
    'Full Timeline': 'المسار الزمني',
    'In/Out Log': 'سجل الدخول/الخروج',
    'Class A 80%': 'الفئة A (%80)',
    'Class B 15%': 'الفئة B (%15)',
    'Class C 5%': 'الفئة C (%5)',
    'Turnover Rate': 'معدل الدوران',
    'Audit Variance': 'فروقات التدقيق',
    'Stock Shrinkage': 'عجز وهدر المخزون',
    'Discrepancy Log': 'سجل الفروقات',
    'Reconciliation': 'المطابقة والتسوية'
  };

  function _arLabel(label) {
    return REPORT_BADGE_AR_MAP[label] || label;
  }

  let _hubActiveTab = 'combobox';
  let _selectedMasterType = 'sales';
  let _selectedMasterSub  = 'invoices';

  const MASTER_REPORT_CATALOG = {
    sales: {
      nameAR: '📊 تقارير المبيعات والأرباح',
      nameEN: '📊 Sales & Profit Reports',
      subOptions: [
        { id: 'invoices', nameAR: '🧾 فواتير المبيعات التفصيلية', nameEN: '🧾 Detailed Sales Invoices' },
        { id: 'top_products', nameAR: '🏆 المنتجات الأكثر مبيعاً', nameEN: '🏆 Top Selling Products' },
        { id: 'items', nameAR: '📦 مبيعات حسب الصنف', nameEN: '📦 Sales By Item' },
        { id: 'categories', nameAR: '📂 مبيعات حسب التصنيف', nameEN: '📂 By Category' },
        { id: 'customers', nameAR: '👥 مبيعات حسب العميل', nameEN: '👥 By Customer' },
        { id: 'salespersons', nameAR: '👤 مبيعات حسب البائع والكاشير', nameEN: '👤 By Salesperson' },
        { id: 'daily', nameAR: '📅 ملخص مبيعات يومي', nameEN: '📅 Daily Summary' },
        { id: 'returns', nameAR: '🔄 تقرير المرتجعات', nameEN: '🔄 Returns Report' }
      ]
    },
    stock: {
      nameAR: '📦 تقارير المخزون وحركة البضاعة',
      nameEN: '📦 Inventory & Stock Reports',
      subOptions: [
        { id: 'levels', nameAR: '📦 مستويات المخزون الحالي', nameEN: '📦 Current Stock on Hand' },
        { id: 'low_stock', nameAR: '⚠️ النواقص والأصناف المنخفضة', nameEN: '⚠️ Low & Out of Stock' },
        { id: 'movement', nameAR: '🔄 حركة المخزون والأرباح', nameEN: '🔄 Stock Movement Ledger' },
        { id: 'valuation', nameAR: '💰 تقييم المخزون المالي والتكلفة', nameEN: '💰 Stock Financial Valuation' }
      ]
    },
    pl: {
      nameAR: '💰 الأرباح والخسائر والقوائم المالية (P&L)',
      nameEN: '💰 Profit & Loss Statement (P&L)',
      subOptions: [
        { id: 'pl', nameAR: '📑 بيان الأرباح والخسائر الشامل (P&L)', nameEN: '📑 Comprehensive P&L Statement' },
        { id: 'trial_balance', nameAR: '⚖️ ميزان المراجعة بالمجاميع والأرصدة', nameEN: '⚖️ Trial Balance' },
        { id: 'balance_sheet', nameAR: '🏛️ الميزانية العمومية والمركز المالي', nameEN: '🏛️ Balance Sheet' },
        { id: 'cash_flow', nameAR: '💵 قائمة التدفقات النقدية (Cash Flow)', nameEN: '💵 Cash Flow Statement' },
        { id: 'vat', nameAR: '⚖️ إقرار وملخص ضريبة القيمة المضافة (VAT)', nameEN: '⚖️ VAT & Tax Summary' },
        { id: 'expenses', nameAR: '📉 تحليل وتفاصيل مصروفات التشغيل', nameEN: '📉 Operating Expenses Breakdown' }
      ]
    },
    'customer-ledger': {
      nameAR: '👥 كشف حساب العملاء والأرصدة',
      nameEN: '👥 Customer Ledger & Balances',
      dynamic: 'customers'
    },
    'supplier-ledger': {
      nameAR: '🏭 كشف حساب الموردين والمدفوعات',
      nameEN: '🏭 Supplier Ledger & Payables',
      dynamic: 'suppliers'
    },
    'cashier-reconciliation': {
      nameAR: '💳 تسوية ورديات الكاشير وصناديق المال',
      nameEN: '💳 Cashier Shift Reconciliation',
      dynamic: 'users'
    },
    'dead-stock': {
      nameAR: '⏳ تقرير الأصناف الراكدة وبطيئة الحركة',
      nameEN: '⏳ Slow-Moving & Dead Stock Report',
      subOptions: [
        { id: '30', nameAR: '30 يوماً بدون بيع', nameEN: '30 Days Inactive' },
        { id: '60', nameAR: '60 يوماً (المعيار الموصى به)', nameEN: '60 Days Inactive (Standard)' },
        { id: '90', nameAR: '90 يوماً (راكد حاد)', nameEN: '90 Days Inactive (Critical)' },
        { id: '180', nameAR: '180 يوماً (ميت بالكامل)', nameEN: '180 Days Inactive (Dead Stock)' }
      ]
    },
    'item-stock-card': {
      nameAR: '🔍 كشف حركة صنف مفصل (Stock Card)',
      nameEN: '🔍 Detailed Item Stock Card',
      dynamic: 'items'
    },
    'abc-analysis': {
      nameAR: '🏷️ تحليل تصنيف ABC للمخزون والدوران',
      nameEN: '🏷️ ABC Inventory Velocity Analysis',
      subOptions: [
        { id: '30', nameAR: 'فترة 30 يوماً', nameEN: 'Last 30 Days' },
        { id: '60', nameAR: 'فترة 60 يوماً', nameEN: 'Last 60 Days' },
        { id: '90', nameAR: 'فترة 90 يوماً', nameEN: 'Last 90 Days' },
        { id: '180', nameAR: 'فترة 180 يوماً', nameEN: 'Last 180 Days' },
        { id: '365', nameAR: 'سنة كاملة (365 يوماً)', nameEN: 'Full Year (365 Days)' }
      ]
    },
    'stock-audit': {
      nameAR: '⚖️ جرد المخزون الفعلي ومطابقة الفروقات',
      nameEN: '⚖️ Physical Stock Count Audit & Variances',
      subOptions: [
        { id: 'all', nameAR: '📋 جدول الجرد وفروقات المخزون', nameEN: '📋 Physical Count & Variances' },
        { id: 'variance', nameAR: '⚠️ الأصناف التي بها فروقات فقط', nameEN: '⚠️ Discrepancies Only' },
        { id: 'shortage', nameAR: '📉 عجز وهدر المخزون', nameEN: '📉 Inventory Shrinkage' },
        { id: 'surplus', nameAR: '📈 الزيادة في المخزون', nameEN: '📈 Stock Surplus' }
      ]
    },
    'multi-branch': {
      nameAR: '🏬 مقارنة مخزون الفروع والمستودعات',
      nameEN: '🏬 Multi-Branch Stock Comparison',
      subOptions: [
        { id: 'all', nameAR: '🏬 مصفوفة مقارنة كافة الفروع', nameEN: '🏬 All Branches Matrix' },
        { id: 'low_any', nameAR: '⚠️ ينقص أو غير متوفر في أي فرع', nameEN: '⚠️ Low or Zero in Any Branch' },
        { id: 'in_stock', nameAR: '✅ متوفر في كافة الفروع', nameEN: '✅ In Stock in All Branches' }
      ]
    },
    'repairs-report': {
      nameAR: '🛠️ أرباح الصيانة وأداء الفنيين',
      nameEN: '🛠️ Workshop Repairs & Technician Profit',
      subOptions: [
        { id: 'all', nameAR: '🛠️ سجل وإحصائيات ورش الصيانة', nameEN: '🛠️ Workshop & Repairs Summary' },
        { id: 'delivered', nameAR: '✅ الأجهزة المكتملة والمسلمة', nameEN: '✅ Completed & Delivered' },
        { id: 'in_progress', nameAR: '⏳ أجهزة قيد الفحص والإصلاح', nameEN: '⏳ In Progress / Diagnosing' },
        { id: 'technicians', nameAR: '👨‍🔧 تقييم وإنتاجية الفنيين', nameEN: '👨‍🔧 Technicians Productivity' }
      ]
    },
    'top-customers': {
      nameAR: '👑 كبار العملاء الأكثر شراءً وربحية',
      nameEN: '👑 Top VIP Customers Ranking',
      subOptions: [
        { id: 'profit', nameAR: '💰 ترتيب حسب صافي الربح المحقق', nameEN: '💰 Highest Net Profit' },
        { id: 'spend', nameAR: '💳 ترتيب حسب إجمالي المشتريات', nameEN: '💳 Highest Total Spend' },
        { id: 'invoices', nameAR: '🧾 ترتيب حسب عدد الفواتير', nameEN: '🧾 Most Invoices' },
        { id: 'balance', nameAR: '⚠️ ترتيب حسب أعلى ديون مستحقة', nameEN: '⚠️ Highest Debt Balance' }
      ]
    },
    gift: {
      nameAR: '🎁 تقرير حركة الهدايا والعينات المجانية',
      nameEN: '🎁 Gifts & Promotional Samples',
      subOptions: [
        { id: 'all', nameAR: '🎁 سجل العينات والهدايا الموزعة', nameEN: '🎁 Distributed Gifts & Samples' },
        { id: 'by_item', nameAR: '📦 تجميع حسب الصنف المهدى', nameEN: '📦 Grouped by Item' }
      ]
    },
    attendance: {
      nameAR: '⏱️ تقارير الحضور والدوام',
      nameEN: '⏱️ Employee Attendance Report',
      subOptions: [
        { id: 'all', nameAR: '⏱️ سجلات دوام الموظفين (الكل)', nameEN: '⏱️ All Attendance Records' },
        { id: 'present', nameAR: '✅ سجلات الحضور فقط', nameEN: '✅ Present Only' },
        { id: 'late', nameAR: '⏰ سجلات التأخير', nameEN: '⏰ Late Records' },
        { id: 'absent', nameAR: '❌ سجلات الغياب', nameEN: '❌ Absent Records' }
      ]
    },
    analytics: {
      nameAR: '📈 الرسوم البيانية والتحليلات المرئية',
      nameEN: '📈 Visual Charts & Analytics Graphs',
      subOptions: [
        { id: 'today', nameAR: '📅 مؤشرات ورسوم اليوم', nameEN: '📅 Today Analytics' },
        { id: '7days', nameAR: '📊 آخر 7 أيام', nameEN: '📊 Last 7 Days' },
        { id: 'month', nameAR: '📈 هذا الشهر', nameEN: '📈 This Month' },
        { id: 'year', nameAR: '🏆 هذه السنة', nameEN: '🏆 This Year' },
        { id: 'all', nameAR: '🌐 كافة الفترات', nameEN: '🌐 All Time' }
      ]
    },
    restaurant: {
      nameAR: '🍽️ تقارير المطاعم والمأكولات',
      nameEN: '🍽️ Restaurant & Food Reports',
      subOptions: [
        { id: 'invoices', nameAR: '🧾 فواتير المطعم التفصيلية', nameEN: '🧾 Restaurant Invoices' },
        { id: 'menu', nameAR: '🍽️ مبيعات قائمة الطعام والأطباق', nameEN: '🍽️ Menu Items Sales' },
        { id: 'dining', nameAR: '🪑 الصالة والطلبات الداخلية', nameEN: '🪑 Dine-In Orders' },
        { id: 'delivery', nameAR: '🛵 طلبات التوصيل والدليفري', nameEN: '🛵 Delivery Orders' },
        { id: 'takeaway', nameAR: '🛍️ طلبات السفري والاستلام', nameEN: '🛍️ Takeaway Orders' },
        { id: 'tables', nameAR: '🏷️ إحصائيات وأداء الطاولات', nameEN: '🏷️ Tables Performance' },
        { id: 'drivers', nameAR: '🛵 أداء سائقي التوصيل', nameEN: '🛵 Delivery Drivers' },
        { id: 'periods', nameAR: '⏱️ ساعات الذروة والوجبات', nameEN: '⏱️ Peak Rush Hours' }
      ]
    }
  };

  function switchHubTab(tab) {
    _hubActiveTab = tab;
    const content = document.getElementById('page-content');
    render(content);
  }

  function toggleCardsMode() {
    _hubActiveTab = (_hubActiveTab === 'cards') ? 'combobox' : 'cards';
    render(document.getElementById('page-content'));
  }

  function applyDatePreset(preset) {
    const today = Utils.today();
    const fromEl = document.getElementById('rep-from');
    const toEl   = document.getElementById('rep-to');
    if (!fromEl || !toEl) return;

    let fromVal = today;
    let toVal = today;

    if (preset === 'today') {
      fromVal = today;
      toVal = today;
    } else if (preset === 'yesterday') {
      const d = new Date();
      d.setDate(d.getDate() - 1);
      fromVal = d.toISOString().slice(0, 10);
      toVal = fromVal;
    } else if (preset === 'week') {
      const d = new Date();
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(d.setDate(diff));
      fromVal = monday.toISOString().slice(0, 10);
      toVal = today;
    } else if (preset === 'month') {
      fromVal = `${today.slice(0, 7)}-01`;
      toVal = today;
    } else if (preset === 'year') {
      fromVal = `${today.slice(0, 4)}-01-01`;
      toVal = today;
    } else if (preset === 'all') {
      fromVal = '';
      toVal = '';
    }

    fromEl.value = fromVal;
    toEl.value = toVal;

    document.querySelectorAll('.rep-preset-btn').forEach(btn => {
      if (btn.dataset.preset === preset) {
        btn.className = 'btn btn-sm btn-primary rep-preset-btn';
        btn.style.boxShadow = '0 2px 6px rgba(99,102,241,0.25)';
      } else {
        btn.className = 'btn btn-sm btn-ghost rep-preset-btn';
        btn.style.boxShadow = 'none';
      }
    });

    if (_selectedMasterType === 'sales') {
      loadSalesData();
    } else {
      runMasterReport();
    }
  }

  function onDateInputChange() {
    document.querySelectorAll('.rep-preset-btn').forEach(btn => {
      btn.className = 'btn btn-sm btn-ghost rep-preset-btn';
      btn.style.boxShadow = 'none';
    });
    if (_selectedMasterType === 'sales') {
      loadSalesData();
    } else {
      runMasterReport();
    }
  }

  function onBranchFilterChange() {
    if (_selectedMasterType === 'sales') {
      loadSalesData();
    } else {
      runMasterReport();
    }
  }

  function filterTableRows(query) {
    const q = (query || '').toLowerCase().trim();
    const rows = document.querySelectorAll('#rep-table-wrapper tbody tr:not([id^="rep-inv-detail-"]):not([id^="rep-top-"])');
    rows.forEach(tr => {
      const text = tr.textContent.toLowerCase();
      tr.style.display = (!q || text.includes(q)) ? '' : 'none';
    });
  }

  function printActiveReport() {
    switch (_selectedMasterType) {
      case 'sales': Reports.printSalesReport(); break;
      case 'stock': Reports.printStockReport(); break;
      case 'pl':
      case 'finance': Reports.printPLReport(); break;
      default: window.print(); break;
    }
  }

  function exportActiveReport() {
    switch (_selectedMasterType) {
      case 'sales': Reports.exportSalesReport(); break;
      case 'stock': Reports.exportStockReport(); break;
      case 'pl':
      case 'finance': Reports.exportPLReport(); break;
      default:
        const table = document.querySelector('#master-report-render-target table, .table-wrapper table');
        if (table && window.Utils && typeof Utils.exportTableToCSV === 'function') {
          Utils.exportTableToCSV(table, `${_selectedMasterType}_report.csv`);
        } else {
          Utils.toast(i18n.getLang() === 'ar' ? 'جاري تصدير التقرير...' : 'Exporting report...', 'info');
        }
        break;
    }
  }

  async function onMasterReportTypeChange(repType) {
    _selectedMasterType = repType;
    const subSelect = document.getElementById('master-rep-sub');
    if (!subSelect) return;
    const isAR = i18n.getLang() === 'ar';
    const def = MASTER_REPORT_CATALOG[repType];
    if (!def) return;

    let optionsHtml = '';
    if (def.dynamic === 'customers') {
      const customers = (await DB.getAll('customers')) || [];
      optionsHtml = `<option value="all">-- ${isAR ? 'جميع العملاء (جدول الأرصدة العام)' : 'All Customers (General Balances)'} --</option>` +
        customers.map(c => `<option value="${c.id}">${isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar)} (الرصيد: ${Utils.formatMoney(c.balance || 0)})</option>`).join('');
    } else if (def.dynamic === 'suppliers') {
      const suppliers = (await DB.getAll('suppliers')) || [];
      optionsHtml = `<option value="all">-- ${isAR ? 'جميع الموردين (جدول الأرصدة العام)' : 'All Suppliers (General Balances)'} --</option>` +
        suppliers.map(s => `<option value="${s.id}">${isAR ? (s.name_ar || s.name || s.name_en) : (s.name_en || s.name || s.name_ar)} (الرصيد: ${Utils.formatMoney(s.balance || 0)})</option>`).join('');
    } else if (def.dynamic === 'items') {
      const items = (await DB.getAll('items')) || [];
      optionsHtml = items.map(i => {
        const nm = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
        return `<option value="${i.id}">[${i.item_code || '-'}] ${nm}</option>`;
      }).join('');
    } else if (def.dynamic === 'users') {
      const users = (await DB.getAll('users')) || [];
      optionsHtml = `<option value="all">-- ${isAR ? 'جميع موظفي الكاشير' : 'All Cashiers'} --</option>` +
        users.map(u => `<option value="${u.username}">${u.full_name || u.username}</option>`).join('');
    } else if (def.subOptions) {
      optionsHtml = def.subOptions.map(o => `<option value="${o.id}">${isAR ? o.nameAR : o.nameEN}</option>`).join('');
    }

    subSelect.innerHTML = optionsHtml;
    _selectedMasterSub = subSelect.value;
    await runMasterReport();
  }

  function onMasterReportSubChange(subVal) {
    _selectedMasterSub = subVal;
    if (_selectedMasterType === 'sales') {
      switchSubTab(subVal);
    } else {
      runMasterReport();
    }
  }

  function resetMasterReport() {
    _selectedMasterType = 'sales';
    _selectedMasterSub = 'invoices';
    const typeSelect = document.getElementById('master-rep-type');
    if (typeSelect) typeSelect.value = 'sales';
    applyDatePreset('month');
    onMasterReportTypeChange('sales');
  }

  async function runMasterReport() {
    const typeSelect = document.getElementById('master-rep-type');
    const subSelect  = document.getElementById('master-rep-sub');
    const repType = typeSelect ? typeSelect.value : _selectedMasterType;
    const repSub  = subSelect  ? subSelect.value  : _selectedMasterSub;
    _selectedMasterType = repType;
    _selectedMasterSub = repSub;

    // Update active badge in toolbar
    const badgeTitle = document.getElementById('rep-active-badge-title');
    if (badgeTitle) {
      const isAR = i18n.getLang() === 'ar';
      const def = MASTER_REPORT_CATALOG[repType];
      if (def) {
        badgeTitle.innerHTML = `${isAR ? def.nameAR : def.nameEN}`;
      }
    }

    const target = document.getElementById('master-report-render-target');
    if (!target) return;

    target.innerHTML = `<div style="text-align:center;padding:35px;color:var(--text-muted);font-weight:700">⏳ ${i18n.getLang() === 'ar' ? 'جاري تحميل التقرير...' : 'Loading report...'}</div>`;

    try {
    switch (repType) {
      case 'sales':
        await renderSalesReport(target, repSub);
        break;
      case 'stock':
        await renderStockReport(target, repSub);
        break;
      case 'pl':
      case 'finance':
        await renderFinanceReport(target, repSub);
        break;
      case 'customer-ledger':
        await renderCustomerLedger(target, repSub);
        break;
      case 'supplier-ledger':
        await renderSupplierLedger(target, repSub);
        break;
      case 'cashier-reconciliation':
        await renderCashierReconciliationReport(target);
        if (repSub && repSub !== 'all') {
          const userEl = document.getElementById('recon-user');
          if (userEl) {
            userEl.value = repSub;
            await loadCashierReconData();
          }
        }
        break;
      case 'dead-stock':
        await renderDeadStockReport(target);
        if (repSub) {
          const thEl = document.getElementById('dead-threshold');
          if (thEl) {
            thEl.value = repSub;
            await loadDeadStockData();
          }
        }
        break;
      case 'item-stock-card':
        await renderItemStockCardReport(target);
        if (repSub) {
          const itemEl = document.getElementById('sc-item-select');
          if (itemEl) {
            itemEl.value = repSub;
            await loadItemStockCardData();
          }
        }
        break;
      case 'abc-analysis':
        await renderABCAnalysisReport(target);
        if (repSub) {
          const perEl = document.getElementById('abc-period');
          if (perEl) {
            perEl.value = repSub;
            await loadABCAnalysisData();
          }
        }
        break;
      case 'stock-audit':
        await renderStockAuditVarianceReport(target, repSub);
        break;
      case 'multi-branch':
        await renderMultiBranchStockReport(target, repSub);
        break;
      case 'repairs-report':
        await renderRepairsReport(target, repSub);
        break;
      case 'top-customers':
        await renderTopCustomersReport(target, repSub);
        break;
      case 'gift':
        await renderGiftReport(target, repSub);
        break;
      case 'attendance':
        await renderAttReport(target, repSub);
        break;
      case 'analytics':
        await renderAnalyticsGraphs(target, repSub);
        break;
      case 'restaurant':
        {
          const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function') 
            ? License.getCachedBusinessMode() 
            : 'retail';
          if (bMode !== 'retail') {
            await renderRestaurantReport(target, repSub);
          } else {
            await renderSalesReport(target, 'invoices');
          }
        }
        break;
      default:
        await renderSalesReport(target, 'invoices');
        break;
    }
    } catch (err) {
      console.error('[Reports] Error running master report:', err);
      const isAR = (typeof i18n !== 'undefined' && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : true;
      target.innerHTML = `<div style="text-align:center;padding:60px 20px;color:var(--danger);font-weight:700">
        <div style="font-size:2.5rem;margin-bottom:10px">⚠️</div>
        <div style="font-size:1.15rem;margin-bottom:8px">${isAR ? 'تعذر تحميل التقرير المطلوب' : 'Failed to generate report'}</div>
        <div style="font-size:0.85rem;color:var(--text-muted);max-width:500px;margin:0 auto;line-height:1.5;">${err.message || err}</div>
      </div>`;
    }
  }

  async function render(container) {
    if (!container) container = document.getElementById('page-content');
    const isAR = i18n.getLang() === 'ar';
    _currentReport = null;

    const bMode = (typeof License !== 'undefined' && typeof License.getBusinessMode === 'function') 
      ? await License.getBusinessMode() 
      : await DB.getSetting('business_mode', 'retail');

    if (bMode === 'retail' && _selectedMasterType === 'restaurant') {
      _selectedMasterType = 'sales';
    }

    const today = Utils.today();
    const thisMonth = today.slice(0, 7);

    // Collect branches & nodes
    let isServerNode = true;
    let myBranch = 'main';
    let myNode = 'SRV-01';
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      try {
        const sc = await BranchSync.getConfig();
        isServerNode = (sc.role === 'server');
        myBranch = sc.branchId || 'main';
        myNode = sc.nodeId || 'SRV-01';
      } catch(e) {}
    }

    const branchOptions = new Set();
    const enrichedSales = await _getEnrichedSales();
    enrichedSales.forEach(s => {
      const b = s.syncBranchId || s.branch_id || s.syncNodeId || s.terminal_id;
      if (b && b !== 'undefined' && b !== 'null') branchOptions.add(b);
    });

    try {
      const sessions = (await DB.getAll('cashbox_sessions')) || [];
      sessions.forEach(s => {
        if (s.terminal_id) branchOptions.add(s.terminal_id);
      });
      const warehouses = (await DB.getAll('warehouses')) || [];
      warehouses.forEach(w => {
        if (w.name) branchOptions.add(w.name);
      });
      if (isServerNode) {
        const nRes = await fetch('/api/sync/nodes');
        if (nRes.ok) {
          const nj = await nRes.json();
          (nj.nodes || []).forEach(n => {
            if (n.nodeId) branchOptions.add(n.nodeId);
          });
        }
      }
    } catch(e) {}

    const branchSelectHtml = isServerNode ? `
      <select class="form-control" id="rep-branch-filter" style="font-weight:700;height:38px;border-radius:8px;font-size:0.82rem" onchange="Reports.onBranchFilterChange()">
        <option value="all">🏢 ${isAR ? 'كافة الفروع والمحطات' : 'All Branches & Stations'}</option>
        <option value="main">🖥️ ${isAR ? 'الفرع الرئيسي (السيرفر)' : 'Main Store (Server)'}</option>
        ${Array.from(branchOptions).filter(b => b !== 'main').map(b => `<option value="${b}">🏬 ${b}</option>`).join('')}
      </select>
    ` : `
      <div style="height:38px;padding:8px 12px;background:rgba(255,255,255,0.04);border:1px solid var(--border-color);border-radius:8px;font-weight:800;color:var(--primary);font-size:0.82rem;display:flex;align-items:center">
        🏬 ${myBranch} (${myNode})
      </div>
      <input type="hidden" id="rep-branch-filter" value="${myBranch}">
    `;

    let subOptionsHtml = '';
    const def = MASTER_REPORT_CATALOG[_selectedMasterType] || MASTER_REPORT_CATALOG.sales;
    if (def.dynamic === 'customers') {
      const customers = (await DB.getAll('customers')) || [];
      subOptionsHtml = `<option value="all">-- ${isAR ? 'جميع العملاء (جدول الأرصدة العام)' : 'All Customers (General Balances)'} --</option>` +
        customers.map(c => `<option value="${c.id}" ${_selectedMasterSub == c.id ? 'selected' : ''}>${isAR ? (c.name_ar || c.name_en) : (c.name_en || c.name_ar)} (الرصيد: ${Utils.formatMoney(c.balance || 0)})</option>`).join('');
    } else if (def.dynamic === 'suppliers') {
      const suppliers = (await DB.getAll('suppliers')) || [];
      subOptionsHtml = `<option value="all">-- ${isAR ? 'جميع الموردين (جدول الأرصدة العام)' : 'All Suppliers (General Balances)'} --</option>` +
        suppliers.map(s => `<option value="${s.id}" ${_selectedMasterSub == s.id ? 'selected' : ''}>${isAR ? (s.name_ar || s.name || s.name_en) : (s.name_en || s.name || s.name_ar)} (الرصيد: ${Utils.formatMoney(s.balance || 0)})</option>`).join('');
    } else if (def.dynamic === 'items') {
      const items = (await DB.getAll('items')) || [];
      subOptionsHtml = items.map(i => {
        const nm = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
        return `<option value="${i.id}" ${_selectedMasterSub == i.id ? 'selected' : ''}>[${i.item_code || '-'}] ${nm}</option>`;
      }).join('');
    } else if (def.dynamic === 'users') {
      const users = (await DB.getAll('users')) || [];
      subOptionsHtml = `<option value="all">-- ${isAR ? 'جميع موظفي الكاشير' : 'All Cashiers'} --</option>` +
        users.map(u => `<option value="${u.username}" ${_selectedMasterSub === u.username ? 'selected' : ''}>${u.full_name || u.username}</option>`).join('');
    } else if (def.subOptions) {
      subOptionsHtml = def.subOptions.map(o => `<option value="${o.id}" ${_selectedMasterSub === o.id ? 'selected' : ''}>${isAR ? o.nameAR : o.nameEN}</option>`).join('');
    }

    const typeOptionsHtml = Object.keys(MASTER_REPORT_CATALOG).filter(k => {
      if (bMode === 'retail' && k === 'restaurant') return false;
      return true;
    }).map(k => {
      const it = MASTER_REPORT_CATALOG[k];
      return `<option value="${k}" ${_selectedMasterType === k ? 'selected' : ''}>${isAR ? it.nameAR : it.nameEN}</option>`;
    }).join('');

    container.innerHTML = `
    <div class="animate-slide">
      <!-- Executive Page Header -->
      <div class="page-header" style="margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:12px">
            <div style="width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,var(--primary),#6366f1);display:flex;align-items:center;justify-content:center;color:white;font-size:22px;box-shadow:0 4px 14px rgba(99,102,241,0.25)">📊</div>
            <div>
              <h1 style="margin:0;font-size:1.35rem;font-weight:900">${isAR ? 'مركز التقارير والتحليلات' : 'Reports & Analytics Center'}</h1>
              <p style="margin:2px 0 0 0;font-size:0.8rem;color:var(--text-secondary)">${isAR ? 'تحليل شامل ومؤشرات ذكية للمبيعات، المخزون، والأرباح المالية' : 'Real-time sales, inventory, profit margins and financial intelligence'}</p>
            </div>
          </div>
        </div>
        <div class="page-actions" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <button class="btn btn-success btn-sm" onclick="Reports.openDailyDigestModal()" style="display:flex;align-items:center;gap:6px;font-weight:700;border-radius:8px;padding:6px 12px">
            <span>📱</span> ${isAR ? 'ملخص الإغلاق (واتساب)' : 'Daily Digest'}
          </button>
          <button class="btn btn-secondary btn-sm" onclick="Reports.printActiveReport()" style="display:flex;align-items:center;gap:6px;font-weight:700;border-radius:8px;padding:6px 12px">
            <span>🖨️</span> ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary btn-sm" onclick="Reports.exportActiveReport()" style="display:flex;align-items:center;gap:6px;font-weight:700;border-radius:8px;padding:6px 12px">
            <span>📥</span> ${isAR ? 'تصدير' : 'Export'}
          </button>
          <button class="btn ${_hubActiveTab === 'cards' ? 'btn-primary' : 'btn-ghost'} btn-sm" onclick="Reports.toggleCardsMode()" style="font-weight:700;border-radius:8px;padding:6px 12px" title="${isAR ? 'عرض كافة بطاقات وأقسام التقارير' : 'Toggle Categories Overview'}">
            🗂️ ${isAR ? (_hubActiveTab === 'cards' ? 'المستعرض المباشر' : 'دليل الأقسام') : (_hubActiveTab === 'cards' ? 'Live Explorer' : 'All Categories')}
          </button>
        </div>
      </div>

      ${_hubActiveTab === 'cards' ? `
      <!-- Report Categories Grid View -->
      <div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;background:var(--surface-card);border:1px solid var(--border-color);border-radius:10px;padding:10px 16px">
        <span style="font-weight:800;font-size:0.9rem;color:var(--text-primary)">🗂️ ${isAR ? 'اختر قسماً للاستعراض المباشر أو التحليل' : 'Select a category to view reports'}</span>
        <button class="btn btn-sm btn-primary" onclick="Reports.toggleCardsMode()" style="font-weight:700;border-radius:8px">
          ← ${isAR ? 'المستعرض المباشر' : 'Back to Explorer'}
        </button>
      </div>
      <div class="grid grid-3" style="gap:16px">

        <!-- Visual Analytics & Modern Graphs Featured Card -->
        <div class="card" style="grid-column:1/-1;cursor:pointer;background:linear-gradient(135deg, rgba(168,85,247,0.15) 0%, rgba(99,102,241,0.15) 100%);border:1px solid rgba(168,85,247,0.3);box-shadow:0 8px 24px rgba(168,85,247,0.08)" onclick="Reports._nav('analytics')">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:16px">
              <div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#a855f7,#6366f1);display:flex;align-items:center;justify-content:center;font-size:28px;color:white;box-shadow:0 6px 16px rgba(168,85,247,0.4)">📈</div>
              <div>
                <div style="font-weight:800;font-size:1.15rem;color:var(--text-primary);display:flex;align-items:center;gap:8px">
                  ${isAR ? 'الرسوم البيانية والتحليلات المرئية المتقدمة' : 'Modern Interactive Analytics & Visual Graphs'}
                  <span class="badge" style="background:#a855f7;color:white;font-size:0.65rem">${isAR ? 'جديد ✨' : 'NEW ✨'}</span>
                </div>
                <div style="font-size:0.82rem;color:var(--text-secondary);margin-top:2px">${isAR ? 'رسوم تفاعلية لمسار الإيرادات والأرباح، ساعات الذروة، تصنيفات المبيعات، وأفضل المنتجات' : 'Interactive charts for daily revenue, profit margins, peak rush hours, category share & top products'}</div>
              </div>
            </div>
            <button class="btn btn-primary btn-sm" style="background:linear-gradient(135deg,#a855f7,#6366f1);border:none;padding:8px 16px;border-radius:10px;font-weight:700">
              ${isAR ? 'عرض الرسوم البيانية ←' : 'Open Visual Graphs →'}
            </button>
          </div>
        </div>


        <!-- Sales Reports -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderSalesReport()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(16,185,129,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">📊</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'تقارير المبيعات والأرباح' : 'Sales & Profit Reports'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'ملخص، حسب الصنف، العميل، البائع، الأكثر مبيعاً' : 'Summary, by item, customer, salesperson, top products'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge badge-success" style="cursor:pointer;font-weight:800;background:#10b981;color:white" onclick="event.stopPropagation(); Reports.renderSalesReport(null, 'top_products')">🏆 ${isAR ? 'الأكثر مبيعاً' : 'Top Products'}</span>
            <span class="badge badge-success" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderSalesReport(null, 'items')">${isAR ? 'حسب الصنف' : 'By Item'}</span>
            <span class="badge badge-success" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderSalesReport(null, 'customers')">${isAR ? 'حسب العميل' : 'By Customer'}</span>
            <span class="badge badge-success" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderSalesReport(null, 'salespersons')">${isAR ? 'حسب البائع' : 'By Salesperson'}</span>
            <span class="badge badge-success" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderSalesReport(null, 'daily')">${isAR ? 'ملخص يومي' : 'Daily Summary'}</span>
            <span class="badge badge-success" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderSalesReport(null, 'returns')">${isAR ? 'المرتجعات' : 'Return Report'}</span>
          </div>
        </div>

        ${bMode !== 'retail' ? `
        <!-- Restaurant & Dining Reports -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderRestaurantReport()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(239,68,68,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🍽️</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'تقارير المطاعم والمأكولات والصالة' : 'Restaurant & Dining Floor Reports'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'مبيعات الأطباق، الطاولات، الدليفري، والسفري' : 'Menu sales, tables performance, delivery, takeaway'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderRestaurantReport(null, 'overview')">📊 ${isAR ? 'ملخص عام' : 'Overview'}</span>
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderRestaurantReport(null, 'dining')">🪑 ${isAR ? 'الصالة' : 'Dine-In'}</span>
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderRestaurantReport(null, 'delivery')">🛵 ${isAR ? 'الدليفري' : 'Delivery'}</span>
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderRestaurantReport(null, 'takeaway')">🛍️ ${isAR ? 'السفري' : 'Takeaway'}</span>
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderRestaurantReport(null, 'tables')">🏷️ ${isAR ? 'الطاولات' : 'Tables'}</span>
          </div>
        </div>
        ` : ''}

        <!-- Inventory Reports -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderStockReport()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(245,158,11,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">📦</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'تقارير المخزون وحركة البضاعة' : 'Inventory & Stock Reports'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'المخزون الحالي، النواقص، الحركة، التقييم' : 'Stock on hand, low stock, movement, valuation'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge badge-warning" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderStockReport(null, 'levels')">${isAR ? 'المخزون الحالي' : 'Stock on Hand'}</span>
            <span class="badge badge-warning" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderStockReport(null, 'low_stock')">${isAR ? 'مخزون منخفض' : 'Low Stock'}</span>
            <span class="badge badge-warning" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderStockReport(null, 'movement')">${isAR ? 'حركة المخزون' : 'Stock Movement'}</span>
            <span class="badge badge-warning" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderStockReport(null, 'valuation')">${isAR ? 'تقييم المخزون' : 'Stock Valuation'}</span>
            <span class="badge badge-warning" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('damage')">${isAR ? 'البضاعة التالفة' : 'Damaged Items'}</span>
          </div>
        </div>

        <!-- Finance Reports -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderPLReport()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(0,180,216,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">💰</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'التقارير المالية (الأرباح والخسائر)' : 'Financial Reports (P&L)'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الأرباح والخسائر، ميزان المراجعة، الضرائب' : 'P&L, trial balance, balance sheet, VAT'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge badge-primary" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderPLReport()">${isAR ? 'الأرباح والخسائر' : 'P&L Statement'}</span>
            <span class="badge badge-primary" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('journals')">${isAR ? 'القيود اليومية' : 'Journals'}</span>
            <span class="badge badge-primary" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('accounts')">${isAR ? 'ميزان المراجعة' : 'Trial Balance'}</span>
            <span class="badge badge-primary" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('vat')">${isAR ? 'إقرار الضريبة VAT' : 'VAT Report'}</span>
          </div>
        </div>

        <!-- Customer Ledger -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderCustomerLedger()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(139,92,246,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">👥</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'كشف حساب العملاء' : 'Customer Ledger'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الرصيد، كشف الحساب، كبار العملاء' : 'Balances, receivables, top customers'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge" style="background:rgba(139,92,246,0.15);color:#8B5CF6;cursor:pointer" onclick="event.stopPropagation(); Reports.renderCustomerLedger()">${isAR ? 'كشف الحساب' : 'Statement'}</span>
            <span class="badge" style="background:rgba(139,92,246,0.15);color:#8B5CF6;cursor:pointer" onclick="event.stopPropagation(); Reports.renderTopCustomersReport()">👑 ${isAR ? 'كبار العملاء' : 'Top Customers'}</span>
            <span class="badge" style="background:rgba(139,92,246,0.15);color:#8B5CF6;cursor:pointer" onclick="event.stopPropagation(); App.navigate('customers')">${isAR ? 'دليل العملاء' : 'Customer List'}</span>
          </div>
        </div>

        <!-- Supplier Ledger -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderSupplierLedger()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(239,68,68,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🏭</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'كشف حساب الموردين' : 'Supplier Ledger'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'المدفوعات، الأرصدة، المستحقات' : 'Payments, balances, payables'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderSupplierLedger()">${isAR ? 'كشف الحساب' : 'Statement'}</span>
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('suppliers')">${isAR ? 'دليل الموردين' : 'Supplier Directory'}</span>
            <span class="badge badge-danger" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('supplier-payments')">${isAR ? 'سجل المدفوعات' : 'Payment History'}</span>
          </div>
        </div>

        <!-- HR Reports -->
        <div class="card" style="cursor:pointer" onclick="Reports.renderAttReport()">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(16,185,129,0.1);display:flex;align-items:center;justify-content:center;font-size:24px">👤</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'تقارير الموارد البشرية' : 'HR Reports'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الحضور، الرواتب، الإجازات، نهاية الخدمة' : 'Attendance, payroll, leave, EOSG'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            <span class="badge badge-secondary" style="cursor:pointer" onclick="event.stopPropagation(); Reports.renderAttReport()">${isAR ? 'سجل الحضور' : 'Attendance'}</span>
            <span class="badge badge-secondary" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('payroll')">${isAR ? 'مسير الرواتب' : 'Payroll Summary'}</span>
            <span class="badge badge-secondary" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('leave')">${isAR ? 'الإجازات' : 'Leave Report'}</span>
            <span class="badge badge-secondary" style="cursor:pointer" onclick="event.stopPropagation(); App.navigate('eosg')">${isAR ? 'مكافأة نهاية الخدمة' : 'EOSG Report'}</span>
          </div>
        </div>

        <!-- 1. Multi-Branch Stock Matrix -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('multi-branch')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(59,130,246,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🏬</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'مقارنة مخزون الفروع والمستودعات' : 'Multi-Branch Stock Matrix'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'مقارنة كميات وتقييم بضاعة كل فرع جنباً إلى جنب' : 'Side-by-side branch inventory comparison'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['All Branches','Stock Matrix','Rebalance Alert','Valuation'].map(r =>
              `<span class="badge badge-primary">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 2. Repairs & Workshop Profitability -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('repairs-report')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(6,182,212,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🛠️</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'أرباح الصيانة وأداء الفنيين' : 'Repairs & Workshop Report'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'تكلفة قطع الغيار، أجور اليد، وإنتاجية الفنيين' : 'Spare parts cost, labor fees, technician revenue'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Tickets Summary','Technicians Profit','Parts Cost','Net Labor'].map(r =>
              `<span class="badge" style="background:rgba(6,182,212,0.15);color:#06b6d4">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 3. Cashier Shift Reconciliation -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('cashier-reconciliation')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(234,179,8,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">💳</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'تسوية ورديات الكاشير وطرق الدفع' : 'Cashier Shift Reconciliation'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'مبيعات الكاش، الفيزا، الديون، والعجز والزيادة' : 'Cash, Visa/Cards, Customer Debt & register variances'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Cash vs Card','Shift Close','Cash Shortage','Payment Audit'].map(r =>
              `<span class="badge badge-warning">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 4. Slow-Moving & Dead Stock -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('dead-stock')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(249,115,22,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">⏳</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'الأصناف الراكدة وبطيئة الحركة' : 'Slow-Moving & Dead Stock'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'السلع التي لم تبع في آخر 30-90 يوماً ورأس المال المجمد' : 'Items with zero sales and locked capital'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Dead Stock','Locked Capital','Zero Sales','Clearance Alert'].map(r =>
              `<span class="badge" style="background:rgba(249,115,22,0.15);color:#f97316">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 5. Top VIP Customers & Profitability Ranking -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('top-customers')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(168,85,247,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">👑</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'كبار العملاء وتصنيف الربحية' : 'VIP Customers & Profitability'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'أكثر العملاء تحقيقاً للأرباح والمشتريات وحالة الديون' : 'Customer ranking by net profit generated'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Top Spenders','Most Profitable','Visit Frequency','Credit Status'].map(r =>
              `<span class="badge" style="background:rgba(168,85,247,0.15);color:#a855f7">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- Free Gifts & Samples -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('gift')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(236,72,153,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🎁</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'الهدايا والعينات المجانية' : 'Gifts & Free Samples'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'الأصناف المصروفة بقيمة صفر وتكلفتها' : 'Promotional free items log'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Free Items','Promo Samples','Retail Impact'].map(r =>
              `<span class="badge" style="background:rgba(236,72,153,0.15);color:#ec4899">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 6. Single Item 360 Stock Card -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('item-stock-card')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(14,165,233,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🔍</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'كارت الصنف الشامل ومسار الحركة' : 'Single Item 360° Stock Card'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'سجل تفصيلي لحركة الصنف: مبيعات، مشتريات، مرتجعات، وتحويلات' : 'Complete item lifecycle & running stock balance audit'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Stock Card','Running Balance','Full Timeline','In/Out Log'].map(r =>
              `<span class="badge" style="background:rgba(14,165,233,0.15);color:#0ea5e9">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 7. ABC Inventory Classification & Turnover Velocity -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('abc-analysis')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(34,197,94,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">🏆</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'تحليل تصنيف المخزون ABC ومعدل الدوران' : 'ABC Inventory Velocity Analysis'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'تصنيف بضائع الفئة A (الأكثر مبيعاً) والفئة B وC ومعدل الدوران' : 'Pareto 80/20 ABC ranking & Days Sales of Inventory (DSI)'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Class A 80%','Class B 15%','Class C 5%','Turnover Rate'].map(r =>
              `<span class="badge" style="background:rgba(34,197,94,0.15);color:#22c55e">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

        <!-- 8. Physical Stock Count Audit & Discrepancy -->
        <div class="card" style="cursor:pointer" onclick="Reports._nav('stock-audit')">
          <div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">
            <div style="width:48px;height:48px;border-radius:12px;background:rgba(239,68,68,0.15);display:flex;align-items:center;justify-content:center;font-size:24px">⚖️</div>
            <div>
              <div style="font-weight:700;font-size:1rem">${isAR ? 'مطابقة وفروقات الجرد الفعلي' : 'Physical Stock Count Audit'}</div>
              <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'مقارنة الجرد الفعلي بالرصيد الدفتري، العجز والزيادة، وخسائر الهدر' : 'System vs counted variances & shrinkage loss calculation'}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px">
            ${['Audit Variance','Stock Shrinkage','Discrepancy Log','Reconciliation'].map(r =>
              `<span class="badge badge-danger">${isAR ? _arLabel(r) : r}</span>`
            ).join('')}
          </div>
        </div>

      </div>
      ` : `
      <!-- Unified Modern Control Toolbar -->
      <div class="card mb-3" style="background:var(--surface-card);border:1px solid var(--border-color);border-radius:14px;padding:12px 16px;box-shadow:0 4px 16px rgba(0,0,0,0.03)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;flex-wrap:wrap;gap:8px">
          <div style="display:flex;align-items:center;gap:8px;font-weight:800;font-size:0.92rem;color:var(--text-primary)">
            <span style="font-size:1.05rem">⚡</span>
            <span id="rep-active-badge-title">${isAR ? def.nameAR : def.nameEN}</span>
          </div>
          <div id="rep-date-presets" style="display:flex;align-items:center;gap:5px;flex-wrap:wrap">
            <span style="font-size:0.75rem;font-weight:800;color:var(--text-muted);margin-left:4px">${isAR ? 'فترة سريعة:' : 'Quick Period:'}</span>
            <button type="button" class="btn btn-sm btn-ghost rep-preset-btn" data-preset="today" onclick="Reports.applyDatePreset('today')" style="padding:3px 10px;font-size:0.78rem;font-weight:700;border-radius:6px;border:1px solid var(--border-color)">${isAR ? 'اليوم' : 'Today'}</button>
            <button type="button" class="btn btn-sm btn-ghost rep-preset-btn" data-preset="yesterday" onclick="Reports.applyDatePreset('yesterday')" style="padding:3px 10px;font-size:0.78rem;font-weight:700;border-radius:6px;border:1px solid var(--border-color)">${isAR ? 'أمس' : 'Yesterday'}</button>
            <button type="button" class="btn btn-sm btn-ghost rep-preset-btn" data-preset="week" onclick="Reports.applyDatePreset('week')" style="padding:3px 10px;font-size:0.78rem;font-weight:700;border-radius:6px;border:1px solid var(--border-color)">${isAR ? 'هذا الأسبوع' : 'This Week'}</button>
            <button type="button" class="btn btn-sm btn-primary rep-preset-btn" data-preset="month" onclick="Reports.applyDatePreset('month')" style="padding:3px 10px;font-size:0.78rem;font-weight:700;border-radius:6px;border:1px solid var(--border-color);box-shadow:0 2px 6px rgba(99,102,241,0.25)">${isAR ? 'هذا الشهر' : 'This Month'}</button>
            <button type="button" class="btn btn-sm btn-ghost rep-preset-btn" data-preset="year" onclick="Reports.applyDatePreset('year')" style="padding:3px 10px;font-size:0.78rem;font-weight:700;border-radius:6px;border:1px solid var(--border-color)">${isAR ? 'هذا العام' : 'This Year'}</button>
            <button type="button" class="btn btn-sm btn-ghost rep-preset-btn" data-preset="all" onclick="Reports.applyDatePreset('all')" style="padding:3px 10px;font-size:0.78rem;font-weight:700;border-radius:6px;border:1px solid var(--border-color)">${isAR ? 'الكل' : 'All'}</button>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:minmax(190px, 1.2fr) minmax(170px, 1fr) minmax(130px, 0.8fr) minmax(130px, 0.8fr) minmax(160px, 0.9fr) auto;gap:10px;align-items:flex-end">
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-weight:800;font-size:0.78rem;margin-bottom:4px">1. ${isAR ? 'نوع التقرير' : 'Report Type'}</label>
            <select id="master-rep-type" class="form-control" style="font-weight:700;height:38px;border-radius:8px;font-size:0.82rem" onchange="Reports.onMasterReportTypeChange(this.value)">
              ${typeOptionsHtml}
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-weight:800;font-size:0.78rem;margin-bottom:4px">2. ${isAR ? 'التصفية / القسم' : 'Sub-Option'}</label>
            <select id="master-rep-sub" class="form-control" style="font-weight:700;height:38px;border-radius:8px;font-size:0.82rem" onchange="Reports.onMasterReportSubChange(this.value)">
              ${subOptionsHtml}
            </select>
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-weight:800;font-size:0.78rem;margin-bottom:4px">${isAR ? 'من تاريخ' : 'From Date'}</label>
            <input type="date" class="form-control" id="rep-from" value="${thisMonth}-01" style="height:38px;border-radius:8px;font-size:0.82rem;font-weight:600" onchange="Reports.onDateInputChange()">
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-weight:800;font-size:0.78rem;margin-bottom:4px">${isAR ? 'إلى تاريخ' : 'To Date'}</label>
            <input type="date" class="form-control" id="rep-to" value="${today}" style="height:38px;border-radius:8px;font-size:0.82rem;font-weight:600" onchange="Reports.onDateInputChange()">
          </div>
          <div class="form-group" style="margin-bottom:0">
            <label class="form-label" style="font-weight:800;font-size:0.78rem;margin-bottom:4px">${isAR ? 'الفرع / المحطة' : 'Branch / POS'}</label>
            ${branchSelectHtml}
          </div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-primary" onclick="Reports.runMasterReport()" style="height:38px;font-weight:800;border-radius:8px;display:flex;align-items:center;gap:6px;padding:0 16px" title="${isAR ? 'تحديث البيانات' : 'Apply'}">
              <span>⚡</span> ${isAR ? 'تحديث' : 'Apply'}
            </button>
            <button class="btn btn-secondary" onclick="Reports.resetMasterReport()" title="${isAR ? 'إعادة ضبط' : 'Reset'}" style="height:38px;border-radius:8px;padding:0 10px">
              🔄
            </button>
          </div>
        </div>
      </div>
      <!-- Live Master Report Display Target -->
      <div id="master-report-render-target"></div>
      `}
    </div>`;

    if (_hubActiveTab === 'combobox') {
      await runMasterReport();
    }
  }

  async function _nav(type, container) {
    if (!container) container = document.getElementById('page-content');
    const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function') 
      ? License.getCachedBusinessMode() 
      : 'retail';
    if (bMode === 'retail' && type === 'restaurant-report') {
      type = 'sales';
    }

    switch (type) {
      case 'analytics': await renderAnalyticsGraphs(container); break;
      case 'restaurant-report': await renderRestaurantReport(container); break;
      case 'sales': await renderSalesReport(container); break;
      case 'stock': await renderStockReport(container); break;
      case 'pl': await renderPLReport(container); break;
      case 'customer-ledger': await renderCustomerLedger(container); break;
      case 'supplier-ledger': await renderSupplierLedger(container); break;
      case 'attendance': await renderAttReport(container); break;
      case 'gift': await renderGiftReport(container); break;
      case 'multi-branch': await renderMultiBranchStockReport(container); break;
      case 'repairs-report': await renderRepairsReport(container); break;
      case 'cashier-reconciliation': await renderCashierReconciliationReport(container); break;
      case 'dead-stock': await renderDeadStockReport(container); break;
      case 'top-customers': await renderTopCustomersReport(container); break;
      case 'item-stock-card': await renderItemStockCardReport(container); break;
      case 'abc-analysis': await renderABCAnalysisReport(container); break;
      case 'stock-audit': await renderStockAuditVarianceReport(container); break;
      default: await render(container); break;
    }
  }

  // ── Gift Items Report ─────────────────────────────────────────
  async function renderGiftReport(container, subFilter = 'all') {
    const isAR = i18n.getLang() === 'ar';
    const sales = await DB.getAll('sales');

    const giftRows = [];
    for (const s of sales) {
      let cart = [];
      try { cart = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
      for (const item of cart) {
        if (item.line_type === 'gift' || item.is_gift) {
          giftRows.push({
            date: s.created_at || s.doc_date,
            ref: s.receipt_no || s.ref || `INV-${s.id}`,
            customer: s.customer_name || (isAR ? 'عميل عابر' : 'Walk-in'),
            cashier: s.cashier || 'system',
            item_name: isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar),
            qty: parseFloat(item.qty) || 1,
            unit_price: parseFloat(item.price) || 0,
            gift_val: (parseFloat(item.qty) || 1) * (parseFloat(item.price) || 0)
          });
        }
      }
    }

    const totalQty = giftRows.reduce((sum, r) => sum + r.qty, 0);
    const totalVal = giftRows.reduce((sum, r) => sum + r.gift_val, 0);
    window._giftReportData = giftRows;

    let tableHtml = '';
    if (subFilter === 'by_item') {
      const itemGroup = {};
      giftRows.forEach(r => {
        if (!itemGroup[r.item_name]) {
          itemGroup[r.item_name] = { name: r.item_name, count: 0, qty: 0, val: 0, price: r.unit_price };
        }
        itemGroup[r.item_name].count++;
        itemGroup[r.item_name].qty += r.qty;
        itemGroup[r.item_name].val += r.gift_val;
      });
      const itemRows = Object.values(itemGroup).sort((a, b) => b.qty - a.qty);

      tableHtml = `
      <div class="table-wrapper card">
        <table>
          <thead><tr>
            <th>${isAR ? 'الصنف المهدى' : 'Gifted Item'}</th>
            <th style="text-align:center">${isAR ? 'عدد مرات الصرف' : 'Times Gifted'}</th>
            <th style="text-align:center">${isAR ? 'إجمالي القطع المهدات' : 'Total Qty Gifted'}</th>
            <th style="text-align:right">${isAR ? 'سعر الوحدة الافتراضي' : 'Unit Price'}</th>
            <th style="text-align:right">${isAR ? 'إجمالي القيمة المقدرة' : 'Total Estimated Value'}</th>
          </tr></thead>
          <tbody>
            ${itemRows.map(r => `
            <tr>
              <td style="font-weight:700;color:var(--text-primary)">🎁 ${Utils.sanitize(r.name)}</td>
              <td style="text-align:center;font-weight:700">${r.count}</td>
              <td style="text-align:center;font-weight:900;color:var(--primary)">${r.qty}</td>
              <td style="text-align:right">${Utils.formatMoney(r.price)}</td>
              <td style="text-align:right;font-weight:900;color:var(--warning)">${Utils.formatMoney(r.val)}</td>
            </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد هدايا مسجلة' : 'No gifts recorded'}</td></tr>`}
          </tbody>
        </table>
      </div>`;
    } else {
      tableHtml = `
      <div class="table-wrapper card">
        <table>
          <thead><tr>
            <th>${isAR ? 'التاريخ' : 'Date'}</th>
            <th>${isAR ? 'رقم السند' : 'Ref #'}</th>
            <th>${isAR ? 'العميل' : 'Customer'}</th>
            <th>${isAR ? 'أمين الصندوق' : 'Cashier'}</th>
            <th>${isAR ? 'الصنف المهدى' : 'Gifted Item'}</th>
            <th style="text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>
            <th style="text-align:right">${isAR ? 'سعر الوحدة' : 'Unit Price'}</th>
            <th style="text-align:right">${isAR ? 'القيمة المقدرة' : 'Estimated Value'}</th>
          </tr></thead>
          <tbody>
            ${giftRows.map(r => `
            <tr>
              <td style="font-size:0.78rem">${Utils.formatDate(r.date)}</td>
              <td style="font-weight:700;color:var(--primary)">${r.ref}</td>
              <td>${Utils.sanitize(r.customer)}</td>
              <td>${Utils.sanitize(r.cashier)}</td>
              <td style="font-weight:600;color:var(--info)">🎁 ${Utils.sanitize(r.item_name)}</td>
              <td style="text-align:center;font-weight:700">${r.qty}</td>
              <td style="text-align:right">${Utils.formatMoney(r.unit_price)}</td>
              <td style="text-align:right;font-weight:800;color:var(--warning)">${Utils.formatMoney(r.gift_val)}</td>
            </tr>`).join('') || `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد هدايا مسجلة حتى الآن' : 'No gift items recorded yet'}</td></tr>`}
          </tbody>
        </table>
      </div>`;
    }

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>🎁 ${isAR ? 'تقرير الهدايا والعينات المجانية' : 'Gift & Free Items Report'}</h1>
          <p>${isAR ? 'سجل تفصيلي بجميع الأصناف التي تم صرفها كـ هدايا بقيمة صفر' : 'Detailed breakdown of all items issued as gifts ($0.00 price)'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printGiftReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportGiftReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير' : 'Export'}
          </button>
        </div>
      </div>

      <div class="stats-grid mb-4">
        ${kpiCard(isAR ? 'عدد عمليات الهدايا' : 'Gift Transactions', giftRows.length, 'blue', '🎁', false)}
        ${kpiCard(isAR ? 'إجمالي القطع المهدات' : 'Total Gifted Qty', totalQty, 'green', '📦', false, isAR ? ' قطعة' : ' pcs')}
        ${kpiCard(isAR ? 'قيمة الهدايا المستهدفة' : 'Total Gift Retail Value', totalVal, 'gold', '💰', true)}
      </div>

      ${tableHtml}
    </div>`;
  }

  function printGiftReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._giftReportData || [];
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR?'rtl':'ltr'}">
      <h2>🎁 ${isAR ? 'تقرير الهدايا والعينات المجانية' : 'Gift & Free Items Report'}</h2>
      <p style="color:#666">${isAR ? 'تاريخ التقرير:' : 'Report Date:'} ${Utils.today()}</p>
      <table style="width:100%;border-collapse:collapse;margin-top:16px;font-size:12px" border="1" cellpadding="6">
        <thead>
          <tr style="background:#f1f5f9">
            <th>Date</th><th>Ref</th><th>Customer</th><th>Cashier</th><th>Item</th><th>Qty</th><th>Unit Price</th><th>Gift Value</th>
          </tr>
        </thead>
        <tbody>
          ${data.map(d => `<tr>
            <td>${Utils.formatDate(d.date)}</td><td>${d.ref}</td><td>${d.customer}</td><td>${d.cashier}</td>
            <td>🎁 ${d.item_name}</td><td>${d.qty}</td><td>$${d.unit_price}</td><td>$${d.gift_val}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'Gift-Report');
  }

  function exportGiftReport() {
    const data = window._giftReportData || [];
    Utils.exportCSV(data.map(d => ({
      Date: d.date, Ref: d.ref, Customer: d.customer, Cashier: d.cashier,
      Item: d.item_name, Qty: d.qty, UnitPrice: d.unit_price, GiftValue: d.gift_val
    })), 'gift_items_report');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 1. 🏬 Multi-Branch Stock Matrix Report
  // ═══════════════════════════════════════════════════════════════════
  async function renderMultiBranchStockReport(container, subFilter = 'all') {
    const isAR = i18n.getLang() === 'ar';
    const items = (await DB.getAll('items')) || [];
    let warehouses = (await DB.getAll('warehouses')) || [];
    if (!warehouses.length) {
      warehouses = [{ id: 1, name: 'Main Store', name_ar: 'المستودع الرئيسي', code: 'WH-01', is_default: true }];
    }
    const cats = (await DB.getAll('categories')) || [];

    window._mbItems = items;
    window._mbWarehouses = warehouses;
    window._mbCats = cats;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">🏬 ${isAR ? 'مقارنة مخزون الفروع والمستودعات' : 'Multi-Branch Stock Matrix'}</h1>
          </div>
          <p>${isAR ? 'مقارنة أرصدة وتقييم كميات كل صنف في كافة الفروع والمستودعات جنباً إلى جنب' : 'Side-by-side inventory balance & valuation across all stores and warehouses'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printMultiBranchReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportMultiBranchReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Live Summary KPI Cards -->
      <div class="grid grid-4 mb-4" id="mb-kpi-grid">
        ${kpiCard(isAR ? 'عدد الأصناف المسجلة' : 'Total Item SKUs', items.length, 'primary', '📦', false)}
        ${kpiCard(isAR ? 'عدد الفروع والمستودعات' : 'Active Stores / WH', warehouses.length, 'success', '🏬', false)}
        ${kpiCard(isAR ? 'إجمالي القطع في جميع الفروع' : 'Total Global Stock Units', items.reduce((s, i) => s + (parseFloat(i.stock_qty) || 0), 0), 'warning', '🔢', false, isAR ? ' وحدة' : ' units')}
        ${kpiCard(isAR ? 'إجمالي تقييم المخزون بالتكلفة' : 'Global Cost Valuation', items.reduce((s, i) => s + ((parseFloat(i.stock_qty) || 0) * (parseFloat(i.cost_price) || 0)), 0), 'danger', '💰', true)}
      </div>

      <!-- Filters -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:16px">
          <div class="grid grid-3" style="gap:12px">
            <div class="form-group">
              <label class="form-label">${isAR ? 'بحث بالاسم أو الباركود' : 'Search Item / Barcode'}</label>
              <input type="text" id="mb-search" class="form-control" placeholder="${isAR ? 'اكتب اسم الصنف أو الكود...' : 'Filter item name or code...'}" oninput="Reports.filterMultiBranchData()">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'التصنيف' : 'Category'}</label>
              <select id="mb-cat-filter" class="form-control" onchange="Reports.filterMultiBranchData()">
                <option value="">${isAR ? 'جميع التصنيفات' : 'All Categories'}</option>
                ${cats.map(c => `<option value="${c.id}">${isAR ? (c.name_ar || c.name) : (c.name || c.name_ar)}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'حالة التوفر' : 'Stock Status'}</label>
              <select id="mb-status-filter" class="form-control" onchange="Reports.filterMultiBranchData()">
                <option value="all">${isAR ? 'جميع الأصناف' : 'All Products'}</option>
                <option value="low_any">${isAR ? '⚠️ ينقص أو غير متوفر في أي فرع' : '⚠️ Low or Zero in Any Branch'}</option>
                <option value="in_stock">${isAR ? '✅ متوفر في كافة الفروع' : '✅ In Stock Across All Branches'}</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- Matrix Table -->
      <div class="card">
        <div class="table-wrapper">
          <table style="font-size:0.85rem">
            <thead>
              <tr>
                <th>${isAR ? 'الكود' : 'Code'}</th>
                <th>${isAR ? 'اسم الصنف' : 'Item Name'}</th>
                <th>${isAR ? 'التصنيف' : 'Category'}</th>
                <th>${isAR ? 'التكلفة' : 'Cost'}</th>
                <th>${isAR ? 'البيع' : 'Price'}</th>
                ${warehouses.map(w => `<th style="text-align:center;background:rgba(59,130,246,0.08);color:var(--primary)">🏬 ${isAR ? (w.name_ar || w.name) : (w.name || w.name_ar)}</th>`).join('')}
                <th style="text-align:center;font-weight:900">${isAR ? 'المجموع' : 'Total Stock'}</th>
                <th style="text-align:right">${isAR ? 'تقييم التكلفة' : 'Total Cost Value'}</th>
                <th style="text-align:center">${isAR ? 'إجراء سريع' : 'Action'}</th>
              </tr>
            </thead>
            <tbody id="mb-table-body">
              <!-- Populated dynamically -->
            </tbody>
          </table>
        </div>
      </div>
    </div>`;

    if (subFilter && ['all', 'low_any', 'in_stock'].includes(subFilter)) {
      const mbStatus = document.getElementById('mb-status-filter');
      if (mbStatus) mbStatus.value = subFilter;
    }
    filterMultiBranchData();
  }

  function filterMultiBranchData() {
    const isAR = i18n.getLang() === 'ar';
    const items = window._mbItems || [];
    const warehouses = window._mbWarehouses || [];
    const search = (document.getElementById('mb-search')?.value || '').toLowerCase().trim();
    const catId = document.getElementById('mb-cat-filter')?.value;
    const status = document.getElementById('mb-status-filter')?.value || 'all';

    const filtered = items.filter(item => {
      const name = ((item.name_ar || '') + ' ' + (item.name_en || '') + ' ' + (item.item_code || '') + ' ' + (item.barcode || '')).toLowerCase();
      if (search && !name.includes(search)) return false;
      if (catId && String(item.category_id) !== String(catId)) return false;

      if (status === 'low_any') {
        const hasLowOrZero = warehouses.some(w => {
          const st = item.warehouse_stocks?.[w.id] ?? (w.id === 1 ? (item.stock_qty || 0) : 0);
          return st <= (item.min_stock || 5);
        });
        if (!hasLowOrZero) return false;
      } else if (status === 'in_stock') {
        const allInStock = warehouses.every(w => {
          const st = item.warehouse_stocks?.[w.id] ?? (w.id === 1 ? (item.stock_qty || 0) : 0);
          return st > 0;
        });
        if (!allInStock) return false;
      }

      return true;
    });

    window._mbFilteredData = filtered;

    const tbody = document.getElementById('mb-table-body');
    if (!tbody) return;

    if (!filtered.length) {
      tbody.innerHTML = `<tr><td colspan="${8 + warehouses.length}" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد نتائج مطابقة' : 'No matching items found'}</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(item => {
      const name = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
      const cat = (window._mbCats || []).find(c => c.id === item.category_id);
      const catName = cat ? (isAR ? (cat.name_ar || cat.name) : (cat.name || cat.name_ar)) : '-';
      const cost = parseFloat(item.cost_price) || 0;
      const price = parseFloat(item.selling_price) || 0;

      let totalStock = 0;
      const branchCols = warehouses.map(w => {
        const st = item.warehouse_stocks?.[w.id] ?? (w.id === 1 ? (item.stock_qty || 0) : 0);
        totalStock += st;
        const isZero = st <= 0;
        const isLow = st > 0 && st <= (item.min_stock || 5);
        const color = isZero ? 'var(--danger)' : isLow ? 'var(--warning)' : 'var(--text-primary)';
        return `<td style="text-align:center;font-weight:700;color:${color};background:${isZero ? 'rgba(239,68,68,0.06)' : ''}">${st}</td>`;
      }).join('');

      const totalCostVal = totalStock * cost;

      return `
      <tr>
        <td style="font-family:monospace;font-weight:700;color:var(--text-muted)">${item.item_code || '-'}</td>
        <td style="font-weight:700;color:var(--text-primary)">${Utils.sanitize(name)}</td>
        <td><span class="badge" style="font-size:0.72rem">${Utils.sanitize(catName)}</span></td>
        <td>${Utils.formatMoney(cost)}</td>
        <td style="font-weight:700;color:var(--success)">${Utils.formatMoney(price)}</td>
        ${branchCols}
        <td style="text-align:center;font-weight:900;font-size:0.95rem;color:var(--primary)">${totalStock}</td>
        <td style="text-align:right;font-weight:800">${Utils.formatMoney(totalCostVal)}</td>
        <td style="text-align:center">
          <button class="btn btn-ghost btn-sm" onclick="App.navigate('transfer')" title="${isAR ? 'تحويل بين الفروع' : 'Transfer Stock'}" style="padding:4px 8px;font-size:0.75rem">
            🔄 ${isAR ? 'تحويل' : 'Transfer'}
          </button>
        </td>
      </tr>`;
    }).join('');
  }

  function printMultiBranchReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._mbFilteredData || [];
    const warehouses = window._mbWarehouses || [];

    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <div style="text-align:center;margin-bottom:16px">
        <h2 style="margin:0">🏬 ${isAR ? 'تقرير مقارنة مخزون الفروع والمستودعات' : 'Multi-Branch Stock Comparison Matrix'}</h2>
        <div style="font-size:12px;color:#666;margin-top:4px">${isAR ? 'تاريخ التقرير:' : 'Date:'} ${Utils.today()} | ${data.length} ${isAR ? 'صنف' : 'items'}</div>
      </div>
      <table style="width:100%;border-collapse:collapse;font-size:11px" border="1" cellpadding="5">
        <thead>
          <tr style="background:#f1f5f9">
            <th>${isAR ? 'الكود' : 'Code'}</th>
            <th>${isAR ? 'الصنف' : 'Item'}</th>
            <th>${isAR ? 'التكلفة' : 'Cost'}</th>
            <th>${isAR ? 'البيع' : 'Price'}</th>
            ${warehouses.map(w => `<th>${isAR ? (w.name_ar || w.name) : (w.name || w.name_ar)}</th>`).join('')}
            <th>${isAR ? 'الإجمالي' : 'Total'}</th>
            <th>${isAR ? 'تقييم التكلفة' : 'Cost Value'}</th>
          </tr>
        </thead>
        <tbody>
          ${data.map(i => {
            let tot = 0;
            const bCols = warehouses.map(w => {
              const st = i.warehouse_stocks?.[w.id] ?? (w.id === 1 ? (i.stock_qty || 0) : 0);
              tot += st;
              return `<td style="text-align:center">${st}</td>`;
            }).join('');
            return `<tr>
              <td>${i.item_code || ''}</td>
              <td>${isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar)}</td>
              <td>${Utils.formatMoney(i.cost_price || 0)}</td>
              <td>${Utils.formatMoney(i.selling_price || 0)}</td>
              ${bCols}
              <td style="text-align:center;font-weight:bold">${tot}</td>
              <td style="text-align:right">${Utils.formatMoney(tot * (i.cost_price || 0))}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;

    Utils.printElement(html, 'Multi-Branch-Stock-Report');
  }

  function exportMultiBranchReport() {
    const data = window._mbFilteredData || [];
    const warehouses = window._mbWarehouses || [];
    const isAR = i18n.getLang() === 'ar';

    const rows = data.map(item => {
      let tot = 0;
      const row = {
        Code: item.item_code || '',
        Name: isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar),
        Cost: item.cost_price || 0,
        Price: item.selling_price || 0
      };
      warehouses.forEach(w => {
        const st = item.warehouse_stocks?.[w.id] ?? (w.id === 1 ? (item.stock_qty || 0) : 0);
        tot += st;
        row[w.name || w.name_ar] = st;
      });
      row['Total Stock'] = tot;
      row['Total Cost Value'] = tot * (item.cost_price || 0);
      return row;
    });

    Utils.exportCSV(rows, 'multi_branch_stock_matrix');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 2. 🛠️ Workshop & Repairs Profitability Report
  // ═══════════════════════════════════════════════════════════════════
  async function renderRepairsReport(container, subFilter = 'all') {
    const isAR = i18n.getLang() === 'ar';
    let jobs = (await DB.getAll('repair_jobs')) || [];
    if (subFilter === 'delivered') {
      jobs = jobs.filter(j => j.status === 'delivered' || j.status === 'ready');
    } else if (subFilter === 'in_progress') {
      jobs = jobs.filter(j => j.status === 'diagnosing' || j.status === 'waiting_parts' || j.status === 'received');
    }

    const totalJobs = jobs.length;
    const completed = jobs.filter(j => j.status === 'delivered' || j.status === 'ready').length;
    const inProgress = jobs.filter(j => j.status === 'diagnosing' || j.status === 'waiting_parts' || j.status === 'received').length;
    
    let totalRevenue = 0;
    let totalPartsCost = 0;

    jobs.forEach(j => {
      const rev = (parseFloat(j.labor_cost) || 0) + (parseFloat(j.parts_cost) || 0);
      totalRevenue += rev;
      totalPartsCost += (parseFloat(j.parts_cost) || 0);
    });

    const netWorkshopProfit = totalRevenue - totalPartsCost;

    // Group by technician
    const techMap = {};
    jobs.forEach(j => {
      const tech = j.technician || (isAR ? 'غير محدد' : 'Unassigned');
      if (!techMap[tech]) techMap[tech] = { count: 0, completed: 0, revenue: 0, labor: 0 };
      techMap[tech].count++;
      if (j.status === 'delivered' || j.status === 'ready') techMap[tech].completed++;
      techMap[tech].labor += (parseFloat(j.labor_cost) || 0);
      techMap[tech].revenue += ((parseFloat(j.labor_cost) || 0) + (parseFloat(j.parts_cost) || 0));
    });

    window._repairsReportData = jobs;
    window._techData = techMap;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">🛠️ ${isAR ? 'تقرير أرباح الصيانة وأداء الفنيين' : 'Repairs & Workshop Profitability'}</h1>
          </div>
          <p>${isAR ? 'تحليل الإيرادات، تكلفة قطع الغيار، الأرباح الصافية، ومعدل إنجاز الفنيين' : 'Detailed workshop revenue, spare parts cost, net profits & technician KPI metrics'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printRepairsReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportRepairsReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- KPI Summary -->
      <div class="grid grid-4 mb-4">
        ${kpiCard(isAR ? 'إجمالي تذاكر الصيانة' : 'Total Repair Jobs', totalJobs, 'primary', '🎫', false)}
        ${kpiCard(isAR ? 'الأجهزة المنجزة والمسلمة' : 'Completed / Delivered', completed, 'success', '✅', false)}
        ${kpiCard(isAR ? 'إجمالي إيرادات الصيانة' : 'Total Workshop Revenue', totalRevenue, 'blue', '💰', true)}
        ${kpiCard(isAR ? 'صافي أرباح الورشة (أجور اليد)' : 'Net Workshop Profit', netWorkshopProfit, 'green', '📈', true)}
      </div>

      <!-- Technician Performance Card -->
      <div class="card mb-4">
        <div class="card-header">
          <div class="card-title">👨‍🔧 ${isAR ? 'جدول أداء وإنتاجية الفنيين' : 'Technicians Productivity & Labor Revenue'}</div>
        </div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'اسم الفني' : 'Technician'}</th>
                <th style="text-align:center">${isAR ? 'عدد الأجهزة' : 'Jobs Assigned'}</th>
                <th style="text-align:center">${isAR ? 'الأجهزة المكتملة' : 'Completed'}</th>
                <th style="text-align:center">${isAR ? 'نسبة الإنجاز%' : 'Completion Rate'}</th>
                <th style="text-align:right">${isAR ? 'أجور اليد المحققة' : 'Labor Revenue'}</th>
                <th style="text-align:right">${isAR ? 'إجمالي إيراد الفني' : 'Total Revenue'}</th>
              </tr>
            </thead>
            <tbody>
              ${Object.keys(techMap).map(tech => {
                const d = techMap[tech];
                const pct = d.count > 0 ? Math.round((d.completed / d.count) * 100) : 0;
                return `
                <tr>
                  <td style="font-weight:700">👨‍🔧 ${Utils.sanitize(tech)}</td>
                  <td style="text-align:center;font-weight:700">${d.count}</td>
                  <td style="text-align:center;color:var(--success);font-weight:700">${d.completed}</td>
                  <td style="text-align:center">
                    <span class="badge ${pct >= 75 ? 'badge-success' : 'badge-warning'}">${pct}%</span>
                  </td>
                  <td style="text-align:right;font-weight:700;color:var(--success)">${Utils.formatMoney(d.labor)}</td>
                  <td style="text-align:right;font-weight:900;color:var(--primary)">${Utils.formatMoney(d.revenue)}</td>
                </tr>`;
              }).join('') || `<tr><td colspan="6" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات فنيين مسجلة' : 'No technician data recorded'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Tickets Detailed Ledger -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">📋 ${isAR ? 'سجل تذاكر الصيانة والأرباح' : 'Detailed Repair Jobs Ledger'}</div>
        </div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'رقم التذكرة' : 'Ticket #'}</th>
                <th>${isAR ? 'العميل' : 'Customer'}</th>
                <th>${isAR ? 'الجهاز / المشكلة' : 'Device / Issue'}</th>
                <th>${isAR ? 'الفني' : 'Technician'}</th>
                <th style="text-align:center">${isAR ? 'الحالة' : 'Status'}</th>
                <th style="text-align:right">${isAR ? 'قطع الغيار' : 'Parts Cost'}</th>
                <th style="text-align:right">${isAR ? 'أجر اليد' : 'Labor Cost'}</th>
                <th style="text-align:right">${isAR ? 'المبلغ الإجمالي' : 'Total Charged'}</th>
              </tr>
            </thead>
            <tbody>
              ${jobs.map(j => {
                const tot = (parseFloat(j.labor_cost) || 0) + (parseFloat(j.parts_cost) || 0);
                return `
                <tr>
                  <td style="font-family:monospace;font-weight:800;color:var(--primary)">${j.ref || j.ticket_no || ('REP-' + j.id)}</td>
                  <td style="font-weight:600">${Utils.sanitize(j.customer_name || '-')}</td>
                  <td>${Utils.sanitize(j.device_model || j.device_type || '-')} <small style="color:var(--text-muted)">(${Utils.sanitize(j.issue || '')})</small></td>
                  <td>${Utils.sanitize(j.technician || '-')}</td>
                  <td style="text-align:center"><span class="badge badge-${j.status === 'delivered' ? 'success' : j.status === 'ready' ? 'primary' : 'warning'}">${j.status || 'received'}</span></td>
                  <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(j.parts_cost || 0)}</td>
                  <td style="text-align:right;color:var(--success);font-weight:700">${Utils.formatMoney(j.labor_cost || 0)}</td>
                  <td style="text-align:right;font-weight:900;color:var(--text-primary)">${Utils.formatMoney(tot)}</td>
                </tr>`;
              }).join('') || `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد تذاكر صيانة مسجلة' : 'No repair jobs recorded'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  }

  function printRepairsReport() {
    const isAR = i18n.getLang() === 'ar';
    const jobs = window._repairsReportData || [];
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <h2 style="text-align:center;margin-bottom:16px">🛠️ ${isAR ? 'تقرير إيرادات وأرباح الصيانة' : 'Repairs & Workshop Report'}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:11px" border="1" cellpadding="5">
        <thead>
          <tr style="background:#f1f5f9">
            <th>${isAR ? 'رقم التذكرة' : 'Ticket'}</th>
            <th>${isAR ? 'العميل' : 'Customer'}</th>
            <th>${isAR ? 'الجهاز' : 'Device'}</th>
            <th>${isAR ? 'الفني' : 'Technician'}</th>
            <th>${isAR ? 'قطع الغيار' : 'Parts Cost'}</th>
            <th>${isAR ? 'أجر اليد' : 'Labor Cost'}</th>
            <th>${isAR ? 'الإجمالي' : 'Total'}</th>
          </tr>
        </thead>
        <tbody>
          ${jobs.map(j => `<tr>
            <td>${j.ref || j.ticket_no || j.id}</td>
            <td>${j.customer_name || ''}</td>
            <td>${j.device_model || ''}</td>
            <td>${j.technician || ''}</td>
            <td>${Utils.formatMoney(j.parts_cost || 0)}</td>
            <td>${Utils.formatMoney(j.labor_cost || 0)}</td>
            <td>${Utils.formatMoney((j.parts_cost || 0) + (j.labor_cost || 0))}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'Repairs-Report');
  }

  function exportRepairsReport() {
    const jobs = window._repairsReportData || [];
    Utils.exportCSV(jobs.map(j => ({
      Ticket: j.ref || j.ticket_no || j.id,
      Customer: j.customer_name || '',
      Device: j.device_model || '',
      Technician: j.technician || '',
      Status: j.status || '',
      PartsCost: j.parts_cost || 0,
      LaborCost: j.labor_cost || 0,
      TotalRevenue: (parseFloat(j.parts_cost) || 0) + (parseFloat(j.labor_cost) || 0)
    })), 'repairs_workshop_report');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 3. 💳 Cashier Shift Reconciliation & Payment Methods Report
  // ═══════════════════════════════════════════════════════════════════
  async function renderCashierReconciliationReport(container) {
    const isAR = i18n.getLang() === 'ar';
    const users = (await DB.getAll('users')) || [];
    const today = Utils.today();

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">💳 ${isAR ? 'تسوية ورديات الكاشير وتوزيع طرق الدفع' : 'Cashier Shift Reconciliation'}</h1>
          </div>
          <p>${isAR ? 'مراقبة مبيعات كل كاشير، المدفوعات النقدية، بطاقات الائتمان، مبيعات الآجل، والعجز والزيادة' : 'Audit cashier sales, cash vs card splits, customer debt, and drawer variances'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printCashierReconReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportCashierReconReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Filters -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:16px">
          <div class="grid grid-4" style="gap:12px">
            <div class="form-group">
              <label class="form-label">${isAR ? 'من تاريخ' : 'From Date'}</label>
              <input type="date" id="recon-from" class="form-control" value="${today}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'إلى تاريخ' : 'To Date'}</label>
              <input type="date" id="recon-to" class="form-control" value="${today}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'المستخدم / الكاشير' : 'Cashier / User'}</label>
              <select id="recon-user" class="form-control">
                <option value="">${isAR ? 'جميع موظفي الكاشير' : 'All Cashiers'}</option>
                ${users.map(u => `<option value="${u.username}">${u.full_name || u.username}</option>`).join('')}
              </select>
            </div>
            <div class="form-group" style="display:flex;align-items:flex-end">
              <button class="btn btn-primary" onclick="Reports.loadCashierReconData()" style="width:100%">${isAR ? 'عرض التسوية' : 'Filter & Run'}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- KPI Summary -->
      <div class="grid grid-4 mb-4" id="recon-kpi-grid"></div>

      <!-- Cashier Breakdown Table -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">📊 ${isAR ? 'ملخص تسوية الورديات حسب الكاشير' : 'Cashier Shift Audit Breakdown'}</div>
        </div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الكاشير' : 'Cashier'}</th>
                <th style="text-align:center">${isAR ? 'عدد الفواتير' : 'Invoices'}</th>
                <th style="text-align:right">${isAR ? 'نقدي (كاش)' : 'Cash'}</th>
                <th style="text-align:right">${isAR ? 'شبكة / فيزا' : 'Card / POS'}</th>
                <th style="text-align:right">${isAR ? 'مبيعات آجل (ذمم)' : 'Credit (Debt)'}</th>
                <th style="text-align:right">${isAR ? 'الخصومات الممنوحة' : 'Discounts'}</th>
                <th style="text-align:right;font-weight:900">${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
              </tr>
            </thead>
            <tbody id="recon-table-body"></tbody>
          </table>
        </div>
      </div>
    </div>`;

    await loadCashierReconData();
  }

  async function loadCashierReconData() {
    const isAR = i18n.getLang() === 'ar';
    const from = document.getElementById('recon-from')?.value || Utils.today();
    const to = document.getElementById('recon-to')?.value || Utils.today();
    const filterUser = document.getElementById('recon-user')?.value;

    const sales = (await DB.getAll('sales')) || [];
    const filtered = sales.filter(s => {
      const d = (s.created_at || s.doc_date || '').slice(0, 10);
      if (from && d < from) return false;
      if (to && d > to) return false;
      if (filterUser && s.cashier !== filterUser && s.user_name !== filterUser) return false;
      return true;
    });

    let totalRev = 0, totalCash = 0, totalCard = 0, totalCredit = 0, totalDisc = 0;
    const cashierMap = {};

    filtered.forEach(s => {
      const gTot = parseFloat(s.grand_total) || 0;
      let cash = 0, card = 0, credit = 0;
      if (s.payment_method === 'cash') {
        cash = gTot;
      } else if (s.payment_method === 'card') {
        card = gTot;
      } else if (s.payment_method === 'credit') {
        const down = parseFloat(s.paid_amount !== undefined ? s.paid_amount : (s.tendered || 0));
        cash = Math.min(gTot, Math.max(0, down));
        credit = parseFloat(s.credit_amount !== undefined ? s.credit_amount : Math.max(0, gTot - cash));
      } else {
        cash = gTot;
      }
      const disc = parseFloat(s.discount_amount || s.discount || s.manual_discount || 0);

      totalRev += gTot;
      totalCash += cash;
      totalCard += card;
      totalCredit += credit;
      totalDisc += disc;

      const cName = s.cashier || s.user_name || 'Admin';
      if (!cashierMap[cName]) {
        cashierMap[cName] = { count: 0, cash: 0, card: 0, credit: 0, disc: 0, total: 0 };
      }
      cashierMap[cName].count++;
      cashierMap[cName].cash += cash;
      cashierMap[cName].card += card;
      cashierMap[cName].credit += credit;
      cashierMap[cName].disc += disc;
      cashierMap[cName].total += gTot;
    });

    window._cashierReconData = cashierMap;

    // Render KPI
    const kpi = document.getElementById('recon-kpi-grid');
    if (kpi) {
      kpi.innerHTML = `
        ${kpiCard(isAR ? 'إجمالي المبيعات المحصلة' : 'Total Revenue', totalRev, 'primary', '💰', true)}
        ${kpiCard(isAR ? 'المقبوضات النقدية (كاش)' : 'Cash Collected', totalCash, 'success', '💵', true)}
        ${kpiCard(isAR ? 'المدفوعات الإلكترونية (فيزا)' : 'Card / POS Terminals', totalCard, 'blue', '💳', true)}
        ${kpiCard(isAR ? 'المبيعات الآجلة (ذمم)' : 'On Account (Credit Debt)', totalCredit, 'warning', '📝', true)}
        ${kpiCard(isAR ? 'الخصومات الممنوحة' : 'Total Discounts', totalDisc, 'danger', '🏷️', true)}
      `;
    }

    const tbody = document.getElementById('recon-table-body');
    if (tbody) {
      tbody.innerHTML = Object.keys(cashierMap).map(c => {
        const d = cashierMap[c];
        return `
        <tr>
          <td style="font-weight:700">👤 ${Utils.sanitize(c)}</td>
          <td style="text-align:center;font-weight:700">${d.count}</td>
          <td style="text-align:right;color:var(--success);font-weight:700">${Utils.formatMoney(d.cash)}</td>
          <td style="text-align:right;color:var(--info);font-weight:700">${Utils.formatMoney(d.card)}</td>
          <td style="text-align:right;color:var(--warning);font-weight:700">${Utils.formatMoney(d.credit)}</td>
          <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(d.disc)}</td>
          <td style="text-align:right;font-weight:900;font-size:0.95rem;color:var(--primary)">${Utils.formatMoney(d.total)}</td>
        </tr>`;
      }).join('') || `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد معاملات في هذه الفترة' : 'No transactions recorded in this period'}</td></tr>`;
    }
  }

  function printCashierReconReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._cashierReconData || {};
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <h2 style="text-align:center;margin-bottom:16px">💳 ${isAR ? 'تقرير تسوية ورديات الكاشير' : 'Cashier Reconciliation Report'}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:12px" border="1" cellpadding="6">
        <thead>
          <tr style="background:#f1f5f9">
            <th>Cashier</th><th>Invoices</th><th>Cash</th><th>Card</th><th>Credit</th><th>Discounts</th><th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${Object.keys(data).map(c => `<tr>
            <td>${c}</td><td>${data[c].count}</td><td>${Utils.formatMoney(data[c].cash)}</td><td>${Utils.formatMoney(data[c].card)}</td><td>${Utils.formatMoney(data[c].credit)}</td><td>${Utils.formatMoney(data[c].disc)}</td><td>${Utils.formatMoney(data[c].total)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'Cashier-Reconciliation-Report');
  }

  function exportCashierReconReport() {
    const data = window._cashierReconData || {};
    Utils.exportCSV(Object.keys(data).map(c => ({
      Cashier: c,
      Invoices: data[c].count,
      Cash: data[c].cash,
      Card: data[c].card,
      Credit: data[c].credit,
      Discounts: data[c].disc,
      TotalRevenue: data[c].total
    })), 'cashier_reconciliation_report');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 4. ⏳ Slow-Moving & Dead Stock Report
  // ═══════════════════════════════════════════════════════════════════
  async function renderDeadStockReport(container) {
    const isAR = i18n.getLang() === 'ar';
    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">⏳ ${isAR ? 'تقرير الأصناف الراكدة وبطيئة الحركة' : 'Slow-Moving & Dead Stock Report'}</h1>
          </div>
          <p>${isAR ? 'كشف السلع التي لم تحقق أي مبيعات خلال فترة معينة ورأس المال المجمد فيها' : 'Identify stagnant inventory with zero sales to free up locked working capital'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printDeadStockReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportDeadStockReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Threshold Selector -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:16px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:12px">
              <label class="form-label" style="margin:0;font-weight:700">${isAR ? 'فترة الركود (عدم وجود مبيعات):' : 'Stagnancy Inactivity Period:'}</label>
              <select id="dead-threshold" class="form-control" style="width:200px" onchange="Reports.loadDeadStockData()">
                <option value="30">${isAR ? 'آخر 30 يوماً' : 'Last 30 Days'}</option>
                <option value="60" selected>${isAR ? 'آخر 60 يوماً (موصى به)' : 'Last 60 Days (Standard)'}</option>
                <option value="90">${isAR ? 'آخر 90 يوماً (راكد حاد)' : 'Last 90 Days (Critical)'}</option>
                <option value="180">${isAR ? 'آخر 180 يوماً (ميت بالكامل)' : 'Last 180 Days (Dead Stock)'}</option>
              </select>
            </div>
            <button class="btn btn-warning btn-sm" onclick="App.navigate('offers')">
              🏷️ ${isAR ? 'إنشاء عروض تصفية لهذه الأصناف' : 'Create Clearance Promotion'}
            </button>
          </div>
        </div>
      </div>

      <!-- KPI Summary -->
      <div class="grid grid-4 mb-4" id="dead-kpi-grid"></div>

      <!-- Table -->
      <div class="card">
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الكود' : 'Code'}</th>
                <th>${isAR ? 'اسم الصنف' : 'Item Name'}</th>
                <th>${isAR ? 'التكلفة' : 'Cost Price'}</th>
                <th>${isAR ? 'البيع الحالي' : 'Retail Price'}</th>
                <th style="text-align:center">${isAR ? 'المخزون المتكدس' : 'Units In Stock'}</th>
                <th style="text-align:right">${isAR ? 'رأس المال المجمد' : 'Locked Capital'}</th>
                <th style="text-align:center">${isAR ? 'آخر عملية بيع' : 'Last Sale Date'}</th>
                <th style="text-align:center">${isAR ? 'إجراء مقترح' : 'AI Recommendation'}</th>
              </tr>
            </thead>
            <tbody id="dead-table-body"></tbody>
          </table>
        </div>
      </div>
    </div>`;

    await loadDeadStockData();
  }

  async function loadDeadStockData() {
    const isAR = i18n.getLang() === 'ar';
    const daysThreshold = parseInt(document.getElementById('dead-threshold')?.value || '60', 10);
    const items = (await DB.getAll('items')) || [];
    const sales = (await DB.getAll('sales')) || [];

    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysThreshold);
    const cutoffStr = cutoffDate.toISOString().slice(0, 10);

    // Map sales history per item
    const itemLastSold = {};
    const itemSoldInPeriod = {};

    sales.forEach(s => {
      const d = (s.created_at || s.doc_date || '').slice(0, 10);
      let cart = [];
      try { cart = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
      
      cart.forEach(ci => {
        const id = String(ci.item_id || ci.id);
        if (!itemLastSold[id] || d > itemLastSold[id]) {
          itemLastSold[id] = d;
        }
        if (d >= cutoffStr) {
          itemSoldInPeriod[id] = (itemSoldInPeriod[id] || 0) + (parseFloat(ci.qty) || 1);
        }
      });
    });

    // Filter items with stock > 0 and 0 sales in period
    const deadItems = items.filter(item => {
      const st = parseFloat(item.stock_qty) || 0;
      if (st <= 0) return false;
      const soldInPeriod = itemSoldInPeriod[String(item.id)] || 0;
      return soldInPeriod === 0;
    });

    let totalLockedCapital = 0;
    let totalDeadUnits = 0;

    deadItems.forEach(i => {
      const st = parseFloat(i.stock_qty) || 0;
      const cost = parseFloat(i.cost_price) || 0;
      totalDeadUnits += st;
      totalLockedCapital += (st * cost);
    });

    window._deadStockData = deadItems;

    // Render KPI
    const kpi = document.getElementById('dead-kpi-grid');
    if (kpi) {
      kpi.innerHTML = `
        ${kpiCard(isAR ? 'عدد الأصناف الراكدة' : 'Stagnant SKUs', deadItems.length, 'danger', '⏳', false)}
        ${kpiCard(isAR ? 'إجمالي القطع المتكدسة' : 'Total Stagnant Units', totalDeadUnits, 'warning', '📦', false, isAR ? ' قطعة' : ' pcs')}
        ${kpiCard(isAR ? 'رأس المال المجمد في الركود' : 'Locked Working Capital', totalLockedCapital, 'danger', '💸', true)}
        ${kpiCard(isAR ? 'فترة الفحص النشطة' : 'Inactivity Filter', daysThreshold, 'primary', '📅', false, isAR ? ' يوماً' : ' days')}
      `;
    }

    const tbody = document.getElementById('dead-table-body');
    if (tbody) {
      tbody.innerHTML = deadItems.map(item => {
        const name = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
        const cost = parseFloat(item.cost_price) || 0;
        const price = parseFloat(item.selling_price) || 0;
        const st = parseFloat(item.stock_qty) || 0;
        const locked = st * cost;
        const lastSale = itemLastSold[String(item.id)] || (isAR ? 'لم يُبع مطلقاً' : 'Never Sold');

        return `
        <tr>
          <td style="font-family:monospace;font-weight:700;color:var(--text-muted)">${item.item_code || '-'}</td>
          <td style="font-weight:700;color:var(--text-primary)">${Utils.sanitize(name)}</td>
          <td>${Utils.formatMoney(cost)}</td>
          <td style="color:var(--text-muted)">${Utils.formatMoney(price)}</td>
          <td style="text-align:center;font-weight:800;color:var(--danger)">${st}</td>
          <td style="text-align:right;font-weight:900;color:var(--danger)">${Utils.formatMoney(locked)}</td>
          <td style="text-align:center;font-size:0.8rem">${lastSale}</td>
          <td style="text-align:center">
            <span class="badge" style="background:rgba(239,68,68,0.12);color:#ef4444;font-size:0.72rem;font-weight:700">
              🏷️ ${isAR ? 'خصم تصفية 20%' : 'Clearance 20% OFF'}
            </span>
          </td>
        </tr>`;
      }).join('') || `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--success);font-weight:700">🎉 ${isAR ? 'مبارك! لا توجد أصناف راكدة في هذه الفترة' : 'Great news! No stagnant stock found in this period.'}</td></tr>`;
    }
  }

  function printDeadStockReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._deadStockData || [];
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <h2 style="text-align:center;margin-bottom:16px">⏳ ${isAR ? 'تقرير الأصناف الراكدة وبطيئة الحركة' : 'Slow-Moving & Dead Stock Report'}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:12px" border="1" cellpadding="6">
        <thead>
          <tr style="background:#f1f5f9">
            <th>Code</th><th>Item Name</th><th>Cost Price</th><th>Stock Qty</th><th>Locked Capital</th>
          </tr>
        </thead>
        <tbody>
          ${data.map(i => `<tr>
            <td>${i.item_code || ''}</td>
            <td>${isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar)}</td>
            <td>${Utils.formatMoney(i.cost_price || 0)}</td>
            <td>${i.stock_qty || 0}</td>
            <td>${Utils.formatMoney((i.stock_qty || 0) * (i.cost_price || 0))}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'Dead-Stock-Report');
  }

  function exportDeadStockReport() {
    const data = window._deadStockData || [];
    const isAR = i18n.getLang() === 'ar';
    Utils.exportCSV(data.map(i => ({
      Code: i.item_code || '',
      Name: isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar),
      Cost: i.cost_price || 0,
      Price: i.selling_price || 0,
      UnitsInStock: i.stock_qty || 0,
      LockedCapital: (parseFloat(i.stock_qty) || 0) * (parseFloat(i.cost_price) || 0)
    })), 'slow_moving_dead_stock_report');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 5. 👑 VIP Top Customers & Profitability Ranking
  // ═══════════════════════════════════════════════════════════════════
  async function renderTopCustomersReport(container, sortMode = 'profit') {
    const isAR = i18n.getLang() === 'ar';
    const customers = (await DB.getAll('customers')) || [];
    const enrichedSales = await _getEnrichedSales();

    // Map sales per customer
    const custStats = {};
    customers.forEach(c => {
      custStats[String(c.id)] = {
        id: c.id,
        name: isAR ? (c.name_ar || c.name) : (c.name || c.name_ar),
        phone: c.phone || '-',
        balance: parseFloat(c.balance) || 0,
        invoices: 0,
        totalSpend: 0,
        totalCost: 0,
        netProfit: 0
      };
    });

    enrichedSales.forEach(s => {
      const cid = String(s.customer_id);
      if (custStats[cid]) {
        custStats[cid].invoices++;
        custStats[cid].totalSpend += (parseFloat(s.grand_total) || 0);
        custStats[cid].totalCost += (parseFloat(s.total_cost) || 0);
        custStats[cid].netProfit += (parseFloat(s.net_profit) || 0);
      }
    });

    let ranked = Object.values(custStats).filter(c => c.invoices > 0 || c.balance > 0);
    if (sortMode === 'spend') {
      ranked.sort((a, b) => b.totalSpend - a.totalSpend);
    } else if (sortMode === 'invoices') {
      ranked.sort((a, b) => b.invoices - a.invoices);
    } else if (sortMode === 'balance') {
      ranked.sort((a, b) => b.balance - a.balance);
    } else {
      ranked.sort((a, b) => b.netProfit - a.netProfit);
    }

    window._topCustData = ranked;

    const totalVIPRev = ranked.reduce((s, c) => s + c.totalSpend, 0);
    const totalVIPProfit = ranked.reduce((s, c) => s + c.netProfit, 0);

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">👑 ${isAR ? 'كبار العملاء وتصنيف الربحية (VIP)' : 'VIP Customers & Profitability Ranking'}</h1>
          </div>
          <p>${isAR ? 'ترتيب العملاء حسب صافي الأرباح المحققة، حجم المشتريات، ومعدل السداد' : 'Rank customers by real net profit generated, invoice volume & credit standing'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printTopCustomersReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportTopCustomersReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- KPI Summary -->
      <div class="grid grid-4 mb-4">
        ${kpiCard(isAR ? 'عدد العملاء النشطين' : 'Active VIP Customers', ranked.length, 'primary', '👥', false)}
        ${kpiCard(isAR ? 'إجمالي مشتريات العملاء' : 'Total Revenue from VIPs', totalVIPRev, 'blue', '💳', true)}
        ${kpiCard(isAR ? 'صافي الأرباح من هؤلاء العملاء' : 'Net Profit from VIPs', totalVIPProfit, 'green', '📈', true)}
        ${kpiCard(isAR ? 'أفضل عميل ربحية' : 'Top Profitable Customer', ranked[0] ? Utils.formatMoney(ranked[0].netProfit) : '$0', 'gold', '🏆', false)}
      </div>

      <!-- Table -->
      <div class="card">
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th style="text-align:center;width:60px">${isAR ? 'الترتيب' : 'Rank'}</th>
                <th>${isAR ? 'اسم العميل' : 'Customer Name'}</th>
                <th>${isAR ? 'الهاتف' : 'Phone'}</th>
                <th style="text-align:center">${isAR ? 'عدد الفواتير' : 'Invoices'}</th>
                <th style="text-align:right">${isAR ? 'إجمالي المشتريات' : 'Total Spend'}</th>
                <th style="text-align:right">${isAR ? 'صافي الربح المحقق' : 'Net Profit Generated'}</th>
                <th style="text-align:center">${isAR ? 'هامش الربح%' : 'Margin %'}</th>
                <th style="text-align:right">${isAR ? 'الرصيد / الدين الحالي' : 'Outstanding Balance'}</th>
                <th style="text-align:center">${isAR ? 'كشف الحساب' : 'Statement'}</th>
              </tr>
            </thead>
            <tbody>
              ${ranked.map((c, idx) => {
                const margin = c.totalSpend > 0 ? Math.round((c.netProfit / c.totalSpend) * 100) : 0;
                const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `#${idx + 1}`;
                return `
                <tr>
                  <td style="text-align:center;font-weight:800;font-size:1.1rem">${medal}</td>
                  <td style="font-weight:700;color:var(--text-primary)">${Utils.sanitize(c.name)}</td>
                  <td style="font-family:monospace;color:var(--text-muted)">${Utils.sanitize(c.phone)}</td>
                  <td style="text-align:center;font-weight:700">${c.invoices}</td>
                  <td style="text-align:right;font-weight:700">${Utils.formatMoney(c.totalSpend)}</td>
                  <td style="text-align:right;font-weight:900;color:var(--success);font-size:0.95rem">${Utils.formatMoney(c.netProfit)}</td>
                  <td style="text-align:center"><span class="badge badge-success">${margin}%</span></td>
                  <td style="text-align:right;font-weight:700;color:${c.balance > 0 ? 'var(--danger)' : 'var(--text-muted)'}">
                    ${Utils.formatMoney(c.balance)}
                  </td>
                  <td style="text-align:center">
                    <button class="btn btn-ghost btn-sm" onclick="App.navigate('customer-statement')" style="padding:4px 8px;font-size:0.75rem">
                      📜 ${isAR ? 'الكشف' : 'View'}
                    </button>
                  </td>
                </tr>`;
              }).join('') || `<tr><td colspan="9" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات عملاء مسجلة' : 'No customer sales recorded'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
  }

  function printTopCustomersReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._topCustData || [];
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <h2 style="text-align:center;margin-bottom:16px">👑 ${isAR ? 'تقرير تصنيف كبار العملاء الأكثر ربحية' : 'VIP Customers Ranking Report'}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:12px" border="1" cellpadding="6">
        <thead>
          <tr style="background:#f1f5f9">
            <th>Rank</th><th>Customer</th><th>Phone</th><th>Invoices</th><th>Total Spend</th><th>Net Profit</th><th>Balance</th>
          </tr>
        </thead>
        <tbody>
          ${data.map((c, idx) => `<tr>
            <td>#${idx + 1}</td><td>${c.name}</td><td>${c.phone}</td><td>${c.invoices}</td><td>${Utils.formatMoney(c.totalSpend)}</td><td>${Utils.formatMoney(c.netProfit)}</td><td>${Utils.formatMoney(c.balance)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'VIP-Customers-Report');
  }

  function exportTopCustomersReport() {
    const data = window._topCustData || [];
    Utils.exportCSV(data.map((c, idx) => ({
      Rank: idx + 1,
      Customer: c.name,
      Phone: c.phone,
      Invoices: c.invoices,
      TotalSpend: c.totalSpend,
      NetProfit: c.netProfit,
      MarginPct: c.totalSpend > 0 ? Math.round((c.netProfit / c.totalSpend) * 100) : 0,
      OutstandingDebt: c.balance
    })), 'vip_customers_profitability_report');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 6. 🔍 Single Item 360° Stock Card & Audit Trail
  // ═══════════════════════════════════════════════════════════════════
  async function renderItemStockCardReport(container) {
    const isAR = i18n.getLang() === 'ar';
    const items = (await DB.getAll('items')) || [];
    const today = Utils.today();
    const firstDayOfYear = `${new Date().getFullYear()}-01-01`;

    window._stockCardAllItems = items;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">🔍 ${isAR ? 'كارت الصنف الشامل ومسار الحركة (360°)' : 'Single Item 360° Stock Card'}</h1>
          </div>
          <p>${isAR ? 'سجل محاسبي تفصيلي لحركة صنف محدد: رصيد البداية، المبيعات، المشتريات، المرتجعات، والتحويلات مع الرصيد اللحظي' : 'Complete audit trail and running stock balance for an individual product'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printItemStockCardReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportItemStockCardReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Item & Period Selectors -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:16px">
          <div class="grid grid-4" style="gap:12px">
            <div class="form-group" style="grid-column:1/3">
              <label class="form-label" style="font-weight:700">${isAR ? 'اختر الصنف المراد فحصه *' : 'Select Item To Inspect *'}</label>
              <select id="sc-item-select" class="form-control" onchange="Reports.loadItemStockCardData()">
                <option value="">${isAR ? '-- حدد الصنف من القائمة --' : '-- Choose a product --'}</option>
                ${items.map(i => {
                  const nm = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
                  return `<option value="${i.id}">[${i.item_code || 'N/A'}] ${nm} (الرصيد: ${i.stock_qty || 0})</option>`;
                }).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'من تاريخ' : 'From Date'}</label>
              <input type="date" id="sc-from" class="form-control" value="${firstDayOfYear}" onchange="Reports.loadItemStockCardData()">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'إلى تاريخ' : 'To Date'}</label>
              <input type="date" id="sc-to" class="form-control" value="${today}" onchange="Reports.loadItemStockCardData()">
            </div>
          </div>
        </div>
      </div>

      <!-- Selected Item Profile Banner -->
      <div id="sc-item-banner" class="mb-4" style="display:none"></div>

      <!-- KPI Summary Cards -->
      <div class="grid grid-4 mb-4" id="sc-kpi-grid" style="display:none"></div>

      <!-- Detailed Stock Card Table -->
      <div class="card" id="sc-card-table-wrap" style="display:none">
        <div class="card-header">
          <div class="card-title">📜 ${isAR ? 'جدول حركة الصنف والرصيد التراكمي' : 'Chronological Stock Movements & Running Balance'}</div>
        </div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
                <th>${isAR ? 'نوع الحركة' : 'Movement Type'}</th>
                <th>${isAR ? 'رقم السند / المرجع' : 'Ref / Doc #'}</th>
                <th style="text-align:center;color:var(--success)">${isAR ? 'الوارد (+)' : 'In (+)'}</th>
                <th style="text-align:center;color:var(--danger)">${isAR ? 'المنصرف (-)' : 'Out (-)'}</th>
                <th style="text-align:center;font-weight:900;background:rgba(59,130,246,0.08);color:var(--primary)">${isAR ? 'الرصيد اللحظي' : 'Running Balance'}</th>
                <th style="text-align:right">${isAR ? 'سعر الوحدة' : 'Unit Price'}</th>
                <th>${isAR ? 'المستخدم / المسؤول' : 'User / Party'}</th>
                <th>${isAR ? 'ملاحظات' : 'Notes'}</th>
              </tr>
            </thead>
            <tbody id="sc-table-body"></tbody>
          </table>
        </div>
      </div>
    </div>`;

    if (items.length > 0) {
      document.getElementById('sc-item-select').value = items[0].id;
      await loadItemStockCardData();
    }
  }

  async function loadItemStockCardData() {
    const isAR = i18n.getLang() === 'ar';
    const itemId = parseInt(document.getElementById('sc-item-select')?.value, 10);
    const from = document.getElementById('sc-from')?.value;
    const to = document.getElementById('sc-to')?.value;

    const banner = document.getElementById('sc-item-banner');
    const kpiGrid = document.getElementById('sc-kpi-grid');
    const tableWrap = document.getElementById('sc-card-table-wrap');

    if (!itemId) {
      if (banner) banner.style.display = 'none';
      if (kpiGrid) kpiGrid.style.display = 'none';
      if (tableWrap) tableWrap.style.display = 'none';
      return;
    }

    const item = (window._stockCardAllItems || []).find(i => i.id === itemId);
    if (!item) return;

    // Fetch transactions
    const sales = (await DB.getAll('sales')) || [];
    const purchases = (await DB.getAll('purchases')) || [];
    const adjustments = (await DB.getAll('stock_adjustments')) || [];
    const damages = (await DB.getAll('damaged_items')) || [];
    const transfers = (await DB.getAll('stock_transfers')) || [];

    const timeline = [];

    // 1. Sales
    sales.forEach(s => {
      let cart = [];
      try { cart = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
      cart.forEach(ci => {
        if (ci.item_id === itemId || String(ci.item_code) === String(item.item_code)) {
          const qty = parseFloat(ci.qty) || 1;
          const isReturn = ci.line_type === 'return' || (s.type === 'return');
          timeline.push({
            date: s.created_at || s.doc_date || '',
            type: isReturn ? (isAR ? 'مرتجع بيع' : 'Sales Return') : (isAR ? 'فاتورة بيع' : 'POS Sale'),
            typeKey: isReturn ? 'return' : 'sale',
            ref: s.receipt_no || s.ref || `INV-${s.id}`,
            inQty: isReturn ? qty : 0,
            outQty: isReturn ? 0 : qty,
            price: ci.price || item.selling_price || 0,
            user: s.cashier || s.user_name || 'Cashier',
            notes: s.customer_name ? `${isAR ? 'العميل:' : 'Cust:'} ${s.customer_name}` : ''
          });
        }
      });
    });

    // 2. Purchases
    purchases.forEach(p => {
      let cart = [];
      try { cart = typeof p.items === 'string' ? JSON.parse(p.items) : (p.items || []); } catch(e) {}
      cart.forEach(ci => {
        if (ci.item_id === itemId || String(ci.item_code) === String(item.item_code)) {
          const qty = parseFloat(ci.qty) || 1;
          timeline.push({
            date: p.created_at || p.doc_date || '',
            type: isAR ? 'فاتورة شراء' : 'Purchase Receipt',
            typeKey: 'purchase',
            ref: p.ref || `PO-${p.id}`,
            inQty: qty,
            outQty: 0,
            price: ci.cost || item.cost_price || 0,
            user: p.supplier_name || 'Supplier',
            notes: `${isAR ? 'مشتريات واردة' : 'Inbound purchase'}`
          });
        }
      });
    });

    // 3. Adjustments
    adjustments.forEach(adj => {
      if (adj.item_id === itemId || String(adj.item_code) === String(item.item_code)) {
        const delta = parseFloat(adj.delta || adj.qty) || 0;
        timeline.push({
          date: adj.created_at || '',
          type: isAR ? 'تسوية مخزون' : 'Stock Adjustment',
          typeKey: 'adjustment',
          ref: adj.ref || `ADJ-${adj.id}`,
          inQty: delta > 0 ? delta : 0,
          outQty: delta < 0 ? Math.abs(delta) : 0,
          price: item.cost_price || 0,
          user: adj.user_name || 'Admin',
          notes: adj.reason || (isAR ? 'جرد وتعديل' : 'Audit adjustment')
        });
      }
    });

    // 4. Damaged Items
    damages.forEach(d => {
      if (d.item_id === itemId || String(d.item_code) === String(item.item_code)) {
        const qty = parseFloat(d.qty) || 1;
        timeline.push({
          date: d.created_at || '',
          type: isAR ? 'بضاعة تالفة' : 'Damaged Scrap',
          typeKey: 'damage',
          ref: d.ref || `DMG-${d.id}`,
          inQty: 0,
          outQty: qty,
          price: item.cost_price || 0,
          user: d.user_name || 'Staff',
          notes: d.reason || (isAR ? 'تلف / كسر' : 'Damaged')
        });
      }
    });

    // 5. Inter-Store Transfers
    transfers.forEach(t => {
      if (t.item_id === itemId || String(t.item_code) === String(item.item_code)) {
        const qty = parseFloat(t.qty) || 1;
        timeline.push({
          date: t.created_at || '',
          type: isAR ? `تحويل (${t.from_wh_name} ➔ ${t.to_wh_name})` : `Transfer (${t.from_wh_name} -> ${t.to_wh_name})`,
          typeKey: 'transfer',
          ref: t.ref || `TRF-${t.id}`,
          inQty: 0,
          outQty: 0,
          price: item.cost_price || 0,
          user: t.user_name || 'Manager',
          notes: `${t.from_wh_name} ➔ ${t.to_wh_name}`
        });
      }
    });

    // Sort chronologically ascending
    timeline.sort((a, b) => new Date(a.date) - new Date(b.date));

    // Calculate Running Balance
    const currentFinalStock = parseFloat(item.stock_qty) || 0;
    
    // Work forward: calculate starting balance from transactions
    let running = 0;
    const computedRows = timeline.map(r => {
      running += (r.inQty - r.outQty);
      return { ...r, runningBalance: running };
    });

    // Filter by date range for display
    const displayRows = computedRows.filter(r => {
      const d = (r.date || '').slice(0, 10);
      if (from && d < from) return false;
      if (to && d > to) return false;
      return true;
    });

    window._stockCardData = { item, rows: displayRows };

    // Render Banner
    if (banner) {
      banner.style.display = 'block';
      const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
      banner.innerHTML = `
      <div class="card" style="padding:16px;background:linear-gradient(135deg, rgba(14,165,233,0.1) 0%, rgba(59,130,246,0.1) 100%);border:1px solid rgba(14,165,233,0.3)">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:14px">
            <div style="width:48px;height:48px;border-radius:12px;background:#0ea5e9;display:flex;align-items:center;justify-content:center;font-size:24px;color:white">📦</div>
            <div>
              <div style="font-weight:900;font-size:1.2rem;color:var(--text-primary)">${Utils.sanitize(itemName)}</div>
              <div style="font-size:0.8rem;color:var(--text-muted);display:flex;gap:12px;margin-top:2px">
                <span><strong>${isAR ? 'الكود:' : 'Code:'}</strong> <code style="color:var(--primary)">${item.item_code || '-'}</code></span>
                <span><strong>${isAR ? 'الباركود:' : 'Barcode:'}</strong> ${item.barcode || '-'}</span>
                <span><strong>${isAR ? 'التكلفة:' : 'Cost:'}</strong> ${Utils.formatMoney(item.cost_price || 0)}</span>
                <span><strong>${isAR ? 'سعر البيع:' : 'Price:'}</strong> ${Utils.formatMoney(item.selling_price || 0)}</span>
              </div>
            </div>
          </div>
          <div style="text-align:right">
            <div style="font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;font-weight:700">${isAR ? 'الرصيد الفعلي الحالي' : 'Current Physical Stock'}</div>
            <div style="font-size:1.6rem;font-weight:900;color:var(--primary)">${item.stock_qty || 0} <span style="font-size:0.9rem;font-weight:600">${isAR ? (item.unit || 'قطعة') : (item.unit || 'pcs')}</span></div>
          </div>
        </div>
      </div>`;
    }

    // Render KPIs
    let totalIn = 0, totalOut = 0;
    displayRows.forEach(r => {
      totalIn += r.inQty;
      totalOut += r.outQty;
    });

    if (kpiGrid) {
      kpiGrid.style.display = 'grid';
      kpiGrid.innerHTML = `
        ${kpiCard(isAR ? 'إجمالي الوارد في الفترة (+)' : 'Total Inbound (+)', totalIn, 'success', '📥', false, isAR ? ' وحدة' : ' units')}
        ${kpiCard(isAR ? 'إجمالي المنصرف في الفترة (-)' : 'Total Outbound (-)', totalOut, 'danger', '📤', false, isAR ? ' وحدة' : ' units')}
        ${kpiCard(isAR ? 'صافي حركة المخزون' : 'Net Movement Delta', totalIn - totalOut, 'primary', '📊', false, isAR ? ' وحدة' : ' units')}
        ${kpiCard(isAR ? 'عدد الحركات المسجلة' : 'Recorded Transactions', displayRows.length, 'warning', '📜', false)}
      `;
    }

    // Render Table
    if (tableWrap) tableWrap.style.display = 'block';
    const tbody = document.getElementById('sc-table-body');
    if (tbody) {
      tbody.innerHTML = displayRows.map(r => {
        const typeBadgeColor = r.typeKey === 'sale' ? 'badge-primary' : r.typeKey === 'purchase' ? 'badge-success' : r.typeKey === 'return' ? 'badge-warning' : 'badge-danger';
        return `
        <tr>
          <td style="font-size:0.78rem;color:var(--text-muted)">${Utils.formatDate(r.date)}</td>
          <td><span class="badge ${typeBadgeColor}">${Utils.sanitize(r.type)}</span></td>
          <td style="font-family:monospace;font-weight:700;color:var(--primary)">${Utils.sanitize(r.ref)}</td>
          <td style="text-align:center;font-weight:800;color:var(--success)">${r.inQty > 0 ? `+${r.inQty}` : '-'}</td>
          <td style="text-align:center;font-weight:800;color:var(--danger)">${r.outQty > 0 ? `-${r.outQty}` : '-'}</td>
          <td style="text-align:center;font-weight:900;font-size:0.95rem;background:rgba(59,130,246,0.06);color:var(--text-primary)">${r.runningBalance}</td>
          <td style="text-align:right">${Utils.formatMoney(r.price)}</td>
          <td style="font-size:0.8rem">${Utils.sanitize(r.user)}</td>
          <td style="font-size:0.8rem;color:var(--text-secondary)">${Utils.sanitize(r.notes || '-')}</td>
        </tr>`;
      }).join('') || `<tr><td colspan="9" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد حركات مسجلة لهذا الصنف في هذه الفترة' : 'No movements found for this item in selected range'}</td></tr>`;
    }
  }

  function printItemStockCardReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._stockCardData;
    if (!data || !data.item) return;

    const item = data.item;
    const rows = data.rows || [];
    const itemName = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);

    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <div style="text-align:center;margin-bottom:16px">
        <h2 style="margin:0">🔍 ${isAR ? 'كارت الصنف الشامل ومسار الحركة' : 'Single Item Stock Card'}</h2>
        <div style="font-size:14px;font-weight:bold;color:#0284c7;margin-top:4px">${itemName} (${item.item_code || ''})</div>
        <div style="font-size:11px;color:#666;margin-top:2px">${isAR ? 'الرصيد الحالي:' : 'Current Stock:'} <strong>${item.stock_qty || 0}</strong> | ${isAR ? 'تاريخ التقرير:' : 'Date:'} ${Utils.today()}</div>
      </div>
      <table style="width:100%;border-collapse:collapse;font-size:11px" border="1" cellpadding="5">
        <thead>
          <tr style="background:#f1f5f9">
            <th>${isAR ? 'التاريخ' : 'Date'}</th>
            <th>${isAR ? 'نوع الحركة' : 'Type'}</th>
            <th>${isAR ? 'المرجع' : 'Ref #'}</th>
            <th>${isAR ? 'الوارد (+)' : 'In (+)'}</th>
            <th>${isAR ? 'المنصرف (-)' : 'Out (-)'}</th>
            <th>${isAR ? 'الرصيد اللحظي' : 'Running Bal'}</th>
            <th>${isAR ? 'السعر' : 'Price'}</th>
            <th>${isAR ? 'المستخدم / الطرف' : 'User'}</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map(r => `<tr>
            <td>${Utils.formatDate(r.date)}</td>
            <td>${r.type}</td>
            <td>${r.ref}</td>
            <td style="text-align:center;color:green">${r.inQty || ''}</td>
            <td style="text-align:center;color:red">${r.outQty || ''}</td>
            <td style="text-align:center;font-weight:bold">${r.runningBalance}</td>
            <td style="text-align:right">${Utils.formatMoney(r.price)}</td>
            <td>${r.user}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;

    Utils.printElement(html, `StockCard-${item.item_code || item.id}`);
  }

  function exportItemStockCardReport() {
    const data = window._stockCardData;
    if (!data || !data.item) return;
    const rows = data.rows || [];
    Utils.exportCSV(rows.map(r => ({
      Date: r.date,
      MovementType: r.type,
      Ref: r.ref,
      InQty: r.inQty,
      OutQty: r.outQty,
      RunningBalance: r.runningBalance,
      UnitPrice: r.price,
      User: r.user,
      Notes: r.notes
    })), `stock_card_${data.item.item_code || data.item.id}`);
  }

  // ═══════════════════════════════════════════════════════════════════
  // 7. 🏆 ABC Inventory Classification & Turnover Velocity
  // ═══════════════════════════════════════════════════════════════════
  async function renderABCAnalysisReport(container) {
    const isAR = i18n.getLang() === 'ar';
    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">🏆 ${isAR ? 'تحليل تصنيف المخزون ABC ومعدل الدوران' : 'ABC Inventory Classification & Velocity'}</h1>
          </div>
          <p>${isAR ? 'تصنيف المنتجات حسب مساهمتها في الأرباح والمبيعات: الفئة A (80% من المبيعات)، الفئة B (15%)، والفئة C (5%)' : 'Pareto 80/20 inventory ranking with Days Sales of Inventory (DSI) and stock turnover ratio'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printABCReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportABCReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Filters -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:16px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:12px">
              <label class="form-label" style="margin:0;font-weight:700">${isAR ? 'فترة تحليل المبيعات والدوران:' : 'Analysis Velocity Period:'}</label>
              <select id="abc-period" class="form-control" style="width:220px" onchange="Reports.loadABCAnalysisData()">
                <option value="30">${isAR ? 'آخر 30 يوماً (سريع)' : 'Last 30 Days (Fast Pace)'}</option>
                <option value="90" selected>${isAR ? 'آخر 90 يوماً (المعيار ربع السنوي)' : 'Last 90 Days (Quarterly Standard)'}</option>
                <option value="365">${isAR ? 'آخر سنة كاملة (365 يوماً)' : 'Last 1 Year (Annual)'}</option>
              </select>
            </div>
            <div style="font-size:0.8rem;color:var(--text-muted)">
              <span class="badge" style="background:#22c55e;color:white">Class A: 80% Rev</span>
              <span class="badge" style="background:#3b82f6;color:white">Class B: 15% Rev</span>
              <span class="badge" style="background:#f97316;color:white">Class C: 5% Rev</span>
            </div>
          </div>
        </div>
      </div>

      <!-- ABC KPI Cards -->
      <div class="grid grid-4 mb-4" id="abc-kpi-grid"></div>

      <!-- Table -->
      <div class="card">
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th style="text-align:center;width:70px">${isAR ? 'الفئة' : 'Class'}</th>
                <th>${isAR ? 'الكود' : 'Code'}</th>
                <th>${isAR ? 'اسم الصنف' : 'Item Name'}</th>
                <th style="text-align:center">${isAR ? 'الكمية المباعة' : 'Units Sold'}</th>
                <th style="text-align:right">${isAR ? 'إجمالي الإيرادات' : 'Revenue ($)'}</th>
                <th style="text-align:center">${isAR ? 'الحصة %' : 'Share %'}</th>
                <th style="text-align:center">${isAR ? 'التراكمي %' : 'Cumul %'}</th>
                <th style="text-align:center">${isAR ? 'المخزون الحالي' : 'Stock on Hand'}</th>
                <th style="text-align:center">${isAR ? 'أيام نفاد المخزون (DSI)' : 'Days of Inventory'}</th>
                <th>${isAR ? 'التوجيه الإداري الذكي' : 'Strategic Action'}</th>
              </tr>
            </thead>
            <tbody id="abc-table-body"></tbody>
          </table>
        </div>
      </div>
    </div>`;

    await loadABCAnalysisData();
  }

  async function loadABCAnalysisData() {
    const isAR = i18n.getLang() === 'ar';
    const periodDays = parseInt(document.getElementById('abc-period')?.value || '90', 10);
    const items = (await DB.getAll('items')) || [];
    const sales = (await DB.getAll('sales')) || [];

    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - periodDays);
    const cutoffStr = cutoff.toISOString().slice(0, 10);

    // Aggregate sales per item
    const itemSales = {};
    items.forEach(i => {
      itemSales[String(i.id)] = {
        item: i,
        qtySold: 0,
        revenue: 0,
        cost: 0
      };
    });

    sales.forEach(s => {
      const d = (s.created_at || s.doc_date || '').slice(0, 10);
      if (d < cutoffStr) return;

      let cart = [];
      try { cart = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
      cart.forEach(ci => {
        const id = String(ci.item_id || ci.id);
        if (itemSales[id]) {
          const q = parseFloat(ci.qty) || 1;
          const p = parseFloat(ci.price) || 0;
          const disc = parseFloat(ci.disc_pct) || 0;
          const rev = q * p * (1 - disc / 100);
          itemSales[id].qtySold += q;
          itemSales[id].revenue += rev;
        }
      });
    });

    const totalRevenueAll = Object.values(itemSales).reduce((s, x) => s + x.revenue, 0);

    // Sort by revenue descending
    const sorted = Object.values(itemSales).sort((a, b) => b.revenue - a.revenue);

    let cumulativeRevenue = 0;
    let classACount = 0, classBCount = 0, classCCount = 0;

    const abcClassified = sorted.map(row => {
      cumulativeRevenue += row.revenue;
      const sharePct = totalRevenueAll > 0 ? (row.revenue / totalRevenueAll) * 100 : 0;
      const cumulPct = totalRevenueAll > 0 ? (cumulativeRevenue / totalRevenueAll) * 100 : 100;

      let classification = 'C';
      if (cumulPct <= 80 || (cumulPct > 80 && cumulativeRevenue - row.revenue < totalRevenueAll * 0.8)) {
        classification = 'A';
        classACount++;
      } else if (cumulPct <= 95) {
        classification = 'B';
        classBCount++;
      } else {
        classification = 'C';
        classCCount++;
      }

      // Days Sales of Inventory (DSI)
      const currentStock = parseFloat(row.item.stock_qty) || 0;
      const dailyVelocity = row.qtySold / periodDays;
      const dsi = dailyVelocity > 0 ? Math.round(currentStock / dailyVelocity) : (currentStock > 0 ? 999 : 0);

      return {
        ...row,
        sharePct: Utils.round(sharePct),
        cumulPct: Utils.round(cumulPct),
        classification,
        dsi
      };
    });

    window._abcReportData = abcClassified;

    // Render KPI
    const kpi = document.getElementById('abc-kpi-grid');
    if (kpi) {
      kpi.innerHTML = `
        ${kpiCard(isAR ? 'أصناف الفئة A (نجوم الإيرادات 80%)' : 'Class A (Top 80% Revenue)', classACount, 'success', '🌟', false, isAR ? ' صنفاً' : ' items')}
        ${kpiCard(isAR ? 'أصناف الفئة B (متوسطة 15%)' : 'Class B (Moderate 15%)', classBCount, 'primary', '📦', false, isAR ? ' صنفاً' : ' items')}
        ${kpiCard(isAR ? 'أصناف الفئة C (هامشية 5%)' : 'Class C (Marginal 5%)', classCCount, 'warning', '⏳', false, isAR ? ' صنفاً' : ' items')}
        ${kpiCard(isAR ? 'إجمالي مبيعات فترة التحليل' : 'Total Evaluated Revenue', totalRevenueAll, 'blue', '💰', true)}
      `;
    }

    // Render Table
    const tbody = document.getElementById('abc-table-body');
    if (tbody) {
      tbody.innerHTML = abcClassified.map(r => {
        const name = isAR ? (r.item.name_ar || r.item.name_en) : (r.item.name_en || r.item.name_ar);
        const badgeColor = r.classification === 'A' ? 'background:#22c55e;color:white' : r.classification === 'B' ? 'background:#3b82f6;color:white' : 'background:#f97316;color:white';
        
        let action = '';
        if (r.classification === 'A') {
          action = isAR ? '⭐ تأمين حد أمان مرتفع وعدم النفاد' : '⭐ Maintain high safety stock; priority PO';
        } else if (r.classification === 'B') {
          action = isAR ? '📦 إعادة طلب قياسية منتظمة' : '📦 Regular standard replenishment';
        } else {
          action = isAR ? '⚠️ تقليل حجم الطلب وتجنب التكدس' : '⚠️ Reduce order sizes; clearance if stale';
        }

        const dsiBadge = r.dsi === 999 ? (isAR ? 'لا حركة' : 'No sales') : `${r.dsi} ${isAR ? 'يوم' : 'days'}`;
        const dsiColor = r.dsi <= 7 && r.classification === 'A' ? 'color:var(--danger);font-weight:900' : 'color:var(--text-primary)';

        return `
        <tr>
          <td style="text-align:center">
            <span class="badge" style="${badgeColor};font-weight:900;font-size:0.85rem;padding:4px 10px">${r.classification}</span>
          </td>
          <td style="font-family:monospace;font-weight:700;color:var(--text-muted)">${r.item.item_code || '-'}</td>
          <td style="font-weight:700;color:var(--text-primary)">${Utils.sanitize(name)}</td>
          <td style="text-align:center;font-weight:700">${r.qtySold}</td>
          <td style="text-align:right;font-weight:800;color:var(--success)">${Utils.formatMoney(r.revenue)}</td>
          <td style="text-align:center;font-weight:700">${r.sharePct}%</td>
          <td style="text-align:center;color:var(--text-muted)">${r.cumulPct}%</td>
          <td style="text-align:center;font-weight:700">${r.item.stock_qty || 0}</td>
          <td style="text-align:center;${dsiColor}">${dsiBadge}</td>
          <td style="font-size:0.78rem;font-weight:600">${action}</td>
        </tr>`;
      }).join('') || `<tr><td colspan="10" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات كافية للتحليل' : 'Not enough sales data for ABC analysis'}</td></tr>`;
    }
  }

  function printABCReport() {
    const isAR = i18n.getLang() === 'ar';
    const data = window._abcReportData || [];
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <h2 style="text-align:center;margin-bottom:16px">🏆 ${isAR ? 'تقرير تصنيف المخزون ABC ومعدل الدوران' : 'ABC Inventory Classification Report'}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:11px" border="1" cellpadding="5">
        <thead>
          <tr style="background:#f1f5f9">
            <th>Class</th><th>Code</th><th>Item Name</th><th>Units Sold</th><th>Revenue</th><th>Share %</th><th>Stock</th><th>DSI</th>
          </tr>
        </thead>
        <tbody>
          ${data.map(r => `<tr>
            <td style="text-align:center;font-weight:bold">${r.classification}</td>
            <td>${r.item.item_code || ''}</td>
            <td>${isAR ? (r.item.name_ar || r.item.name_en) : (r.item.name_en || r.item.name_ar)}</td>
            <td style="text-align:center">${r.qtySold}</td>
            <td style="text-align:right">${Utils.formatMoney(r.revenue)}</td>
            <td style="text-align:center">${r.sharePct}%</td>
            <td style="text-align:center">${r.item.stock_qty || 0}</td>
            <td style="text-align:center">${r.dsi}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'ABC-Inventory-Report');
  }

  function exportABCReport() {
    const data = window._abcReportData || [];
    const isAR = i18n.getLang() === 'ar';
    Utils.exportCSV(data.map(r => ({
      Class: r.classification,
      Code: r.item.item_code || '',
      ItemName: isAR ? (r.item.name_ar || r.item.name_en) : (r.item.name_en || r.item.name_ar),
      UnitsSold: r.qtySold,
      Revenue: r.revenue,
      SharePct: r.sharePct,
      CumulPct: r.cumulPct,
      StockOnHand: r.item.stock_qty || 0,
      DaysOfInventory: r.dsi
    })), 'abc_inventory_analysis');
  }

  // ═══════════════════════════════════════════════════════════════════
  // 8. ⚖️ Physical Stock Count Audit & Discrepancy Reconciliation
  // ═══════════════════════════════════════════════════════════════════
  let _auditSubFilter = 'all';
  async function renderStockAuditVarianceReport(container, subFilter = 'all') {
    _auditSubFilter = subFilter || 'all';
    const isAR = i18n.getLang() === 'ar';
    const items = (await DB.getAll('items')) || [];

    // Initialize audit working state
    window._auditItems = items.map(i => ({
      id: i.id,
      item_code: i.item_code,
      name_ar: i.name_ar,
      name_en: i.name_en,
      cost_price: parseFloat(i.cost_price) || 0,
      selling_price: parseFloat(i.selling_price) || 0,
      systemQty: parseFloat(i.stock_qty) || 0,
      countedQty: parseFloat(i.stock_qty) || 0,
      variance: 0,
      varianceValue: 0
    }));

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-ghost btn-sm" onclick="Reports._nav('hub')">← ${isAR ? 'مركز التقارير' : 'Back to Hub'}</button>
            <h1 style="margin:0">⚖️ ${isAR ? 'مطابقة وفروقات الجرد الفعلي للمخزون' : 'Physical Stock Count Audit & Reconciliation'}</h1>
          </div>
          <p>${isAR ? 'إدخال الجرد الفعلي، احتساب العجز والزيادة وقيمة الهدر المالي، والترحيل التلقائي إلى قيود التسوية' : 'Physical count verification, variance calculation & automated shrinkage reconciliation'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-success" onclick="Reports.postAuditAdjustments()" style="display:flex;align-items:center;gap:6px">
            <span>💾</span> ${isAR ? 'ترحيل واعتماد الجرد كـ تسوية' : 'Post Reconciliation to Stock'}
          </button>
          <button class="btn btn-secondary" onclick="Reports.printStockAuditReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportStockAuditReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير إكسل' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Quick Filter -->
      <div class="card mb-4">
        <div class="modal-body" style="padding:14px">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
            <input type="text" id="audit-search" class="form-control" placeholder="${isAR ? 'بحث بالاسم أو الكود لتسريع إدخال الجرد...' : 'Search item name or code...'}" style="max-width:380px" oninput="Reports.filterAuditTable()">
            <div style="font-size:0.82rem;color:var(--text-muted)">
              💡 ${isAR ? 'عدّل عمود (الجرد الفعلي) لأي صنف لحساب الفرق المالي فوراً' : 'Edit the (Physical Count) field to calculate shrinkage/surplus instantly'}
            </div>
          </div>
        </div>
      </div>

      <!-- KPI Summary -->
      <div class="grid grid-4 mb-4" id="audit-kpi-grid"></div>

      <!-- Audit Table -->
      <div class="card">
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الكود' : 'Code'}</th>
                <th>${isAR ? 'اسم الصنف' : 'Item Name'}</th>
                <th>${isAR ? 'سعر التكلفة' : 'Cost'}</th>
                <th style="text-align:center">${isAR ? 'الرصيد الدفتري (النظام)' : 'System Qty'}</th>
                <th style="text-align:center;width:130px;background:rgba(59,130,246,0.08);color:var(--primary)">${isAR ? 'الجرد الفعلي ✍️' : 'Physical Count ✍️'}</th>
                <th style="text-align:center">${isAR ? 'فرق الكمية' : 'Variance Qty'}</th>
                <th style="text-align:right">${isAR ? 'الأثر المالي ($)' : 'Financial Impact ($)'}</th>
                <th style="text-align:center">${isAR ? 'الحالة' : 'Status'}</th>
              </tr>
            </thead>
            <tbody id="audit-table-body"></tbody>
          </table>
        </div>
      </div>
    </div>`;

    renderAuditTable();
  }

  function renderAuditTable() {
    const isAR = i18n.getLang() === 'ar';
    const list = window._auditItems || [];
    const search = (document.getElementById('audit-search')?.value || '').toLowerCase().trim();

    let totalShrinkageVal = 0;
    let totalSurplusVal = 0;
    let discrepancyCount = 0;

    list.forEach(i => {
      i.variance = i.countedQty - i.systemQty;
      i.varianceValue = i.variance * i.cost_price;
      if (i.variance < 0) totalShrinkageVal += Math.abs(i.varianceValue);
      if (i.variance > 0) totalSurplusVal += i.varianceValue;
      if (i.variance !== 0) discrepancyCount++;
    });

    // Render KPIs
    const kpi = document.getElementById('audit-kpi-grid');
    if (kpi) {
      kpi.innerHTML = `
        ${kpiCard(isAR ? 'إجمالي الأصناف المجرودة' : 'Audited Products', list.length, 'primary', '📦', false)}
        ${kpiCard(isAR ? 'عدد الأصناف بفروقات' : 'Discrepancy SKUs', discrepancyCount, discrepancyCount > 0 ? 'warning' : 'success', '⚠️', false)}
        ${kpiCard(isAR ? 'خسائر العجز والهدر (-)' : 'Total Shrinkage Deficit (-)', totalShrinkageVal, 'danger', '📉', true)}
        ${kpiCard(isAR ? 'قيمة الزيادة في المخزون (+)' : 'Total Surplus Over (+)', totalSurplusVal, 'success', '📈', true)}
      `;
    }

    const filtered = list.filter(i => {
      if (_auditSubFilter === 'variance' && i.variance === 0) return false;
      if (_auditSubFilter === 'shortage' && i.variance >= 0) return false;
      if (_auditSubFilter === 'surplus' && i.variance <= 0) return false;
      if (!search) return true;
      const text = ((i.name_ar || '') + ' ' + (i.name_en || '') + ' ' + (i.item_code || '')).toLowerCase();
      return text.includes(search);
    });

    const tbody = document.getElementById('audit-table-body');
    if (tbody) {
      tbody.innerHTML = filtered.map(i => {
        const name = isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar);
        const hasDiff = i.variance !== 0;
        const statusBadge = i.variance === 0 
          ? `<span class="badge badge-success">✅ ${isAR ? 'مطابق' : 'Match'}</span>`
          : i.variance < 0 
          ? `<span class="badge badge-danger">📉 ${isAR ? 'عجز' : 'Deficit'}</span>` 
          : `<span class="badge badge-warning">📈 ${isAR ? 'زيادة' : 'Surplus'}</span>`;

        const varColor = i.variance === 0 ? 'var(--text-muted)' : i.variance < 0 ? 'var(--danger)' : 'var(--success)';

        return `
        <tr>
          <td style="font-family:monospace;font-weight:700;color:var(--text-muted)">${i.item_code || '-'}</td>
          <td style="font-weight:700;color:var(--text-primary)">${Utils.sanitize(name)}</td>
          <td>${Utils.formatMoney(i.cost_price)}</td>
          <td style="text-align:center;font-weight:700">${i.systemQty}</td>
          <td style="text-align:center">
            <input type="number" step="any" class="form-control form-control-sm" value="${i.countedQty}" style="width:100px;margin:0 auto;text-align:center;font-weight:900;background:rgba(59,130,246,0.06)" onchange="Reports.updateAuditRow(${i.id}, this.value)">
          </td>
          <td style="text-align:center;font-weight:900;color:${varColor}">${i.variance > 0 ? `+${i.variance}` : i.variance}</td>
          <td style="text-align:right;font-weight:900;color:${varColor}">${Utils.formatMoney(i.varianceValue)}</td>
          <td style="text-align:center">${statusBadge}</td>
        </tr>`;
      }).join('') || `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد نتائج' : 'No items'}</td></tr>`;
    }
  }

  function updateAuditRow(itemId, val) {
    const list = window._auditItems || [];
    const item = list.find(i => i.id === itemId);
    if (item) {
      item.countedQty = parseFloat(val) || 0;
      renderAuditTable();
    }
  }

  function filterAuditTable() {
    renderAuditTable();
  }

  async function postAuditAdjustments() {
    const isAR = i18n.getLang() === 'ar';
    const list = (window._auditItems || []).filter(i => i.variance !== 0);

    if (!list.length) {
      return Utils.toast(isAR ? 'جميع الأصناف مطابقة ولا توجد فروقات لترحيلها!' : 'All items are fully matched. No adjustments needed!', 'info');
    }

    if (!confirm(isAR ? `هل أنت متأكد من ترحيل فروقات الجرد لعدد (${list.length}) صنفاً وتحديث أرصدة النظام؟` : `Confirm posting stock count adjustments for (${list.length}) items?`)) {
      return;
    }

    const ref = await DB.nextSeq('stock_adjustments', 'ADJ-AUDIT-', 5);
    const user = Auth.getUser();

    for (const row of list) {
      const orig = await DB.get('items', row.id);
      if (orig) {
        orig.stock_qty = row.countedQty;
        if (!orig.warehouse_stocks) orig.warehouse_stocks = { 1: row.countedQty };
        else orig.warehouse_stocks[1] = row.countedQty;
        await DB.update('items', orig);

        await DB.add('stock_adjustments', {
          item_id: row.id,
          item_code: row.item_code,
          ref,
          qty: row.variance,
          delta: row.variance,
          type: row.variance > 0 ? 'increase' : 'decrease',
          reason: `Physical Count Reconciliation (Diff: ${row.variance})`,
          user_name: user?.full_name || user?.username || 'Auditor',
          created_at: new Date().toISOString()
        });
      }
    }

    Utils.toast(isAR ? 'تم ترحيل واعتماد الجرد وتحديث المخزون بنجاح!' : 'Physical stock count posted successfully!', 'success');
    await renderStockAuditVarianceReport(document.getElementById('page-content'));
  }

  function printStockAuditReport() {
    const isAR = i18n.getLang() === 'ar';
    const list = window._auditItems || [];
    const html = `
    <div style="font-family:sans-serif;padding:20px" dir="${isAR ? 'rtl' : 'ltr'}">
      <h2 style="text-align:center;margin-bottom:16px">⚖️ ${isAR ? 'تقرير مطابقة وفروقات الجرد الفعلي للمخزون' : 'Physical Stock Audit Report'}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:11px" border="1" cellpadding="5">
        <thead>
          <tr style="background:#f1f5f9">
            <th>Code</th><th>Item Name</th><th>Cost</th><th>System Qty</th><th>Counted Qty</th><th>Variance</th><th>Impact ($)</th>
          </tr>
        </thead>
        <tbody>
          ${list.map(i => `<tr>
            <td>${i.item_code || ''}</td>
            <td>${isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar)}</td>
            <td>${Utils.formatMoney(i.cost_price)}</td>
            <td style="text-align:center">${i.systemQty}</td>
            <td style="text-align:center;font-weight:bold">${i.countedQty}</td>
            <td style="text-align:center;color:${i.variance < 0 ? 'red' : 'green'}">${i.variance}</td>
            <td style="text-align:right">${Utils.formatMoney(i.varianceValue)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
    Utils.printElement(html, 'Stock-Audit-Report');
  }

  function exportStockAuditReport() {
    const list = window._auditItems || [];
    const isAR = i18n.getLang() === 'ar';
    Utils.exportCSV(list.map(i => ({
      Code: i.item_code || '',
      ItemName: isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar),
      CostPrice: i.cost_price,
      SystemQty: i.systemQty,
      PhysicalCounted: i.countedQty,
      VarianceQty: i.variance,
      FinancialImpact: i.varianceValue,
      Status: i.variance === 0 ? 'Match' : i.variance < 0 ? 'Deficit' : 'Surplus'
    })), 'physical_stock_count_audit');
  }

  // ── Modern Analytics & Graphs Dashboard ───────────────────────
  let _activeAnalyticsPeriod = 'month';
  window._analyticsChartInstances = {};

  function _destroyAnalyticsCharts() {
    if (window._analyticsChartInstances) {
      Object.keys(window._analyticsChartInstances).forEach(key => {
        try {
          if (window._analyticsChartInstances[key] && typeof window._analyticsChartInstances[key].destroy === 'function') {
            window._analyticsChartInstances[key].destroy();
          }
        } catch(e) {}
      });
    }
    window._analyticsChartInstances = {};
  }

  function getPeriod() {
    return _activeAnalyticsPeriod;
  }

  async function setAnalyticsPeriod(period, btnEl) {
    _activeAnalyticsPeriod = period;
    if (btnEl) {
      const container = btnEl.parentElement;
      container.querySelectorAll('.btn').forEach(b => {
        b.className = 'btn btn-sm btn-secondary';
      });
      btnEl.className = 'btn btn-sm btn-primary';
    }
    await loadAnalyticsData();
  }

  async function applyCustomAnalyticsDate() {
    _activeAnalyticsPeriod = 'custom';
    await loadAnalyticsData();
  }

  async function renderAnalyticsGraphs(container, defaultPeriod) {
    if (defaultPeriod && ['today', '7days', 'month', 'year', 'all'].includes(defaultPeriod)) {
      _activeAnalyticsPeriod = defaultPeriod;
    }
    const isAR = i18n.getLang() === 'ar';
    _destroyAnalyticsCharts();

    const today = Utils.today();
    const thisMonth = today.slice(0, 7);

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:10px">
            <button class="btn btn-secondary btn-sm" onclick="Reports._nav('hub', this.closest('.animate-slide').parentElement)">
              ← ${isAR ? 'العودة لمركز التقارير' : 'Back to Hub'}
            </button>
            <h1 style="margin:0">📈 ${isAR ? 'الرسوم البيانية والتحليلات المتقدمة' : 'Modern Analytics & Visual Graphs'}</h1>
          </div>
          <p style="margin-top:4px">${isAR ? 'تحليل الأداء البصري، اتجاهات المبيعات، والأرباح، والأصناف الأكثر طلباً' : 'Visual performance trends, revenue curves, category distribution & peak hours'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-success" onclick="Reports.openDailyDigestModal()">
            📱 ${isAR ? 'ملخص واتساب' : 'WhatsApp Digest'}
          </button>
          <button class="btn btn-secondary" onclick="window.print()">
            🖨️ ${isAR ? 'طباعة الرسوم' : 'Print Charts'}
          </button>
        </div>
      </div>

      <!-- Filter Controls Bar -->
      <div class="card mb-4" style="padding:14px;background:var(--surface)">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn btn-sm ${_activeAnalyticsPeriod === 'today' ? 'btn-primary' : 'btn-secondary'}" onclick="Reports.setAnalyticsPeriod('today', this)">${isAR ? 'اليوم' : 'Today'}</button>
            <button class="btn btn-sm ${_activeAnalyticsPeriod === '7days' ? 'btn-primary' : 'btn-secondary'}" onclick="Reports.setAnalyticsPeriod('7days', this)">${isAR ? 'آخر 7 أيام' : 'Last 7 Days'}</button>
            <button class="btn btn-sm ${_activeAnalyticsPeriod === 'month' ? 'btn-primary' : 'btn-secondary'}" onclick="Reports.setAnalyticsPeriod('month', this)">${isAR ? 'هذا الشهر' : 'This Month'}</button>
            <button class="btn btn-sm ${_activeAnalyticsPeriod === 'year' ? 'btn-primary' : 'btn-secondary'}" onclick="Reports.setAnalyticsPeriod('year', this)">${isAR ? 'هذه السنة' : 'This Year'}</button>
            <button class="btn btn-sm ${_activeAnalyticsPeriod === 'all' ? 'btn-primary' : 'btn-secondary'}" onclick="Reports.setAnalyticsPeriod('all', this)">${isAR ? 'كل الفترات' : 'All Time'}</button>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <input type="date" class="form-control form-control-sm" id="analytics-date-from" value="${thisMonth}-01" style="width:140px">
            <span>→</span>
            <input type="date" class="form-control form-control-sm" id="analytics-date-to" value="${today}" style="width:140px">
            <button class="btn btn-primary btn-sm" onclick="Reports.applyCustomAnalyticsDate()">${isAR ? 'تطبيق' : 'Apply'}</button>
          </div>
        </div>
      </div>

      <!-- KPI Summary Cards -->
      <div class="grid grid-4 mb-4" id="analytics-kpi-cards">
        <div class="stat-card blue">
          <div class="stat-icon">💰</div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'إجمالي الإيرادات' : 'Total Revenue'}</div>
            <div class="stat-value" id="kpi-total-rev">...</div>
          </div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">📈</div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'إجمالي الأرباح الصافية' : 'Gross Net Profit'}</div>
            <div class="stat-value" id="kpi-total-profit">...</div>
          </div>
        </div>
        <div class="stat-card purple">
          <div class="stat-icon">🧾</div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'عدد الفواتير / المعاملات' : 'Total Transactions'}</div>
            <div class="stat-value" id="kpi-total-invoices">...</div>
          </div>
        </div>
        <div class="stat-card orange">
          <div class="stat-icon">🛍️</div>
          <div class="stat-info">
            <div class="stat-label">${isAR ? 'متوسط قيمة الفاتورة' : 'Avg Basket Value'}</div>
            <div class="stat-value" id="kpi-avg-basket">...</div>
          </div>
        </div>
      </div>

      <!-- Charts Grid 1: Revenue Trend (Full Width) -->
      <div class="card mb-4">
        <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
          <div class="card-title">📊 ${isAR ? 'مسار الإيرادات والأرباح اليومية' : 'Daily Revenue & Net Profit Trend'}</div>
          <div style="font-size:0.75rem;color:var(--text-muted)">USD ($)</div>
        </div>
        <div style="height:320px;padding:12px;position:relative">
          <canvas id="chart-sales-trend"></canvas>
        </div>
      </div>

      <!-- Charts Grid 2: Categories (Half) & Payment Methods (Half) -->
      <div class="grid grid-2 mb-4">
        <div class="card">
          <div class="card-header">
            <div class="card-title">🥧 ${isAR ? 'توزيع المبيعات حسب التصنيف' : 'Revenue by Category'}</div>
          </div>
          <div style="height:280px;padding:12px;position:relative">
            <canvas id="chart-category-pie"></canvas>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <div class="card-title">💳 ${isAR ? 'طرق الدفع المستخدمة' : 'Payment Methods Distribution'}</div>
          </div>
          <div style="height:280px;padding:12px;position:relative">
            <canvas id="chart-payment-doughnut"></canvas>
          </div>
        </div>
      </div>

      <!-- Charts Grid 3: Top Products (Half) & Peak Rush Hours (Half) -->
      <div class="grid grid-2 mb-4">
        <div class="card">
          <div class="card-header">
            <div class="card-title">🏆 ${isAR ? 'المنتجات الـ 10 الأكثر مبيعاً' : 'Top 10 Selling Products'}</div>
          </div>
          <div style="height:300px;padding:12px;position:relative">
            <canvas id="chart-top-products"></canvas>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <div class="card-title">⏰ ${isAR ? 'ساعات الذروة ونشاط المبيعات' : 'Peak Rush Hours Traffic'}</div>
          </div>
          <div style="height:300px;padding:12px;position:relative">
            <canvas id="chart-hourly-traffic"></canvas>
          </div>
        </div>
      </div>

    </div>`;

    setTimeout(loadAnalyticsData, 100);
  }

  async function loadAnalyticsData() {
    const isAR = i18n.getLang() === 'ar';
    const allEnriched = await _getEnrichedSales();
    const today = Utils.today();

    let filtered = [];
    if (_activeAnalyticsPeriod === 'today') {
      filtered = allEnriched.filter(s => (s.created_at || '').startsWith(today));
    } else if (_activeAnalyticsPeriod === '7days') {
      const d7 = new Date();
      d7.setDate(d7.getDate() - 7);
      const d7Str = d7.toISOString().slice(0, 10);
      filtered = allEnriched.filter(s => (s.created_at || '').slice(0, 10) >= d7Str);
    } else if (_activeAnalyticsPeriod === 'month') {
      const mStr = today.slice(0, 7);
      filtered = allEnriched.filter(s => (s.created_at || '').startsWith(mStr));
    } else if (_activeAnalyticsPeriod === 'year') {
      const yStr = today.slice(0, 4);
      filtered = allEnriched.filter(s => (s.created_at || '').startsWith(yStr));
    } else if (_activeAnalyticsPeriod === 'custom') {
      const from = document.getElementById('analytics-date-from')?.value || '1970-01-01';
      const to   = document.getElementById('analytics-date-to')?.value || '2099-12-31';
      filtered = allEnriched.filter(s => {
        const d = (s.created_at || '').slice(0, 10);
        return d >= from && d <= to;
      });
    } else {
      filtered = allEnriched;
    }

    // Compute KPIs
    const totalRev    = filtered.reduce((s, x) => s + (parseFloat(x.grand_total) || 0), 0);
    const totalProfit = filtered.reduce((s, x) => s + (parseFloat(x.net_profit) || 0), 0);
    const totalInvs   = filtered.length;
    const avgBasket   = totalInvs > 0 ? (totalRev / totalInvs) : 0;
    const marginPct   = totalRev > 0 ? ((totalProfit / totalRev) * 100).toFixed(1) : '0.0';

    const revEl    = document.getElementById('kpi-total-rev');
    const profitEl = document.getElementById('kpi-total-profit');
    const invEl    = document.getElementById('kpi-total-invoices');
    const basketEl = document.getElementById('kpi-avg-basket');

    if (revEl) revEl.textContent = Utils.formatMoney(totalRev);
    if (profitEl) profitEl.innerHTML = `${Utils.formatMoney(totalProfit)} <span style="font-size:0.75rem;opacity:0.85">(${marginPct}%)</span>`;
    if (invEl) invEl.textContent = totalInvs.toLocaleString();
    if (basketEl) basketEl.textContent = Utils.formatMoney(avgBasket);

    if (typeof Chart === 'undefined') {
      console.warn('Chart.js library not loaded yet');
      return;
    }

    _destroyAnalyticsCharts();

    const isDarkMode = document.documentElement.getAttribute('data-theme') !== 'light';
    const textColor = isDarkMode ? '#cbd5e1' : '#475569';
    const gridColor = isDarkMode ? 'rgba(255, 255, 255, 0.07)' : 'rgba(0, 0, 0, 0.06)';

    // ── 1. Daily Revenue & Net Profit Trend (Line / Area Chart) ──
    const dateMap = {};
    filtered.forEach(s => {
      const d = (s.created_at || '').slice(0, 10) || 'Unknown';
      if (!dateMap[d]) dateMap[d] = { rev: 0, profit: 0 };
      dateMap[d].rev += parseFloat(s.grand_total) || 0;
      dateMap[d].profit += parseFloat(s.net_profit) || 0;
    });

    const sortedDates = Object.keys(dateMap).sort();
    const trendLabels = sortedDates.length ? sortedDates : [today];
    const trendRev    = sortedDates.length ? sortedDates.map(d => Utils.round(dateMap[d].rev)) : [0];
    const trendProfit = sortedDates.length ? sortedDates.map(d => Utils.round(dateMap[d].profit)) : [0];

    const ctxTrend = document.getElementById('chart-sales-trend')?.getContext('2d');
    if (ctxTrend) {
      window._analyticsChartInstances.trend = new Chart(ctxTrend, {
        type: 'line',
        data: {
          labels: trendLabels,
          datasets: [
            {
              label: isAR ? 'الإيرادات ($)' : 'Revenue ($)',
              data: trendRev,
              borderColor: '#6366f1',
              backgroundColor: 'rgba(99, 102, 241, 0.15)',
              fill: true,
              tension: 0.35,
              borderWidth: 2.5,
              pointRadius: 3.5,
              pointHoverRadius: 6
            },
            {
              label: isAR ? 'الربح الصافي ($)' : 'Net Profit ($)',
              data: trendProfit,
              borderColor: '#10b981',
              backgroundColor: 'rgba(16, 185, 129, 0.15)',
              fill: true,
              tension: 0.35,
              borderWidth: 2.5,
              pointRadius: 3.5,
              pointHoverRadius: 6
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { labels: { color: textColor, font: { family: 'inherit', size: 12 } } },
            tooltip: { padding: 10, cornerRadius: 8 }
          },
          scales: {
            x: { grid: { color: gridColor }, ticks: { color: textColor } },
            y: { grid: { color: gridColor }, ticks: { color: textColor } }
          }
        }
      });
    }

    // ── 2. Category Distribution (Doughnut Chart) ──
    const catMap = {};
    filtered.forEach(s => {
      (s.enriched_items || []).forEach(ci => {
        const cat = ci.category_name || (isAR ? 'غير مصنف' : 'Uncategorized');
        catMap[cat] = (catMap[cat] || 0) + (ci.item_revenue || 0);
      });
    });

    const catLabels = Object.keys(catMap);
    const catData   = catLabels.map(k => Utils.round(catMap[k]));
    const catColors = ['#6366f1', '#a855f7', '#ec4899', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#8b5cf6', '#64748b'];

    const ctxCat = document.getElementById('chart-category-pie')?.getContext('2d');
    if (ctxCat) {
      window._analyticsChartInstances.cat = new Chart(ctxCat, {
        type: 'doughnut',
        data: {
          labels: catLabels.length ? catLabels : [isAR ? 'لا بيانات' : 'No Data'],
          datasets: [{
            data: catData.length ? catData : [1],
            backgroundColor: catColors,
            borderWidth: 2,
            borderColor: isDarkMode ? '#1e293b' : '#ffffff'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'right', labels: { color: textColor, font: { size: 11 } } }
          },
          cutout: '62%'
        }
      });
    }

    // ── 3. Payment Methods (Pie / Doughnut Chart) ──
    const payMap = { cash: 0, card: 0, credit: 0 };
    filtered.forEach(s => {
      const m = (s.payment_method || 'cash').toLowerCase();
      payMap[m] = (payMap[m] || 0) + (parseFloat(s.grand_total) || 0);
    });

    const payLabels = [isAR ? 'نقدي (Cash)' : 'Cash', isAR ? 'بطاقة (Card)' : 'Card', isAR ? 'على الحساب (Credit)' : 'On Account'];
    const payData   = [Utils.round(payMap.cash || 0), Utils.round(payMap.card || 0), Utils.round(payMap.credit || 0)];
    const payColors = ['#10b981', '#3b82f6', '#f59e0b'];

    const ctxPay = document.getElementById('chart-payment-doughnut')?.getContext('2d');
    if (ctxPay) {
      window._analyticsChartInstances.pay = new Chart(ctxPay, {
        type: 'pie',
        data: {
          labels: payLabels,
          datasets: [{
            data: payData,
            backgroundColor: payColors,
            borderWidth: 2,
            borderColor: isDarkMode ? '#1e293b' : '#ffffff'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { position: 'right', labels: { color: textColor, font: { size: 11 } } }
          }
        }
      });
    }

    // ── 4. Top 10 Selling Products (Horizontal Bar Chart) ──
    const itemRevMap = {};
    filtered.forEach(s => {
      (s.enriched_items || []).forEach(ci => {
        const name = isAR ? (ci.name_ar || ci.name_en) : (ci.name_en || ci.name_ar);
        if (!name) return;
        itemRevMap[name] = (itemRevMap[name] || 0) + (ci.item_revenue || 0);
      });
    });

    const sortedItems = Object.entries(itemRevMap).sort((a, b) => b[1] - a[1]).slice(0, 10);
    const topLabels   = sortedItems.map(x => x[0]);
    const topData     = sortedItems.map(x => Utils.round(x[1]));

    const ctxTop = document.getElementById('chart-top-products')?.getContext('2d');
    if (ctxTop) {
      window._analyticsChartInstances.top = new Chart(ctxTop, {
        type: 'bar',
        data: {
          labels: topLabels.length ? topLabels : [isAR ? 'لا بيانات' : 'No Data'],
          datasets: [{
            label: isAR ? 'المبيعات ($)' : 'Sales ($)',
            data: topData.length ? topData : [0],
            backgroundColor: '#a855f7',
            borderRadius: 6,
            maxBarThickness: 18
          }]
        },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false }
          },
          scales: {
            x: { grid: { color: gridColor }, ticks: { color: textColor } },
            y: { grid: { display: false }, ticks: { color: textColor, font: { size: 10.5 } } }
          }
        }
      });
    }

    // ── 5. Peak Rush Hours Traffic (Bar Chart) ──
    const hourMap = {};
    for (let h = 8; h <= 23; h++) hourMap[h] = 0;

    filtered.forEach(s => {
      if (s.created_at) {
        const d = new Date(s.created_at);
        const h = d.getHours();
        if (hourMap[h] !== undefined) hourMap[h]++;
      }
    });

    const hourLabels = Object.keys(hourMap).map(h => `${h}:00`);
    const hourData   = Object.values(hourMap);

    const ctxHour = document.getElementById('chart-hourly-traffic')?.getContext('2d');
    if (ctxHour) {
      window._analyticsChartInstances.hour = new Chart(ctxHour, {
        type: 'bar',
        data: {
          labels: hourLabels,
          datasets: [{
            label: isAR ? 'عدد الفواتير' : 'Invoices Count',
            data: hourData,
            backgroundColor: '#3b82f6',
            borderRadius: 6,
            maxBarThickness: 20
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false }
          },
          scales: {
            x: { grid: { display: false }, ticks: { color: textColor, font: { size: 9.5 } } },
            y: { grid: { color: gridColor }, ticks: { color: textColor, stepSize: 1 } }
          }
        }
      });
    }
  }

  function _arLabel(en) {
    const map = {
      'Daily Summary': 'ملخص يومي', 'By Item': 'حسب الصنف', 'By Customer': 'حسب العميل',
      'By Salesperson': 'حسب البائع', 'Top Products': 'أكثر مبيعاً', 'Return Report': 'المرتجعات',
      'Stock on Hand': 'المخزون الحالي', 'Stock Movement': 'حركة المخزون',
      'Low Stock': 'مخزون منخفض', 'Damaged Items': 'البضاعة التالفة', 'Stock Valuation': 'تقييم المخزون',
      'P&L Statement': 'الأرباح والخسائر', 'Trial Balance': 'ميزان المراجعة',
      'Balance Sheet': 'الميزانية العمومية', 'Cash Flow': 'التدفقات النقدية', 'VAT Report': 'تقرير الضريبة',
      'Statement': 'كشف الحساب', 'Aging Report': 'تقرير الاستحقاق',
      'Balance Summary': 'ملخص الأرصدة', 'Top Customers': 'أهم العملاء',
      'Payment History': 'سجل المدفوعات', 'AP Summary': 'ملخص الذمم الدائنة',
      'Attendance': 'الحضور والانصراف', 'Payroll Summary': 'ملخص الرواتب',
      'Leave Report': 'تقرير الإجازات', 'EOSG Report': 'مكافأة نهاية الخدمة',
      'Gift Report': 'تقرير الهدايا',
    };
    return map[en] || en;
  }

  // ── Helper ────────────────────────────────────────────────────
  function kpiCard(label, value, color, icon, isCurrency = true, suffix = '') {
    const display = (isCurrency && typeof value === 'number')
      ? Utils.formatMoney(value)
      : ((typeof value === 'number') ? `${(value || 0).toLocaleString()}${suffix}` : `${value || 0}${suffix}`);

    const colorMap = {
      primary: { border: 'var(--primary, #6366f1)', bg: 'rgba(99, 102, 241, 0.12)', text: 'var(--primary, #6366f1)' },
      success: { border: '#10b981', bg: 'rgba(16, 185, 129, 0.12)', text: '#10b981' },
      green:   { border: '#10b981', bg: 'rgba(16, 185, 129, 0.12)', text: '#10b981' },
      warning: { border: '#f59e0b', bg: 'rgba(245, 158, 11, 0.12)', text: '#f59e0b' },
      gold:    { border: '#f59e0b', bg: 'rgba(245, 158, 11, 0.12)', text: '#f59e0b' },
      danger:  { border: '#ef4444', bg: 'rgba(239, 68, 68, 0.12)', text: '#ef4444' },
      blue:    { border: '#3b82f6', bg: 'rgba(59, 130, 246, 0.12)', text: '#3b82f6' }
    };
    const c = colorMap[color] || colorMap.primary;

    return `
    <div class="stat-card ${color}" style="background:var(--surface-card);border:1px solid var(--border-color);border-bottom:3px solid ${c.border};border-radius:12px;padding:12px 14px;box-shadow:0 2px 8px rgba(0,0,0,0.03);display:flex;align-items:center;gap:10px;min-width:0;transition:transform 0.15s ease,box-shadow 0.15s ease">
      <div class="stat-icon" style="width:38px;height:38px;border-radius:10px;background:${c.bg};color:${c.text};display:flex;align-items:center;justify-content:center;font-size:19px;flex-shrink:0">${icon}</div>
      <div class="stat-info" style="min-width:0;flex:1;overflow:hidden">
        <div class="stat-label" style="font-size:0.75rem;font-weight:700;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${label}">${label}</div>
        <div class="stat-value" style="font-size:1.12rem;font-weight:800;color:var(--text-primary);letter-spacing:-0.02em;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${display}</div>
      </div>
    </div>`;
  }

  // ── 1-Click WhatsApp / Telegram Daily Closing Summary ─────────
  async function generateDailyDigestText() {
    const isAR = i18n.getLang() === 'ar';
    const companyName = await DB.getSetting('company_name', 'Red Shark POS');
    const enrichedSales = await _getEnrichedSales();
    const todayStr = new Date().toISOString().split('T')[0];
    const todaySales = enrichedSales.filter(s => (s.created_at || '').startsWith(todayStr));

    const totalRev = todaySales.reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);
    const totalDisc = todaySales.reduce((sum, s) => sum + (parseFloat(s.total_discount || s.discount_amount || s.discount || s.manual_discount || 0)), 0);
    const totalProfit = todaySales.reduce((sum, s) => sum + (parseFloat(s.net_profit) || 0), 0);
    const marginPct = totalRev > 0 ? ((totalProfit / totalRev) * 100).toFixed(1) : '0.0';
    let cashTotal = 0, cardTotal = 0, creditTotal = 0;
    todaySales.forEach(s => {
      const gTot = parseFloat(s.grand_total) || 0;
      if (s.payment_method === 'cash') {
        cashTotal += gTot;
      } else if (s.payment_method === 'card') {
        cardTotal += gTot;
      } else if (s.payment_method === 'credit') {
        const down = parseFloat(s.paid_amount !== undefined ? s.paid_amount : (s.tendered || 0));
        const cPaid = Math.min(gTot, Math.max(0, down));
        cashTotal += cPaid;
        creditTotal += parseFloat(s.credit_amount !== undefined ? s.credit_amount : Math.max(0, gTot - cPaid));
      } else {
        cashTotal += gTot;
      }
    });

    const forecast = window.AICopilot ? await AICopilot.computeInventoryForecast() : [];
    const criticalCount = forecast.filter(f => f.urgency === 'critical').length;

    let text = `📊 *${companyName.toUpperCase()} — DAILY CLOSING SUMMARY*\n`;
    text += `📅 Date: ${todayStr} | ⏰ Time: ${new Date().toLocaleTimeString()}\n\n`;
    text += `💰 *FINANCIAL PERFORMANCE*\n`;
    text += `• Total Revenue (Net): ${Utils.formatMoney(totalRev)}\n`;
    if (totalDisc > 0) text += `• Total Discounts: ${Utils.formatMoney(totalDisc)}\n`;
    text += `• Total Invoices: ${todaySales.length}\n`;
    text += `• Est. Gross Profit: ${Utils.formatMoney(totalProfit)} (${marginPct}% Margin)\n\n`;
    text += `💳 *PAYMENT BREAKDOWN*\n`;
    text += `• Cash: ${Utils.formatMoney(cashTotal)}\n`;
    text += `• Card: ${Utils.formatMoney(cardTotal)}\n`;
    if (creditTotal > 0) text += `• On Account: ${Utils.formatMoney(creditTotal)}\n`;
    text += `\n📦 *INVENTORY HEALTH*\n`;
    text += criticalCount > 0 ? `⚠️ ${criticalCount} items require immediate reorder.\n` : `✅ All inventory levels are healthy.\n`;
    text += `\n_Generated automatically by Red Shark POS AI_`;
    return text;
  }

  async function openDailyDigestModal() {
    const isAR = i18n.getLang() === 'ar';
    const digestText = await generateDailyDigestText();
    const encoded = encodeURIComponent(digestText);
    
    const ownerPhone = await DB.getSetting('owner_whatsapp_phone', '');
    const cleanPhone = ownerPhone.replace(/[^0-9]/g, '');
    const waUrl = cleanPhone 
      ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encoded}` 
      : `https://api.whatsapp.com/send?text=${encoded}`;

    const botToken = await DB.getSetting('telegram_bot_token', '');
    const chatId = await DB.getSetting('telegram_chat_id', '');

    document.getElementById('digest-modal')?.remove();

    const html = `
    <div class="modal-overlay open" id="digest-modal">
      <div class="modal" style="max-width:520px;border-radius:16px">
        <div class="modal-header">
          <div class="modal-title">📱 ${isAR ? 'الملخص اليومي للإغلاق (واتساب / تليجرام)' : 'Daily Closing Digest (WhatsApp / Telegram)'}</div>
          <button class="modal-close" onclick="document.getElementById('digest-modal').remove()">✕</button>
        </div>
        <div class="modal-body">
          <textarea id="digest-textarea" class="form-control" style="font-family:monospace;font-size:0.8rem;height:240px;margin-bottom:14px;background:var(--surface-2)" readonly>${digestText}</textarea>
          
          <div style="display:flex;flex-direction:column;gap:10px">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <a href="${waUrl}" target="_blank" class="btn btn-success" style="display:flex;align-items:center;justify-content:center;gap:6px;font-weight:700">
                <span>💬</span> ${isAR ? 'إرسال عبر واتساب' : 'Send via WhatsApp'}
              </a>
              <button class="btn btn-primary" onclick="navigator.clipboard.writeText(document.getElementById('digest-textarea').value); Utils.toast('${isAR?'تم نسخ الملخص إلى الحافظة':'Copied to clipboard!'}', 'success')">
                📋 ${isAR ? 'نسخ النص' : 'Copy Text'}
              </button>
            </div>

            ${(botToken && chatId) ? `
            <button class="btn btn-secondary" onclick="Reports.sendDigestToTelegram()" style="display:flex;align-items:center;justify-content:center;gap:6px;font-weight:700;background:rgba(59,130,246,0.15);border:1px solid rgba(59,130,246,0.35);color:#3b82f6">
              <span>🤖</span> ${isAR ? 'إرسال فوري إلى بوت تيليجرام' : 'Send via Telegram Bot'}
            </button>` : ''}
          </div>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  async function sendDigestToTelegram() {
    const isAR = i18n.getLang() === 'ar';
    const token = await DB.getSetting('telegram_bot_token', '');
    const chatId = await DB.getSetting('telegram_chat_id', '');
    if (!token || !chatId) {
      return Utils.toast(isAR ? 'يرجى ضبط توكن وتيليجرام في الإعدادات أولاً' : 'Please configure Telegram Bot Token in Settings first', 'warning');
    }
    const digestText = await generateDailyDigestText();
    try {
      Utils.toast(isAR ? 'جاري الإرسال إلى تيليجرام...' : 'Sending to Telegram...', 'info');
      const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: digestText, parse_mode: 'Markdown' })
      });
      const data = await res.json();
      if (data.ok) {
        Utils.toast(isAR ? '✅ تم إرسال التقرير اليومي بنجاح إلى تيليجرام!' : '✅ Daily closing report sent to Telegram!', 'success');
        document.getElementById('digest-modal')?.remove();
      } else {
        Utils.toast('Telegram error: ' + (data.description || 'Failed'), 'error');
      }
    } catch(e) {
      Utils.toast('Network error: ' + e.message, 'error');
    }
  }

  // ── Restaurant & Dining Analytics Report Implementation ───────
  async function renderRestaurantReport(container, defaultTab = 'overview') {
    if (!container) container = document.getElementById('page-content');
    const isAR = i18n.getLang() === 'ar';

    const today = Utils.today();
    const thisMonth = today.slice(0, 7);

    window._restRepActiveTab = defaultTab;

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left" style="display:flex;align-items:center;gap:12px">
          <button class="btn btn-ghost btn-sm" onclick="Reports.render(document.getElementById('page-content'))" style="font-weight:700">← ${isAR ? 'مركز التقارير' : 'Reports Hub'}</button>
          <div>
            <h1>🍽️ ${isAR ? 'تقارير وتحليلات المطاعم والصالة' : 'Restaurant & Dining Floor Analytics'}</h1>
            <p>${isAR ? 'مبيعات الصالة، الطلبات الخارجية، أداء الطاولات، مبيعات الويترية، وتوزيع أقسام المطبخ' : 'Dine-in vs takeaway, table turnover, server sales & kitchen station analytics'}</p>
          </div>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" onclick="Reports.printRestaurantReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة' : 'Print'}
          </button>
          <button class="btn btn-primary" onclick="Reports.exportRestaurantReport()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            ${isAR ? 'تصدير' : 'Export'}
          </button>
        </div>
      </div>

      <!-- Filters & Date Range -->
      <div class="card mb-4">
        <div class="card-header"><div class="card-title">${isAR ? 'تصفية التقرير بالفترة الزمنية' : 'Filter by Date Range'}</div></div>
        <div class="modal-body">
          <div class="grid grid-4" style="gap:12px">
            <div class="form-group">
              <label class="form-label">${isAR ? 'من تاريخ' : 'From Date'}</label>
              <input type="date" class="form-control" id="rest-rep-from" value="${thisMonth}-01">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'إلى تاريخ' : 'To Date'}</label>
              <input type="date" class="form-control" id="rest-rep-to" value="${today}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'نوع الطلب' : 'Order Channel'}</label>
              <select class="form-control" id="rest-rep-channel" onchange="Reports.loadRestaurantData()">
                <option value="all">${isAR ? 'جميع القنوات (All Channels)' : 'All Channels'}</option>
                <option value="dine_in">🍽️ ${isAR ? 'صالة داخلية (Dine-In)' : 'Dine-In Tables'}</option>
                <option value="takeaway">🛍️ ${isAR ? 'طلبات خارجية (Takeaway)' : 'Takeaway / Pickup'}</option>
                <option value="delivery">🚚 ${isAR ? 'خدمة التوصيل (Delivery)' : 'Delivery'}</option>
              </select>
            </div>
            <div class="form-group" style="display:flex;align-items:flex-end">
              <button class="btn btn-primary" onclick="Reports.loadRestaurantData()" style="width:100%">${isAR ? 'عرض التحليلات' : 'Run Report'}</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Sub Navigation Tabs -->
      <div class="tabs mb-4">
        <button class="tab-btn ${defaultTab==='overview'?'active':''}" onclick="Reports.switchRestSubTab('overview', this)">📊 ${isAR ? 'نظرة عامة والقنوات' : 'Overview & Channels'}</button>
        <button class="tab-btn ${defaultTab==='delivery'?'active':''}" onclick="Reports.switchRestSubTab('delivery', this)">🛵 ${isAR ? 'طلبات وسائقي الدليفري' : 'Delivery & Drivers'}</button>
        <button class="tab-btn ${defaultTab==='takeaway'?'active':''}" onclick="Reports.switchRestSubTab('takeaway', this)">🛍️ ${isAR ? 'الطلبات الخارجية (السفري)' : 'Takeaway & Pickup'}</button>
        <button class="tab-btn ${defaultTab==='tables'?'active':''}" onclick="Reports.switchRestSubTab('tables', this)">🪑 ${isAR ? 'الصالات والطاولات' : 'Zones & Tables'}</button>
        <button class="tab-btn ${defaultTab==='waiters'?'active':''}" onclick="Reports.switchRestSubTab('waiters', this)">👥 ${isAR ? 'أداء الويترية والخدمة' : 'Waiters & Staff'}</button>
        <button class="tab-btn ${defaultTab==='categories'?'active':''}" onclick="Reports.switchRestSubTab('categories', this)">🍳 ${isAR ? 'أقسام المطبخ والبار' : 'Kitchen vs Bar'}</button>
        <button class="tab-btn ${defaultTab==='peakhours'?'active':''}" onclick="Reports.switchRestSubTab('peakhours', this)">⏰ ${isAR ? 'ساعات الذروة والوجبات' : 'Peak Hours'}</button>
      </div>

      <div id="rest-report-content"></div>
    </div>`;

    await loadRestaurantData();
  }

  function switchRestSubTab(tab, btn) {
    window._restRepActiveTab = tab;
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    loadRestaurantData();
  }

  async function loadRestaurantData() {
    const from = document.getElementById('rest-rep-from')?.value || '';
    const to = document.getElementById('rest-rep-to')?.value || '';
    const channel = document.getElementById('rest-rep-channel')?.value || 'all';
    const isAR = i18n.getLang() === 'ar';
    const tab = window._restRepActiveTab || 'overview';
    const container = document.getElementById('rest-report-content');
    if (!container) return;

    let allSales = await DB.getAll('sales') || [];
    let allDeliveries = await DB.getAll('restaurant_delivery_orders') || [];
    const tables = await DB.getAll('restaurant_tables') || [];
    const zones = await DB.getAll('restaurant_zones') || [];

    // Filter by date
    if (from) {
      allSales = allSales.filter(s => (s.created_at || '').slice(0,10) >= from);
      allDeliveries = allDeliveries.filter(d => (d.created_at || '').slice(0,10) >= from);
    }
    if (to) {
      allSales = allSales.filter(s => (s.created_at || '').slice(0,10) <= to);
      allDeliveries = allDeliveries.filter(d => (d.created_at || '').slice(0,10) <= to);
    }

    // Filter by channel
    if (channel !== 'all') {
      allSales = allSales.filter(s => (s.order_type || 'dine_in') === channel);
    }

    // Calculations
    const dineInSales = allSales.filter(s => !s.order_type || s.order_type === 'dine_in');
    const takeawaySales = allSales.filter(s => s.order_type === 'takeaway');
    const deliverySales = allSales.filter(s => s.order_type === 'delivery');

    const totalRev = allSales.reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);
    const dineInRev = dineInSales.reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);
    const takeawayRev = takeawaySales.reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);
    const deliveryRev = deliverySales.reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);

    const totalGuests = dineInSales.reduce((sum, s) => sum + (parseInt(s.guest_count) || 2), 0);
    const avgSpendPerGuest = totalGuests > 0 ? (dineInRev / totalGuests) : 0;
    const avgOrderValue = allSales.length > 0 ? (totalRev / allSales.length) : 0;

    let html = '';

    if (tab === 'overview') {
      html = `
      <!-- KPI Summary Cards -->
      <div class="grid grid-4 mb-4" style="gap:14px">
        <div class="card" style="border-top:3px solid #3b82f6;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🍽️ ${isAR ? 'مبيعات الصالة (Dine-In)' : 'Dine-In Revenue'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:var(--primary);margin-top:4px">${Utils.formatMoney(dineInRev)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${dineInSales.length} ${isAR ? 'طلب صالة' : 'Orders'} (${totalRev > 0 ? ((dineInRev/totalRev)*100).toFixed(1) : 0}%)</div>
        </div>

        <div class="card" style="border-top:3px solid #10b981;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🛍️ ${isAR ? 'مبيعات السفري (Takeaway)' : 'Takeaway Revenue'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:var(--success);margin-top:4px">${Utils.formatMoney(takeawayRev)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${takeawaySales.length} ${isAR ? 'طلب خارجي' : 'Orders'} (${totalRev > 0 ? ((takeawayRev/totalRev)*100).toFixed(1) : 0}%)</div>
        </div>

        <div class="card" style="border-top:3px solid #f59e0b;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🚚 ${isAR ? 'مبيعات التوصيل (Delivery)' : 'Delivery Revenue'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:var(--warning);margin-top:4px">${Utils.formatMoney(deliveryRev)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${deliverySales.length} ${isAR ? 'طلب توصيل' : 'Orders'}</div>
        </div>

        <div class="card" style="border-top:3px solid #8b5cf6;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">👥 ${isAR ? 'متوسط إنفاق الزبون (Cover Spend)' : 'Avg Spend / Guest'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:#8b5cf6;margin-top:4px">${Utils.formatMoney(avgSpendPerGuest)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${totalGuests} ${isAR ? 'ضيف وضيفة تم خدمتهم' : 'Total Guests'}</div>
        </div>
      </div>

      <!-- Channel Breakdown Table -->
      <div class="card">
        <div class="card-header"><div class="card-title">${isAR ? 'تفاصيل المبيعات حسب قنوات الخدمة' : 'Sales Breakdown by Dining Channel'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'القناة' : 'Channel'}</th>
                <th>${isAR ? 'عدد الطلبات' : 'Orders'}</th>
                <th>${isAR ? 'عدد الضيوف' : 'Guests'}</th>
                <th>${isAR ? 'متوسط الفاتورة' : 'Avg Check'}</th>
                <th>${isAR ? 'الإجمالي' : 'Total Revenue'}</th>
                <th>${isAR ? 'النسبة' : 'Share'}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="font-weight:700">🍽️ ${isAR ? 'الصالة وتناول الطعام بالداخل' : 'Dine-In Floor'}</td>
                <td>${dineInSales.length}</td>
                <td>${totalGuests}</td>
                <td>${dineInSales.length > 0 ? Utils.formatMoney(dineInRev / dineInSales.length) : '$0.00'}</td>
                <td style="font-weight:700;color:var(--primary)">${Utils.formatMoney(dineInRev)}</td>
                <td><span class="badge badge-primary">${totalRev > 0 ? ((dineInRev/totalRev)*100).toFixed(1) : 0}%</span></td>
              </tr>
              <tr>
                <td style="font-weight:700">🛍️ ${isAR ? 'الطلبات الخارجية والاستلام (Takeaway)' : 'Takeaway / Pickup'}</td>
                <td>${takeawaySales.length}</td>
                <td>-</td>
                <td>${takeawaySales.length > 0 ? Utils.formatMoney(takeawayRev / takeawaySales.length) : '$0.00'}</td>
                <td style="font-weight:700;color:var(--success)">${Utils.formatMoney(takeawayRev)}</td>
                <td><span class="badge badge-success">${totalRev > 0 ? ((takeawayRev/totalRev)*100).toFixed(1) : 0}%</span></td>
              </tr>
              <tr>
                <td style="font-weight:700">🚚 ${isAR ? 'التوصيل المنزلي (Home Delivery)' : 'Home Delivery'}</td>
                <td>${deliverySales.length}</td>
                <td>-</td>
                <td>${deliverySales.length > 0 ? Utils.formatMoney(deliveryRev / deliverySales.length) : '$0.00'}</td>
                <td style="font-weight:700;color:var(--warning)">${Utils.formatMoney(deliveryRev)}</td>
                <td><span class="badge badge-warning">${totalRev > 0 ? ((deliveryRev/totalRev)*100).toFixed(1) : 0}%</span></td>
              </tr>
            </tbody>
            <tfoot>
              <tr style="font-weight:900;background:var(--surface-2)">
                <td>${isAR ? 'المجموع الكلي' : 'Total'}</td>
                <td>${allSales.length}</td>
                <td>${totalGuests}</td>
                <td>${Utils.formatMoney(avgOrderValue)}</td>
                <td style="color:var(--primary)">${Utils.formatMoney(totalRev)}</td>
                <td>100%</td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>`;
    } else if (tab === 'delivery') {
      // DEDICATED DELIVERY DISPATCH & DRIVERS REPORT
      const validDel = allDeliveries.filter(d => (!d.order_type || d.order_type === 'delivery'));
      const delCount = validDel.length;
      const deliveredCount = validDel.filter(d => d.status === 'delivered').length;
      const cancelledCount = validDel.filter(d => d.status === 'cancelled').length;
      const activeDelCount = validDel.filter(d => d.status !== 'delivered' && d.status !== 'cancelled').length;

      const delItemsRev = validDel.reduce((sum, d) => sum + (parseFloat(d.total || d.total_amount) || 0), 0);
      const delFeesRev = validDel.reduce((sum, d) => sum + (parseFloat(d.delivery_fee) || 0), 0);
      const delTotalRev = delItemsRev + delFeesRev;

      const codOrders = validDel.filter(d => (!d.is_paid && d.payment_status !== 'paid') || d.payment_method === 'Cash' || d.payment_method === 'COD');
      const prepaidOrders = validDel.filter(d => (d.is_paid || d.payment_status === 'paid') && d.payment_method !== 'Cash' && d.payment_method !== 'COD');
      
      const codTotal = validDel.filter(d => (!d.is_paid && d.payment_status !== 'paid') && d.status !== 'cancelled')
                               .reduce((sum, d) => sum + (parseFloat(d.total || d.total_amount) || 0) + (parseFloat(d.delivery_fee) || 0), 0);
      const paidTotal = validDel.filter(d => (d.is_paid || d.payment_status === 'paid') && d.status !== 'cancelled')
                                .reduce((sum, d) => sum + (parseFloat(d.total || d.total_amount) || 0) + (parseFloat(d.delivery_fee) || 0), 0);

      // Driver Stats
      const driverMap = {};
      validDel.forEach(d => {
        const dname = (d.driver || '').trim() || (isAR ? 'غير محدد' : 'Unassigned');
        if (!driverMap[dname]) {
          driverMap[dname] = { name: dname, totalTrips: 0, delivered: 0, cancelled: 0, orderVolume: 0, fees: 0, collectedCash: 0, pendingCash: 0 };
        }
        const orderVal = (parseFloat(d.total || d.total_amount) || 0) + (parseFloat(d.delivery_fee) || 0);
        const feeVal = parseFloat(d.delivery_fee) || 0;

        driverMap[dname].totalTrips++;
        driverMap[dname].orderVolume += orderVal;
        driverMap[dname].fees += feeVal;

        if (d.status === 'delivered') driverMap[dname].delivered++;
        if (d.status === 'cancelled') driverMap[dname].cancelled++;

        if (d.is_paid || d.payment_status === 'paid') {
          driverMap[dname].collectedCash += orderVal;
        } else if (d.status !== 'cancelled') {
          driverMap[dname].pendingCash += orderVal;
        }
      });

      const driverRows = Object.values(driverMap).sort((a, b) => b.delivered - a.delivered);

      html = `
      <!-- Delivery KPI Summary -->
      <div class="grid grid-4 mb-4" style="gap:14px">
        <div class="card" style="border-top:3px solid #06b6d4;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🛵 ${isAR ? 'إجمالي طلبات التوصيل' : 'Total Deliveries'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:#06b6d4;margin-top:4px">${delCount}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">
            <span style="color:var(--success)">${deliveredCount} ${isAR ? 'تم تسليمها' : 'Delivered'}</span> • 
            <span style="color:var(--warning)">${activeDelCount} ${isAR ? 'نشطة' : 'Active'}</span>
          </div>
        </div>

        <div class="card" style="border-top:3px solid #10b981;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">💰 ${isAR ? 'إجمالي حجم مبيعات التوصيل' : 'Delivery Gross Revenue'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:var(--success);margin-top:4px">${Utils.formatMoney(delTotalRev)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">+$${delFeesRev.toFixed(2)} ${isAR ? 'رسوم توصيل مجمعة' : 'Delivery Fees'}</div>
        </div>

        <div class="card" style="border-top:3px solid #ef4444;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🔴 ${isAR ? 'مبالغ COD قيد التحصيل' : 'Unpaid COD Balance'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:var(--danger);margin-top:4px">${Utils.formatMoney(codTotal)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${validDel.filter(d => !d.is_paid && d.status !== 'cancelled').length} ${isAR ? 'طلبات غير مسددة' : 'Unpaid Orders'}</div>
        </div>

        <div class="card" style="border-top:3px solid #8b5cf6;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">💵 ${isAR ? 'مبالغ التوصيل المحصلة' : 'Settled & Paid Revenue'}</div>
          <div style="font-size:1.4rem;font-weight:900;color:#8b5cf6;margin-top:4px">${Utils.formatMoney(paidTotal)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${delCount > 0 ? Utils.formatMoney(delTotalRev / delCount) : '$0.00'} ${isAR ? 'متوسط الفاتورة' : 'Avg Order'}</div>
        </div>
      </div>

      <!-- Driver Performance & Settlement Table -->
      <div class="card mb-4">
        <div class="card-header"><div class="card-title">🛵 ${isAR ? 'أداء سائقي التوصيل وتحصيل المبالغ النقدية (Driver Shift Settlement)' : 'Delivery Driver Performance & Cash Settlement'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'السائق / المندوب' : 'Driver Name'}</th>
                <th>${isAR ? 'إجمالي الطلبات' : 'Assigned Trips'}</th>
                <th>${isAR ? 'تم التسليم بنجاح' : 'Delivered'}</th>
                <th>${isAR ? 'حجم المبيعات' : 'Order Volume'}</th>
                <th>${isAR ? 'رسوم التوصيل' : 'Delivery Fees'}</th>
                <th>${isAR ? 'المسدد نقداً' : 'Cash Collected'}</th>
                <th>${isAR ? 'المتبقي للتحصيل' : 'Pending COD'}</th>
              </tr>
            </thead>
            <tbody>
              ${driverRows.map(dr => `
              <tr>
                <td style="font-weight:800;color:var(--text-primary)">👤 ${Utils.sanitize(dr.name)}</td>
                <td>${dr.totalTrips}</td>
                <td><span class="badge badge-success">${dr.delivered} (${dr.totalTrips > 0 ? ((dr.delivered/dr.totalTrips)*100).toFixed(0) : 0}%)</span></td>
                <td style="font-weight:700">${Utils.formatMoney(dr.orderVolume)}</td>
                <td style="color:var(--brand-cyan);font-weight:700">${Utils.formatMoney(dr.fees)}</td>
                <td style="color:var(--success);font-weight:800">${Utils.formatMoney(dr.collectedCash)}</td>
                <td style="color:${dr.pendingCash > 0 ? 'var(--danger)' : 'var(--text-muted)'};font-weight:800">${Utils.formatMoney(dr.pendingCash)}</td>
              </tr>`).join('')}
              ${!driverRows.length ? `<tr><td colspan="7" style="text-align:center;padding:20px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات توصيل' : 'No driver records found'}</td></tr>` : ''}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Itemized Delivery Orders Log -->
      <div class="card">
        <div class="card-header"><div class="card-title">📋 ${isAR ? 'سجل طلبات التوصيل التفصيلي' : 'Itemized Delivery Orders Log'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'رقم الطلب' : 'Order #'}</th>
                <th>${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
                <th>${isAR ? 'الزبون والهاتف' : 'Customer & Phone'}</th>
                <th>${isAR ? 'العنوان' : 'Address'}</th>
                <th>${isAR ? 'السائق' : 'Driver'}</th>
                <th>${isAR ? 'الحالة' : 'Status'}</th>
                <th>${isAR ? 'الدفع' : 'Payment'}</th>
                <th>${isAR ? 'الإجمالي' : 'Total'}</th>
              </tr>
            </thead>
            <tbody>
              ${validDel.map(d => {
                const totalVal = (parseFloat(d.total || d.total_amount) || 0) + (parseFloat(d.delivery_fee) || 0);
                const isPaid = d.is_paid || d.payment_status === 'paid';
                return `
                <tr>
                  <td style="font-weight:800;color:var(--primary)">#DEL-${d.id}</td>
                  <td style="font-size:0.75rem">${Utils.formatDateTime(d.created_at)}</td>
                  <td>
                    <div style="font-weight:700">${Utils.sanitize(d.customer_name || 'Customer')}</div>
                    <div style="font-size:0.72rem;color:var(--text-muted)">${Utils.sanitize(d.phone || '-')}</div>
                  </td>
                  <td style="font-size:0.75rem;max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${Utils.sanitize(d.address || '')}">
                    ${Utils.sanitize(d.address || '-')}
                  </td>
                  <td>${Utils.sanitize(d.driver || (isAR ? 'غير معين' : 'Unassigned'))}</td>
                  <td>
                    <span class="badge ${d.status === 'delivered' ? 'badge-success' : (d.status === 'cooking' ? 'badge-warning' : 'badge-primary')}">
                      ${d.status || 'cooking'}
                    </span>
                  </td>
                  <td>
                    <span class="badge ${isPaid ? 'badge-success' : 'badge-danger'}">
                      ${isPaid ? (isAR ? 'مدفوع' : 'PAID') : (isAR ? 'غير مدفوع (COD)' : 'COD')}
                    </span>
                  </td>
                  <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(totalVal)}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
    } else if (tab === 'takeaway') {
      // DEDICATED TAKEAWAY & PICKUP REPORT
      const tkSales = allSales.filter(s => s.order_type === 'takeaway');
      const tkDeliveries = allDeliveries.filter(d => d.order_type === 'takeaway');
      
      const tkCount = Math.max(tkSales.length, tkDeliveries.length);
      const tkRev = tkSales.length ? takeawayRev : tkDeliveries.reduce((sum, d) => sum + (parseFloat(d.total || d.total_amount) || 0), 0);
      const avgTkCheck = tkCount > 0 ? (tkRev / tkCount) : 0;

      // Top Takeaway Items Breakdown
      const itemCounter = {};
      const sourceList = tkSales.length ? tkSales : tkDeliveries;
      sourceList.forEach(s => {
        let items = [];
        try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e){}
        items.forEach(it => {
          const iname = it.name || it.name_en || it.name_ar || 'Item';
          if (!itemCounter[iname]) itemCounter[iname] = { name: iname, qty: 0, rev: 0 };
          const q = parseFloat(it.qty || it.quantity) || 1;
          const p = parseFloat(it.price) || 0;
          itemCounter[iname].qty += q;
          itemCounter[iname].rev += (q * p);
        });
      });

      const topItems = Object.values(itemCounter).sort((a, b) => b.qty - a.qty);

      html = `
      <!-- Takeaway KPI Summary -->
      <div class="grid grid-3 mb-4" style="gap:14px">
        <div class="card" style="border-top:3px solid #10b981;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🛍️ ${isAR ? 'إجمالي طلبات السفري (Takeaway)' : 'Total Takeaway Orders'}</div>
          <div style="font-size:1.5rem;font-weight:900;color:var(--success);margin-top:4px">${tkCount}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${totalRev > 0 ? ((tkRev/totalRev)*100).toFixed(1) : 0}% ${isAR ? 'من إجمالي المبيعات' : 'of total restaurant sales'}</div>
        </div>

        <div class="card" style="border-top:3px solid #3b82f6;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">💰 ${isAR ? 'إجمالي إيرادات السفري' : 'Takeaway Revenue'}</div>
          <div style="font-size:1.5rem;font-weight:900;color:var(--primary);margin-top:4px">${Utils.formatMoney(tkRev)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR ? 'مبيعات الكاونتر والاستلام السريع' : 'Counter & pickup sales volume'}</div>
        </div>

        <div class="card" style="border-top:3px solid #f59e0b;padding:16px">
          <div style="font-size:0.75rem;color:var(--text-muted)">🧾 ${isAR ? 'متوسط فاتورة السفري' : 'Average Takeaway Check'}</div>
          <div style="font-size:1.5rem;font-weight:900;color:var(--warning);margin-top:4px">${Utils.formatMoney(avgTkCheck)}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:4px">${isAR ? 'معدل الإنفاق لكل طلب سفري' : 'Spend per takeaway customer'}</div>
        </div>
      </div>

      <!-- Top Selling Takeaway Food Items -->
      <div class="card mb-4">
        <div class="card-header"><div class="card-title">🏆 ${isAR ? 'الأصناف والأطباق الأكثر طلباً في السفري' : 'Top Selling Takeaway Menu Items'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الصنف / الوجبة' : 'Item Name'}</th>
                <th>${isAR ? 'الكمية المباعة سفري' : 'Quantity Sold'}</th>
                <th>${isAR ? 'إجمالي المبيعات' : 'Revenue'}</th>
                <th>${isAR ? 'نسبة المساهمة' : 'Share'}</th>
              </tr>
            </thead>
            <tbody>
              ${topItems.slice(0, 15).map(it => `
              <tr>
                <td style="font-weight:800;color:var(--text-primary)">🍽️ ${Utils.sanitize(it.name)}</td>
                <td style="font-weight:700">${it.qty}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(it.rev)}</td>
                <td><span class="badge badge-success">${tkRev > 0 ? ((it.rev/tkRev)*100).toFixed(1) : 0}%</span></td>
              </tr>`).join('')}
              ${!topItems.length ? `<tr><td colspan="4" style="text-align:center;padding:20px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات للأصناف' : 'No takeaway items sold in this period'}</td></tr>` : ''}
            </tbody>
          </table>
        </div>
      </div>`;
    } else if (tab === 'tables') {
      // Group by table
      const tableStats = {};
      tables.forEach(t => {
        tableStats[t.id] = { name: t.name || t.table_number, zone_id: t.zone_id, orders: 0, revenue: 0, guests: 0 };
      });

      dineInSales.forEach(s => {
        const tid = s.table_id || 1;
        if (!tableStats[tid]) {
          tableStats[tid] = { name: `Table ${tid}`, zone_id: 1, orders: 0, revenue: 0, guests: 0 };
        }
        tableStats[tid].orders += 1;
        tableStats[tid].revenue += (parseFloat(s.grand_total) || 0);
        tableStats[tid].guests += (parseInt(s.guest_count) || 2);
      });

      const zoneNameMap = {};
      zones.forEach(z => zoneNameMap[z.id] = isAR ? (z.name_ar || z.name) : z.name);

      const tableRows = Object.values(tableStats).sort((a,b) => b.revenue - a.revenue);

      html = `
      <div class="card">
        <div class="card-header"><div class="card-title">${isAR ? 'أداء الطاولات ومعدل دوران الصالة' : 'Table Turnover & Revenue Performance'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الطاولة' : 'Table'}</th>
                <th>${isAR ? 'المنطقة / الصالة' : 'Zone'}</th>
                <th>${isAR ? 'عدد الطلبات المنجزة' : 'Orders Served'}</th>
                <th>${isAR ? 'إجمالي الرواد' : 'Total Guests'}</th>
                <th>${isAR ? 'متوسط الفاتورة' : 'Average Check'}</th>
                <th>${isAR ? 'إجمالي الإيرادات' : 'Total Revenue'}</th>
              </tr>
            </thead>
            <tbody>
              ${tableRows.map(tr => `
              <tr>
                <td style="font-weight:800;color:var(--primary)">🪑 ${Utils.sanitize(tr.name)}</td>
                <td>${zoneNameMap[tr.zone_id] || (isAR ? 'الصالة الرئيسية' : 'Main Hall')}</td>
                <td>${tr.orders}</td>
                <td>${tr.guests}</td>
                <td>${tr.orders > 0 ? Utils.formatMoney(tr.revenue / tr.orders) : '$0.00'}</td>
                <td style="font-weight:800">${Utils.formatMoney(tr.revenue)}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
    } else if (tab === 'waiters') {
      const waiterStats = {};
      allSales.forEach(s => {
        const wname = s.waiter_name || s.salesperson_name || s.cashier_name || (isAR ? 'طاقم الخدمة' : 'Floor Staff');
        if (!waiterStats[wname]) waiterStats[wname] = { name: wname, orders: 0, revenue: 0, guests: 0 };
        waiterStats[wname].orders += 1;
        waiterStats[wname].revenue += (parseFloat(s.grand_total) || 0);
        waiterStats[wname].guests += (parseInt(s.guest_count) || 2);
      });

      const waiterRows = Object.values(waiterStats).sort((a,b) => b.revenue - a.revenue);

      html = `
      <div class="card">
        <div class="card-header"><div class="card-title">${isAR ? 'تقرير مبيعات وأداء الويترية وطاقم الصالة' : 'Waiter & Service Staff Performance'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الويتر / الموظف' : 'Server / Waiter'}</th>
                <th>${isAR ? 'عدد الطاولات المخدومة' : 'Orders Served'}</th>
                <th>${isAR ? 'عدد الضيوف' : 'Guests Served'}</th>
                <th>${isAR ? 'متوسط الفاتورة' : 'Average Check'}</th>
                <th>${isAR ? 'إجمالي المبيعات' : 'Total Sales'}</th>
              </tr>
            </thead>
            <tbody>
              ${waiterRows.map(w => `
              <tr>
                <td style="font-weight:800">👤 ${Utils.sanitize(w.name)}</td>
                <td>${w.orders}</td>
                <td>${w.guests}</td>
                <td>${w.orders > 0 ? Utils.formatMoney(w.revenue / w.orders) : '$0.00'}</td>
                <td style="font-weight:800;color:var(--success)">${Utils.formatMoney(w.revenue)}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
    } else if (tab === 'categories') {
      const catStats = {
        food: { name: isAR ? '🍳 المأكولات والمطبخ' : 'Food & Kitchen', revenue: 0, count: 0 },
        drinks: { name: isAR ? '🍹 المشروبات والبار' : 'Beverages & Bar', revenue: 0, count: 0 },
        desserts: { name: isAR ? '🍰 الحلويات والمخبوزات' : 'Desserts & Pastries', revenue: 0, count: 0 },
        shisha: { name: isAR ? '💨 الشيشة' : 'Shisha', revenue: 0, count: 0 },
        other: { name: isAR ? 'أخرى' : 'Other', revenue: 0, count: 0 }
      };

      allSales.forEach(s => {
        let items = [];
        try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e){}
        items.forEach(it => {
          const cat = (it.category_name || '').toLowerCase();
          const rev = (parseFloat(it.price) || 0) * (parseFloat(it.qty) || 1);
          if (cat.includes('drink') || cat.includes('beverage') || cat.includes('مشروب') || cat.includes('عصير') || cat.includes('قهوة') || cat.includes('بار')) {
            catStats.drinks.revenue += rev;
            catStats.drinks.count += (parseFloat(it.qty) || 1);
          } else if (cat.includes('dessert') || cat.includes('sweet') || cat.includes('حلو') || cat.includes('كيك')) {
            catStats.desserts.revenue += rev;
            catStats.desserts.count += (parseFloat(it.qty) || 1);
          } else if (cat.includes('shisha') || cat.includes('شيشة') || cat.includes('نرجيلة')) {
            catStats.shisha.revenue += rev;
            catStats.shisha.count += (parseFloat(it.qty) || 1);
          } else {
            catStats.food.revenue += rev;
            catStats.food.count += (parseFloat(it.qty) || 1);
          }
        });
      });

      html = `
      <div class="card">
        <div class="card-header"><div class="card-title">${isAR ? 'توزيع المبيعات حسب أقسام الطعام والمشروبات (KOT Breakdown)' : 'Kitchen vs Bar Category Revenue Share'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'القسم' : 'Station'}</th>
                <th>${isAR ? 'الكمية المباعة' : 'Quantity Sold'}</th>
                <th>${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</th>
              </tr>
            </thead>
            <tbody>
              ${Object.values(catStats).map(c => `
              <tr>
                <td style="font-weight:700">${c.name}</td>
                <td>${c.count}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(c.revenue)}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
    } else if (tab === 'peakhours') {
      const mealBuckets = {
        breakfast: { name: isAR ? '🥐 الفطور الصباحي (07:00 - 11:59)' : 'Breakfast (07:00 - 11:59)', orders: 0, revenue: 0 },
        lunch:     { name: isAR ? '🍔 الغداء (12:00 - 16:59)' : 'Lunch (12:00 - 16:59)', orders: 0, revenue: 0 },
        dinner:    { name: isAR ? '🥩 العشاء (17:00 - 22:59)' : 'Dinner (17:00 - 22:59)', orders: 0, revenue: 0 },
        late:      { name: isAR ? '🌙 السهرات والساعات المتأخرة (23:00 - 06:59)' : 'Late Night (23:00 - 06:59)', orders: 0, revenue: 0 }
      };

      allSales.forEach(s => {
        const d = new Date(s.created_at || Date.now());
        const hour = d.getHours();
        const rev = parseFloat(s.grand_total) || 0;
        if (hour >= 7 && hour < 12) { mealBuckets.breakfast.orders++; mealBuckets.breakfast.revenue += rev; }
        else if (hour >= 12 && hour < 17) { mealBuckets.lunch.orders++; mealBuckets.lunch.revenue += rev; }
        else if (hour >= 17 && hour < 23) { mealBuckets.dinner.orders++; mealBuckets.dinner.revenue += rev; }
        else { mealBuckets.late.orders++; mealBuckets.late.revenue += rev; }
      });

      html = `
      <div class="card">
        <div class="card-header"><div class="card-title">${isAR ? 'تحليل فترات الوجبات وساعات الذروة' : 'Meal Periods & Peak Rush Hours'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>${isAR ? 'الفترة' : 'Meal Period'}</th>
                <th>${isAR ? 'عدد الطلبات' : 'Orders'}</th>
                <th>${isAR ? 'إجمالي المبيعات' : 'Revenue'}</th>
                <th>${isAR ? 'النسبة' : 'Share'}</th>
              </tr>
            </thead>
            <tbody>
              ${Object.values(mealBuckets).map(m => `
              <tr>
                <td style="font-weight:800">${m.name}</td>
                <td>${m.orders}</td>
                <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(m.revenue)}</td>
                <td><span class="badge badge-primary">${totalRev > 0 ? ((m.revenue/totalRev)*100).toFixed(1) : 0}%</span></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>`;
    }

    container.innerHTML = html;
  }

  function printRestaurantReport() {
    window.print();
  }

  function exportRestaurantReport() {
    Utils.toast(i18n.getLang() === 'ar' ? 'جاري تصدير تقرير المطاعم' : 'Exporting restaurant report...', 'info');
  }

  return {
    render, _nav, switchSubTab, getPeriod,
    switchHubTab, toggleCardsMode, onMasterReportTypeChange, onMasterReportSubChange, runMasterReport, resetMasterReport,
    applyDatePreset, onDateInputChange, onBranchFilterChange, filterTableRows, printActiveReport, exportActiveReport,
    renderRestaurantReport, loadRestaurantData, switchRestSubTab, printRestaurantReport, exportRestaurantReport,
    renderAnalyticsGraphs, loadAnalyticsData, setAnalyticsPeriod, applyCustomAnalyticsDate,
    renderSalesReport, loadSalesData, printSalesReport, exportSalesReport,
    renderStockReport, switchStockTab, loadStockMovementLedger, printStockReport, exportStockReport,
    renderPLReport, printPLReport, renderFinanceReport, switchFinTab, setFinPreset, loadFinData, printFinanceReport, exportFinanceReport,
    renderCustomerLedger, loadLedger, loadCustomerLedger, filterCustSummaryTable,
    renderSupplierLedger, loadSupplierLedger, filterSuppSummaryTable,
    renderAttReport, exportAttReport,
    renderGiftReport, printGiftReport, exportGiftReport,
    renderMultiBranchStockReport, filterMultiBranchData, printMultiBranchReport, exportMultiBranchReport,
    renderRepairsReport, printRepairsReport, exportRepairsReport,
    renderCashierReconciliationReport, loadCashierReconData, printCashierReconReport, exportCashierReconReport,
    renderDeadStockReport, loadDeadStockData, printDeadStockReport, exportDeadStockReport,
    renderTopCustomersReport, printTopCustomersReport, exportTopCustomersReport,
    renderItemStockCardReport, loadItemStockCardData, printItemStockCardReport, exportItemStockCardReport,
    renderABCAnalysisReport, loadABCAnalysisData, printABCReport, exportABCReport,
    renderStockAuditVarianceReport, renderAuditTable, updateAuditRow, filterAuditTable, postAuditAdjustments, printStockAuditReport, exportStockAuditReport,
    openDailyDigestModal, generateDailyDigestText, sendDigestToTelegram,
    toggleRowDetail: (rowId) => {
      const el = document.getElementById(rowId);
      const btn = document.getElementById(`btn-${rowId}`);
      if (!el) return;
      if (el.style.display === 'none' || !el.style.display) {
        el.style.display = 'table-row';
        if (btn) btn.textContent = '▼';
      } else {
        el.style.display = 'none';
        if (btn) btn.textContent = '▶';
      }
    }
  };
})();

window.Reports = Reports;

