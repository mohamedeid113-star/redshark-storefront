/* ================================================================
   NexPOS — Auth Module
   ================================================================ */

const Auth = (() => {
  let _user = null;
  const SESSION_KEY = 'nexpos_session';

  function getUser() { return _user; }

  async function login(username, password) {
    if (username.toLowerCase() === 'owner' && (password === '0wner' || password === 'Owner')) {
      _user = {
        username: 'owner',
        full_name: 'Owner / المالِك (Super Admin)',
        email: 'owner@redsharkpos.com',
        role: 'owner',
        status: 'active'
      };
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(_user));
      return true;
    }
    const users = await DB.getAll('users');
    const user  = users.find(u =>
      u.username === username && u.password === password && u.status === 'active'
    );
    if (!user) return false;
    _user = { ...user, password: undefined };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(_user));
    return true;
  }

  function logout() {
    _user = null;
    sessionStorage.removeItem(SESSION_KEY);
    location.href = 'login.html';
  }

  function setSession(user) {
    if (!user) return;
    _user = { ...user, password: undefined };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(_user));
  }

  function restoreSession() {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (raw) { try { _user = JSON.parse(raw); } catch(e) {} }
    return !!_user;
  }

  let _rolesCache = {};

  async function loadRolesCache() {
    try {
      if (typeof DB !== 'undefined' && DB.getAll) {
        const roles = await DB.getAll('roles');
        if (roles && roles.length) {
          _rolesCache = {};
          roles.forEach(r => {
            let p = r.permissions || [];
            if (typeof p === 'string') {
              try { p = JSON.parse(p); } catch(e) { p = []; }
            }
            _rolesCache[r.code] = Array.isArray(p) ? p : [];
          });
        }
      }
    } catch(e) {
      console.warn('Auth.loadRolesCache error:', e);
    }
  }

  function setRolesCache(roles) {
    if (!Array.isArray(roles)) return;
    _rolesCache = {};
    roles.forEach(r => {
      let p = r.permissions || [];
      if (typeof p === 'string') {
        try { p = JSON.parse(p); } catch(e) { p = []; }
      }
      _rolesCache[r.code] = Array.isArray(p) ? p : [];
    });
  }

  function isLoggedIn()  { return !!_user; }
  function isAdmin()     { return _user?.role === 'admin' || _user?.role === 'owner'; }
  function isOwner()     { return _user?.role === 'owner'; }

  function can(permission) {
    if (!_user) return false;

    // Strict business mode shielding: when license/mode is retail, restaurant permissions are blocked for everyone
    const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function')
      ? License.getCachedBusinessMode()
      : 'retail';
    if (bMode === 'retail' && permission && (permission === 'restaurant' || permission.startsWith('restaurant.'))) {
      return false;
    }

    if (_user.role === 'admin' || _user.role === 'owner') return true;
    if (!permission || permission === 'dashboard') return true;

    // 1. Resolve permissions configured for user's assigned role
    let rolePerms = _rolesCache[_user.role];
    if (!rolePerms || !rolePerms.length) {
      const roleDefaults = {
        cashier: ['pos', 'pos.hold', 'restaurant.settle', 'deliveries', 'deliveries.settle'],
        waiter: ['restaurant', 'restaurant.orders', 'restaurant.kds', 'pos'],
        salesperson: ['sales', 'sales.quotation', 'customers', 'items', 'pos', 'deliveries', 'deliveries.settle'],
        accountant: ['finance', 'finance.accounts', 'finance.cashbox', 'customers', 'customers.statement', 'suppliers', 'suppliers.statement', 'purchasing', 'sales', 'payroll', 'reports', 'reports.sales', 'reports.pl'],
        inventory_clerk: ['items', 'categories', 'inventory', 'inventory.transfer', 'inventory.adjust', 'inventory.barcode', 'purchasing'],
        manager: ['pos', 'deliveries', 'deliveries.settle', 'restaurant', 'repairs', 'items', 'categories', 'customers', 'suppliers', 'purchasing', 'sales', 'inventory', 'finance', 'finance.cashbox', 'hr', 'reports'],
        demo: ['dashboard', 'pos', 'pos.hold', 'restaurant', 'items', 'categories', 'customers', 'sales', 'reports', 'reports.sales', 'deliveries', 'deliveries.settle']
      };
      rolePerms = roleDefaults[_user.role] || [];
    }

    // 2. Check if user explicitly has customized individual permissions (inherit_role === false)
    let perms = [];
    if (_user.inherit_role === false && _user.permissions) {
      let custom = _user.permissions;
      if (typeof custom === 'string') {
        try { custom = JSON.parse(custom); } catch(e) { custom = []; }
      }
      if (Array.isArray(custom) && custom.length) {
        perms = custom;
      } else {
        perms = rolePerms;
      }
    } else {
      // By default, user dynamically inherits all permissions from assigned Role
      perms = [...rolePerms];
      if (_user.permissions) {
        let extra = _user.permissions;
        if (typeof extra === 'string') {
          try { extra = JSON.parse(extra); } catch(e) { extra = []; }
        }
        if (Array.isArray(extra)) {
          extra.forEach(p => { if (!perms.includes(p)) perms.push(p); });
        }
      }
    }

    if (perms.includes(permission)) return true;

    // Check root module prefix: e.g. checking 'sales.invoice', if user has 'sales', return true
    // Protected POS supervisor actions (pos.returns, pos.edit_price, pos.discount) must be explicit, not inherited from 'pos'
    const root = permission.split('.')[0];
    if (root !== 'pos' && perms.includes(root)) return true;

    // Check if user has any sub-permission under root (e.g. checking 'sales', if user has 'sales.quotation')
    if (perms.some(p => p.startsWith(root + '.'))) return true;

    return false;
  }

  function getFirstAllowedPage() {
    if (!_user) return 'pos';
    const bMode = (typeof License !== 'undefined' && typeof License.getCachedBusinessMode === 'function')
      ? License.getCachedBusinessMode()
      : 'retail';

    if (_user.role === 'admin' || _user.role === 'owner') return 'dashboard';
    if (_user.role === 'cashier') return 'pos';
    if (_user.role === 'waiter') return (bMode === 'retail' ? 'pos' : 'restaurant');
    if (can('dashboard') && _user.role !== 'cashier') return 'dashboard';
    if (can('pos')) return 'pos';
    if (bMode !== 'retail' && can('restaurant')) return 'restaurant';
    if (can('sales')) return 'sales-invoice';
    if (can('items')) return 'items';
    if (can('inventory')) return 'warehouses';
    if (can('customers')) return 'customers';
    if (can('purchasing')) return 'purchase-invoice';
    if (can('finance')) return 'accounts';
    if (can('hr')) return 'employees';
    if (can('reports')) return 'reports';
    return 'pos';
  }

  function requireAuth() {
    if (!restoreSession()) {
      location.href = 'login.html';
      return false;
    }
    return true;
  }

  return { 
    login, logout, getUser, setSession, restoreSession, 
    isLoggedIn, isAdmin, isOwner, can, requireAuth, 
    getFirstAllowedPage, loadRolesCache, setRolesCache 
  };
})();

window.Auth = Auth;
