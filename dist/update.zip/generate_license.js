/**
 * Red Shark POS — Developer License Generator (CLI)
 * Run: node generate_license.js [machineId] [clientName] [expiryDate (YYYY-MM-DD)] [mode (retail)]
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SECRET_SALT = "RedSharkPOS_LicenseSalt_2026_Enterprise";

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

function generate(machineId, clientName, expiryDate, businessMode = 'retail', modules = ['*']) {
  if (!machineId || !clientName || !expiryDate) {
    console.error('Usage: node generate_license.js <MachineID> <ClientName> <ExpiryDate YYYY-MM-DD> [Mode: retail]');
    process.exit(1);
  }

  const cleanMachId = machineId.trim().toUpperCase();
  const cleanName = clientName.trim();
  const cleanExpiry = expiryDate.trim();
  const mode = businessMode.trim().toLowerCase();

  const modulesStr = modules.join(',');
  const checkText = `${cleanMachId}|${cleanName}|${cleanExpiry}|${modulesStr}|${SECRET_SALT}`;
  const signature = sha256(checkText);

  const licData = {
    machine_id: cleanMachId,
    client_name: cleanName,
    expiry_date: cleanExpiry,
    allowed_modules: modules,
    business_mode: mode,
    signature: signature
  };

  const encoded = Buffer.from(JSON.stringify(licData)).toString('base64');
  const fileName = `license_${cleanName.replace(/\s+/g, '_')}.lic`;
  const filePath = path.join(__dirname, fileName);

  fs.writeFileSync(filePath, encoded, 'utf8');

  console.log('================================================================');
  console.log(' Red Shark POS — License Generated Successfully!');
  console.log('================================================================');
  console.log(` Client Name   : ${cleanName}`);
  console.log(` Machine ID    : ${cleanMachId}`);
  console.log(` Edition / Mode: ${mode.toUpperCase()}`);
  console.log(` Expiry Date   : ${cleanExpiry}`);
  console.log(` Saved File    : ${filePath}`);
  console.log('----------------------------------------------------------------');
  console.log(' Base64 Key (Copy & Paste):');
  console.log(encoded);
  console.log('================================================================');
}

// Read args
const args = process.argv.slice(2);
if (args.length >= 3) {
  generate(args[0], args[1], args[2], args[3] || 'retail');
} else {
  console.log('--- Interactive Mode ---');
  const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
  });

  readline.question('Machine ID (e.g. RS-XXXX): ', (machId) => {
    readline.question('Client / Store Name: ', (name) => {
      readline.question('Expiry Date (YYYY-MM-DD, e.g. 2027-12-31): ', (expiry) => {
        generate(machId, name, expiry, 'retail');
        readline.close();
      });
    });
  });
}
