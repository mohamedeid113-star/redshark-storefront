@echo off
setlocal

set POS_ROOT=D:\GravityProject\POSSoftware
set STORE_ROOT=D:\GravityProject\RedSharkStorefront

if not exist "%POS_ROOT%\version.json" (
  echo [ERROR] POS version.json not found: %POS_ROOT%\version.json
  pause
  exit /b 1
)

if not exist "%STORE_ROOT%" (
  echo [ERROR] Storefront repo not found: %STORE_ROOT%
  pause
  exit /b 1
)

if not exist "%STORE_ROOT%\dist" mkdir "%STORE_ROOT%\dist"

copy /Y "%POS_ROOT%\version.json" "%STORE_ROOT%\version.json"

if exist "%POS_ROOT%\dist\update_1.4.89.zip" (
  copy /Y "%POS_ROOT%\dist\update_1.4.89.zip" "%STORE_ROOT%\dist\update.zip"
) else if exist "%POS_ROOT%\dist\update.zip" (
  copy /Y "%POS_ROOT%\dist\update.zip" "%STORE_ROOT%\dist\update.zip"
) else (
  echo [WARN] No update zip found in %POS_ROOT%\dist
)

echo.
echo [INFO] Synced storefront release files.
echo [INFO] Pushing to GitHub...

git -C "%STORE_ROOT%" add version.json dist/update.zip

git -C "%STORE_ROOT%" commit -m "chore: publish OTA release 1.4.89" || echo [INFO] No new commit created.

git -C "%STORE_ROOT%" push origin main

echo.
echo [INFO] Done.
pause
