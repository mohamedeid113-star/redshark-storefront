/**
 * Red Shark POS — Safe Clean Reset & Sync Restart Utility
 * 
 * Clears all items, sales, transactions, transfers, and sync watermarks,
 * while STRICTLY PRESERVING:
 * 1. Server & Branch node configuration (role, node_id, server_ip, branch_id)
 * 2. Store / Warehouse definitions (BOBmarketKobayath, BOBmarketKatlaben)
 * 3. System settings, licenses, and admin credentials
 * 4. Cleans up Supabase Cloud for bobmarket (products, orders, banner_url)
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MASTER_SECRET = '0wner_RedSharkPOS_SuperSecret_Master_Key_2026';
const ENC_KEY = crypto.createHash('sha256').update(MASTER_SECRET).digest();

function decryptText(encryptedText) {
  try {
    const parts = encryptedText.split(':');
    if (parts.length !== 3) return null;
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    const decipher = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (e) {
    return null;
  }
}

function encryptText(text) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

async function cleanCloud(shopSlug = 'bobmarket') {
  console.log(`\n☁️ Step 1: Cleaning Supabase Cloud for shop: ${shopSlug}...`);
  const url = 'https://mcebwpiswvwqcdwjpagy.supabase.co';
  const key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg';
  const headers = {
    'apikey': key,
    'Authorization': `Bearer ${key}`,
    'Content-Type': 'application/json'
  };

  try {
    const tRes = await fetch(`${url}/rest/v1/tenants?slug=eq.${encodeURIComponent(shopSlug)}&select=id,shop_name`, { headers });
    const tData = await tRes.json();
    if (!tData || !tData.length) {
      console.warn(`  ⚠️ Shop slug "${shopSlug}" not found on Supabase.`);
      return;
    }
    const shopId = tData[0].id;
    console.log(`  ✓ Found Shop: ${tData[0].shop_name} (ID: ${shopId})`);

    // 1. Delete products
    const delP = await fetch(`${url}/rest/v1/products?shop_id=eq.${shopId}`, {
      method: 'DELETE',
      headers: { ...headers, 'Prefer': 'return=representation' }
    });
    console.log(`  ✓ Cleared Cloud Products (Status: ${delP.status})`);

    // 2. Delete categories
    const delC = await fetch(`${url}/rest/v1/categories?shop_id=eq.${shopId}`, {
      method: 'DELETE',
      headers: { ...headers, 'Prefer': 'return=representation' }
    });
    console.log(`  ✓ Cleared Cloud Categories (Status: ${delC.status})`);

    // 3. Delete orders
    const delO = await fetch(`${url}/rest/v1/orders?shop_id=eq.${shopId}`, {
      method: 'DELETE',
      headers: { ...headers, 'Prefer': 'return=representation' }
    });
    console.log(`  ✓ Cleared Cloud Orders (Status: ${delO.status})`);

    // 4. Reset banner_url to clean lightweight metadata
    const cleanBanner = {
      cloud_sync_seq: 1,
      tables_updated_at: new Date().toISOString(),
      last_change_type: 'reset',
      last_change_desc: 'Initial Clean Setup',
      last_change_time: new Date().toISOString()
    };
    const patchB = await fetch(`${url}/rest/v1/tenants?id=eq.${shopId}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ banner_url: JSON.stringify(cleanBanner) })
    });
    console.log(`  ✓ Reset Cloud banner_url to clean state (${JSON.stringify(cleanBanner).length} bytes, Status: ${patchB.status})`);
  } catch(e) {
    console.error('  ✗ Cloud cleanup error:', e.message);
  }
}

function cleanLocalServer() {
  console.log('\n🖥️ Step 2: Resetting Local Server Cache & Sync Watermarks...');
  const SYNC_DIR = path.join(__dirname, 'data', 'sync');
  const TABLES_DIR = path.join(SYNC_DIR, 'tables');

  if (fs.existsSync(TABLES_DIR)) {
    const files = fs.readdirSync(TABLES_DIR);
    for (const f of files) {
      if (f.endsWith('.json')) {
        // Keep warehouses table intact if exists, reset others
        if (f === 'warehouses.json') continue;
        fs.writeFileSync(path.join(TABLES_DIR, f), JSON.stringify([]), 'utf8');
        console.log(`  ✓ Reset snapshot: ${f}`);
      }
    }
  }

  // Clear transactions.json
  const transFile = path.join(SYNC_DIR, 'transactions.json');
  if (fs.existsSync(transFile)) {
    const emptyTrans = { sales: [], purchases: [], purchaseReturns: [], salesReturns: [], cashboxSessions: [], cashTransactions: [] };
    fs.writeFileSync(transFile, JSON.stringify(emptyTrans, null, 2), 'utf8');
    console.log('  ✓ Reset transactions.json');
  }

  // Clear tombstones.json
  const tombFile = path.join(SYNC_DIR, 'tombstones.json');
  if (fs.existsSync(tombFile)) {
    fs.writeFileSync(tombFile, JSON.stringify([]), 'utf8');
    console.log('  ✓ Reset tombstones.json');
  }

  // Reset local database db.dat
  const dbFile = path.join(__dirname, 'data', 'db.dat');
  if (fs.existsSync(dbFile)) {
    try {
      const raw = fs.readFileSync(dbFile, 'utf8').trim();
      const dec = decryptText(raw);
      if (dec) {
        const db = JSON.parse(dec);
        const preservedWarehouses = db.warehouses || [];
        const preservedSettings = db.settings || [];
        const preservedUsers = db.users || [];

        // Clear operational data
        db.items = [];
        db.sales = [];
        db.sales_invoice = [];
        db.sales_returns = [];
        db.purchase_invoices = [];
        db.purchase_returns = [];
        db.cash_transactions = [];
        db.bank_transactions = [];
        db.cashbox_sessions = [];
        db.cashbox_movements = [];
        db.stock_transfers = [];
        db.stock_movements = [];
        db.stock_adjustments = [];
        db.categories = [];
        db.offers = [];

        // Ensure warehouses are preserved
        db.warehouses = preservedWarehouses;
        db.settings = preservedSettings;
        db.users = preservedUsers;

        const enc = encryptText(JSON.stringify(db, null, 2));
        fs.writeFileSync(dbFile, enc, 'utf8');
        console.log(`  ✓ Reset db.dat (Preserved ${preservedWarehouses.length} warehouses & system settings)`);
      }
    } catch(dbErr) {
      console.warn('  ⚠️ db.dat reset warning:', dbErr.message);
    }
  }
}

async function run() {
  console.log('====================================================');
  console.log('🔄 Red Shark POS — Clean Reset & Start Fresh Sync');
  console.log('====================================================');
  await cleanCloud('bobmarket');
  cleanLocalServer();
  console.log('\n====================================================');
  console.log('✅ Server & Cloud reset completed successfully!');
  console.log('====================================================');
}

if (require.main === module) {
  run();
}

module.exports = { cleanCloud, cleanLocalServer };

