# Red Shark POS — Project Handoff & Technical Status

## 1. Goal of This Project
**Red Shark POS** is a commercial, enterprise-grade Point of Sale (POS), Inventory, Financial, Multi-Branch Synchronization, and Online Storefront system. It is designed for grocery stores, supermarkets, retail shops, and restaurants.
Key operational requirements:
- **Zero Data Loss & Rock-Solid Stability**: The software is sold commercially to paying clients; data corruption, duplicate transactions, missing invoices, or lost customer debt balances are unacceptable.
- **Offline-First Resilience**: Workstations and branch terminals must function completely offline on local IndexedDB and sync seamlessly with the Central Server / LAN / Cloudflare Tunnel without freezing the cashier interface.
- **Accurate Financial & Stock Attribution**: Sales, stock deductions, cash drawer balances, and customer accounts must be strictly attributed to the correct branch without cross-branch pollution.

---

## 2. What We’ve Done So Far

### A. Barcode `1` Conflict & Sequence Overlap (Resolved in v1.4.87 / Build 175)
1. **Scale Barcode Collision (`js/utils.js`)**:
   - `Utils.parseScaleBarcode` previously had fallback checks matching `String(i.id) === pluStr` and `i.barcode === pluStr`. When an item with barcode `1` was added, any scale barcode starting with PLU `1` was falsely hijacked.
   - **Fix**: Restricted scale barcode matching strictly to items with `is_scale: true` and an explicit `scale_plu`.
2. **Search Substring Freezes (`js/modules/pos.js`)**:
   - Searching or scanning `1` used `.includes(query)`, matching thousands of EAN-13 barcodes containing the digit `1` and freezing the DOM.
   - **Fix**: Enforced exact matching (`barcode === query`) for inputs of length $\le 2$ and prioritized exact matches at the top.
3. **Item Sequence Gaps (`js/db.js`)**:
   - Item code generation previously read from sequence cache (`current: 4`), producing `ITM-00005` in existing gaps instead of appending after `ITM-00021`.
   - **Fix**: Redesigned `nextSeq` and `peekSeq` to dynamically compute `maxNum = Math.max(record.current, ...allExistingTableRecords) + 1`, guaranteeing new items always append at the very end.
4. **Selective "Delete Only Items" Tool (`js/modules/admin.js`, `js/modules/items.js`)**:
   - Added a red **"تفريغ دليل الأصناف" (Clear Items Catalog)** toolbar button and Option 0 in Database Reset to wipe only `items` and item counters while strictly preserving customer balances, debts, suppliers, invoices, and licenses.
   - Published release **v1.4.87 (Build 175)** to Cloudflare OTA and `dist/RedSharkPOS_Client_Release`.

### B. Customer Bug Diagnosis (Audio Note & Production Report)
We investigated the root causes behind 4 critical customer complaints:
1. **Phantom Branch Sales on Server Report**: Server reports showed sales under a branch that had made zero sales.
2. **Duplicate Phantom Branch in Dropdowns**: Systems with only 1 branch showed 2 branches.
3. **Double Invoices in Customer Account Statement**: Invoices appeared twice (once as an invoice and once as an immediate cash payment or down payment).
4. **Software Stalls/Freezes on Opening POS/Reports/Customers**: UI locked up, forcing cashiers to kill and restart the application.

### C. System Hardening & Architectural Fixes Implemented
1. **Atomic Server Database Writes & Rolling Backups (`server.js`)**:
   - Replaced fragile non-atomic `fs.writeFileSync(DB_FILE, ...)` with temporary file write + atomic rename (`fs.renameSync`).
   - Implemented an emergency write-abort shield: if `readDb()` fails to decrypt or parse `db.dat`, subsequent writes are blocked so an empty memory state can never wipe customer data.
   - Added rolling encrypted backups in `data/backups/` keeping the last 30 snapshots with a 10-minute rotation throttle.
2. **Canonical Branch & Transaction Identity (`server.js`)**:
   - Built canonical `txnBranch(s)` and `txnKey(s)` helpers in `server.js`.
   - Fixed `/api/sync/transactions` and `/api/sync/push-transactions` so transactions are keyed consistently via UUID or `ref::branch::invoice_no`.
   - Resolved branch cashbox session and movement leaks where movements from all branches were returned to any requesting branch.
   - Fixed warehouse stock snapshot cross-contamination so server pushes (`main`) can never write into remote branch warehouses.
   - Stopped central server pushes from registering the server as a remote "branch" node in `nodes.json` (root cause of the phantom 2nd branch).
3. **Safe Deduplication & Automatic UUID Injection (`js/db.js`)**:
   - Replaced destructive startup `_repairDuplicateRefs()` (which deleted records by plain `ref`, merged customers by name, and purged categories/items) with a non-destructive fingerprint matcher (`uuid` or `ref` + amount + exact creation timestamp).
   - Moved duplicate repair to background execution with a 6-hour throttle so it never blocks or freezes application startup.
   - Added auto-generation of RFC-compliant `uuid`s on `DB.add` and `DB.update` across all 13 transactional stores.

---

## 3. Key Decisions & Architecture Principles
1. **No Data Deletion on Guesswork**:
   - Duplicate cleaning must never delete records simply because invoice numbers match across terminals. Multi-terminal POS setups inevitably produce colliding local counters if offline; deduplication must strictly key on `uuid` or full business fingerprints.
2. **Single Authority for Branch Metadata**:
   - The Central Server is the master authority for warehouses and branches. Workstation nodes inherit their branch identity and must never re-register themselves or alter server warehouse IDs.
3. **Atomic File System Operations**:
   - In a production environment running on Windows, file write race conditions and power interruptions must be guarded by write-to-temp and atomic rename.
4. **Clear Separation of Master Data vs Transactional Ledgers**:
   - Master data (items, prices, categories, barcodes) sync downward from server to branch.
   - Transactional ledgers (sales, cash sessions, payments) push upward from branches to server.

---

## 4. Files Changed

| File | Status | Description of Changes |
| :--- | :--- | :--- |
| `server.js` | Modified | Atomic DB writes (`tmp` + rename), rolling backups (`data/backups`), canonical `txnBranch`/`txnKey`, branch cash report isolation, prevented server self-registration as branch node. |
| `js/db.js` | Modified | Auto-assignment of UUIDs for transactional stores, safe fingerprint-based deduplication, non-blocking background repair schedule, preserved original timestamps on imports. |
| `js/modules/pos.js` | Committed (v1.4.87) | Scale PLU barcode 1 collision fix, short-query exact barcode matching, UI totals calculation. |
| `js/utils.js` | Committed (v1.4.87) | Strict scale barcode parsing guard requiring `is_scale: true` and `scale_plu`. |
| `js/modules/admin.js` | Committed (v1.4.87) | Selective database reset tool (Option 0: Delete Items Only) preserving debts and accounts. |
| `js/modules/items.js` | Committed (v1.4.87) | Added "تفريغ دليل الأصناف" header action button with safety modal. |
| `Build_Client_Release.js` | Committed (v1.4.87) | Excluded background service scripts from client tar to prevent file-lock build crashes. |
| `package.json` / `version.json` | Committed (v1.4.87) | Bumped to `v1.4.87 (Build 175)`. |

---

## 5. Current Bugs & Known Vulnerabilities (Pending Fixes)

1. **Synchronous Full-Table Sync Freezes UI (`js/modules/branch_sync.js`)**:
   - `pushLocalTransactions()` and `importBranchTransactionsToServerDb()` are triggered every 3–4 seconds on the main thread.
   - Every tick executes `DB.getAll()` on 10 stores (thousands of rows) and serializes massive JSON payloads over HTTP. When the customer's sales history grows, this chokes the JavaScript main thread and freezes POS/Reports.
   - **Required Fix**: Throttle sync intervals, implement dirty/incremental change tracking (only push unsynced records where `sync_status !== 'synced'`), and avoid full-table sweeps every 3 seconds.
2. **Double Entry in Customer Statement of Account (`js/modules/customers.js`)**:
   - In `CustomersModule.buildCustomerLedger`, every cash sale adds two rows: a debit entry ("POS Sale") and an automatic credit entry ("Immediate Cash Payment").
   - Customers interpret this as the invoice being entered twice. Furthermore, if a credit sale down payment already exists in `cash_transactions`, mismatched IDs can cause both the synthetic down payment row and the actual receipt row to render.
   - **Required Fix**: Cleanly format customer statements with clear running balances, consolidate cash sales into single neutral rows in statement view, and match down payments strictly by `sale_ref` / `uuid`.
3. **Non-Atomic POS Checkout Execution (`js/modules/pos.js`)**:
   - The checkout routine executes 6 sequential asynchronous operations: sequence increment, customer balance update, sale record save, delivery record save, cashbox record save, and item stock deductions.
   - An unexpected error or sudden power cutoff midway leaves orphaned records (e.g., debt increased without an invoice, or invoice saved without stock deduction).
   - **Required Fix**: Wrap core checkout steps in a unified error-catch handler with compensating rollback.

---

## 6. Exact Next Steps

1. **Step 1: Optimize Sync Cadence & Server Self-Sync in `js/modules/branch_sync.js`**:
   - Prevent the server role from executing `pushLocalTransactions()` with hardcoded fallback `branch-1`.
   - Change the heartbeat loop on branches to send lightweight ping requests (checking table version hashes) instead of sweeping full tables every 3 seconds.
2. **Step 2: Refactor Customer Statement Ledger in `js/modules/customers.js`**:
   - In `buildCustomerLedger`, ensure immediate cash sales show as a single completed transaction or provide a clean toggle between "All Transactions" and "Debt Movements Only".
   - Fix linked transaction matching so down payments are not counted twice.
3. **Step 3: Syntax & Runtime Verification**:
   - Run `node --check server.js` and test client script execution in browser sandbox.
4. **Step 4: Package & Deploy v1.4.88**:
   - Run `node Build_Client_Release.js` to build version `1.4.88 (Build 176)`, package hardened client binaries, and push OTA update to Cloudflare and git repository.

