/* ================================================================
   Red Shark POS — Licensing & Security Manager
   ================================================================ */

const License = (() => {
  const SECRET_SALT = "RedSharkPOS_LicenseSalt_2026_Enterprise";
  const APP_VERSION = "1.4.89"; // Incremented each time we update
  const APP_BUILD = 177;

  // Helper: Simple SHA-256 hash using Web Crypto API
  async function _hash(text) {
    const msgBuffer = new TextEncoder().encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  let _cachedMachineId = null;
  let _cachedStatus = null;
  let _cachedStatusTime = 0;

  // Get or create unique Machine ID (hardware-locked & persistent offline)
  async function getMachineId() {
    if (_cachedMachineId) return _cachedMachineId;

    // 1. If active license is already installed, preserve its machine_id
    const rawLic = await DB.getSetting('license_active_data');
    if (rawLic) {
      try {
        const lic = JSON.parse(rawLic);
        if (lic && lic.machine_id) {
          _cachedMachineId = lic.machine_id;
          return lic.machine_id;
        }
      } catch {}
    }

    // 2. Query local server hardware-id endpoint
    try {
      const res = await fetch('/api/hardware-id');
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.machine_id) {
          _cachedMachineId = json.machine_id;
          await DB.setSetting('license_machine_id', json.machine_id);
          localStorage.setItem('redshark_cached_machine_id', json.machine_id);
          return json.machine_id;
        }
      }
    } catch (e) {}

    // 3. Persistent DB or localStorage cache
    let machineId = await DB.getSetting('license_machine_id');
    if (!machineId) {
      machineId = localStorage.getItem('redshark_cached_machine_id');
    }
    if (!machineId) {
      machineId = 'RS-' + 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      }).substring(0, 18).toUpperCase();
      await DB.setSetting('license_machine_id', machineId);
      localStorage.setItem('redshark_cached_machine_id', machineId);
    }
    _cachedMachineId = machineId;
    return machineId;
  }

  // Generate License Request File content
  async function generateRequestFile() {
    const machineId = await getMachineId();
    const companyName = await DB.getSetting('company_name', 'My Shop');
    const reqData = {
      machine_id: machineId,
      company: companyName,
      version: APP_VERSION,
      timestamp: new Date().toISOString()
    };
    const encoded = btoa(JSON.stringify(reqData));
    
    const blob = new Blob([encoded], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LicenseRequest_${machineId}.req`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Activate license from file upload or raw text
  async function activateLicenseText(raw) {
    const isAR = i18n.getLang() === 'ar';
    if (!raw || !raw.trim()) {
      return Utils.toast(isAR ? 'يرجى إدخال مفتاح الترخيص أو اختيار الملف' : 'Please enter or select a license key', 'warning');
    }

    try {
      const cleanRaw = raw.trim().replace(/\s+/g, '');
      const decoded = JSON.parse(atob(cleanRaw));
      
      // Validate signature
      const isValid = await verifyLicenseObject(decoded);
      if (!isValid) {
        return Utils.toast(isAR ? 'رمز الترخيص غير صالح لجهازك أو تم التعديل عليه!' : 'Invalid signature or license is not matching this machine!', 'error');
      }

      // Save license & deactivate demo mode
      await DB.setSetting('license_active_data', JSON.stringify(decoded));
      if (decoded.machine_id) {
        await DB.setSetting('license_machine_id', decoded.machine_id);
        localStorage.setItem('redshark_cached_machine_id', decoded.machine_id);
        _cachedMachineId = decoded.machine_id;
      }
      await DB.setSetting('demo_trial_active', false);
      _cachedStatus = null;
      Utils.toast(isAR ? 'تم تفعيل ترخيص البرنامج بنجاح!' : 'Software License Activated Successfully!', 'success');
      
      // Refresh page to apply changes
      await App.renderPage(App.getCurrentPage());
    } catch (err) {
      console.error(err);
      Utils.toast(isAR ? 'حدث خطأ أثناء تنشيط الترخيص: رمز غير صالح' : 'Error activating license: Invalid format', 'error');
    }
  }

  // Activate license from file upload
  async function activateLicense(fileInputId) {
    const file = document.getElementById(fileInputId)?.files[0];
    if (!file) return Utils.toast('Please select a license file (.lic)', 'warning');

    const reader = new FileReader();
    reader.onload = async (e) => {
      await activateLicenseText(e.target.result);
    };
    reader.readAsText(file);
  }

  // Deactivate/Clear license
  async function deactivateLicense() {
    const isAR = i18n.getLang() === 'ar';
    if (confirm(isAR ? 'هل أنت متأكد من إلغاء تنشيط الترخيص الحالي؟' : 'Are you sure you want to deactivate the current license?')) {
      await DB.setSetting('license_active_data', '');
      _cachedStatus = null;
      Utils.toast(isAR ? 'تم إلغاء التنشيط' : 'License deactivated successfully', 'info');
      await App.renderPage(App.getCurrentPage());
    }
  }

  // Verify license signature and expiration
  async function verifyLicenseObject(lic) {
    if (!lic || !lic.machine_id || !lic.expiry_date || !lic.signature) return false;

    // Verify signature hash
    const modulesStr = (lic.allowed_modules || []).join(',');
    const checkText = `${lic.machine_id}|${lic.client_name || ''}|${lic.expiry_date}|${modulesStr}|${SECRET_SALT}`;
    const computedSig = await _hash(checkText);
    if (computedSig !== lic.signature) return false;

    // Check machine lock:
    // 1. Direct hardware machine ID match
    const currentMachine = await getMachineId();
    if (lic.machine_id.toUpperCase() === currentMachine.toUpperCase()) return true;

    // 2. Wildcard / Multi-terminal license (* or ALL)
    if (lic.machine_id === '*' || lic.machine_id === 'ALL') return true;

    // 3. Shop Slug Match (Allows a shop like 'bobmarket' to license all its stations/branches!)
    const shopSlug = (await DB.getSetting('online_store_slug', '')) || localStorage.getItem('redshark_shop_slug') || '';
    if (shopSlug && lic.machine_id.trim().toLowerCase() === shopSlug.trim().toLowerCase()) return true;

    // 4. Client / Company Name Match
    const compName = (await DB.getSetting('company_name', '')) || '';
    if (compName && lic.machine_id.trim().toLowerCase() === compName.trim().toLowerCase()) return true;
    if (lic.client_name && shopSlug && lic.client_name.trim().toLowerCase() === shopSlug.trim().toLowerCase()) return true;
    if (lic.client_name && compName && lic.client_name.trim().toLowerCase() === compName.trim().toLowerCase()) return true;

    // 5. If on a client/mobile terminal, verify if server validates this license
    try {
      const srv = await fetch('/api/license-status', { signal: AbortSignal.timeout(2000) });
      if (srv.ok) {
        const srvData = await srv.json();
        if (srvData.success && srvData.active) return true;
      }
    } catch(e) {}

    return false;
  }

  // Fetch active license status
  async function getStatus(forceRefresh = false) {
    if (!forceRefresh && _cachedStatus && (Date.now() - _cachedStatusTime < 30000)) {
      return _cachedStatus;
    }

    let result = null;

    // 0. Primary check for mobile & client terminals: Inherit license directly from POS server
    try {
      const srvRes = await fetch('/api/license-status', { signal: AbortSignal.timeout(2500) });
      if (srvRes.ok) {
        const srvJson = await srvRes.json();
        if (srvJson.success && srvJson.active && srvJson.status === 'active') {
          result = {
            active: true,
            status: 'active',
            data: srvJson.data || { allowed_modules: ['*'] },
            is_licensed: true,
            is_server_license: true,
            machine_id: srvJson.machine_id
          };
          _cachedStatus = result;
          _cachedStatusTime = Date.now();
          return result;
        } else if (srvJson.success && srvJson.status === 'demo_trial') {
          result = {
            active: true,
            status: 'demo_trial',
            data: {
              client_name: 'Demo Trial',
              expiry_date: srvJson.expiresAt ? srvJson.expiresAt.split('T')[0] : '',
              allowed_modules: ['*']
            },
            is_licensed: false,
            is_demo: true,
            is_server_license: true
          };
          _cachedStatus = result;
          _cachedStatusTime = Date.now();
          return result;
        }
      }
    } catch(e) {}

    // 1. Check if an active license key is installed on this machine
    const raw = await DB.getSetting('license_active_data');
    if (raw) {
      try {
        const lic = JSON.parse(raw);
        const isValid = await verifyLicenseObject(lic);
        if (!isValid) {
          result = { active: false, status: 'tampered', is_licensed: false };
        } else {
          const now = new Date();
          const expiry = new Date(lic.expiry_date + 'T23:59:59');
          if (now > expiry) {
            result = { active: false, status: 'expired', data: lic, is_licensed: true };
          } else {
            result = { active: true, status: 'active', data: lic, is_licensed: true };
          }
        }
      } catch {
        result = { active: false, status: 'corrupt', is_licensed: false };
      }
    }

    // 2. Check if Demo Trial is active
    if (!result) {
      const isDemo = await DB.getSetting('demo_trial_active', false);
      if (isDemo) {
        const expiresAt = await DB.getSetting('demo_expires_at', null);
        const remainingMs = expiresAt ? (new Date(expiresAt).getTime() - Date.now()) : 0;
        if (remainingMs > 0) {
          result = {
            active: true,
            status: 'demo_trial',
            data: {
              client_name: await DB.getSetting('demo_shop_name', 'Demo Trial User'),
              expiry_date: expiresAt ? expiresAt.split('T')[0] : '',
              allowed_modules: ['*']
            },
            is_licensed: false,
            is_demo: true
          };
        } else {
          result = {
            active: false,
            status: 'expired',
            data: {
              client_name: await DB.getSetting('demo_shop_name', 'Demo Trial User'),
              expiry_date: expiresAt ? expiresAt.split('T')[0] : 'Expired'
            },
            is_licensed: false,
            is_demo: true
          };
        }
      }
    }

    // 3. Online cloud demo host requires active trial (no permanent 2029 bypass)
    if (!result) {
      const isOnlineDemo = window.location.hostname.includes('demo') || window.location.hostname.includes('workers.dev');
      if (isOnlineDemo) {
        result = {
          active: false,
          status: 'unlicensed',
          data: {
            client_name: 'Red Shark Demo Trial Required',
            expiry_date: '',
            allowed_modules: []
          },
          is_licensed: false,
          is_demo: false
        };
      }
    }

    // 4. Unlicensed / Locked by default (Requires Activation or Demo Request)
    if (!result) {
      result = {
        active: false,
        status: 'unlicensed',
        data: {
          client_name: 'Unlicensed Software',
          expiry_date: '',
          allowed_modules: []
        },
        is_licensed: false
      };
    }

    _cachedStatus = result;
    _cachedStatusTime = Date.now();
    return result;
  }

  let _cachedBusinessMode = null;

  // Get business operating mode strictly from the active license or system setup
  async function getBusinessMode() {
    const raw = await DB.getSetting('license_active_data');
    if (raw) {
      try {
        const lic = JSON.parse(raw);
        if (lic.business_mode) {
          _cachedBusinessMode = lic.business_mode.toLowerCase();
          return _cachedBusinessMode;
        }
        const mods = (lic.allowed_modules || []).map(m => m.toLowerCase());
        _cachedBusinessMode = 'retail';
        return 'retail';
      } catch(e) {}
    }

    _cachedBusinessMode = 'retail';
    return _cachedBusinessMode;
  }

  function getCachedBusinessMode() {
    return _cachedBusinessMode || 'retail';
  }

  // Route security shield: returns true if allowed to access the page
  async function checkRouteAccess(page, pageModule) {
    if (page === 'settings' || page === 'backup') return true;

    const isOnlineDemo = window.location.hostname.includes('demo') || window.location.hostname.includes('github.io');
    if (isOnlineDemo) return true;

    // Check if Demo Trial is active and not expired
    const isDemo = await DB.getSetting('demo_trial_active', false);
    if (isDemo) {
      const expiresAt = await DB.getSetting('demo_expires_at', null);
      const remainingMs = expiresAt ? (new Date(expiresAt).getTime() - Date.now()) : 0;
      if (remainingMs > 0) {
        return true;
      }
    }

    const status = await getStatus();
    if (!status.active) return false;

    // Check module permission in license
    if (status.data && status.data.allowed_modules) {
      const allowed = status.data.allowed_modules.map(m => m.toLowerCase());
      if (allowed.includes('*') || allowed.includes('all')) return true;

      let checkModule = pageModule ? pageModule.toLowerCase() : '';
      if (checkModule === 'items' || checkModule === 'categories') checkModule = 'inventory';
      else if (checkModule === 'customers') checkModule = 'sales';
      else if (checkModule === 'suppliers') checkModule = 'purchasing';
      else if (checkModule === 'cashbox' || checkModule === 'deliveries' || checkModule === 'retail_deliveries') checkModule = 'pos';
      else if (checkModule === 'onlineorders' || checkModule === 'online_orders' || checkModule === 'online_store') {
        return allowed.includes('online_store') || allowed.includes('onlineorders') || allowed.includes('online-orders') || allowed.includes('onlinestore');
      }
      else if (checkModule === 'repairs') {
        return allowed.includes('repairs') || allowed.includes('repair') || allowed.includes('workshop');
      }
      else if (checkModule === 'multibranch' || checkModule === 'branch-sync' || page === 'multi-pos') {
        return allowed.includes('multibranch') || allowed.includes('multi_branch') || allowed.includes('multi-branch') || allowed.includes('multi_pos');
      }
      else if (checkModule === 'finance' || checkModule === 'accounting') {
        return allowed.includes('finance') || allowed.includes('accounting');
      }
      else if (checkModule === 'hr') {
        return allowed.includes('hr');
      }
      else if (checkModule === 'payroll') {
        return allowed.includes('payroll') || allowed.includes('hr');
      }
      
      if (checkModule && !allowed.includes(checkModule)) {
        return false;
      }
    }
    return true;
  }

  // Feature flag checker for add-ons
  async function hasFeature(featureKey) {
    const isDemo = await DB.getSetting('demo_trial_active', false);
    if (isDemo) return true;

    const status = await getStatus();
    if (!status.active) return true;
    if (!status.data || !status.data.allowed_modules) return true;
    const allowed = status.data.allowed_modules.map(m => m.toLowerCase());
    if (allowed.includes('*') || allowed.includes('all')) return true;

    const fLow = (featureKey || '').toLowerCase();
    if (fLow === 'direct_print' || fLow === 'thermal_direct' || fLow === 'directprint') {
      return allowed.includes('direct_print') || allowed.includes('thermal_printer') || allowed.includes('directprint');
    }
    if (fLow === 'multibranch' || fLow === 'multi_branch' || fLow === 'branch_sync') {
      return allowed.includes('multibranch') || allowed.includes('multi_branch') || allowed.includes('multi-branch') || allowed.includes('multi_pos');
    }
    return allowed.includes(fLow);
  }

  // Developer Tool: Generate License File for clients
  async function generateLicenseFileDev(devKey, clientMachineId, clientName, expiryDate, modulesArray, businessMode = 'retail') {
    const pinHash = await _hash(devKey);
    const validHashes = [
      "0160d31fafd3d415176116adfd6d2d7cb64a3c2db7711154357abb0bd8b76434", // 'RedSharkAdminMaster2026'
      "bca578b88d3a77eaefd32bc13d50fa5de6c6f6630f9a263259837c76251b66b4"
    ];
    if (!validHashes.includes(pinHash) && devKey !== 'RedSharkAdminMaster2026') {
      throw new Error("Invalid Developer Master Key!");
    }

    const modulesStr = (modulesArray || []).join(',');
    const checkText = `${clientMachineId}|${clientName}|${expiryDate}|${modulesStr}|${SECRET_SALT}`;
    const signature = await _hash(checkText);

    const licData = {
      machine_id: clientMachineId,
      client_name: clientName,
      expiry_date: expiryDate,
      allowed_modules: modulesArray,
      business_mode: businessMode,
      signature: signature
    };

    const encoded = btoa(JSON.stringify(licData));
    const blob = new Blob([encoded], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `license_${clientName.replace(/\s+/g, '_')}.lic`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  return {
    APP_VERSION,
    APP_BUILD,
    getMachineId,
    generateRequestFile,
    activateLicense,
    activateLicenseText,
    deactivateLicense,
    getStatus,
    getBusinessMode,
    getCachedBusinessMode,
    checkRouteAccess,
    hasFeature,
    generateLicenseFileDev
  };
})();

window.License = License;
