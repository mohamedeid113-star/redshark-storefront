/* ================================================================
   NexPOS — Generic CRUD Helper (used by Customers, Suppliers, etc.)
   ================================================================ */

function buildGenericList(config) {
  /**
   * config: {
   *   store, title, titleAr, singularEn, singularAr,
   *   columns: [{key, label, labelAr, render?}],
   *   fields:  [{id, label, labelAr, type, placeholder, placeholderAr, options?, dir?}],
   *   searchKeys: ['name_en','name_ar',...]
   * }
   */
  return {
    _data: [],
    _page: 1,
    _perPage: 20,

    async render(container) {
      this._data = await DB.getAll(config.store);
      const isAR = i18n.getLang() === 'ar';
      this._page = 1;
      const title = isAR ? config.titleAr : config.title;
      const singular = isAR ? config.singularAr : config.singularEn;

      container.innerHTML = `
      <div class="animate-slide">
        <div class="page-header">
          <div class="page-header-left">
            <h1>${title}</h1>
            <p>${isAR ? `${this._data.length} سجل` : `${this._data.length} records`}</p>
          </div>
          <div class="page-actions">
            <button class="btn btn-secondary" onclick="${config.store}Module.exportData()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              ${isAR ? 'تصدير' : 'Export'}
            </button>
            <button class="btn btn-primary" onclick="${config.store}Module.openForm()">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              ${isAR ? 'جديد' : 'New'} ${singular}
            </button>
          </div>
        </div>

        <div class="toolbar">
          <div class="search-bar flex-1">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" class="form-control" id="${config.store}-search"
              placeholder="${isAR ? 'بحث...' : 'Search...'}"
              oninput="${config.store}Module.search(this.value)" style="padding-left:34px">
          </div>
        </div>

        <div class="table-wrapper">
          <table>
            <thead><tr>
              ${config.columns.map(c => `<th>${isAR ? c.labelAr : c.label}</th>`).join('')}
              <th>${isAR ? 'إجراءات' : 'Actions'}</th>
            </tr></thead>
            <tbody id="${config.store}-tbody"></tbody>
          </table>
        </div>
        <div class="pagination" id="${config.store}-pag"></div>
      </div>

      <!-- Form Modal -->
      <div class="modal-overlay" id="${config.store}-modal">
        <div class="modal" style="max-width:560px">
          <div class="modal-header">
            <div class="modal-title" id="${config.store}-modal-title">
              ${singular}
            </div>
            <button class="btn-icon" onclick="Utils.closeModal('${config.store}-modal')">✕</button>
          </div>
          <div class="modal-body">
            <div class="grid grid-2">
              ${config.fields.map(f => `
              <div class="form-group ${f.fullWidth ? 'grid-span-2' : ''}">
                <label class="form-label">${isAR ? f.labelAr : f.label}</label>
                ${f.type === 'select' ? `
                  <select class="form-control" id="${config.store}-${f.id}">
                    ${f.options.map(o => `<option value="${o.value}">${isAR ? (o.labelAr || o.label) : o.label}</option>`).join('')}
                  </select>` :
          f.type === 'textarea' ? `
                  <textarea class="form-control" id="${config.store}-${f.id}" rows="2"
                    placeholder="${isAR ? (f.placeholderAr || f.placeholder) : f.placeholder}" ${f.dir || ''}></textarea>` :
            `<input type="${f.type || 'text'}" class="form-control" id="${config.store}-${f.id}"
                  placeholder="${isAR ? (f.placeholderAr || f.placeholder) : f.placeholder}" ${f.dir || ''} step="${f.step || ''}">`}
              </div>`).join('')}
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-ghost" onclick="Utils.closeModal('${config.store}-modal')">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button class="btn btn-primary" onclick="${config.store}Module.save()">${isAR ? 'حفظ' : 'Save'}</button>
          </div>
        </div>
      </div>`;

      this.renderTable(this.getFiltered());
    },

    getFiltered(q = '') {
      const query = (q || document.getElementById(`${config.store}-search`)?.value || '').toLowerCase();
      return this._data.filter(r =>
        !query || config.searchKeys.some(k => String(r[k] ?? '').toLowerCase().includes(query))
      );
    },

    renderTable(data) {
      const isAR = i18n.getLang() === 'ar';
      const start = (this._page - 1) * this._perPage;
      const paged = data.slice(start, start + this._perPage);
      const tbody = document.getElementById(`${config.store}-tbody`);
      if (!tbody) return;

      tbody.innerHTML = paged.map(row => `
      <tr>
        ${config.columns.map(col => `<td>${col.render ? col.render(row, isAR) : (Utils.sanitize(String(row[col.key] || '-')))}</td>`).join('')}
        <td>
          <div style="display:flex;gap:4px;flex-wrap:wrap">
            ${config.store === 'customers' ? `
              <button class="btn btn-success btn-sm" onclick="CustomersModule.openPaymentModal('${row.id}')" title="${isAR ? 'قبض دفعة (سداد دين)' : 'Receive Payment'}">
                💵 ${isAR ? 'دفعة' : 'Pay'}
              </button>
              <button class="btn btn-info btn-sm" onclick="CustomersModule.openStatementModal('${row.id}')" title="${isAR ? 'كشف حساب عميل' : 'Statement of Account'}">
                📄 ${isAR ? 'كشف حساب' : 'Statement'}
              </button>
            ` : config.store === 'suppliers' ? `
              <button class="btn btn-warning btn-sm" onclick="SuppliersModule.openPaymentModal('${row.id}')" title="${isAR ? 'دفع للمورد' : 'Pay Supplier'}">
                💵 ${isAR ? 'دفع' : 'Pay'}
              </button>
              <button class="btn btn-info btn-sm" onclick="SuppliersModule.openStatementModal('${row.id}')" title="${isAR ? 'كشف حساب مورد' : 'Supplier Statement'}">
                📄 ${isAR ? 'كشف حساب' : 'Statement'}
              </button>
            ` : ''}
            <button class="btn btn-ghost btn-sm" onclick="${config.store}Module.openForm('${row.id}')" title="${isAR ? 'تعديل' : 'Edit'}">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </button>
            <button class="btn btn-ghost btn-sm" onclick="${config.store}Module.deleteRecord('${row.id}')" style="color:var(--danger)" title="${isAR ? 'حذف' : 'Delete'}">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            </button>
          </div>
        </td>
      </tr>`).join('') || `<tr><td colspan="${config.columns.length + 1}" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد بيانات' : 'No records found'}</td></tr>`;

      // Pagination
      const pages = Math.ceil(data.length / this._perPage);
      const pagEl = document.getElementById(`${config.store}-pag`);
      if (pagEl) {
        if (pages <= 1) { pagEl.innerHTML = ''; return; }
        let html = '';
        if (this._page > 1) html += `<button class="page-btn" onclick="${config.store}Module.goPage(${this._page - 1})">‹</button>`;
        for (let p = 1; p <= pages; p++) html += `<button class="page-btn ${p === this._page ? 'active' : ''}" onclick="${config.store}Module.goPage(${p})">${p}</button>`;
        if (this._page < pages) html += `<button class="page-btn" onclick="${config.store}Module.goPage(${this._page + 1})">›</button>`;
        pagEl.innerHTML = html;
      }
    },

    search(q) { this._page = 1; this.renderTable(this.getFiltered(q)); },
    goPage(p) { this._page = p; this.renderTable(this.getFiltered()); },

    async refresh() {
      this._data = (await DB.getAll(config.store)) || [];
      const searchInput = document.getElementById(`${config.store}-search`);
      if (searchInput && searchInput.value) {
        this.renderTable(this.getFiltered(searchInput.value));
      } else {
        this.renderTable(this.getFiltered());
      }
    },

    async openForm(id = null) {
      const isAR = i18n.getLang() === 'ar';
      if (id !== null && id !== undefined && !isNaN(Number(id)) && String(Number(id)) === String(id).trim()) {
        id = Number(id);
      }
      window[`_edit_${config.store}_id`] = id;
      const singular = isAR ? config.singularAr : config.singularEn;
      document.getElementById(`${config.store}-modal-title`).textContent =
        (id ? (isAR ? 'تعديل' : 'Edit') : (isAR ? 'جديد' : 'New')) + ' ' + singular;

      // Reset
      config.fields.forEach(f => {
        const el = document.getElementById(`${config.store}-${f.id}`);
        if (el) {
          if (f.id === 'opening_balance') {
            el.value = '0';
          } else {
            el.value = f.type === 'select' ? (f.options?.[0]?.value || '') : '';
          }
        }
      });

      if (id) {
        const record = await DB.get(config.store, id);
        if (record) {
          config.fields.forEach(f => {
            const el = document.getElementById(`${config.store}-${f.id}`);
            if (el && record[f.id] !== undefined) el.value = record[f.id];
          });
        }
      }
      Utils.openModal(`${config.store}-modal`);
    },

    async save() {
      const data = {};
      config.fields.forEach(f => {
        const el = document.getElementById(`${config.store}-${f.id}`);
        if (el) data[f.id] = f.type === 'number' ? (parseFloat(el.value) || 0) : el.value;
      });

      let editId = window[`_edit_${config.store}_id`];
      if (editId !== null && editId !== undefined && !isNaN(Number(editId)) && String(Number(editId)) === String(editId).trim()) {
        editId = Number(editId);
      }
      try {
        let savedRecord = null;
        if (editId !== null && editId !== undefined && editId !== '') {
          const oldRecord = await DB.get(config.store, editId);
          const actualId = (oldRecord && oldRecord.id !== undefined) ? oldRecord.id : editId;
          if (config.store === 'customers' || config.store === 'suppliers') {
            const oldOpBal = parseFloat(oldRecord?.opening_balance) || 0;
            const newOpBal = parseFloat(data.opening_balance) || 0;
            data.opening_balance = newOpBal;
            const diff = newOpBal - oldOpBal;
            data.balance = Utils.round((parseFloat(oldRecord?.balance) || 0) + diff);
          }
          savedRecord = { ...oldRecord, ...data, id: actualId };
          await DB.update(config.store, savedRecord);
        } else {
          if (config.store === 'customers' || config.store === 'suppliers') {
            const opBal = parseFloat(data.opening_balance) || 0;
            data.opening_balance = opBal;
            data.balance = opBal;
          }
          const newId = await DB.add(config.store, data);
          savedRecord = { ...data, id: newId };
        }
        Utils.closeModal(`${config.store}-modal`);
        Utils.toast(i18n.t(editId ? 'common.updated' : 'common.saved'), 'success');
        this._data = await DB.getAll(config.store);
        this.renderTable(this.getFiltered());
        if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
          BranchSync.notifyChange(config.store, savedRecord);
        }
      } catch (e) { Utils.toast('Error: ' + e.message, 'error'); }
    },

    async deleteRecord(id) {
      Utils.confirm(i18n.t('common.confirm_delete'), async () => {
        await DB.remove(config.store, id);
        this._data = this._data.filter(r => r.id !== id);
        this.renderTable(this.getFiltered());
        Utils.toast(i18n.t('common.deleted'), 'success');
        if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
          BranchSync.notifyChange(config.store);
        }
      });
    },

    exportData() {
      Utils.exportCSV(this.getFiltered(), config.store);
    }
  };
}

/* ── Customers ─────────────────────────────────────────────────── */
const CustomersModule = buildGenericList({
  store: 'customers', title: 'Customers', titleAr: 'العملاء',
  singularEn: 'Customer', singularAr: 'عميل',
  searchKeys: ['name_en', 'name_ar', 'phone', 'email'],
  columns: [
    { key: 'name_en', label: 'Name', labelAr: 'الاسم', render: (r, ar) => `<div style="font-weight:600">${Utils.truncate(ar ? (r.name_ar || r.name_en) : (r.name_en || r.name_ar), 30)}</div>` },
    { key: 'phone', label: 'Phone', labelAr: 'الهاتف' },
    { key: 'email', label: 'Email', labelAr: 'البريد الإلكتروني' },
    { key: 'category', label: 'Category', labelAr: 'الفئة', render: r => `<span class="badge badge-secondary">${r.category || 'Retail'}</span>` },
    { key: 'points_balance', label: 'Loyalty Points', labelAr: 'نقاط الولاء', render: r => `<span class="badge" style="background:rgba(168,85,247,0.15);color:#a855f7;font-weight:700">⭐ ${(r.points_balance || 0).toLocaleString()} pts</span>` },
    { key: 'credit_limit', label: 'Credit Limit', labelAr: 'حد الائتمان', render: r => Utils.formatMoney(r.credit_limit || 0) },
    { key: 'balance', label: 'Balance', labelAr: 'الرصيد', render: r => `<span style="color:${(r.balance || 0) > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(r.balance || 0)}</span>` },
    { key: 'status', label: 'Status', labelAr: 'الحالة', render: r => `<span class="badge ${r.status === 'active' ? 'badge-success' : 'badge-secondary'}">${r.status || 'active'}</span>` },
  ],
  fields: [
    { id: 'name_ar', label: 'Name (Arabic)', labelAr: 'الاسم (عربي)', placeholder: 'الاسم بالعربي', placeholderAr: 'الاسم بالعربي', dir: 'dir="rtl"' },
    { id: 'name_en', label: 'Name (English)', labelAr: 'الاسم (إنجليزي)', placeholder: 'Name in English' },
    { id: 'phone', label: 'Phone', labelAr: 'الهاتف', placeholder: '+961...' },
    { id: 'email', label: 'Email', labelAr: 'البريد الإلكتروني', placeholder: 'email@domain.com', type: 'email' },
    { id: 'address', label: 'Address', labelAr: 'العنوان', placeholder: 'Address', fullWidth: true },
    { id: 'vat_number', label: 'VAT Number', labelAr: 'الرقم الضريبي', placeholder: 'VAT #' },
    { id: 'opening_balance', label: 'Opening / Old Loan Balance (Debt)', labelAr: 'الرصيد الافتتاحي / دين وقرض سابق', placeholder: '0.00', placeholderAr: '0.00', type: 'number', step: '0.01' },
    { id: 'points_balance', label: 'Points Balance', labelAr: 'رصيد نقاط الولاء', placeholder: '0', type: 'number', step: '1' },
    {
      id: 'category', label: 'Category', labelAr: 'الفئة', type: 'select', options: [
        { value: 'retail', label: 'Retail', labelAr: 'مفرق' },
        { value: 'wholesale', label: 'Wholesale', labelAr: 'جملة' },
        { value: 'vip', label: 'VIP', labelAr: 'VIP' },
      ]
    },
    { id: 'credit_limit', label: 'Credit Limit', labelAr: 'حد الائتمان', placeholder: '0.00', type: 'number', step: '0.01' },
    { id: 'payment_terms', label: 'Payment Terms', labelAr: 'شروط الدفع', placeholder: 'e.g. 30 days' },
    {
      id: 'status', label: 'Status', labelAr: 'الحالة', type: 'select', options: [
        { value: 'active', label: 'Active', labelAr: 'نشط' },
        { value: 'inactive', label: 'Inactive', labelAr: 'غير نشط' },
        { value: 'blocked', label: 'Blocked', labelAr: 'محجوب' },
      ]
    },
    { id: 'notes', label: 'Notes', labelAr: 'ملاحظات', type: 'textarea', placeholder: 'Notes...', fullWidth: true },
  ]
});

/* ── Receive Payment & Statement Methods for Customers ─────────── */
CustomersModule.openPaymentModal = async function (id) {
  const isAR = i18n.getLang() === 'ar';
  const customer = await DB.get('customers', id);
  if (!customer) return;

  const modalId = 'cust-pay-modal';
  let modalEl = document.getElementById(modalId);
  if (modalEl) modalEl.remove();

  const custName = isAR ? (customer.name_ar || customer.name_en) : (customer.name_en || customer.name_ar);
  const bal = customer.balance || 0;

  modalEl = document.createElement('div');
  modalEl.className = 'modal-overlay open';
  modalEl.id = modalId;
  modalEl.innerHTML = `
    <div class="modal" style="max-width:480px">
      <div class="modal-header">
        <div class="modal-title">
          💵 ${isAR ? 'قبض دفعة من عميل (سداد دين)' : 'Receive Customer Payment'}
        </div>
        <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;padding:12px;margin-bottom:16px">
          <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px">${isAR ? 'اسم العميل:' : 'Customer Name:'} <strong style="color:var(--text-primary)">${Utils.sanitize(custName)}</strong></div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:0.82rem;font-weight:600">${isAR ? 'الرصيد المستحق (دين):' : 'Current Debt Balance:'}</span>
            <span style="font-size:1.1rem;font-weight:800;color:${bal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(bal)}</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'المبلغ المدفوع' : 'Payment Amount'}</label>
          <input type="number" class="form-control" id="cust-pay-amount" value="${bal > 0 ? bal : ''}" placeholder="0.00" step="0.01" min="0.01" style="font-size:1.1rem;font-weight:700;color:var(--primary)">
        </div>
        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
            <select class="form-control" id="cust-pay-method">
              <option value="cash">${isAR ? 'نقداً (الصندوق)' : 'Cash'}</option>
              <option value="card">${isAR ? 'بطاقة إئتمان' : 'Card'}</option>
              <option value="bank">${isAR ? 'تحويل بنكي' : 'Bank Transfer'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'التاريخ' : 'Date'}</label>
            <input type="date" class="form-control" id="cust-pay-date" value="${Utils.today()}">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'ملاحظات / البيان' : 'Notes / Description'}</label>
          <input type="text" class="form-control" id="cust-pay-notes" placeholder="${isAR ? 'مثال: سداد دفعة من الدين' : 'e.g. Debt payment'}">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
        <button class="btn btn-primary" onclick="CustomersModule.savePayment(${id})">${isAR ? 'حفظ وخصم الدفعة' : 'Save & Deduct Payment'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(modalEl);
};

CustomersModule.savePayment = async function (id) {
  const isAR = i18n.getLang() === 'ar';
  const customer = await DB.get('customers', id);
  if (!customer) return;

  const amountInput = document.getElementById('cust-pay-amount');
  const paidAmount = parseFloat(amountInput ? amountInput.value : 0) || 0;

  if (paidAmount <= 0) {
    Utils.toast(isAR ? 'يرجى إدخال مبلغ دفع صحيح' : 'Please enter a valid payment amount', 'warning');
    return;
  }

  const method = document.getElementById('cust-pay-method')?.value || 'cash';
  const payDate = document.getElementById('cust-pay-date')?.value || Utils.today();
  const notes = document.getElementById('cust-pay-notes')?.value || (isAR ? 'دفعة حساب عميل' : 'Customer Debt Payment');

  const now = new Date();
  const nowIso = now.toISOString();
  const dateWithTime = (payDate === Utils.today()) ? nowIso : (payDate.length === 10 ? (payDate + 'T' + nowIso.slice(11)) : payDate);

  const oldBalance = customer.balance || 0;
  const newBalance = Utils.round(oldBalance - paidAmount);
  const updatedCustomer = {
    ...customer,
    balance: newBalance,
    updated_at: nowIso
  };

  // Update Customer balance in DB
  await DB.update('customers', updatedCustomer);

  // Record Transaction in DB
  const store = method === 'bank' ? 'bank_transactions' : 'cash_transactions';
  const prefix = method === 'bank' ? 'BNK-' : 'RCPT-';
  const ref = await DB.nextSeq(store, prefix, 5);

  const curBranchId = localStorage.getItem('sync_branch_id') || 'main';
  const curBranchName = (curBranchId === 'main')
    ? 'الفرع الرئيسي (Main Branch)'
    : (localStorage.getItem('sync_node_name') || curBranchId);

  const txnId = await DB.add(store, {
    ref,
    type: 'receipt',
    date: dateWithTime,
    created_at: nowIso,
    amount: paidAmount,
    customer_id: id,
    customer_name: customer.name_en || customer.name_ar,
    description: notes,
    payment_method: method,
    branch_id: curBranchId,
    branch_name: curBranchName,
    syncBranchId: curBranchId
  });

  Utils.closeModal('cust-pay-modal');
  Utils.toast(isAR ? `تم خصم الدفعة بنجاح! الرصيد الجديد: ${Utils.formatMoney(newBalance)}` : `Payment deducted! New Balance: ${Utils.formatMoney(newBalance)}`, 'success');

  // Refresh Customer list
  CustomersModule._data = await DB.getAll('customers');
  CustomersModule.renderTable(CustomersModule.getFiltered());

  // Propagate updated customer balance to server, cloud & branches
  if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
    BranchSync.notifyChange('customers', updatedCustomer);
    if (typeof BranchSync.syncNow === 'function') {
      BranchSync.syncNow(true).catch(() => { });
    }
  }
  window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'customers', updatedId: id } }));

  // Confirm Print Receipt
  Utils.confirm(
    isAR ? 'تم خصم المبلغ من دين العميل. هل ترغب في طباعة سند القبض الآن؟' : 'Payment deducted from debt. Would you like to print the receipt now?',
    () => CustomersModule.printPaymentReceipt(txnId, customer, paidAmount, ref, payDate, method, notes, newBalance)
  );
};

CustomersModule.deletePaymentTxn = async function (txnStore, txnId, custId) {
  const isAR = i18n.getLang() === 'ar';
  Utils.confirm(
    isAR ? 'هل أنت متأكد من إمكانية إلغاء وحذف هذه الدفعة وإعادة المبلغ لدين العميل؟' : 'Are you sure you want to delete this payment and restore it to the customer debt balance?',
    async () => {
      const txn = await DB.get(txnStore, txnId);
      if (txn) {
        const txnRef = txn.ref;
        if (txnRef) {
          let deletedRefs = [];
          try { deletedRefs = JSON.parse(localStorage.getItem('rs_deleted_txn_refs') || '[]'); } catch (e) { }
          if (!deletedRefs.includes(txnRef)) {
            deletedRefs.push(txnRef);
            localStorage.setItem('rs_deleted_txn_refs', JSON.stringify(deletedRefs.slice(-500)));
          }
        }

        const paidAmt = parseFloat(txn.amount) || 0;
        const cust = await DB.get('customers', custId);
        if (cust) {
          const nowIso = new Date().toISOString();
          const newBal = Utils.round((cust.balance || 0) + paidAmt);
          const updatedCust = { ...cust, balance: newBal, updated_at: nowIso };
          await DB.update('customers', updatedCust);
          if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
            BranchSync.notifyChange('customers', updatedCust);
            if (typeof BranchSync.syncNow === 'function') {
              BranchSync.syncNow(true).catch(() => { });
            }
          }
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'customers', updatedId: custId } }));
        }
        await DB.remove(txnStore, txnId);
        Utils.toast(isAR ? 'تم حذف الدفعة وإعادة المبلغ لدين العميل' : 'Payment deleted and restored to customer balance', 'info');

        // Refresh Customers list
        CustomersModule._data = await DB.getAll('customers');
        CustomersModule.renderTable(CustomersModule.getFiltered());

        // Re-open statement modal
        CustomersModule.openStatementModal(custId);
      }
    }
  );
};

CustomersModule.openEditPaymentModal = async function (txnStore, txnId, custId) {
  const isAR = i18n.getLang() === 'ar';
  const txn = await DB.get(txnStore, txnId);
  const cust = await DB.get('customers', custId);
  if (!txn || !cust) return;

  const modalId = 'cust-edit-pay-modal';
  let modalEl = document.getElementById(modalId);
  if (modalEl) modalEl.remove();

  const custName = isAR ? (cust.name_ar || cust.name_en) : (cust.name_en || cust.name_ar);

  modalEl = document.createElement('div');
  modalEl.className = 'modal-overlay open';
  modalEl.id = modalId;
  modalEl.innerHTML = `
    <div class="modal" style="max-width:480px">
      <div class="modal-header">
        <div class="modal-title">
          ✏️ ${isAR ? 'تعديل دفعة مقبوضة: ' + txn.ref : 'Edit Payment: ' + txn.ref}
        </div>
        <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--surface-2);border-radius:8px;padding:10px;margin-bottom:14px;font-size:0.82rem">
          <div>${isAR ? 'العميل:' : 'Customer:'} <strong>${Utils.sanitize(custName)}</strong></div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'المبلغ المدفوع المعدل' : 'Edit Payment Amount'}</label>
          <input type="number" class="form-control" id="edit-pay-amount" value="${txn.amount || ''}" placeholder="0.00" step="0.01" min="0.01" style="font-size:1.1rem;font-weight:700;color:var(--primary)">
        </div>
        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
            <select class="form-control" id="edit-pay-method">
              <option value="cash" ${txn.payment_method === 'cash' ? 'selected' : ''}>${isAR ? 'نقداً (الصندوق)' : 'Cash'}</option>
              <option value="card" ${txn.payment_method === 'card' ? 'selected' : ''}>${isAR ? 'بطاقة إئتمان' : 'Card'}</option>
              <option value="bank" ${txn.payment_method === 'bank' ? 'selected' : ''}>${isAR ? 'تحويل بنكي' : 'Bank Transfer'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'التاريخ' : 'Date'}</label>
            <input type="date" class="form-control" id="edit-pay-date" value="${txn.date || Utils.today()}">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'ملاحظات / البيان' : 'Notes / Description'}</label>
          <input type="text" class="form-control" id="edit-pay-notes" value="${Utils.sanitize(txn.description || '')}">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
        <button class="btn btn-primary" onclick="CustomersModule.saveEditPayment('${txnStore}', ${txnId}, ${custId})">${isAR ? 'حفظ التعديل' : 'Save Changes'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(modalEl);
};

CustomersModule.saveEditPayment = async function (txnStore, txnId, custId) {
  const isAR = i18n.getLang() === 'ar';
  const txn = await DB.get(txnStore, txnId);
  const cust = await DB.get('customers', custId);
  if (!txn || !cust) return;

  const newAmount = parseFloat(document.getElementById('edit-pay-amount')?.value || 0) || 0;
  if (newAmount <= 0) {
    Utils.toast(isAR ? 'يرجى إدخال مبلغ صحيح' : 'Please enter a valid amount', 'warning');
    return;
  }

  const oldAmount = parseFloat(txn.amount) || 0;
  const diff = newAmount - oldAmount;

  // Re-adjust customer balance with fresh timestamp
  const nowIso = new Date().toISOString();
  const newBalance = Utils.round((cust.balance || 0) - diff);
  const updatedCust = { ...cust, balance: newBalance, updated_at: nowIso };
  await DB.update('customers', updatedCust);

  // Update payment transaction
  const method = document.getElementById('edit-pay-method')?.value || txn.payment_method || 'cash';
  const payDate = document.getElementById('edit-pay-date')?.value || txn.date;
  const notes = document.getElementById('edit-pay-notes')?.value || txn.description;

  await DB.update(txnStore, {
    ...txn,
    amount: newAmount,
    payment_method: method,
    date: payDate,
    description: notes
  });

  if (window.BranchSync && typeof BranchSync.notifyChange === 'function') {
    BranchSync.notifyChange('customers', updatedCust);
    if (typeof BranchSync.syncNow === 'function') {
      BranchSync.syncNow(true).catch(() => { });
    }
  }
  window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'customers', updatedId: custId } }));

  Utils.closeModal('cust-edit-pay-modal');
  Utils.toast(isAR ? 'تم تعديل الدفعة وتعديل رصيد العميل بنجاح' : 'Payment updated and customer balance re-adjusted successfully', 'success');

  // Refresh Customer table & Statement modal
  CustomersModule._data = await DB.getAll('customers');
  CustomersModule.renderTable(CustomersModule.getFiltered());
  CustomersModule.openStatementModal(custId);
};

CustomersModule.printPaymentReceipt = async function (txnId, customer, paidAmount, ref, payDate, method, notes, newBalance) {
  const isAR = i18n.getLang() === 'ar';
  const custName = isAR ? (customer.name_ar || customer.name_en) : (customer.name_en || customer.name_ar);
  const company = await DB.getSetting('company_name', 'Store');
  const companyAr = await DB.getSetting('company_name_ar', '');
  const compPhone = await DB.getSetting('company_phone', '');
  const logo = await DB.getSetting('company_logo', '');
  const printLogo = await DB.getSetting('print_logo', true);

  const html = `
    <div style="font-family:'Cairo', 'Inter', sans-serif; padding: 24px; max-width: 520px; margin: auto; border: 1px solid #cbd5e1; border-radius: 10px; background:#fff" dir="${isAR ? 'rtl' : 'ltr'}">
      <div style="text-align: center; border-bottom: 2px dashed #0f172a; padding-bottom: 12px; margin-bottom: 14px;">
        ${(printLogo && logo) ? `<div style="margin-bottom:6px"><img src="${logo}" style="max-width:70px;max-height:70px;object-fit:contain"></div>` : ''}
        <h2 style="margin:0; font-size: 1.4rem; color:#0f172a">${isAR ? (companyAr || company) : (company || companyAr)}</h2>
        <p style="margin:4px 0 0; font-size: 0.85rem; color: #475569;">${isAR ? 'إيصال استلام دفعة (سند قبض)' : 'Official Payment Receipt'}</p>
        ${compPhone ? `<p style="margin:2px 0 0; font-size: 0.8rem; color: #64748b;">📞 ${compPhone}</p>` : ''}
      </div>

      <div style="margin-bottom: 14px; font-size: 0.88rem; line-height: 1.7; color:#1e293b">
        <div style="display: flex; justify-content: space-between;">
          <span><strong>${isAR ? 'رقم السند:' : 'Receipt Ref:'}</strong> ${ref}</span>
          <span><strong>${isAR ? 'التاريخ:' : 'Date:'}</strong> ${Utils.formatDate(payDate)}</span>
        </div>
        <div><strong>${isAR ? 'وصلنا من السيد/السادة:' : 'Received From:'}</strong> ${Utils.sanitize(custName)}</div>
        <div><strong>${isAR ? 'طريقة الدفع:' : 'Payment Method:'}</strong> ${method.toUpperCase()}</div>
      </div>

      <div style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 8px; padding: 14px; text-align: center; margin-bottom: 16px;">
        <div style="font-size: 0.8rem; color: #64748b;">${isAR ? 'المبلغ المستلم المقبوض' : 'Amount Paid Received'}</div>
        <div style="font-size: 1.8rem; font-weight: 900; color: #059669;">${Utils.formatMoney(paidAmount)}</div>
      </div>

      <div style="margin-bottom: 18px; font-size: 0.85rem; line-height: 1.6; color: #334155;">
        <div><strong>${isAR ? 'وذلك لقاء / البيان:' : 'Payment Description:'}</strong> ${Utils.sanitize(notes || '-')}</div>
        <div style="margin-top: 4px;"><strong>${isAR ? 'الرصيد المتبقي على العميل:' : 'Remaining Customer Debt:'}</strong> <span style="font-weight: 800; color: #dc2626;">${Utils.formatMoney(newBalance)}</span></div>
      </div>

      <div style="display: flex; justify-content: space-between; margin-top: 36px; padding-top: 12px; border-top: 1px solid #e2e8f0; font-size: 0.82rem; color:#475569">
        <div style="text-align: center;"><p style="margin-bottom: 30px;">${isAR ? 'توقيع المستلم' : 'Received By'}</p><p>___________________</p></div>
        <div style="text-align: center;"><p style="margin-bottom: 30px;">${isAR ? 'توقيع العميل' : 'Customer Signature'}</p><p>___________________</p></div>
      </div>
    </div>
  `;
  Utils.printElement(html, `Receipt-${ref}`);
};

CustomersModule.buildCustomerLedger = async function (id, isAR, requestedBranch, statementFilter = 'debt_only') {
  let customerRecord = await DB.get('customers', id);
  if (!customerRecord && typeof id === 'string' && /^\d+$/.test(id)) {
    customerRecord = await DB.get('customers', parseInt(id, 10));
  }
  if (!customerRecord && typeof id === 'number') {
    customerRecord = await DB.get('customers', String(id));
  }
  const matchIdStr = String(id);
  let rawPosSales = (await DB.getAll('sales', s => String(s.customer_id) === matchIdStr)) || [];
  let rawInvoices = (await DB.getAll('sales_invoice', i => String(i.customer_id) === matchIdStr)) || [];
  let rawCashTxns = (await DB.getAll('cash_transactions', t => String(t.customer_id) === matchIdStr && (t.type === 'receipt' || t.type === 'income'))) || [];
  let bankTxns = (await DB.getAll('bank_transactions', t => String(t.customer_id) === matchIdStr && (t.type === 'receipt' || t.type === 'income'))) || [];

  // Helper to extract clean normalized transaction reference (stripping prefixes for cross-table matching)
  const normRef = (t) => {
    let r = String(t.ref || t.receipt_no || t.invoice_no || ('ID_' + t.id)).trim().toUpperCase();
    return r.replace(/^(REDSHARKPOS-|POS-|INV-)+/g, '');
  };

  // Cross-Table Deduplication: ensure sales and sales_invoice share the same map to prevent duplicate rows
  const allSalesMap = new Map();
  let posSales = [];
  let invoices = [];

  rawPosSales.forEach(s => {
    const r = normRef(s);
    if (!allSalesMap.has(r)) {
      allSalesMap.set(r, s);
      posSales.push(s);
    }
  });

  rawInvoices.forEach(i => {
    const r = normRef(i);
    if (!allSalesMap.has(r)) {
      allSalesMap.set(r, i);
      invoices.push(i);
    }
  });

  const cashMap = new Map();
  let cashTxns = [];
  rawCashTxns.forEach(t => {
    const r = normRef(t);
    if (!cashMap.has(r)) {
      cashMap.set(r, t);
      cashTxns.push(t);
    }
  });

  // Determine Branch Scope
  let syncCfg = { role: 'server', branchId: 'main' };
  try {
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      syncCfg = await BranchSync.getConfig();
    }
  } catch (e) { }
  const isServerNode = syncCfg.role === 'server';
  const myBranch = (syncCfg.branchId || 'main').toLowerCase();
  const branchFilter = (requestedBranch || 'all').toLowerCase();

  // Cross-Branch Live Sync: Fetch transactions from server if connected with branch validation
  try {
    const baseUrl = (window.BranchSync && typeof BranchSync.getServerBaseUrl === 'function')
      ? BranchSync.getServerBaseUrl(syncCfg)
      : (window.location.origin.startsWith('http') ? window.location.origin : 'http://127.0.0.1:3000');

    const queryParams = new URLSearchParams({ customerId: id });
    if (branchFilter && branchFilter !== 'all') {
      queryParams.set('branchId', branchFilter);
    }

    const trRes = await fetch(`${baseUrl}/api/sync/transactions?${queryParams.toString()}`, {
      headers: {
        'x-sync-branch-id': syncCfg.branchId || 'main',
        'x-sync-role': syncCfg.role || 'server',
        'x-sync-node-id': syncCfg.nodeId || 'MAIN'
      },
      signal: (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function') ? AbortSignal.timeout(1800) : undefined
    });
    if (trRes.ok) {
      const trData = await trRes.json();
      if (trData.success && Array.isArray(trData.sales)) {
        for (const s of trData.sales) {
          const r = normRef(s);
          if (!allSalesMap.has(r)) {
            allSalesMap.set(r, s);
            if (s.store === 'sales_invoice') {
              invoices.push(s);
            } else {
              posSales.push(s);
            }
          }
        }
      }
      if (trData.success && Array.isArray(trData.cashTransactions)) {
        for (const ct of trData.cashTransactions) {
          const r = normRef(ct);
          if (!cashMap.has(r)) {
            cashMap.set(r, ct);
            cashTxns.push(ct);
          }
        }
      }
    }
  } catch (e) { }

  // Robust branch matching
  const fLow = String(branchFilter || 'all').trim().toLowerCase();
  function matchesBranch(t) {
    if (!branchFilter || fLow === 'all') return true;
    const bId = String(t.branch_id || t.syncBranchId || t.terminal_id || t.syncNodeId || '').trim().toLowerCase();
    const bName = String(t.branch_name || t.branch_title || t.syncBranchName || '').trim().toLowerCase();
    if (fLow === 'main') {
      return !bId || bId === 'main' || bName.includes('main') || bName.includes('رئيسي') || bId === 'srv-01';
    }
    return bId === fLow || bName === fLow || bName.includes(fLow) || fLow.includes(bId) || (bId && fLow.includes(bId));
  }

  posSales = posSales.filter(matchesBranch);
  invoices = invoices.filter(matchesBranch);
  cashTxns = cashTxns.filter(matchesBranch);
  bankTxns = bankTxns.filter(matchesBranch);

  const ledger = [];

  // Helper to format clean branch name
  const resolveBranch = (item) => {
    return item.branch_name || item.branch_title || item.syncBranchName || (
      (item.branch_id === 'main' || !item.branch_id)
        ? (isAR ? 'الفرع الرئيسي (Main)' : 'Main Branch')
        : item.branch_id
    );
  };

  // 0. Process Opening Balance (if any)
  const custOpBal = parseFloat(customerRecord?.opening_balance) || 0;
  if (custOpBal !== 0) {
    ledger.push({
      id: 'op-bal',
      store: 'opening',
      date: (customerRecord?.created_at || '1970-01-01').slice(0, 10),
      created_at: customerRecord?.created_at || '1970-01-01',
      ref: isAR ? 'رصيد افتتاحي' : 'OP-BAL',
      type: isAR ? 'رصيد افتتاحي / دين وقرض سابق' : 'Opening Balance / Old Loan (Migrated)',
      debit: custOpBal > 0 ? custOpBal : 0,
      credit: custOpBal < 0 ? -custOpBal : 0,
      isPayment: false,
      priority: 0,
      branch: isAR ? 'الفرع الرئيسي (Main)' : 'Main Branch',
      branch_id: 'main'
    });
  }

  // 1. Process POS Sales
  posSales.forEach(s => {
    const gTot = parseFloat(s.grand_total) || 0;
    const isCredit = s.payment_method === 'credit';
    const paidAmt = parseFloat(s.paid_amount !== undefined ? s.paid_amount : (isCredit ? 0 : gTot)) || 0;
    const isFullyPaidCash = !isCredit && (paidAmt >= gTot - 0.001);

    // If filter is debt_only, skip 100% paid cash/card transactions (0 debt effect)
    if (statementFilter === 'debt_only' && isFullyPaidCash) {
      return;
    }

    const sDate = s.created_at || s.doc_date || s.date;
    const bName = resolveBranch(s);

    ledger.push({
      id: s.id,
      store: 'sales',
      date: sDate,
      created_at: s.created_at || sDate,
      ref: s.receipt_no || s.ref || `POS-${s.id}`,
      type: isAR ? (isCredit ? 'مبيعات نقاط البيع (آجل)' : 'مبيعات نقاط البيع (نقدي)') : (isCredit ? 'POS Sale (On Account)' : 'POS Sale (Cash)'),
      debit: gTot,
      credit: 0,
      isPayment: false,
      priority: 1,
      branch: bName,
      branch_id: s.branch_id || s.syncBranchId || 'main'
    });

    const hasLinkedTxn = cashTxns.some(t => t.sale_id === s.id || (t.sale_ref && t.sale_ref === s.ref) || (t.ref && t.ref === s.ref))
      || bankTxns.some(t => t.sale_id === s.id || (t.sale_ref && t.sale_ref === s.ref) || (t.ref && t.ref === s.ref));

    if (!hasLinkedTxn && paidAmt > 0) {
      let payType = isAR ? 'سداد فوري للمبيعات' : 'Immediate Sale Payment';
      if (s.payment_method === 'cash') payType = isAR ? 'سداد نقدي فوري للفاتورة' : 'Immediate Cash Payment';
      else if (s.payment_method === 'card') payType = isAR ? 'سداد فوري بالبطاقة' : 'Immediate Card Payment';
      else if (s.payment_method === 'mixed') payType = isAR ? 'سداد فوري (نقداً + بطاقة)' : 'Immediate Split Payment';
      else if (isCredit) payType = isAR ? 'دفعة مسددة على الفاتورة (نقداً)' : 'Down Payment on Invoice (Cash)';

      ledger.push({
        id: s.id,
        store: 'sales',
        date: sDate,
        created_at: s.created_at || sDate,
        ref: s.receipt_no || s.ref || `POS-${s.id}`,
        type: payType,
        debit: 0,
        credit: paidAmt,
        isPayment: true,
        priority: 2,
        linkedRef: s.ref || `POS-${s.id}`,
        branch: bName,
        branch_id: s.branch_id || s.syncBranchId || 'main'
      });
    }
  });

  // 2. Process Backoffice Invoices
  invoices.forEach(i => {
    const gTot = parseFloat(i.grand_total) || 0;
    const isCredit = i.payment_method === 'credit';
    const paidAmt = parseFloat(i.paid_amount !== undefined ? i.paid_amount : (i.status === 'paid' ? gTot : 0)) || 0;
    const isFullyPaidCash = !isCredit && (paidAmt >= gTot - 0.001);

    if (statementFilter === 'debt_only' && isFullyPaidCash) {
      return;
    }

    const iDate = i.created_at || i.doc_date || i.date;
    const bName = resolveBranch(i);

    ledger.push({
      id: i.id,
      store: 'sales_invoice',
      date: iDate,
      created_at: i.created_at || iDate,
      ref: i.ref || `INV-${i.id}`,
      type: isAR ? (isCredit ? 'فاتورة مبيعات (آجل)' : 'فاتورة مبيعات (نقدي)') : (isCredit ? 'Sales Invoice (Credit)' : 'Sales Invoice (Cash)'),
      debit: gTot,
      credit: 0,
      isPayment: false,
      priority: 1,
      branch: bName,
      branch_id: i.branch_id || i.syncBranchId || 'main'
    });

    const hasLinkedTxn = cashTxns.some(t => t.invoice_id === i.id || (t.invoice_ref && t.invoice_ref === i.ref) || (t.ref && t.ref === i.ref))
      || bankTxns.some(t => t.invoice_id === i.id || (t.invoice_ref && t.invoice_ref === i.ref) || (t.ref && t.ref === i.ref));

    if (!hasLinkedTxn && paidAmt > 0) {
      let payType = isAR ? 'سداد فوري للفاتورة' : 'Invoice Payment';
      if (i.payment_method === 'cash') payType = isAR ? 'سداد نقدي فوري للفاتورة' : 'Immediate Cash Payment';
      else if (i.payment_method === 'card') payType = isAR ? 'سداد فوري بالبطاقة' : 'Immediate Card Payment';
      else if (isCredit) payType = isAR ? 'دفعة مسددة على الفاتورة' : 'Invoice Down Payment';

      ledger.push({
        id: i.id,
        store: 'sales_invoice',
        date: iDate,
        created_at: i.created_at || iDate,
        ref: i.ref || `INV-${i.id}`,
        type: payType,
        debit: 0,
        credit: paidAmt,
        isPayment: true,
        priority: 2,
        linkedRef: i.ref || `INV-${i.id}`,
        branch: bName,
        branch_id: i.branch_id || i.syncBranchId || 'main'
      });
    }
  });

  // 3. Process Cash & Bank Receipts
  cashTxns.forEach(t => {
    let effectiveDate = t.date || t.created_at;
    if (t.created_at && String(t.date || '').length === 10 && t.created_at.startsWith(t.date)) {
      effectiveDate = t.created_at;
    }
    const bName = resolveBranch(t);

    ledger.push({
      id: t.id,
      store: 'cash_transactions',
      date: effectiveDate,
      created_at: t.created_at || effectiveDate,
      ref: t.ref || `RCPT-${t.id}`,
      type: isAR ? (t.description || 'إيصال قبض دفعة (صندوق)') : (t.description || 'Payment Receipt'),
      debit: 0,
      credit: parseFloat(t.amount) || 0,
      isPayment: true,
      priority: 2,
      linkedRef: t.sale_ref || t.invoice_ref || '',
      branch: bName,
      branch_id: t.branch_id || t.syncBranchId || 'main'
    });
  });

  bankTxns.forEach(t => {
    let effectiveDate = t.date || t.created_at;
    if (t.created_at && String(t.date || '').length === 10 && t.created_at.startsWith(t.date)) {
      effectiveDate = t.created_at;
    }
    const bName = resolveBranch(t);

    ledger.push({
      id: t.id,
      store: 'bank_transactions',
      date: effectiveDate,
      created_at: t.created_at || effectiveDate,
      ref: t.ref || `BNK-${t.id}`,
      type: isAR ? (t.description || 'تحويل بنكي قبض') : (t.description || 'Bank Payment Receipt'),
      debit: 0,
      credit: parseFloat(t.amount) || 0,
      isPayment: true,
      priority: 2,
      linkedRef: t.sale_ref || t.invoice_ref || '',
      branch: bName,
      branch_id: t.branch_id || t.syncBranchId || 'main'
    });
  });

  // Accurate Chronological Sorting
  ledger.sort((a, b) => {
    const dayA = String(a.date || a.created_at || '').slice(0, 10);
    const dayB = String(b.date || b.created_at || '').slice(0, 10);

    if (dayA !== dayB) {
      return dayA.localeCompare(dayB);
    }
    if (b.linkedRef && (b.linkedRef === a.ref || (b.type && b.type.includes(a.ref)))) {
      return -1;
    }
    if (a.linkedRef && (a.linkedRef === b.ref || (a.type && a.type.includes(b.ref)))) {
      return 1;
    }

    const timeA = new Date(a.created_at || a.date || 0).getTime();
    const timeB = new Date(b.created_at || b.date || 0).getTime();
    if (Math.abs(timeA - timeB) > 1000) {
      return timeA - timeB;
    }

    if ((a.priority || 0) !== (b.priority || 0)) {
      return (a.priority || 0) - (b.priority || 0);
    }

    return (a.id || 0) - (b.id || 0);
  });

  let runningBal = 0;
  ledger.forEach(item => {
    runningBal += (item.debit - item.credit);
    item.balance = Utils.round(runningBal);
  });

  const totalDebit = Utils.round(ledger.reduce((s, i) => s + i.debit, 0));
  const totalCredit = Utils.round(ledger.reduce((s, i) => s + i.credit, 0));
  runningBal = Utils.round(runningBal);

  // Statement ledger calculation complete
  return { ledger, totalDebit, totalCredit, runningBal };
};

CustomersModule.openStatementModal = async function (id, requestedBranch, statementFilter = 'debt_only') {
  try {
    const isAR = i18n.getLang() === 'ar';
    let cust = await DB.get('customers', id);
    if (!cust && typeof id === 'string' && /^\d+$/.test(id)) {
      cust = await DB.get('customers', parseInt(id, 10));
    }
    if (!cust && typeof id === 'number') {
      cust = await DB.get('customers', String(id));
    }
    if (!cust) {
      const allCusts = (await DB.getAll('customers')) || [];
      cust = allCusts.find(c => String(c.id) === String(id));
    }
    if (!cust) {
      console.warn('[Statement] Customer not found for id:', id);
      Utils.toast(isAR ? 'لم يتم العثور على بيانات العميل!' : 'Customer record not found!', 'error');
      return;
    }

    const modalId = 'cust-stmt-modal';
    let modalEl = document.getElementById(modalId);
    if (modalEl) modalEl.remove();

    const custName = isAR ? (cust.name_ar || cust.name_en) : (cust.name_en || cust.name_ar);

    let syncCfg = { role: 'server', branchId: 'main' };
    try {
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        syncCfg = await BranchSync.getConfig();
      }
    } catch (e) { }
    const isServerNode = syncCfg.role === 'server';
    const myBranch = syncCfg.branchId || 'main';
    const branchFilter = isServerNode ? (requestedBranch || 'all') : myBranch;

    let availableBranches = [];
    if (isServerNode) {
      try {
        if (window.Reports && typeof Reports.getAvailableBranches === 'function') {
          availableBranches = await Reports.getAvailableBranches();
        } else {
          const whs = (await DB.getAll('warehouses')) || [];
          availableBranches = whs.filter(w => w.id !== 1 && (w.code || '').toUpperCase() !== 'WH-01' && !w.is_default).map(w => ({
            id: w.code || w.name,
            label: w.name || w.name_ar || w.code
          }));
        }
      } catch (e) { }
    }

    const { ledger, totalDebit, totalCredit, runningBal } = await CustomersModule.buildCustomerLedger(cust.id ?? id, isAR, branchFilter, statementFilter);

    // Sync customer balance if deviated and viewing consolidated
    if (branchFilter === 'all' && Math.abs((cust.balance || 0) - runningBal) > 0.009) {
      cust.balance = Utils.round(runningBal);
      await DB.update('customers', { ...cust, balance: cust.balance });
    }

    modalEl = document.createElement('div');
    modalEl.className = 'modal-overlay open';
    modalEl.id = modalId;
    modalEl.addEventListener('click', (e) => {
      if (e.target === modalEl) Utils.closeModal(modalId);
    });
    modalEl.innerHTML = `
    <div class="modal" style="max-width:960px">
      <div class="modal-header">
        <div class="modal-title">
          📄 ${isAR ? 'كشف حساب عميل مفصل: ' : 'Customer Statement of Account: '} ${Utils.sanitize(custName)}
        </div>
        <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
      </div>
      <div class="modal-body">

        <!-- Branch Scope & Filter Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;background:var(--surface-2);border-radius:8px;padding:8px 14px;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:0.85rem;font-weight:700">🏢 ${isAR ? 'نطاق الفرع:' : 'Branch Scope:'}</span>
            ${isServerNode ? `
              <select class="form-control" style="height:32px;min-width:240px;font-size:0.82rem;font-weight:700" onchange="CustomersModule.openStatementModal('${cust.id ?? id}', this.value, '${statementFilter}')">
                <option value="all" ${branchFilter === 'all' ? 'selected' : ''}>🌐 ${isAR ? 'كافة الفروع (كشف موحد)' : 'All Branches (Consolidated)'}</option>
                <option value="main" ${branchFilter === 'main' ? 'selected' : ''}>🖥️ ${isAR ? 'الفرع الرئيسي' : 'Main Branch'}</option>
                ${availableBranches.map(b => `<option value="${b.id}" ${branchFilter.toLowerCase() === b.id.toLowerCase() ? 'selected' : ''}>🏬 ${b.label}</option>`).join('')}
              </select>
            ` : `
              <span class="badge badge-primary" style="font-size:0.8rem;padding:4px 10px">🔒 ${myBranch} (${isAR ? 'مقيد بالفرع' : 'Branch Restricted'})</span>
            `}
          </div>

          <!-- Debt Only vs All Filter -->
          <div class="btn-group" style="display:inline-flex;border-radius:8px;overflow:hidden;border:1px solid var(--border-color)">
            <button class="btn btn-xs ${statementFilter === 'debt_only' ? 'btn-primary' : 'btn-ghost'}" onclick="CustomersModule.openStatementModal('${cust.id ?? id}', '${branchFilter}', 'debt_only')" style="font-weight:700;padding:4px 8px">
              📋 ${isAR ? 'فواتير الآجل والذمم فقط (الديون)' : 'Credit & Debt Only'}
            </button>
            <button class="btn btn-xs ${statementFilter === 'all' ? 'btn-primary' : 'btn-ghost'}" onclick="CustomersModule.openStatementModal('${cust.id ?? id}', '${branchFilter}', 'all')" style="font-weight:700;padding:4px 8px">
              🌐 ${isAR ? 'شامل النقدي' : 'Show All (Inc. Cash)'}
            </button>
          </div>
        </div>

        <!-- Summary Header -->
        <div class="grid grid-3" style="gap:12px;margin-bottom:16px">
          <div style="background:var(--surface-2);border-radius:8px;padding:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'العميل' : 'Customer'}</div>
            <div style="font-weight:700;font-size:0.95rem;margin-top:2px">${Utils.sanitize(custName)}</div>
            <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px">📞 ${cust.phone || '-'}</div>
          </div>
          <div style="background:var(--surface-2);border-radius:8px;padding:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'حد الائتمان' : 'Credit Limit'}</div>
            <div style="font-weight:700;font-size:0.95rem;margin-top:2px;color:var(--info)">${Utils.formatMoney(cust.credit_limit || 0)}</div>
          </div>
          <div style="background:var(--surface-2);border-radius:8px;padding:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${branchFilter === 'all' ? (isAR ? 'الرصيد المتبقي الإجمالي (كافة الفروع)' : 'Net Balance Due (All Branches)') : `${isAR ? 'الرصيد المتبقي لفرع' : 'Net Balance for'} ${branchFilter}`}</div>
            <div style="font-weight:900;font-size:1.1rem;margin-top:2px;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</div>
          </div>
        </div>

        <div class="table-wrapper" style="max-height:420px;overflow-y:auto">
          <table style="font-size:0.82rem">
            <thead><tr>
              <th>${isAR ? 'التاريخ' : 'Date'}</th>
              <th style="text-align:center">${isAR ? 'الفرع' : 'Branch'}</th>
              <th>${isAR ? 'الرقم' : 'Ref #'}</th>
              <th>${isAR ? 'النوع / البيان' : 'Type / Ref'}</th>
              <th style="text-align:right">${isAR ? 'مدين (مبيعات)' : 'Debit'}</th>
              <th style="text-align:right">${isAR ? 'دائن (مدفوعات)' : 'Credit'}</th>
              <th style="text-align:right">${isAR ? 'الرصيد' : 'Balance'}</th>
              <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
            </tr></thead>
            <tbody>
              ${ledger.map(l => `
              <tr>
                <td style="font-size:0.78rem">${Utils.formatDate(l.date)}</td>
                <td style="text-align:center"><span class="badge ${l.branch_id === 'main' || !l.branch_id ? 'badge-primary' : 'badge-info'}" style="font-size:0.74rem;padding:2px 7px;white-space:nowrap">${Utils.sanitize(l.branch || '-')}</span></td>
                <td style="font-weight:700;color:var(--primary)">${l.ref}</td>
                <td>${l.type}</td>
                <td style="text-align:right;font-weight:600;color:${l.debit > 0 ? 'var(--danger)' : 'inherit'}">${l.debit > 0 ? Utils.formatMoney(l.debit) : '-'}</td>
                <td style="text-align:right;font-weight:600;color:${l.credit > 0 ? 'var(--success)' : 'inherit'}">${l.credit > 0 ? Utils.formatMoney(l.credit) : '-'}</td>
                <td style="text-align:right;font-weight:800">${Utils.formatMoney(l.balance)}</td>
                <td>
                  <div style="display:flex;gap:4px;justify-content:center">
                    ${l.isPayment ? `
                      <button class="btn btn-ghost btn-sm" onclick="CustomersModule.openEditPaymentModal('${l.store}', ${l.id}, ${cust.id})" title="${isAR ? 'تعديل الدفعة' : 'Edit Payment'}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                      <button class="btn btn-ghost btn-sm" onclick="CustomersModule.deletePaymentTxn('${l.store}', ${l.id}, ${cust.id})" style="color:var(--danger)" title="${isAR ? 'إلغاء وحذف الدفعة' : 'Delete Payment'}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                      </button>
                    ` : `
                      <button class="btn btn-ghost btn-sm" onclick="SalesModule.openSalesDoc('${l.store}', ${l.id})" title="${isAR ? 'عرض/تعديل الوثيقة' : 'View Doc'}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                    `}
                  </div>
                </td>
              </tr>`).join('') || `<tr><td colspan="8" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد حركات لـ هذا العميل' : 'No transactions recorded for this customer'}</td></tr>`}
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:800">
                <td colspan="4" style="padding:10px">${isAR ? 'الإجمالي الصافي' : 'Total'}</td>
                <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(totalDebit)}</td>
                <td style="text-align:right;color:var(--success)">${Utils.formatMoney(totalCredit)}</td>
                <td style="text-align:right;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <div class="modal-footer" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px">
        <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إغلاق' : 'Close'}</button>
        <div style="display:flex;gap:8px">
          <button class="btn btn-secondary" onclick="CustomersModule.printStatement(${id}, '80mm', '${statementFilter}', '${branchFilter}')">
            🧾 ${isAR ? 'طباعة إيصال (80mm)' : 'Thermal (80mm)'}
          </button>
          <button class="btn btn-primary" onclick="CustomersModule.printStatement(${id}, 'A4', '${statementFilter}', '${branchFilter}')">
            📄 ${isAR ? 'طباعة كشف A4' : 'A4 Statement'}
          </button>
        </div>
      </div>
    </div>
  `;
    document.body.appendChild(modalEl);
  } catch (err) {
    console.error('[Statement] Error opening customer statement modal:', err);
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    Utils.toast(isAR ? 'حدث خطأ أثناء فتح كشف الحساب: ' + err.message : 'Error opening statement: ' + err.message, 'error');
  }
};

CustomersModule.printStatement = async function (id, requestedFormat = null, requestedFilter = 'debt_only', requestedBranch = 'all') {
  const isAR = i18n.getLang() === 'ar';
  const cust = await DB.get('customers', id);
  if (!cust) return;

  const custName = isAR ? (cust.name_ar || cust.name_en) : (cust.name_en || cust.name_ar);
  const company = await DB.getSetting('company_name', 'Store');
  const companyAr = await DB.getSetting('company_name_ar', '');
  const phone = await DB.getSetting('company_phone', '');
  const email = await DB.getSetting('company_email', '');
  const address = await DB.getSetting('company_address', '');
  const vatNum = await DB.getSetting('vat_number', '');
  const logo = await DB.getSetting('company_logo', '');
  const printLogo = await DB.getSetting('print_logo', true);
  const primaryColor = await DB.getSetting('inv_primary_color', '#2563eb');
  const fontFamily = await DB.getSetting('inv_font_family', 'Cairo');
  const cur1 = await DB.getSetting('currency_1', 'USD');
  const cur2 = await DB.getSetting('currency_2', 'LBP');
  const exchRate = parseFloat(await DB.getSetting('exchange_rate', '89500')) || 89500;
  const dualCur = (await DB.getSetting('inv_show_dual_currency', true)) !== false;

  const defaultReceiptSize = await DB.getSetting('receipt_size', '80mm');
  let format = requestedFormat;
  if (!format) {
    format = (defaultReceiptSize === '80mm' || defaultReceiptSize === '58mm') ? '80mm' : 'A4';
  }

  const { ledger, totalDebit, totalCredit, runningBal } = await CustomersModule.buildCustomerLedger(id, isAR, requestedBranch, requestedFilter);

  if (format === '80mm' || format === '58mm') {
    // ── 80mm Thermal Receipt Statement ──
    const html = `
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
          width: 76mm; 
          margin: 0 auto; 
          font-family: 'Segoe UI', 'Tahoma', 'Arial', 'Cairo', sans-serif; 
          font-size: 11px; 
          font-weight: 600;
          color: #000000 !important; 
          background: #ffffff !important; 
          direction: ${isAR ? 'rtl' : 'ltr'}; 
          text-align: ${isAR ? 'right' : 'left'}; 
          -webkit-font-smoothing: antialiased;
        }
        .statement-80mm { padding: 2mm 1mm; width: 100%; }
        .center { text-align: center; }
        .bold { font-weight: 800; }
        .large { font-size: 14px; font-weight: 900; letter-spacing: 0.5px; }
        .divider { border-top: 1.5px dashed #000; margin: 5px 0; }
        .divider-solid { border-top: 2px solid #000; margin: 5px 0; }
        .row { display: flex; justify-content: space-between; align-items: center; margin: 3px 0; font-size: 11px; color: #000; font-weight: 600; }
        bdi { unicode-bidi: isolate; }
        @media print {
          @page { margin: 0; size: 80mm auto; }
          body { width: 100%; color: #000 !important; font-size: 11px; }
        }
      </style>
      <div class="statement-80mm">
        <!-- Header -->
        <div class="center">
          ${(printLogo && logo) ? `<div style="margin-bottom:4px"><img src="${logo}" style="max-width:70px;max-height:55px;object-fit:contain"></div>` : ''}
          <div class="large">${Utils.sanitize(isAR ? (companyAr || company) : company)}</div>
          ${address ? `<div style="font-size:10px;font-weight:600;margin-top:2px">${Utils.sanitize(address)}</div>` : ''}
          ${phone ? `<div style="font-size:10px;font-weight:600;margin-top:2px">${isAR ? 'هاتف: ' : 'Tel: '}<bdi>${Utils.sanitize(phone)}</bdi></div>` : ''}
          ${vatNum ? `<div style="font-size:10px;font-weight:600;margin-top:2px">${isAR ? 'الرقم المالي: ' : 'Tax ID: '}<bdi>${Utils.sanitize(vatNum)}</bdi></div>` : ''}
        </div>

        <div class="divider"></div>

        <!-- Document Title & Customer Info -->
        <div class="center" style="font-weight:900;font-size:13px;margin:4px 0;letter-spacing:0.3px">
          📋 ${isAR ? 'كشف حساب عميل' : 'CUSTOMER STATEMENT'}
        </div>
        <div class="row">
          <span>${isAR ? 'تاريخ الكشف / Date:' : 'Date:'}</span>
          <span><bdi>${Utils.formatDate(Utils.today())}</bdi></span>
        </div>
        <div class="row">
          <span>${isAR ? 'العميل / Customer:' : 'Customer:'}</span>
          <span class="bold">${Utils.sanitize(custName)}</span>
        </div>
        ${cust.phone ? `
        <div class="row">
          <span>${isAR ? 'الهاتف / Phone:' : 'Phone:'}</span>
          <span><bdi>${Utils.sanitize(cust.phone)}</bdi></span>
        </div>` : ''}

        <div class="divider-solid"></div>

        <!-- Transactions Header -->
        <div style="font-weight:900;font-size:11px;display:flex;justify-content:space-between;padding:3px 0">
          <span>${isAR ? 'الحركة / البيان' : 'Movement / Details'}</span>
          <span>${isAR ? 'المبلغ والرصيد' : 'Amount & Balance'}</span>
        </div>
        <div class="divider"></div>

        <!-- Transactions Flow -->
        ${ledger.map((l, idx) => `
        <div style="padding:4px 0;border-bottom:1.5px dotted #000;font-size:11px">
          <div style="display:flex;justify-content:space-between;font-weight:800">
            <span><bdi>${Utils.formatDate(l.date)}</bdi> • ${Utils.sanitize(l.ref)} <span style="font-size:9.5px;font-weight:700;color:#333">[${Utils.sanitize(l.branch || '-')}]</span></span>
            <span style="font-weight:900;color:#000">
              ${l.debit > 0 ? `+${Utils.formatMoney(l.debit)}` : `-${Utils.formatMoney(l.credit)}`}
            </span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:10px;margin-top:2px;font-weight:600">
            <span>${Utils.sanitize(l.type)}</span>
            <span style="font-weight:800">${isAR ? 'الرصيد: ' : 'Bal: '}<bdi>${Utils.formatMoney(l.balance)}</bdi></span>
          </div>
        </div>
        `).join('') || `<div class="center" style="padding:8px 0;font-size:10px">${isAR ? 'لا توجد حركات سابقة' : 'No transactions'}</div>`}

        <div class="divider-solid"></div>

        <!-- Totals -->
        <div class="row">
          <span>${isAR ? 'إجمالي المشتريات (مدين +):' : 'Total Invoiced (Debit +):'}</span>
          <span class="bold"><bdi>+${Utils.formatMoney(totalDebit)}</bdi></span>
        </div>
        <div class="row">
          <span>${isAR ? 'إجمالي المدفوعات (دائن -):' : 'Total Paid (Credit -):'}</span>
          <span class="bold"><bdi>-${Utils.formatMoney(totalCredit)}</bdi></span>
        </div>

        <!-- Highlighted Net Outstanding Box (Supermarket Style) -->
        <div style="border:2px solid #000;background:#ffffff;border-radius:4px;padding:6px 8px;margin:6px 0;text-align:center">
          <div style="font-size:11px;font-weight:800;letter-spacing:0.3px">
            ${isAR ? 'إجمالي الرصيد المستحق (BALANCE DUE)' : 'TOTAL OUTSTANDING BALANCE DUE'}
          </div>
          <div style="font-size:16px;font-weight:900;margin-top:2px">
            <bdi>${Utils.formatMoney(runningBal)}</bdi>
          </div>
          ${(dualCur && exchRate) ? `
          <div style="font-size:11px;font-weight:800;margin-top:3px;border-top:1.5px dashed #000;padding-top:3px">
            <span>${isAR ? `المعادل بـ (${cur2}): ` : `In ${cur2}: `}</span>
            <span><bdi>${Utils.formatCurrency(Utils.calcSecondaryPrice(runningBal, cur1, cur2, exchRate), cur2)}</bdi></span>
          </div>` : ''}
        </div>

        <!-- Signatures -->
        <div style="display:flex;justify-content:space-between;margin-top:14px;padding-top:4px;font-size:10px;font-weight:700">
          <div style="text-align:center;width:45%;border-top:1.5px dashed #000;padding-top:3px">
            ${isAR ? 'توقيع العميل' : 'Customer Signature'}
          </div>
          <div style="text-align:center;width:45%;border-top:1.5px dashed #000;padding-top:3px">
            ${isAR ? 'توقيع وختم المتجر' : 'Store Stamp & Signature'}
          </div>
        </div>

        <!-- Footer -->
        <div class="center" style="font-size:10px;font-weight:600;margin-top:10px;border-top:1.5px dashed #000;padding-top:4px">
          <div>${isAR ? 'شكراً لتعاملكم معنا ونسعد بخدمتكم' : 'Thank you for your business!'}</div>
          <div style="font-size:9px;margin-top:2px">${isAR ? 'مستند كشف حساب محاسبي رسمي' : 'Official Accounting Statement'}</div>
        </div>
      </div>
    `;

    await Utils.printElement(html, `Statement-${custName}`, '80mm');
    return;
  }

  // ── A4 Official Statement ──
  const html = `
    <div style="font-family:'${fontFamily}','Cairo','Inter',sans-serif;padding:24px;max-width:850px;margin:auto" dir="${isAR ? 'rtl' : 'ltr'}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid ${primaryColor};padding-bottom:14px;margin-bottom:20px;gap:16px">
        <div style="display:flex;gap:14px;align-items:center">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:80px;max-height:80px;object-fit:contain;border-radius:4px">` : ''}
          <div>
            <h1 style="margin:0;font-size:1.5rem;color:${primaryColor};font-weight:900">${isAR ? (companyAr || company) : (company || companyAr)}</h1>
            <p style="margin:3px 0 0;color:#64748b;font-weight:700;font-size:0.9rem">${isAR ? 'كشف حساب عميل مفصل (كافة الفروع)' : 'Customer Account Statement (All Branches)'}</p>
            ${address ? `<p style="margin:2px 0 0;font-size:0.78rem;color:#64748b">📍 ${address}</p>` : ''}
            ${phone ? `<p style="margin:2px 0 0;font-size:0.78rem;color:#64748b">📞 ${phone}</p>` : ''}
            ${vatNum ? `<p style="margin:2px 0 0;font-size:0.78rem;color:#334155"><strong>${isAR ? 'الرقم الضريبي: ' : 'VAT No: '}</strong>${vatNum}</p>` : ''}
          </div>
        </div>
        <div style="text-align:${isAR ? 'left' : 'right'};font-size:0.85rem">
          <p style="margin:0"><strong>${isAR ? 'تاريخ الكشف:' : 'Statement Date:'}</strong> ${Utils.formatDate(Utils.today())}</p>
          <p style="margin:3px 0 0;color:#64748b;font-size:0.75rem">${isAR ? 'مستند محاسبي رسمي' : 'Official Statement'}</p>
        </div>
      </div>

      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:0.85rem">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div><strong>${isAR ? 'اسم العميل:' : 'Customer Name:'}</strong> ${Utils.sanitize(custName)}</div>
          <div><strong>${isAR ? 'الهاتف:' : 'Phone:'}</strong> ${cust.phone || '-'}</div>
          <div><strong>${isAR ? 'البريد الإلكتروني:' : 'Email:'}</strong> ${cust.email || '-'}</div>
          <div><strong>${isAR ? 'حد الائتمان:' : 'Credit Limit:'}</strong> ${Utils.formatMoney(cust.credit_limit || 0)}</div>
        </div>
      </div>

      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;font-size:0.8rem">
        <thead>
          <tr style="background:${primaryColor};color:white">
            <th style="padding:8px 10px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'التاريخ' : 'Date'}</th>
            <th style="padding:8px 10px;text-align:center">${isAR ? 'الفرع' : 'Branch'}</th>
            <th style="padding:8px 10px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'الرقم' : 'Ref #'}</th>
            <th style="padding:8px 10px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'البيان / النوع' : 'Type / Ref'}</th>
            <th style="padding:8px 10px;text-align:right">${isAR ? 'مدين (+)' : 'Debit (+)'}</th>
            <th style="padding:8px 10px;text-align:right">${isAR ? 'دائن (-)' : 'Credit (-)'}</th>
            <th style="padding:8px 10px;text-align:right">${isAR ? 'الرصيد' : 'Balance'}</th>
          </tr>
        </thead>
        <tbody>
          ${ledger.map((l, idx) => `
          <tr style="background:${idx % 2 === 0 ? '#fff' : '#f8fafc'};border-bottom:1px solid #e2e8f0">
            <td style="padding:7px 10px">${Utils.formatDate(l.date)}</td>
            <td style="padding:7px 10px;text-align:center"><span style="display:inline-block;padding:2px 7px;border-radius:4px;font-size:0.74rem;background:#f1f5f9;color:#334155;font-weight:700">${Utils.sanitize(l.branch || '-')}</span></td>
            <td style="padding:7px 10px;font-weight:700">${l.ref}</td>
            <td style="padding:7px 10px">${l.type}</td>
            <td style="padding:7px 10px;text-align:right;color:#ef4444;font-weight:600">${l.debit > 0 ? Utils.formatMoney(l.debit) : '-'}</td>
            <td style="padding:7px 10px;text-align:right;color:#10b981;font-weight:600">${l.credit > 0 ? Utils.formatMoney(l.credit) : '-'}</td>
            <td style="padding:7px 10px;text-align:right;font-weight:800">${Utils.formatMoney(l.balance)}</td>
          </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;padding:20px">${isAR ? 'لا توجد حركات' : 'No records'}</td></tr>`}
        </tbody>
        <tfoot>
          <tr style="background:#f1f5f9;font-weight:800;border-top:2px solid #333">
            <td colspan="4" style="padding:10px">${isAR ? 'الإجمالي الصافي' : 'Grand Total'}</td>
            <td style="padding:10px;text-align:right;color:#ef4444">${Utils.formatMoney(totalDebit)}</td>
            <td style="padding:10px;text-align:right;color:#10b981">${Utils.formatMoney(totalCredit)}</td>
            <td style="padding:10px;text-align:right;color:#0f172a;font-size:1rem">${Utils.formatMoney(runningBal)}</td>
          </tr>
        </tfoot>
      </table>

      <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;padding:12px;text-align:center;margin-bottom:30px">
        <div style="font-size:0.85rem;color:#991b1b;font-weight:600">${isAR ? 'إجمالي الدين المستحق الحالي المطلوب سداده:' : 'Total Outstanding Balance Due:'}</div>
        <div style="font-size:1.6rem;font-weight:900;color:#dc2626;margin-top:4px">${Utils.formatMoney(runningBal)}</div>
        ${(dualCur && exchRate) ? `
        <div style="font-size:0.95rem;color:#7f1d1d;font-weight:700;margin-top:4px">
          ${isAR ? `ما يعادل بالعملة المحلية (${cur2}): ` : `Equivalent in ${cur2}: `}
          ${Utils.formatCurrency(Utils.calcSecondaryPrice(runningBal, cur1, cur2, exchRate), cur2)}
        </div>` : ''}
      </div>

      <div style="display:flex;justify-content:space-between;margin-top:40px;padding-top:10px;border-top:1px solid #ccc;font-size:0.85rem">
        <div style="text-align:center"><p style="margin-bottom:30px">${isAR ? 'توقيع العميل' : 'Customer Signature'}</p><p>___________________</p></div>
        <div style="text-align:center"><p style="margin-bottom:30px">${isAR ? 'ختم وتوقيع المحاسب' : 'Accountant Stamp & Signature'}</p><p>___________________</p></div>
      </div>
    </div>
  `;

  await Utils.printElement(html, `Statement-${custName}`, 'A4');
};

const Customers = {
  render: (c) => CustomersModule.render(c),
};

window.CustomersModule = CustomersModule;
window.customersModule = CustomersModule;
window.Customers = Customers;

/* ── Suppliers ─────────────────────────────────────────────────── */
const SuppliersModule = buildGenericList({
  store: 'suppliers', title: 'Suppliers', titleAr: 'الموردون',
  singularEn: 'Supplier', singularAr: 'مورد',
  searchKeys: ['name_en', 'name_ar', 'phone', 'email'],
  columns: [
    { key: 'name_en', label: 'Name', labelAr: 'الاسم', render: (r, ar) => `<div style="font-weight:600">${Utils.truncate(ar ? (r.name_ar || r.name_en) : (r.name_en || r.name_ar), 30)}</div>` },
    { key: 'phone', label: 'Phone', labelAr: 'الهاتف' },
    { key: 'email', label: 'Email', labelAr: 'البريد الإلكتروني' },
    { key: 'currency', label: 'Currency', labelAr: 'العملة', render: r => `<span class="badge badge-info">${r.currency || 'USD'}</span>` },
    { key: 'balance', label: 'Balance', labelAr: 'الرصيد', render: r => `<span style="color:${(r.balance || 0) > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(r.balance || 0)}</span>` },
  ],
  fields: [
    { id: 'name_ar', label: 'Name (Arabic)', labelAr: 'الاسم (عربي)', placeholder: 'الاسم بالعربي', dir: 'dir="rtl"' },
    { id: 'name_en', label: 'Name (English)', labelAr: 'الاسم (إنجليزي)', placeholder: 'Supplier name' },
    { id: 'phone', label: 'Phone', labelAr: 'الهاتف', placeholder: '+961...' },
    { id: 'email', label: 'Email', labelAr: 'البريد', placeholder: 'email@domain.com', type: 'email' },
    { id: 'address', label: 'Address', labelAr: 'العنوان', placeholder: 'Address', fullWidth: true },
    { id: 'vat_number', label: 'VAT Number', labelAr: 'الرقم الضريبي', placeholder: 'VAT #' },
    { id: 'opening_balance', label: 'Opening / Old Loan Balance (Payable)', labelAr: 'الرصيد الافتتاحي / مستحق ودين سابق للمورد', placeholder: '0.00', placeholderAr: '0.00', type: 'number', step: '0.01' },
    {
      id: 'currency', label: 'Currency', labelAr: 'العملة', type: 'select', options: [
        { value: 'USD', label: 'USD' }, { value: 'EUR', label: 'EUR' },
        { value: 'LBP', label: 'LBP' }, { value: 'AED', label: 'AED' },
      ]
    },
    { id: 'payment_terms', label: 'Payment Terms', labelAr: 'شروط الدفع', placeholder: '30 days' },
    { id: 'notes', label: 'Notes', labelAr: 'ملاحظات', type: 'textarea', placeholder: 'Notes...', fullWidth: true },
  ]
});

SuppliersModule.buildSupplierLedger = async function (id, isAR, requestedBranch) {
  let suppRecord = await DB.get('suppliers', id);
  if (!suppRecord && typeof id === 'string' && /^\d+$/.test(id)) {
    suppRecord = await DB.get('suppliers', parseInt(id, 10));
  }
  if (!suppRecord && typeof id === 'number') {
    suppRecord = await DB.get('suppliers', String(id));
  }
  const matchIdStr = String(id);
  let pinvDocs = (await DB.getAll('purchase_invoices', i => String(i.supplier_id) === matchIdStr && i.status !== 'cancelled' && i.status !== 'draft')) || [];
  let pretDocs = (await DB.getAll('purchase_returns', r => String(r.supplier_id) === matchIdStr && r.status !== 'cancelled')) || [];
  let cashTxns = (await DB.getAll('cash_transactions', t => String(t.supplier_id) === matchIdStr && (t.type === 'payment' || t.type === 'expense'))) || [];
  let bankTxns = (await DB.getAll('bank_transactions', t => String(t.supplier_id) === matchIdStr && (t.type === 'payment' || t.type === 'expense'))) || [];

  // Determine Branch Scope
  let syncCfg = { role: 'server', branchId: 'main' };
  try {
    if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
      syncCfg = await BranchSync.getConfig();
    }
  } catch (e) { }
  const isServerNode = syncCfg.role === 'server';
  const myBranch = (syncCfg.branchId || 'main').toLowerCase();
  const branchFilter = isServerNode ? (requestedBranch || 'all').toLowerCase() : myBranch;

  const fLow = String(branchFilter || 'all').trim().toLowerCase();
  function matchesBranch(t) {
    if (!branchFilter || fLow === 'all') return true;
    const bId = String(t.branch_id || t.syncBranchId || t.terminal_id || t.syncNodeId || '').trim().toLowerCase();
    const bName = String(t.branch_name || t.branch_title || t.syncBranchName || '').trim().toLowerCase();
    if (fLow === 'main') {
      return !bId || bId === 'main' || bName.includes('main') || bName.includes('رئيسي') || bId === 'srv-01';
    }
    return bId === fLow || bName === fLow || bName.includes(fLow) || fLow.includes(bId) || (bId && fLow.includes(bId));
  }

  pinvDocs = pinvDocs.filter(matchesBranch);
  pretDocs = pretDocs.filter(matchesBranch);
  cashTxns = cashTxns.filter(matchesBranch);
  bankTxns = bankTxns.filter(matchesBranch);

  const ledger = [];

  // 0. Process Opening Balance (if any)
  const suppOpBal = parseFloat(suppRecord?.opening_balance) || 0;
  if (suppOpBal !== 0) {
    ledger.push({
      id: 'op-bal',
      store: 'opening',
      date: (suppRecord?.created_at || '1970-01-01').slice(0, 10),
      created_at: suppRecord?.created_at || '1970-01-01',
      ref: isAR ? 'رصيد افتتاحي' : 'OP-BAL',
      type: isAR ? 'رصيد افتتاحي / مستحق وقرض سابق' : 'Opening Balance / Old Loan (Migrated)',
      debit: suppOpBal > 0 ? suppOpBal : 0,
      credit: suppOpBal < 0 ? -suppOpBal : 0,
      isPayment: false,
      priority: 0
    });
  }
  pinvDocs.forEach(p => {
    const debitAmount = parseFloat(p.base_grand_total !== undefined ? p.base_grand_total : p.grand_total) || 0;
    const isCredit = p.payment_method === 'credit';
    const pDate = p.doc_date || p.created_at || p.date;
    const paidAmt = parseFloat(p.base_paid_amount !== undefined ? p.base_paid_amount : (p.paid_amount !== undefined ? p.paid_amount : (!isCredit ? debitAmount : 0))) || 0;

    ledger.push({
      id: p.id,
      store: 'purchase_invoices',
      date: pDate,
      created_at: p.created_at || pDate,
      ref: p.ref || `PINV-${p.id}`,
      type: isAR ? (isCredit ? 'فاتورة مشتريات (آجل)' : 'فاتورة مشتريات (نقدي)') : (isCredit ? 'Purchase Invoice (Credit)' : 'Purchase Invoice (Cash)'),
      debit: debitAmount,
      credit: 0,
      isPayment: false,
      priority: 1
    });

    // Check if down payment or cash settlement is already logged in cash/bank txns
    const hasLinkedTxn = cashTxns.some(t => t.invoice_id === p.id || (t.ref && t.ref === p.ref) || (t.notes && t.notes.includes(p.ref)))
      || bankTxns.some(t => t.invoice_id === p.id || (t.ref && t.ref === p.ref) || (t.description && t.description.includes(p.ref)));

    if (!hasLinkedTxn && paidAmt > 0) {
      ledger.push({
        id: p.id,
        store: 'purchase_invoices',
        date: pDate,
        created_at: p.created_at || pDate,
        ref: p.ref || `PINV-${p.id}`,
        type: isAR ? (isCredit ? 'دفعة مسددة على الفاتورة' : 'سداد فوري للمشتريات') : (isCredit ? 'Down Payment on Invoice' : 'Immediate Purchase Payment'),
        debit: 0,
        credit: paidAmt,
        isPayment: true,
        priority: 2,
        linkedRef: p.ref || `PINV-${p.id}`
      });
    }
  });

  pretDocs.forEach(r => {
    const creditAmount = parseFloat(r.base_grand_total !== undefined ? r.base_grand_total : r.grand_total) || 0;
    const rDate = r.doc_date || r.created_at || r.date;
    ledger.push({
      id: r.id,
      store: 'purchase_returns',
      date: rDate,
      created_at: r.created_at || rDate,
      ref: r.ref || `PRET-${r.id}`,
      type: isAR ? 'مرتجع مشتريات' : 'Purchase Return',
      debit: 0,
      credit: creditAmount,
      isPayment: true,
      priority: 2
    });
  });

  cashTxns.forEach(t => {
    let effectiveDate = t.date || t.created_at;
    if (t.created_at && String(t.date || '').length === 10 && t.created_at.startsWith(t.date)) {
      effectiveDate = t.created_at;
    }
    ledger.push({
      id: t.id,
      store: 'cash_transactions',
      date: effectiveDate,
      created_at: t.created_at || effectiveDate,
      ref: t.ref || `PAY-${t.id}`,
      type: isAR ? (t.notes || t.description || 'سداد دفعة للمورد (نقدي)') : (t.notes || t.description || 'Supplier Payment (Cash)'),
      debit: 0,
      credit: parseFloat(t.amount) || 0,
      isPayment: true,
      priority: 2,
      linkedRef: t.ref || ''
    });
  });

  bankTxns.forEach(t => {
    let effectiveDate = t.date || t.created_at;
    if (t.created_at && String(t.date || '').length === 10 && t.created_at.startsWith(t.date)) {
      effectiveDate = t.created_at;
    }
    ledger.push({
      id: t.id,
      store: 'bank_transactions',
      date: effectiveDate,
      created_at: t.created_at || effectiveDate,
      ref: t.ref || `BNK-${t.id}`,
      type: isAR ? (t.description || t.notes || 'سداد بنكي للمورد') : (t.description || t.notes || 'Supplier Bank Payment'),
      debit: 0,
      credit: parseFloat(t.amount) || 0,
      isPayment: true,
      priority: 2,
      linkedRef: t.ref || ''
    });
  });

  ledger.sort((a, b) => {
    const dayA = String(a.date || a.created_at || '').slice(0, 10);
    const dayB = String(b.date || b.created_at || '').slice(0, 10);
    if (dayA !== dayB) return dayA.localeCompare(dayB);
    if (b.linkedRef && b.linkedRef === a.ref) return -1;
    if (a.linkedRef && a.linkedRef === b.ref) return 1;
    const timeA = new Date(a.created_at || a.date || 0).getTime();
    const timeB = new Date(b.created_at || b.date || 0).getTime();
    if (Math.abs(timeA - timeB) > 1000) return timeA - timeB;
    if ((a.priority || 0) !== (b.priority || 0)) return (a.priority || 0) - (b.priority || 0);
    return (a.id || 0) - (b.id || 0);
  });

  let runningBal = 0;
  ledger.forEach(item => {
    runningBal += (item.debit - item.credit);
    item.balance = Utils.round(runningBal);
  });

  const totalDebit = Utils.round(ledger.reduce((s, i) => s + i.debit, 0));
  const totalCredit = Utils.round(ledger.reduce((s, i) => s + i.credit, 0));
  runningBal = Utils.round(runningBal);

  return { ledger, totalDebit, totalCredit, runningBal };
};

SuppliersModule.openPaymentModal = async function (id) {
  const isAR = i18n.getLang() === 'ar';
  const supplier = await DB.get('suppliers', id);
  if (!supplier) return;

  const modalId = 'supp-pay-modal';
  let modalEl = document.getElementById(modalId);
  if (modalEl) modalEl.remove();

  const suppName = isAR ? (supplier.name_ar || supplier.name_en) : (supplier.name_en || supplier.name_ar);
  const bal = supplier.balance || 0;

  modalEl = document.createElement('div');
  modalEl.className = 'modal-overlay open';
  modalEl.id = modalId;
  modalEl.innerHTML = `
    <div class="modal" style="max-width:480px">
      <div class="modal-header">
        <div class="modal-title">
          💵 ${isAR ? 'دفع مبلغ لمورد (سداد دين)' : 'Pay Supplier'}
        </div>
        <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;padding:12px;margin-bottom:16px">
          <div style="font-size:0.8rem;color:var(--text-muted);margin-bottom:4px">${isAR ? 'اسم المورد:' : 'Supplier Name:'} <strong style="color:var(--text-primary)">${Utils.sanitize(suppName)}</strong></div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:0.82rem;font-weight:600">${isAR ? 'رصيد حساب المورد (دين المستحق له):' : 'Current Supplier Balance:'}</span>
            <span style="font-size:1.1rem;font-weight:800;color:${bal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(bal)}</span>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'المبلغ المدفوع' : 'Payment Amount'}</label>
          <input type="number" class="form-control" id="supp-pay-amount" value="${bal > 0 ? bal : ''}" placeholder="0.00" step="0.01" min="0.01" style="font-size:1.1rem;font-weight:700;color:var(--warning)">
        </div>
        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
            <select class="form-control" id="supp-pay-method">
              <option value="cash">${isAR ? 'نقداً (الصندوق)' : 'Cash'}</option>
              <option value="bank">${isAR ? 'تحويل بنكي' : 'Bank Transfer'}</option>
              <option value="card">${isAR ? 'بطاقة إئتمان' : 'Card'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'التاريخ' : 'Date'}</label>
            <input type="date" class="form-control" id="supp-pay-date" value="${Utils.today()}">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'ملاحظات / البيان' : 'Notes / Description'}</label>
          <input type="text" class="form-control" id="supp-pay-notes" placeholder="${isAR ? 'مثال: سداد قيمة مشتريات' : 'e.g. Purchase payment'}">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
        <button class="btn btn-primary" onclick="SuppliersModule.savePayment(${id})">${isAR ? 'حفظ خصم المبلغ' : 'Save Payment'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(modalEl);
};

SuppliersModule.savePayment = async function (id) {
  const isAR = i18n.getLang() === 'ar';
  const supplier = await DB.get('suppliers', id);
  if (!supplier) return;

  const paidAmount = parseFloat(document.getElementById('supp-pay-amount')?.value || 0) || 0;
  if (paidAmount <= 0) {
    Utils.toast(isAR ? 'يرجى إدخال مبلغ صحيح' : 'Please enter a valid amount', 'warning');
    return;
  }

  const method = document.getElementById('supp-pay-method')?.value || 'cash';
  const payDate = document.getElementById('supp-pay-date')?.value || Utils.today();
  const notes = document.getElementById('supp-pay-notes')?.value || (isAR ? 'دفع حساب مورد' : 'Supplier Debt Payment');

  const store = method === 'bank' ? 'bank_transactions' : 'cash_transactions';
  const prefix = method === 'bank' ? 'BNK-OUT-' : 'PAY-';
  const ref = await DB.nextSeq(store, prefix, 5);

  await DB.add(store, {
    ref,
    type: 'payment',
    date: payDate,
    amount: paidAmount,
    supplier_id: id,
    supplier_name: supplier.name_en || supplier.name_ar,
    description: notes,
    payment_method: method
  });

  const { runningBal } = await SuppliersModule.buildSupplierLedger(id, isAR);

  Utils.closeModal('supp-pay-modal');
  Utils.toast(isAR ? `تم خصم المبلغ بنجاح! الرصيد المتبقي للمورد: ${Utils.formatMoney(runningBal)}` : `Payment saved! Supplier Balance: ${Utils.formatMoney(runningBal)}`, 'success');

  SuppliersModule._data = await DB.getAll('suppliers');
  SuppliersModule.renderTable(SuppliersModule.getFiltered());
};

SuppliersModule.printStatement = async function (id, requestedFormat = null) {
  const isAR = i18n.getLang() === 'ar';
  const supp = await DB.get('suppliers', id);
  if (!supp) return;

  const suppName = isAR ? (supp.name_ar || supp.name_en) : (supp.name_en || supp.name_ar);
  const company = await DB.getSetting('company_name', 'Store');
  const companyAr = await DB.getSetting('company_name_ar', '');
  const phone = await DB.getSetting('company_phone', '');
  const email = await DB.getSetting('company_email', '');
  const address = await DB.getSetting('company_address', '');
  const vatNum = await DB.getSetting('vat_number', '');
  const logo = await DB.getSetting('company_logo', '');
  const printLogo = await DB.getSetting('print_logo', true);
  const primaryColor = await DB.getSetting('inv_primary_color', '#2563eb');
  const fontFamily = await DB.getSetting('inv_font_family', 'Cairo');
  const cur1 = await DB.getSetting('currency_1', 'USD');
  const cur2 = await DB.getSetting('currency_2', 'LBP');
  const exchRate = parseFloat(await DB.getSetting('exchange_rate', '89500')) || 89500;
  const dualCur = (await DB.getSetting('inv_show_dual_currency', true)) !== false;

  const defaultReceiptSize = await DB.getSetting('receipt_size', '80mm');
  let format = requestedFormat;
  if (!format) {
    format = (defaultReceiptSize === '80mm' || defaultReceiptSize === '58mm') ? '80mm' : 'A4';
  }

  const { ledger, totalDebit, totalCredit, runningBal } = await SuppliersModule.buildSupplierLedger(id, isAR);

  if (format === '80mm' || format === '58mm') {
    // ── 80mm Thermal Receipt Statement for Supplier ──
    const html = `
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
          width: 76mm; 
          margin: 0 auto; 
          font-family: 'Segoe UI', 'Tahoma', 'Arial', 'Cairo', sans-serif; 
          font-size: 11px; 
          font-weight: 600;
          color: #000000 !important; 
          background: #ffffff !important; 
          direction: ${isAR ? 'rtl' : 'ltr'}; 
          text-align: ${isAR ? 'right' : 'left'}; 
          -webkit-font-smoothing: antialiased;
        }
        .statement-80mm { padding: 2mm 1mm; width: 100%; }
        .center { text-align: center; }
        .bold { font-weight: 800; }
        .large { font-size: 14px; font-weight: 900; letter-spacing: 0.5px; }
        .divider { border-top: 1.5px dashed #000; margin: 5px 0; }
        .divider-solid { border-top: 2px solid #000; margin: 5px 0; }
        .row { display: flex; justify-content: space-between; align-items: center; margin: 3px 0; font-size: 11px; color: #000; font-weight: 600; }
        bdi { unicode-bidi: isolate; }
        @media print {
          @page { margin: 0; size: 80mm auto; }
          body { width: 100%; color: #000 !important; font-size: 11px; }
        }
      </style>
      <div class="statement-80mm">
        <!-- Header -->
        <div class="center">
          ${(printLogo && logo) ? `<div style="margin-bottom:4px"><img src="${logo}" style="max-width:70px;max-height:55px;object-fit:contain"></div>` : ''}
          <div class="large">${Utils.sanitize(isAR ? (companyAr || company) : company)}</div>
          ${address ? `<div style="font-size:9px;margin-top:1px">${Utils.sanitize(address)}</div>` : ''}
          ${phone ? `<div style="font-size:9px;margin-top:1px">${isAR ? 'هاتف: ' : 'Tel: '}<bdi>${Utils.sanitize(phone)}</bdi></div>` : ''}
          ${vatNum ? `<div style="font-size:9px;margin-top:1px">${isAR ? 'الرقم المالي: ' : 'Tax ID: '}<bdi>${Utils.sanitize(vatNum)}</bdi></div>` : ''}
        </div>

        <div class="divider"></div>

        <!-- Document Title & Supplier Info -->
        <div class="center" style="font-weight:900;font-size:12px;margin:3px 0;letter-spacing:0.3px">
          📦 ${isAR ? 'كشف حساب مورد' : 'SUPPLIER STATEMENT'}
        </div>
        <div class="row">
          <span>${isAR ? 'تاريخ الكشف / Date:' : 'Date:'}</span>
          <span><bdi>${Utils.formatDate(Utils.today())}</bdi></span>
        </div>
        <div class="row">
          <span>${isAR ? 'المورد / Supplier:' : 'Supplier:'}</span>
          <span class="bold">${Utils.sanitize(suppName)}</span>
        </div>
        ${supp.phone ? `
        <div class="row">
          <span>${isAR ? 'الهاتف / Phone:' : 'Phone:'}</span>
          <span><bdi>${Utils.sanitize(supp.phone)}</bdi></span>
        </div>` : ''}

        <div class="divider-solid"></div>

        <!-- Transactions Header -->
        <div style="font-weight:900;font-size:9.5px;display:flex;justify-content:space-between;padding:2px 0">
          <span>${isAR ? 'الحركة / البيان' : 'Movement / Details'}</span>
          <span>${isAR ? 'المبلغ والرصيد' : 'Amount & Balance'}</span>
        </div>
        <div class="divider"></div>

        <!-- Transactions Flow -->
        ${ledger.map((l, idx) => `
        <div style="padding:3px 0;border-bottom:1px dotted #888;font-size:9.5px">
          <div style="display:flex;justify-content:space-between;font-weight:800">
            <span><bdi>${Utils.formatDate(l.date)}</bdi> • ${Utils.sanitize(l.ref)}</span>
            <span style="font-weight:900;color:#000">
              ${l.debit > 0 ? `+${Utils.formatMoney(l.debit)}` : `-${Utils.formatMoney(l.credit)}`}
            </span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:8.5px;margin-top:1px">
            <span>${Utils.sanitize(l.type)}</span>
            <span style="font-weight:800">${isAR ? 'الرصيد: ' : 'Bal: '}<bdi>${Utils.formatMoney(l.balance)}</bdi></span>
          </div>
        </div>
        `).join('') || `<div class="center" style="padding:8px 0;font-size:9px">${isAR ? 'لا توجد حركات سابقة' : 'No transactions'}</div>`}

        <div class="divider-solid"></div>

        <!-- Totals -->
        <div class="row">
          <span>${isAR ? 'إجمالي المشتريات (مستحق +):' : 'Total Purchases (+):'}</span>
          <span class="bold"><bdi>+${Utils.formatMoney(totalDebit)}</bdi></span>
        </div>
        <div class="row">
          <span>${isAR ? 'إجمالي السدادات (مدفوع -):' : 'Total Payments (-):'}</span>
          <span class="bold"><bdi>-${Utils.formatMoney(totalCredit)}</bdi></span>
        </div>

        <!-- Highlighted Net Outstanding Box -->
        <div style="border:2px solid #000;border-radius:4px;padding:6px 8px;margin:6px 0;text-align:center">
          <div style="font-size:9.5px;font-weight:800;letter-spacing:0.3px">
            ${isAR ? 'صافي الرصيد المستحق للمورد (DUE TO SUPPLIER)' : 'NET BALANCE DUE TO SUPPLIER'}
          </div>
          <div style="font-size:15px;font-weight:900;margin-top:2px">
            <bdi>${Utils.formatMoney(runningBal)}</bdi>
          </div>
          ${(dualCur && exchRate) ? `
          <div style="font-size:9.5px;font-weight:800;margin-top:3px;border-top:1px dashed #000;padding-top:3px">
            <span>${isAR ? `المعادل بـ (${cur2}): ` : `In ${cur2}: `}</span>
            <span><bdi>${Utils.formatCurrency(Utils.calcSecondaryPrice(runningBal, cur1, cur2, exchRate), cur2)}</bdi></span>
          </div>` : ''}
        </div>

        <!-- Signatures -->
        <div style="display:flex;justify-content:space-between;margin-top:12px;padding-top:4px;font-size:8.5px">
          <div style="text-align:center;width:45%;border-top:1px dashed #000;padding-top:2px">
            ${isAR ? 'توقيع المورد' : 'Supplier Signature'}
          </div>
          <div style="text-align:center;width:45%;border-top:1px dashed #000;padding-top:2px">
            ${isAR ? 'توقيع وختم الإدارة' : 'Management Stamp & Signature'}
          </div>
        </div>

        <!-- Footer -->
        <div class="center" style="font-size:8.5px;margin-top:10px;border-top:1px dashed #000;padding-top:4px">
          <div>${isAR ? 'مستند كشف حساب مشتريات ومحاسبة معتمد' : 'Official Approved Supplier Statement'}</div>
        </div>
      </div>
    `;

    await Utils.printElement(html, `SupplierStatement-${suppName}`, '80mm');
    return;
  }

  // ── A4 Official Statement ──
  const html = `
    <div style="font-family:'${fontFamily}','Cairo','Inter',sans-serif;padding:24px;max-width:800px;margin:auto" dir="${isAR ? 'rtl' : 'ltr'}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid ${primaryColor};padding-bottom:14px;margin-bottom:20px;gap:16px">
        <div style="display:flex;gap:14px;align-items:center">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:80px;max-height:80px;object-fit:contain;border-radius:4px">` : ''}
          <div>
            <h1 style="margin:0;font-size:1.5rem;color:${primaryColor};font-weight:900">${isAR ? (companyAr || company) : (company || companyAr)}</h1>
            <p style="margin:3px 0 0;color:#64748b;font-weight:700;font-size:0.9rem">${isAR ? 'كشف حساب مورد مفصل' : 'Supplier Statement of Account'}</p>
            ${address ? `<p style="margin:2px 0 0;font-size:0.78rem;color:#64748b">📍 ${address}</p>` : ''}
            ${phone ? `<p style="margin:2px 0 0;font-size:0.78rem;color:#64748b">📞 ${phone}</p>` : ''}
            ${vatNum ? `<p style="margin:2px 0 0;font-size:0.78rem;color:#334155"><strong>${isAR ? 'الرقم الضريبي: ' : 'VAT No: '}</strong>${vatNum}</p>` : ''}
          </div>
        </div>
        <div style="text-align:${isAR ? 'left' : 'right'};font-size:0.85rem">
          <p style="margin:0"><strong>${isAR ? 'تاريخ الكشف:' : 'Statement Date:'}</strong> ${Utils.formatDate(Utils.today())}</p>
          <p style="margin:3px 0 0;color:#64748b;font-size:0.75rem">${isAR ? 'مستند مشتريات ومحاسبة رسمي' : 'Official Accounting Statement'}</p>
        </div>
      </div>

      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:0.85rem">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div><strong>${isAR ? 'اسم المورد:' : 'Supplier Name:'}</strong> ${Utils.sanitize(suppName)}</div>
          <div><strong>${isAR ? 'الهاتف:' : 'Phone:'}</strong> ${supp.phone || '-'}</div>
          <div><strong>${isAR ? 'البريد الإلكتروني:' : 'Email:'}</strong> ${supp.email || '-'}</div>
          <div><strong>${isAR ? 'العنوان:' : 'Address:'}</strong> ${supp.address || '-'}</div>
        </div>
      </div>

      <table style="width:100%;border-collapse:collapse;margin-bottom:20px;font-size:0.8rem">
        <thead>
          <tr style="background:${primaryColor};color:white">
            <th style="padding:8px 10px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'التاريخ' : 'Date'}</th>
            <th style="padding:8px 10px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'الرقم' : 'Ref #'}</th>
            <th style="padding:8px 10px;text-align:${isAR ? 'right' : 'left'}">${isAR ? 'النوع / البيان' : 'Type / Ref'}</th>
            <th style="padding:8px 10px;text-align:right">${isAR ? 'مشتريات (+)' : 'Purchases (+)'}</th>
            <th style="padding:8px 10px;text-align:right">${isAR ? 'مدفوعات (-)' : 'Payments (-)'}</th>
            <th style="padding:8px 10px;text-align:right">${isAR ? 'الرصيد' : 'Balance'}</th>
          </tr>
        </thead>
        <tbody>
          ${ledger.map((l, idx) => `
          <tr style="background:${idx % 2 === 0 ? '#fff' : '#f8fafc'};border-bottom:1px solid #e2e8f0">
            <td style="padding:7px 10px">${Utils.formatDate(l.date)}</td>
            <td style="padding:7px 10px;font-weight:700">${l.ref}</td>
            <td style="padding:7px 10px">${l.type}</td>
            <td style="padding:7px 10px;text-align:right;color:#ef4444;font-weight:600">${l.debit > 0 ? Utils.formatMoney(l.debit) : '-'}</td>
            <td style="padding:7px 10px;text-align:right;color:#10b981;font-weight:600">${l.credit > 0 ? Utils.formatMoney(l.credit) : '-'}</td>
            <td style="padding:7px 10px;text-align:right;font-weight:800">${Utils.formatMoney(l.balance)}</td>
          </tr>`).join('') || `<tr><td colspan="6" style="text-align:center;padding:20px">${isAR ? 'لا توجد حركات' : 'No records'}</td></tr>`}
        </tbody>
        <tfoot>
          <tr style="background:#f1f5f9;font-weight:800;border-top:2px solid #333">
            <td colspan="3" style="padding:10px">${isAR ? 'الإجمالي الصافي' : 'Grand Total'}</td>
            <td style="padding:10px;text-align:right;color:#ef4444">${Utils.formatMoney(totalDebit)}</td>
            <td style="padding:10px;text-align:right;color:#10b981">${Utils.formatMoney(totalCredit)}</td>
            <td style="padding:10px;text-align:right;color:#0f172a;font-size:1rem">${Utils.formatMoney(runningBal)}</td>
          </tr>
        </tfoot>
      </table>

      <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;padding:12px;text-align:center;margin-bottom:26px">
        <div style="font-size:0.85rem;color:#991b1b;font-weight:600">${isAR ? 'صافي الرصيد المستحق للمورد:' : 'Net Supplier Balance Due:'}</div>
        <div style="font-size:1.5rem;font-weight:900;color:#dc2626;margin-top:2px">${Utils.formatMoney(runningBal)}</div>
        ${(dualCur && exchRate) ? `
        <div style="font-size:0.95rem;color:#7f1d1d;font-weight:700;margin-top:4px">
          ${isAR ? `ما يعادل بالعملة المحلية (${cur2}): ` : `Equivalent in ${cur2}: `}
          ${Utils.formatCurrency(Utils.calcSecondaryPrice(runningBal, cur1, cur2, exchRate), cur2)}
        </div>` : ''}
      </div>

      <div style="display:flex;justify-content:space-between;margin-top:35px;padding-top:10px;border-top:1px solid #ccc;font-size:0.82rem">
        <div style="text-align:center"><p style="margin-bottom:25px">${isAR ? 'توقيع المورد' : 'Supplier Signature'}</p><p>___________________</p></div>
        <div style="text-align:center"><p style="margin-bottom:25px">${isAR ? 'ختم وتوقيع المحاسب' : 'Accountant Stamp & Signature'}</p><p>___________________</p></div>
      </div>
    </div>
  `;

  await Utils.printElement(html, `SupplierStatement-${suppName}`, 'A4');
};

SuppliersModule.deletePaymentTxn = async function (txnStore, txnId, suppId) {
  const isAR = i18n.getLang() === 'ar';
  Utils.confirm(
    isAR ? 'هل أنت متأكد من إلغاء وحذف هذه الدفعة وإعادة المبلغ لحساب دين المورد؟' : 'Are you sure you want to delete this payment and restore it to the supplier debt balance?',
    async () => {
      const txn = await DB.get(txnStore, txnId);
      if (txn) {
        const paidAmt = parseFloat(txn.amount) || 0;
        const supp = await DB.get('suppliers', suppId);
        if (supp) {
          const newBal = Utils.round((supp.balance || 0) + paidAmt);
          const newPaid = Math.max(0, Utils.round((supp.total_paid || 0) - paidAmt));
          await DB.update('suppliers', { ...supp, balance: newBal, total_paid: newPaid });
        }
        await DB.remove(txnStore, txnId);
        Utils.toast(isAR ? 'تم حذف الدفعة وإعادة المبلغ لدين المورد' : 'Payment deleted and restored to supplier balance', 'info');

        // Re-sync and refresh
        await SuppliersModule.buildSupplierLedger(suppId, isAR);
        SuppliersModule._data = await DB.getAll('suppliers');
        SuppliersModule.renderTable(SuppliersModule.getFiltered());
        SuppliersModule.openStatementModal(suppId);
      }
    }
  );
};

SuppliersModule.openEditPaymentModal = async function (txnStore, txnId, suppId) {
  const isAR = i18n.getLang() === 'ar';
  const txn = await DB.get(txnStore, txnId);
  const supp = await DB.get('suppliers', suppId);
  if (!txn || !supp) return;

  const modalId = 'supp-edit-pay-modal';
  let modalEl = document.getElementById(modalId);
  if (modalEl) modalEl.remove();

  const suppName = isAR ? (supp.name_ar || supp.name_en) : (supp.name_en || supp.name_ar);

  modalEl = document.createElement('div');
  modalEl.className = 'modal-overlay open';
  modalEl.id = modalId;
  modalEl.innerHTML = `
    <div class="modal" style="max-width:480px">
      <div class="modal-header">
        <div class="modal-title">
          ✏️ ${isAR ? 'تعديل دفعة للمورد: ' + (txn.ref || '') : 'Edit Supplier Payment: ' + (txn.ref || '')}
        </div>
        <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
      </div>
      <div class="modal-body">
        <div style="background:var(--surface-2);border-radius:8px;padding:10px;margin-bottom:14px;font-size:0.82rem">
          <div>${isAR ? 'المورد:' : 'Supplier:'} <strong>${Utils.sanitize(suppName)}</strong></div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'المبلغ المدفوع المعدل' : 'Edit Payment Amount'}</label>
          <input type="number" class="form-control" id="edit-supp-pay-amount" value="${txn.amount || ''}" placeholder="0.00" step="0.01" min="0.01" style="font-size:1.1rem;font-weight:700;color:var(--primary)">
        </div>
        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label">${isAR ? 'طريقة الدفع' : 'Payment Method'}</label>
            <select class="form-control" id="edit-supp-pay-method">
              <option value="cash" ${txn.payment_method === 'cash' ? 'selected' : ''}>${isAR ? 'نقداً (الصندوق)' : 'Cash'}</option>
              <option value="bank" ${txn.payment_method === 'bank' ? 'selected' : ''}>${isAR ? 'تحويل بنكي' : 'Bank Transfer'}</option>
              <option value="card" ${txn.payment_method === 'card' ? 'selected' : ''}>${isAR ? 'بطاقة إئتمان' : 'Card'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'التاريخ' : 'Date'}</label>
            <input type="date" class="form-control" id="edit-supp-pay-date" value="${txn.date || Utils.today()}">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">${isAR ? 'ملاحظات / البيان' : 'Notes / Description'}</label>
          <input type="text" class="form-control" id="edit-supp-pay-notes" value="${Utils.sanitize(txn.notes || txn.description || '')}">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إلغاء' : 'Cancel'}</button>
        <button class="btn btn-primary" onclick="SuppliersModule.saveEditPayment('${txnStore}', ${txnId}, ${suppId})">${isAR ? 'حفظ التعديل' : 'Save Changes'}</button>
      </div>
    </div>
  `;
  document.body.appendChild(modalEl);
};

SuppliersModule.saveEditPayment = async function (txnStore, txnId, suppId) {
  const isAR = i18n.getLang() === 'ar';
  const txn = await DB.get(txnStore, txnId);
  const supp = await DB.get('suppliers', suppId);
  if (!txn || !supp) return;

  const newAmount = parseFloat(document.getElementById('edit-supp-pay-amount')?.value || 0) || 0;
  if (newAmount <= 0) {
    Utils.toast(isAR ? 'يرجى إدخال مبلغ صحيح' : 'Please enter a valid amount', 'warning');
    return;
  }

  const method = document.getElementById('edit-supp-pay-method')?.value || txn.payment_method || 'cash';
  const payDate = document.getElementById('edit-supp-pay-date')?.value || txn.date;
  const notes = document.getElementById('edit-supp-pay-notes')?.value || txn.notes || txn.description;

  await DB.update(txnStore, {
    ...txn,
    amount: newAmount,
    payment_method: method,
    date: payDate,
    description: notes,
    notes: notes
  });

  // Re-sync balance
  await SuppliersModule.buildSupplierLedger(suppId, isAR);

  Utils.closeModal('supp-edit-pay-modal');
  Utils.toast(isAR ? 'تم تعديل الدفعة وتحديث رصيد المورد بنجاح' : 'Payment updated and supplier balance updated successfully', 'success');

  SuppliersModule._data = await DB.getAll('suppliers');
  SuppliersModule.renderTable(SuppliersModule.getFiltered());
  SuppliersModule.openStatementModal(suppId);
};

SuppliersModule.openStatementModal = async function (id, requestedBranch) {
  try {
    const isAR = i18n.getLang() === 'ar';
    let supp = await DB.get('suppliers', id);
    if (!supp && typeof id === 'string' && /^\d+$/.test(id)) {
      supp = await DB.get('suppliers', parseInt(id, 10));
    }
    if (!supp && typeof id === 'number') {
      supp = await DB.get('suppliers', String(id));
    }
    if (!supp) {
      const allSupps = (await DB.getAll('suppliers')) || [];
      supp = allSupps.find(s => String(s.id) === String(id));
    }
    if (!supp) {
      console.warn('[Statement] Supplier not found for id:', id);
      Utils.toast(isAR ? 'لم يتم العثور على بيانات المورد!' : 'Supplier record not found!', 'error');
      return;
    }

    const modalId = 'supp-stmt-modal';
    let modalEl = document.getElementById(modalId);
    if (modalEl) modalEl.remove();

    const suppName = isAR ? (supp.name_ar || supp.name_en) : (supp.name_en || supp.name_ar);

    let syncCfg = { role: 'server', branchId: 'main' };
    try {
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        syncCfg = await BranchSync.getConfig();
      }
    } catch (e) { }
    const isServerNode = syncCfg.role === 'server';
    const myBranch = syncCfg.branchId || 'main';
    const branchFilter = isServerNode ? (requestedBranch || 'all') : myBranch;

    let availableBranches = [];
    if (isServerNode) {
      try {
        if (window.Reports && typeof Reports.getAvailableBranches === 'function') {
          availableBranches = await Reports.getAvailableBranches();
        } else {
          const whs = (await DB.getAll('warehouses')) || [];
          availableBranches = whs.filter(w => w.id !== 1 && (w.code || '').toUpperCase() !== 'WH-01' && !w.is_default).map(w => ({
            id: w.code || w.name,
            label: w.name || w.name_ar || w.code
          }));
        }
      } catch (e) { }
    }

    const { ledger, totalDebit, totalCredit, runningBal } = await SuppliersModule.buildSupplierLedger(supp.id ?? id, isAR, branchFilter);

    modalEl = document.createElement('div');
    modalEl.className = 'modal-overlay open';
    modalEl.id = modalId;
    modalEl.addEventListener('click', (e) => {
      if (e.target === modalEl) Utils.closeModal(modalId);
    });
    modalEl.innerHTML = `
    <div class="modal" style="max-width:920px">
      <div class="modal-header">
        <div class="modal-title">
          📄 ${isAR ? 'كشف حساب مورد: ' : 'Supplier Statement of Account: '} ${Utils.sanitize(suppName)}
        </div>
        <button class="btn-icon" onclick="Utils.closeModal('${modalId}')">✕</button>
      </div>
      <div class="modal-body">

        <!-- Branch Scope Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;background:var(--surface-2);border-radius:8px;padding:8px 14px">
          <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:0.85rem;font-weight:700">🏢 ${isAR ? 'نطاق الفرع:' : 'Branch Scope:'}</span>
            ${isServerNode ? `
              <select class="form-control" style="height:32px;min-width:240px;font-size:0.82rem;font-weight:700" onchange="SuppliersModule.openStatementModal('${supp.id ?? id}', this.value)">
                <option value="all" ${branchFilter === 'all' ? 'selected' : ''}>🌐 ${isAR ? 'كافة الفروع (كشف موحد)' : 'All Branches (Consolidated)'}</option>
                <option value="main" ${branchFilter === 'main' ? 'selected' : ''}>🖥️ ${isAR ? 'الفرع الرئيسي' : 'Main Branch'}</option>
                ${availableBranches.map(b => `<option value="${b.id}" ${branchFilter.toLowerCase() === b.id.toLowerCase() ? 'selected' : ''}>🏬 ${b.label}</option>`).join('')}
              </select>
            ` : `
              <span class="badge badge-primary" style="font-size:0.8rem;padding:4px 10px">🔒 ${myBranch} (${isAR ? 'مقيد بالفرع' : 'Branch Restricted'})</span>
            `}
          </div>
          <div style="font-size:0.8rem;color:var(--text-muted)">
            ${isServerNode ? (branchFilter === 'all' ? (isAR ? 'عرض شامل لكافة فروع المؤسسة' : 'Company-wide Consolidated Statement') : `${isAR ? 'مصفى للفرع:' : 'Filtered to:'} ${branchFilter}`) : (isAR ? 'بيانات هذا الفرع فقط' : 'Own Branch Transactions Only')}
          </div>
        </div>

        <!-- Summary Header Cards -->
        <div class="grid grid-3" style="gap:12px;margin-bottom:16px">
          <div style="background:var(--surface-2);border-radius:8px;padding:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'المورد' : 'Supplier'}</div>
            <div style="font-weight:700;font-size:0.95rem;margin-top:2px">${Utils.sanitize(suppName)}</div>
            <div style="font-size:0.75rem;color:var(--text-secondary);margin-top:2px">📞 ${supp.phone || '-'} ${supp.vat_number ? `| ${isAR ? 'الرقم الضريبي: ' : 'VAT: '}${supp.vat_number}` : ''}</div>
          </div>
          <div style="background:var(--surface-2);border-radius:8px;padding:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR ? 'شروط الدفع / العملة' : 'Terms / Currency'}</div>
            <div style="font-weight:700;font-size:0.95rem;margin-top:2px;color:var(--info)">${supp.payment_terms || (isAR ? 'حسب الاتفاق' : 'Standard')} (${supp.currency || 'USD'})</div>
          </div>
          <div style="background:var(--surface-2);border-radius:8px;padding:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${branchFilter === 'all' ? (isAR ? 'الرصيد المتبقي المستحق للمورد (كافة الفروع)' : 'Net Supplier Balance Due (All Branches)') : `${isAR ? 'الرصيد المتبقي لفرع' : 'Net Balance for'} ${branchFilter}`}</div>
            <div style="font-weight:900;font-size:1.15rem;margin-top:2px;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</div>
          </div>
        </div>

        <!-- Ledger Table -->
        <div class="table-wrapper" style="max-height:420px;overflow-y:auto">
          <table style="font-size:0.82rem">
            <thead><tr>
              <th>${isAR ? 'التاريخ' : 'Date'}</th>
              <th>${isAR ? 'الرقم' : 'Ref #'}</th>
              <th>${isAR ? 'النوع / البيان' : 'Type / Description'}</th>
              <th style="text-align:right">${isAR ? 'مشتريات (+)' : 'Purchases (+)'}</th>
              <th style="text-align:right">${isAR ? 'مدفوعات/مرتجع (-)' : 'Payments/Returns (-)'}</th>
              <th style="text-align:right">${isAR ? 'الرصيد' : 'Balance'}</th>
              <th style="text-align:center">${isAR ? 'إجراءات' : 'Actions'}</th>
            </tr></thead>
            <tbody>
              ${ledger.map(l => `
              <tr>
                <td style="font-size:0.78rem">${Utils.formatDate(l.date)}</td>
                <td style="font-weight:700;color:var(--primary)">${l.ref}</td>
                <td>${l.type}</td>
                <td style="text-align:right;font-weight:600;color:${l.debit > 0 ? 'var(--danger)' : 'inherit'}">${l.debit > 0 ? Utils.formatMoney(l.debit) : '-'}</td>
                <td style="text-align:right;font-weight:600;color:${l.credit > 0 ? 'var(--success)' : 'inherit'}">${l.credit > 0 ? Utils.formatMoney(l.credit) : '-'}</td>
                <td style="text-align:right;font-weight:800">${Utils.formatMoney(l.balance)}</td>
                <td>
                  <div style="display:flex;gap:4px;justify-content:center">
                    ${(l.isPayment && (l.store === 'cash_transactions' || l.store === 'bank_transactions')) ? `
                      <button class="btn btn-ghost btn-sm" onclick="SuppliersModule.openEditPaymentModal('${l.store}', ${l.id}, ${supp.id})" title="${isAR ? 'تعديل الدفعة' : 'Edit Payment'}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                      <button class="btn btn-ghost btn-sm" onclick="SuppliersModule.deletePaymentTxn('${l.store}', ${l.id}, ${supp.id})" style="color:var(--danger)" title="${isAR ? 'إلغاء وحذف الدفعة' : 'Delete Payment'}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
                      </button>
                    ` : (l.store === 'purchase_invoices' || l.store === 'purchase_returns') ? `
                      <button class="btn btn-ghost btn-sm" onclick="window.Purchasing ? Purchasing.openDoc('${l.store}', ${l.id}) : null" title="${isAR ? 'عرض / تعديل الفاتورة' : 'View / Edit Doc'}">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                    ` : ''}
                  </div>
                </td>
              </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--text-muted)">${isAR ? 'لا توجد حركات لـ هذا المورد' : 'No records found for this supplier'}</td></tr>`}
            </tbody>
            <tfoot>
              <tr style="border-top:2px solid var(--border-color);font-weight:800">
                <td colspan="3" style="padding:10px">${isAR ? 'الإجمالي' : 'Total'}</td>
                <td style="text-align:right;color:var(--danger)">${Utils.formatMoney(totalDebit)}</td>
                <td style="text-align:right;color:var(--success)">${Utils.formatMoney(totalCredit)}</td>
                <td style="text-align:right;color:${runningBal > 0 ? 'var(--danger)' : 'var(--success)'}">${Utils.formatMoney(runningBal)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <div class="modal-footer" style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px">
        <button class="btn btn-ghost" onclick="Utils.closeModal('${modalId}')">${isAR ? 'إغلاق' : 'Close'}</button>
        <div style="display:flex;gap:8px">
          <button class="btn btn-warning" onclick="SuppliersModule.openPaymentModal(${id})">
            💵 ${isAR ? 'دفع للمورد' : 'Pay Supplier'}
          </button>
          <button class="btn btn-secondary" onclick="SuppliersModule.printStatement(${id}, '80mm')">
            🧾 ${isAR ? 'طباعة إيصال (80mm)' : 'Thermal (80mm)'}
          </button>
          <button class="btn btn-primary" onclick="SuppliersModule.printStatement(${id}, 'A4')">
            📄 ${isAR ? 'طباعة كشف A4' : 'A4 Statement'}
          </button>
        </div>
      </div>
    </div>
  `;
    document.body.appendChild(modalEl);
  } catch (err) {
    console.error('[Statement] Error opening supplier statement modal:', err);
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    Utils.toast(isAR ? 'حدث خطأ أثناء فتح كشف الحساب: ' + err.message : 'Error opening statement: ' + err.message, 'error');
  }
};



const Suppliers = {
  render: (c) => SuppliersModule.render(c),
};

window.SuppliersModule = SuppliersModule;
window.suppliersModule = SuppliersModule;
window.Suppliers = Suppliers;
window.suppliers = Suppliers;

// Auto-refresh customers and suppliers tables when background sync updates records
window.addEventListener('redshark_sync_complete', async (e) => {
  try {
    const tbl = e.detail?.table;
    if (!tbl || tbl === 'customers' || tbl === 'all') {
      const tbody = document.getElementById('customers-tbody');
      if (tbody && window.CustomersModule && typeof CustomersModule.refresh === 'function') {
        await CustomersModule.refresh();
      }
    }
    if (!tbl || tbl === 'suppliers' || tbl === 'all') {
      const tbody = document.getElementById('suppliers-tbody');
      if (tbody && window.SuppliersModule && typeof SuppliersModule.refresh === 'function') {
        await SuppliersModule.refresh();
      }
    }
  } catch (err) { }
});

