/* ================================================================
   Red Shark POS — AI Business Copilot & Predictive Intelligence
   ================================================================ */

const AICopilot = (() => {
  let _audioCtx = null;

  function _getAudioContext() {
    if (!_audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) _audioCtx = new AudioCtx();
    }
    if (_audioCtx && _audioCtx.state === 'suspended') {
      _audioCtx.resume();
    }
    return _audioCtx;
  }

  // ── Web Audio Haptics ──────────────────────────────────────────
  function playAudio(type = 'scan') {
    try {
      const ctx = _getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      if (type === 'scan') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1800, now);
        osc.frequency.exponentialRampToValueAtTime(2400, now + 0.05);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'success' || type === 'pay') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.16); // G5
        osc.frequency.setValueAtTime(1046.50, now + 0.24); // C6
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
        osc.start(now);
        osc.stop(now + 0.45);
      } else if (type === 'error' || type === 'warning') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.setValueAtTime(220, now + 0.1);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
      }
    } catch (e) {
      console.warn('Audio feedback skipped:', e);
    }
  }

  function _isAppArabic() {
    try {
      if (typeof window !== 'undefined' && window.i18n && typeof window.i18n.getLang === 'function') {
        return window.i18n.getLang() === 'ar';
      }
      if (typeof i18n !== 'undefined' && typeof i18n.getLang === 'function') {
        return i18n.getLang() === 'ar';
      }
      if (typeof document !== 'undefined' && document.documentElement && document.documentElement.lang === 'ar') {
        return true;
      }
    } catch(e) {}
    return false;
  }

  // ── Unified Sales Helper (POS 'sales' + Backoffice 'sales_invoice') ──
  async function _getAllSales() {
    let posSales = [];
    let invSales = [];
    try {
      posSales = (await DB.getAll('sales')) || [];
    } catch(e) {}
    try {
      invSales = (await DB.getAll('sales_invoice')) || [];
    } catch(e) {}

    let combined = [
      ...posSales.map(s => ({ ...s, _source: 'pos' })),
      ...invSales.map(s => ({ ...s, _source: 'invoice' }))
    ];

    // Branch Isolation for AI Copilot
    let syncCfg = { role: 'server', branchId: 'main' };
    try {
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        syncCfg = await BranchSync.getConfig();
      }
    } catch(e) {}
    if (syncCfg.role !== 'server') {
      const myBranch = (syncCfg.branchId || 'main').toLowerCase();
      combined = combined.filter(s => {
        const b = String(s.branch_id || s.syncBranchId || '').trim().toLowerCase();
        return b === myBranch || (!b && myBranch === 'main');
      });
    }

    return combined.map(s => {
      let items = [];
      if (Array.isArray(s.items)) {
        items = s.items;
      } else if (typeof s.items === 'string') {
        try { items = JSON.parse(s.items); } catch(e) { items = []; }
      }

      // Parse invoice date reliably across ISO, local, and custom formats
      const rawDate = s.created_at || s.date || s.doc_date || s.timestamp || s.invoice_date || '';
      const dateObj = _parseInvoiceDate(rawDate);

      // POS sales use grand_total, backoffice uses total_usd or grand_total
      const total = parseFloat(s.grand_total ?? s.total ?? s.total_usd ?? s.net_amount ?? 0) || 0;

      return {
        ...s,
        _items: items,
        _rawDate: rawDate,
        _dateObj: dateObj,
        _total: total
      };
    });
  }

  // ── Robust Invoice Date Parser ──────────────────────────────────
  function _parseInvoiceDate(rawDate, dateObj) {
    if (dateObj instanceof Date && !isNaN(dateObj.getTime())) {
      return dateObj;
    }
    if (!rawDate) return null;
    if (typeof rawDate === 'number') {
      const d = new Date(rawDate);
      return isNaN(d.getTime()) ? null : d;
    }
    const str = String(rawDate).trim();
    if (!str) return null;

    // 1. Try standard ISO or parseable date string
    const std = new Date(str);
    if (!isNaN(std.getTime())) return std;

    // 2. Try DD/MM/YYYY or DD-MM-YYYY
    const dmy = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})(?:\s+(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
    if (dmy) {
      const d = parseInt(dmy[1], 10);
      const m = parseInt(dmy[2], 10) - 1;
      const y = parseInt(dmy[3], 10);
      const hr = parseInt(dmy[4] || 0, 10);
      const min = parseInt(dmy[5] || 0, 10);
      const sec = parseInt(dmy[6] || 0, 10);
      const parsed = new Date(y, m, d, hr, min, sec);
      if (!isNaN(parsed.getTime())) return parsed;
    }

    // 3. Try YYYY/MM/DD or YYYY-MM-DD
    const ymd = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/);
    if (ymd) {
      const y = parseInt(ymd[1], 10);
      const m = parseInt(ymd[2], 10) - 1;
      const d = parseInt(ymd[3], 10);
      const parsed = new Date(y, m, d);
      if (!isNaN(parsed.getTime())) return parsed;
    }

    return null;
  }

  function _parseDateString(str) {
    if (!str) return null;
    str = String(str).trim();
    const ymd = str.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
    if (ymd) {
      return new Date(parseInt(ymd[1], 10), parseInt(ymd[2], 10) - 1, parseInt(ymd[3], 10));
    }
    const dmy = str.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (dmy) {
      return new Date(parseInt(dmy[3], 10), parseInt(dmy[2], 10) - 1, parseInt(dmy[1], 10));
    }
    const dm = str.match(/^(\d{1,2})[\/\-](\d{1,2})$/);
    if (dm) {
      const now = new Date();
      return new Date(now.getFullYear(), parseInt(dm[2], 10) - 1, parseInt(dm[1], 10));
    }
    const d = new Date(str);
    return isNaN(d.getTime()) ? null : d;
  }

  function _formatLocalDate(d) {
    if (!d || isNaN(d.getTime())) return '';
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  // ── Intelligent Universal Timeframe & Period Resolver ──────────
  function _parseTimeframeFilter(query, allSales, lang) {
    const q = (query || '').toLowerCase().trim();
    const isAR = lang === 'ar';
    const isFR = lang === 'fr';
    const isES = lang === 'es';
    const isTR = lang === 'tr';

    const now = new Date();
    const currentYear = now.getFullYear();

    let startDate = null;
    let endDate = null;
    let isAllTime = false;
    let type = 'today';
    let labelAR = 'اليوم';
    let labelEN = "Today's";

    // 1. Explicit Custom Date Range (e.g. from 2026-09-01 to 2026-09-15 or من 1/9/2026 الى 15/9/2026)
    const datePat = '(\\d{4}[\\/\\-]\\d{1,2}[\\/\\-]\\d{1,2}|\\d{1,2}[\\/\\-]\\d{1,2}[\\/\\-]\\d{4}|\\d{1,2}[\\/\\-]\\d{1,2})';
    const rangeRegex = new RegExp('(?:from|between|من|بين)\\s+' + datePat + '\\s+(?:to|and|الى|إلى|ل|حتى|و)\\s+' + datePat, 'i');
    const simpleRangeRegex = new RegExp(datePat + '\\s*(?:\\s+to\\s+|\\s*\\-\\s*|\\s+الى\\s+|\\s+إلى\\s+)' + datePat, 'i');

    let mRange = q.match(rangeRegex) || q.match(simpleRangeRegex);
    if (mRange) {
      const d1 = _parseDateString(mRange[1]);
      const d2 = _parseDateString(mRange[2]);
      if (d1 && d2) {
        startDate = new Date(Math.min(d1.getTime(), d2.getTime()));
        startDate.setHours(0, 0, 0, 0);
        endDate = new Date(Math.max(d1.getTime(), d2.getTime()));
        endDate.setHours(23, 59, 59, 999);
        type = 'custom_range';
        const d1Str = _formatLocalDate(startDate);
        const d2Str = _formatLocalDate(endDate);
        labelAR = `من ${d1Str} إلى ${d2Str}`;
        labelEN = `From ${d1Str} to ${d2Str}`;
      }
    }

    // 2. Single Specific Date (e.g. on 2026-09-18, بتاريخ 18/9/2026, for 2026-09-15)
    if (!startDate) {
      const singleDateRegex = new RegExp('(?:on|date|for|بتاريخ|يوم|تاريخ)\\s+' + datePat, 'i');
      let sm = q.match(singleDateRegex);
      if (!sm) {
        const fullDate = q.match(/(\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})/);
        if (fullDate) sm = fullDate;
      }
      if (sm) {
        const parsedSingle = _parseDateString(sm[1]);
        if (parsedSingle) {
          startDate = new Date(parsedSingle);
          startDate.setHours(0, 0, 0, 0);
          endDate = new Date(parsedSingle);
          endDate.setHours(23, 59, 59, 999);
          type = 'single_date';
          const dStr = _formatLocalDate(startDate);
          labelAR = `بتاريخ ${dStr}`;
          labelEN = `Date: ${dStr}`;
        }
      }
    }

    // 3. Last N Days (e.g. last 5 days, past 7 days, آخر 5 أيام)
    if (!startDate) {
      const nDaysMatch = q.match(/(?:last|past)\s+(\d+)\s+days?/i) || q.match(/(?:آخر|اخر)\s+(\d+)\s*(?:أيام|ايام|يوم)/);
      if (nDaysMatch) {
        const daysCount = parseInt(nDaysMatch[1], 10);
        if (daysCount > 0 && daysCount <= 3650) {
          startDate = new Date();
          startDate.setDate(startDate.getDate() - daysCount);
          startDate.setHours(0, 0, 0, 0);
          endDate = new Date();
          endDate.setHours(23, 59, 59, 999);
          type = 'past_n_days';
          labelAR = `آخر ${daysCount} أيام`;
          labelEN = `Past ${daysCount} Days`;
        }
      }
    }

    // 4. Specific Month by name or number (e.g. september, شهر 8, أيلول)
    if (!startDate) {
      const monthsEn = ['january','february','march','april','may','june','july','august','september','october','november','december'];
      const monthsAr = ['يناير','فبراير','مارس','أبريل','ابريل','مايو','يونيو','يوليو','أغسطس','اغسطس','سبتمبر','أكتوبر','اكتوبر','نوفمبر','ديسمبر'];
      const monthsLevant = ['كانون الثاني','شباط','آذار','اذار','نيسان','أيار','ايار','حزيران','تموز','آب','اب','أيلول','ايلول','تشرين الأول','تشرين الاول','تشرين الثاني','كانون الأول','كانون الاول'];
      
      let foundMonth = -1;
      let monthNameDisplay = '';
      for (let i = 0; i < 12; i++) {
        if (q.includes(monthsEn[i]) || q.includes(monthsAr[i]) || q.includes(monthsLevant[i])) {
          foundMonth = i;
          monthNameDisplay = isAR ? monthsAr[i] : monthsEn[i].charAt(0).toUpperCase() + monthsEn[i].slice(1);
          break;
        }
      }
      if (foundMonth === -1) {
        const monthNumMatch = q.match(/(?:month|شهر)\s+(\d{1,2})/);
        if (monthNumMatch) {
          const mn = parseInt(monthNumMatch[1], 10);
          if (mn >= 1 && mn <= 12) {
            foundMonth = mn - 1;
            monthNameDisplay = isAR ? monthsAr[foundMonth] : monthsEn[foundMonth].charAt(0).toUpperCase() + monthsEn[foundMonth].slice(1);
          }
        }
      }

      if (foundMonth !== -1) {
        startDate = new Date(currentYear, foundMonth, 1, 0, 0, 0, 0);
        endDate = new Date(currentYear, foundMonth + 1, 0, 23, 59, 59, 999);
        type = 'specific_month';
        labelAR = `شهر ${monthNameDisplay} ${currentYear}`;
        labelEN = `${monthNameDisplay} ${currentYear}`;
      }
    }

    // 5. Last Month / Previous Month
    if (!startDate && (
        q.includes('last month') || q.includes('past month') || q.includes('previous month') ||
        q.includes('الشهر الماضي') || q.includes('الشهر السابق') || q.includes('شهر مضى') || q.includes('الشهر اللي فات') ||
        q.includes('mois dernier') || q.includes('mes pasado') || q.includes('geçen ay')
    )) {
      startDate = new Date(currentYear, now.getMonth() - 1, 1, 0, 0, 0, 0);
      endDate = new Date(currentYear, now.getMonth(), 0, 23, 59, 59, 999);
      type = 'last_month';
      labelAR = 'الشهر الماضي';
      labelEN = 'Last Month';
    }

    // 6. This Month / Monthly
    if (!startDate && (
        q.includes('this month') || q.includes('current month') || q.includes('monthly') ||
        q.includes('هذا الشهر') || q.includes('الشهر الحالي') || q.includes('شهري') || q.includes('خلال الشهر') ||
        q.includes('ce mois') || q.includes('este mes') || q.includes('bu ay')
    )) {
      startDate = new Date(currentYear, now.getMonth(), 1, 0, 0, 0, 0);
      endDate = new Date();
      endDate.setHours(23, 59, 59, 999);
      type = 'this_month';
      labelAR = 'هذا الشهر (من أول الشهر)';
      labelEN = 'This Month (Month to Date)';
    }

    // 7. Last Week / Previous Week
    if (!startDate && (
        q.includes('last week') || q.includes('previous week') || q.includes('past week') ||
        q.includes('الاسبوع الماضي') || q.includes('الأسبوع الماضي') || q.includes('الاسبوع السابق') || q.includes('الأسبوع السابق') ||
        q.includes('semaine dernière') || q.includes('semana pasada') || q.includes('geçen hafta')
    )) {
      const dayOfWeek = now.getDay();
      const endLastWeek = new Date(now);
      endLastWeek.setDate(now.getDate() - dayOfWeek - 1);
      endLastWeek.setHours(23, 59, 59, 999);
      const startLastWeek = new Date(endLastWeek);
      startLastWeek.setDate(endLastWeek.getDate() - 6);
      startLastWeek.setHours(0, 0, 0, 0);
      startDate = startLastWeek;
      endDate = endLastWeek;
      type = 'last_week';
      labelAR = 'الأسبوع الماضي';
      labelEN = 'Last Week';
    }

    // 8. This Week / Current Week / Weekly
    if (!startDate && (
        q.includes('this week') || q.includes('current week') || q.includes('weekly') ||
        q.includes('هذا الاسبوع') || q.includes('هذا الأسبوع') || q.includes('الاسبوع الحالي') || q.includes('الأسبوع الحالي') ||
        q.includes('أسبوعي') || q.includes('اسبوعي') || q.includes('خلال الاسبوع') || q.includes('خلال الأسبوع') ||
        q.includes('cette semaine') || q.includes('esta semana') || q.includes('bu hafta')
    )) {
      startDate = new Date();
      startDate.setDate(startDate.getDate() - 7);
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date();
      endDate.setHours(23, 59, 59, 999);
      type = 'this_week';
      labelAR = 'آخر 7 أيام (هذا الأسبوع)';
      labelEN = 'Past 7 Days (This Week)';
    }

    // 9. Last Year
    if (!startDate && (
        q.includes('last year') || q.includes('previous year') ||
        q.includes('السنة الماضية') || q.includes('العام الماضي') || q.includes('السنة السابقة') ||
        q.includes('année dernière') || q.includes('año pasado') || q.includes('geçen yıl')
    )) {
      startDate = new Date(currentYear - 1, 0, 1, 0, 0, 0, 0);
      endDate = new Date(currentYear - 1, 11, 31, 23, 59, 59, 999);
      type = 'last_year';
      labelAR = `العام الماضي (${currentYear - 1})`;
      labelEN = `Last Year (${currentYear - 1})`;
    }

    // 10. This Year / Annual / Yearly
    if (!startDate && (
        q.includes('this year') || q.includes('current year') || q.includes('yearly') || q.includes('annual') ||
        q.includes('هذه السنة') || q.includes('هذا العام') || q.includes('العام الحالي') || q.includes('السنة الحالية') || q.includes('سنوي') ||
        q.includes('cette année') || q.includes('este año') || q.includes('bu yıl')
    )) {
      startDate = new Date(currentYear, 0, 1, 0, 0, 0, 0);
      endDate = new Date();
      endDate.setHours(23, 59, 59, 999);
      type = 'this_year';
      labelAR = `العام الحالي (${currentYear})`;
      labelEN = `This Year (${currentYear})`;
    }

    // 11. Yesterday
    if (!startDate && (
        q.includes('yesterday') || q.includes('أمس') || q.includes('امس') || q.includes('البارحة') || q.includes('مبارح') || q.includes('امبارح') || q.includes('اليوم السابق') ||
        q.includes('hier') || q.includes('ayer') || q.includes('dün')
    )) {
      const yest = new Date();
      yest.setDate(yest.getDate() - 1);
      startDate = new Date(yest);
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date(yest);
      endDate.setHours(23, 59, 59, 999);
      type = 'yesterday';
      labelAR = 'أمس';
      labelEN = 'Yesterday';
    }

    // 12. Explicit Today / Daily (CRUCIAL: matches "daily", "today", "يومي", "اليوم", etc.)
    if (!startDate && (
        q.includes('today') || q.includes('daily') || q.includes('اليوم') || q.includes('يومي') || q.includes('اليومي') ||
        q.includes('يومية') || q.includes('اليومية') || q.includes('النهاردة') || q.includes('نهار اليوم') || q.includes('اليوم الحالي') ||
        q.includes('aujourd') || q.includes('hoy') || q.includes('bugün') || q.includes('günlük')
    )) {
      startDate = new Date();
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date();
      endDate.setHours(23, 59, 59, 999);
      type = 'today';
      labelAR = 'اليوم';
      labelEN = "Today's";
    }

    // 13. Explicit All-Time (ONLY when explicitly requested by words like "كل الأيام", "all time", "من البداية", etc.)
    if (!startDate && (
        q.includes('all time') || q.includes('all days') || q.includes('entire history') || q.includes('all history') ||
        q.includes('كل الايام') || q.includes('كل الأيام') || q.includes('جميع الأيام') || q.includes('جميع الايام') ||
        q.includes('من البداية') || q.includes('تاريخياً') || q.includes('كامل المدة') || q.includes('كل مبيعات') ||
        q.includes('toutes les ventes') || q.includes('todas las ventas') || q.includes('tüm satışlar')
    )) {
      isAllTime = true;
      type = 'all_time';
      labelAR = 'جميع المبيعات (من البداية)';
      labelEN = isFR ? 'Toutes les Ventes (Global)' : (isES ? 'Todas las Ventas (Global)' : (isTR ? 'Tüm Satışlar' : 'All-Time (Entire History)'));
    }

    // 14. Default fallback: TODAY (Default for daily POS operations)
    if (!startDate && !isAllTime) {
      startDate = new Date();
      startDate.setHours(0, 0, 0, 0);
      endDate = new Date();
      endDate.setHours(23, 59, 59, 999);
      type = 'today_default';
      labelAR = 'اليوم';
      labelEN = "Today's";
    }

    // Filter invoices according to resolved range
    let invoices = [];
    if (isAllTime) {
      invoices = allSales;
    } else if (startDate && endDate) {
      invoices = allSales.filter(inv => {
        const d = _parseInvoiceDate(inv._rawDate, inv._dateObj);
        if (!d) return false;
        return d.getTime() >= startDate.getTime() && d.getTime() <= endDate.getTime();
      });
    }

    return {
      invoices,
      labelAR,
      labelEN,
      type,
      isAllTime,
      isToday: type === 'today' || type === 'today_default',
      startDate,
      endDate
    };
  }

  function _isToday(dateObj, rawDate) {
    const d = _parseInvoiceDate(rawDate, dateObj);
    if (!d) return false;
    const now = new Date();
    return d.getFullYear() === now.getFullYear() &&
           d.getMonth() === now.getMonth() &&
           d.getDate() === now.getDate();
  }

  function _isYesterday(dateObj, rawDate) {
    const d = _parseInvoiceDate(rawDate, dateObj);
    if (!d) return false;
    const now = new Date();
    const yest = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    return d.getFullYear() === yest.getFullYear() &&
           d.getMonth() === yest.getMonth() &&
           d.getDate() === yest.getDate();
  }

  function _isPastNDays(dateObj, days) {
    const d = _parseInvoiceDate(null, dateObj);
    if (!d) return false;
    const now = Date.now();
    const diff = now - d.getTime();
    return diff >= 0 && diff <= days * 24 * 60 * 60 * 1000;
  }

  function generateSingleItemAnalytics(item, allSales, isAR) {
    let soldTotal = 0;
    let revTotal = 0;
    const id = String(item.id);
    const code = String(item.item_code || '');

    allSales.forEach(s => {
      (s._items || []).forEach(l => {
        if (String(l.item_id || l.id) === id || (code && String(l.item_code) === code)) {
          const q = parseFloat(l.qty) || 0;
          soldTotal += q;
          revTotal += parseFloat(l.total) || ((parseFloat(l.price || l.unit_price || 0)) * q);
        }
      });
    });

    const stock = parseFloat(item.stock_qty || item.quantity || 0);
    const price = parseFloat(item.selling_price || item.price || 0);
    const cost = parseFloat(item.cost_price || 0);
    const margin = price > 0 && cost > 0 ? Math.round(((price - cost) / price) * 100) : 0;
    const name = Utils.sanitize(isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar));

    return {
      title: isAR ? `📦 تقرير الصنف: ${name}` : `📦 Product Report: ${name}`,
      content: `
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'المخزون المتوفر:':'Available Stock:'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:${stock<=5?'#ef4444':'#22c55e'}">${stock} ${isAR?'قطعة':'units'}</div>
            </div>
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'إجمالي المبيعات (تاريخياً):':'Total Sold (All-Time):'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:var(--primary)">${soldTotal} ${isAR?'قطعة':'units'}</div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;font-size:0.75rem;padding:8px;background:rgba(255,255,255,0.03);border-radius:6px">
            <div>${isAR?'سعر البيع:':'Price:'} <strong>${Utils.formatMoney(price)}</strong></div>
            <div>${isAR?'التكلفة:':'Cost:'} <strong>${cost>0?Utils.formatMoney(cost):`<span style="color:#ef4444">${isAR?'غير محددة':'Not set'}</span>`}</strong></div>
            <div>${isAR?'هامش الربح:':'Margin:'} <strong style="color:#eab308">${margin}%</strong></div>
          </div>
          <div style="margin-top:8px;font-size:0.75rem;color:var(--text-muted)">
            ${isAR ? `إجمالي الإيراد المحقق من هذا الصنف: <strong>${Utils.formatMoney(revTotal)}</strong>` : `Total revenue generated by this item: <strong>${Utils.formatMoney(revTotal)}</strong>`}
          </div>
        </div>
        <button class="btn btn-outline btn-sm" style="width:100%" onclick="App.navigate('items'); AICopilot.close();">
          ✏️ ${isAR ? 'تعديل الصنف في المخزون' : 'Edit Item in Inventory'}
        </button>
      `
    };
  }

  function generateSingleCustomerAnalytics(cust, allSales, isAR) {
    const cId = String(cust.id);
    const custSales = allSales.filter(s => String(s.customer_id || s.customer) === cId);
    const totalSpent = custSales.reduce((sum, s) => sum + s._total, 0);
    const balance = parseFloat(cust.balance || cust.current_balance || 0);
    const name = Utils.sanitize(cust.name || cust.customer_name);

    return {
      title: isAR ? `👥 كشف حساب العميل: ${name}` : `👥 Customer Statement: ${name}`,
      content: `
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'الرصيد / الذمة المستحقة:':'Outstanding Balance:'}</div>
              <div style="font-size:1.2rem;font-weight:800;color:${balance>0?'#ef4444':'#22c55e'}">${Utils.formatMoney(balance)}</div>
            </div>
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'إجمالي المشتريات:':'Total Purchases:'}</div>
              <div style="font-size:1.2rem;font-weight:800;color:var(--primary)">${Utils.formatMoney(totalSpent)}</div>
            </div>
          </div>
          <div style="font-size:0.75rem;color:var(--text-muted);line-height:1.4">
            ${isAR ? `عدد الفواتير المسجلة باسم العميل: <strong>${custSales.length} فاتورة</strong>` : `Total invoices recorded: <strong>${custSales.length} invoices</strong>`}
            ${cust.phone ? ` | 📞 ${cust.phone}` : ''}
          </div>
        </div>
        <button class="btn btn-secondary btn-sm" style="width:100%" onclick="App.navigate('customer-receipts'); AICopilot.close();">
          💵 ${isAR ? 'تسجيل سند قبض لهذا العميل' : 'Receive Payment from Customer'}
        </button>
      `
    };
  }

  async function generateCashboxSummary(isAR) {
    let sessions = [];
    let movements = [];
    try { sessions = (await DB.getAll('cashbox_sessions')) || []; } catch(e) {}
    try { movements = (await DB.getAll('cashbox_movements')) || []; } catch(e) {}

    const openSession = sessions.find(s => s.status === 'open') || sessions[sessions.length - 1];
    const todayStr = new Date().toISOString().split('T')[0];
    const todayMovements = movements.filter(m => (m.created_at || m.date || '').startsWith(todayStr));

    let cashIn = 0;
    let cashOut = 0;
    todayMovements.forEach(m => {
      const a = parseFloat(m.amount) || 0;
      if (m.type === 'in' || m.type === 'sale' || a > 0) cashIn += Math.abs(a);
      else cashOut += Math.abs(a);
    });

    const currentOpening = openSession ? (parseFloat(openSession.opening_amount) || 0) : 0;
    const estimatedBalance = currentOpening + cashIn - cashOut;

    return {
      title: isAR ? '💵 كشف الصندوق وحركة النقدية' : '💵 Cash Drawer & Register Analytics',
      content: `
        <div style="background:var(--surface);border:1px solid var(--border-color);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'الرصيد التقديري في الصندوق:':'Estimated Cash In Drawer:'}</div>
              <div style="font-size:1.2rem;font-weight:800;color:#22c55e">${Utils.formatMoney(estimatedBalance)}</div>
            </div>
            <div>
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'حالة الوردية / الجلسة:':'Register Session Status:'}</div>
              <div style="font-size:1rem;font-weight:800;color:${openSession?.status==='open'?'#38bdf8':'#eab308'}">
                ${openSession?.status === 'open' ? (isAR?'🟢 مفتوحة':'🟢 Open') : (isAR?'⚪ مغلقة':'⚪ Closed')}
              </div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:0.75rem;padding:8px;background:rgba(255,255,255,0.03);border-radius:6px">
            <div>${isAR?'رصيد الافتتاح:':'Opening Float:'} <strong>${Utils.formatMoney(currentOpening)}</strong></div>
            <div>${isAR?'مقبوضات اليوم:':'Today In:'} <strong style="color:#22c55e">+${Utils.formatMoney(cashIn)}</strong></div>
            <div>${isAR?'مدفوعات اليوم:':'Today Out:'} <strong style="color:#ef4444">-${Utils.formatMoney(cashOut)}</strong></div>
            <div>${isAR?'عدد الحركات:':'Movements:'} <strong>${todayMovements.length}</strong></div>
          </div>
        </div>
        <button class="btn btn-secondary btn-sm" style="width:100%" onclick="App.navigate('cashbox'); AICopilot.close();">
          💵 ${isAR ? 'فتح شاشة الصندوق والورديات' : 'Open Cash Drawer Management'}
        </button>
      `
    };
  }

  // ── Multilingual Query Language Detector ─────────────────────────
  function detectQueryLang(text) {
    const q = (text || '').toLowerCase();
    if (/[\u0600-\u06FF]/.test(q)) return 'ar';
    if (/\b(rapport|ventes|bénéfice|benefice|chiffre|facture|combien|aujourd'hui|hier|semaine|mois|imprimer|tous)\b/i.test(q)) return 'fr';
    if (/\b(informe|reporte|ventas|ganancia|factura|cuanto|hoy|ayer|semana|mes|imprimir|todos)\b/i.test(q)) return 'es';
    if (/\b(rapor|satış|satis|kâr|kar|fatura|bugün|dün|hafta|ay|yazdır|hepsi)\b/i.test(q)) return 'tr';
    if (_isAppArabic()) return 'ar';
    return 'en';
  }

  // ── Universal AI Multi-Report Engine & Dynamic Printer ─────────────
  let _lastExecutiveReportData = null;

  async function generateExecutiveAIReport(q, lang, items, allSales, customers) {
    const isAR = lang === 'ar';
    const isFR = lang === 'fr';
    const isES = lang === 'es';
    const isTR = lang === 'tr';

    // ── 1. Specific Report Type Classification ──
    const isStockReport = q.includes('مخزون') || q.includes('stock') || q.includes('inventory') || q.includes('جرد') || q.includes('inventaire') || q.includes('inventario');
    const isPLReport = (q.includes('ارباح') && q.includes('خسائر')) || q.includes('خسارة') || q.includes('p&l') || q.includes('دخل') || q.includes('income statement') || q.includes('profit and loss');
    const isSupplierReport = q.includes('مورد') || q.includes('supplier') || q.includes('fournisseur') || q.includes('مشتريات') || q.includes('purchase') || q.includes('proveedor');
    const isCustomerReport = q.includes('عملاء') || q.includes('عميل') || q.includes('ديون') || q.includes('ذمم') || q.includes('debt') || q.includes('customer') || q.includes('client');
    const isDeadStockReport = q.includes('راكد') || q.includes('dead') || q.includes('stagnant') || q.includes('slow');
    const isCashierReport = q.includes('كاشير') || q.includes('وردية') || q.includes('shift') || q.includes('درج') || q.includes('صندوق') || q.includes('drawer');
    const isRepairsReport = q.includes('صيانة') || q.includes('تصليح') || q.includes('repair') || q.includes('workshop');

    // ── A. Stock & Inventory Valuation Report ──
    if (isStockReport) {
      let totalQty = 0;
      let totalCostValuation = 0;
      let totalRetailValuation = 0;
      let zeroStockCount = 0;
      let lowStockCount = 0;

      const itemsWithValuation = items.map(i => {
        const qty = parseFloat(i.stock_qty || i.quantity || 0);
        const cost = parseFloat(i.cost_price || 0);
        const price = parseFloat(i.price_1 || i.selling_price || i.price || 0);
        const minAlert = parseFloat(i.min_stock_alert || i.alert_qty || 5);
        if (qty <= 0) zeroStockCount++;
        else if (qty <= minAlert) lowStockCount++;

        totalQty += Math.max(0, qty);
        totalCostValuation += Math.max(0, qty * cost);
        totalRetailValuation += Math.max(0, qty * price);

        return {
          id: i.id,
          name: isAR ? (i.name_ar || i.name_en || i.name) : (i.name_en || i.name_ar || i.name),
          qty,
          cost,
          price,
          totalCostVal: qty * cost,
          totalRetailVal: qty * price
        };
      });

      const potentialProfit = Math.max(0, totalRetailValuation - totalCostValuation);
      const topValued = itemsWithValuation.sort((a, b) => b.totalRetailVal - a.totalRetailVal).slice(0, 5);

      _lastExecutiveReportData = {
        reportType: 'stock',
        reportName: isAR ? 'تقرير جرد وتقييم المخزون العام' : 'Inventory Valuation & Stock Audit Report',
        totalItemsCount: items.length,
        totalQty,
        totalCostValuation,
        totalRetailValuation,
        potentialProfit,
        zeroStockCount,
        lowStockCount,
        topValued,
        dateGenerated: new Date().toLocaleString()
      };

      return {
        title: isAR ? '📦 تقرير جرد وتقييم المخزون (Stock Report)' : '📦 Inventory Valuation & Stock Audit Report',
        content: `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:6px">${isAR ? 'القيمة الإجمالية للمخزون:' : 'Inventory Asset Valuation:'}</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
              <div style="background:rgba(255,255,255,0.03);padding:8px;border-radius:6px;border:1px solid var(--border-color)">
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'تقييم بسعر التكلفة':'Valuation (At Cost)'}</div>
                <div style="font-size:1.15rem;font-weight:800;color:#38bdf8">${Utils.formatMoney(totalCostValuation)}</div>
                <div style="font-size:0.68rem;color:var(--text-muted)">${items.length} ${isAR?'صنفاً مسجلاً':'active SKUs'}</div>
              </div>
              <div style="background:rgba(255,255,255,0.03);padding:8px;border-radius:6px;border:1px solid var(--border-color)">
                <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'تقييم بسعر البيع (Retail)':'Valuation (At Retail)'}</div>
                <div style="font-size:1.15rem;font-weight:800;color:#22c55e">${Utils.formatMoney(totalRetailValuation)}</div>
                <div style="font-size:0.68rem;color:#eab308;font-weight:700">+${Utils.formatMoney(potentialProfit)} ${isAR?'أرباح كامنة':'Unrealized Profit'}</div>
              </div>
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;font-size:0.75rem">
            <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color)">
              <span style="color:var(--text-muted)">${isAR?'أصناف نافدة تماماً:':'Out of Stock SKUs:'}</span>
              <div style="font-size:1.05rem;font-weight:800;color:#ef4444">${zeroStockCount}</div>
            </div>
            <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color)">
              <span style="color:var(--text-muted)">${isAR?'أصناف قاربت النفاذ:':'Low Stock SKUs:'}</span>
              <div style="font-size:1.05rem;font-weight:800;color:#facc15">${lowStockCount}</div>
            </div>
          </div>

          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="btn btn-primary btn-sm" style="width:100%;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px" onclick="AICopilot.printExecutiveReport()">
              🖨️ ${isAR ? 'طباعة تقرير جرد وتقييم المخزون (Print / PDF)' : 'Print Official Stock Report (PDF)'}
            </button>
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.renderStockReport(document.getElementById('page-content'));">
              📦 ${isAR ? 'فتح شاشة جرد المخزون التفصيلية' : 'Open Detailed Stock Report'}
            </button>
          </div>
        `
      };
    }

    // ── B. Profit & Loss (P&L) Report ──
    if (isPLReport) {
      const itemMap = new Map();
      items.forEach(i => {
        if (i.id) itemMap.set(String(i.id), i);
        if (i.item_code) itemMap.set(String(i.item_code), i);
      });

      const totalSalesUSD = allSales.reduce((sum, i) => sum + i._total, 0);
      let totalCostUSD = 0;
      allSales.forEach(inv => {
        (inv._items || []).forEach(line => {
          let cost = parseFloat(line.cost_price);
          if (isNaN(cost) || cost === 0) {
            const matched = itemMap.get(String(line.item_id || line.id)) || itemMap.get(String(line.item_code));
            cost = matched ? (parseFloat(matched.cost_price) || 0) : 0;
          }
          totalCostUSD += cost * (parseFloat(line.qty) || 1);
        });
      });

      const grossProfitUSD = Math.max(0, totalSalesUSD - totalCostUSD);

      // Load expenses from cashbox movements if available
      const movements = (await DB.getAll('cashbox_movements')) || [];
      const totalExpenses = movements.filter(m => m.type === 'out' || m.type === 'expense').reduce((s, m) => s + (parseFloat(m.amount) || 0), 0);
      const netOperatingIncome = grossProfitUSD - totalExpenses;
      const netMarginPct = totalSalesUSD > 0 ? ((netOperatingIncome / totalSalesUSD) * 100).toFixed(1) : 0;

      _lastExecutiveReportData = {
        reportType: 'pl',
        reportName: isAR ? 'قائمة الدخل والأرباح والخسائر الشاملة' : 'Comprehensive Profit & Loss Statement',
        totalSalesUSD,
        totalCostUSD,
        grossProfitUSD,
        totalExpenses,
        netOperatingIncome,
        netMarginPct,
        dateGenerated: new Date().toLocaleString()
      };

      return {
        title: isAR ? '📈 تقرير قائمة الدخل والأرباح والخسائر (P&L)' : '📈 Profit & Loss Statement (P&L)',
        content: `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.06);font-size:0.8rem">
              <span>${isAR?'إجمالي الإيرادات (Sales):':'Total Revenue:'}</span>
              <strong style="color:#22c55e">${Utils.formatMoney(totalSalesUSD)}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.06);font-size:0.8rem">
              <span>${isAR?'تكلفة البضاعة المباعة (COGS):':'Cost of Goods Sold:'}</span>
              <strong style="color:#ef4444">-${Utils.formatMoney(totalCostUSD)}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.1);font-size:0.85rem">
              <span>${isAR?'مجمل الربح (Gross Profit):':'Gross Profit:'}</span>
              <strong style="color:#38bdf8">${Utils.formatMoney(grossProfitUSD)}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.06);font-size:0.8rem">
              <span>${isAR?'المصاريف التشغيلية (Expenses):':'Operating Expenses:'}</span>
              <strong style="color:#f87171">-${Utils.formatMoney(totalExpenses)}</strong>
            </div>
            <div style="display:flex;justify-content:space-between;padding:8px 0;font-size:0.95rem;background:rgba(255,255,255,0.04);margin-top:4px;border-radius:4px;padding:6px 8px">
              <strong>${isAR?'صافي الدخل والربح (Net Income):':'Net Operating Profit:'}</strong>
              <strong style="color:${netOperatingIncome>=0?'#22c55e':'#ef4444'}">${Utils.formatMoney(netOperatingIncome)} (${netMarginPct}%)</strong>
            </div>
          </div>

          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="btn btn-primary btn-sm" style="width:100%;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px" onclick="AICopilot.printExecutiveReport()">
              🖨️ ${isAR ? 'طباعة تقرير الأرباح والخسائر الرسمي (Print / PDF)' : 'Print Official P&L Statement (PDF)'}
            </button>
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.renderPLReport(document.getElementById('page-content'));">
              📊 ${isAR ? 'فتح شاشة الأرباح والخسائر الكاملة' : 'Open Full P&L Statement'}
            </button>
          </div>
        `
      };
    }

    // ── C. Suppliers & Payables Report ──
    if (isSupplierReport) {
      const suppliers = (await DB.getAll('suppliers')) || [];
      const totalPayables = suppliers.reduce((s, sup) => s + Math.max(0, parseFloat(sup.balance || sup.current_balance || 0)), 0);
      const activeSuppliers = suppliers.filter(s => parseFloat(s.balance || s.current_balance || 0) > 0).sort((a, b) => parseFloat(b.balance||0) - parseFloat(a.balance||0));

      _lastExecutiveReportData = {
        reportType: 'supplier',
        reportName: isAR ? 'تقرير ذمم ومستحقات الموردين والمشتريات' : 'Supplier Payables & Procurement Report',
        totalSuppliersCount: suppliers.length,
        totalPayables,
        activeSuppliers: activeSuppliers.slice(0, 10),
        dateGenerated: new Date().toLocaleString()
      };

      return {
        title: isAR ? '🚚 تقرير ذمم ومستحقات الموردين' : '🚚 Supplier Payables & Procurement Report',
        content: `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'إجمالي المستحقات والديون للموردين:':'Total Accounts Payable:'}</div>
            <div style="font-size:1.3rem;font-weight:800;color:#ef4444">${Utils.formatMoney(totalPayables)}</div>
            <div style="font-size:0.7rem;color:var(--text-muted)">${suppliers.length} ${isAR?'موردين مسجلين':'registered suppliers'} (${activeSuppliers.length} ${isAR?'عليهم رصيد مستحق':'with pending balances'})</div>
          </div>

          ${activeSuppliers.length > 0 ? `
            <div style="font-size:0.75rem;font-weight:700;margin-bottom:6px;color:#eab308">📑 ${isAR?'أعلى الموردين المستحق لهم أرصدة:':'Top Creditor Suppliers:'}</div>
            <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px;font-size:0.75rem;display:flex;flex-direction:column;gap:4px">
              ${activeSuppliers.slice(0, 5).map((sup, idx) => `
                <div style="display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.05);padding:3px 0">
                  <span>${idx+1}. <strong>${Utils.sanitize(sup.name || sup.supplier_name)}</strong></span>
                  <span style="color:#ef4444;font-weight:700">${Utils.formatMoney(parseFloat(sup.balance || sup.current_balance || 0))}</span>
                </div>
              `).join('')}
            </div>
          ` : `<p style="color:#22c55e;font-size:0.8rem;margin-bottom:10px">${isAR?'جميع حسابات الموردين مسددة بالكامل ولا توجد ديون.':'All supplier accounts are fully settled.'}</p>`}

          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="btn btn-primary btn-sm" style="width:100%;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px" onclick="AICopilot.printExecutiveReport()">
              🖨️ ${isAR ? 'طباعة كشف ذمم الموردين (Print / PDF)' : 'Print Supplier Payables Ledger (PDF)'}
            </button>
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.renderSupplierLedger(document.getElementById('page-content'));">
              📋 ${isAR ? 'فتح دفتر أستاذ الموردين الكامل' : 'Open Supplier Ledger'}
            </button>
          </div>
        `
      };
    }

    // ── D. Customer Accounts & Receivables Report ──
    if (isCustomerReport) {
      const debtors = (customers || []).filter(c => parseFloat(c.balance || c.current_balance || 0) > 0).sort((a, b) => parseFloat(b.balance||0) - parseFloat(a.balance||0));
      const totalReceivables = debtors.reduce((s, c) => s + parseFloat(c.balance || c.current_balance || 0), 0);

      _lastExecutiveReportData = {
        reportType: 'customer',
        reportName: isAR ? 'تقرير أعمار ديون وذمم العملاء' : 'Customer Aging & Receivables Report',
        totalCustomersCount: customers.length,
        totalReceivables,
        debtors: debtors.slice(0, 10),
        dateGenerated: new Date().toLocaleString()
      };

      return {
        title: isAR ? '👥 تقرير ديون وذمم العملاء (Receivables)' : '👥 Customer Aging & Receivables Report',
        content: `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'إجمالي الديون المستحقة على العملاء:':'Total Accounts Receivable:'}</div>
            <div style="font-size:1.3rem;font-weight:800;color:#ef4444">${Utils.formatMoney(totalReceivables)}</div>
            <div style="font-size:0.7rem;color:var(--text-muted)">${customers.length} ${isAR?'عميلاً مسجلاً':'customers'} (${debtors.length} ${isAR?'عليهم مبالغ آجلة':'with pending balance'})</div>
          </div>

          ${debtors.length > 0 ? `
            <div style="font-size:0.75rem;font-weight:700;margin-bottom:6px;color:#eab308">👥 ${isAR?'أعلى العملاء المدينين:':'Top Outstanding Debtors:'}</div>
            <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px;font-size:0.75rem;display:flex;flex-direction:column;gap:4px">
              ${debtors.slice(0, 5).map((c, idx) => `
                <div style="display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.05);padding:3px 0">
                  <span>${idx+1}. <strong>${Utils.sanitize(c.name || c.customer_name)}</strong></span>
                  <span style="color:#ef4444;font-weight:700">${Utils.formatMoney(parseFloat(c.balance || c.current_balance || 0))}</span>
                </div>
              `).join('')}
            </div>
          ` : `<p style="color:#22c55e;font-size:0.8rem;margin-bottom:10px">${isAR?'لا توجد ديون مستحقة على العملاء حالياً.':'No outstanding customer debt.'}</p>`}

          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="btn btn-primary btn-sm" style="width:100%;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px" onclick="AICopilot.printExecutiveReport()">
              🖨️ ${isAR ? 'طباعة كشف ذمم وديون العملاء (Print / PDF)' : 'Print Customer Receivables Report (PDF)'}
            </button>
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.renderCustomerLedger(document.getElementById('page-content'));">
              📋 ${isAR ? 'فتح دفتر أستاذ العملاء' : 'Open Customer Ledger'}
            </button>
          </div>
        `
      };
    }

    // ── E. Dead / Stagnant Stock Report ──
    if (isDeadStockReport) {
      const now = new Date();
      const past30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const soldItemIds = new Set();

      allSales.forEach(inv => {
        if (inv._dateObj && inv._dateObj >= past30Days) {
          (inv._items || []).forEach(l => {
            if (l.item_id) soldItemIds.add(String(l.item_id));
            if (l.id) soldItemIds.add(String(l.id));
            if (l.item_code) soldItemIds.add(String(l.item_code));
          });
        }
      });

      const stagnant = items.filter(i => {
        const id = String(i.id);
        const code = String(i.item_code);
        const stock = parseFloat(i.stock_qty || i.quantity || 0);
        return stock > 0 && !soldItemIds.has(id) && !soldItemIds.has(code);
      }).map(i => {
        const stock = parseFloat(i.stock_qty || i.quantity || 0);
        const cost = parseFloat(i.cost_price || 0);
        return {
          name: isAR ? (i.name_ar || i.name_en || i.name) : (i.name_en || i.name_ar || i.name),
          stock,
          cost,
          trappedCash: stock * cost
        };
      }).sort((a, b) => b.trappedCash - a.trappedCash);

      const totalTrapped = stagnant.reduce((s, i) => s + i.trappedCash, 0);

      _lastExecutiveReportData = {
        reportType: 'dead_stock',
        reportName: isAR ? 'تقرير الأصناف الراكدة ورأس المال المجمد' : 'Dead Stock & Stagnant Inventory Report',
        stagnantCount: stagnant.length,
        totalTrapped,
        topStagnant: stagnant.slice(0, 10),
        dateGenerated: new Date().toLocaleString()
      };

      return {
        title: isAR ? '📦 تقرير الأصناف الراكدة والمخزون المجمد' : '📦 Dead Stock & Dormant Capital Report',
        content: `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'رأس المال المجمد في بضاعة راكدة (30+ يوم):':'Capital Trapped in Dead Stock (30+ days):'}</div>
            <div style="font-size:1.3rem;font-weight:800;color:#facc15">${Utils.formatMoney(totalTrapped)}</div>
            <div style="font-size:0.7rem;color:var(--text-muted)">${stagnant.length} ${isAR?'صنفاً في المخزن لم يباع منها شيء منذ 30 يوماً':'items with zero movement in 30 days'}</div>
          </div>

          ${stagnant.length > 0 ? `
            <div style="font-size:0.75rem;font-weight:700;margin-bottom:6px;color:#eab308">⚠️ ${isAR?'أعلى أصناف تحبس سيولة نقدية:':'Top Stagnant Capital Items:'}</div>
            <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px;font-size:0.75rem;display:flex;flex-direction:column;gap:4px">
              ${stagnant.slice(0, 5).map((it, idx) => `
                <div style="display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.05);padding:3px 0">
                  <span>${idx+1}. <strong>${Utils.sanitize(it.name)}</strong> (${it.stock} ${isAR?'قطعة':'pcs'})</span>
                  <span style="color:#facc15;font-weight:700">${Utils.formatMoney(it.trappedCash)}</span>
                </div>
              `).join('')}
            </div>
          ` : `<p style="color:#22c55e;font-size:0.8rem;margin-bottom:10px">${isAR?'ممتاز! لا يوجد مخزون راكد في متجرك.':'Optimal! No dead inventory detected.'}</p>`}

          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="btn btn-primary btn-sm" style="width:100%;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px" onclick="AICopilot.printExecutiveReport()">
              🖨️ ${isAR ? 'طباعة تقرير الأصناف الراكدة (Print / PDF)' : 'Print Dead Stock Report (PDF)'}
            </button>
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.renderDeadStockReport(document.getElementById('page-content'));">
              📦 ${isAR ? 'فتح تقرير الراكد في لوحة التقارير' : 'Open Dead Stock Screen'}
            </button>
          </div>
        `
      };
    }

    // ── F. Universal Executive Business Report (Default / General) ──
    const tf = _parseTimeframeFilter(q, allSales, lang);
    const targetInvoices = tf.invoices;
    const periodName = isAR ? tf.labelAR : tf.labelEN;

    const itemMap = new Map();
    items.forEach(i => {
      if (i.id) itemMap.set(String(i.id), i);
      if (i.item_code) itemMap.set(String(i.item_code), i);
    });

    const totalSalesUSD = targetInvoices.reduce((sum, i) => sum + i._total, 0);
    const invoiceCount = targetInvoices.length;
    let totalCostUSD = 0;
    const itemSalesSummary = {};

    targetInvoices.forEach(i => {
      (i._items || []).forEach(line => {
        let cost = parseFloat(line.cost_price);
        if (isNaN(cost) || cost === 0) {
          const matched = itemMap.get(String(line.item_id || line.id)) || itemMap.get(String(line.item_code));
          cost = matched ? (parseFloat(matched.cost_price) || 0) : 0;
        }
        const qty = parseFloat(line.qty) || 1;
        totalCostUSD += cost * qty;

        const name = (isAR ? (line.name_ar || line.name_en || line.name) : (line.name_en || line.name_ar || line.name)) || 'Item';
        if (!itemSalesSummary[name]) {
          itemSalesSummary[name] = { qty: 0, rev: 0, cost: 0 };
        }
        itemSalesSummary[name].qty += qty;
        itemSalesSummary[name].rev += (parseFloat(line.total) || ((parseFloat(line.price || line.unit_price || 0)) * qty));
        itemSalesSummary[name].cost += (cost * qty);
      });
    });

    const grossProfitUSD = Math.max(0, totalSalesUSD - totalCostUSD);
    const marginPct = totalSalesUSD > 0 ? ((grossProfitUSD / totalSalesUSD) * 100).toFixed(1) : 0;
    const avgBasket = invoiceCount > 0 ? (totalSalesUSD / invoiceCount) : 0;

    const topItems = Object.entries(itemSalesSummary)
      .map(([name, d]) => ({ name, ...d, profit: Math.max(0, d.rev - d.cost) }))
      .sort((a, b) => b.rev - a.rev)
      .slice(0, 5);

    const lowStockItems = items.filter(i => {
      const stock = parseFloat(i.stock_qty || i.quantity || 0);
      const min = parseFloat(i.min_stock_alert || i.alert_qty || 5);
      return stock <= min;
    });

    const totalCustomerDebt = (customers || []).reduce((s, c) => s + Math.max(0, parseFloat(c.balance || c.current_balance || 0)), 0);

    _lastExecutiveReportData = {
      reportType: 'executive',
      reportName: isAR ? 'التقرير التنفيذي الشامل للعمليات والأرباح' : 'Executive Business Performance Report',
      periodName,
      totalSalesUSD,
      invoiceCount,
      totalCostUSD,
      grossProfitUSD,
      marginPct,
      avgBasket,
      topItems,
      totalItemsCount: items.length,
      lowStockCount: lowStockItems.length,
      totalCustomerDebt,
      dateGenerated: new Date().toLocaleString()
    };

    const reportTitle = isAR ? `📑 تقرير تنفيذي شامل (${periodName})` : 
                        (isFR ? `📑 Rapport Exécutif des Affaires (${periodName})` : 
                        (isES ? `📑 Informe Ejecutivo de Negocio (${periodName})` : 
                        (isTR ? `📑 Yönetici İş Raporu (${periodName})` : 
                        `📑 AI Executive Business Report (${periodName})`)));

    return {
      title: reportTitle,
      content: `
        <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
          <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:6px">${isAR ? 'المؤشرات المالية الرئيسية (KPIs):' : 'Key Performance Indicators (KPIs):'}</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <div style="background:rgba(255,255,255,0.03);padding:8px;border-radius:6px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'المبيعات':'Sales'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:#22c55e">${Utils.formatMoney(totalSalesUSD)}</div>
              <div style="font-size:0.68rem;color:var(--text-muted)">${invoiceCount} ${isAR?'فاتورة':'invoices'}</div>
            </div>
            <div style="background:rgba(255,255,255,0.03);padding:8px;border-radius:6px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'الأرباح والهامش':'Gross Profit & Margin'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:#38bdf8">${Utils.formatMoney(grossProfitUSD)}</div>
              <div style="font-size:0.68rem;color:#eab308;font-weight:700">${marginPct}% ${isAR?'هامش ربح':'margin'}</div>
            </div>
            <div style="background:rgba(255,255,255,0.03);padding:8px;border-radius:6px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'تكلفة المبيعات (COGS)':'Total Cost (COGS)'}</div>
              <div style="font-size:0.95rem;font-weight:800;color:#f87171">${Utils.formatMoney(totalCostUSD)}</div>
            </div>
            <div style="background:rgba(255,255,255,0.03);padding:8px;border-radius:6px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'متوسط الفاتورة':'Average Ticket'}</div>
              <div style="font-size:0.95rem;font-weight:800;color:#a855f7">${Utils.formatMoney(avgBasket)}</div>
            </div>
          </div>
        </div>

        ${topItems.length > 0 ? `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="font-size:0.75rem;font-weight:700;margin-bottom:6px;color:#eab308">🏆 ${isAR ? 'أعلى الأصناف إيراداً للفترة:' : 'Top Performing Items:'}</div>
            <div style="font-size:0.75rem;display:flex;flex-direction:column;gap:4px">
              ${topItems.map((item, idx) => `
                <div style="display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.05);padding:3px 0">
                  <span>${idx+1}. <strong>${Utils.sanitize(item.name)}</strong> (${item.qty} ${isAR?'قطعة':'pcs'})</span>
                  <span style="color:#22c55e;font-weight:700">${Utils.formatMoney(item.rev)}</span>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;font-size:0.75rem">
          <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color)">
            <span style="color:var(--text-muted)">${isAR ? 'أصناف قاربت النفاذ:' : 'Low Stock SKUs:'}</span>
            <div style="font-size:1.05rem;font-weight:800;color:${lowStockItems.length>0?'#ef4444':'#22c55e'}">${lowStockItems.length}</div>
          </div>
          <div style="background:var(--surface);padding:8px;border-radius:8px;border:1px solid var(--border-color)">
            <span style="color:var(--text-muted)">${isAR ? 'ديون وذمم العملاء:' : 'Total Receivables:'}</span>
            <div style="font-size:1.05rem;font-weight:800;color:#ef4444">${Utils.formatMoney(totalCustomerDebt)}</div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:6px">
          <button class="btn btn-primary btn-sm" style="width:100%;font-weight:700;display:flex;align-items:center;justify-content:center;gap:6px" onclick="AICopilot.printExecutiveReport()">
            🖨️ ${isAR ? 'طباعة التقرير التنفيذي الرسمي (Print / PDF)' : 'Print Executive Report (PDF)'}
          </button>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.switchSubTab('invoices');">
              📊 ${isAR ? 'فواتير المبيعات' : 'Sales Invoices'}
            </button>
            <button class="btn btn-secondary btn-sm" style="font-size:0.72rem" onclick="App.navigate('reports'); AICopilot.close(); Reports.renderPLReport(document.getElementById('page-content'));">
              📈 ${isAR ? 'الأرباح والخسائر' : 'P&L Statement'}
            </button>
          </div>
        </div>
      `
    };
  }

  async function printExecutiveReport() {
    if (!_lastExecutiveReportData) {
      Utils.toast(_isAppArabic() ? 'لا يوجد تقرير جاهز للطباعة' : 'No report data available to print.', 'warning');
      return;
    }
    const d = _lastExecutiveReportData;
    const isAR = _isAppArabic();
    const compName = (await DB.getSetting(isAR ? 'company_name_ar' : 'company_name', '')) || 'Red Shark Business';
    const phone = (await DB.getSetting('company_phone', '')) || '';

    let contentHtml = '';

    if (d.reportType === 'stock') {
      contentHtml = `
        <div class="kpi-grid" style="grid-template-columns: repeat(3, 1fr);">
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'تقييم المخزون بالتكلفة':'Valuation (Cost)'}</div>
            <div class="kpi-val" style="color:#0284c7">${Utils.formatMoney(d.totalCostValuation)}</div>
            <div class="kpi-sub">${d.totalItemsCount} ${isAR?'صنف':'SKUs'}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'تقييم المخزون بسعر البيع':'Valuation (Retail)'}</div>
            <div class="kpi-val" style="color:#059669">${Utils.formatMoney(d.totalRetailValuation)}</div>
            <div class="kpi-sub">${d.totalQty} ${isAR?'قطعة بالمخزن':'units in stock'}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'أرباح متوقعة عند البيع':'Unrealized Profit'}</div>
            <div class="kpi-val" style="color:#d97706">${Utils.formatMoney(d.potentialProfit)}</div>
          </div>
        </div>

        <div class="section-title">📦 ${isAR?'أعلى الأصناف قيمة في المخزن':'Top Valued Inventory Items'}</div>
        <table>
          <thead>
            <tr>
              <th style="width:40px">#</th>
              <th style="text-align:${isAR?'right':'left'}">${isAR?'الصنف':'Item'}</th>
              <th style="width:70px">${isAR?'الكمية':'Qty'}</th>
              <th style="width:100px;text-align:right">${isAR?'سعر التكلفة':'Unit Cost'}</th>
              <th style="width:100px;text-align:right">${isAR?'سعر البيع':'Unit Retail'}</th>
              <th style="width:120px;text-align:right">${isAR?'إجمالي القيمة':'Total Valuation'}</th>
            </tr>
          </thead>
          <tbody>
            ${d.topValued.map((it, idx) => `
              <tr>
                <td style="text-align:center">${idx+1}</td>
                <td><strong>${Utils.sanitize(it.name)}</strong></td>
                <td style="text-align:center">${it.qty}</td>
                <td style="text-align:right">${Utils.formatMoney(it.cost)}</td>
                <td style="text-align:right">${Utils.formatMoney(it.price)}</td>
                <td style="text-align:right;font-weight:700;color:#0284c7">${Utils.formatMoney(it.totalRetailVal)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    } else if (d.reportType === 'pl') {
      contentHtml = `
        <div class="kpi-grid" style="grid-template-columns: repeat(4, 1fr);">
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'إجمالي الإيرادات':'Revenues'}</div>
            <div class="kpi-val" style="color:#059669">${Utils.formatMoney(d.totalSalesUSD)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'تكلفة البضاعة (COGS)':'COGS'}</div>
            <div class="kpi-val" style="color:#dc2626">-${Utils.formatMoney(d.totalCostUSD)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'المصاريف التشغيلية':'Expenses'}</div>
            <div class="kpi-val" style="color:#e11d48">-${Utils.formatMoney(d.totalExpenses)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'صافي الأرباح':'Net Profit'}</div>
            <div class="kpi-val" style="color:#0284c7">${Utils.formatMoney(d.netOperatingIncome)}</div>
            <div class="kpi-sub">${d.netMarginPct}% margin</div>
          </div>
        </div>
      `;
    } else if (d.reportType === 'supplier') {
      contentHtml = `
        <div class="kpi-grid" style="grid-template-columns: repeat(2, 1fr);">
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'إجمالي ذمم ومستحقات الموردين':'Total Accounts Payable'}</div>
            <div class="kpi-val" style="color:#dc2626">${Utils.formatMoney(d.totalPayables)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'عدد الموردين المسجلين':'Registered Suppliers'}</div>
            <div class="kpi-val">${d.totalSuppliersCount}</div>
          </div>
        </div>

        <div class="section-title">🚚 ${isAR?'كشف أرصدة الموردين المستحقة':'Suppliers with Outstanding Balances'}</div>
        <table>
          <thead>
            <tr>
              <th style="width:40px">#</th>
              <th style="text-align:${isAR?'right':'left'}">${isAR?'المورد':'Supplier'}</th>
              <th style="text-align:${isAR?'right':'left'}">${isAR?'الهاتف':'Phone'}</th>
              <th style="width:130px;text-align:right">${isAR?'الرصيد المستحق':'Balance Due'}</th>
            </tr>
          </thead>
          <tbody>
            ${d.activeSuppliers.map((s, idx) => `
              <tr>
                <td style="text-align:center">${idx+1}</td>
                <td><strong>${Utils.sanitize(s.name || s.supplier_name)}</strong></td>
                <td>${s.phone || '-'}</td>
                <td style="text-align:right;font-weight:700;color:#dc2626">${Utils.formatMoney(parseFloat(s.balance || s.current_balance || 0))}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    } else if (d.reportType === 'customer') {
      contentHtml = `
        <div class="kpi-grid" style="grid-template-columns: repeat(2, 1fr);">
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'إجمالي ديون وذمم العملاء':'Total Receivables'}</div>
            <div class="kpi-val" style="color:#dc2626">${Utils.formatMoney(d.totalReceivables)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'عدد العملاء المسجلين':'Active Customers'}</div>
            <div class="kpi-val">${d.totalCustomersCount}</div>
          </div>
        </div>

        <div class="section-title">👥 ${isAR?'أعلى العملاء المدينين':'Top Customers with Outstanding Debts'}</div>
        <table>
          <thead>
            <tr>
              <th style="width:40px">#</th>
              <th style="text-align:${isAR?'right':'left'}">${isAR?'العميل':'Customer'}</th>
              <th style="text-align:${isAR?'right':'left'}">${isAR?'الهاتف':'Phone'}</th>
              <th style="width:130px;text-align:right">${isAR?'الرصيد المدين':'Debit Balance'}</th>
            </tr>
          </thead>
          <tbody>
            ${d.debtors.map((c, idx) => `
              <tr>
                <td style="text-align:center">${idx+1}</td>
                <td><strong>${Utils.sanitize(c.name || c.customer_name)}</strong></td>
                <td>${c.phone || '-'}</td>
                <td style="text-align:right;font-weight:700;color:#dc2626">${Utils.formatMoney(parseFloat(c.balance || c.current_balance || 0))}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    } else if (d.reportType === 'dead_stock') {
      contentHtml = `
        <div class="kpi-grid" style="grid-template-columns: repeat(2, 1fr);">
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'إجمالي رأس المال المجمد':'Total Trapped Capital'}</div>
            <div class="kpi-val" style="color:#d97706">${Utils.formatMoney(d.totalTrapped)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR?'عدد الأصناف الراكدة':'Stagnant SKUs'}</div>
            <div class="kpi-val">${d.stagnantCount}</div>
          </div>
        </div>

        <div class="section-title">⚠️ ${isAR?'قائمة الأصناف الراكدة بالتكلفة المجمدة':'Dormant Items with Trapped Capital'}</div>
        <table>
          <thead>
            <tr>
              <th style="width:40px">#</th>
              <th style="text-align:${isAR?'right':'left'}">${isAR?'اسم الصنف':'Item'}</th>
              <th style="width:80px">${isAR?'الكمية الراكدة':'Qty'}</th>
              <th style="width:110px;text-align:right">${isAR?'سعر التكلفة':'Unit Cost'}</th>
              <th style="width:130px;text-align:right">${isAR?'القيمة المجمدة':'Locked Cash'}</th>
            </tr>
          </thead>
          <tbody>
            ${d.topStagnant.map((it, idx) => `
              <tr>
                <td style="text-align:center">${idx+1}</td>
                <td><strong>${Utils.sanitize(it.name)}</strong></td>
                <td style="text-align:center">${it.stock}</td>
                <td style="text-align:right">${Utils.formatMoney(it.cost)}</td>
                <td style="text-align:right;font-weight:700;color:#d97706">${Utils.formatMoney(it.trappedCash)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    } else {
      // General Executive Report
      const topItemsRows = (d.topItems || []).map((item, idx) => `
        <tr>
          <td style="padding:6px;border:1px solid #ddd;text-align:center">${idx + 1}</td>
          <td style="padding:6px;border:1px solid #ddd;font-weight:700">${Utils.sanitize(item.name)}</td>
          <td style="padding:6px;border:1px solid #ddd;text-align:center">${item.qty}</td>
          <td style="padding:6px;border:1px solid #ddd;text-align:right;font-weight:700">${Utils.formatMoney(item.rev)}</td>
          <td style="padding:6px;border:1px solid #ddd;text-align:right;color:#0284c7">${Utils.formatMoney(item.profit)}</td>
        </tr>
      `).join('');

      contentHtml = `
        <div class="kpi-grid">
          <div class="kpi-card">
            <div class="kpi-label">${isAR ? 'إجمالي المبيعات' : 'Total Revenue'}</div>
            <div class="kpi-val" style="color:#059669">${Utils.formatMoney(d.totalSalesUSD)}</div>
            <div class="kpi-sub">${d.invoiceCount} ${isAR ? 'فاتورة' : 'invoices'}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR ? 'صافي الربح التقديري' : 'Gross Profit'}</div>
            <div class="kpi-val" style="color:#0284c7">${Utils.formatMoney(d.grossProfitUSD)}</div>
            <div class="kpi-sub" style="color:#d97706">${d.marginPct}% ${isAR ? 'هامش' : 'margin'}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR ? 'تكلفة البضاعة (COGS)' : 'Total Cost'}</div>
            <div class="kpi-val" style="color:#dc2626">${Utils.formatMoney(d.totalCostUSD)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">${isAR ? 'متوسط الفاتورة' : 'Avg Basket'}</div>
            <div class="kpi-val" style="color:#7c3aed">${Utils.formatMoney(d.avgBasket)}</div>
          </div>
        </div>

        ${(d.topItems && d.topItems.length > 0) ? `
          <div class="section-title">🏆 ${isAR ? 'أعلى الأصناف أداءً وإيراداً' : 'Top Performing Products'}</div>
          <table>
            <thead>
              <tr>
                <th style="width:40px">#</th>
                <th style="text-align:${isAR?'right':'left'}">${isAR ? 'اسم الصنف' : 'Item Name'}</th>
                <th style="width:80px">${isAR ? 'الكمية المباعة' : 'Qty Sold'}</th>
                <th style="width:110px;text-align:right">${isAR ? 'الإيرادات' : 'Revenue'}</th>
                <th style="width:110px;text-align:right">${isAR ? 'الربح التقديري' : 'Est. Profit'}</th>
              </tr>
            </thead>
            <tbody>
              ${topItemsRows}
            </tbody>
          </table>
        ` : ''}

        <div class="section-title">📦 ${isAR ? 'ملخص المخزون والذمم المالية' : 'Inventory & Receivables Summary'}</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:18px">
          <div style="border:1px solid #e2e8f0;border-radius:6px;padding:10px">
            <div><strong>${isAR ? 'إجمالي الأصناف المسجلة:' : 'Total Active SKUs:'}</strong> ${d.totalItemsCount}</div>
            <div style="margin-top:4px"><strong>${isAR ? 'أصناف قريبة أو تحت حد النفاذ:' : 'Low Stock / Critical SKUs:'}</strong> <span style="color:${d.lowStockCount>0?'#dc2626':'#059669'};font-weight:700">${d.lowStockCount}</span></div>
          </div>
          <div style="border:1px solid #e2e8f0;border-radius:6px;padding:10px">
            <div><strong>${isAR ? 'إجمالي ديون وذمم العملاء:' : 'Outstanding Customer Receivables:'}</strong> <span style="color:#dc2626;font-weight:700">${Utils.formatMoney(d.totalCustomerDebt)}</span></div>
            <div style="font-size:11px;color:#64748b;margin-top:4px">${isAR ? 'مستحقات آجلة قيد التحصيل' : 'Pending balances to be collected'}</div>
          </div>
        </div>
      `;
    }

    const html = `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${d.reportName || (isAR ? 'تقرير الأعمال التنفيذي' : 'Executive Business Report')}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Inter:wght@400;600;700;800&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: ${isAR ? "'Cairo', sans-serif" : "'Inter', sans-serif"}; color: #1e293b; background: #fff; padding: 20px; font-size: 13px; line-height: 1.5; }
    .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 16px; }
    .header-title h1 { font-size: 20px; color: #0f172a; margin-bottom: 2px; }
    .header-title p { font-size: 12px; color: #64748b; }
    .header-info { text-align: ${isAR ? 'left' : 'right'}; font-size: 12px; color: #475569; }
    .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 18px; }
    .kpi-card { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; text-align: center; }
    .kpi-label { font-size: 11px; color: #64748b; text-transform: uppercase; margin-bottom: 4px; }
    .kpi-val { font-size: 18px; font-weight: 800; color: #0f172a; }
    .kpi-sub { font-size: 11px; color: #10b981; font-weight: 600; margin-top: 2px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 18px; font-size: 12px; }
    th { background: #f1f5f9; padding: 8px; border: 1px solid #cbd5e1; font-weight: 700; color: #334155; }
    td { padding: 6px 8px; border: 1px solid #e2e8f0; }
    .section-title { font-size: 14px; font-weight: 700; color: #0f172a; margin: 14px 0 8px 0; display: flex; align-items: center; gap: 6px; }
    .footer-stamp { display: flex; justify-content: space-between; margin-top: 30px; border-top: 1px dashed #cbd5e1; padding-top: 12px; font-size: 11px; color: #64748b; }
    .no-print { display: flex; gap: 10px; justify-content: center; margin-bottom: 16px; }
    .btn-print { background: #0284c7; color: #fff; padding: 8px 18px; border-radius: 6px; border: none; cursor: pointer; font-weight: 700; }
    .btn-close { background: #e2e8f0; color: #334155; padding: 8px 18px; border-radius: 6px; border: none; cursor: pointer; }
    @media print { .no-print { display: none !important; } body { padding: 0; } @page { margin: 12mm; } }
  </style>
</head>
<body>
  <div class="no-print">
    <button class="btn-print" onclick="window.print()">🖨️ ${isAR ? 'طباعة الآن' : 'Print Now'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>

  <div class="header">
    <div class="header-title">
      <h1>${d.reportName || (isAR ? 'تقرير الأعمال والذكاء الاصطناعي التنفيذي' : 'Red Shark Executive AI Business Report')}</h1>
      <p>${compName} ${phone ? '• ' + phone : ''}</p>
    </div>
    <div class="header-info">
      <div><strong>${isAR ? 'الفترة:' : 'Period:'}</strong> ${d.periodName || (isAR ? 'فوري' : 'Live')}</div>
      <div><strong>${isAR ? 'تاريخ التوليد:' : 'Generated:'}</strong> ${d.dateGenerated}</div>
    </div>
  </div>

  ${contentHtml}

  <div class="footer-stamp">
    <div>${isAR ? 'تم إنشاء التقرير بواسطة Red Shark AI Copilot' : 'Generated by Red Shark AI Copilot Engine'}</div>
    <div>${isAR ? 'توقيع الإدارة / المحاسب: _______________________' : 'Manager / Accountant Signature: _______________________'}</div>
  </div>
</body>
</html>`;

    if (window.PrintEngine?.openPrintWindow) {
      PrintEngine.openPrintWindow(html, d.reportName || (isAR ? 'تقرير تنفيذي' : 'Executive Report'));
    } else {
      const win = window.open('', '_blank', 'width=850,height=950');
      win.document.write(html);
      win.document.close();
      win.focus();
      setTimeout(() => { win.print(); }, 500);
    }
  }

  // ── AI Demand Forecasting & Runout Engine ──────────────────────
  async function computeInventoryForecast() {
    const items = (await DB.getAll('items')) || [];
    const allSales = await _getAllSales();
    const now = new Date();
    const past30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Aggregate sales by item ID over past 30 days
    const itemSales30d = {};
    allSales.forEach(inv => {
      if (inv._dateObj && inv._dateObj >= past30Days) {
        inv._items.forEach(line => {
          const id = line.item_id || line.id;
          if (id) {
            itemSales30d[id] = (itemSales30d[id] || 0) + (parseFloat(line.qty) || 0);
          }
        });
      }
    });

    const forecastList = items.map(item => {
      const sold30 = itemSales30d[item.id] || 0;
      const dailyVelocity = sold30 / 30; // units/day
      const stock = parseFloat(item.stock_qty || item.quantity || 0);
      const reorderPoint = parseFloat(item.reorder_level || item.min_stock || item.min_qty || 5);
      
      let daysLeft = dailyVelocity > 0 ? Math.round(stock / dailyVelocity) : (stock > 0 ? 999 : 0);
      let urgency = 'normal'; // 'critical', 'warning', 'healthy', 'overstock'
      
      if (stock <= 0) {
        urgency = 'critical';
      } else if (daysLeft <= 3 || stock <= reorderPoint) {
        urgency = 'critical';
      } else if (daysLeft <= 7) {
        urgency = 'warning';
      } else if (daysLeft > 60 && stock > 50) {
        urgency = 'overstock';
      } else {
        urgency = 'healthy';
      }

      // Suggested order qty to maintain 21-day target stock
      const targetDays = 21;
      const neededForTarget = Math.ceil(dailyVelocity * targetDays);
      const suggestedReorderQty = Math.max(0, Math.max(reorderPoint * 2, neededForTarget) - stock);

      return {
        item,
        stock,
        sold30,
        dailyVelocity: parseFloat(dailyVelocity.toFixed(2)),
        daysLeft,
        urgency,
        suggestedReorderQty: Math.ceil(suggestedReorderQty)
      };
    });

    return forecastList;
  }

  // ── AI Strategic Profit & Growth Advisory Engine ───────────────
  async function generateStrategicProfitAdvice() {
    const isAR = _isAppArabic();
    const items = (await DB.getAll('items')) || [];
    const allSales = await _getAllSales();
    const customers = (await DB.getAll('customers')) || [];
    const forecast = await computeInventoryForecast();

    // 1. Audit missing cost prices
    const noCostItems = items.filter(it => {
      const price = parseFloat(it.selling_price || it.price || 0);
      const cost = parseFloat(it.cost_price || 0);
      return price > 0 && cost <= 0;
    });

    // 2. High margin items (> 30% margin)
    const highMarginItems = items.filter(it => {
      const price = parseFloat(it.selling_price || it.price || 0);
      const cost = parseFloat(it.cost_price || 0);
      return price > 0 && cost > 0 && ((price - cost) / price) >= 0.30;
    }).sort((a,b) => {
      const ma = ((parseFloat(a.selling_price||0) - parseFloat(a.cost_price||0)) / parseFloat(a.selling_price||1));
      const mb = ((parseFloat(b.selling_price||0) - parseFloat(b.cost_price||0)) / parseFloat(b.selling_price||1));
      return mb - ma;
    }).slice(0, 3);

    // 3. Dead / Slow Moving Stock (Stock >= 5, 0 sales in past 30 days)
    const past30Days = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const soldItemIds = new Set();
    allSales.forEach(s => {
      if (s._dateObj && s._dateObj >= past30Days) {
        (s._items || []).forEach(l => {
          if (l.item_id || l.id) soldItemIds.add(String(l.item_id || l.id));
        });
      }
    });

    const deadStockItems = items.filter(it => {
      const stock = parseFloat(it.stock_qty || it.quantity || 0);
      return stock >= 5 && !soldItemIds.has(String(it.id));
    });
    const deadStockCapital = deadStockItems.reduce((acc, it) => acc + (parseFloat(it.cost_price || it.selling_price || 0) * (parseFloat(it.stock_qty || 0))), 0);

    // 4. Critical Stockout Risks (high demand running out)
    const stockoutRisks = forecast.filter(f => f.urgency === 'critical' && f.sold30 > 0).slice(0, 3);

    // 5. Customer Debts
    const totalDebt = customers.reduce((acc, c) => acc + Math.max(0, parseFloat(c.balance || c.current_balance || 0)), 0);

    // 6. Basket Size & Upselling
    const totalRevenue = allSales.reduce((acc, s) => acc + s._total, 0);
    const avgBasket = allSales.length > 0 ? (totalRevenue / allSales.length) : 0;
    const currentBasket = avgBasket > 0 ? avgBasket : 10;
    const targetLift = (currentBasket * 0.15);

    const adviceCards = [];

    // Diagnostic 1: Missing Cost Price Alert (Explains why profit was 0.0%)
    if (noCostItems.length > 0) {
      const sampleNames = noCostItems.slice(0, 3).map(i => Utils.sanitize(isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar))).join(', ');
      adviceCards.push(`
        <div style="background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.3);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="font-weight:800;color:#ef4444;font-size:0.83rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
            <span>⚠️</span> ${isAR ? 'تحديد تكلفة الشراء (أولوية فورية للأرباح)' : 'Set Missing Cost Prices (Immediate Priority)'}
          </div>
          <div style="font-size:0.77rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `تم رصد <strong>${noCostItems.length} صنفاً</strong> مسجلة بسعر تكلفة $0.00 (مثل: <em>${sampleNames}</em>)، وهذا هو سبب ظهور هامش الربح 0% في النظام. إدخال التكلفة الحقيقية ضروري لمعرفة أرباحك الصافية ومنع بيع بضائع بخسارة غير مقصودة.` 
              : `Found <strong>${noCostItems.length} items</strong> with zero cost price (e.g. <em>${sampleNames}</em>). Setting cost prices is essential to reveal true gross margins and avoid selling at a hidden loss.`}
          </div>
          <button class="btn btn-outline btn-sm" style="font-size:0.73rem;padding:4px 10px" onclick="App.navigate('items'); AICopilot.close();">
            🏷️ ${isAR ? 'تعديل أسعار التكلفة الآن' : 'Edit Cost Prices Now'}
          </button>
        </div>
      `);
    }

    // Diagnostic 2: High-Margin Champions
    if (highMarginItems.length > 0) {
      const championList = highMarginItems.map(i => {
        const p = parseFloat(i.selling_price || i.price || 0);
        const c = parseFloat(i.cost_price || 0);
        const m = p > 0 ? Math.round(((p - c) / p) * 100) : 0;
        const name = Utils.sanitize(isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar));
        return `<span style="background:rgba(34,197,94,0.15);color:#22c55e;padding:2px 6px;border-radius:4px;font-weight:700;font-size:0.7rem">${name} (${m}% ${isAR?'هامش':'margin'})</span>`;
      }).join(' ');

      adviceCards.push(`
        <div style="background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.3);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="font-weight:800;color:#22c55e;font-size:0.83rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
            <span>⭐</span> ${isAR ? 'تعزيز مبيعات الأصناف الأعلى ربحية' : 'Promote High-Margin Champions'}
          </div>
          <div style="font-size:0.77rem;color:var(--text-color);line-height:1.45">
            ${isAR 
              ? `أصناف تحقق أعلى هامش ربح في المتجر: ${championList}. شجع الكاشير على ترشيحها، وضعها كأزرار سريعة في شاشة الكاشير وفي الواجهة، حيث أن زيادة بيع هذه الأصناف تضاعف أرباحك الصافية دون أي مصاريف إضافية.`
              : `Your highest margin products: ${championList}. Feature them on front displays and POS quick-action buttons to maximize return per ticket.`}
          </div>
        </div>
      `);
    }

    // Diagnostic 3: Dead Stock Capital Recovery
    if (deadStockItems.length > 0) {
      const deadNames = deadStockItems.slice(0, 3).map(i => Utils.sanitize(isAR ? (i.name_ar || i.name_en) : (i.name_en || i.name_ar))).join(', ');
      adviceCards.push(`
        <div style="background:rgba(234,179,8,0.08);border:1px solid rgba(234,179,8,0.3);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="font-weight:800;color:#eab308;font-size:0.83rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
            <span>📦</span> ${isAR ? `تسييل رأس المال المجمد (${Utils.formatMoney(deadStockCapital)})` : `Liquidate Dead Stock (${Utils.formatMoney(deadStockCapital)})`}
          </div>
          <div style="font-size:0.77rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `تم رصد <strong>${deadStockItems.length} صنفاً</strong> لم تسجل أي حركة بيع في آخر 30 يوماً (مثل: <em>${deadNames}</em>). بقاؤها في الرف يجمّد السيولة. ننصح بدمجها في عروض ترويجية (اشتري 1 واحصل على الثاني بخصم) أو تخفيض 10-15% لتحويلها لكاش نشط فوراً.`
              : `You have <strong>${deadStockItems.length} idle items</strong> without sales in 30 days (e.g. <em>${deadNames}</em>). Turn this tied-up capital into active cash flow with bundle discounts.`}
          </div>
          <button class="btn btn-outline btn-sm" style="font-size:0.73rem;padding:4px 10px" onclick="App.navigate('promotions'); AICopilot.close();">
            🏷️ ${isAR ? 'إنشاء عروض ترويجية للبضائع الراكدة' : 'Create Clearance Promotions'}
          </button>
        </div>
      `);
    }

    // Diagnostic 4: Stockout Lost Profits
    if (stockoutRisks.length > 0) {
      const riskNames = stockoutRisks.map(s => Utils.sanitize(isAR ? (s.item.name_ar || s.item.name_en) : (s.item.name_en || s.item.name_ar))).join(', ');
      adviceCards.push(`
        <div style="background:rgba(249,115,22,0.08);border:1px solid rgba(249,115,22,0.3);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="font-weight:800;color:#f97316;font-size:0.83rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
            <span>🚨</span> ${isAR ? 'منع ضياع الأرباح بسبب نفاذ المخزون' : 'Prevent Lost Profits from Stockouts'}
          </div>
          <div style="font-size:0.77rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `أصناف سريعة الحركة وذات طلب نشط أوشكت على النفاذ (مثل: <em>${riskNames}</em>). نفاذ الصنف يعني ضياع زبائن وعوائد مؤكدة لمنافسين آخرين. ننصح بإصدار أمر توريد فوري.`
              : `High-velocity items are near stockout: <em>${riskNames}</em>. Running out of stock directly forfeits daily revenue. Reorder now.`}
          </div>
          <button class="btn btn-outline btn-sm" style="font-size:0.73rem;padding:4px 10px" onclick="App.navigate('purchase-order'); AICopilot.close();">
            🚚 ${isAR ? 'إنشاء أمر توريد فوري' : 'Create Purchase Order'}
          </button>
        </div>
      `);
    }

    // Diagnostic 5: Basket Size Optimization (Cross-Selling)
    adviceCards.push(`
      <div style="background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.3);border-radius:10px;padding:12px;margin-bottom:10px">
        <div style="font-weight:800;color:#818cf8;font-size:0.83rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
          <span>🛒</span> ${isAR ? `زيادة متوسط سلة المشتريات (+15%)` : `Increase Average Basket Value (+15%)`}
        </div>
        <div style="font-size:0.77rem;color:var(--text-color);line-height:1.45">
          ${isAR 
            ? `متوسط الفاتورة في متجرك حالياً هو <strong>${Utils.formatMoney(currentBasket)}</strong>. بتدريب الكاشير على تقديم اقتراح إضافي صغير (مثل إضافة مياه، حلوى، أو إكسسوار بقيمة <strong>${Utils.formatMoney(targetLift)}</strong>) لكل زبون، سترتفع أرباحك الشهرية بمقدار 15% إلى 20% دون الحاجة لجلب زبائن جدد.`
            : `Average invoice size is currently <strong>${Utils.formatMoney(currentBasket)}</strong>. Training cashiers to suggest a complementary item worth <strong>${Utils.formatMoney(targetLift)}</strong> per checkout increases monthly net income by ~15% at zero customer acquisition cost.`}
        </div>
      </div>
    `);

    // Diagnostic 6: Outstanding Customer Debts
    if (totalDebt > 0) {
      adviceCards.push(`
        <div style="background:rgba(168,85,247,0.08);border:1px solid rgba(168,85,247,0.3);border-radius:10px;padding:12px;margin-bottom:10px">
          <div style="font-weight:800;color:#a855f7;font-size:0.83rem;margin-bottom:4px;display:flex;align-items:center;gap:6px">
            <span>👥</span> ${isAR ? `تحصيل الديون لتعزيز السيولة (${Utils.formatMoney(totalDebt)})` : `Collect Receivables for Liquidity (${Utils.formatMoney(totalDebt)})`}
          </div>
          <div style="font-size:0.77rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `لديك ذمم مستحقة بقيمة <strong>${Utils.formatMoney(totalDebt)}</strong> بذمة العملاء. تحصيل 40-50% من هذه المبالغ يمنحك سيولة لشراء بضائع بخصومات سداد نقدي (Cash Discounts) تزيد هامش ربحك بنسبة 3-5%.`
              : `You have <strong>${Utils.formatMoney(totalDebt)}</strong> in customer receivables. Collecting this allows leveraging cash supplier discounts (3-5% margin boost).`}
          </div>
          <button class="btn btn-outline btn-sm" style="font-size:0.73rem;padding:4px 10px" onclick="App.navigate('customer-receipts'); AICopilot.close();">
            💵 ${isAR ? 'تسجيل سندات قبض العملاء' : 'Receive Customer Payments'}
          </button>
        </div>
      `);
    }

    return {
      title: isAR ? '💡 خطة الذكاء الاصطناعي الاستراتيجية لزيادة الأرباح' : '💡 AI Strategic Plan to Boost Profits & Revenue',
      content: `
        <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:12px">
          ${isAR ? 'قام الذكاء الاصطناعي بتحليل قاعدة بيانات المبيعات والمخزون والتكاليف لمتجرك، وهذه هي التوصيات العملية المباشرة لتعظيم صافي الأرباح:' : 'AI analyzed your live database (sales, stock velocity, margins, and debts). Here is your tailored profit growth roadmap:'}
        </p>
        <div style="display:flex;flex-direction:column;gap:4px">
          ${adviceCards.join('')}
        </div>
      `
    };
  }

  // ── AI Item Performance & Low-Sales Diagnostic Engine ──────────
  async function analyzeItemPerformanceAndSuggestions() {
    const isAR = _isAppArabic();
    const items = (await DB.getAll('items')) || [];
    const allSales = await _getAllSales();

    const now = new Date();
    const past30Days = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    // Track sales in last 30 days per item
    const sales30d = new Map();
    allSales.forEach(s => {
      if (s._dateObj && s._dateObj >= past30Days) {
        (s._items || []).forEach(l => {
          const id = String(l.item_id || l.id || l.item_code || '');
          if (id) {
            const cur = sales30d.get(id) || { qty: 0, rev: 0, count: 0 };
            const q = parseFloat(l.qty) || 0;
            const r = parseFloat(l.total) || ((parseFloat(l.price || l.unit_price || 0)) * q);
            cur.qty += q;
            cur.rev += r;
            cur.count += 1;
            sales30d.set(id, cur);
          }
        });
      }
    });

    // Categorize items
    const slowMoving = [];     // Has stock, but 0 or <= 1 sales in last 30 days
    const highMarginGems = []; // Margin >= 35%, sold <= 4, has stock
    const lowMarginTraps = []; // Sold >= 5, Margin < 12%
    const overstocked = [];    // Stock >= 15, lasts > 60 days

    items.forEach(it => {
      const id = String(it.id);
      const code = String(it.item_code || '');
      const sData = sales30d.get(id) || sales30d.get(code) || { qty: 0, rev: 0, count: 0 };
      const stock = parseFloat(it.stock_qty || it.quantity || 0);
      const price = parseFloat(it.selling_price || it.price || 0);
      const cost = parseFloat(it.cost_price || 0);
      const margin = (price > 0 && cost > 0) ? ((price - cost) / price) : 0;
      const marginPct = Math.round(margin * 100);

      const dailyVelocity = sData.qty / 30;
      const daysLeft = dailyVelocity > 0 ? Math.round(stock / dailyVelocity) : (stock > 0 ? 999 : 0);

      const itemInfo = {
        id: it.id,
        item: it,
        name: Utils.sanitize(isAR ? (it.name_ar || it.name_en) : (it.name_en || it.name_ar)),
        stock,
        price,
        cost,
        marginPct,
        sold30: sData.qty,
        rev30: sData.rev,
        daysLeft
      };

      // 1. Slow Moving / Low Sales (has stock but barely sells)
      if (stock > 0 && sData.qty <= 1) {
        slowMoving.push(itemInfo);
      }

      // 2. High Margin Gems (under-marketed)
      if (marginPct >= 30 && sData.qty <= 4 && stock > 0) {
        highMarginGems.push(itemInfo);
      }

      // 3. Low Margin Traps (Fast sales, tiny profit)
      if (sData.qty >= 5 && marginPct > 0 && marginPct < 12) {
        lowMarginTraps.push(itemInfo);
      }

      // 4. Overstocked
      if (stock >= 15 && daysLeft > 60 && sData.qty > 0) {
        overstocked.push(itemInfo);
      }
    });

    // Sort slow moving by largest stock value first
    slowMoving.sort((a,b) => (b.stock * (b.cost || b.price)) - (a.stock * (a.cost || a.price)));

    const resultBlocks = [];

    // Block 1: Slow-Moving & Low-Sales Products
    if (slowMoving.length > 0) {
      const topSlow = slowMoving.slice(0, 5);
      const rows = topSlow.map(s => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border-color);font-size:0.77rem">
          <div>
            <strong>${s.name}</strong>
            <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'المخزون المتوفر:':'Available Stock:'} <span style="color:#ef4444;font-weight:700">${s.stock}</span> | ${isAR?'المبيعات (30 يوم):':'Sales (30d):'} <span style="font-weight:700">${s.sold30}</span></div>
          </div>
          <div style="text-align:right">
            <span style="font-size:0.7rem;font-weight:700;color:#eab308">${Utils.formatMoney(s.stock * (s.cost || s.price))} ${isAR?'مجمد':'idle'}</span>
          </div>
        </div>
      `).join('');

      resultBlocks.push(`
        <div style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.25);border-radius:10px;padding:12px;margin-bottom:12px">
          <div style="font-weight:800;color:#ef4444;font-size:0.84rem;margin-bottom:6px;display:flex;align-items:center;gap:6px">
            <span>📉</span> ${isAR ? `أصناف راكدة وضعيفة المبيعات (${slowMoving.length} صنف)` : `Slow-Moving & Low Sales Items (${slowMoving.length} items)`}
          </div>
          <div style="font-size:0.76rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `هذه الأصناف لديها مخزون في المحل لكن حركة بيعها شبه متوقفة (مبيعاتها 0 أو 1 خلال آخر شهر):`
              : `These items have stock on hand but near-zero movement over the last 30 days:`}
          </div>
          <div style="margin-bottom:10px">${rows}</div>
          <div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:8px;font-size:0.74rem;color:var(--text-color);line-height:1.4;margin-bottom:8px">
            💡 <strong>${isAR?'خطة تصريف الأصناف الراكدة:':'Tactical Suggestions for Slow Items:'}</strong>
            <ul style="margin:4px 0 0 16px;padding:0">
              <li>${isAR ? '<strong>عروض الحزم الترويجية (Bundles):</strong> ادمج الصنف الراكد مع الصنف الأكثر مبيعاً بخصم جذاب.' : '<strong>Bundle Offer:</strong> Pair stagnant item with a bestseller at package discount.'}</li>
              <li>${isAR ? '<strong>تخفيض التصفية (15-20%):</strong> خصم مباشر لتسييل رأس المال وشراء أصناف سريعة الدوران.' : '<strong>Flash Clearance:</strong> Apply 15-20% discount to free cash flow.'}</li>
              <li>${isAR ? '<strong>إعادة للمورد:</strong> إذا كانت البضاعة حديثة، استبدلها من المورد بأصناف أكثر طلباً.' : '<strong>Supplier Exchange:</strong> Request return/credit for high-demand items.'}</li>
            </ul>
          </div>
          <button class="btn btn-outline btn-sm" style="width:100%;font-size:0.75rem" onclick="App.navigate('promotions'); AICopilot.close();">
            🎁 ${isAR ? 'إنشاء عروض ترويجية لتصريف البضاعة' : 'Launch Promotion for Slow Items'}
          </button>
        </div>
      `);
    } else {
      resultBlocks.push(`
        <div style="background:rgba(34,197,94,0.06);border:1px solid rgba(34,197,94,0.25);border-radius:10px;padding:12px;margin-bottom:12px">
          <div style="font-weight:800;color:#22c55e;font-size:0.83rem">
            ✅ ${isAR ? 'ممتاز! لا توجد أصناف راكدة بشكل ملحوظ في متجرك حالياً.' : 'Optimal! No severely stagnant items detected in your store.'}
          </div>
        </div>
      `);
    }

    // Block 2: High Margin Gems (Under-Marketed)
    if (highMarginGems.length > 0) {
      const topGems = highMarginGems.slice(0, 4);
      const rows = topGems.map(g => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--border-color);font-size:0.77rem">
          <div><strong>${g.name}</strong> <span style="color:#22c55e;font-weight:700">(${g.marginPct}% ${isAR?'ربح':'profit'})</span></div>
          <div style="font-size:0.72rem;color:var(--text-muted)">${isAR?'المبيعات:':'Sold:'} ${g.sold30} ${isAR?'قطعة':'units'}</div>
        </div>
      `).join('');

      resultBlocks.push(`
        <div style="background:rgba(34,197,94,0.06);border:1px solid rgba(34,197,94,0.25);border-radius:10px;padding:12px;margin-bottom:12px">
          <div style="font-weight:800;color:#22c55e;font-size:0.84rem;margin-bottom:6px;display:flex;align-items:center;gap:6px">
            <span>💎</span> ${isAR ? 'فرص ذهبية: أصناف عالية الربح لكن مبيعاتها قليلة' : 'High-Margin Hidden Gems (Under-Marketed)'}
          </div>
          <div style="font-size:0.76rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `هذه المنتجات تحقق هامش ربح استثنائي، ولكن الزبائن لا يشترونها بكثرة بسبب ضعف العرض:`
              : `These products have exceptional margins (>30%), but are not exposed enough to shoppers:`}
          </div>
          <div style="margin-bottom:8px">${rows}</div>
          <div style="font-size:0.74rem;color:var(--text-muted);line-height:1.4">
            💡 <strong>${isAR?'اقتراح الذكاء الاصطناعي:':'AI Actionable Advice:'}</strong> ${isAR ? 'انقل هذه الأصناف إلى مستوى نظر الزبون في الرفوف أو بجانب شاشة الدفع، وضعها كأزرار سريعة في الكاشير لتحفيز الموظفين على بيعها.' : 'Move to eye-level shelving, add to POS Quick Buttons, and incentivize staff to recommend them.'}
          </div>
        </div>
      `);
    }

    // Block 3: Low-Margin Traps
    if (lowMarginTraps.length > 0) {
      const topTraps = lowMarginTraps.slice(0, 3);
      const rows = topTraps.map(t => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--border-color);font-size:0.77rem">
          <div><strong>${t.name}</strong> <span style="color:#ef4444;font-weight:700">(${t.marginPct}% ${isAR?'هامش فقط':'margin only'})</span></div>
          <div style="font-size:0.72rem;color:var(--text-muted)">${t.sold30} ${isAR?'مبيعات':'sold'} (${Utils.formatMoney(t.rev30)})</div>
        </div>
      `).join('');

      resultBlocks.push(`
        <div style="background:rgba(234,179,8,0.06);border:1px solid rgba(234,179,8,0.25);border-radius:10px;padding:12px;margin-bottom:12px">
          <div style="font-weight:800;color:#eab308;font-size:0.84rem;margin-bottom:6px;display:flex;align-items:center;gap:6px">
            <span>⚡</span> ${isAR ? 'تنبيه: أصناف سريعة البيع لكن ربحها ضئيل جداً' : 'Fast Sellers with Weak Profit Margins (<12%)'}
          </div>
          <div style="font-size:0.76rem;color:var(--text-color);line-height:1.45;margin-bottom:8px">
            ${isAR 
              ? `هذه الأصناف تستنزف السيولة وتبيع بكثرة دون ترك أرباح حقيقية في الصندوق:`
              : `High volume products that generate cash flow but negligible bottom-line profit:`}
          </div>
          <div style="margin-bottom:8px">${rows}</div>
          <div style="font-size:0.74rem;color:var(--text-muted);line-height:1.4">
            💡 <strong>${isAR?'اقتراح الذكاء الاصطناعي:':'AI Actionable Advice:'}</strong> ${isAR ? 'زيادة السعر بنسبة طفيفة (2% - 3%) لن تؤثر على إقبال الزبائن على الأصناف الاستهلاكية، لكنها ستضاعف ربحها الصافي 100%. كما يُنصح بالتفاوض مع المورد على خصم كميات.' : 'A minor +2-3% price adjustment will not hurt demand but will double net earnings on these high-velocity goods.'}
          </div>
        </div>
      `);
    }

    return {
      title: isAR ? '📊 تحليل أداء الأصناف وتوصيات المبيعات الراكدة' : '📊 Item Performance & Low-Sales Analytics',
      content: `
        <p style="font-size:0.8rem;color:var(--text-muted);margin-bottom:12px">
          ${isAR ? 'تم فحص حركة دوران المخزون وهوامش ربح جميع الأصناف المسجلة، وإليك النتائج والاقتراحات الميدانية:' : 'Scanned stock velocity, sales history, and profit margins across your catalog. Diagnostic breakdown:'}
        </p>
        <div style="display:flex;flex-direction:column;gap:4px">
          ${resultBlocks.join('')}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
          <button class="btn btn-secondary btn-sm" style="font-size:0.75rem" onclick="App.navigate('items'); AICopilot.close();">
            📦 ${isAR ? 'إدارة الأصناف' : 'Manage Items'}
          </button>
          <button class="btn btn-secondary btn-sm" style="font-size:0.75rem" onclick="App.navigate('promotions'); AICopilot.close();">
            🏷️ ${isAR ? 'العروض الترويجية' : 'Promotions'}
          </button>
        </div>
      `
    };
  }

  function _findMatchingItem(query, items) {
    if (!query || query.length < 2) return null;
    const businessKeywords = [
      'today', 'yesterday', 'sale', 'sales', 'sell', 'sold', 'profit', 'revenue',
      'stock', 'low', 'reorder', 'inventory', 'debt', 'debts', 'customer', 'customers',
      'report', 'reports', 'cashbox', 'drawer', 'session', 'best', 'top', 'overview',
      'اليوم', 'امس', 'أمس', 'مبيع', 'مبيعات', 'بيع', 'بعت', 'بعنا', 'ارباح', 'أرباح',
      'مخزون', 'بضاعة', 'دين', 'ديون', 'عميل', 'عملاء', 'تقرير', 'صندوق', 'كاشير', 'درج',
      'افضل', 'أفضل', 'اكثر', 'أكثر', 'دخل', 'ايراد'
    ];
    const tokens = query.split(/\s+/).filter(Boolean);
    if (tokens.every(t => businessKeywords.includes(t))) return null;

    // 1. Exact barcode or item code match
    const codeMatch = items.find(i => 
      (i.barcode && String(i.barcode).toLowerCase() === query) ||
      (i.item_code && String(i.item_code).toLowerCase() === query)
    );
    if (codeMatch) return codeMatch;

    // 2. Explicit item prefix query (e.g. "item iphone", "صنف بيبسي", "سعر حليب")
    const itemPrefix = /^(item|product|صنف|منتج|سعر|سعر صنف)\s+(.+)$/i;
    const matchPrefix = query.match(itemPrefix);
    if (matchPrefix) {
      const searchTerm = matchPrefix[2].trim().toLowerCase();
      if (searchTerm.length >= 2) {
        const found = items.find(i => 
          (i.name_en && i.name_en.toLowerCase().includes(searchTerm)) ||
          (i.name_ar && i.name_ar.toLowerCase().includes(searchTerm)) ||
          (i.item_code && String(i.item_code).toLowerCase() === searchTerm) ||
          (i.barcode && String(i.barcode).toLowerCase() === searchTerm)
        );
        if (found) return found;
      }
    }

    // 3. Exact full name match (only if query is reasonably specific, > 3 chars)
    if (query.length >= 3) {
      const nameMatch = items.find(i => 
        (i.name_en && i.name_en.toLowerCase() === query) ||
        (i.name_ar && i.name_ar.toLowerCase() === query)
      );
      if (nameMatch) return nameMatch;
    }

    return null;
  }

  function _findMatchingCustomer(query, customers) {
    if (!query || query.length < 2) return null;
    const businessKeywords = [
      'today', 'yesterday', 'sale', 'sales', 'sell', 'sold', 'profit', 'revenue',
      'stock', 'debt', 'debts', 'customer', 'customers', 'report', 'reports', 'cashbox',
      'اليوم', 'مبيع', 'مبيعات', 'ارباح', 'ديون', 'دين', 'عميل', 'عملاء', 'ذمم'
    ];
    const tokens = query.split(/\s+/).filter(Boolean);
    if (tokens.every(t => businessKeywords.includes(t))) return null;

    // 1. Exact phone number match
    const phoneMatch = customers.find(c => c.phone && String(c.phone).trim() === query);
    if (phoneMatch) return phoneMatch;

    // 2. Explicit customer prefix query (e.g. "customer john", "عميل علي", "زبون احمد")
    const custPrefix = /^(customer|client|عميل|زبون)\s+(.+)$/i;
    const matchPrefix = query.match(custPrefix);
    if (matchPrefix) {
      const searchTerm = matchPrefix[2].trim().toLowerCase();
      if (searchTerm.length >= 2) {
        const found = customers.find(c => 
          (c.name && c.name.toLowerCase().includes(searchTerm)) ||
          (c.customer_name && c.customer_name.toLowerCase().includes(searchTerm)) ||
          (c.phone && String(c.phone).includes(searchTerm))
        );
        if (found) return found;
      }
    }

    // 3. Exact customer name match (only if not a generic word)
    if (query.length >= 3) {
      const nameMatch = customers.find(c => 
        (c.name && c.name.toLowerCase() === query) ||
        (c.customer_name && c.customer_name.toLowerCase() === query)
      );
      if (nameMatch) return nameMatch;
    }

    return null;
  }

  // ── AI Natural Language Business Analysis Engine ───────────────
  async function processBusinessQuery(query) {
    const q = (query || '').toLowerCase().trim();
    const detectedLang = detectQueryLang(q);
    const isAR = detectedLang === 'ar';
    const isFR = detectedLang === 'fr';
    const isES = detectedLang === 'es';
    const isTR = detectedLang === 'tr';

    // 0. AI Item Performance & Low-Sales Diagnostics (Analyzes all items and slow movement)
    const isItemAnalysisQuery = 
      q === 'items_analysis' || q === 'slow_items' ||
      q.includes('راكد') || q.includes('بطي') || q.includes('ضعيف') || q.includes('قليل') ||
      (q.includes('صنف') && (q.includes('حلل') || q.includes('تحليل') || q.includes('بيع') || q.includes('مبيع') || q.includes('مخزون') || q.includes('اقتراح') || q.includes('قليلة') || q.includes('ضعيفة'))) ||
      (q.includes('اصناف') && (q.includes('حلل') || q.includes('تحليل') || q.includes('بيع') || q.includes('مبيع') || q.includes('مخزون') || q.includes('اقتراح') || q.includes('قليلة') || q.includes('ضعيفة'))) ||
      (q.includes('أصناف') && (q.includes('حلل') || q.includes('تحليل') || q.includes('بيع') || q.includes('مبيع') || q.includes('مخزون') || q.includes('اقتراح') || q.includes('قليلة') || q.includes('ضعيفة'))) ||
      (q.includes('منتج') && (q.includes('حلل') || q.includes('تحليل') || q.includes('بيع') || q.includes('مبيع') || q.includes('مخزون') || q.includes('اقتراح') || q.includes('قليلة') || q.includes('ضعيفة'))) ||
      q.includes('slow') || q.includes('low sale') || q.includes('dead stock') || q.includes('stagnant') ||
      (q.includes('item') && (q.includes('analy') || q.includes('low') || q.includes('suggest') || q.includes('slow') || q.includes('perf')));

    if (isItemAnalysisQuery) {
      return await analyzeItemPerformanceAndSuggestions();
    }

    // 1. AI Strategic Advisory & Suggestions Router (PRIORITY over simple revenue lookup)
    const isStrategyQuery = 
      q.includes('تقترح') || q.includes('اقتراح') || q.includes('نصيح') || q.includes('توصي') || 
      q.includes('زيادة') || q.includes('ارفع') || q.includes('كيف') || q.includes('تطوير') || 
      q.includes('تحسين') || q.includes('استراتيج') || q.includes('خطة') || q.includes('حلول') ||
      q.includes('suggest') || q.includes('tip') || q.includes('advice') || q.includes('recommend') ||
      q.includes('increase') || q.includes('grow') || q.includes('improve') || q.includes('strategy') ||
      q.includes('boost') || q === 'profit_strategy' || (q.includes('profit') && (q.includes('more') || q.includes('how') || q.includes('raise')));

    if (isStrategyQuery) {
      return await generateStrategicProfitAdvice();
    }

    const items = (await DB.getAll('items')) || [];
    const allSales = await _getAllSales();
    const customers = (await DB.getAll('customers')) || [];

    // Check if query is asking for an Executive Business Report (in any language)
    const isReportQuery = 
      q === 'report' || q === 'reports' || q === 'print_report' ||
      q.includes('تقرير') || q.includes('تقارير') || q.includes('كشف') || q.includes('ملخص') ||
      q.includes('report') || q.includes('rapport') || q.includes('informe') || q.includes('reporte') ||
      q.includes('rapor') || q.includes('bericht') || q.includes('p&l') || q.includes('statement') ||
      q.includes('طباعة') || q.includes('print') || q.includes('imprimer');

    if (isReportQuery) {
      return await generateExecutiveAIReport(q, detectedLang, items, allSales, customers);
    }

    // Check if query is explicitly asking about a specific item
    const matchedItem = _findMatchingItem(q, items);
    if (matchedItem) {
      return generateSingleItemAnalytics(matchedItem, allSales, isAR);
    }

    // Check if query is explicitly asking about a specific customer
    const matchedCust = _findMatchingCustomer(q, customers);
    if (matchedCust) {
      return generateSingleCustomerAnalytics(matchedCust, allSales, isAR);
    }

    // Check if query is about cashbox / drawer
    if (q.includes('صندوق') || q.includes('درج') || q.includes('كاشير') || q.includes('cashbox') || q.includes('drawer') || q.includes('session') ||
        q.includes('caisse') || q.includes('caja') || q.includes('kasa')) {
      return await generateCashboxSummary(isAR);
    }

    const itemMap = new Map();
    items.forEach(i => {
      if (i.id) itemMap.set(String(i.id), i);
      if (i.item_code) itemMap.set(String(i.item_code), i);
    });

    // ── Intelligent Universal Timeframe Detection ──
    const tf = _parseTimeframeFilter(q, allSales, detectedLang);
    const targetInvoices = tf.invoices;
    const timeframeLabelAR = tf.labelAR;
    const timeframeLabelEN = tf.labelEN;

    const filteredTotalUSD = targetInvoices.reduce((sum, i) => sum + i._total, 0);
    const filteredCount = targetInvoices.length;
    let filteredCostUSD = 0;
    let missingCostItemsCount = 0;

    targetInvoices.forEach(i => {
      (i._items || []).forEach(line => {
        let cost = parseFloat(line.cost_price);
        if (isNaN(cost) || cost === 0) {
          const matched = itemMap.get(String(line.item_id || line.id)) || itemMap.get(String(line.item_code));
          cost = matched ? (parseFloat(matched.cost_price) || 0) : 0;
        }
        if (cost === 0) missingCostItemsCount++;
        filteredCostUSD += cost * (parseFloat(line.qty) || 1);
      });
    });

    const grossProfitUSD = Math.max(0, filteredTotalUSD - filteredCostUSD);
    const marginPct = filteredTotalUSD > 0 ? ((grossProfitUSD / filteredTotalUSD) * 100).toFixed(1) : 0;
    const avgBasket = filteredCount > 0 ? (filteredTotalUSD / filteredCount) : 0;

    let cashTxns = (await DB.getAll('cash_transactions')) || [];
    let syncCfg = { role: 'server', branchId: 'main' };
    try {
      if (typeof window !== 'undefined' && window.BranchSync && typeof window.BranchSync.getConfig === 'function') {
        syncCfg = await window.BranchSync.getConfig();
      }
    } catch(e) {}
    if (syncCfg.role !== 'server') {
      const myBranch = (syncCfg.branchId || 'main').toLowerCase();
      cashTxns = cashTxns.filter(t => {
        const b = String(t.branch_id || t.syncBranchId || '').trim().toLowerCase();
        return b === myBranch || (!b && myBranch === 'main');
      });
    }

    let periodExpenses = 0;
    cashTxns.forEach(t => {
      if (t.type === 'expense' || t.type === 'payment') {
        const dObj = _parseInvoiceDate(t.date || t.created_at);
        if (tf.isToday) {
          if (_isToday(dObj, t.date || t.created_at)) periodExpenses += parseFloat(t.amount) || 0;
        } else if (dObj) {
          if (tf.startDate && tf.endDate) {
            if (dObj >= tf.startDate && dObj <= tf.endDate) periodExpenses += parseFloat(t.amount) || 0;
          } else {
            periodExpenses += parseFloat(t.amount) || 0;
          }
        }
      }
    });
    const netProfitUSD = grossProfitUSD - periodExpenses;

    // 1. Sales & Revenue / Profit Summary
    const isSalesQuery = 
      q.includes('sale') || q.includes('sell') || q.includes('sold') || q.includes('revenue') ||
      q.includes('profit') || q.includes('income') || q.includes('turnover') || q.includes('cogs') || q.includes('margin') ||
      q.includes('مبيع') || q.includes('بيع') || q.includes('بعت') || q.includes('بعنا') ||
      q.includes('ارباح') || q.includes('أرباح') || q.includes('ربح') || q.includes('دخل') ||
      q.includes('ايراد') || q.includes('إيراد') || q.includes('تكلفة') || q.includes('هامش') ||
      q.includes('today') || q.includes('daily') || q.includes('day') ||
      q.includes('اليوم') || q.includes('يومي') || q.includes('اليومي') || q.includes('يومية') || q.includes('اليومية') ||
      q.includes('امس') || q.includes('أمس') || q.includes('yesterday') ||
      q.includes('اسبوع') || q.includes('أسبوع') || q.includes('week') ||
      q.includes('شهر') || q.includes('month') || q.includes('سنة') || q.includes('عام') || q.includes('year') ||
      q.includes('فترة') || q.includes('period') || q.includes('تاريخ') || q.includes('date') ||
      q.includes('جميع') || q.includes('لكل') || q === 'sales' ||
      q.includes('vente') || q.includes('bénéfice') || q.includes('benefice') ||
      q.includes('ganancia') || q.includes('satış') || q.includes('kâr') || q.includes('kar') || q.includes('ciro');

    if (isSalesQuery) {
      const zeroCostNotice = (grossProfitUSD === 0 && filteredTotalUSD > 0) ? `
        <div style="margin-top:8px;padding:8px 10px;background:rgba(234,179,8,0.12);border:1px solid rgba(234,179,8,0.3);border-radius:6px;font-size:0.75rem;color:#facc15">
          ⚠️ <strong>${isAR ? 'تنبيه تكلفة الأصناف:' : 'Cost Price Notice:'}</strong> ${isAR ? 'الربح يظهر $0.00 لأن أسعار التكلفة (Cost Price) للأصناف المباعة مسجلة بصفر أو غير محددة في كرت الصنف. لتفعيل حساب الأرباح بدقة، يرجى تعبئة سعر التكلفة في شاشة الأصناف.' : 'Gross profit shows $0.00 because cost prices for the sold items are registered as $0.00 in the catalog. Set cost prices in Items screen to unlock live margin calculation.'}
        </div>
      ` : '';

      const zeroSalesNotice = (filteredCount === 0) ? `
        <div style="margin-top:10px;padding:10px 12px;background:rgba(56,189,248,0.09);border:1px solid rgba(56,189,248,0.25);border-radius:8px;font-size:0.78rem;color:#7dd3fc;line-height:1.5">
          ℹ️ <strong>${isAR ? 'تنبيه الفترة المحددة:' : 'Timeframe Notice:'}</strong> ${isAR ? `لم يتم تسجيل أي مبيعات خلال (${timeframeLabelAR}) حتى الآن (0 فواتير). ستتحدث الأرقام والأرباح فورياً وبشكل تلقائي بمجرد تسجيل أي عملية بيع جديدة من شاشة الكاشير.` : `No sales transactions recorded for (${timeframeLabelEN}) yet (0 invoices). Live revenue and gross profit will automatically reflect here as soon as a sale is registered at the POS.`}
        </div>
      ` : '';

      return {
        title: isAR ? `📊 تحليل المبيعات والأرباح (${timeframeLabelAR})` : `📊 ${timeframeLabelEN} Sales & Profit Analytics`,
        content: `
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
            <div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">📈 ${isAR?'إجمالي المبيعات':'Total Sales'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:#22c55e">${Utils.formatMoney(filteredTotalUSD)}</div>
              <div style="font-size:0.68rem;color:var(--text-muted)">${filteredCount} ${isAR?'فاتورة':'invoices'}</div>
            </div>
            <div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">📦 ${isAR?'تكلفة البضاعة (COGS)':'Total Cost (COGS)'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:#f87171">${Utils.formatMoney(filteredCostUSD)}</div>
              <div style="font-size:0.68rem;color:var(--text-muted)">${isAR?'تكلفة المبيعات':'Cost of Sales'}</div>
            </div>
            <div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">💰 ${isAR?'مجمل الربح':'Gross Profit'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:#38bdf8">${Utils.formatMoney(grossProfitUSD)}</div>
              <div style="font-size:0.68rem;color:#eab308;font-weight:700">${marginPct}% ${isAR?'هامش':'margin'}</div>
            </div>
            <div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border-color)">
              <div style="font-size:0.7rem;color:var(--text-muted)">🏆 ${isAR?'صافي الربح':'Net Profit'}</div>
              <div style="font-size:1.15rem;font-weight:800;color:${netProfitUSD>=0?'#22c55e':'#ef4444'}">${Utils.formatMoney(netProfitUSD)}</div>
              <div style="font-size:0.68rem;color:var(--text-muted)">${periodExpenses > 0 ? (isAR ? `مصاريف: -${Utils.formatMoney(periodExpenses)}` : `Exp: -${Utils.formatMoney(periodExpenses)}`) : (isAR ? 'بدون مصاريف' : 'Zero Expenses')}</div>
            </div>
          </div>
          ${zeroCostNotice}
          ${zeroSalesNotice}
          ${filteredCount > 0 ? `
            <div style="margin-top:8px;font-size:0.78rem;color:#f1f5f9;background:rgba(255,255,255,0.08);padding:9px 12px;border-radius:6px;border:1px solid rgba(255,255,255,0.15);line-height:1.5">
              💡 <strong style="color:#38bdf8">${isAR?'رؤية الذكاء الاصطناعي:':'AI Insight:'}</strong> ${isAR ? `متوسط قيمة السلة ${Utils.formatMoney(avgBasket)}. مجمل الربح المحقق هو ${Utils.formatMoney(grossProfitUSD)} وصافي الربح بعد خصم المصاريف هو ${Utils.formatMoney(netProfitUSD)}.` : `Average basket value is ${Utils.formatMoney(avgBasket)}. Realized gross profit is ${Utils.formatMoney(grossProfitUSD)} and net profit after operating expenses is ${Utils.formatMoney(netProfitUSD)}.`}
            </div>
          ` : ''}
          <div style="margin-top:10px;display:flex;flex-direction:column;gap:6px">
            ${filteredCount === 0 && tf.isToday ? `
              <button class="btn btn-secondary btn-sm" style="width:100%;font-size:0.75rem;background:linear-gradient(135deg,rgba(99,102,241,0.2),rgba(168,85,247,0.2));border:1px solid rgba(168,85,247,0.4);color:#c084fc;font-weight:700" onclick="AICopilot.ask('all time sales')">
                📈 ${isAR ? 'عرض مبيعات وأرباح كل الأيام (All-Time)' : 'View All-Time Sales & Profit'}
              </button>
              <button class="btn btn-secondary btn-sm" style="width:100%;font-size:0.73rem" onclick="AICopilot.ask('yesterday sales')">
                📅 ${isAR ? 'عرض مبيعات وأرباح أمس (Yesterday)' : 'View Yesterday\'s Sales'}
              </button>
            ` : ''}
            <button class="btn btn-secondary btn-sm" style="width:100%;font-size:0.75rem;background:linear-gradient(135deg,rgba(99,102,241,0.2),rgba(168,85,247,0.2));border:1px solid rgba(168,85,247,0.4);color:#c084fc;font-weight:700" onclick="AICopilot.ask('profit_strategy')">
              💡 ${isAR ? 'ماذا تقترح لزيادة الأرباح وتطوير العمل؟' : 'AI Suggestions: How to boost profits?'}
            </button>
            <button class="btn btn-secondary btn-sm" style="width:100%;font-size:0.73rem" onclick="AICopilot.ask('items_analysis')">
              🏷️ ${isAR ? 'تحليل أداء الأصناف والأصناف ضعيفة البيع' : 'Analyze Item Performance & Stagnant Items'}
            </button>
          </div>
        `
      };
    }

    // 2. Low Stock & Reorder Suggestions
    if (q.includes('stock') || q.includes('low') || q.includes('reorder') || q.includes('نقص') || q.includes('مخزون') || q.includes('طلب')) {
      const forecast = await computeInventoryForecast();
      const critical = forecast.filter(f => f.urgency === 'critical' || f.urgency === 'warning').slice(0, 5);

      if (!critical.length) {
        return {
          title: isAR ? '✅ حالة المخزون ممتازة' : '✅ Stock Health is Optimal',
          content: `<p style="font-size:0.85rem;color:#22c55e">🎉 ${isAR ? 'جميع الأصناف متوفرة ولا يوجد نقص حرج في المخزون حالياً.' : 'All items are well-stocked. No critical inventory shortages detected.'}</p>`
        };
      }

      const rows = critical.map(c => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border-color);font-size:0.78rem">
          <div>
            <strong>${Utils.sanitize(isAR ? (c.item.name_ar || c.item.name_en) : (c.item.name_en || c.item.name_ar))}</strong>
            <div style="color:var(--text-muted);font-size:0.72rem">${isAR?'متبقي:':'Stock:'} <span style="color:#ef4444;font-weight:700">${c.stock}</span> | ${isAR?'يكفي':'Runout:'} ${c.daysLeft} ${isAR?'أيام':'days'}</div>
          </div>
          <div style="text-align:right">
            <span style="background:rgba(239,68,68,0.15);color:#ef4444;padding:2px 6px;border-radius:4px;font-weight:700;font-size:0.7rem">+${c.suggestedReorderQty} ${isAR?'اطلب':'order'}</span>
          </div>
        </div>
      `).join('');

      return {
        title: isAR ? '⚠️ أصناف تحتاج إعادة طلب عاجل' : '⚠️ Critical Stock Reorder Alerts',
        content: `
          <div style="margin-top:6px">${rows}</div>
          <button class="btn btn-primary btn-sm" style="width:100%;margin-top:10px" onclick="App.navigate('purchase-order'); AICopilot.close();">
            🚚 ${isAR ? 'إنشاء أمر شراء سريع' : 'Create Purchase Order Now'}
          </button>
        `
      };
    }

    // 2.4. Fastest Selling and Slow-Moving Products
    const isFastAndSlow = (q.includes('fast') || q.includes('سريع')) && (q.includes('slow') || q.includes('راكد') || q.includes('بطي'));
    if (isFastAndSlow) {
      const itemMapSales = {};
      allSales.forEach(inv => {
        (inv._items || []).forEach(l => {
          const name = isAR ? (l.name_ar || l.name_en || l.name) : (l.name_en || l.name_ar || l.name);
          const qty = parseFloat(l.qty) || 0;
          const rev = parseFloat(l.total) || ((parseFloat(l.price || l.unit_price || 0)) * qty);
          if (name) {
            if (!itemMapSales[name]) itemMapSales[name] = { qty: 0, rev: 0 };
            itemMapSales[name].qty += qty;
            itemMapSales[name].rev += rev;
          }
        });
      });
      const fastItems = Object.entries(itemMapSales).sort((a,b) => b[1].qty - a[1].qty).slice(0, 5);
      const slowItems = items.filter(it => (parseFloat(it.stock_qty || it.quantity || 0) > 0) && (!itemMapSales[it.name_en || it.name_ar || it.name] || itemMapSales[it.name_en || it.name_ar || it.name].qty <= 1)).slice(0, 5);

      return {
        title: isAR ? '🚀 حركة الأصناف: سريعة الدوران والراكدة' : '🚀 Product Velocity: Fast-Moving vs Slow-Moving',
        content: `
          <div style="margin-bottom:10px;background:rgba(34,197,94,0.06);border:1px solid rgba(34,197,94,0.25);border-radius:8px;padding:10px">
            <div style="font-weight:800;color:#22c55e;font-size:0.82rem;margin-bottom:6px">⚡ ${isAR?'الأصناف الأكثر والأسرع مبيعاً:':'Fastest-Selling Products (High Velocity):'}</div>
            ${fastItems.length ? fastItems.map(([name, d], idx) => `
              <div style="display:flex;justify-content:space-between;font-size:0.75rem;padding:3px 0;border-bottom:1px solid rgba(255,255,255,0.05)">
                <span>#${idx+1} <strong>${Utils.sanitize(name)}</strong></span>
                <span style="font-weight:700;color:#22c55e">${d.qty} ${isAR?'مباع':'sold'} (${Utils.formatMoney(d.rev)})</span>
              </div>
            `).join('') : `<p style="font-size:0.75rem;color:var(--text-muted)">${isAR?'لا توجد مبيعات مسجلة بعد':'No sales recorded yet'}</p>`}
          </div>

          <div style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.25);border-radius:8px;padding:10px">
            <div style="font-weight:800;color:#ef4444;font-size:0.82rem;margin-bottom:6px">📉 ${isAR?'الأصناف الراكدة وبطيئة الحركة (بحاجة لتنشيط):':'Slow-Moving / Stagnant Products (Low Velocity):'}</div>
            ${slowItems.length ? slowItems.map(it => `
              <div style="display:flex;justify-content:space-between;font-size:0.75rem;padding:3px 0;border-bottom:1px solid rgba(255,255,255,0.05)">
                <span><strong>${Utils.sanitize(isAR ? (it.name_ar || it.name_en) : (it.name_en || it.name_ar))}</strong></span>
                <span style="color:#ef4444;font-weight:700">${isAR?'المخزون:':'Stock:'} ${it.stock_qty || 0} (${isAR?'مبيعاته 0':'0 sold'})</span>
              </div>
            `).join('') : `<p style="font-size:0.75rem;color:var(--text-muted)">${isAR?'لا توجد أصناف راكدة حالياً':'No stagnant items detected'}</p>`}
          </div>
        `
      };
    }

    // 2.5. Top Profitable Products (e.g. Which 10 products made me the most profit this month?)
    const isTopProfitQuery = (q.includes('profit') || q.includes('ارباح') || q.includes('ربح') || q.includes('bénéfice') || q.includes('ganancia')) &&
      (q.includes('product') || q.includes('item') || q.includes('منتج') || q.includes('صنف') || q.includes('10') || q.includes('most') || q.includes('اكثر') || q.includes('أكثر') || q.includes('اعلى') || q.includes('أعلى'));

    if (isTopProfitQuery) {
      const itemMapProfit = {};
      targetInvoices.forEach(inv => {
        (inv._items || []).forEach(l => {
          const name = isAR ? (l.name_ar || l.name_en || l.name) : (l.name_en || l.name_ar || l.name);
          const qty = parseFloat(l.qty) || 0;
          const rev = parseFloat(l.total) || ((parseFloat(l.price || l.unit_price || 0)) * qty);
          let cost = parseFloat(l.cost_price);
          if (isNaN(cost) || cost === 0) {
            const matched = itemMap.get(String(l.item_id || l.id)) || itemMap.get(String(l.item_code));
            cost = matched ? (parseFloat(matched.cost_price) || 0) : 0;
          }
          const totalCost = cost * qty;
          const profit = rev - totalCost;
          if (name) {
            if (!itemMapProfit[name]) itemMapProfit[name] = { qty: 0, rev: 0, cost: 0, profit: 0 };
            itemMapProfit[name].qty += qty;
            itemMapProfit[name].rev += rev;
            itemMapProfit[name].cost += totalCost;
            itemMapProfit[name].profit += profit;
          }
        });
      });

      const sortedProfits = Object.entries(itemMapProfit).sort((a, b) => b[1].profit - a[1].profit).slice(0, 10);
      if (!sortedProfits.length) {
        return {
          title: isAR ? `💰 أكثر 10 أصناف تحقيقاً للأرباح (${timeframeLabelAR})` : `💰 Top 10 Most Profitable Products (${timeframeLabelEN})`,
          content: `<p style="font-size:0.8rem;color:var(--text-muted)">${isAR ? 'لا توجد مبيعات مسجلة في هذه الفترة لحساب الأرباح.' : 'No sales recorded in this timeframe to compute product profits.'}</p>`
        };
      }

      const rows = sortedProfits.map(([name, data], idx) => {
        const margin = data.rev > 0 ? ((data.profit / data.rev) * 100).toFixed(1) : 0;
        return `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--border-color);font-size:0.78rem">
            <div>
              <span style="color:#eab308;font-weight:800">#${idx+1}</span> <strong>${Utils.sanitize(name)}</strong>
              <div style="font-size:0.7rem;color:var(--text-muted)">${data.qty} ${isAR?'مباع':'sold'} | ${isAR?'إيراد:':'Rev:'} ${Utils.formatMoney(data.rev)} | ${isAR?'تكلفة:':'Cost:'} ${Utils.formatMoney(data.cost)}</div>
            </div>
            <div style="text-align:right">
              <div style="font-weight:800;color:#22c55e">${Utils.formatMoney(data.profit)}</div>
              <div style="font-size:0.68rem;color:#eab308;font-weight:700">${margin}% ${isAR?'هامش':'margin'}</div>
            </div>
          </div>
        `;
      }).join('');

      return {
        title: isAR ? `💰 أكثر 10 أصناف تحقيقاً للأرباح (${timeframeLabelAR})` : `💰 Top 10 Most Profitable Products (${timeframeLabelEN})`,
        content: `
          <div style="margin-top:6px">${rows}</div>
          <div style="margin-top:10px;padding:8px;background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.25);border-radius:6px;font-size:0.75rem;color:var(--text-secondary)">
            💡 <strong>${isAR?'توصية الذكاء الاصطناعي:':'AI Insight:'}</strong> ${isAR ? 'الأصناف ذات هوامش الربح العالية هي الأكثر أهمية للتركيز عليها في الواجهة والعروض لتعظيم العائد الصافي.' : 'These top high-margin items yield the bulk of your net profit. Prioritize their stock availability and prime shelf visibility.'}
          </div>
        `
      };
    }

    // 2.6. Supplier Debts & Payables (How much money do I currently owe each supplier?)
    if (q.includes('owe') || q.includes('supplier') || q.includes('fournisseur') || q.includes('مورد') || q.includes('موردين') || q.includes('مستحق')) {
      const suppliers = (await DB.getAll('suppliers')) || [];
      const activeSuppliers = suppliers.filter(s => parseFloat(s.balance || s.current_balance || 0) > 0).sort((a, b) => parseFloat(b.balance||0) - parseFloat(a.balance||0));
      const totalPayables = suppliers.reduce((s, sup) => s + Math.max(0, parseFloat(sup.balance || sup.current_balance || 0)), 0);

      const supplierRows = activeSuppliers.map((sup, idx) => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid var(--border-color);font-size:0.78rem">
          <div>
            <span style="color:#eab308;font-weight:800">#${idx+1}</span> <strong>${Utils.sanitize(sup.name_en || sup.name_ar || sup.name)}</strong>
            ${sup.phone ? `<div style="font-size:0.7rem;color:var(--text-muted)">📞 ${Utils.sanitize(sup.phone)}</div>` : ''}
          </div>
          <div style="text-align:right">
            <span style="color:#ef4444;font-weight:800;font-size:0.85rem">${Utils.formatMoney(parseFloat(sup.balance || sup.current_balance || 0))}</span>
          </div>
        </div>
      `).join('');

      return {
        title: isAR ? '🚚 ذمم ومستحقات الموردين' : '🚚 Outstanding Supplier Balances (Accounts Payable)',
        content: `
          <div style="background:var(--surface);padding:10px;border-radius:8px;border:1px solid var(--border-color);margin-bottom:10px">
            <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'إجمالي المستحقات والديون لجميع الموردين:':'Total Money Owed to Suppliers:'}</div>
            <div style="font-size:1.35rem;font-weight:800;color:#ef4444">${Utils.formatMoney(totalPayables)}</div>
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:2px">${suppliers.length} ${isAR?'مورد مسجل':'registered suppliers'} (${activeSuppliers.length} ${isAR?'عليهم رصيد مستحق':'with pending balances'})</div>
          </div>
          ${activeSuppliers.length ? `
            <div style="margin-bottom:10px">${supplierRows}</div>
          ` : `<p style="color:#22c55e;font-size:0.82rem;margin-bottom:10px">🎉 ${isAR?'جميع حسابات الموردين مسددة بالكامل (لا توجد ذمم مستحقة للموردين).':'All supplier accounts are fully settled. You currently owe $0.00.'}</p>`}
          <div style="display:flex;gap:6px">
            <button class="btn btn-primary btn-sm" style="flex:1" onclick="App.navigate('supplier-payments'); AICopilot.close();">
              💵 ${isAR ? 'تسجيل دفعة لمورد' : 'Pay Supplier'}
            </button>
            <button class="btn btn-secondary btn-sm" style="flex:1" onclick="App.navigate('suppliers'); AICopilot.close();">
              📄 ${isAR ? 'كشوف حساب الموردين' : 'View Supplier Ledgers'}
            </button>
          </div>
        `
      };
    }

    // 3. Top Best Sellers
    if (q.includes('top') || q.includes('best') || q.includes('popular') || q.includes('افضل') || q.includes('أفضل') || q.includes('اكثر') || q.includes('أكثر')) {
      const itemMapSales = {};
      allSales.forEach(inv => {
        (inv._items || []).forEach(l => {
          const name = isAR ? (l.name_ar || l.name_en || l.name) : (l.name_en || l.name_ar || l.name);
          const qty = parseFloat(l.qty) || 0;
          const rev = parseFloat(l.total) || ((parseFloat(l.price || l.unit_price || 0)) * qty);
          if (name) {
            if (!itemMapSales[name]) itemMapSales[name] = { qty: 0, rev: 0 };
            itemMapSales[name].qty += qty;
            itemMapSales[name].rev += rev;
          }
        });
      });

      const sorted = Object.entries(itemMapSales).sort((a, b) => b[1].rev - a[1].rev).slice(0, 5);
      if (!sorted.length) {
        return {
          title: isAR ? '🏆 الأصناف الأكثر مبيعاً' : '🏆 Top Best-Selling Products',
          content: `<p style="font-size:0.8rem;color:var(--text-muted)">${isAR ? 'لا توجد بيانات مبيعات كافية حتى الآن.' : 'No sales data accumulated yet.'}</p>`
        };
      }

      const listHtml = sorted.map(([name, data], idx) => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid var(--border-color);font-size:0.78rem">
          <div><span style="color:#eab308;font-weight:800">#${idx+1}</span> <strong>${Utils.sanitize(name)}</strong></div>
          <div style="font-weight:700;color:var(--primary)">${data.qty} ${isAR?'قطعة':'units'} (${Utils.formatMoney(data.rev)})</div>
        </div>
      `).join('');

      return {
        title: isAR ? '🏆 المنتجات الأكثر مبيعاً والأعلى إيراداً' : '🏆 Top Revenue Generating Items',
        content: `<div style="margin-top:6px">${listHtml}</div>`
      };
    }

    // 4. Customer Debts & Balances
    if (q.includes('customer') || q.includes('debt') || q.includes('credit') || q.includes('عملاء') || q.includes('ديون') || q.includes('ذمم')) {
      const debtors = (customers || []).filter(c => (parseFloat(c.balance || c.current_balance || 0) > 0)).sort((a, b) => (parseFloat(b.balance||0) - parseFloat(a.balance||0))).slice(0, 5);
      const totalDebt = (customers || []).reduce((s, c) => s + Math.max(0, parseFloat(c.balance || c.current_balance || 0)), 0);

      const debtorRows = debtors.map(d => `
        <div style="display:flex;justify-content:space-between;font-size:0.78rem;padding:5px 0;border-bottom:1px solid var(--border-color)">
          <span>${Utils.sanitize(d.name || d.customer_name)}</span>
          <span style="color:#ef4444;font-weight:700">${Utils.formatMoney(parseFloat(d.balance || d.current_balance || 0))}</span>
        </div>
      `).join('');

      return {
        title: isAR ? '👥 ذمم وديون العملاء المستحقة' : '👥 Outstanding Customer Balances',
        content: `
          <div style="font-size:0.8rem;margin-bottom:8px">
            ${isAR?'إجمالي الديون المستحقة:':'Total Receivables:'} <strong style="color:#ef4444">${Utils.formatMoney(totalDebt)}</strong>
          </div>
          ${debtorRows ? `<div style="margin-bottom:8px">${debtorRows}</div>` : `<p style="color:#22c55e;font-size:0.8rem">${isAR?'لا توجد ديون متأخرة':'No outstanding customer debt.'}</p>`}
          <button class="btn btn-secondary btn-sm" style="width:100%" onclick="App.navigate('customer-receipts'); AICopilot.close();">
            💵 ${isAR ? 'تسجيل سند قبض عميل' : 'Receive Payment'}
          </button>
        `
      };
    }

    // Default Fallback / Smart General Overview
    const totalItems = items.length;
    const totalCustomers = customers.length;
    const totalInvoices = allSales.length;

    return {
      title: isAR ? '🤖 مساعد Red Shark الذكي' : '🤖 Red Shark AI Business Copilot',
      content: `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
          <div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border-color)">
            <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'مبيعات اليوم':'Today\'s Sales'}</div>
            <div style="font-size:1.05rem;font-weight:800;color:#22c55e">${Utils.formatMoney(allSales.filter(i => _isToday(i._dateObj, i._rawDate)).reduce((s, i) => s + i._total, 0))}</div>
          </div>
          <div style="background:var(--surface);padding:8px 10px;border-radius:8px;border:1px solid var(--border-color)">
            <div style="font-size:0.7rem;color:var(--text-muted)">${isAR?'إجمالي كل المبيعات':'All-Time Sales'}</div>
            <div style="font-size:1.05rem;font-weight:800;color:#38bdf8">${Utils.formatMoney(allSales.reduce((s, i) => s + i._total, 0))}</div>
          </div>
        </div>
        <p style="font-size:0.8rem;line-height:1.4;margin-bottom:10px">
          ${isAR ? `نظامك يدير حالياً <strong>${totalItems} صنفاً</strong> و <strong>${totalCustomers} عميلاً</strong> بإجمالي <strong>${totalInvoices} عملية بيع</strong> مسجلة.` : `Currently tracking <strong>${totalItems} products</strong> and <strong>${totalCustomers} customers</strong> across <strong>${totalInvoices} transactions</strong>.`}
        </p>
        <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:8px">${isAR?'أمثلة على أسئلة يمكنك كتابتها مباشرة:':'Direct questions you can ask:'}</div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.77rem;background:linear-gradient(135deg,rgba(34,197,94,0.18),rgba(16,185,129,0.18));border:1px solid rgba(34,197,94,0.45);color:#4ade80;font-weight:800;padding:7px 12px;border-radius:8px" onclick="AICopilot.ask('today sales')">📅 ${isAR ? 'مبيعات وأرباح اليوم (Today\'s Sales & Profit)' : 'Today\'s Sales & Live Gross Profit'}</button>
          <button class="btn btn-sm" style="text-align:left;font-size:0.77rem;background:linear-gradient(135deg,rgba(99,102,241,0.25),rgba(168,85,247,0.25));border:1px solid rgba(168,85,247,0.5);color:#e9d5ff;font-weight:800;padding:8px 12px;border-radius:8px" onclick="AICopilot.ask('ما هي ارباح جميع مبيعاتي لكل الايام؟')">📈 ${isAR ? 'ما هي أرباح ومبيعات جميع الأيام (All-Time)؟' : 'What are my all-time sales and gross profit?'}</button>
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.75rem" onclick="AICopilot.ask('report')">📑 ${isAR ? 'توليد وطباعة تقرير تنفيذي شامل (Executive Report)' : 'Generate & Print Executive Business Report (PDF)'}</button>
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.75rem" onclick="AICopilot.ask('profit_strategy')">💡 ${isAR ? 'ماذا يقترح الذكاء الاصطناعي لزيادة الأرباح وتطوير العمل؟' : 'AI Strategic Plan: How to boost profits and business growth?'}</button>
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.75rem" onclick="AICopilot.ask('items_analysis')">🏷️ ${isAR ? 'تحليل أداء الأصناف والأصناف الراكدة وضعيفة البيع' : 'Analyze Item Performance & Low-Sales Products'}</button>
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.75rem" onclick="AICopilot.ask('صندوق')">💵 ${isAR ? 'حالة الصندوق والدرج النقدي' : 'Cashbox & Drawer status'}</button>
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.75rem" onclick="AICopilot.ask('stock')">⚠️ ${isAR?'ما هي الأصناف المنتهية أو القريبة من النفاذ؟':'Which items are running low on stock?'}</button>
          <button class="btn btn-secondary btn-sm" style="text-align:left;font-size:0.75rem" onclick="AICopilot.ask('debt')">👥 ${isAR?'كم تبلغ ديون وذمم العملاء؟':'What is the outstanding customer debt?'}</button>
        </div>
      `
    };
  }

  // ── Smart Bilingual Catalog Assistant ──────────────────────────
  function translateItemBilingual(enText) {
    if (!enText) return '';
    const clean = enText.trim();
    
    // Built-in intelligent retail glossary
    const glossary = {
      'water': 'مياه',
      'juice': 'عصير',
      'milk': 'حليب',
      'coffee': 'قهوة',
      'tea': 'شاي',
      'sugar': 'سكر',
      'rice': 'أرز',
      'oil': 'زيت',
      'bread': 'خبز',
      'cheese': 'جبنة',
      'chocolate': 'شوكولاتة',
      'chips': 'رقائق بطاطس',
      'biscuit': 'بسكويت',
      'soda': 'مشروب غازي',
      'cola': 'كولا',
      'energy drink': 'مشروب طاقة',
      'shampoo': 'شامبو',
      'soap': 'صابون',
      'tissue': 'محارم ورقية',
      'tissues': 'مناديل ورقية',
      'cleaner': 'منظف',
      'sauce': 'صلصة',
      'ketchup': 'كاتشب',
      'mayo': 'مايونيز',
      'butter': 'زبدة',
      'meat': 'لحم',
      'chicken': 'دجاج',
      'fish': 'سمك',
      'large': 'كبير',
      'medium': 'وسط',
      'small': 'صغير',
      'pack': 'عبوة',
      'box': 'علبة',
      'bottle': 'زجاجة',
      'can': 'علبة معدنية'
    };

    let words = clean.split(/\s+/);
    let translatedWords = words.map(w => {
      const lower = w.toLowerCase().replace(/[^a-z0-9]/g, '');
      return glossary[lower] || w;
    });

    return translatedWords.join(' ');
  }

  // ── UI Modal & Widget Mounting ─────────────────────────────────
  function mountWidget() {
    if (document.getElementById('ai-copilot-container')) return;

    const isAR = _isAppArabic();
    const isHidden = (typeof localStorage !== 'undefined' ? localStorage.getItem('hide_ai_floating_bubble') : null) === '1';

    const html = `
    <div id="ai-copilot-container">
      <!-- Floating Bubble Wrapper -->
      <div id="ai-copilot-bubble-wrap" style="position:fixed;bottom:24px;${isAR?'left:24px':'right:24px'};z-index:999;display:${isHidden ? 'none' : 'block'}">
        <button id="ai-copilot-bubble" onclick="AICopilot.toggle()" title="${isAR?'مساعد Red Shark الذكي':'Red Shark AI Copilot'}" style="position:relative;width:54px;height:54px;border-radius:50%;background:linear-gradient(135deg,#ef4444,#a855f7);border:none;box-shadow:0 8px 25px rgba(168,85,247,0.4);cursor:pointer;display:flex;align-items:center;justify-content:center;color:white;font-size:24px;transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1)">
          🤖
          <span onclick="event.stopPropagation(); AICopilot.hideBubble()" title="${isAR?'حذف / إخفاء الأيقونة العائمة':'Hide / Remove Floating Bubble'}" style="position:absolute;top:-4px;${isAR?'left:-4px':'right:-4px'};width:18px;height:18px;border-radius:50%;background:#ef4444;border:2px solid #0f172a;color:white;font-size:9px;font-weight:900;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.3)">
            ✕
          </span>
        </button>
      </div>

      <!-- Glassmorphic AI Panel -->
      <div id="ai-copilot-panel" style="display:none;position:fixed;bottom:90px;${isAR?'left:24px':'right:24px'};z-index:999;width:380px;max-width:calc(100vw - 48px);background:rgba(15,23,42,0.85);backdrop-filter:blur(20px);border:1px solid rgba(168,85,247,0.3);border-radius:18px;box-shadow:0 25px 50px -12px rgba(0,0,0,0.6);overflow:hidden;animation:fadeIn 0.2s ease">
        
        <!-- Header -->
        <div style="background:linear-gradient(135deg,rgba(239,68,68,0.2),rgba(168,85,247,0.2));padding:14px 18px;border-bottom:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;justify-content:space-between">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:1.3rem">🤖</span>
            <div>
              <div style="font-size:0.9rem;font-weight:800;color:white">Red Shark <span style="color:#c084fc">AI Copilot</span></div>
              <div style="font-size:0.7rem;color:#cbd5e1">${isAR?'مساعد الأعمال وتحليل البيانات الذكي':'Real-time Business & Predictive AI'}</div>
            </div>
          </div>
          <button onclick="AICopilot.close()" style="background:transparent;border:none;color:#94a3b8;font-size:18px;cursor:pointer;padding:4px">✕</button>
        </div>

        <!-- Body Content -->
        <div id="ai-copilot-content" style="padding:16px;max-height:360px;overflow-y:auto;color:#f8fafc">
          <!-- Content dynamically rendered -->
        </div>

        <!-- Input Bar -->
        <div style="padding:12px 16px;background:rgba(30,41,59,0.7);border-top:1px solid rgba(255,255,255,0.08);display:flex;gap:8px">
          <input type="text" id="ai-copilot-input" placeholder="${isAR?'اسأل عن المبيعات، المخزون، أو الديون...':'Ask about sales, stock, or debts...'}" style="flex:1;background:rgba(15,23,42,0.8);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:8px 12px;color:white;font-size:0.8rem;outline:none" onkeydown="if(event.key==='Enter') AICopilot.sendInput()">
          <button onclick="AICopilot.sendInput()" class="btn btn-primary" style="padding:6px 12px;border-radius:10px;font-size:0.8rem">
            ➤
          </button>
        </div>
      </div>
    </div>`;

    if (typeof document !== 'undefined' && document.body) {
      document.body.insertAdjacentHTML('beforeend', html);
    }
  }

  function hideBubble() {
    const isAR = _isAppArabic();
    try { if (typeof localStorage !== 'undefined') localStorage.setItem('hide_ai_floating_bubble', '1'); } catch(e){}
    const wrap = document.getElementById('ai-copilot-bubble-wrap');
    if (wrap) wrap.style.display = 'none';
    if (window.Utils && typeof Utils.toast === 'function') {
      Utils.toast(isAR ? 'تم إخفاء الزر العائم. يمكنك فتح المساعد الذكي من الزر العلوي 🤖 في أي وقت.' : 'Floating bubble hidden. You can open AI Copilot from the topbar button anytime.', 'info');
    }
  }

  function showBubble() {
    try { if (typeof localStorage !== 'undefined') localStorage.removeItem('hide_ai_floating_bubble'); } catch(e){}
    const wrap = document.getElementById('ai-copilot-bubble-wrap');
    if (wrap) wrap.style.display = 'block';
  }

  function toggle() {
    let panel = document.getElementById('ai-copilot-panel');
    if (!panel) {
      mountWidget();
      panel = document.getElementById('ai-copilot-panel');
    }
    if (!panel) return;
    if (panel.style.display === 'none' || !panel.style.display) {
      panel.style.display = 'block';
      ask('overview');
    } else {
      panel.style.display = 'none';
    }
  }

  function close() {
    const panel = document.getElementById('ai-copilot-panel');
    if (panel) panel.style.display = 'none';
  }

  async function ask(query) {
    let panel = document.getElementById('ai-copilot-panel');
    if (!panel) {
      mountWidget();
      panel = document.getElementById('ai-copilot-panel');
    }
    if (panel) panel.style.display = 'block';

    const contentEl = document.getElementById('ai-copilot-content');
    if (!contentEl) return;
    contentEl.innerHTML = `
      <div style="text-align:center;padding:20px;color:#c084fc">
        <div class="spinner-sm" style="margin:0 auto 10px"></div>
        <div style="font-size:0.78rem">Analyzing database records...</div>
      </div>`;

    try {
      const res = await processBusinessQuery(query);
      if (res && res.title) {
        contentEl.innerHTML = `
          <div style="font-size:0.85rem;font-weight:700;margin-bottom:8px;color:#c084fc">${res.title}</div>
          <div>${res.content || ''}</div>
        `;
      } else {
        contentEl.innerHTML = `
          <div style="padding:10px;color:var(--text-muted);font-size:0.8rem">No analysis results found.</div>
        `;
      }
    } catch(err) {
      console.error('AICopilot query processing failed:', err);
      contentEl.innerHTML = `
        <div style="padding:12px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;color:#fca5a5;font-size:0.78rem">
          <div style="font-weight:700;margin-bottom:4px">⚠️ Analysis Error</div>
          <div style="margin-bottom:8px">${Utils?.sanitize ? Utils.sanitize(err.message || 'Error executing AI analysis') : (err.message || 'Error')}</div>
          <button class="btn btn-secondary btn-sm" style="font-size:0.72rem;background:rgba(255,255,255,0.08)" onclick="AICopilot.ask('')">
            🔄 Main Menu
          </button>
        </div>
      `;
    }
  }

  function sendInput() {
    const input = document.getElementById('ai-copilot-input');
    const val = input?.value?.trim();
    if (!val) return;
    input.value = '';
    ask(val);
  }

  // Auto mount on document ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      mountWidget();
    });
  } else {
    setTimeout(mountWidget, 200);
  }

  return {
    playAudio,
    computeInventoryForecast,
    processBusinessQuery,
    translateItemBilingual,
    mountWidget,
    toggle,
    close,
    ask,
    sendInput,
    hideBubble,
    showBubble,
    printExecutiveReport
  };
})();

window.AICopilot = AICopilot;
