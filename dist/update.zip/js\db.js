/* ================================================================
   NexPOS — Database Layer (IndexedDB + localStorage fallback)
   ================================================================ */

const DB = (() => {
  const DB_NAME    = 'NexPOS_DB';
  const DB_VERSION = 10;
  let   _db        = null;

  const STORES = [
    { name: 'settings',         keyPath: 'key' },
    { name: 'fiscal_years',     keyPath: 'id', autoIncrement: true },
    { name: 'users',            keyPath: 'id', autoIncrement: true },
    { name: 'roles',            keyPath: 'id', autoIncrement: true },
    { name: 'categories',       keyPath: 'id', autoIncrement: true },
    { name: 'items',            keyPath: 'id', autoIncrement: true },
    { name: 'customers',        keyPath: 'id', autoIncrement: true },
    { name: 'suppliers',        keyPath: 'id', autoIncrement: true },
    { name: 'sales',            keyPath: 'id', autoIncrement: true },
    { name: 'sale_items',       keyPath: 'id', autoIncrement: true },
    { name: 'quotation',        keyPath: 'id', autoIncrement: true },
    { name: 'sales_orders',     keyPath: 'id', autoIncrement: true },
    { name: 'delivery_order',   keyPath: 'id', autoIncrement: true },
    { name: 'sales_invoice',    keyPath: 'id', autoIncrement: true },
    { name: 'sales_returns',    keyPath: 'id', autoIncrement: true },
    { name: 'deliveries',       keyPath: 'id', autoIncrement: true },
    { name: 'purchase_orders',  keyPath: 'id', autoIncrement: true },
    { name: 'po_items',         keyPath: 'id', autoIncrement: true },
    { name: 'goods_receipts',   keyPath: 'id', autoIncrement: true },
    { name: 'grn_items',        keyPath: 'id', autoIncrement: true },
    { name: 'purchase_invoices',keyPath: 'id', autoIncrement: true },
    { name: 'purchase_returns', keyPath: 'id', autoIncrement: true },
    { name: 'stock_adjustments',keyPath: 'id', autoIncrement: true },
    { name: 'stock_transfers',  keyPath: 'id', autoIncrement: true },
    { name: 'stock_movements',  keyPath: 'id', autoIncrement: true },
    { name: 'accounts',         keyPath: 'id', autoIncrement: true },
    { name: 'journals',         keyPath: 'id', autoIncrement: true },
    { name: 'journal_lines',    keyPath: 'id', autoIncrement: true },
    { name: 'cash_transactions',keyPath: 'id', autoIncrement: true },
    { name: 'bank_accounts',    keyPath: 'id', autoIncrement: true },
    { name: 'bank_transactions',keyPath: 'id', autoIncrement: true },
    { name: 'employees',        keyPath: 'id', autoIncrement: true },
    { name: 'departments',      keyPath: 'id', autoIncrement: true },
    { name: 'attendance',       keyPath: 'id', autoIncrement: true },
    { name: 'leave_requests',   keyPath: 'id', autoIncrement: true },
    { name: 'payroll_runs',     keyPath: 'id', autoIncrement: true },
    { name: 'payroll_lines',    keyPath: 'id', autoIncrement: true },
    { name: 'audit_log',        keyPath: 'id', autoIncrement: true },
    { name: 'currencies',       keyPath: 'id', autoIncrement: true },
    { name: 'price_lists',      keyPath: 'id', autoIncrement: true },
    { name: 'warehouses',       keyPath: 'id', autoIncrement: true },
    { name: 'sequences',        keyPath: 'key' },
    // Offers & Promotions
    { name: 'offers',           keyPath: 'id', autoIncrement: true },
    // Cash Box
    { name: 'cashbox_sessions',  keyPath: 'id', autoIncrement: true },
    { name: 'cashbox_movements', keyPath: 'id', autoIncrement: true },
    // Repair & Workshop Jobs
    { name: 'repair_jobs',       keyPath: 'id', autoIncrement: true },
    // Restaurant & F&B Suite Stores
    { name: 'restaurant_zones',           keyPath: 'id', autoIncrement: true },
    { name: 'restaurant_tables',          keyPath: 'id', autoIncrement: true },
    { name: 'restaurant_reservations',    keyPath: 'id', autoIncrement: true },
    { name: 'restaurant_delivery_orders', keyPath: 'id', autoIncrement: true },
    { name: 'item_modifiers',             keyPath: 'id', autoIncrement: true },
    { name: 'kitchen_printers',           keyPath: 'id', autoIncrement: true },
    { name: 'restaurant_orders',          keyPath: 'id', autoIncrement: true },
    { name: 'recipes',                    keyPath: 'id', autoIncrement: true },
  ];

  async function callApi(url, options = {}) {
    try {
      const apiUrl = window.location.origin.startsWith('http') 
        ? url 
        : `http://localhost:3000${url}`;
      const resp = await fetch(apiUrl, {
        signal: AbortSignal.timeout(15000),
        ...options
      });
      if (resp.ok) {
        return await resp.json();
      }
    } catch (e) {
      console.warn('Backend API connection failed:', e.message);
    }
    return null;
  }

  async function bulkSyncToServer(storeName, items, replace = false) {
    if ((!items || !items.length) && !replace) return;
    if ((!items || !items.length) && replace) {
      await callApi(`/api/db-bulk/${storeName}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: [], replace: true })
      });
      return;
    }
    const CHUNK_SIZE = 1000;
    for (let i = 0; i < items.length; i += CHUNK_SIZE) {
      const chunk = items.slice(i, i + CHUNK_SIZE);
      await callApi(`/api/db-bulk/${storeName}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(replace && i === 0 ? { items: chunk, replace: true } : chunk)
      });
    }
  }

  async function syncFromServer() {
    try {
      const resp = await callApi('/api/db-all');
      if (resp && resp.success && resp.data) {
        let nodeRole = 'server';
        try {
          const roleSetting = (resp.data.settings || []).find(s => s.key === 'sync_node_role');
          if (roleSetting && roleSetting.value) nodeRole = String(roleSetting.value).toLowerCase();
        } catch(e){}

        const TRANSACTIONAL_STORES = [
          'sales', 'sales_invoice', 'sale_items', 'quotation', 'sales_orders', 'delivery_order', 'sales_returns', 'deliveries',
          'purchase_invoices', 'purchase_returns', 'purchase_orders', 'goods_receipts', 'po_items', 'grn_items',
          'cash_transactions', 'bank_transactions', 
          'cashbox_sessions', 'cashbox_movements', 
          'stock_movements', 'stock_adjustments', 'audit_log'
        ];

        for (const storeName of STORES.map(s => s.name)) {
          if (!_db || !_db.objectStoreNames.contains(storeName)) continue;
          
          const serverItems = resp.data[storeName] || [];
          const isTransactional = TRANSACTIONAL_STORES.includes(storeName);

          await new Promise((resolve) => {
            try {
              const tx = _db.transaction(storeName, 'readwrite');
              const store = tx.objectStore(storeName);

              // ── 1. TRANSACTIONAL STORES (Sales, Invoices, Purchases, Cash Movements) ──
              // Branches have their own transactions. NEVER clear, delete, or overwrite by non-scoped ID!
              if (isTransactional) {
                const getAllReq = store.getAll();
                getAllReq.onsuccess = () => {
                  const localItems = getAllReq.result || [];
                  const localUuidMap = new Map();
                  const localBranchRefMap = new Map();
                  const localRefOnlyMap = new Map();
                  const localCompositeMap = new Map();
                  const localIdMap = new Map();

                  const getCompositeKey = (item) => {
                    if (!item) return null;
                    if (storeName === 'cashbox_movements') {
                      const desc = String(item.description || item.reason || '').trim();
                      const invMatch = desc.match(/INV-[A-Z0-9_-]+/i);
                      if (invMatch && item.type === 'sale') {
                        return `cbm_inv::${item.session_id || ''}::${invMatch[0].toUpperCase()}`;
                      }
                      return `cbm::${item.session_id || ''}::${item.type || ''}::${item.amount || 0}::${desc}::${String(item.created_at || '').slice(0, 19)}`;
                    }
                    if (storeName === 'cashbox_sessions') {
                      return `cbs::${item.terminal_id || ''}::${item.opened_at || ''}`;
                    }
                    if (storeName === 'stock_movements') {
                      return `stm::${item.item_id || ''}::${item.type || ''}::${item.ref || ''}::${item.qty || 0}::${String(item.created_at || '').slice(0, 16)}`;
                    }
                    return null;
                  };

                  localItems.forEach(loc => {
                    if (loc.uuid) localUuidMap.set(String(loc.uuid).trim().toUpperCase(), loc);
                    const bId = String(loc.branch_id || loc.syncBranchId || 'main').trim().toLowerCase();
                    const ref = String(loc.ref || loc.invoice_no || loc.receipt_no || '').trim().toUpperCase();
                    if (ref) {
                      localBranchRefMap.set(`${bId}::${ref}`, loc);
                      if (storeName !== 'stock_movements') {
                        localRefOnlyMap.set(ref, loc);
                      }
                    }
                    const compKey = getCompositeKey(loc);
                    if (compKey) localCompositeMap.set(compKey, loc);
                    if (loc.id != null) localIdMap.set(String(loc.id), loc);
                  });

                  for (const sItem of serverItems) {
                    const sUuid = sItem.uuid ? String(sItem.uuid).trim().toUpperCase() : null;
                    const sBranch = String(sItem.branch_id || sItem.syncBranchId || 'main').trim().toLowerCase();
                    const sRef = String(sItem.ref || sItem.invoice_no || sItem.receipt_no || '').trim().toUpperCase();
                    const sBranchRefKey = sRef ? `${sBranch}::${sRef}` : null;
                    const sCompKey = getCompositeKey(sItem);
                    const sIdKey = (sItem.id != null) ? String(sItem.id) : null;

                    // Match by UUID, (branch + ref), global unique ref, composite signature, or server ID
                    const match = (sUuid && localUuidMap.get(sUuid)) ||
                                  (sBranchRefKey && localBranchRefMap.get(sBranchRefKey)) ||
                                  (sRef && storeName !== 'stock_movements' && localRefOnlyMap.get(sRef)) ||
                                  (sCompKey && localCompositeMap.get(sCompKey)) ||
                                  (nodeRole === 'server' && sIdKey && localIdMap.get(sIdKey));

                    if (match) {
                      // Update existing record, keeping the local auto-increment ID
                      store.put({ ...sItem, id: match.id });
                    } else {
                      // Add new transaction from server with next auto-increment ID
                      const copy = { ...sItem };
                      delete copy.id;
                      store.add(copy);
                      if (sUuid) localUuidMap.set(sUuid, copy);
                      if (sBranchRefKey) localBranchRefMap.set(sBranchRefKey, copy);
                      if (sRef && storeName !== 'stock_movements') localRefOnlyMap.set(sRef, copy);
                      if (sCompKey) localCompositeMap.set(sCompKey, copy);
                    }
                  }
                };
                getAllReq.onerror = () => {};
                tx.oncomplete = () => resolve();
                tx.onerror = () => resolve();
                tx.onabort = () => resolve();
                return;
              }

              // ── 2. SHARED MASTER DATA STORES (Customers & Suppliers) ──
              // Protect business partners from wipeout and merge records preserving local data
              if (storeName === 'customers' || storeName === 'suppliers') {
                const getAllMasterReq = store.getAll();
                getAllMasterReq.onsuccess = () => {
                  const localMasters = getAllMasterReq.result || [];
                  const localIdMap = new Map();
                  const localPhoneMap = new Map();
                  localMasters.forEach(m => {
                    if (m.id != null) localIdMap.set(String(m.id), m);
                    if (m.phone) localPhoneMap.set(String(m.phone).trim(), m);
                  });

                  for (const sMaster of serverItems) {
                    const mId = (sMaster.id != null) ? String(sMaster.id) : null;
                    const mPhone = sMaster.phone ? String(sMaster.phone).trim() : null;
                    const matchedMaster = (mId && localIdMap.get(mId)) || (mPhone && localPhoneMap.get(mPhone));

                    if (matchedMaster) {
                      store.put({ ...matchedMaster, ...sMaster, id: matchedMaster.id });
                    } else {
                      store.put(sMaster);
                    }
                  }
                };
                getAllMasterReq.onerror = () => {};
                tx.oncomplete = () => resolve();
                tx.onerror = () => resolve();
                tx.onabort = () => resolve();
                return;
              }

              // ── 3. CATALOG & SETTINGS MASTER STORES ──
              const countReq = store.count();
              countReq.onsuccess = async () => {
                const localCount = countReq.result || 0;

                // CRITICAL SAFETY FOR BRANCH NODES:
                // Branches have full local autonomy. Never bulk-clear or overwrite branch database!
                if (nodeRole !== 'server') {
                  if (storeName === 'items') {
                    // Branch maintains its own inventory. Master definition syncs prices/barcodes/names only.
                    const getAllReq = store.getAll();
                    getAllReq.onsuccess = () => {
                      const localList = getAllReq.result || [];
                      const localMap = new Map();
                      localList.forEach(it => {
                        if (it.id != null) localMap.set(String(it.id), it);
                        if (it.barcode) localMap.set('bc::' + String(it.barcode).trim(), it);
                      });
                      for (const sItem of serverItems) {
                        const match = (sItem.id != null && localMap.get(String(sItem.id))) ||
                                      (sItem.barcode && localMap.get('bc::' + String(sItem.barcode).trim()));
                        if (match) {
                          const pStock = (match.stock_qty !== undefined && match.stock_qty !== null) ? match.stock_qty : (match.stock || 0);
                          const pWh = { ...(match.warehouse_stocks || {}) };
                          store.put({
                            ...sItem,
                            id: match.id,
                            stock_qty: pStock,
                            stock: pStock,
                            warehouse_stocks: pWh
                          });
                        } else {
                          store.put({
                            ...sItem,
                            stock_qty: 0,
                            stock: 0,
                            warehouse_stocks: { '1': 0 }
                          });
                        }
                      }
                    };
                    getAllReq.onerror = () => {};
                    tx.oncomplete = () => resolve();
                    return;
                  }

                  // Other master tables on branch: upsert without clearing
                  for (const item of serverItems) {
                    store.put(item);
                  }
                  tx.oncomplete = () => resolve();
                  return;
                }

                if (localCount > 0 && serverItems.length === 0) {
                  console.warn(`[Sync Safety] Local store ${storeName} has ${localCount} items, but server returned 0 items. Preserving.`);
                  tx.oncomplete = () => resolve();
                  return;
                }

                if (localCount > serverItems.length && serverItems.length > 0) {
                  for (const item of serverItems) {
                    store.put(item);
                  }
                  tx.oncomplete = () => resolve();
                  return;
                }
                
                // Server has newer/full catalog data for master tables
                store.clear();
                for (const item of serverItems) {
                  store.put(item);
                }
                tx.oncomplete = () => resolve();
              };
              countReq.onerror = () => {
                for (const item of serverItems) store.put(item);
                tx.oncomplete = () => resolve();
              };
              tx.onerror = (e) => {
                console.warn(`Sync error in store ${storeName}:`, e.target?.error);
                resolve();
              };
              tx.onabort = () => resolve();
            } catch (txErr) {
              console.warn(`Sync tx failed for store ${storeName}:`, txErr);
              resolve();
            }
          });
        }
        console.log('Database loaded from server successfully.');
        return true;
      }
    } catch (err) {
      console.warn('Database sync failed:', err.message);
    }
    return false;
  }

  async function syncToServer(storeName, data, isDelete = false) {
    if (isDelete) {
      const id = data.id || data.key;
      await callApi(`/api/db/${storeName}/${id}`, {
        method: 'DELETE'
      });
    } else {
      await callApi(`/api/db/${storeName}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
    }
  }

  async function bulkPut(storeName, itemsArray) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName) || !itemsArray || !itemsArray.length) return 0;
    
    const CHUNK_SIZE = 250;
    let totalSaved = 0;

    for (let i = 0; i < itemsArray.length; i += CHUNK_SIZE) {
      const chunk = itemsArray.slice(i, i + CHUNK_SIZE);
      let chunkSuccess = false;

      try {
        await new Promise((resolve, reject) => {
          const tx = _db.transaction(storeName, 'readwrite');
          const store = tx.objectStore(storeName);

          for (const item of chunk) {
            try {
              const clean = { ...item };
              if (clean.id !== undefined && clean.id !== null && clean.id !== '' && !isNaN(Number(clean.id))) {
                clean.id = Number(clean.id);
              } else {
                delete clean.id;
              }
              const req = store.put(clean);
              req.onerror = (ev) => {
                ev.preventDefault?.();
                ev.stopPropagation?.();
              };
            } catch (putErr) {}
          }

          tx.oncomplete = () => {
            totalSaved += chunk.length;
            chunkSuccess = true;
            resolve();
          };
          tx.onerror = (e) => {
            e.preventDefault?.();
            reject(e.target?.error || e);
          };
          tx.onabort = (e) => reject(e);
        });
      } catch (chunkErr) {
        console.warn(`[DB.bulkPut] Batch failed for ${storeName}, falling back to single items:`, chunkErr);
      }

      // Resilient fallback: save each item individually if chunk transaction aborted
      if (!chunkSuccess) {
        for (const item of chunk) {
          try {
            const clean = { ...item };
            if (clean.id !== undefined && clean.id !== null && clean.id !== '' && !isNaN(Number(clean.id))) {
              clean.id = Number(clean.id);
            } else {
              delete clean.id;
            }
            await new Promise((resolve) => {
              try {
                const tx = _db.transaction(storeName, 'readwrite');
                const store = tx.objectStore(storeName);
                const req = store.put(clean);
                req.onsuccess = () => { totalSaved++; resolve(); };
                req.onerror = (ev) => { ev.preventDefault?.(); resolve(); };
                tx.oncomplete = () => resolve();
                tx.onerror = (ev) => { ev.preventDefault?.(); resolve(); };
                tx.onabort = () => resolve();
              } catch (e) { resolve(); }
            });
          } catch (e) {}
        }
      }
    }
    return totalSaved;
  }

  async function bulkAdd(storeName, itemsArray) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName) || !itemsArray || !itemsArray.length) return [];
    const now = new Date().toISOString();
    
    // Save to IndexedDB in one high-performance transaction
    const savedItems = await new Promise((resolve, reject) => {
      try {
        const tx = _db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        const results = [];
        for (const raw of itemsArray) {
          const item = { ...raw, created_at: raw.created_at || now, updated_at: now };
          const req = store.put(item);
          req.onsuccess = (e) => {
            if (!item.id && e.target.result) item.id = e.target.result;
            results.push(item);
          };
        }
        tx.oncomplete = () => resolve(results);
        tx.onerror = (e) => reject(e.target.error);
        tx.onabort = (e) => reject(e);
      } catch (err) {
        reject(err);
      }
    });

    // Sync to server in bulk chunks
    await bulkSyncToServer(storeName, savedItems);
    return savedItems;
  }

  function getActiveTenantSlug() {
    if (typeof window !== 'undefined' && window.location.search) {
      const urlParams = new URLSearchParams(window.location.search);
      const tenantParam = urlParams.get('tenant') || urlParams.get('shop');
      if (tenantParam) {
        const cleanSlug = tenantParam.toLowerCase().replace(/[^a-z0-9]/g, '_');
        localStorage.setItem('redshark_active_tenant', cleanSlug);
        return cleanSlug;
      }
    }
    const rawSession = sessionStorage.getItem('nexpos_session');
    if (rawSession) {
      try {
        const s = JSON.parse(rawSession);
        if (s.tenant_slug) return s.tenant_slug.toLowerCase().replace(/[^a-z0-9]/g, '_');
        if (s.shop_name) return s.shop_name.toLowerCase().replace(/[^a-z0-9]/g, '_');
      } catch(e){}
    }
    const active = localStorage.getItem('redshark_active_tenant');
    if (active) return active;
    return 'default';
  }

  function getTenantDbName(customSlug = null) {
    const slug = customSlug || getActiveTenantSlug();
    return `RedSharkPOS_${slug}`;
  }

  function open(customSlug = null) {
    const currentDbName = getTenantDbName(customSlug);

    return new Promise((resolve, reject) => {
      if (_db && _db.name === currentDbName && _db.version === DB_VERSION) { resolve(_db); return; }
      if (_db) {
        try { _db.close(); } catch(e){}
        _db = null;
      }
      const req = indexedDB.open(currentDbName, DB_VERSION);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        STORES.forEach(s => {
          if (!db.objectStoreNames.contains(s.name)) {
            const opts = s.keyPath
              ? { keyPath: s.keyPath, autoIncrement: !!s.autoIncrement }
              : { autoIncrement: true };
            db.createObjectStore(s.name, opts);
          }
        });
      };
      req.onsuccess  = async e => {
        _db = e.target.result;
        try {
          await syncFromServer();
          await _repairDuplicateRefs();
        } catch(err) {
          console.warn('Sync on open failed:', err);
        }
        resolve(_db);
      };
      req.onerror    = e => reject(e.target.error);
    });
  }

  async function getDB() {
    const currentDbName = getTenantDbName();
    if (!_db || _db.name !== currentDbName || _db.version !== DB_VERSION) await open();
    return _db;
  }

  function tx(storeName, mode = 'readonly') {
    return _db.transaction(storeName, mode).objectStore(storeName);
  }

  function promisify(request) {
    return new Promise((res, rej) => {
      request.onsuccess = () => res(request.result);
      request.onerror   = () => rej(request.error);
    });
  }

  async function getAll(storeName, filter = null) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return [];
    const store = tx(storeName);
    const all = await promisify(store.getAll());
    if (filter) return all.filter(filter);
    return all;
  }

  async function get(storeName, id) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName) || id === undefined || id === null) return null;
    const store = tx(storeName);
    let res = await promisify(store.get(id));
    if (res === undefined && typeof id === 'string' && id.trim() !== '' && !isNaN(Number(id))) {
      res = await promisify(tx(storeName).get(Number(id)));
    } else if (res === undefined && typeof id === 'number') {
      res = await promisify(tx(storeName).get(String(id)));
    }
    return res ?? null;
  }

  async function getByKey(storeName, key) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return null;
    const store = tx(storeName);
    return promisify(store.get(key));
  }

  async function add(storeName, data) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return null;
    const store = tx(storeName, 'readwrite');
    const now = new Date().toISOString();
    const record = { ...data, created_at: now, updated_at: now };
    const id = await promisify(store.add(record));
    record.id = id;
    await _audit('add', storeName, record);
    syncToServer(storeName, record).catch(console.error);
    return id;
  }

  async function update(storeName, data) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return null;
    const store = tx(storeName, 'readwrite');
    const now = new Date().toISOString();
    let record = { ...data, updated_at: now };

    // Safety for autoIncrement numeric stores: ensure numeric ID doesn't get converted into string key
    if (record.id !== undefined && record.id !== null) {
      if (typeof record.id === 'string' && !isNaN(Number(record.id)) && String(Number(record.id)) === record.id.trim()) {
        const numId = Number(record.id);
        record.id = numId;
        try { store.delete(String(numId)); } catch(e){}
      }
    }

    await promisify(store.put(record));
    await _audit('update', storeName, record);
    syncToServer(storeName, record).catch(console.error);
    return record.id;
  }

  async function put(storeName, data) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return null;
    const store = tx(storeName, 'readwrite');
    const res = await promisify(store.put(data));
    syncToServer(storeName, data).catch(console.error);
    return res;
  }

  async function remove(storeName, id) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return;
    const old = await get(storeName, id);
    const store = tx(storeName, 'readwrite');
    try {
      await promisify(store.delete(id));
    } catch (e) {}
    if (typeof id === 'string' && !isNaN(Number(id))) {
      try { await promisify(store.delete(Number(id))); } catch (e) {}
    } else if (typeof id === 'number') {
      try { await promisify(store.delete(String(id))); } catch (e) {}
    }
    await _audit('delete', storeName, old);
    syncToServer(storeName, { id }, true).catch(console.error);
  }

  async function bulkDelete(storeName, ids) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName) || !Array.isArray(ids) || ids.length === 0) return 0;
    const store = tx(storeName, 'readwrite');
    for (const id of ids) {
      try { store.delete(id); } catch(e) {}
      if (typeof id === 'string' && !isNaN(Number(id))) {
        try { store.delete(Number(id)); } catch(e) {}
      } else if (typeof id === 'number') {
        try { store.delete(String(id)); } catch(e) {}
      }
    }
    callApi('/api/sync/delete-batch', {
      method: 'POST',
      body: { table: storeName, ids }
    }).catch(console.error);
    return ids.length;
  }

  async function count(storeName) {
    await getDB();
    if (!_db || !_db.objectStoreNames.contains(storeName)) return 0;
    const store = tx(storeName);
    return promisify(store.count());
  }

  async function clear(storeName) {
    await getDB();
    const store = tx(storeName, 'readwrite');
    await promisify(store.clear());
    callApi(`/api/db-clear/${storeName}`, { method: 'POST' }).catch(console.error);
  }

  // ── Settings ────────────────────────────────────────────────
  async function getSetting(key, defaultVal = null) {
    const record = await getByKey('settings', key);
    return record ? record.value : defaultVal;
  }

  async function setSetting(key, value) {
    return put('settings', { key, value });
  }

  // ── Sequences (Auto-numbering with Duplicate Prevention) ─────
  async function nextSeq(key, prefix = '', padLength = 5) {
    await getDB();
    let maxNum = 0;
    let hasSeq = false;

    // Fast path: Check sequence table (0.1ms)
    try {
      if (_db && _db.objectStoreNames.contains('sequences')) {
        const sStore = tx('sequences', 'readonly');
        const record = await promisify(sStore.get(key));
        if (record && typeof record.current === 'number' && record.current > 0) {
          maxNum = record.current;
          hasSeq = true;
        }
      }
    } catch(e) {}

    // Fallback only if sequences store is not yet initialized for this key
    if (!hasSeq) {
      const tableToCheck = (key === 'sales' || key === 'sales_invoice') ? ['sales', 'sales_invoice'] : [key];
      for (const tName of tableToCheck) {
        try {
          if (_db && _db.objectStoreNames.contains(tName)) {
            const tStore = tx(tName, 'readonly');
            const allRecords = await promisify(tStore.getAll());
            for (const item of (allRecords || [])) {
              const refVal = String(item.ref || item.receipt_no || item.item_code || item.emp_code || '');
              if (prefix && refVal.startsWith(prefix)) {
                const numPart = parseInt(refVal.slice(prefix.length), 10);
                if (!isNaN(numPart) && numPart > maxNum) maxNum = numPart;
              } else if (!prefix) {
                const numPart = parseInt(refVal, 10);
                if (!isNaN(numPart) && numPart > maxNum) maxNum = numPart;
              }
            }
          }
        } catch(e) {}
      }
    }

    const next = maxNum + 1;

    try {
      if (_db && _db.objectStoreNames.contains('sequences')) {
        const wStore = tx('sequences', 'readwrite');
        await promisify(wStore.put({ key, current: next }));
      }
    } catch(e) {}

    return `${prefix}${String(next).padStart(padLength, '0')}`;
  }

  async function peekSeq(key, prefix = '', padLength = 5) {
    await getDB();
    let maxNum = 0;
    let hasSeq = false;
    try {
      if (_db && _db.objectStoreNames.contains('sequences')) {
        const sStore = tx('sequences', 'readonly');
        const record = await promisify(sStore.get(key));
        if (record && typeof record.current === 'number' && record.current > 0) {
          maxNum = record.current;
          hasSeq = true;
        }
      }
    } catch(e) {}

    if (!hasSeq) {
      const tableToCheck = (key === 'sales' || key === 'sales_invoice') ? ['sales', 'sales_invoice'] : [key];
      for (const tName of tableToCheck) {
        try {
          if (_db && _db.objectStoreNames.contains(tName)) {
            const tStore = tx(tName, 'readonly');
            const allRecords = await promisify(tStore.getAll());
            for (const item of (allRecords || [])) {
              const refVal = String(item.ref || item.receipt_no || item.item_code || item.emp_code || '');
              if (prefix && refVal.startsWith(prefix)) {
                const numPart = parseInt(refVal.slice(prefix.length), 10);
                if (!isNaN(numPart) && numPart > maxNum) maxNum = numPart;
              } else if (!prefix) {
                const numPart = parseInt(refVal, 10);
                if (!isNaN(numPart) && numPart > maxNum) maxNum = numPart;
              }
            }
          }
        } catch(e) {}
      }
    }

    const next = maxNum + 1;
    return `${prefix}${String(next).padStart(padLength, '0')}`;
  }

  async function _repairDuplicateRefs() {
    try {
      if (!_db) return;
      const storesToFix = [
        { name: 'sales', prefix: 'INV-', pad: 6 },
        { name: 'sales_invoice', prefix: 'INV-', pad: 5 },
        { name: 'purchase_invoices', prefix: 'PINV-', pad: 5 },
        { name: 'repair_jobs', prefix: 'REP-', pad: 5 }
      ];

      for (const cfg of storesToFix) {
        if (!_db.objectStoreNames.contains(cfg.name)) continue;
        const allRecords = await promisify(tx(cfg.name, 'readonly').getAll());
        if (!allRecords || allRecords.length === 0) continue;

        const seenRefs = new Set();
        let hasDuplicates = false;
        for (const rec of allRecords) {
          const refVal = String(rec.ref || rec.receipt_no || rec.invoice_no || '').trim().toUpperCase();
          if (refVal) {
            if (seenRefs.has(refVal)) {
              hasDuplicates = true;
              break;
            }
            seenRefs.add(refVal);
          }
        }

        if (hasDuplicates) {
          allRecords.sort((a, b) => new Date(a.created_at || a.doc_date || 0) - new Date(b.created_at || b.doc_date || 0) || ((a.id || 0) - (b.id || 0)));
          const usedRefs = new Set();
          for (const rec of allRecords) {
            const currentRef = String(rec.ref || rec.receipt_no || rec.invoice_no || '').trim().toUpperCase();
            if (currentRef && usedRefs.has(currentRef)) {
              // Delete duplicate copy from IndexedDB AND Server to eliminate duplicate calculations & ghost sales
              try {
                await promisify(tx(cfg.name, 'readwrite').delete(rec.id));
                syncToServer(cfg.name, { id: rec.id }, true).catch(() => {});
                console.log(`[DB] Cleaned duplicate row from ${cfg.name}: ID ${rec.id} Ref ${currentRef}`);
              } catch(e){}
            } else if (currentRef) {
              usedRefs.add(currentRef);
            }
          }
        }
      }

      // Auto-cleanup duplicate cashbox_movements (e.g. duplicate POS sale entries in the same session)
      if (_db.objectStoreNames.contains('cashbox_movements')) {
        const allMvs = await promisify(tx('cashbox_movements', 'readonly').getAll());
        if (allMvs && allMvs.length > 1) {
          allMvs.sort((a, b) => new Date(a.created_at || a.date || 0) - new Date(b.created_at || b.date || 0) || ((a.id || 0) - (b.id || 0)));
          const seenMvKeys = new Set();
          for (const m of allMvs) {
            const desc = String(m.description || '').trim();
            const invMatch = desc.match(/(INV-[A-Z0-9_-]+)/i);
            const invRef = String(m.ref || (invMatch ? invMatch[1] : '')).trim().toUpperCase();
            let mvKey = '';
            if (invRef) {
              mvKey = `REF::${m.session_id || ''}::${m.type || 'sale'}::${invRef}`;
            } else if (m.type === 'sale' && desc) {
              const minuteStr = String(m.date || m.created_at || '').slice(0, 16);
              mvKey = `SALE::${m.session_id || ''}::${Number(m.amount || 0).toFixed(2)}::${desc.toUpperCase()}::${minuteStr}`;
            }
            if (mvKey && seenMvKeys.has(mvKey)) {
              try {
                await promisify(tx('cashbox_movements', 'readwrite').delete(m.id));
                syncToServer('cashbox_movements', { id: m.id }, true).catch(() => {});
                console.log(`[DB] Cleaned duplicate cashbox movement: ID ${m.id} (${desc})`);
              } catch (e) {}
            } else if (mvKey) {
              seenMvKeys.add(mvKey);
            }
          }
        }
      }

      // Auto-cleanup duplicate categories in local client DB
      if (_db.objectStoreNames.contains('categories')) {
        const catStore = tx('categories', 'readwrite');
        const allCats = await promisify(catStore.getAll());
        const seenCats = new Set();
        for (const c of (allCats || [])) {
          const cKey = (c.name_en || c.name || c.name_ar || '').toLowerCase().trim();
          if (cKey && seenCats.has(cKey)) {
            await promisify(catStore.delete(c.id));
          } else if (cKey) {
            seenCats.add(cKey);
          }
        }
      }

      // Auto-cleanup duplicate items in local client DB
      if (_db.objectStoreNames.contains('items')) {
        const itemStore = tx('items', 'readwrite');
        const allIts = await promisify(itemStore.getAll());
        const seenIts = new Set();
        for (const it of (allIts || [])) {
          const iKey = (it.barcode || it.item_code || it.code || it.name_en || '').toLowerCase().trim();
          if (iKey && seenIts.has(iKey)) {
            await promisify(itemStore.delete(it.id));
          } else if (iKey) {
            seenIts.add(iKey);
          }
        }
      }

      // Auto-cleanup duplicate customers in local client DB (same exact ID or identical name+phone)
      if (_db.objectStoreNames.contains('customers')) {
        const custStore = tx('customers', 'readwrite');
        const allCusts = await promisify(custStore.getAll());
        if (allCusts && allCusts.length > 1) {
          const seenCusts = new Map();
          for (const c of allCusts) {
            const name = (c.name_ar || c.name_en || c.name || '').trim().toLowerCase();
            const phone = (c.phone || '').trim();
            const idStr = String(c.id);
            let cKey = null;
            if (name && phone && phone.length >= 6) {
              cKey = `NP::${name}::${phone}`;
            }
            const idKey = `ID::${idStr}`;

            const match = seenCusts.get(idKey) || (cKey ? seenCusts.get(cKey) : null);
            if (match && match.id !== c.id) {
              if (parseFloat(c.balance || 0) > parseFloat(match.balance || 0)) {
                match.balance = c.balance;
                await promisify(custStore.put(match));
              }
              await promisify(custStore.delete(c.id));
              console.log(`[DB] Cleaned duplicate customer: ID ${c.id} Name "${name}"`);
            } else {
              seenCusts.set(idKey, c);
              if (cKey) seenCusts.set(cKey, c);
            }
          }
        }
      }

      // Auto-cleanup duplicate suppliers in local client DB (same exact ID or identical name+phone)
      if (_db.objectStoreNames.contains('suppliers')) {
        const suppStore = tx('suppliers', 'readwrite');
        const allSupps = await promisify(suppStore.getAll());
        if (allSupps && allSupps.length > 1) {
          const seenSupps = new Map();
          for (const s of allSupps) {
            const name = (s.name_ar || s.name_en || s.name || '').trim().toLowerCase();
            const phone = (s.phone || '').trim();
            const idStr = String(s.id);
            let sKey = null;
            if (name && phone && phone.length >= 6) {
              sKey = `NP::${name}::${phone}`;
            }
            const idKey = `ID::${idStr}`;

            const match = seenSupps.get(idKey) || (sKey ? seenSupps.get(sKey) : null);
            if (match && match.id !== s.id) {
              if (parseFloat(s.balance || 0) > parseFloat(match.balance || 0)) {
                match.balance = s.balance;
                await promisify(suppStore.put(match));
              }
              await promisify(suppStore.delete(s.id));
              console.log(`[DB] Cleaned duplicate supplier: ID ${s.id} Name "${name}"`);
            } else {
              seenSupps.set(idKey, s);
              if (sKey) seenSupps.set(sKey, s);
            }
          }
        }
      }
    } catch(err) {
      console.warn('Auto repair duplicate refs failed:', err);
    }
  }

  // ── Audit Log ────────────────────────────────────────────────
  async function _audit(action, table, data, description = '') {
    try {
      const user = (typeof Auth !== 'undefined' && Auth?.getUser) ? (Auth.getUser()?.username || 'system') : 'system';
      await getDB();
      const store = tx('audit_log', 'readwrite');
      store.add({
        action, table,
        user,
        description: description || `${action.toUpperCase()} on ${table}`,
        data: typeof data === 'string' ? data : JSON.stringify(data),
        timestamp: new Date().toISOString()
      });
    } catch(e) { /* silent */ }
  }

  async function purgeAuditLogs() {
    const daysStr = await getSetting('audit_retention_days', '30');
    if (!daysStr || daysStr === 'forever') return 0;
    const days = parseInt(daysStr) || 30;
    const cutoff = new Date(Date.now() - (days * 24 * 60 * 60 * 1000)).toISOString();

    const logs = await getAll('audit_log');
    let deletedCount = 0;
    for (const log of logs) {
      if (log.timestamp && log.timestamp < cutoff) {
        await remove('audit_log', log.id);
        deletedCount++;
      }
    }
    return deletedCount;
  }

  // ── Seed Default Data ────────────────────────────────────────
  async function seed() {
    // Default settings
    const keys = [
      ['company_name', 'Store'],
      ['company_name_ar', 'المتجر'],
      ['company_address', ''],
      ['company_phone', ''],
      ['company_email', ''],
      ['vat_number', ''],
      ['currency_1', 'USD'],
      ['currency_2', 'LBP'],
      ['exchange_rate', 89500],
      ['vat_rate', 11],
      ['vat_enabled', false],
      ['theme', 'dark'],
      ['lang', 'en'],
      ['company_logo', 'data:image/png;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/6xeHSlAAAQAAAAEAABd9anVtYgAAAB5qdW1kYzJwYQARABCAAACqADibcQNjMnBhAAAAF1dqdW1iAAAAR2p1bWRjMm1hABEAEIAAAKoAOJtxA3VybjpjMnBhOmQwYTdiOTZiLThkNWQtYzRiZi1hOTUxLTQ2ZGE2OTU0OGJmYwAAABMAanVtYgAAAChqdW1kYzJjcwARABCAAACqADibcQNjMnBhLnNpZ25hdHVyZQAAABLQY2JvctKEWQYrogEmGCGCWQM/MIIDOzCCAsCgAwIBAgIUAJ6vFWKBqUkCFltI/1ipbSSYHs4wCgYIKoZIzj0EAwMwUTELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxLTArBgNVBAMMJEdvb2dsZSBDMlBBIE1lZGlhIFNlcnZpY2VzIDFQIElDQSBHMzAeFw0yNjAyMTcxNTE3MTJaFw0yNzAyMTIxNTE3MTFaMGsxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpHb29nbGUgTExDMRwwGgYDVQQLExNHb29nbGUgU3lzdGVtIDYwMDMyMSkwJwYDVQQDEyBHb29nbGUgTWVkaWEgUHJvY2Vzc2luZyBTZXJ2aWNlczBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IABLBjir7O78duFgwA85LMipPVJpwNGfPRe9uLhP2QbYYvWYLwkqIuwXGpMdIYJ5OtG6kKVtfi3xS50maSO0eJywCjggFaMIIBVjAOBgNVHQ8BAf8EBAMCBsAwHwYDVR0lBBgwFgYIKwYBBQUHAwQGCisGAQQBg+heAgEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQUkG/QOXwhnfJG44eVEH4Wr2aQ5O4wHwYDVR0jBBgwFoAU2nvhvbQsioXgENZrmsdK8frf9jcwbAYIKwYBBQUHAQEEYDBeMCYGCCsGAQUFBzABhhpodHRwOi8vYzJwYS1vY3NwLnBraS5nb29nLzA0BggrBgEFBQcwAoYoaHR0cDovL3BraS5nb29nL2MycGEvbWVkaWEtMXAtaWNhLWczLmNydDAXBgNVHSAEEDAOMAwGCisGAQQBg+heAQEwGQYJKwYBBAGD6F4DBAwGCisGAQQBg+heAwowMwYJKwYBBAGD6F4EBCYMJDAxOWMzNGQzLTczM2YtN2E0Ny1iOTE3LTUwZGQzOGY0MWVjZTAKBggqhkjOPQQDAwNpADBmAjEAk41aMTcCgSsA+aAKV0GYPGVAUzMSnab02y1JhvXYZraq9fLZxPw8G8NcdJnCEndyAjEAvrBQu9UmLza4dENTmz+o32xGSkRJXRQgjFfWVLanodD/bGcbObPJxEvCR0JMirQCWQLgMIIC3DCCAmOgAwIBAgIUQfqlIUd2IVjaf5ss/439Fgke7j4wCgYIKoZIzj0EAwMwQzELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxHzAdBgNVBAMMFkdvb2dsZSBDMlBBIFJvb3QgQ0EgRzMwHhcNMjUwNTA4MjIzNjI2WhcNMzAwNTA4MjIzNjI2WjBRMQswCQYDVQQGEwJVUzETMBEGA1UECgwKR29vZ2xlIExMQzEtMCsGA1UEAwwkR29vZ2xlIEMyUEEgTWVkaWEgU2VydmljZXMgMVAgSUNBIEczMHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEuCPlUxSiltqnB2lx2ES7FK+TVZWmAxRzzDjTzKZ8umoqyvCqSLOkZBrOieaLqrp+rnzt0EADWWH3X62NqzEXRewW6rb/lS7VXkVCM02gC0ZgJW7+PCsZgLoUBUQ+nkN5o4IBCDCCAQQwFwYDVR0gBBAwDjAMBgorBgEEAYPoXgEBMA4GA1UdDwEB/wQEAwIBBjAfBgNVHSUEGDAWBggrBgEFBQcDBAYKKwYBBAGD6F4CATASBgNVHRMBAf8ECDAGAQH/AgEAMGQGCCsGAQUFBwEBBFgwVjAsBggrBgEFBQcwAoYgaHR0cDovL3BraS5nb29nL2MycGEvcm9vdC1nMy5jcnQwJgYIKwYBBQUHMAGGGmh0dHA6Ly9jMnBhLW9jc3AucGtpLmdvb2cvMB8GA1UdIwQYMBaAFJxc2IlTQ+da1YHbA94ZfwQqKi2qMB0GA1UdDgQWBBTae+G9tCyKheAQ1muax0rx+t/2NzAKBggqhkjOPQQDAwNnADBkAjACxtEE3NW13bwN1u/51ericNF6rkEhYVESDO6Jqb5cX37Hwg0X9S2rH+vXaoFZIHsCMC03wCKKomDHgqV47UtyyHpZlo5IZACW72Xdc4gipdWMEmhvPk88dvxbYtn+LVd9zKRnc2lnVHN0MqFpdHN0VG9rZW5zgaFjdmFsWQfeMIIH2gYJKoZIhvcNAQcCoIIHyzCCB8cCAQMxDTALBglghkgBZQMEAgEwgY4GCyqGSIb3DQEJEAEEoH8EfTB7AgEBBgorBgEEAdZ5AgoBMDEwDQYJYIZIAWUDBAIBBQAEIGkjlFawaZWcShd76A0qcIVkPtLAABgYU4FfNxEzD0iIAhR/EbNSsHACbmJy/7pUL/l/LhGB2BgPMjAyNjA4MTAwOTQwMjFaMAYCAQGAAQoCCCuYkFfO1JmuoIIFoTCCAsowggJPoAMCAQICEw8EPf3XdjR+pffDrUWnC1ruJFUwCgYIKoZIzj0EAwMwUjELMAkGA1UEBhMCVVMxEzARBgNVBAoMCkdvb2dsZSBMTEMxLjAsBgNVBAMMJUdvb2dsZSBDMlBBIENvcmUgVGltZS1TdGFtcGluZyBJQ0EgRzMwHhcNMjUwOTA4MTM0ODU3WhcNMzEwOTA5MDE0ODU2WjBUMQswCQYDVQQGEwJVUzETMBEGA1UEChMKR29vZ2xlIExMQzEwMC4GA1UEAxMnR29vZ2xlIENvcmUgVGltZSBTdGFtcGluZyBBdXRob3JpdHkgVDEwMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEwJKbXyfOJJilyKDp1W/PyAmRenY4jtdwrwbBiwmEw9zLsQPWjGVV58u4cxKuXm+rmUiSpq+E8SqbcZmvcUd1EaOCAQAwgf0wDgYDVR0PAQH/BAQDAgbAMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFFLiDUEVXlAa9ix0gn1++SL+3G6KMB8GA1UdIwQYMBaAFN5Vl4xgdDsD4mq0RAZll2HK5fiOMGwGCCsGAQUFBwEBBGAwXjAmBggrBgEFBQcwAYYaaHR0cDovL2MycGEtb2NzcC5wa2kuZ29vZy8wNAYIKwYBBQUHMAKGKGh0dHA6Ly9wa2kuZ29vZy9jMnBhL2NvcmUtdHNhLWljYS1nMy5jcnQwFwYDVR0gBBAwDjAMBgorBgEEAYPoXgEBMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMAoGCCqGSM49BAMDA2kAMGYCMQD84ETIWiUgcdNUBJnsihQJ96+gbnGbvO/vSWaaGD1a6+xireAGvdRpjtOY3awLFEQCMQDUFt3bIxSI2L1ofAyxaiVgstIieyrQdpXHP98wBbExjGbmC3X5wdICe/7xA+BNZMwwggLPMIICVqADAgECAhRFAINuchMCxWSknmQzdvqPCbdk9DAKBggqhkjOPQQDAzBDMQswCQYDVQQGEwJVUzETMBEGA1UECgwKR29vZ2xlIExMQzEfMB0GA1UEAwwWR29vZ2xlIEMyUEEgUm9vdCBDQSBHMzAeFw0yNTA1MDgyMjM2MjZaFw00MDA1MDgyMjM2MjZaMFIxCzAJBgNVBAYTAlVTMRMwEQYDVQQKDApHb29nbGUgTExDMS4wLAYDVQQDDCVHb29nbGUgQzJQQSBDb3JlIFRpbWUtU3RhbXBpbmcgSUNBIEczMHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEo3338b0IKh9FWSXgUvmpIN/+2y6PRSHYTwrVzQNx3WcqLFluwJwkMnIiebkCkV+5pspHn6fFNHMTfl7FJUTpMSKONNW4Fv4awasz6sYhLCNP/wHk4MF/8DhrxXKtJUsKo4H7MIH4MBcGA1UdIAQQMA4wDAYKKwYBBAGD6F4BATAOBgNVHQ8BAf8EBAMCAQYwEwYDVR0lBAwwCgYIKwYBBQUHAwgwEgYDVR0TAQH/BAgwBgEB/wIBADBkBggrBgEFBQcBAQRYMFYwLAYIKwYBBQUHMAKGIGh0dHA6Ly9wa2kuZ29vZy9jMnBhL3Jvb3QtZzMuY3J0MCYGCCsGAQUFBzABhhpodHRwOi8vYzJwYS1vY3NwLnBraS5nb29nLzAfBgNVHSMEGDAWgBScXNiJU0PnWtWB2wPeGX8EKiotqjAdBgNVHQ4EFgQU3lWXjGB0OwPiarREBmWXYcrl+I4wCgYIKoZIzj0EAwMDZwAwZAIwQcYGjR1KfAGV1uVNgXR8YF3McEJbShGEY/+lh9yUJNiBzKj5R1Hmdi6IdmkoWFBxAjBwC6Yt0x6bxekQmwAR51P07SWj6Sxq5/Bsn3cFWHkcbeHfuvGKPycTTri6GlI+Iy0xggF7MIIBdwIBATBpMFIxCzAJBgNVBAYTAlVTMRMwEQYDVQQKDApHb29nbGUgTExDMS4wLAYDVQQDDCVHb29nbGUgQzJQQSBDb3JlIFRpbWUtU3RhbXBpbmcgSUNBIEczAhMPBD3913Y0fqX3w61Fpwta7iRVMAsGCWCGSAFlAwQCAaCBpDAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8XDTI2MDgxMDA5NDAyMFowLwYJKoZIhvcNAQkEMSIEINarZYD3t0dnfwI1QDSk5X94kB4m0zJw7aQ3dM97rP/EMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIGygncU8KqUbOTYofoUhdk3q/0zMz2bBIKJqpxxvGSmOMAoGCCqGSM49BAMCBEcwRQIgEmSV+rQJE8qMMEUNX1z9CUcBa5rHEinUdgqPG94pykECIQDKFbyXXM3wsYLIcAoFqz4SoP6jI14DXEA2aNnwep0du2VyVmFsc6Fob2NzcFZhbHOCWQPyMIID7goBAKCCA+cwggPjBgkrBgEFBQcwAQEEggPUMIID0DCB7KFCMEAxCzAJBgNVBAYTAlVTMRMwEQYDVQQKEwpHb29nbGUgTExDMRwwGgYDVQQDExNDMlBBIE9DU1AgUmVzcG9uZGVyGA8yMDI2MDgwOTE1MTQwMFowgZQwgZEwaTANBglghkgBZQMEAgEFAAQgssyQyamfMvBXXlCCvNODuNEJ0MZY4HuaHcboqhUW7SoEIJwa/V8+flyCR5a1dPJTP+OCaW+uDbdG9nAQsZU5sds9AhQAnq8VYoGpSQIWW0j/WKltJJgezoAAGA8yMDI2MDgwOTE1MTQzNVqgERgPMjAyNjA4MTYxNTE0MzVaMAoGCCqGSM49BAMCA0cAMEQCIFFs6UyNoMgFBIoj2qJIrEHU0JFVKR+rmKfNPTLwOUW5AiAgdhZkUo4K0ZwDkn5l7AGHEnZyIaDwKQbRjtUuI6oG3KCCAogwggKEMIICgDCCAgagAwIBAgITeA/KyZUK7Tb7YPvoD3fd59JmbjAKBggqhkjOPQQDAzBRMQswCQYDVQQGEwJVUzETMBEGA1UECgwKR29vZ2xlIExMQzEtMCsGA1UEAwwkR29vZ2xlIEMyUEEgTWVkaWEgU2VydmljZXMgMVAgSUNBIEczMB4XDTI2MDgwNDE0MjA1NFoXDTI2MDkwMzE0MjA1M1owQDELMAkGA1UEBhMCVVMxEzARBgNVBAoTCkdvb2dsZSBMTEMxHDAaBgNVBAMTE0MyUEEgT0NTUCBSZXNwb25kZXIwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAQ1Zzn39WS9146qROh23M7K4Cg3qiPwgaVyz/oYtReVuW/1M+A9+RSlU+2vMcbVKNdQwY5Kd6/D740+KFQ8wEg7o4HNMIHKMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDCTAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBTId+ECPnB4yVhxps+1wsb8QhpE7DAfBgNVHSMEGDAWgBTae+G9tCyKheAQ1muax0rx+t/2NzBEBggrBgEFBQcBAQQ4MDYwNAYIKwYBBQUHMAKGKGh0dHA6Ly9wa2kuZ29vZy9jMnBhL21lZGlhLTFwLWljYS1nMy5jcnQwDwYJKwYBBQUHMAEFBAIFADAKBggqhkjOPQQDAwNoADBlAjAZUNnfh5OfAQmvEgZyLz6wS2vt16K/AuguItJVfRxe/oRpEmtoTjtKoYt5DoK25XgCMQCpgFQ9fMmjuTKJJfky3YDhcyFmaoLLfj8nSV6yi36KvO1WsWEeY4BEncZDyBHMF0dAY3BhZFhGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRwYWQyQQD2WECPrVLy35++oCJI3Y2/XfNg0PdOzioc84vTZNb2S0aMtOrwiZwy7h5QyN3TR5+eONYgKZFQSuMjPmzPTaGeXeVfAAABt2p1bWIAAAAnanVtZGMyY2wAEQAQgAAAqgA4m3EDYzJwYS5jbGFpbS52MgAAAAGIY2JvcqVqaW5zdGFuY2VJRHgkNzZhYmI1ZDgtOGUwOS0zM2NjLWY3YmEtNDI0NTNiZmI1NjJkdGNsYWltX2dlbmVyYXRvcl9pbmZvomRuYW1leCJHb29nbGUgQzJQQSBDb3JlIEdlbmVyYXRvciBMaWJyYXJ5Z3ZlcnNpb25zOTU4ODgyNDU3Ojk2MTA1OTIwNHJjcmVhdGVkX2Fzc2VydGlvbnOComN1cmx4KnNlbGYjanVtYmY9YzJwYS5hc3NlcnRpb25zL2MycGEuYWN0aW9ucy52MmRoYXNoWCBoIlEry3OUHQkL7sBT6fq20DpcCKubtEkMo/VaRNDouaJjdXJseClzZWxmI2p1bWJmPWMycGEuYXNzZXJ0aW9ucy9jMnBhLmhhc2guZGF0YWRoYXNoWCB5kOi9JegOJ8d2Ktj81nbdBjMdGulcCMFt9jXEX3K7LWlzaWduYXR1cmV4GXNlbGYjanVtYmY9YzJwYS5zaWduYXR1cmVjYWxnZnNoYTI1NgAAAlFqdW1iAAAAKWp1bWRjMmFzABEAEIAAAKoAOJtxA2MycGEuYXNzZXJ0aW9ucwAAAACcanVtYgAAAChqdW1kY2JvcgARABCAAACqADibcQNjMnBhLmhhc2guZGF0YQAAAABsY2JvcqRqZXhjbHVzaW9uc4GiZXN0YXJ0FGZsZW5ndGgZF4ljYWxnZnNoYTI1NmRoYXNoWCAJfkItU86meLtDR+NNJb7G3QJcns+bckFah+RzC91cu2NwYWROAAAAAAAAAAAAAAAAAAAAAAGEanVtYgAAAClqdW1kY2JvcgARABCAAACqADibcQNjMnBhLmFjdGlvbnMudjIAAAABU2Nib3KhZ2FjdGlvbnOCo2ZhY3Rpb25sYzJwYS5jcmVhdGVka2Rlc2NyaXB0aW9ueCBDcmVhdGVkIGJ5IEdvb2dsZSBHZW5lcmF0aXZlIEFJLnFkaWdpdGFsU291cmNlVHlwZXhGaHR0cDovL2N2LmlwdGMub3JnL25ld3Njb2Rlcy9kaWdpdGFsc291cmNldHlwZS90cmFpbmVkQWxnb3JpdGhtaWNNZWRpYaNmYWN0aW9ua2MycGEuZWRpdGVka2Rlc2NyaXB0aW9ueChBcHBsaWVkIGltcGVyY2VwdGlibGUgU3ludGhJRCB3YXRlcm1hcmsucWRpZ2l0YWxTb3VyY2VUeXBleEZodHRwOi8vY3YuaXB0Yy5vcmcvbmV3c2NvZGVzL2RpZ2l0YWxzb3VyY2V0eXBlL3RyYWluZWRBbGdvcml0aG1pY01lZGlh/9sAQwABAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEB/9sAQwEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEB/8AAEQgEAAQAAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A/vzhGEUdMKox2AAC/XjbjH4nJNSEA/ljoP6//qpBnj5ccDvnGO3/ANenUb7h6iY/ljt+fT/63tRgfpgcDj6cf/W56UtFACAAf/qH58D/AOt7UY/l6D8+nX9PalooAQDH+HH59P8A63tRjv3xjPH59P8A63tS0UAFJjnPtjoPzz/kUtFACAY/LHb/AA/+t7UY5z7egz9en19uaWigApMc574x2/w/+t7UtFABSY5z7egz9en19uaWigApMc574x2/w/8Are1LRQAUmOc+2Ogz9c4+vt7UtFABSY5z7Y6D88/5FLRQAUmOc+2Og/PP+RS0UAFJjnPtjoPzz/kUtFABSY5z7Y6D88/5FLRQAUmOc+2Og/PP+RS0UAFJjnPfGO3+H/1valooAKTHOfbHQfnn/IpaKACkxznvjHb/AA/+t7UtFABSY5z3xjt/h/8AW9qWigApMc574x2/w/8Are1LRQAUmOc+2Og/PP8AkUtFABSY5z7Y6D88/wCRS0UAGP5Y7f5/pSY5z3xjt/h/9b2paKACkxzn2x0H55/yKWigAx/LHb/P9KTHOfbHQfnn/IpaKADH8sdv8/0pMc59sdB+ef8AIpaKACkxzn2x0H8/6dKWigApMc59sdBn65x9fb2paKADH8sdv8/0pMc59sdB+ef8ilooAKTHOe+Mdv8AD/63tS0UAFJjnPtjoPzz/kUtFABSY5z3xjt/h/8AW9qWigApMc574x2/w/8Are1LRQAUmOc98Y7f4f8A1valooAKTHOfbHQfnn/IpaKACkxzn2x0H55/yKWigAx/LHb/AD/Skxzn2x0H55/yKWigApMc574x2/w/+t7UtFABj+WO3+f6UmOc98Y7f4f/AFvalooAMfyx2/z/AEpMc59sdB+ef8ilooAKTHOfbHQfz/p0paKACkxznvjHb/D/AOt7UtFABj+WO3+f6UmOc+2Og/PP+RS0UAFJjnPfGO3+H/1valooAKTHOfbHQfnn/IpaKACkxzn2x0GfrnH19valooAKTHOe+Mdv8P8A63tS0UAFJjnPtjoPzz/kUtFABSY5z3xjt/h/9b2paKACkxznvjHb/D/63tS0UAFJjnPfGO3+H/1valooAKTHOfbHQfnn/IpaKADH8sdv8/0pMc574x2/w/8Are1LRQAUmOc+2Og/PP8AkUtFABSY5z7Y6D88/wCRS0UAIBj/ACP6evejHOfbHQZ+ucfX29qWigAx/LHb/P8ASkxznvjHb/D/AOt7UtFABj9OKTAzn+g/Pp/9b2paKAEAx/kf09e9GOc98Y7f4f8A1valooAMfpxSY5z3xjt/h/8AW9qWigAAxSY5z3xjt/h/9b2paKACkxzn2x2/w/8Are1LRQAUUUUAFNdVYcjOOQPfBHHocEjI554606igBgJOOAMjpuHbPAxnv39B0p/4f59KYOo4xwOCwPTPAxnoe/seM07Ht2655GeTk5z+RPNL/g/g/nZrotNtkL+rr5eT0fXXT8looopjCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAYDkjgDIHGR2zgYHcHvjjBA9S4D27dc8jOSRnr1700ZJzgcgd+OOwHPQ45xx068lwHt2655GeSM9evp39KX/B/B/PVdNvRdEuny13fTfTr1fl9y0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMBPHHYcE+nbGTyD1PbGBnqVx7duufXJIz169xmkGTg44wO/H4Dtz1PbBABPJdj27dc+vOM9evel/m/z+eq6fkukrZei13fTy69X2X3LRRRTKCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAYM8cDGOmeMjtj1HU8cAYHI5Uew6jrn15xnOevcUgzkHA6evA9gO3IBPHGMDkcqPYdR1z684znPXuKX9a+vz9Vr8lbSVstO23y/Dvq9F9zqKKKa2X9f5fkigooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGjJwcdhxngY7Y9Qep7AYGT1B7DqOufXJIz169xnrSAk44GMDuO3sO4PU446Dpyo9h1HXPrkkZ69e4z1pP8Ar5P810X/AA5K2Xy16vb89n6fc6ij/PrRQtl6f10X5L0KCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqSccdhwT/L3B6nnGMDpy7Ht2659ckjPXr3GaaDyOB0HU/kB+PXHTGBz1fj27dc+vOM9evel20/pPd76rotPTqStl8tevTfTr18l9y0UUULZen9dF+S9CgooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEankcdh1P8vxHJHTHHI5fj27evIzyQT169xmmA8jgdB1P5Afj1x0xgc9X49ucHv074z16+maXbT+k93vqui09Oolsn6a9em+nXr6fctFFFNbL+v8AL8kMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSeOOw6nv7c4yD1x06D3fj25we/TvjPXr6Zpgzxx1A6n06AdsjqcZx256vx7c4Pfp3xnr19M0dv667vez7LT9RLZP0169N9OvX0+5aKKKBhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqTxx2HU+np2yD1x05xz1fj25we/TvjPXr6Zpi5447DqeOO3pkdSRnHOOer8e3OD36d8Z69fTNL+vxWvX1X9WS2T9NevTfTr19PuWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSePoOCf5c4yCOSOmDjkcvx7c4Pfp3xnr19M0xSeOOw6n09O2QeuOnOOer8e3OD36d8Z69fTNL/AIf8fnZrov6SWyfpr16b6devp9y0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqeRx2HU/y/EckdMccjl+PbnB79O+M9evpmmKTxx2HU8cDt2yD1I6YI68l+PbnB79O+M9evpml/X4ry3XT+rJbJ+mvXpvp16+n3LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGp5HHYdT/AC57Ec46YwOnLx0GB1Hr689evXuM+tMXPBx2A5PcDjHPUdSe2Djkcvx7c4Pfp3xnr19M0Pp/Wz676rotP1Etk/TXr03069fT7looooGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGueOOMDqe/tzjII59McD1fj25we/TvjPXr6Zpq5447DqeMgdMevckdMEDJHLseg7Hvz68nOevpml/X4/PVdO+/olsn6a9em+nXr6fctFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADATxx1A6n07Y6ZBGSR0+vJdj25we/TvjPXr6Zpq5447DqeM46DtkYySM4wQOerse3OD36d8Z69fTNL+vx3669u/l0S2T9NevTfTr19PuWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSeOOw6njgdu2QepHTBHXkvx7c4Pfp3xnr19M0wZ44HIHU+nYe46kjOOQOQcvx7c4Pfp3xnr19M0P8Ar7/zXT+mJbJ+mvXpvp16+n3LRRRQv6/4O1hhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARrnjjqB1P8ueoPX07D1fj25we/TvjPXr6Zpq5447DqeM46DtkYySM4wQOerse3OD36d8Z69fTNL7v6fXezXTa+9uolsn6a9em+nXr6fctFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEYJ46YIHU9xjoM9QevH055L8e3OD36d8Z69fTNNHbocgd/T0HqDySOnIHPV2PQdj359eTnPX0zS+X/AAdeu9rdFdeiEuny13fTfTr1fl9y0UUU1/X/AAdrDCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjUnjjsOp9B27ZHcjp256vx7c4Pfp3xnr19M00Z478DvxkDsPXuSOmCByOXY9ucHv074z16+maO39dd3vZ9lp+pK2T8lr1e2+j3669N+y0UUUL+v+DtYoKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCMZ49wOCfT07ZGMnGcduer8eg7Hvz68nOevpmmjPHcYHc4z2x2yMZOOn1HLseg7Hvz68nOevpml8v+Dr13tborr0Ql0+Wu76eXXr9/otFFFNbL+v8AL8kMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBi5446gdT6DsPUHkntg4yeS7HoOx78+vJznr6Zpozx34HfjIHYevckdMEDkcux6Dse/Pryc56+maXb5/nu97NdFp6Lol0+Wu76eXXr9/otFFFC/r+rIYUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNc8cdQOrenoMnkHqe2CAO5fj27dc8+uCevX0zzTBnjjqB1Pp0A7ZHU4zjtz1fj0HY9+fXk5z19M0u2n9J6N76rotL72QlsvRa7vpvp16/f6LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGueOOoHVvT0GTyD1PbBAHcvx6Dse/Pryc56+maYCeO/A6njj09x1JAOOnXq/HoOx78+vJznr6ZpfL/g69d7W6K69EJdPlru+nl16/f6LRRRQv8Ahv8AhrK3oMKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUVR1Owt9U0+9068RpLS+tZ7O7iSWSBpba5ieCeMTQvHLHvikcb43SRT8yMrAMB3s7b9Luyv5uzt62foOPK5RUm4xbXM0lJqN9WotxUmlqk5RTel1uXqK/ga+Mn7Sv7cX7Fn7R/xi+DHhj9p742afbfDL4h69oWi2Ou+NNT8XaXdeGkuhe+Eb1tG8aN4g02WLUfC91o97l7UeZ52QASa+o/g1/wcAftf+Bpra1+LHhf4afG7RkaNbm4l02X4ceL3iUgMYtY8Lx3PhrzWXJJm8FSb3OS6jp+fUfEXKPb1MNj8NjcBVo1Z0ajlCGIpQnTk4TTlSl7X3ZJp2oPZ9dD+5M1+gV4pyyXL+IeCuIOEON8szXLcHmuXU8PjMTkmZYvB4/DUsXhalOlmlBZWvaUKsJrnzmK1STd9P7QqK/F79nT/guX+xr8ZHsNF+IWpa9+z34su2jhNv8AE2GGfwdPdSMEEdn8Q9DFzosEJLALP4otfCqYUsVBO0fsToWv6L4n0mx17w9qum65omqQJd6ZrGkX1rqelalZyruiu7DUbKWezvbWUfNHcWs0sTjlXI5r7LAZpl+Z0/a4DGUMVGyclSqJzhfb2lJ2qU2+1SEX5H8ncaeHPHXh3jll3G/CudcNYmblGg8ywdSnhcXyfFLAZhBTwGYU49amCxNemv5jYooorvPiwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGDPHQ5A7+noPXOCT27c9XY9B2Pfn15Oc9fTNNGeDgHIHf07Y9c8n05wM9XY9B2Pfn15Oc9fTNL7v+GfXezXTVX7IXb/h309d+rv8A5i0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH8bv/AAcI/BZPBn7T3w3+M+n2nkaf8aPh0+l6zcKm1Ljxj8MbyDS7meQrlDNP4S1zwtAgOZGTTHJ4TNfgTX9oH/BwN8LE8X/sX6F8RoLbzNQ+D3xb8K6xLcBMtD4e8aQ3vgbVod4+ZY5dX1bwzcSAlUzZxkhiq4/i9JwM88EfXAP9RX878c4FYPiTG8q5YYyNLG00lu60eWr85V6dZ/Ndz/eT6GPF0+L/AKPvCUa9V1cbwpiMz4QxU5SvanlVeNfK6et2o0cjxuWUYrb93db2LIGPTO0rkgEYIweDkGvqr9mj9tf9pj9kbWE1H4IfE3VtD0d7hbnU/AOsk+IfhvrrZJlGo+Db6Q2FvcTL8r6tobaPrig/udTjYZPytRXy2HxOIwtWFfDV6uHrQd4VaNSVKpFu204OLS0SavytaNWP6OzzIcj4myzE5JxHk+W57lGMjyYrLc2wWHx+Drro50MTTqU+eL1pzUeenK04SjJJr+1H9hz/AILZ/A79o640j4efHGDTPgJ8Yb1obKyl1LUy3wv8aajKVjjh8NeJ7/y5PD+pXUrYt/Dni14t7sltpviHW7llir9vEkR1DKwKkAg9DyMjIPIyuGGecHOK/wAvEqrAqwDKwIKsoYEEdCrAgg9wQR7Gv2s/4J5/8Fivij+y5Po3wu+ONzr/AMWPgCGgsLO6kmbVPiP8LrMERJJ4a1C+mEvibwtZIQz+DdVulnsoFP8AwjGo2QjGlXn6rw34huUqeDz62toU8yhFRV3ZJYulBWSvde3pRilp7Snbnqr/ADQ8ffoIU6dLHcV+CKqt01UxOM8P8ZiJ1pygkpVHwxmOJqSq1JxSco5RmdapUq++sHmDqfV8vn/bLRXm3wn+Lfw8+NvgXw/8SPhZ4s0jxv4J8S2S3ujeItDuPtFjdxhvLmgcSCO5s9QsZg9rqmlX8Ftqel3iPaX9pbzoY69Jr9ahOFSEalOcakJxjKE4SUoTjJKUZRlFuMoyi01JNpp3TP8AMTF4TFYDFYjBY7DYjB43CV6uGxeExVGph8ThcRQnKnWw+IoVYwq0a1KpGVOrSqQjOnOLjKKkmgoooqjnCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGDPHQ5A7+noPXOCT27c9XY9B2Pfn15Oc9fTNNGeO/A78cdh78ZPoB0z1dj0HY9+fXk5z19M0v+D+D+eq6bei6Ls/x+710fXX/MWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA+JP+CkPgFfiV+wp+1P4VMPnzP8GvGHiGxjxuP9q+CbH/AITbSmRQCS6ah4dt2UrhgQMEV/neo29Q4+6wjZfocMDxkcgg9T9a/wBN74r6NH4i+GHxG0CVBJFrngTxfo8qFQwePU/DupWMiFSCCGScggg5HGK/zHLUFbWBW4KRQK2fVURTz7EGvxrxQpKONyjEJLmq4bE0pPq1Qq0pwT+eInr5/f8A61/s382qVuEfFDJJSvSy7iHIM1pwvdRqZxluMwlaSXRyhklFPq+VGlRRRX5Yf6OhRweCMjvRRTW69fR7r7vlrv0A+7/2Ef8AgoD8YP2FfiCNZ8KSz+LPhX4gvreT4jfCTUL149I8QQIFhk1zw7JJ5kHhrxxZ2v7uw12KFrfUI449M8QW1/p/k/ZP7p/2b/2kfhP+1T8LNB+L3wd8SQa/4X1pGgurZ9sGt+GdbgSNtR8MeKdLLvNo3iHSmkVLyxlZ45I3gvrCe80y7tLyf/Np/l3FfZX7Ef7bfxS/Ye+LNv4+8DTS614O1p7Ox+J/w0u7toNE8daBA7YaIsskGk+LtISWabwx4lSF5bK4eSyvVutJvb6zn+74R4vr5LUhgsdOdXKqkrK95zwMpNN1KK1lKi2061BX0bqUUp88av8AGn0ovoqZT4w4DF8X8H4fCZT4nYLD8/NFU8LgeMqOHppQy7NZe7So5rGnBU8szifLtTwOZTlgvq2Jyz/RGBzyKK8L/Z1/aG+GP7UPwo8MfGH4Sa8mu+E/ElqeJAsWq6Fq9thNW8MeJbLczaX4l0K4Jt9V01iwjZorq1ludOu7O7uPdK/eKVWnXpU61GcKlKrCNSnUhJThOE4qUZRkrqUZRaaadmmf4n5lluYZPmGNynNcHicuzPLcVXwWPwGMozw+KweMw1SVLEYbEUKijUo1qNWMqdSnNKUZRaa0CiiitDiCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAYM8d+B3447D34yfQDpnq7HoOx78+vJznr6Zpozx34HfjjsPfjJ9AOmersY6D15z+PJ68n0zS/r7n1323WuvZC7f8O+nrv1d/8AMWiiimv6/wCDtYYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBg+KZY4PDWvzTMFhi0XVZJWboI00+5eQnkcBAxPtnII4r/AC/VZXjDpjY+XX/dfay44BHysP8APFf6U/7Uvi+L4f8A7NX7QHjiWUQr4S+C/wAT/EKyFtuJtK8E65d26huMO9xFFGmOS7AAE1/mq2yGO1gjPLRwQxt65WONfzyp7detfkHijUXtslp6XjTxs5d0pzwsYvold05rXez2sf6tfs28FUhk3i7mLTVHE5hwfgqcre7KrgsNxDXrJP8AmjDH0L9lJX6GnRRRX5Mf6XBRRRQO2jd/l3/r/PsFIQDwQCPQjIpaKtNefnrt8NnfTqu+gj9BP+CeP7ffjz9hL4sjXLb+0PE3wc8ZXVja/Fj4dxTBjfWcO6CDxf4XhnkS0s/HHh+3kf7HM5ig13TVl0DVJVilsb7TP7zPhd8UPA/xk8AeFvif8OfEeneKvBPjTSLbW/D2uaZIXtr2xuQw2ujATWt7azJLZanp1ykd5pmo211p97FFdW0sa/5l44Ir9gf+CUP/AAUkv/2NviCvw0+KGrXlx+zZ8Q9YjfWWkMt2fhT4qvfLtl8f6VbgSSLoF6Fhg8e6XaJums4oPEFnE+o6XNbap+g8E8WPK60MrzCrfLa82qFWb/3GtN9ZP4cNVlZ1Iv3aU2qy5YyrOf8ACf0wPow0vEvLMV4j8C5fGPiFk+EU82y3CUrS4zyrCUlFRjShb2vEWX0IJYCcU62ZYWH9lyVatTyyND+4+isvSNX07WtOsNU0q/tNU07VLK21LTtR0+4ivLDUNOvYUuLLULC7geSC7sby3kjuLW6gkkhngkSWJ2jdWOpX7mmmk07p6po/xklGUJShOLjOLcZRknGUZLRxlF2aaejTSa6hRRRTEFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADBnjocgd/T0HrnBJ7duerseg7Hvz68nOevpmmjPHGRgd+OOn455Jx9Oerseg7Hvz68nOevpml9z/4D672a6a69kJdPlru+nrv11fe/ZaKKKYwooooAKKKKACiiigAooooAKKKKACiiigAooooA+EP24/2zPEn7E/hTRvibefADxf8AF34UM0lr448V+CPEWlWeo/Du9ku7aDSrnXdB1OxIl8P6v57wJrsepw22n38UdnqKW4vbSeT4g8Ff8HAv7E/iFoYfFfh742fD2WTYJbjVfBml+IdMgLYyWufCPiPWr5kXkll0skqM7cnFftt4g0HSPE+jap4f1/S9P1vRtZ0+80vVdI1azg1DS9S06/ge3vbDULG6SS2u7O7t3eC4t50eKWNyrqQa/iH/AOCqv/BNLVP2M/GzfE74XadqGo/s0+OtWaHSpGMt7cfCfxNeu0q+BtcunLSPod84kfwXrNyzNLDG2g6hM+p2Vvdar8LxZjOJsnX9p5XWo4nLopLE4Svhqc5YV6L2qqU1CrPDz+25T56M3dylTklT/sv6MXCH0fvFmsvDrxFyzNcg46xE60+HeJMp4ixeDo8SRblVlldbCY/69lmEzrCwv9SVHCQoZnh4OHs44+io5h/VH8M/+Cm37BnxZkt7Xwn+078MrbUbkosWleMtVn+HuptI+AIUs/Hdp4dkml3Hbtt/OyeFJr7a0vWtH1ywg1TRNU0/WNMukElrqOmXlvf2FwjDcrwXlrJLbzIQQQ0cjDBB6V/mCfK4KuqurcbXVXB46ENlT2B57+5Nen/DX4y/F34N6gmq/CX4ofED4aXyOH83wR4u1zw5FKynIF1Y6ZfQ6feISBuivLS4iccOjDIr5bB+KGITSzDK6NRaXnhK06Ml3fsqyrKT8vawXmf0jxX+zjyOrGrU4I8SM0wFRJujgeKspwuZ05y6QqZllU8qnQjdr95HK8S7X9x7n+l8GVs7SDgkHBBwR1Bx3HcdRS1/En8D/wDgup+2v8LDaWHj648FfHnw/biNJYvGmixeGfFhgVsMLfxb4Og0+3e4ZMg3Os+HNblZjvkLtyf2m/Z//wCC9H7I3xRaz0j4s2Hi39nzxHP5cUlx4ptj4p8CGduCIfGXhe2lubWEsSfP1/w3oVrCg3S3CgFh9rl3HHD2YtQ+tvBVXb91jo+wV3ZaVuaeH3dlespP+U/kjj36HHjvwJGtiVwvHi/LKPM3mPBeIedNwjrzPKXSw2fq0fenJZTKjCzTrNWb/caiuK8EfEfwF8S/Dtp4t+HvjLwx438L3677PxD4T1zTfEGi3AK79sepaVc3VoZFXHmRGUTRN8skaOCo7UHIyOh6fT/69fWRlGcYzhKM4SSlGUWpRlF6pxkm001qmnZn8wYjD4jCV6uGxVCthsRQqSpV8PiKU6NajVg7Tp1aVSMZ06kHpOE4qUXdNJoKKKKoxCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPya/wCC1/xat/hf/wAE+/izpi3Ih1f4s33hj4R6NGGCyT/8JNq0WoeI40UZZ1HgzQ/EZlwu1VI3nDYP8I6jrkd1/U/l09q/oU/4ODP2lIfHfx1+H37Nfh+/WfR/gror+L/GyQSh42+Injy0gOladcAMymfw54JjtLtASPKbxldRECRHr+e8KOAB3H6HPv8AifT6V/PvHuYxx/ENalTalTwFKGBT6OrBznXfVpwrVZUpd3SVls3/ALp/Qj4DxHBXgRlGNx1F0cw46zLGcYVac041KeAxlPDZdkqba1p4jK8vw+ZUdPgzC+7aLNGOn1x/n86KmUDAOO3+H9RkZ6e3Svik7O9rn9ajArA//qPpke3B/H3oKn0HTsB1wPT349uTwKlo/wA/nVc7vsnrtb0/HTT/AIYaf3dVfcgIx6j6/U/57UlPY5A9cDnj/ayO3f8Az6sqWrNr8/QGrejtb7k/luFIR0PXGTjr7dDweMjB9fWlooV20vP/AIf8hJ21R/SB/wAEWf8AgpkfAeo6B+x18efEITwdrF5Hp3wJ8a6xcEReF9Yvp2Mfwu1q+nfEPh3WLmY/8INdyusWjaxMfDcjLpuo6Uumf1nKwYBgcgjPTB6kYKnlSCMYPzAghgCDX+Xj0IIJUjkMpKOrA5DI6kMjggMrqQysAykMAa/r3/4JD/8ABVnTPi9ovh79l/8AaP8AEsFh8ZtGt4NI+Gvj3XLtLe3+LukWsQisNC1O+uWVT8T9MgjW3AnkU+NrGKO+tWl8QRahDefr3AvFitTyPM6yUopQy7EVJJKcVZRwdScmrSitMNKXxRX1e/NGjF/5afTS+i/Vp1sx8ZfDvLJVKFaVXGcf8P4Ci5Tw9Z+/W4swGHppuWHrPmnxDRpRcqFVvOeWVCpmlbC/0M0VGkschIRgSMgryGUgkEMpAZcHj5gOeKkr9ZP8wvwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBgzx0PA7+nt65wSew4HPV2PQdj359eTnPX0zTRnjjPA78ceme/GSR0wRjPV2PQdj359eTnPX0zS+7+n13s102vvbqLz/AOC9beT366+fotFFFNf1/wAHawwooooAKKKKACiiigAooooAKKKKACiiigAooooAK4H4n/DPwT8YfAXiv4ZfEbw/ZeKfBPjbRL3QPEehahHvt7/TrtTkI6lZLW9tpRHeafqFs8V7p1/b21/ZTw3dvDKnfUVM4RqRlCcYzhOMoThJKUZRkmpRlF3TjJNppppptM3w2JxOCxOHxmDxFbCYvCV6OKwuKw1WdHEYbE4epGrQr0K1NxqUq1GrCNSlVpyjOnOMZwkpJNf54/7fH7Gfiz9iH4+6z8L9Ve91fwLrKS+JPhJ40uo+fFPgqa4aOKK9ljSOEeJvDM7DRfE1tFHGDdR2+qwwx2Gr2DP8VbiDz+Wc8cf07jqeua/v3/4Ka/sXaf8Atofs2eIPCel2VsvxY8EC78afB3V5PLilj8WWdowufC890wDx6P45sI20G/R5EtYLx9J1icO+jwKP4D7yzvdOvLzTNTsrrTdT027u9O1LTb6F7a903UbC4ktb+wvbaULLbXlldwzW11BKFlimjeN1DIRX87cY8PPIczaoxf8AZ+MU62Dbu+SzXtcM5Ntt0JSjZu7dKdJtuXMf71/RT8co+N/hzTq5vWpPjjhN4fKOLKS5YTxrlTl/ZvEFOlFRUKWb0aNX28acYU6eZYXH06VOnhlhlJgIPIpccg9x0/Hr9Qe4PB71AMjIHX25/l+tTA9M9/p1xz39c9u3TvXyWvS/9f0j+meWS2/D+vw69j1H4UfGz4vfArxEniz4N/Erxl8NPECurzX3hHW7rS4tQCHIh1nS0ZtI1y1PRrTWNPvrZ1yrREEg/vN+y9/wcFfEjww9h4b/AGrvh1ZfEXRQYoJfiP8ADO3svDnjS2jBCvd6z4MupofC3iB1TLOdDvvCTgA7LK5cqh/nJor2Msz/ADfJ5qWAxtalC95UJP2uGn35qFTmpXa051GNRL4Zxep+WeIvgv4Y+K2GnR444QyzNMV7N0qOdUaTy/iDCJK0Pq+dYJ0Mf7Om0pRwtatVwU5RXtsNUjeL/wBG/wDZx/bB/Z1/au8PnX/gd8TvD/i97eCOfV/DfnSaZ4z8OGQDMfiLwlqkdpr2khXYRC7msm0y4cH7FfXUZVz9MZB/z9f8DX+Yv4V8V+KfAviLS/F3gnxLr/g/xVok63Wj+JfC+r3+g67pk6MGEllqmmz295BkjEkay+VMuY5kkjZlP9AP7HX/AAXv+JPgNtL8Fftc+H5fih4Vj8mzT4q+D7Gw074iaVCAI1ufE/hqP7FoPjSKNPnnvNKPh3XHAaaZNbu2CP8AqmR+I+DxbhQzmksBXdorFUuaeDm3/PH3quHu2le9amtZTqU0rH+anjD9ATi3hyOKzrwnzKfGmUU1OtLhzMnh8JxVhKUfeccLWj7DLc8UIqTapxyzGzbhRw2BxlV3f9dFFeK/A39ob4N/tH+CbT4g/Bj4g+HPH3hm5CJPdaLebrrSLxlLtpniDSrlINW8PatEv+u0zWrKyvUALrC0JVz7SCCMggj1HIPfg9+D2r9IpVaVanCrRqQq0qkVKFSnOM4Ti9pRnFuMovo02mf5/Zhl2PynG4rLc0wOMy3McFWnh8ZgMfhq2DxmExFN2qUMThsRCnWoVYPSdOpCM4vRpC0UUVocYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV8p/tnftVeDP2O/gB43+NPi57a7udGtP7O8G+GZLgwXPjPx1qccsfhnwvZnG5heXcbXWqzRZbTNCs9U1V1aOyZH+rD/AJ/r+dfz5f8ABQD/AIJw/txf8FBfjDBqusfEn4O/Cf4F/D6a/wBO+Fvge61jxd4n1mX7U0cWq+PPEdlpXh2y0n/hJvEkcSRwWkeszxaBokNrpcM8t1Pqt3dePnuKzDC5fVeVYOrjMfVTpYaFNR5aU5aOvVlUcaahSV5KMpXnPljblcpR/VfBvhvgfiTjnK6fiTxTl3CfA2W1IZlxDjMZUxH1rMMJhqkZRyXK8Ng6OIxtbGZnU5cPOtRouOBwksRi5T9rSoUa/wDJd8RviD4r+LXj/wAZ/E7x3qR1fxj4+8S6v4t8S6iQVS51jWruW7ult4yT5FjbGRbTTrRT5VnYQW1nCFigVRxtf0r6V/wbgeN3jU65+1j4VtnwBIuk/CLVr+NT3VZrzx9Y5A4xuiQ5xkDJp/iD/g3f03wvpk+q+IP22vDXh6xgVmm1HxD8JrXSNLhAAYtNe3nxVt4I1GcsXmG0EE84z+IS4K4pqc9Wtl75puVSpOpjcFzSlJqUpScsTdybu3KT3betz/Zah9L76M+Ejhcqy7j6jDD4enQwOBweX8I8ZyoUcPQhCjh8NhqVHhxxjTpU4Qp0oU1yxilGKsj+aUdRnp3qUMBxn09vQZHGPU8H1PQ5H6k/F3/gn9+zR8Jnubef/gqD+zDr1/bBw2l6N4V8XeKb7emB5Tw/DHWPiNLDKSdu2SFQp+9gAmvzi8aeHvDfh3U2svDPxB0T4jWILj+2tC0Hxj4etflICk2fjPQ9D1AiT5mUpbsMffKk4rwMXluJwT5MUqEZRduSnjMFXmtr81PD4irNa9XFKz1dz9t4W484b40pLEcO1M7xOGlD2kMVjuEuLcjwdSLSa9ljM9yTLcLWbWqjSrTk9LJt2XK59Mdv6f4/y+lRMxPHT/6+D6D06+/pRuPfn9O4/wAKQ4PI/wA9OB9DkfSuKMbPVX8/u/XbZ6H2AlFFFTyyutumultu39a66B/X9fcFFFFUoJWfb8+nfb+vMCgZV1kUlZUZHSVSVkjeJg8UkUilXilicB4pUZZI5ArowKrgoqmr/wBea/qzWumwX/HR3Sf5n61fA3/gtX+3R8EvD2n+FJvFnhD4u+H9ItorPS0+MHh6+1/X7S0gCrBbHxdoWt+G/EOqrEgEcc/iK81q8RMD7UVRVH0bH/wcRftdoE834Q/s5z4Hz7dM+JUBYgcbceO5QuSMnII5xgY5/AiivcpcT8Q4enGnSzfGqEEoxjKp7VqK5Uop1lUlZJWjG9krJWSsfiea/Ru8Bs7x2IzHMfCvhOeMxdSVbE1cLg6mWxq1pvmqVZUMsr4PD+0qSbnUn7LnqTlKc5OTbf8AQNB/wcV/tUIw+1fAz9ny4UDJEE/xIs2PToz+I7wAfK3JQ/ex0BJ6LT/+Djb4+Rhf7U/Zu+D16RnedO8aeNtNDZxgItzp2qFDgE5LMMngDHP869FarjLiVNWzbEu381PDy6rvSd+u/eyXU8ar9E76OdZNS8K8lSe/ssfxDQe62dHOYNddra2P6YdN/wCDkTxkm0av+yR4aucL+8bS/jNqVrl+PupefDa6wPYyHGeeBmu903/g5G8OttGs/sh+JIPkBkbSvjHol+N2furHe+BNLJ4zwzjk4yM5H8sNFdEOOuJo2/4UnLZe/hcE1074e/fV6/fdeLifoY/RsxLb/wCIdPDuXXDcVcZUlF6aqL4hlDT/AA28tWf1xaN/wcbfAK4ZB4g/Z0+N2kqQDI+k6v8ADrXRGcjIUXPiHQWfAzj5QT6Dt69ov/BwV+w/qQjGqeHfj/4adsbzqPw60LUoYhxkmTw9431eRxjP3IGPXCk4B/i/pMe5H5f1Brrp+IPEkGuavhay0b9rhKcbrS7/AHXsu7bs+x85jfoIfR6xbfsMp4nyu6dvqHFGOnbbVf2pTzJadmmtdT+67wz/AMFtP+CdHiExpdfG3VPC8r4ynin4XfE7ThHyoPmXFr4W1C0GCW5FxtwM5xzXvvhX/gpl+wH4yaGPRP2s/gqks5Ajh13xda+E5yTjhofFa6JKmCcHei/zx/nqjIzyef5enHakYBgQwDAjBDcgj0IPau6l4mZzFpVcFltXb4Y4im35JqvOKff3bHxGZfs7fCGvzPK+L/EHLZv4VicVw/mdGG32I5Dgaslvp9YT6XP9L3wt8dPgn45Ef/CFfF/4YeLvNAaMeGPHvhXXi4OACo0rVbsnJIHAr09ZonVXR1dGAKup3KwOCCGGQQQQQQcV/l3C2tg28W1sHAwHEESuO4IdUDAg8g5689a9H8K/Fv4r+BZY5vBPxT+Jvg2SIgxN4T+IXjHw55ZUgqUTSNas4xtwMDZjgccV6dHxRlp9Yya/96jjXrte0J4Z9+s9Nr3PznNv2btK055F4tyuk3Chm3B276KWLwfEOmu7WCemqi7a/wCmZ5sf/PROuOWA5IBA5PXBFOBB6EH6HP8AKv8APd8Ff8FOf2/PABi/sL9qr4pX0UO0JbeM7nRPiHAVTGEc+O9H8Q3DL8qg/wCkAkDrnmvsDwL/AMF8f28PCpij8TR/BX4lW8ePMPiL4fX3h/UJQMA/6X4I8SaBYxswHLDR3UE58sgAV7GH8SsjqWWIw+Pwre7dKlWgtutOrzta/wDPv5H5Pnn7PbxlwHPPJs94E4hpq7hSpZpmeWY2fZOlmOT0sFBtd8xaXfRn9sdFfyw+Af8Ag491iJYYPip+yxa3Z4Fzqfw6+JhgPUZaHQfFXhchsL0jfxICSceb3r7g+Hv/AAX4/Yb8WtBB4uh+L3wquZdqzSeKvAR1zTIGOAx+3+ANU8XTvGpLfvHsIAFG7aMha93C8ZcNYtpU81oU5O3u4mNXDWb6OVenTh902vM/GOIfom/SF4bVSWM8M86x9KF2qvD9fLeI+eK+1ChkeNx+Ls1qlPDwn05bn7fUV8b/AA0/4KEfsT/FwQp4G/ac+D2o3lxtEWlan4x07wrrbs+0BBoXi59C1jzNzBDGLIuG4x1x9d2mpaff20N7Y3lteWdwiyW93azJcWs8bgFZIbiJmikjYEEOjlSDwa9+hi8Lio8+GxNDEQ356FanVjr/AHqcpL8T8OznhziHhyv9V4hyHOcixV3H6tnOV43LK/MtWvY42hQqXS1a5bpF2imLJG/KOjdPusD15HQ+4p9dB4wUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMGeOnT19Pb1zgk446fV2PQdj359eTnPX0zTVzx3GB3449vXOMnt068l2Pbt/nJ69fTPPNL+vx+evba/ZdF29N9309dH11+fUWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBrqHUqe49xg9jkcjHtX86f7dv/BDrXP2jf2gPFnxw+B3xJ8CfDWD4gRW2seMvCPirQ9euLafx0oe31jxJpV7oLSxwQ+Jo4rTUdVtJbAynXH1PUxNIdQMUf8ARdRXl5rk+X51h44XMaHtqUKiqw5ZzpzhUUZR5o1KbjNXjJqSvaStdNpNfo3hl4r8c+EGfV+I+As4/snMsVgKuWYz2uEwmYYTGYGrVo13RxOCx1GvhqvJWoUqtGq6arUZxbpVIqdRS/iI+Kf/AAQm/bv+Hlncaj4Y034Z/GK1t43me1+H/jVtM11kjBLeVo/j3TPClvcyEA7Lez1W5ncjYiM3yn8nviB8OfiB8KPE934K+J/gfxX8PfF1ku658N+MtC1Dw/qyRZ2rcQ2uowQNeWTniK+smns5s5huJVKmv9NcjIwff9QR9e/Yg+9fPX7Rf7LXwQ/ap8B3nw9+NXgfTPFejzRTnS9SZBaeKPC+oSoRHq/hHxJCBqegapC6xt5tnMLe6jjFpqFte2Mk1rJ8HmfhngalOVTKMXXw1dJuNHFSVbDzfSPtIxjXpN7c7dftyatn9reHP7Q3jHAY/DYTxQ4bynP8mnUhTxGbcN0J5Tn2EpycVPE/UquJq5VmXs0rrCU45Q57/W1bll/m+DB54OefX09fw9OnQUtfov8A8FB/+CcvxQ/YS8axzXMl542+B/ii/lt/APxRitBGFuD5ksfhDxvDbj7No3jOCBHeB4wmk+J7WGXUNFMU0Go6Tpf5zZyAR3x9O3GffoD68ZHFfkWOwOLy7FVcHjaMqGIou04SSt3UouN4zhJWlGcW4yi1KLadz/UrhLi/hzjzh7LuKuE82w2dZDmtL22Ex2Gk7XT5atDEUZxhXwmLw1ROjisJiKdLEYetGVKtThNOI6mP2/oQD1HQ5H9R3OMA00t7c5z/AOg4/QH86TcSMHn+f09u/PJrkPpeWS1XruvL/P52PW/gr8d/i9+zt43s/iJ8FfH2vfD/AMV2hiSW70e5BsdXs45BIdK8SaJcrPpHibR5Wz52ma3ZXtqcl0jjlCSL/Vx+wj/wXI+F/wAaX0b4Z/tRQ6H8GPijctbafpvjmO4ktPhH40vHxDGr3t/NPN8P9ZuXKY0/Xru58OzzMVs/EVtJJBpi/wAdX0oYB1ZXAZWBVlYBgwIwQwPBGMjkHOTn2+gyPibNMhq3wlb2mGlK9XBV3KeGne15KN70qjS/i0nCTtFT9pBcj/D/ABj+j94ceNmXypcVZVHB5/RoullnF+UwpYXP8A4r91Tq1+R08zwEHe+X5jDEUIxnVlhPqmJmsTH/AFCre4huYYri3ljngnjSWGaJw8csUq74pY3XKvHJGVdJEJR0IdCUIJmr+F39gT/grh8bP2OrjSPAfjdtU+Mf7PsLxWx8HajqAk8YeA7Jn+ef4b69qEjKtjbKzSHwVrMx0KZQYtKufD08kl2/9lf7PX7Sfwa/aj+Hmm/E74KeNdM8YeGb4JDdx27m31jw5qnliWfQfFWi3ATUfD2u2gbE+nX8KF023NlJeWMkF3J+6cP8UZdxBS/cS9hjIRvWwNWS9rGyXNOk9FXopu3tIJOOntIU3KKf+M3jj9G/j/wNzBzznDf2zwniq/ssp4xyyhU/szEud3Sw2Y0nKpUybM5Q1eCxc5Uq0o1f7PxePp0atWPu9FICGGQQQehBBH5ilr6Q/n0KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAopCyr1YDPTJA/nUMtzBDDLcSTRpDCjSSys6rHHGg3O8khO1ERfmdmICqCScA0DSbaSV22kkt23ol8yeivz4+PH/BUj9hz9ng3dl42+PXhLXPEtoGD+C/hrNJ8SfFYnjOHtLmy8JJqdnpFzuDIV8QX+jxo335UCsa/HP41/8HHCO15pv7On7OtzJgsll4t+NXiCKyiPQJN/wgngyW8uJFJXeFm8cWbAELJECSK+fzDinIcsco4rMqDqxunQoN4mspK3uyp0FUcHr/y85F5n7hwL9G3xt8RFRrcN+H2ef2fX5ZQzfOaVPh7KJU3/AMvqOOzupgaWMpxWrWA+tVHtGEnof1Jbl9R/kgf1H5j1ryz4mfHH4OfBnTW1f4s/FL4f/DbThG0q3XjfxbofhlZlUAn7LHq17azXj4OVitI5pXIIVCcZ/hd+MX/BWf8Ab5+NP2q11f47av4C0W4Eq/2B8HtPtPhvaRwyZBt/7b0oS+M7iPaduLvxTPkdT6fnlq2p6n4g1K41rX9T1LX9Zu3aS71nXdQvNa1e6lYkvJc6nqk93ezuxOWaWdmJ5zXxmO8TcPG8cuy2rWfSri6saMFtqqVJVpyWqdpTpu26P664M/Zy8SYn2WI4/wDEDKcng+Wc8t4Wy/E53ipRe9KeY5i8pwuFqx6yp4PMKd72ckrv+3b4s/8ABc/9gz4cC4tvDHivxn8aNVhVwlt8MfB182mNMo+VW8SeNJPCOhSwlgR9o0691JMHciyAAn8x/it/wcY/ErUPtFr8Ef2c/CHhWM747fW/ij4s1PxdfFeRHM3hzwpbeFrO2kGAfKPibUYgcBmdev8ANpz3JP1or5LF8e8R4u6p4mjgoP7OEoQTS009rW9vUTs3rGUHfW1j+pOEvoQfR/4YVKpj8hzfjLF0+WX1jijO8VKlzq13/Z+SrJsvqQbv+6xWGxMUtG5bv9Kfif8A8Fd/+Cg3xU8+G9+Pup+B9NmLAaX8KdB0LwEkCuT+7h1vT7K58XBQDtVpPEjydfnJr4A8Y+OvG/xE1B9V+IXjPxd481SRmd9R8beJtc8WXpdySzC58QX+oyoScHCMoBAwMDFcrRXzWKx+PxzvjMdi8U/+n+Iq1Y9NoznKKWmySVunU/pDhvgbgng6mqfCXB/DHDMVFRcsiyPLcsqzS61a2Ew9KtWk+s6s5zfWTd20UBF2p8ijoqYVR2wFXAxjjGOhxS0UVyH1Tk5bu4UUUUCCiiilbW936dP6/rsAUUUUO+n9dv0v/mgFAz+RP6UrAA8dO309ffJz/TjFIO5/zz/k/j6daG6/z9yMjP44796mLurW2X5WXbrr9zK+z53v520Xbbftr9wlFFFWSFFFFZOKUb9bJ67dLu3/AA+5o4pRv1snrt0u7f8AD7hRRRQoXV01/X9P+npmFFFFCjJ+S9f0+S/ALvv/AF/SX3BRRRVqKXe//Df5f53AKKKKFFfda2+n3t9b/eAUUUU2np8vzXbyv+ABRRRWUXqvu9VoktPTy827hdrZ2BwkwCzJHMq8BZUWRRwf4WVh3Pb/ABHpfw++M3xe+E12l98Lvir8SPhxdRsrI/gbxv4l8MREqQR5lrpOp2lpMuQMxzW8kbAYZSvFeaY/z+v9KXH6cH2PP+FbQnKE4yp1J05xd4ypzlCSem0otO+2zv1MMXg8LmGGqYPH4PC4/B1U1VwuNw1HFYarHqqlGvCdKaeqalF3TaZ+rXws/wCC0n/BQP4ZG1gu/itoXxS0u12Z034q+CtF1qaVEwNkviHw4nhbxPK7KNvm3Os3T9WO881+lXwp/wCDjWQC1tPjl+zS5yUW78QfCPxnFMoXgPJF4Q8Z2lmwHVhGfGkxHC7icGv5e8kdCR+NGT1yePf1z/gf84r3sHxbxFgbKlm2InBWXJinHFxsktF9YVWSXS0ZRttFrp+GcVfRe8BOMvaTzTwz4fweJqXf1vhunX4Xrxm96rjw/Wy7D16l3dvFUK8ZP44yP7uPhF/wWe/YC+K5t7af4vTfCvV7hkQaR8YPD2p+DSjuQAjeIlXU/BYwzEb/APhJtuBuAAzj9KfB/wAQPA3xD0iLX/APjHwt420OdVaHWfCWv6X4j0qQMoZSmoaPdXlqwIIxiXPPIByK/wAx8k8jtjGG5475yMH0OR0OK6fwf408YfDzV4fEHw+8YeKvAevQOJIta8FeItZ8KaojqQVJvtDvLG4cA8lZJHQ4wykcV9XgfE3H07LH5dh8VGyTqYapPDVOl24y+sQk93ZKmn5WZ/MXGH7OngrHe1rcDceZ9w/VacqeC4hwWD4gwTlZWpQxOD/sPF4al/08qLMKqu7qof6coYNnBBA9Dk554wOenPuDTq/hN+C//BaH9vX4PC0tNR+I2jfGbQrUru0n4v8Ah221q/liGA0f/CYaBL4e8WvKVACz6jq2qFD87Rycg/rn8Fv+Dib4T619j074/wDwP8afD68ZUS68S/DzUrL4heGvMPD3E2kXsfhrxLYWw+95FpF4iuFXgNKwyfssv4/4exvLGrXq4CrKy5MZSahd72r0XVpJLvUlT80tj+TONvoP+PPCKrV8uybLOOMBSvJ4nhPMqdfFcn2b5RmcMszWrWa+KlgcJjVF6KpJe8f0f0V8i/An9u39kz9pAWsPwj+O3gDxLrN2E8vwpcasfDnjRWcFjE3g3xPFpPiV5IshZGt9Omh35CSugDH638yMHBdAfQsAeuOhweuB9eK+voYjD4qmquGr0cRSe1ShVhVg+uk6cpR28z+V86yDPeG8dUyziHJs1yLMqLtVy/OMvxeW42nra88LjKVGvBXuk5U0nZtaaj6KQEHoQfoc/wAqWtjyQooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBgzx06Dvxx7eueSe3T3Lseg7Hvz68nOevpmmrnjjjA6njjtjnnOMnt255LsY6D15z+PJ68n0zS/4P4P56rpt6Lolsn5LXr09d+uv+YtFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAebfFr4TfD/43fD7xP8AC74n+GdO8XeCfF+lzaVreianHuguIJPnhmt5UInsNUsbhYr3StWs3g1DStRgtr+xniuYEev4RP8Agoh/wT+8e/sK/FP+zZRqfif4LeMby7l+F3xFmgDm4SMNcS+DPFk0EcdnaeONEtiTKY0gtPEemomuaUiAalYaZ/oCV4j+0H8APhp+0x8KfFnwe+K+gR6/4R8WWH2adFMcOp6TfW5abS/EHh2/ZJG0nxJol5tvtJ1SJS0M6GKaOeynuraX5XinhnD8Q4T3eSjmNCLeExLW/V0KzSvKjN7PWVKb9pBNOcKn9KfRt+kTnngRxQvavE5pwHneIow4o4fjPmcF7tOOd5RCpKNOjm+Cp2vHmp0syw0FgsTOm44PF4H/ADXic85GOwGOPYevAH0780lfXX7av7HnxG/Yo+NWrfCrxzHNqehXaz6z8N/Hsds1vpfj/wAINP5dvqUCbmS013TGZNO8U6KGd9K1RS8Rm0y8029vPkWv54xWGr4PEVsLiaUqNehUlTq05pKUZxdmnZtNPRppuMotSi3Fpv8A3h4f4hybinJMr4i4ezDD5pkmdYOjj8szHCyc6GJw1eKlGSTUZ05xfNTrUasadfD1oVKFenSrUqlOBRRRWB68o6N6LyW3Rabeb/q4V73+zl+058av2UfiHa/Ev4I+MbrwxrirDb61pcyvfeFfGOkxyGRtC8Y+HmljtNc0xyWMTOYdS0yVjd6Pf6feBLgeCUVrQr1sNVp18PVqUa1KSnTq0pyhUhJbSjKLTi+l100d02jy82ynK89y3G5NneX4PNspzGhPC4/Lcww9LF4LGYepbno4jD14TpVYSsnaUXaSjJWlFNf3p/8ABPr/AIKe/B79uDQIPD0htfh18etI077R4p+FWpX6SHUY7ZF+2eIvh9fyrCfE3hksfNngCLrvh1GEWtWpthb6ve/p4CD0/Tkfge9f5hfhrxJ4i8GeIdG8WeEtd1fwv4p8Oajbav4f8RaDf3Gl61ouqWjiW21DTdRtJIrm1uoX5DRyASIzxSh4ndG/r/8A+CYf/BYbQf2ghoPwG/aW1DSPCXx1KQab4R8bOLfSPCXxgkVdkNoVHl2nh34i3GAZNGzDpHiefdN4e+yX8n9gr+1cJcc08x9nl2bzhRx+kKGJsqdHGNLSM1ZQpYmXRK1Kq7qCpz5ac/8AIj6TX0M8fwHDMOPPC3D4zNuC4Opi844bvVxmb8KUfjqYnCTbqYjNcgormdSpN1MxyuivaYuWMwtPE4+h++1FMRww6rnOCBwQckYIPOeD1APB44p9fpJ/n8FFFFABRRRQAUUUUAFFFfhL+3P/AMFpJ/2MP2lPEXwBH7PCfES28O6D4Q1uXxQvxNHhi4uj4p0mPVTbR6Q3gnW44hZhmtxK2ouZ3Afy4Rla8/M81wGT4ZYvMa/1fDurCiqns6tX95NSlGPLRhUnqoSd+Wytq7tJ/deHvhrxp4qZ7V4a4EyZ55nVDLsTm1XBrHZbl3LgMJWw1CvX+sZrjMFhnyVsXh4KmqzqydVOEJRjNx/dqivwI+E//Bwn+yr4tntrH4q/Dv4rfB25meOOXVTZad8QvC1sWwHee/8AC80XiRYUJJ3p4Pk2jkhcV+wnwT/aX+A37RuiPr/wR+K/gf4kWEMayXsfhnXba81TSg/3BrehSeRrmhyMSB5WsadYy7vlCbgRWWAzzKMzajgcww2Im1dUoz5K1rXv7CooVrW1vyHoca+Dnil4dRdXjTgXiHIsIpKH9pV8FLEZQ5tpKnHOMC8VlU6jb0pwxkpvdJnudFNDoxIDKccHBB59Dg8H2P8AjTq9U/NQooooAKKaXQdXUfVh7e/uPzHrXHeN/iL4C+GmhT+KPiJ408KeBPDdsCbjX/GPiHSvDWjQ4Xdtk1PWbqzslcryqGbe5+VVLEAzKUYRc5yjCEVeUpNRjFd3JtJLzbNsPh6+LrUsNhaFbE4ivONOjh8PTnWrVqknaNOlSpxlUqTk9IwhFyb0SZ2dISB1IH1/zz1H51+Mnx1/4LrfsNfCP7bp3gvxD4n+P3iS3EiR2Pwr0Vn8Ni5TgJc+OPEz6H4fktmYMGvNBl8QqF+ZIpMAH8Xfjx/wcAftV/EWS60/4LeEPAnwF0JzIltqElsvxM8erGwCh21bX7Gx8JWkhAVtsXg26eFjlL1/vV8tmPGnD2Xc0ZY2OLrR/wCXOBX1h32adWLWHi091KsmnpY/pTgP6IPj1x77Gth+DMRwxllXlf8AavGlR8O0IwlblqLL8TTqZ7XpyTvGphcor02tedJpv+ybW/EGh+G9Mu9a8Q6vpehaNYRGe/1fWb+10vS7GFcFpry/vpYbW2iVcs0k0qIACS1fl38dv+Czv7CPwSa8060+Jlz8ZPEto0sbeH/grpo8YwCePA8qbxdNc6X4FjBcMkpj8TzzxYJ+zsVKn+KT4s/Hv43fHjUjq3xo+LXxA+J13vMkMXjDxPqWqaXZMxJxpmgtMmgaTGpPyRaXplpFGMBEUACvJhwAAAAOAAAAAOgAGAPwr4bMfEvGVeaGWYCnhovRVsVJ16jWnvKnTdOnB9k6lZb3Xb+zeA/2dnDOBdHFeJHG+ZZ5WXLOplHC2Ghk+XxkrN06ma4+OOx2NoS1vKhgsorctuWUZan9EPxx/wCDhv42eJftmmfAD4NeDfhfYyB47fxN8Qb+4+IXitV6Jc2+j6cNA8L6ZcfKGFveSeKLdD8pMi9fx0+Nv7ZH7U37RklwPjN8dviH4y025dnfwwdbk0DwTGWJOIvBPhhNG8LgL0DSaVLKQBvkY81800V8Rj8+zrM7rHZjiKsJPWjGfsqHT/lxRVOk+15Qk7W1et/7K4G8C/CLw39lU4O4ByDLcbR5XDN8RhpZvncZJK8oZ1m88dmdLmd3KFHE06V37tOKSQ2NEiXy4kSKPORHGqxoOucKgAGc06iivIa2s7fK66fJbaWt3XU/WXOTd222++v5hRRRUqOqvLXqna+3q77L5E3b3YUUUVaSWwBQOSB60U4EnHI7AA/UY6D29Qaf9f1p/X5AmOQPp+vSjBH+c+n+Ip3HdunoD6DuPTGP8D0aT26j1xz0Hr06Uk729Ozt02f6fkAlFFFMAopQpP8AntnH+f8A64yFSP5f5/z+hGVdX319e/l/X4gJRRRT/r+v61AUf0P8j/n+dBOSfqfx5JpKKhLl16a/jy+u7W3TuAUUUUot6LdfPSyXX+tfVAFFFFCWq0flpa1mvPbp3tZdgCiiitACiij/AD/n9Pzz2oAKKeE5Of8AOc/Ue/BOPr0VlXqWA68kgc89Tx34PXsKTaW7S9SuSXb/AD/r+uxHRipAgye4x+XHPbGeeOffmpUhkl80xQyS+RE883lxtIIYEZRJPNtBEcCM6K8z4jRnRCysy5YNcqvJqKuk23328n95CFGCevBOegz/AFxg/pxTWGCQO3/1qfu24AOeO+AOnH8uPUdzkENY5+nP0zk8/r7VEtUrbu9t7vuv+H7L5N8trbSX66/d89PzTH+fz/wP40lFFZEf1/X9feFLk+v+ef8AE/nSUUGilovLR9um3V26q3XorATmilAJ/Qfn0oYYOPy+lBfKt7fPzVn/AMP6+YlAOKKKabWxM1pe+3/Deq/L8yRW6A5zwOuBjI/z379iaTIzwep9Oe3Ugg49umc+1MooTs7+f63MiTAEkco4kiYPDKMLJDIp3I8UyESRSIx3I6MHU/MpGM193/AX/gpd+2v+zp9jtPAnxy8Sa74asxGieCvia5+I/hb7OhDfZbWLxG9zrei25ACbfD2t6OyqMIRxXwZQDjpXThcZisHUVXB4rEYWqrWnh6s6Um9FZuEo3T1um2mt1a6PC4i4X4Z4vwEsq4r4eyXiTLpX/wBizvLMHmeHi2kuelTxlGsqNVW92tS5KsHrGaaTX9Vf7Pf/AAcQ+Fr5bLRv2nvgpqPhi5JEdx45+D9yfEOgszYBuLzwPr9za6/pkKnc8v8AZviDxNNg7YrU4Cn9y/gH+2P+zN+05ZJdfBH4yeC/HF35KzXPhy01E6b4x05Su5/7T8Ga1Fp3iixEWdsks+lLbblPlzyD5j/nGB8Y7+uefTpz7Z+vr1qzY3t3pt/aarpl5e6XqthKk9hqmmXdxp+p2FxGcpPZahZSw3lpMhwUmgmjdSMqwNfcZX4i5zg+WnjqdHM6MbXc0sPiVFJKyrUockrbt1KE5S6z3Z/G/iH9Ajwk4pVfF8GYzNvDzNKnNKFHC1J59w9KpKzbqZXmWIjj6XNK6UcHnOGw9KLfJhWlGK/1AgwPIOR/UEgjHXt/nFOr+Fb9mr/gs1+2j+z2dP0fxB4ptPj94Fs/Libw78WnuL3xJBZoFj8rSPiPZ48SxSLGoSD/AISI+J7SEAbLIDiv6Gv2Yv8Agt1+x58en0/QPHmr337O/j28MUA0f4oT2sfhK8vJW2CHR/iPZKPDjoztiL/hJE8K3EgwI7V3IWv0jKONsizXlp/WPqOJlZfV8by0ry00p1+Z0J3b5YJzhUm9qabsfwD4nfQ98avDVYjGxyFcaZBR5pvOuD/bZpKlRjaXPjsm9jTzrCckLzxFVYGvgKFnfHSiuY/Y+iqGn6np2q2VpqemX1nqGnX9vFd2N/ZXMN1Z3lrOu+C5tbqF3hubeZCrxTQu8cqkOjMpBq/kHoc19ctUmtU9mtn6M/luSlGTjKLjOLcZRknGUZRdpRaeqcXo10ej1CiiigQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAwZ4+g6n09vUHBJxx0Az1dj0HY9+fXk5z19M00Z47ggd+OPb14yT2wcDPV2PQdj359eTnPX0zS/H8tH89V+P5Lt6b7vp66Prr8+otFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFH+frRRQB8T/t3fsXeAP23fghq3w18VLBpHizSzc658L/HiW/m6h4I8Zpb+TbXwKDz7nw/qyiPTPFWiq3l6rpL74xFqdjpd7Z/wDfFX4WePPgj8R/GPwm+J2hT+GvHfgTWrjQ/EOkz5aNLiLbJbX+n3JCrqGi6xZS22q6JqcK/Z9R0u8tLuE7JlA/00CM98f5/zg9u1fhJ/wWn/AOCfcf7Qnwul/aK+FmgtP8bvg9odzNrOm6bATe/Ej4YWBmvtV0PyIVMl94k8Ho11r/hc/Nc3dr/bXh+JLmW/0pLX89464YjmmFlmmDpr+0MJTbqxgvexeGgrtNJe9WoRTlTfxThz0vel7JR/u76F30i6nh3xFR8M+Lse1wJxVjoU8rxWJqWpcLcRYqUadKspzfLQyjN6rp0Mwi3GhhMXKhmV6FL+06mI/jLopFZWVXVgyuqurKQQyMMqwwTwR70tfhJ/s7KT1TS9fy06afmFFFFBBJyRgk9sH0Py9O+eeTn6d6QFlKsrOjqyvG6sySI6MrRyRyIweKWJwHjkQq8bqGVgwBDQSCPw/p9fQflTlIPB6H+fAH6DH40Xfe39f1/SQfrof1Kf8Epf+CwcmryeGv2Z/wBrTxPGNac2eg/Cv416/crHHrrYS103wX8StSnYLFrrfurTw940u5Fh1p/K0zxHMmrNBq2pf06xyLIoZScEkEEFWUgkFXUjKsuMENg56iv8vZ41YFWAZSCGBGQRznd67s4/P05/px/4JIf8FcH0+Xwz+yt+1V4n3Wsr2egfB34x+IbzmF2222l/Dz4j6tdOzMhBisfB3i+9l+U+R4f1+cr/AGdqCfrvBnGrk6WU5xWu/dp4PHVZXb2UaGKm93tGlXk77U6rvaof5cfS0+iDCnDM/FHwlyrlhBVcfxbwVl9G8YRV6mKzzhvC0oq0I+9WzLJqEOWEefFZdBQjUwkf6nKKijk3jJwDkjaeGHJGCDyOn9OtS1+tn+XwUUUUAFFFFABX8GH/AAWk8UWPir/go18cW0+VJ4vDWn/DPwjcSxkMov8AR/AGg3OoRZHR7e71KS1lXlklhdG5Uiv7Xv2j/j34F/Zl+Cvj/wCNvxEvktPDfgXQ7nUTbCZIr3XdXcC20Hwxo6vnz9Z8RavNZ6TpsIVl+0XSyzbLeKeSP/OQ+JXxA8SfFv4j+PPin4ymW48V/Ebxh4h8beIXQkxJqfiTVbjVLi2tt3zC0sjcrZ2SH/VWlvBEMCMCvy7xNzCjHBYHLFJOvWxDxc4JpuFGjTq0oOa6KrUqvkfX2VS2x/pF+zq4GzPE8Xca+ItWhUp5LlnD8uEsJiJxcaeMzfNsdluaYmnQla1R5dgssovFxWtL+1ME2n7RW5Tgjdntzyc5/MD6DGOfStzwt4r8UeBfENh4s8EeJvEPg3xVpUqy6Z4k8K6zf+HtdsJFYMDa6rpNxa3kQLAF0EwjcDZIrrlTz1Ffjim1OMoNxlFpxlF2aaaaas1ZprRpp7a6H+sVWjSr0quHxFOniMPXhKlWoV6cK1GrSnFxnSq06ilCpTnFuMoTTjKLaaabv++/7Jf/AAXs+OvwsGm+FP2mvDy/HjwbB5NsPGmjjTvDvxZ0u3XannXv7u18L+NvLjG7bexeHdYuW3SXfiC7lbn+jT4Cf8FH/wBjT9o3Tra5+H/xy8GWOuTxI8/gjx1qlr4C8c2LnO+CXw94nm0+XUDCciS60CXWNMPWG+lT5h/nqZ/L0/z/AE5pskccq7JY45U/uyIrrnkg4YEZBOR6V9rlHH2d5bFUsQ45nQjZKOKclXilZJRxMb1JX2vWjWtoo2R/H3if9CLwe8QK9XM8jo4rw6zqtN1K1bhqjQnkeJnJrmnX4cruGEotK/LHKMRlEHJudZVpNs/0T/iZ+39+xp8IIZ3+IH7SPwi0a6ty4k0ez8Y6d4n8RhoyNyr4Y8JvrniB3OflVNOJPB4r8vPjP/wcJ/sy+EvtNj8Gfhr8TPjNqUe9YNT1KKz+GXg6Vl+5It9rsepeK5Yi3zFW8Fwl1OFkU4Yfx5qkcYxHGka9NsaKgx6YUAf496dXVjfEnO66ccJSwmBT2lGm8RWX/b9Z+y7/APMO/U+Y4S/Z+eD2SVKeI4nzfirjWtBrnwtbF0eH8oqpb82GymCzaDf9zPEvLc/Zf43f8F0f22/ikt3p/gS78DfAbQbhZIkTwJoKa/4sED8BZvF3jNdVWK4VQALvQtA0GZW+aJoz0/J34g/En4ifFnW5PEvxT8eeMviR4gldnOs+O/EuseK9QjLEki2n1u8vTZRgn5YbMW8CABUjVQFHFUV8fjc3zLMpc2PxuJxSvzKNWpJ04t21hSSVKGu/JTj5Nux/WfBnhh4eeHdFUuCOC+HuG3ycksXl2W0Y5nXhZLlxWbVo1czxi2V8Vi6z89Xc/HPbmiiiuFSWluvd3etvXv8Aej7ptvdt+oUUUf5/z/n6U+ZXVur/AK830X/DCF4x15//AF//AFvzoOOMe/8AM+vtThtAOcE+/Tt6ZPUnp1x2ppHuDnvke+eP5f8A16odrK+mq1s7tarftf8AqwlFFOAyCcj1HPXrnjrx/n1qFaV+3/7Lt23Wv/BFa+w2lII/z7kf0NP4GeMnB5PvuPTp2wRgc5obAz/nk7/6mhRS116bvzVlt/VkluXy6Nt7NLbbb79+n3kdFKSCSff+p/8ArUlUtvSy2t0T26bkBRRRTAKKKKACiiigBytjt/8AqJH+B/E0Ficeo/8ArH09R055ptFKyve2v9IAooo/pTABzRTwRxwc8d++Qc49/wCQHTNOHY44P6E7cY+n9O1Tza2atfTXrt2v39P0BNmeR3GfTt6D357+nbmMjFT9vw9c/qev1pjr37/z6k/p/LuTTSW6S29NGaOOia9fW9tr6+iff5EdFKPw6Hr9D/n64pTk84Pf+Zzx25OOvH41OvNfXf5PSK19NbeZFt/67fdvuNpQCTgUlPQ8n8P1IB4/r+dU20tN9LfN2EBXHPUDrz3/AP1/oenekwF5JA9OnOegHPU+nI6c4PL2J4GOep6d+AOeDyf89R9pfDT4JxaX+xd+0R+1Z4mst8Evi7wR+zf8IvPiRreXxh4q1TT/ABP8TPEMW8sTcaH8P9Nk8OafLGpG/wAUayweO405GGuFoVcVKcYf8u8PiMTUm9o0sNSlWm30UnGPJBOynUnTgneSPEz/AD/BcO4XA4nGPmnmWe5Fw9l+HjJKriszz/NcLlWDpU07twpTxLxmLlGMnQwGGxeJ5JRoyR8X8D27da9v8G/Bm61z4IfGP4+a9Nc6d4K+HWoeDvAPhtogI28XfFzx3qAm03w5BK6sr2XhvwZpviTxn4gaEfaI/sWg2B8mLW/Pj8MZm25CtI3VEjVmeR+QsaKOXkdsKqKMsTgckV+5f/BSz4UwfslfsG/8E/8A9l0QrZ+K/EupeOfjr8WolUxy3nxBl8OaJaX7X2WYzto8/j668L2Er8jTPDVhH1Tjuy7BLE4bNcdVT+r5Zg+d72licVVhhcJC6dtKk54lx1jOOGdNpxm2/luPOMJ5NxB4a8F5dV5M98QuLJ4Sk425sPw5wtl9bifizFpNNWq5fgaGRRkrToVs9pYqlJVMPE/DPfwecHOSe+Dn8sY46fpX6F+Nfg8n7PP7AHgDx/4itfI+KX7bnjc3OgQzrtvPD/7N/wAKmh1yNIo3HmwS/Efx3d+DPEt1KoEN14e0jwxGhHm3qt8xfsx/BbUf2j/2gvg/8DtNMyP8SvHWjeH9SurZWaXTfDKyNqXi7V1C8g6T4VsNZ1BWPG+2Verc/qv/AMF7tf0q1/aj+D/wb8NWsGl+Evgp+zz4U0fRNEtBsstHOv61rZjsrWEfLDHB4d8P+FrWNByILWDqACOnL8GoZNm+cVY3VNUcswaauniMZKLxU+zdLL1Vgk0kniudWlCLPnuO+K5Yvxa8LPCrA1XH6+s28RuLYwdqsMg4Uozjw3hZdY0cy40nl+LnOL96GQVcJO9HF1Iy/DnnuR1zwMDGBj8Rzn36AZNJRRXz97rfXd/JpL9Hpt6bfszd3d9QoooqBBRRRQXF6JXS11v207q2lmFFFFBfMlbre39O3XysFFFFBMpaWtvbW+nR6d/l69QooooMwooooHZvW39af5hQDiij/PWrjva/9XTVtd+/p9xZ9n9xMrAj0xj6e2KjkGQVPIYMrA4IKsBlSCCORweM4PXJJpvT/P40cn9B/h/KqUVe6at27bNdfK4k7bH1t+zV+3N+1F+yZewN8F/iprWleHEnE138PPEDHxT8ONR+bMiS+EtWkktNNkmBIkv/AA7Louqjql+p5r+lP9kj/gvh8FPia+m+Ef2nfDo+BHjG4aG2Xxtp015rvwj1K6c7DJdXRjl8Q+B1lcriPWodX0e1BL3XiaJMbf49qeh5/wA/l6YPPGOfwr6LKOJ85yVwjhcVKrhof8weJvWw9tLxhGUlOjezbdCpSu7XUlo/wfxV+jb4SeL9PEV+I+HKOXcQ1ovk4t4eVLKs+jVa92pi6tOlPC5ul8PJm+Fx3JC8aDoytNf6eXh7xHoPizRtO8ReGdZ0rxD4f1i1jvtJ1zRNQtNU0jVLKUborzTtSsZp7O+tJV5jubWaWF/4WODjbr/PJ/ZG/b5/aQ/Yw1uK4+E/jBr3wVPdi6174UeLmudX+HutbnVrmW30zzo5/DOrToCBrnhufTr0tj7aL6BWt3/sj/YK/wCCkHwa/br8PXlr4biufBHxc8NabFqHjX4Wa7cR3Oo2Nm00do2v+G9UiigtvE/hZ72aK3/tCGG0v9Onnt7bWdMsHubKS8/YeHuMsuzxww8l9SzBrXC1ZpxqtK7+rVrRVWy1dKShWSu1TnCLmf5N+O/0SvEDwXp4nPqMo8XcCU6sUuJctoSo4jLIVakadGHEGVudarl7lUnGlHGUKuLy2dSVKFTFYfEV6eFP0Tooor7A/lMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBgzx0IwO/HHt655J7AYHI5dj0HY9+fXk5z19M00Z44yMDvxx7eucEnt0HPV2MdB685/Hk9eT6Zpfj+Wj+eq/H8kuny13fT1366vvfstFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABUM8InQxksoJBLL1GOe/Y4AI6EHmpqKAP4dP+Cx37DP8Awyp8fT8SvAWjGz+B/wAddQ1TW9Ct7KAR6b4I+ICs1/4t8DxrEqwWWm3zSt4n8J2yrHEunXOq6PYRmHw5Ix/Hqv8ARe/bY/Zf8N/td/s5fEP4Ka99ntr7XtN/tHwXr06F28LeP9HEl54S8RIUVpUhttRAstWW32y3ug3+raeTsvHx/ngeLPCniPwF4r8TeBvGOlXGg+LvB2v6t4X8T6JdjFxpWv6FfT6bqljJy27yLu2lVJASk0e2aJnjkRj/AD/x1kH9kZp9Zw8OXA5i51qSirRoV4tPEUNNFHmnGrSWiUKns4pqk2/9xvoZ+NtTxV8OP9X89xbr8Z8AxwuVZjVrVObE5tkc6bhkmcTcm51q6pUamXZjVbqTnisJHGYmcamY04mBRQOSB60f5/z+dfDn9hBRRRQA8Of6Y6Dt6cjv+lMZVkVo3USJIpRkYAqyuMMp+oyD1znOBRRTX4X9bef+a6/cNOzTXR3+4/pK/wCCXn/BZqL4d6VoP7PH7YPiC9uPCWnR2ukfDj45agbjULnw5p8QEFj4V+J8wE19d6JYxiO30TxsFubzS7VUsfEiT2EMer2X9VXh3xL4e8XaLp3iPwtrmkeJPD+r20d7pOuaFqNnq2j6nZzDdFdafqenzXFle20g+5PbTSRtg4PWv8wuvTPh/wDGv4z/AAkEq/Cr4u/FD4aRzuZZ7fwF4+8U+E7OeUkMZLiw0TVbKynkZgCXmt5HJ6nGa/Rcg8QcbluHhg8ww8sxoUoqFGtGqqeKpwjZKnOUoyjXjFWUHNwqRW85xSUf4O8a/oK8K+Ied4rivgLO6PAecZlWniM3yiplrxvDmPxdWXNWxuEpYavhq+TYivNyq4qFCGLwdao+ejgsLOVarW/0w8j1/r6D+oqpeahZafA91fXdvZ20YLSXF1NHbwIBjJeWZkjQDOSWYYGSa/zh9R/bG/a51dGi1P8Aak/aKvYmUo8Uvxl+ISRupGDuSHxBCGBAHBGOAMeviviDxl4y8XStP4t8X+LfFUzklpfE/inXvEMjE5zubWNQvick5OSfXrXu1fFCgl+5yavN2etTFwgk/wDtyhVuvO6PxnLv2bmfVJr+1vFbJ8JTuuZ5dwtjsxm1pdL6znGVpPezd1tp0f8Aok/EH9tr9kf4WCf/AIT79o/4LeG57cMZdPu/iJ4audYG3buVdC06/vNZkfkgRx2LyMVICkkCvzr+NH/Ben9ir4eWt1D8Nz49+O+vRqwtbfwh4au/DHhp5l6C78UeO4dBkigYgj7RpWia6wVtyQPgA/xSpFFF/qoo4s9fLjSP1/uAepqQnPXOf8+v+efwrxMX4mZvWUo4XCYPBp6KbVTE1Y+ac5QpNrzoyXkfsHDH7PHwoyqpRxHE/E/F3FcqTjKeEpTwPD+WYizjzQrUsJRxmZxhLVf7PnFCaW072kfoB+3Z/wAFGfjf+3f4g05PGUdl4H+Fvhi+l1Dwd8J/Dl5dXekWOoPHJbr4g8T6rcR2s3izxQlrLLa2+oT2Wn6dplvPdRaNpGnte38t3+fuAPx/z/n/AOtS0V8DjcbiswxFTF42vPEYiq051Kju3ZJJJK0YRiklGEFGEUkoxSSR/bHCvCfDvBOQ4DhfhLJsHkOQZZBwweXYKEo0oc8nOrWq1Kkp18Via9Ryq4jF4mrWxWIqylVr1qlSUpsooorlPpOSPb8woo/z/n/P6UuRk575PvnnHoOuD/nFBMor02+7RX/z23Eopcn065P8+enbPrxj8k+lNxa6Pv8AL+u5mFFFFK77jvpbftvptotdPu/AKKKKBBRRRRv6jja+vl+a/S4UUUUBJK+m2lvuT9eoUoHGf8OmGz+WP88UlKD29j/Jv6mmrX1/rX/K4Kzeug4Z5HXBIH5NS456jk9v+B575/X1HakBHOeOSfXJIbvx2PHPOOOtPJx6E89D78f/AF/TBrWNrL0V/uX/AAC4pNa9/XTSya67W26aDdnqQCQeB65/ljrTSpHqeP1zjHrjpj1+nR+8fy9uMD1x6n/6wpGJI6enTPcKcfjnv6etUJqNnZq6tbfy+Tb/AK6sjopce/5+vGfyzSUEBRRRQAAZ4FO29cg4/wDrjJycDHXH5n1p6gfjj+QU/nn0pH7AfTr2+U/h+P8AhQXypRu9fR97W6ef5DACSP8APr/gaNp/z+PH6f0pykD/ABPQHnHPbj8etKxAyO57e3PX0wT0GfToaASXLdvW/p2/Tt32bQwDJA+nTGewP+P64pwxkd84H5bc8n6dPyGCKbgjkfpz6/y259KkxwO+Dk4zyVBGOntjP5dRSav/AF/W1iUr7b/52t+rb22GY5JJA79cHsePr2IBpAT0z7+vTkfyH0+lO2nnJOBn8cZ+uOg6+3tTm6+5GB+eDx34P6Ux8ul3pb1u/wCun5pagueBn29+re/HA96U9xnAIxz24b/631pMcEnqATx77se/c/p6HKMc55HTgcc/eHHHt/QHkGgu7Ufu+5JX3ffTTvsIT146/wA889cHgHHTP5ZppOTn+f8An9O1KTx/n0X+opoHT3OKDNu/XTTyV+uit1uFOViO+Aevt70mDx05Pf8AA8+3NAwD6jj8+Cf6j39aT9L/AK/oIWRwiPI5AEauzED+FF3Hk46H05zjB71/Q3/wUP8AheP2dv8AgkP+wP8AB4WyWera98QdF+IfjKMR+VNN4t8SfDnx5411xLwkBpJtP1PxgdMVnyUt9NtoshYkr8F/hv4dXxl8Rfh74Pdd6eLvH3gzws6AEl4vEXibS9HlTAxwyXrDoc8/Kelf1X/8HFWiLD+zX+zneWkIhsNG+N8mkrHGu2KBL74beLBaxKBwqqmmFEHACrgdK+s4fwqeQ8WY1L95TwWEwdN2vaFfExqYnfo1QpP0WqP5W8buJJ0vG76L3Brm1g8x4w4m4nxtNyajLGZJw9PA5FKyfvONfOMw5U017Tke8UfzqfsE/CuH41/tn/s1fDa8tvt2k6v8VvD2sa9aMoZLjw54LM/jfX4JlwR5FzpXhy7tZAwKFZ9rD5q/Vb/g4z1Saf8AaS/Z70NmPkab8D9a1WND0WXW/Ht/aTMB2Z08PwKTjkIBzgCvnv8A4ISeHYtc/wCCg3hrUpIw/wDwh/wm+KHiOBiAfLnubLSfCayAn7p8jxPcxg8H5yO9e+f8HGFjLH+1B8A9TKnyL74DahYxORwZdL+IWuXEyg+qprMBb0DLnrXVg8Oqfh9m2IS9/FZrhozdrP2VCWEVOL02VWdR3vu33R85xHn0sw+nT4YZBObeH4e8LOI8ThqTbahmmd4TiKeNqQW0ZVMuwmXwm7Xaoq7skch/wb6fC6Dxb+1/44+JF5b+db/CH4PX7afMy5W18S/ELWLPw9ZShuQkh8OWHi6EY+by55ADtJr5u/4LR6zLrH/BSD47pIcpoth8LtDt1Jz5cNt8MvCl6yj2NzqFxJ2+aRjX6x/8G33hqKLwP+1Z4xMQM2peOPhp4UjmwNwg8PeHNe1iWENydpk8VRuwBGSFJFfkz/wWi0mXSf8AgpD8e2kUhNXs/hdrduxBAeG6+GHhO1LLnqBcWM8ZI/iRh1BrfH4d0PDrKZRVnis3liK1vtNrH0qbfd+zo0ktHseVwZnyzz6e/inQr1OaHDnhLhshyqMnf2dOliOA8yxlOF37rePzXMZ2S2qTfVt/l3S8+/t+n9MfpSUV+eRTbX9afqf3CFFFIzKjRq7pG0rBIldwrSOxUKqKfmYksMBQSc8A1o4x22em1/Jf1u9bsBaK+ofhN+xR+1x8cTayfC39nP4teKNPvGVYNek8J3nhnwq4cjEg8W+L/wCwPDbR4JbdHqb/ACgkAgV+mPwr/wCDf/8AbJ8ZLa3XxH8U/CL4O2Um1rizvNc1Px/4ntlO3f8A8SvwtYxeHJZFGQUTxmFLYXfXp4TIM5x9ng8sxlaMrWqOlKnSd7f8vaqhStr/AD+d+/5fxZ42eEfA7qQ4q8ReFMqxNK/tMv8A7Vw+OzWFtHzZRl0sXmm+ithHd6LXQ/C2lCnrjjrzx/UcV/XD8M/+DdL4G6QIJ/i58fPil46uF8tp7DwVpHhj4c6RKw+/EWvYPHOstEx6PDqlnLtJwUbBX7++HX/BH/8A4J6fDcW0tr+z1oXjG/tsf8TH4l6z4m+IEk7AAb5tN8Saxe+H9xIBIh0eKPOdqKMAfT4Tw54gr2dd4LBJrVVq/tqi9I4eFaDfe9ReTP524k+n14F5M6lPJocXcXVY3VOpleSQy7Aza1XNWz/F5Vi4Qb05oYCq1dtRZ/BBADdTpa2oa6upSFjtbVWubqQkgAR28AkmckkAKiFiT0r6I8D/ALIX7VvxLSKXwF+zX8c/E9tNtMWoWPww8WwaS6uAVkGs6jpdjpIjYHIc3oTAJ3Yr/Q48D/BT4QfDKGO3+HHwu+HvgG3iTy0h8GeCvDPhlAmMbSdG0uycj1JfJIBJzzXpwUKMAY/M/qea+gw/hdT0eLzectrww2EjC1raKpVq1L9r+yXofhmfftIMdLmp8L+FeDoKN/Z4rP8AiWvjObXeeAy7K8DyeajmU/KXU/gv8G/8Ebf+CivjKOGcfASPwlazKpE/jn4g+ANBePOOZtPtvEGq6vGeuUbTvMGDlM4r6f8ACf8Awb3/ALZGspHJ4n+IXwC8HIwBeFfEHjbxRew5PKmLTvBNhYuw54TUtnORIQRX9mVFe1Q8N+Hqdvayx+Ja39piYwT26UKVFr/wK/mfkWcfT/8AHbMXJZfQ4I4fg2+T+zuH8TiqsIvZOec5rmlOUl1fsYpvXlVrH8qHhv8A4NwvF0ojbxd+1foFi2MzQ+Gfg/qep/URXOsePdLDcggM1mmeDtAOK9h0j/g3E+FUbQnXv2nvilqCrzONG8D+CtDEp44iN/ceImhHB4cTHnr6/wBJ1FenT4H4XppWyuE33qYnGVG/VSxDX4H57j/pk/SQzCTc/Eivhov/AJd4Dh3hPBRitNIzo5FGtpaycqsn531PwB03/g3b/ZKgC/2n8Xv2i9SYBSfL1/4d6cpYY3YWD4cysqtjO0OcdA3JrrIP+DfD9h2NQJvFf7RNy2Bl3+InhqLJ4z8tv4AiXB/TtX7pUV1x4T4bjtk2Cf8Aipc+3+NyPmK30nfpAV25T8WOL4t62oY+GFj/AOA4ajRivkj8N2/4N9v2FGGF179oVDjG5fiXopPbnD+B2TP/AAGse8/4N5/2KplIs/H/AO0fYNjhl8c+CrrH4Xfw2kyOnBJ6da/eCvEfjz+0b8Ff2ZfA938Q/jf8QNC8B+G7cSJaNqlwX1bXb2NQy6T4Z0K2WfWPEeryhlKado9leXKIwnnSK2WSdJq8NcMUqc6tbKsspUqcXKdSdKnShCK3lKbcVGKtq20kdGVfSF+kbmePwmW5P4leIGaZnja8MPgsvweNxeY4vF4io0qdDDYOFOvVr1ZtJRpU6c5Se0WfihrH/Bun+zU6u2kfHz486ZhSwbUF+HerxoqjO5xH4P0tm2jqfMQnOc4zX84/7Zfwi/Zu+BnxRm+Gv7PHxx8TfHxPD015ZeOPF1/oWgad4SstYgkjjTRfC2taLeTJ4qubKRbqPWtTtrWHRbedI7TTrzUpUvWtfuz/AIKF/wDBZb4q/tUx6z8LPgjDrXwc+Al2Z7HU5BdrafEr4lae26No/E2o6bcSx+GfDd5F/rPCei3k817DI8WvaxqFtJ/Zlv8AinawSSzW9raQSzzzzQ2lraWsMk89xcXEiw21pa20CPLNcTyOkNvbwxtLNIyRRIzsqn8i4mx/Dk5PB5BldCLUl7TMF7eHNa3uYak6ijyNrllVq025K6pQStUl/q99HLgn6QGCwsOKvHHxGzXEzr4aUsv4CnTySrHB0qtKSWM4mzSjl8q6xcIy56GWZfjIww01Gpj8XWre1y+hoQxyTyxQQRS3E9xLFbwQW8bzXFxPM6xQ29vDEGkmuJ5XSKGCNWkmldI40Z2VT/bf/wAEc/2BL/8AZK+D2ofE34naX9i+O3xqs9Nu9b0u5jUXfw/8C24+2+H/AAPLkuYdZnnmbW/FqIyqupSWGkSoz6As8vyZ/wAEkv8AgkddfDm58OftR/tT+GxD4/i8jWPhR8JNZt1kPgR2US2fjLxvZSho/wDhNwhWXQ9BlDL4SBW8vwfEmyHRv6SQMcCvtOB+E6mBcc5zKnyYqdNrB4aaanhqdSNpVq0WrxrVItxhSdnRpym6l6k1Gh/IH0z/AKUOA4vhifCLw7zCGM4cw+LpvjHiHC1FLDZ5jcFWjVo5LldWLca+U4LFU4YjGY6EpU8wxlChTws5YLDzrY8ooor9MP8AOIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBgzx0PA7+nt65wSew4HPV2PQdj359eTnPX0zTRnjjIwO/HHt65wSe3IHPV2MdB685/Hk9eT6Zpf1+Pz17bX7Lou3/Dvp679dfO/ZaKKKYwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBjqHUqQSGBU8kcEEdQQR9Rz6da/kL/4L9/skJ4B+KXhD9rDwjpgt/DvxZeDwT8TFtYdtvafEjQtOd/DWvXGwCKNvGHhSwmsJ243ah4UNxO7XeqEv/XvXyJ+3V+zpZ/tT/sr/GL4MSQRSa14k8KXV94JuZQudO+IHhsjX/BV4kjAtAra9YWdjeyR4aTTbu8gbMcrg/P8UZRHOsmxeEUebEQg8Rg2viWKoxlKEU+ntoudCT1tGq3ZtI/dPo4+KNbwj8XOF+J54iVLJMViY5DxTT5mqVTh7NqtKhjK1WKa53llVYfN6MU05V8vpQb5JST/AM6oHkex9s9vX+tB/wAj+fc1LPb3NpPNa3trNZXltNNbXdlcKUns7u2le3urSdGJeO4t7mKaKeN8OkispVcYEVfzO1Ztf8A/6E01JKSaaaTTTUk01dNNNppp3TTaYUUUUJXdu4wopsjxxDdLJHGvq7qo/MnHp+YrX0TQde8TXCWvhnQdd8TXMhCx2/hzRNU164cnGAkOlWl3I5ORgKpJ7CrUOZqMW5N7JK76dLpvdbJ9iak4UacqtacKVKCvOpUnGFOK7ynJqMVbVttJLcyqP8/5P+cV9UeEf2Gv2zfHiwyeFP2V/j5qVvOAYr26+GXibQNPcHbg/wBoeJLLR7FVO7IdrgKQGOcDNfSvhn/gjX/wUZ8UJFKP2fl8OQyruEni74ifDfRmj+6cS2kXijUL9DzyptNwI5GcCvTw+S5vXs6GWZjWi9nTwdeUXdJ/EqbjZ7XT6b2Phc08WPC3IJTjnXiVwHlc4XU6OO4uyDDV1KNrx+r1cfGs5brlVPm02PzBIJzz+nt9eaWv2t0D/ggZ+3hqwjOq3XwI8LblBddW+JGuX0sRzyrJ4f8ABGqxO2AeEuGXgDdya9g0n/g3X/aauURta+PPwJ0piAXj06w8f65sJ6qHuNH0EORg4wo3fLwM16MOE+Javw5NildW/e+zpa/9xakLW119Nj4bG/Sl+j3l7ccR4rcMTa64GeOzWPTaWV4LGRas73TZ/PlR+P8Aj/h+tf0mab/wbh/EuTB1f9qrwNagAbhpnwo8QX/zcblVrrxzp4IHOGKg9MgZ57qw/wCDbg8nVP2v5MnHGnfBGJQOmRm6+J0nvj5fTpW0eBeKZf8AMrcb/wA2LwK/92fz8z5/EfTL+jVh9H4lUqz/AOofhbjSsraaXhw64/8Ak3e5/Lz/AJ/z/nPbrRX9UsP/AAbc+FAD9o/a58Uu3GPI+D+iRLnvkS+OpyR7Z/HtVk/8G3ngrHy/tbeMwcdW+E3hwjPrgeLlOPbPc888a/6g8Uf9AFP/AMLcH/8ALzzZfTb+jZF2XHeLku64Q4xS6d8iT69uh/KmPfp79+D+vIx35yO9BI9vrz26cE4HHbnH8v6nJ/8Ag260DB+y/tfeIFIHyC5+DGkyKG55byviHDkfTBHbHSuevf8Ag26vgM6f+1/A5CkAX3wPYZOOPmt/inwM9TtJ61L4D4pj/wAy2Mt9sZgW+mqviV8te67o3p/TU+jXVaX/ABEOpSv1q8JcaxS1W7jw9Jarqnpr2P5gv1oz/wDq/wA/Wv6Q9R/4NxfipCHOl/tUfD262nCjUfhX4msNx5wGa18aaltyB1VWx1rhNR/4N2P2n4RIdK+O/wABNQIz5a31n8Q9GLkc4Jh0HW1jJ6dXAzWL4L4og7vKartr7tbCT7Xty4iXytdnq4f6W/0csVy+z8Usqi5aL6zlHE+Etto3i8koxjve7aS6tH8+9FfttrX/AAQF/br0wM2m6z+z54iCjIXT/iN4msZXGegXWfh7YRqccndKADxk9vJda/4Inf8ABRnR1d7f4P8AhXxGqDP/ABTvxa+Hkjvzj5Itb1vQpWJ54CducHisJ8NcQ0/jybH/APbmHqVe3/PuM+/Rs+mwX0ifArH8v1fxZ4EjzWssZxFl+XO76NZhWwrj/wBvJH5R0V96+IP+CXf/AAUG8NFxqP7J/wAUboJnL+Hz4T8VKcd0Xw14n1WWQemxGJwcDpXh/ib9kj9qrwcGbxT+zL+0DoEaA75tQ+D3j8WyhfvMbu30Ge12ju3nFcZIOCK82pluYUHetl2Oo73dXC14JXa6yppKyeux9pl/iJ4fZu4RynjzgzNZTtyRy3inI8dKV9ko4bHVZNvokmfPVFaOq6PrGgyvBr2j6xoM0fEkWt6VqOkSxngEPHqVtbOhyejKDnIA7VlRzQzcwzQy8Z/dyxyf+gsf/wBfFcc0r2fuyXRp33X2Xru7bd1bt9jBxq01VpSjUpyV1UpyU4NPVNSi3F3Wqs2SUU4qw6qw4zyCOPXkdKbUWs1rZ+jWl13S/wAtATtqmFFFFaro3+C7266/fs9+huujf4Lvbrr9+z36BRRRSgmlr37WMApc855/P/63X37nmkoGMjPTPP0qv1AXGSB9P6f5/U96kK8cAD15+nf8/Ud+TilA/EHBHpwBjr0Pp/PinVF29Vbbv6dL6dd77aWuBHs69uB378f1z+mKjIx/n1qxwPb/ADj/AOtTCBnPckfzX8ex/M/iKd9Gtf8Ag/19w9LLTXq+/wDX9eUVOC//AKv++f8A4qk4B/L3x0J+vcYp+Rxz0xx/3zk/Xjpk/oaq/k9fL0+759mCt1/D1X6XFUdPpxk+y9PbPtTWB5J9sfXjPv0B6+lSDHbHpx9B7fT8vwEbnJx6Z/p/9emaO3Jv2/RfPbr+mjKKKKDIcDwf0/I/yzk8H8KfnIJ6dv14PX34Jx69DUYI7++PYnHPb+dBOf8AP+R0wOMdqClKyfVP5NOy19P8uhIuSCT0P5459sntj26elI3foRge3J4yO/b16UgbAHU4zj6Y+h9Pw+maGOT/AE7+3JAPfp/jQU2uW17vR697+ejt27feOIHPPQY5+jDAPtn/ACc1G3U/U5+uT+n+fSg8nr69sevXA6mkOe/60tb+X/Df1bfQltPZWX9f5IO/+R+H0o6UUUyQyfy/+t/gKP8AP50c/wD6/wD6/FFAHuv7Lrwx/tN/s4PckLbp8ffg20xbG0Rj4jeGi27PGMDnPbNf19/8F5/AVx4w/wCCf2va/aQGaT4XfFD4aeO5mRdzQ2Fxqtx4EvpcgZWOODxt50p4ASMs3Cmv4svCPiCfwf4r8K+Lrc7bjwn4o8O+KIT6S+HdYstYQjAJPzWYxjH1r/Rr/aA+GOi/tM/s0/FD4X+ZBPpfxg+Feu6LpF7JhoYLrxFoUkvhrVwwyp/s/VJNM1SJx0a2RwRjNfpPA+HWY5JxVl0Le1r0aapq/wBuph8TCjL09rTTf/BP86fpl55PgTxm+jT4hV+ZZZkuc46tjZJNr6pleecNYnNaen262W42rCK3dna6i0v5Nv8Ag3yMY/bi8VlwN7fs8+NxCDjIb/hM/huXxnuEznHOBzjkV9mf8HIHw+lk0j9lf4rwQMYdO1n4i/DnVbgL8qPrun+HvFGhxuw6Fh4Z8QbAx+8TjknHwn/wQwbU/BP/AAUUXwjr9pNpevSfC/4v+DNY025Ux3Flrvh690K+1PT5kYBkns7vw3fQSoRkNAx7E1/Rf/wWB+Ad38fv2EPi3p2i2MmoeK/hnHp/xl8LW0Mfm3E918P3nvdftLZQDI1zf+CbrxTY20UYLzXU8EQVi1dWRYWWYeHma4WEW6tOvi6kYWak6uGeGxap8r15p8igo9ea3U+a8X+KqHAn08fDTifF4iFLK8dlPC+BrYvnj9WhlnEtDO+Fq2MlUT5HhcM8ZUxc6ibioUHNXsfE/wDwboWkcf7LfxuvFA826/aFvYpDxkpafDjwB5YPfjz3wPcn1x+cP/Bwr8O5fDX7X/w5+IcUJSw+JvwW060kn24SXXPAXiTWtOv03dGkj0fXPDZPcIyDhQK/Qn/g3F1dLr9nH9oHSFdGOn/HS11D5SCfL1f4d+E44344CyHTHIPIODg8Gv2Z+PH7I37O/wC05qvgLWPjt8MdD+JNx8NLjWrrwhbeIJdSfS7GXxAumJqq32kWt9a6brltcjR9PY2OuW2o2KSW6yJbByzH1sLk88/4DyzA0KlKlWcKVSlOrzeyjOli6karlyxnK7puso2XxNJ2V2vzHiPxXwvgf9NzxG4zzrBZjmOUwxea5bmeByyOHePxGFzPhnL62XQoLF4jDUOWGY0sqq1nUrx5MNTqThGrUjClP/O9+G3wo+KXxk1lfD3wk+G/jn4l62WRG07wL4X1jxNNb7yAHvpNLs7m306EE/NcX81tAigu8iqCR+sfwW/4IR/tvfE5bPUPHlr4D+A+i3ASRz438RJ4j8VCBsEtD4W8EDV7UTqAd1pq/iTRplbariM7sf2ieD/Avg34f6LaeG/A3hXw74O8PaegSw0Lwtomm+HtGskUYC2umaTbWlnCD32QjPfPOerrPL/DTLaPLPMsZiMbUVm6dFLC0G+qbTqV5JdHGrSfkjr45/aG+IWbSrYfgPhbIeEcLJtUsfmk6vEucxirctSn7SGAymhN2vKjWy7MIQfuxqzS5n/Pz8Gf+Den9mbwmtpffGr4k/Ev4yapEY5LnTNKntPhj4NnYbS8RsdDfU/FzxZGM/8ACaQb16xLuK1+rXwe/Yd/ZL+AYt3+E37P/wAL/CV/a7fJ8QR+FbDWPFu5PuSSeMPEK6v4nlkHBLvqpJYBuMCvqyivtMDkGTZbyvB5bhaM47VXTVWurf8AT+r7St0X2z+SOMvG7xb4/dWPFviDxNmuGrNueWrMamX5P726jkuWLBZTFW0XLg07aXsMCKABjOABzznAxnB4zyelPoor1z8sCivPPiX8WPht8G/DF541+Kvjnwp8PPCNgD9s8R+Mde03w9pMUm3etut1qU8CT3coB8izt/Nu7hlMdvBLIQh/EP8AaA/4OFf2Uvh/Ne6J8EPCfjH4+6zA0kKa3G6/Dn4fGRcgPFrniOxuvFF/EHxl7HwTLaXCZ8i/IIceVmWd5TlEebMcfh8M2rxpznzV5rvDD01OvNLq4U5JdWfo3AXhH4l+J+IdDgPgzPOI4wqKlWxuEwvscpwtR2tTxmdY2eGynBzad1DE42lOSvyxkfv/AEV/Ej8Vf+C+/wC2v49ee1+H8vwk+CemSF0gHhbw0njLxJHC/CifW/Ht3qekvMoIHnWvhOxw3zIqcivgDxz+3X+2V8TJJ38Y/tT/ABw1aK43mWy074ia34Y0g7ydypovg640HSY4znAjjs0QDAwFAA+MxXibktJuOEw2NxjV/ecYYem9tnUlKrbzlRj6H9bcN/s8PF/MadOvxLn/AAfwrTny8+FWJx2eZlSb+JTpYHCUsrk46a0s4qRb05luf6Ms93aWqhrq5t7ZT0aeaOFT05DSMoI565/kawj4z8HqSp8VeHAwJUqdb0wNuGAVKm5BBBIGD3IFf5lOp+JPEuvTtda74l8R67cv9+41rX9Y1idg2S2+bUr65kYtyGJY9MHmsUQQZz5MXXOTGvJPckDOfevLl4pe97mS+7fTnx+vS22Et3vrZd9z9Mw37NqLh/tfjE1Vsrxw/Ad4Rbsrc9Xi+Mpq70fJG/ZH+oPZ6np2oIJLG+s71CA2+1uYbhcHGDuhd1xz1ziruR6j8xX+YTpet63osyXOia5rWi3MZBjuNF1jU9JmjI+6Um0+6tpEYdQVYEHB9K+lvA37cX7Y/wANhDH4L/ag+Oek20GPK0+6+Iuv+I9KQLwF/sjxVc67phUAABfsm0DjGOK6KHihhpNLEZRXpp2vKjiqdZ69VGdKgrf9vnjZv+ze4gowk8h8VMmx9XXlpZxwzjsnp9LKWIwWbZ7Pd2vHDP07/wCi+XUd/wAufT/EfmPWvmj48/tjfsz/ALM2ny3vxs+MngjwNcpEZYPD17qqah4x1FdpZV0vwXoy6j4p1EyH5UktNJlgUkGWWNMsP4XPHP8AwUZ/bq+Imltonin9qf4uy6U8L289poGuWvggXUMnDxXtx4H0/wAOXl6jL8jLc3EilcgggkV8X3M9xe3dxf3lxcXuoXkrTXmoXs815f3kz5Ly3V7cvLdXMrk5aSeWRmJOSTUY7xOp2cMtyybm0v3mNqRjGDdv+XOHc3NK/wDz/p7edjs4M/Zy4+WJhV8QfETBU8JCa9pl/BmAxGJxGIhdXUc3zulg6eClbq8kx0XfRq13/Tl+1J/wcLXl3FqHhn9kH4aS2JdZrZPit8XLWEyxhgFF54c+HOn3UqGRTmW1u/FWsmPG0Xnhd/mSv51fi78Zvix8fPGF34/+MvxB8T/EbxfeB4/7X8Sai939htWcuNN0XT4xFpegaTGx/c6Vollp+nxAfu7cHJqD4W/B/wCK3xv8SxeD/g98OvGPxM8SytGG0nwboV7rT2SO2Bcard20X9n6LZLnMuoazd2FlCgLzXCKpI/oL/ZI/wCDfjxhrsumeLv2xPGkfhDSMxXLfCP4aajbal4oul5b7J4q8diK40bRUyAtzaeFINbuJYmZYPEWnTrvHyl+K+Mqyj+/r0FO+yw+XYdq29uWk5RTet6+IaulzPQ/pyNH6Mn0R8qnVi8myPOqmF5XKVT/AFh8Q87i4p8kI3rZhQwuJko88aUcsyCFW0qn1dWkfgf8Df2e/jH+0n45tPh18EvAWt+PPFF0YnuotNiEWk6DZyP5bat4n1268rSPDujwlsvf6pdW6uR5NqtxcvHBJ/YZ/wAE6v8Agj38LP2Sv7G+K3xZn0r4t/tDQxrc2WqNaNJ4G+Gd06YeLwHpt9Es1/rcOTG/jfVoI9S6jRNP0GNrg3f6hfBT4AfBz9nXwXZ/D/4LfD7w78PvCtmyytYaFZ+VcaldhAh1LXtUnefVfEGrSKNsuq61e31/KoCvcFVUD2Kv0nhzgfA5NKGLxco47MYtShNxaw+GlZO9CnLWdRSV1Xqrm0jKnToyvf8Az58fPpmcZ+K9HGcL8JUcTwRwJX56OKw9LEqfEXEWHl7soZ1j6DUMJgq0V+8yjL5ypTjOdHHY7MaLhCmgG0ADJwAMk5PHqTyTS0UV9yfxcFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMBPy8DkDv6e3qDyT2HA56ux6Dse/Pryc56+maaM8cZyB39Pb1BwSe3QZPV2MdB685/Hk9eT6Zpfj+Wj+eq/H8ktl6LXr09d+uv/AAFooopjCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACop1LxMq53cFcdcqQw6Z64x75weDUtFAH+fR/wAFRPhLa/Bb9vT9o3wnp0AtdG1rxlD8SdEhRPKgjsfihpdn41uoLWMbVW1s9d1bWrCFURY0W12DJQmvgav2W/4L0tbH/goDqK24QSR/BP4WLesmMm5N14vdDJgH5xaG1AJYkxiPjGK/Gjvj2H9f8K/mLiDDQoZ7m1GlZU4Y/Fcq6Ri602oJLpBPlS6JH/Rv4GZrjOIPBnwtzfMJynjsZwJwzLFVZ3c69anlOGo1MRNvVzxE6bryberqX33WiiivFVrq+x+oneeCviR4u+HtwbzwjeaLp140yzi71HwT4H8U3cUiDCm3ufFvhvXZbZRgHyrZoY2bllZua+stD/4KZft3eG7SPTvDv7SPizRLCFVWKy0nwz8NtNs4lUABY7Wz8FQwqq4AwqAADA4xXwmnX8v5jP6VNXdRzDH4T3cLjcZh07K1DF4iintvGlUhH/g67nzWc8FcF8RzVXiHg/hXP6qs1Vzvh7KM1qXSSTVTH4SvJOySunsrH6J2v/BWb/gopaEGP9qLxfKQBxdeF/htdKcEEZE/gp89OSeeozgmut07/gsx/wAFH9OK4/aEjvguPl1P4YfCe7DYx95l8FwuenOHBOT68fl/XtfwP/Zw+Ov7SfiC+8M/Ar4XeKviXq2lQQXOsLoFrbx6bocF07R2s2u69qdzp+g6Mt00cotF1LUrV7wwzC1WUxOB2UM64iq1YUcNmmcVa1RqMKVHGYypUqO10owjUlKTsr2Sel+h8VnHhR4FZdgMTmef+G/hNluV4OCqYzMc14S4RwGBwtPmjTVTE4zE4CjRoU+eUI81SrCPPKMb3kk/0I0//guP/wAFFLJla4+JHw+1cKcldS+EnhRFf2b+x10hgOmdrL3xg16Xo/8AwX//AG6dO2DUdC/Z818JgP8Abvh/4tsHkx1y+lfEW2RScc7YgOTgDFed6B/wQ2/4KEa1Zx3d94I+G3hR5IxJ9g8S/FPQjfx5ONkqeGrfxLaRyDuv2xtvQkMCta9x/wAEIv2/YlJi0v4MXRAzsg+KhR+3GbnwzbJn6uB2Lc179N+IcbSh/rE76r2ixE/T3aqk9ezj66n4dj6f0Ea9SVDEvwHhJS5JPAzyLCU7qyfJicsnRptaaShVs909NPftI/4OLv2lLcr/AG/8APgdqyjAb+yNZ8eeH2Y99pvL/wATBc/7rgE98YPsegf8HImor5a+Kv2RrSbgeZN4c+NEkZzxlkt9W+G2MdSFN36Df1I/OrU/+CJP/BRbT0leD4R+D9ZCAsBpHxc8AF3xnOxNV1fSSehwDtyRjGcCvnf4if8ABNr9u74WWtxqHi/9lz4pnTrSN5rnUPCWm6f8RLSCGMbpJp2+H2peJ5oIEUZeWaCJEGSzAAZ1ec+IWDTnVjm8YR1brZVCpBJbtylg5pLTds86l4T/AEEOKqscNltTwwxOLrNRpYfKfE3GYLF1JyaUY0sJhOLaE5zbdlCNCTbdlG6sf0EeGP8Ag4z/AGf7zyx4x/Z6+Nfh4sf3r6DqfgHxZDFzzta71/wrPIMZwBbqSO2TX0N4Y/4L2/sBa8YV1bVvi74KaUhXPiX4W6pdpbk4yZZPB174sTaDn5oy+QpIXkZ/iWuI5LW4uLS4iltru0me3u7S4je3urS5iYpLb3VvMqTW9xE67ZYZkWSM8SIvIEYxnIY89iff0PvwKih4h8SQfv1MHXs7ONbCRi91/wA+JUPO9rfJ6HqZl9Az6P2YxcsJgOLMjU43g8q4nq1klJJxlF53hc55lrdczldO5/f94U/4Kzf8E7vGMkUOm/tSeANMmlwBF4vt/E3gbYTjiSXxloGh2yYJwS04Uc5Iwa+qvB37SX7PfxDER8BfHL4ReMzPtMUfhf4keDdcmfdjaBBputXM4Y5GEMYfPG3PFf5rWT0ycemaha3t3be8EDOMbXaGNnBz1DFCQR1zkHPOa9Oj4n5jF2xOWYKrrZ+xqV6D/wDJ3iFf5H5nnH7OXgKvzrIfEXi7K3ry/wBsZdk2eJPZXWChw85K+/vJ26n+ohFNFMiyROro6h0dSGRlIyGVxlWGOhBIPUZHNS1/mceC/jN8Y/hvNHP8O/i78U/AcsRBj/4Q34h+L/DUalTlf3GkazZ25AIHyNEUxxtxxX2R4C/4Kzf8FDPh35Kab+0z4t8Q2sWB9j+IWieD/H6SqB92a/8AEnh+81tgRwWXV0l6nzA3Ne3hvE7L52+t5ZjKHd0KtHErdJ/xPqr0v2PyTPf2cnHmHU5cM+IfCecxV3GOdZfm/D1SduiWDhxJTUnr8VRRvo5LVr+/+iv4y/AH/Bwh+2P4cWGHx18P/gf8SrZCDLOmj+KvAuszLnkfbNK8Q6vpEbEdGXw7tyciPGBX3B8Pf+Djj4Z3jQQ/FT9mn4ieGidoub7wB4y8MeOrcE4DyLY+Ibb4fXaRjkrELieTGBuJzj3cNx5w1ibKWMqYaTtaOJw9aO9rXnSjVpLdauol5n4pxD9Cn6Q+QKc6fB+E4gw8L3xHD+f5NiuZK2tPB4zF5fmlS99IxwDk9Pdu7H9KWxP7i/8AfI/wpcDGMDHQe309Pwr8lPh5/wAFuv8Agnp47EEepfFXX/hnezlV+x/Ev4f+LNEjiYnG2fWtH0/xD4ahAOcyPrghAG4yBcMfvP4cftR/s4/F5Lc/C/46fCbx9JdbfJs/CvxB8K6zqRLYwr6VZ6rJqcT88xy2iSA5UqGBA+hw2bZXjbfVMxwWIcto0sTRnP501PnT8nFM/CuIvDHxG4S53xPwHxdkNOnfmxGa8O5rg8I0tXKGMrYWOFqQW/PTrSh1Uj2XVNE0fW7Z7PWNL07VLSUBZbbUbK1vreRQc7ZILqKaJ1z1DIQenTNeC+LP2Pv2U/HSyr4v/Zt+BPiNpgfMl1f4T+Bru5JY5Lfa20MXQY/3hOGzyDnmvosSKRnkdB8wI5PQc8fl6H0p9dVXD0KytWo0qqfSpThP5e8np5HzGX5zm+UzVTKs1zLLKiaaqZfjsVgpprZqWGq05Jro73R+aHi7/gj7/wAE6fGPmvdfs0+GNBnlVgLjwR4h8ceBmjLc7o7bwv4n03T1wcFQbNlHTaV4r5c8W/8ABvp+xHrgnk8NeJPj14DmcMYo9I+IGk6/ZQsfujyPGnhLxFdSIvo2oBiBtLjJNfulRXl1+HMhxF/a5Pl0m95RwtKnL/wOlGEr6b3ufpWUePnjZkXKst8VePKdOFlGhieJc0zDDJLZLC5jiMXh+XT4XSs9mj+Yfxl/wbfaHIJZPh5+1d4i08hf3Nn45+F2ja8GI5Al1Hw34o8LEZAwWXS3OTkJ0Wvk/wAaf8G9X7XOiJPL4O+KfwH8cJH/AKm3vb7xr4K1G4AJwBDdeGNf02JyASRJrARSeZMcn+yiivHr8BcM1neOCnQl1dHFYldto1KtSmv/AAD8D9Vyb6bX0iso5I1uMcDndKFv3Wc8NcP1OZK2k8RgMvy/GzvbWTxPO/5j+Cbxj/wRz/4KKeDfNkf4At4tto1LfafAfj74f+Ig4XgtFYTeI9L1l93VV/swSEY/d7jivlDxp+yJ+1b8Ollk8cfs0/Hjw1bwBmmvb74U+M59NRV+851XTtIvtMaMHOZVvDHgEhiK/wBIcqp5IBPTJA6elIUU9sduMj37Yrx6/hllc23h8wx9FtaKosPWS2/lp0JNafzpn6zk37RXxLw7gs/4H4JzeEbKcstlneSV6iVk26lbMM6oRk7N3jhVFN/DZH+Xneo+m3DWmpRy6bdocPa6lFJp90jDgq9teLBMpB7MgPqAcgNUhhlCHBHBUhxg+hGR+Vf6cHib4feBvGkDW3i7wb4U8U27rseDxL4d0fXoHTB+VodVs7uMjJ5BXBxg18veMf8AgnV+w148eSXxJ+yp8DJp5txkutJ+H2i+GL52bqxvvCsWiXYbphlmDAjIYGvIreGOLV/q+b4eor6KthalHTT7UKuI1/7d7+R+r5R+0e4arciz7wvzzLtEqk8o4jwGca9XCljctyPf+V1tNubqf54oLcDHb0I449u46Yz9OKf/AFr+5rxR/wAEQf8Agnf4kMrWnwn8SeD5JAT5nhH4o/EOzVGJJzHaat4h1qxQDgBfszIvICYNfP8A4l/4N5v2QdS8x/DXxO/aC8KyMD5aN4k8E+ILWJj0Aj1XwGbp0Ho18HYZBfkmvJq+HPENN3p/2fWS6U8RKMn5r2tGkvS8l5+X6Zln0/PAnHcixlHjjJpStzvH8P4SvTg3a/vZVnGYzklrqqWqV7K+n8cTE9vzyOo5x1xkcfrjjNRkn17ew7D/AAH5evFf1Ua9/wAG4HhOTzG8LftYeLrH5SYovEnwr8P61huwlm0nxX4c3DgZ2WwzkkDnFeMa1/wbk/FqB5P7A/ak+HGooB+7Gt/DLxLo0j4+Ub2sPFuuqpyCDtR8DJweledU4I4mpXtlfOr3vTxeDl1Wtvb3te2y+R97gPplfRux6SXiLHBzdrwx/DPF2Gte2jqPIpUdOrVVrz01/m9or97NW/4N6P2wLRZP7K+LH7OushRlFl1r4h6M7jJByJPAmoRxkAdPOZckDNeb6j/wQV/b3sifsyfAzVwFYk2PxQ1KEnaSOBqfgvTxuY8DLBR/EVrklwvxHHfJsY+/JGNTt/z7lNde+tnbY+qwv0m/ADGWdHxX4Sgnt9bxlXAPpvHH0MNJb9UrPS+p+Lef6/r/APqo/L/OP8/XPtX643H/AAQ8/wCCicOfL+Gvw+vMAEC0+L3hAZ+bGR9tls/c84GOM7qzn/4Ik/8ABRtTgfBzwo4wTuT4wfDbHGOPn11Gzye3asXw/n6dnkuZev1Su166U9j14+P/AIGzScfF3w61/n4tyWm+nSpjItb9UtFfvb8n6K/V9P8AgiV/wUcfr8G/Csfy5zL8X/hsBkHBBMevSnJ6jjGBywzWvbf8EOP+Ch8+zzvh98N7DeuW+2fF7wwfKOQMP9hS+Jbhv9XvXg89BRHh7iCTsslzL54SuvzpoVT6QHgdSV5eLnh21/074uySq+nSljJye/RM/Imiv2s0n/ggh+3lqEgS8uPgLoiFQWe++Jut3RHqPL0nwLfliOc4baeCDjr65oH/AAbtftQXpU+Jfjn8B9BjIUsNIg8e+JpkPG5Qt1oXhiNguGwBOM8cgc10U+FOJKjtHJsWv8ahS/8ATsodzxcb9KD6PuATliPFfhaaS1+o1sXmj2T0jlmExcnvpZO/Tc/n3x9PzFOC59enbBP5Zz/ntX9QHhb/AINwcGKXx1+1nK6jabi08G/CCG2LHK7kh1PXfHd/GncK8mlyZJGYicivO/jz+xt/wR3/AGE7aex+NvxS+Mnx++K9nCXj+Dvhrxto8fiS4uiuYU13TfA2meFYfBNlIwRnn8X+K9OmktmabTbPVWVYX6p8G53h6LxGPjgcsoR+KtjsdQhBXtZL2Mq85SeqUIwlOUtIxk7J/O4P6XHg5nua0Mh4Ir8YeIueYhtUcp4N4MzzEYqaTipVJTzjD5LhKWHp3vWxdbE08LQg/aVq1OmpSX84PfHH5jvz/Ln6c0V778bvjB4C+ImqSWXwk+AXw9+AHw8tpy2m+HtAudZ8aeNtQiRv3Fx4x+JvjG81LX9UuwoBax0GPw3oAbBfSrqWNbqvAq+aqwp06s6dOvHERi7e1hCpCnPT4qcasKdXkd9HVp0pvW9ONj+i8rxWMxuAw+Lx+VYnI8TXj7SeV43E4HFY3CRduWnjKuV4nHZasTa7qQwOPx+Gi7Kni6uvKY4z9f0x/jRTl9Pfj2OV56egoC9Mf09Aeh68E/lWV1fe1r+j2/zXzud4AA8n2zzjgbR/In+lS4HP1z9cnP8A9bnmmKO+Me35EH+fX+YzUlZSeqt02200Wmna39WARlVlZWAKujIwIz8rgqR0PY+nPSv9Cj/gmz8WE+NH7DP7NXjRrlLrUYPhpo/gvXnDh5R4h+HRm8Ba01yMsyTXN94dmvSr4Zo7mOTG2QE/565IUEkgAAsSxCqqqMszEkAADknI+oGSP7V/+CEHw0+M3w4/Y91aX4naVNoPhPx/8RL74g/CLSdT3xa7/wAIhrfh/QbW81q6sXG7TtH8Ravps+seH4Jtlzd2tzPrLwpa6tZyTfonhpiK1POcTQjTnOjiMFP2s4xbjSnSqU50p1JbKLTqU431c6it1P4L/aEZNleN8I+H84xOOwuFzbI+MMKsrw9erGOIzLDZpgsVhszweBpOSnVq03TwOY13GLjTw2BqubTlC/z58S/2abr9mL/gth+zl8e/DmmyW/ws/am1/wAe2N/dQRlLDRfi1q/wv8V2finRLiRR5UD+LZl03xppiylX1HUZ/FEdvGw01yv9F9xBDdQTW1zFHPb3EUkE8E8aywzQyoUlimicFJI5EZkkjdSrqSrAgkVy/i3wJ4U8croCeKtGstZXwv4p0Hxr4ea7j3TaN4q8M3Ru9F1zTbhWSa0v7KR5ohJC6iezuryyuFltLy5hl67pX63leVU8rnmao29hj8fPHwp2t7KdejRhXhbZwdWlKpHtGpyWSgm/8tvELxGxviHg/D6WbU6jzngrgjB8DYjMJT5nmmX5Nm2bYvIsVJ39osTh8tzOllmIc+aVWWXwxbqSniZwpfjr/wAE5v2W9R/Yv/ab/bm+DtjYXMXwp8b6v8LvjH8Fb/ypjYDwnrh8eaRqnhZbpsxvqXgfUba08P3MBY3MmlQaFqcwVdSjFfsVTPLTdu2jd6456gnn3IGfXA9BT66cuwFLLcMsJQ0oQq4ipSjaypwr16lf2S/uU3UcIdeRRvd3b8TjvjTNfEHiSvxXnnLLOcdl2Q4LMsTGTlLMMVkeQ5bkTzOvdK2LzKnltPG4214SxdavOHLCUYRKKKK7j48KKKKACg/lRRQB86fEP9kn9m/4ueKo/GvxW+DHw9+JniaG2itLXU/H/hy08YfYbaEYSHTbLxB/aGnaWhwrSDTrS1E7jzLgSuc0WP7If7K2mKF079mz4A2QA2j7N8G/h3FgdsFfDwPHQZJ446V9F0VzfU8HzyqfVcN7Sb5pz9hS55y/mlLk5pPzbbPdjxTxNDC0MFDiPPoYLCwVLDYOGcZjHC4ekndU6GHjiFRo009VCnCMU29NWeAXH7Kf7Mt2hjuf2ePgTcRsMFJvg/8AD2RSOez+HiPw5/U153rv/BPv9iLxKrrrH7J/7PdwZM7pIPhN4O02bJzkifS9LsZlPPVZARgYIwK+w6KU8Dgpq08HhZrtPD0pL7nBm2G4x4uwU1UwfFXEmEqJpqeFzzNMPNNWs1KlioNWstmfl54u/wCCM/8AwTk8XRyh/wBnjT/DFxIGAvPBHjT4heFZISc4aK00zxWmlgqeQH0904AKEZB+J/ih/wAG7H7OWt29xN8IvjV8XfhvqTLI0Fv4qXw58SfDkb4LJG1o1h4T8ReUCAC7+KJZAuWJdgc/0Galqmn6PZXepare2mm6dYQSXV9qF/cxWdjZWsK75rm8u7hkhtraFMvLPKyxRqCXdQCR+L/7W3/BcL9l74Dw6t4Z+DtwP2jfiZbCe2it/B1/HB8MtGvo98e7X/iEYbmy1JIJQrvZ+DLbxHJPse2mvtJc+evz2b5ZwfhaMq2bYLKsNBp+8qUMPXqd1SWGVPEVZ/3aXNLTayP3vwn8RfpW8R5zQyrwx4u8SOJMbSnS56GIzHE8QZPgYyajCrmcuJJY7I8uwz1XtcwlQw7fu8zk0n/Ov+2t/wAErP2gv2I/DSfEPxZ4h+H3j74WyaxYaFF4w8MarJo+qQanqzSLplrqPg7xEttqRuLvyZ3C+HL7xTDbQxSz6hc2kUZkP5lllIPP5e/HGcZ96+nv2qf2yPj5+2T43Xxp8bPFzajDp8t0fCngnRI5dK8B+CLa7IEtv4b8Pm4uFW6ljSKK+13VJ9R8Q6osUaX+qTwxQQQ8H+z/APAD4o/tO/FTw18HfhD4fm17xd4kuE3yFJV0jw3o0csaan4r8UXyI6aX4d0WKUTXt5KN80hhsLGK51K7tbWb8Ox8MBisylSyHDYqOHqzhSw9CtN1q1SpJqPuQSc4qbaUKc51ai+KdT3uSH+03AmJ404a8PqOY+NnEXDFXP8ALcJicx4izjKsKsoyXLsBRpqq44yvVqQw2Ir4WlGpPF47DYTK8JOUlRoYHloLF4z7z/YI/wCCT/xS/bt8Fav8UNL+I/hj4XfDvRfGdz4Kl1HWdA1jxLr2r32nabpuo6nc6DpNpd6Rp1xZ2I1S1snmu9dtSb37TEIm+yvn97/gZ/wQP/Y4+G72ep/FK98efHzXbcq81v4s1ZfCvgl5lwQ8XhTwYdPvJoQwybTXPEuuW0inZLG65z+oH7KX7PHhX9lT9n/4bfAnwjL9tsPA2hrbajrTwrBceJPEuoTzap4o8SXUSljHNrevXt/fpbtJL9jtpoLGORobaPH0PX7TknBeTYHC4SeMwFDFZgqNOWJqV3LEU1XcVKcYUpylQcacm4xkqd5KKlfXT/Hnxi+l/wCK/GfE3EuF4S40zXhvgSWaY6jw/g8ko4fJcxqZPTqSoYSvjM1wuHpZ2q+NoQjia9B4+MKU60qKhamjgvh38Lvhz8I/Dlt4R+GHgbwl8PvDFoVa30HwZ4e0vw1pSOqBDM1lpNtbQy3EigedczCSeYjdLI7ZJ72iivsYxjCKhCMYRikoxilGMUtkopJJLokrH8j4nE4jGV62KxdetisViKkqtfE4mrOvXr1Zu86latVlKpVqSespzlKUnq2woooqjEKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAGDPHHYd/T29QcZPboMnq7HoOx78+vJznr6Zpq544yMDvxwOw9c4ye2CAM9XYx0Hrzn8eT15Ppml/XluvXVdO/5JdPlru+nl16/f6LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFMlfy43f+6M9C3PQcAgnnsDn0p9UNUvrTTdPvNQv7iO0sbG3lvLy6mbZFb2trG09xPK5BCRxRRvJIzDaqKxYgDNG244xlKUYxTlKTUYxim3KUnZJJatttJJH8FX/BYbxrH45/4KJ/tDTwSJLb+Fb3wT4BtmjPA/4RXwH4eh1CM8D5otbu9UjfBwHDghSCK/NEHJJGew9iBn+pP6fSvUvjv8Q5/i78cfjF8U5nZz8Rvil488awsxJP2LxF4n1PUtNQEgErFp1xaQpxhUjUD5RXl/Sv5YzTF/W8yzDFxemJxuKrxf92rXnUirPa0Z2+SS2P8ApZ8Osglwl4e8DcLzjyV+HuEOG8mrx3tictyfB4XEuXnKvSqN6bt9dQoopQOR9f6jr7c15x9cOTr+HXvzj/Pt+dS0mAPw4/l659B/+ukY8cMF77mOFAHUsSCMAc84yccjrTV20v6/pAlc7/4VfC/xt8bfiT4J+Enw30iTXPHHj/xBZeHPD2nruEP2q7YtPqGoTKrfY9H0ezjudW1nUGBjsNLsry6kBWEg/wCg5+xj+yV8O/2M/gX4Z+EHgW2gur+GGPVfHvjB7ZIdU8e+OLu3iTW/Emot88iQSSx/Y9E01pZItH0O3sdNieVoJbif8if+CE/7CT/DTwDN+1/8S9EMHj34q6U2nfCew1CHbc+F/hVcPFNL4jWGUF7bVfiLcQxXNvLtWWLwfaaaYZFi8Q30J/olr904C4cWW4NZriqaWOx1NOjGS97D4SSjKKV9YzxFlVn1VP2ULQkqil/jT9N3x8nx5xbPwy4Zx7lwbwXjJwzerhqt6Gf8WUL0sVOcoPlr4HIJe0y/BrWnPMP7RxSdal9RqU02r/dH5CjavoPToOnpS0V+hn8GjSiHqqn6qP8ACk8qMEsEQMRgsqhWIznGRg9eevWn0UAfjB/wWF/YR+F/x1/Zz+Jfxx0TwrpOh/Hf4OeFNU+IGneMtIsYbDU/F3hrwvatqXifwj4tmtkjbxBay+HbTULjQZ9Q8690XV7WyFhc29heana3f8Q4YEZU5DYIP+z1H6Yx14r+93/grx+0Vov7Pv7DvxcE15Cni74v6Jf/AAX8C6Y0gFxf6l47sLrTdevYosiRoPD/AISOva1PMFaFJrOztZGWS+gD/wAEEeBtUYwu0DBzwMAdB7fjX4b4kUsHTznDvDwpwxNXCKeN9nFLmlKc40qlXlSvWlBNScnzOnGk3dWP9ov2feY8XY/whzuGfYnGYrh/AcVVcFwhPG1KlWVHC08BhKmaYTAyqtyjlWHxlSDw9Om3h6eNq5lTp2nCpCNmj/P+f8/Wivrf9kn9iP8AaC/bQ8Yjw18G/CTyaFYXcNv4s+JWvrc6f8O/Bkb7WcavriW8pv8AVhCTLa+GdDi1DXrtR5v2OCyWa9g+Dw2DxGLr08NhaM8RXqy5adKlCU5Se+yvolrJuyjFOUpKKbP7Sz/Psj4VyjHZ/wAS5tgMjyTLacsRjsyzLEU8LhMPSVkuarUcb1KkrU6NGHNVr1XGlRhUqzhCXzX4R8H+K/H/AIm0XwX4G8N654x8X+I71NO0Hwx4a0y71nXNXvXyRBY6dYxS3ExRQZJpAght4Fee4kjhjkkX9RIv+CIP/BQ648N2fiCH4aeBxd3dot1J4Tn+KfhS28VaeWG4Wt/FcTx+H4rzbndDD4iuVQjbJKkgZB/U5+wb/wAE4fgn+wv4TP8AwjkC+Nvi9rlnHB43+L+t6fBDrepr8ry6H4as99yvhLwfHOqyR6JY3U1xfyxxXmvajq13DbSW36GYAGABjpjAxj0x+J/Ov1nJ/DbD/VVPOq9f61Ujd0MJUpxhh7292VWVOqq1RJK7glTi7xi6iSqP/L7xT/aEZ3T4jlgvCLIsmlw3l9WdN51xXgcficXxBOL5XiMPl2Hx+WzyrL5NN0IYidTMa8OStWjl85TwcP8AO4+IP/BPD9uT4WrPJ4x/ZZ+MUdrbBjPqPhrww3j/AEyNUHzSNf8AgC48T2yRgKWDyug2jOeuPkLUtPv9EvpNL1vT7/RNTgYpNpms2V1pGpQuDtKS2Gow213GwIwVaEEHgjIIr/UC8tM52gHGMjI4/DH59a4Txz8K/hr8TdPfSviL8P8AwT4806SMxtYeNPCuh+KLMpg/L9n1uxvYwMn+EKRgYIxRifC+hq8Dm1em+kMXh6ddPbT2lGWH5dt/ZSfkZcO/tHM8puEOL/DLKMenZVMTw3nuNyhw7zhgczwud+1b35HmNBdOddP8zVcryMjgDI6YPr2Oc9cc1G0cfmLP5cYmU7lmEaiVG5wySKA6MCTgoQQeQQRmv7pfjR/wRY/YN+LcV3caX8Mr/wCDuvXAkZNc+DmvXfhmCOZtxU/8IhqY1vwM0SnaWih8OWzsAUWaPO9f5uv2/f8Agkx8Zv2KtPn+I2h6ufjF8C0nSHUfG+maQ+l+IPAbXEqw2KfEPw/FdX0Nnpl1PItpb+LdKvJ9Ge72Q6rbeHp7rT7e8+NzfgrO8opzxU6dLF4Wl786+EnKbpwVryqUpQp1YxSV5zjCcIJXlOKTZ/WvhP8AS+8H/FTM8Fw9hMdmPCvEuYTjQwOT8U4WjhI5jip2SwuAzTB4nGZZXr1ZNU8NhsRiMJjcZUlGlhsLVqvlPiT4cftbftSfCDyY/hl+0N8Z/B1pblfK0vS/iF4jn0EBCNqP4d1S91HQJYwVH7mXTXjwACu3g/fvw2/4Ln/t+eBDbQ+IPFfw7+LVjb7d8PxB+HthZ30yDA2HV/h7d+CJ2cgf6+5gupMnc2/AB/HoEkfMArgkEcDGOueepyMY6jkelJXh4bOs2wNlhMzx1CKt7kMRV9npbR0nN031veNulrH7PxL4R+F3F7qf6z+HfB+dVqt+fGYvh/LXmPvJKThmcMNDMKTat79PFRfXmuf1EfDT/g44jLW1v8ZP2Yr2EfIt3rHws8f2mpDqN8kPhjxjpGjsgxkrGfF0rchPMP3h+iHwy/4Lhf8ABP74hfZ4dZ+Inin4UX8+1TZ/E/wJr+lwROcArLr3hqLxZ4YiQNkGafW4Yto3syKeP4aMnscfTj+VO3n/ACT7+mD6Dr7n2+jwniFxHhrKrWw2OiumKw0VK3bnwzw8m/OTk773P594n+gl4AZ/7SeW5XxFwfWneSnw7xBia1JTet3huI6efUlC/wDy6oLDxS0i46Nf6Unw0/aO+AXxlgin+E/xm+GPxFEqB1h8G+N/DniC9RWAIE2n6bqNxf27cjMdxbRSAnBQEED2VZUfo3I7MCp/75YA/pX+XrHiKdLuLEV1EwaK5izFcxMp3K0M8YWaNwRlXSQMpwRg4r6s+GH7c/7Y3wZFtF8Of2lfjBoen2hX7PomoeL73xf4bjCcCNPDfjUeItBSPAC7E09AF4UAdfp8J4oQ0WPymcdr1MHiIz7XtRrRha1+td9j+dOJ/wBm/jY+0q8F+J+DxDd3RwPFGR1sEo21Sq5tlOKx/O9UnKOS0lfXl1SX+jFRX8T/AMNP+C+X7cfgryrfxtbfCL4v2Ue0SyeI/B114R12VAQCE1TwHqujaRHIQMb5fDFyM/M0b4wf0K+Gf/Bxr8Nr021v8X/2b/iB4Ycqi3OpfDrxd4c8d2m84DyrpniS1+H99DHxuES3l7IAcB3JzX02E4+4bxVlPFVcHJ/ZxeHqRtpd3qUVWoq3nUXfY/njif6EX0hOG+eeH4Xy7inC0782K4Yz3L8TdLW8MDmdTKc2qv8Au0svnK+nKf0rUV+Ufw2/4LVf8E8/iClvFffGa7+G2pzkJ/Z3xR8G+KPCgicnAE+uR6dqnhOMdSZP+EhMQALb9ozX398PP2gPgb8XIYp/hb8X/hp8REmVXRfBfjnwz4ln2sMgvbaRqd3cxEA8rLEjr3UHNfSYXNcsxtvqmPweIbt7tHE0qk1f+aEZuUX5NLXTc/n7iPw38QuD3P8A1q4H4s4ehBtOtnHD+aYDDSt9qnisRhaeHqw7Tp1ZwfSTPXqKjWRG7le/zAr+p479jUld58UFFFFABgegpNq/3R0x0HT0+lLRQAm1f7o6Y6Dp6fSk2r/dX8h/hTqKAG7E/ur/AN8j/ClCqOigfQAUtRyuUQsBk8ADGckkDp365oA4nx/8T/hv8KdCn8T/ABO8eeDvh94dgV2m1vxn4j0jw1pYKLuZBe6xd2dvJMV+5AjtNIfljRmIFfj5+0D/AMF6P2NvhWl5pnwpTxZ+0R4nhDpCPBtg/hrwMk65BS78b+K7az8+DcBi68M6B4ogcZKORtJ/mj/4KifH9v2kf23PjX4stdQbUfCHg7xE/wALPAKC4kuLCPQPh40nh+71HTonYwxx+IPEcGva8J4ET7RDqUBfcEjC/AgQEc57ccgcdOD/ADH9K/Hc78RMesVicHlVDD0adGtVoxxdS9erUVKbgqtOElCjTjOzlGMoV/da13P9ZvBz6AvBVfh7hvifxNzjP83zLN8oyzOMTwngXTyLLstnmGEo4x5VmOLpSxOa42thY1lQxFXB4vJ2q8KkYxcYpv8AWX9p3/gs5+2f+0WmoaDoPiaz+AXgG8EsDeG/hHPe2PiS7spA8Zh1r4kXTL4nmeSJjHcDw1/wiVjdRllnsHQ4r8n5XluJZZ7iWSeeeaS4uJ5neW4ubiVi8txczyM81xPMzM000zvJKzFnYsSSlFfnePzHHZjWVbH4uvi6ruk6tRuME2m1TgrQpRvryU4wjq9D++eD+AuC/DvLFk/BHDGT8NYCXK6tLLMHTo1cVKmrQq4/GS58dmOIivdWIx+JxOI5XZ1WrIKKKP8APpXIrW02PqRy4yPqPp1H/wBf9KcvJ+g5HbJAzwBj1zn8uKRUz1/z0x/M+nTrUtRJ3dlq3daedv8ALUBBnv8A/q46fnQTjHqSAP8APPFBOAT/AJJ9K/Wn/gll/wAE2Nb/AG1/Hx8efEOy1DSP2aPAWsRweKdUQzWVz8SPENoYpz8OvDV2hSUWao8UnjTXLRg+l2E0WlWUsesalHNp3Xl2W4vNcZRwWDpupWrSSXSEIqznUqy+xTpxd5ys3paKlJpP5Djzjrhrw24VzbjLi3Hxy/Jcoo+0rTsp4nF4ib5cLl2X4dyhLFZhjqzjQwuHjKPNOXPUnSoU6tan7x/wR/8A+CYcv7RWvaX+0t8efD7/APChvC+qCfwH4T1S3ZY/jF4o0q52/b7y1lAW6+Gvh69haO8Lg23i7WoDpKefo9hrK3f9kVvbw20SQwRRwxRqqJHEgSNERQiJGi4VI0RVREUBUVQqgAAVj+GfDOh+D9B0fwx4a0nTtC8PeHtNstG0HQ9JtIbHS9G0jTbaOz0/TNNs7dI4LWys7WKOC3giRUiiRUA4JO9X9F8PZBhcgwMcNR9+tO08ViGkp16yVnJ78tOCvGjSTapwu25VJ1Jy/wADPHLxq4l8ceNMRxLnUp4PKsL7XB8McPQquphMhylzUo0k0owxGY4vlhXzXMHCM8XiFGEI0cFhsFhcMUUUV7x+MhRRRR/X+f8AwACiiigAooqIzIO5P0ViO3fGOM5Jz6+lAEtFfM3xZ/bN/ZS+Bcdwfi1+0F8KPBF3bZ83RtV8Z6LJ4lJUAlIPC1hdXniS6kAziO20qZ2I2hScCvy/+L3/AAcC/saeChdWnwv0D4rfG7U4iwt7nQ/DS+B/CszKePM13x5LpGsJCxH+us/CuoKUbcobAVvKxue5Pl1/rmZYOhKO9OVaEq3yoU3Os/lBn6Zwj4M+K3HjpPhLw+4qzmhWaUMfRyjFUMpu7W584xkMNlVJO6d6uMgra3tqfuzUM1xDAjySuqRxqzyOxwkaKNzyOxwqoi/MzkhVHJNfxzfF/wD4OE/2o/FourL4P/DL4X/B3T5crBqetNqXxR8W269FeO4vk8NeFY5QACUufCupRq3BLr1/J74y/tiftSftDPcD4yfHr4leNtPuXaSTw3P4hn0Pwam4klYvBXhhdF8KooB2rnSGfbgFj1r5HHeJGT0OaOCoYrH1FtLlWFoPbedZe3W/TDNO2+p/VHBn7PnxczuVGtxhnHDXA2EnyurQliHxJnVNNJvlwWUzjlU7J2aefwknpyvU/uM+Of8AwU1/Yj/Z7+2Wnjv49eDtQ8R2QkEngzwFdSfEPxb58fBtJ9J8Hx6uulXJbKAa9c6TCjf62aNQTX4u/H3/AIOKL2dbzSf2YvgYLXPmxW/jj41X6OwUjalxbfD/AMHX7HcCPMifUPG6Bcqs+nN8yV/MGiJGoSKNI0H8ESLGv12oAM++M10Xhbwt4n8ba7Z+F/BnhzX/ABh4m1F1i0/w54V0bU/EWv3ruQFW10jRra81CUkkAskBVQSWIXJHxeP4/wA/xz9lhPZZfCbUYxw1P2teV2vd9tVU3zO9k6VOlJvY/sDgj6CfghwbTjmPFUs246xWEh7evW4hxyyjIKHskpSr/wBl5XPCtUVq6lLM8yzLD8v8ROKZ9IftC/ts/tSftT3Ev/C7vjF4o8T6I83nQ+CbCaLwz8PrNgf3fk+C/D6WGi3UkIwsd7q9vqepYAMl7I+WPym4RE3ErGowoLEIg5CqozgDJ+VVHUkAAnGP2q/Zr/4IZ/tdfGVtO1r4rjRP2cvBl0YppT4xMfiL4jXFo/zN9h8BaLeJBp1wVDK0XirxDoV5bsAX02fBQ/0W/sqf8El/2Pf2WH0zxBp3ghvin8S9PMcy/Ej4rCz8TapZ3qBG+0+GtB+zQeFvCzRzL5lpc6Xo66zCp2TavcsPMOeX8HcR55VWJx7q4aFSzni8xnUniJx0fuUJyliJ6fCqnsKbXwz7dvG30r/o++CmWS4c4MjlvEOMwKnDDcL+HWFwGFyHC1rKL+t5zhaVPJMPGUouOIlgHmmOhNN1sFKTbP5bv2M/+CSv7T/7W13pXiG/0K7+Cvwcunhnn+I/j/Srm01HWdOYh2bwH4LumstX8RyXEJY2mr339k+GSQWXV7qRBay/2I/sjfsVfAj9i7wEPBfwd8NGDUNRW3l8Y+O9caDUPHPjnUbdSEvPEGtJDCBbQM8n9n6JpsNjoWlrJJ9h0+GWa5mn+skjRM7Vxkk45OCeuM5wD6DA9qfX6rkPCmV5ClUoweIxrjyzxtdJ1EmrSjQgvcoQet1C9SUXy1KtRJW/zM8bvpP+JHjfN5fm2IpcP8IUqyrYXhDJalWOAnOnJSo184xc+XE53i6TjGUJYlUsFQqx9tg8vwlSUnIAA6AD6cUUUV9MfziFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMXPH0HU+nbHPOcZPQdOvJdj0HY9+fXk5z19M00Z49wO/p7eoOCSOnbJ6ux7c4Pfp3xnr19M0vx/LR/PVfj+SWy9Fru+m+nXr9/otFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV8E/8FO/jEPgd+wn+0j40gvBZ6xe/DvU/Avhp1cpMfEnxIeHwJpD2+OWntJ/EB1EKvzLHZSSD7hx97V/Mz/wcbfHBdO8A/Af9nTTb0C78X+KdT+LPiq1jcb00LwVayeH/C8VwgJPkanr/iDUbyAN8r3HhokDdECPC4mx6y3Ic0xV3GccLUpUWnqq+Ith6LVtW41KkZWWtot9D9o+jvwVLxA8a/Drhl0fb4SrxFhM0zSm43hLKMg5s8zSFR2ajGvgsvrYeMno6laEV70op/ypIiRqI4/9XGFij4C/JGoRegHYZ6DryAafT9qhB26Y9e2ep56kn360yv5kP+iBtvVu77vd+oDqKkXgDjPP89v59R+OMeoj/wA/56UueMe/+H+H40WbAfuzjnngk9cDj+ZxkDv7c1+on/BKj9hG7/bT+PkN34u0yc/AX4T3OneIPihesrpaeJr4yef4e+GVvcKRvl8SyW73PiHyiJLLwta33z293qelNL8G/BD4LfEH9of4reC/g38L9Hk1rxp441ePTdPiKyfYtMtVBm1XxFrc6BvsOgeH9PSfVNYvnG2G0t2SMSXMsEMv+g/+yF+y54B/Y/8AgV4P+CngKFZodFtzf+J/EksCQ6l418Z6jFC/iHxZqoQsRcaldRiKztWklXS9IttN0mCQ29hFX3XBHDbznHLF4qnfLsDOMqikvdxVdcs6eGs1aUF7tTELVez5Kcor28Zr+O/pgfSBh4RcGS4Y4dxqp+IfGWEr0MudGaVfh7JJuWHx3EU+X3qOJn+9wWSN8snj/bY2m5LKqtKp9GaXp9rpVha6dY2ttY2VlBDaWdnZQpb2dpaW0SQW1raW8SpFb21vBGkMEESJFDGixxqqKBV+iiv31KySXRW+4/w8bcm3JuTbbbbbbb1bbd223q23dvVhRRRTEFct418Z+Gfh54V1/wAb+NNYs/D3hLwtpV7rniHXdQd47LStL0+Fp7q8uGjSSRljRcLHFHLNLIVihjkmeNG6mo5YYp0Mc0aSxtwySKrqcEEZVgVOCAcEEZAPUCk72fK0pWfK5JyinbRuKlFtJ7pSi2tFJbmlF0lVpOvCpUoKpB1qdGpGjWnRUk6kKVadKvClUnDmjCpOhWjCTUpUqiTg/wCCn/goj+1V8WP+Chn7Q0mr+C/AnxGvfhZ4GF74Y+DHgrT/AAh4j1TU30q4nifU/GOq6Tpen3bReJfGc9vaXU9sFeXS9HtNG0Z3eexupp+L+EH/AASn/b5+NFzbf2J+zz4r8G6TcNGW8RfFk2vwz0u3hcg+e9l4le38UXkKj5iNK8O6hKVBKxtX+gPHbW8IKwwxxKf4YlEa9uyYGeBz1xx0qUIo6DuDySeR0PJPI9etfnk/D2jjMbWx2bZvi8bWxFR1KipUaWFTbtaC5p4lxpwUVCEY25YJRi1ZM/vnA/TyzfhDhHJ+DPDDwr4Y4SyrIsup5bl39r5xmXEsqcYXnUxdSGGw/Dka+OxWInWxmLxFeVX6xjK1XEVozlUkn/N5+y3/AMG+Pw/8LXGm+J/2rviHL8T9ShaG5k+G3w8Oo+GfAKyIwb7NrXiidrXxj4ntiB88enQ+DIz80cy3kLsh/oT8CfD3wR8MPCujeB/h74U8PeCvCPh+1Sz0bw54X0iz0TRdOgQk4ttOsYordJJHLS3E5Rp7md5J55JJpHduyor6/LMkyvJ6bhl+Ep0HJJVKutSvUs07VK1RyqSSauoc3JF/DFH8neJHjF4keLWOhjePOKcfnUKE5VMFlq9ngsly9yTTeByfBQoYChV5LU5Yr2EsZVgkq+IqtXCiiivVPzMKKKKACsbXtC0rxHo+qaFrem6drGkazp93peqaXq1nBqGm6lp99BJbXmn6lY3SyW99YXlvLLb3VpcI8NxDI0UqOjEVs0UNJppq6ejT2a7MqE505xqU5ShOEozhOLcZQnFqUZRkrOMotJpppppNan8E/wDwVV/Ydj/Yq/aINr4Os7mP4J/Fi21Dxb8LWlaWeLw7Na3MUXiz4dG7ly8w8JXl5ZT6M8heWTwxq+jRzz3N7aX81fmPX9xX/Bb/AOB1r8WP2FvG3iyCzWbxL8Dtc0H4q6JcJGWuY9LtboeHfGlqJAdyWknhfXdQ1O5jBEbS6PZyvkwLj+HXp7/l/Sv5240yenk+d16eHhyYXF044vDwS92mqspRqUopKyjCtTqKEUrQpSpR7s/3y+iP4q4/xZ8G8qzHPMTPG8ScM43EcJ59i60lKvmFbLqGFxGX5lXbvOdfF5XjMF9brybeJzCnjaza5uWJRRRXySjffRafO/Y/pmUrOy1fz8rBRz2BJ44HucfzNdP4K8EeNPiR4n0rwV8PfCfiPxv4w1uYQaR4X8KaRe65r2oSErua303T4J7k28StvuLuREtbWLdNcyxRKzr/AEa/sWf8EB/EGt/2T48/bT16Xw3pbmG8t/gh4D1aJ/EN0hG9bfx9470957PSYztVbnRfBU15ePHIAPFmnXKSW49nKchzLOqqpZdhp1IxklVxE/3eHo35XepWkuVO3vKEVOpJJ8lOXT8q8T/Gfw68H8sWZcc8RYfA16tOVXL8kwtsbxBmzi2lHAZVSl7edNzXs5YzEfV8uozajicZQumfzUi2na1uL1YJ3srSRIbu8SCV7K0llXdHDd3aobe2lkQF4455EeRAWQMoJFeNklUtC8cq9d0To6nPfKEjn86/0vfhl8DvhF8G/Atl8M/hj8OvCPgvwLYRGOLw3omi2dvp9yzII5LrVA8ck2s6lcqqm91TVpb3Ub6Qebd3U8hLnxX4l/sBfsXfF1p5vHn7Mvwb1a9udxn1ay8FaZ4b16V2zmRvEPhWPRNc35IO/wC378gENnmvup+GGMVKEqebYedZxTqU6uHqwpKejahVjUqScU7pSdGLe/LG9l/FeC/aP8MTzLE0sx8Mc/w+URxElg8dguIMvxmZVMKmlCpicqxGBwWFo15W55UaWcYinTb5FXqKPPL/ADt1LKAM44AwcEe/HI9QfxHrREPs86XduRb3cTboru2Jt7uJx0eK4hMc8bA8h0cMDk5yAa/tZ+IH/BBT9hTxb58vha0+LHwsuXRvJHg74i3OsWEUhJxmw+Ien+MiYxkfu47qEYAUOuSa+FfiH/wbkatF59x8Jv2obS4XDtbaV8Svh1JA467Un8R+FPEMiHAGGkj8KjOciI/drwsTwBxLh3zU8NhsUlrzYXFU09Gto4h4eevRRi2lf5/tPDf05vo+Z7y08fn2ecLVKqUPZcRcOY6ULtJOM8RkKz3Cwj0c61anC3xO17fhH8Pv2y/2tvhUsEXw+/aV+Nvhuztyph0uP4ieI9W0RNmCq/2Dr97q2itGCB+7awZMAKRjOftrwL/wXB/4KFeCvs8ep/ELwL8SLWDA8nx98NNAM0qjA2y6h4IbwTfSMQMGSWaRzySSa1/iF/wQv/b98Fm4fw94a+GvxUtYdxSTwH8RtPs7yVFJww0/x/Z+Cm3NjPlRTztjgFjkV8N/ED9h79sj4YLNL45/Zh+N2jWltv8AP1O28Aa34j0ZBH9521vwpb67o+xRyZBe7Cp3btpBrz+Ti/J9LZ7goR35Hi/YWVnvFyoSXza3tpofbxr/AEU/FVpyn4KcV4vE9KseFP7ebmk17laNDO6U5f4YTTvtJH7JeCP+Djf4w2BiT4j/ALNHw58TKFUTXHgjx34l8FyMeMtHZa/o/jqMEgHCNfYyfvgCvrfwX/wcWfs56mYY/HvwH+NnhGRwonl8P3HgbxxZQ9NxEkviHwnfzKOcbNMDEf8ALMEha/kOv0l0u4e01OKXTLyMsslnqUUlhdxspwVktrtYZo2U8MrorA8VGjbxuHzAjO5eVx1zkE5yK6KPHXE2HtF5gqyW8MRhsPOWlk7zVGFXvvUvt1PFzr6FX0cs6i61LgarlFSsrrE5HxHxFh42la0qWGr5ljMuS3a5MHy22VtD+6Dwb/wXD/4J3+KhENS+KXirwHNKR+58bfDDx3aCLJAxLeaDo3iHTFxzlhfsmAW3Bea+nPCf/BR/9g/xsYk0D9rD4ItLMQI7fWfHGk+Frok4wDa+KZdGuEPOMPEpB4IBr/PGBI6EjP1FSABxhgrAjkN82T7g8AcdMYr2KPiZnMLKtg8urLS7UK9KT2+0sROC6/Y0+8/J83/Z2eEmK555NxXx9lEpfDDEYrIs0w1O9rJU3kmCxEorZKWMbat719T/AEyPDPxe+FHjRUfwd8TPAHitJAGjfw14x8O68rg4wUbStRuw2cjpn9DXfiaNlDK2VI3BgGwRjOQcYIwRyMiv8vdIIIpBLFDFFKDkSxRpFICOhDxqrA+4INd9ovxW+KHhJRJ4b+KXxK8MpboXB0H4heMdESJIxu+VdM1q1RQoXgBQMACvTpeKT/5f5Mul3Sxv32jPDdf8b2PzbMv2bN5N5N4uXTdo0cy4M967tZPEYXiVp+qwqv2R/pmq6v8AdOeAehHB6HkDrXw3/wAFH/2lY/2U/wBjr4y/FSzvks/F7+H38FfDddxWab4i+Nw/h/w1NbAczNoct3P4ou4l6aboV9ITiM15l/wSe+EXxf8Ahj+yR4T1748eNviD4x+Jvxan/wCFk6ha/EPxX4i8Uaj4M8OaxY2sXg7wlbN4i1LUrjTZYPD9va61rVlG8TW+va1qdpOjNaIR+C//AAX/AP2rl+Jnx18Jfsv+FtSFx4T+BUA8ReORbTB7a/8Aiv4r09PsmnzbGaOWTwX4OuoY1/it9R8WazZTKJ7Fgv1+e59PA8MTzOVKeDxeNw0KeFw85Xq0sRi4P2fM+WNqlCk5V5xaTi6cqd+bV/yz4LeCGH4x+kbhvDqhmWG4q4X4Qz/F4/ibPcHh50cszLIuF8VTWOdKE51pLBZzmUcPkeFrqpNVY5hSxdN+yd1+A6hs5eWS4boZ5WMkspxlpZZGG55JCSzu3zuzFmJJJp9IAAAB0AwO/H1PPalr+d1Jq6SW+2+v9afI/wB6Od9LW6af5WXyWi6BRRRS1bWura1IClHUfUe1JTlHzD8/8/5/Sqimrt3SSu133AmHAA9KQnAPr7e/A/z/ADoJAz+uO2cD+uR9DX2X+w5+xF8Uv25Pi5b+APBUcuieDNEezv8A4m/Eu4s3utG8C+H7iQ7VUZji1LxfrCwzweGPDqyJJezxy3961to1jqF5F0YLCYnG4mlhcJSnWxFeap0qUF70m9b3ekYxinOU5NQhCMp1JRhFs8TiTiTI+EMizPiXiXMsPlGR5PhamMzHMcVJxo4ehTcY6KKlUq1qtScKOGw9GFTEYrE1aWGw9KriK1KnPr/+Ce37BHj79uz4tx6BYrqHhz4P+ELqyu/i18R4oB5eladMfPh8KeHZZQ1vd+OPEcKSJp9sUmi0axabX9Tia2t7W01H+9D4W/C/wL8F/h94U+F3w08OWHhTwN4K0i20Xw7oWnRlYLOztwS0ksrlp7y/vJ3mvtT1G7kmvdS1G5ur+9nnu7maZ/MPg98Ifgh+xX8BrLwP4Pj0rwD8LPhrod/rOveIddvba1e5a1tze+JPG/jbxBMsCXmr6h5El9rOsXXlxqqR2lnFa6fa2dnB/OL+0h/wcKfFCP4ma7pP7LXgH4dv8KtJlfT9H8WfE/RPE2p+JfF8sEjJL4jt9K0rxN4at/D2hXhAOj6Xfw3usS2oS91KTT7i6bSbH9qy+jknAWAp1MyrRlmWOt7adKDq1pqFm6WHhpKOFoO3NUnye1q2nKzdKnD/ACD47zjxf+m/xtmGD8Pcmq4bw+4Mc5ZXhcyxlPLcswsq7lRpZrnuLnKdHEcR5vThN4bAYdYqWXZfCrQw6nThmOY4z+siiv4jNV/4L1f8FAdQD/ZNR+Cuhbgdp0v4XXdw0eeAV/tnxdqikj/bRh6g9/Ktd/4LQf8ABR7XFeNfj5ZaHG+cr4d+FvwvsWAP9ye+8J6pcrjAwfPLd89KqfiTkEfgo5lUfRRw9GN7tW1niY2Wu9vzOfB/s9/HLEOP1jNfDvL4tq7xOf5vVlFO32cFw5ik2r7KVvPU/vEMsYONwz7ZPp6Z9R+dNM8eM5cj2jkPp3C47+vr6Gv88zxD/wAFHv29PFHmf2v+1p8bYllBV49B8UJ4Qjw3UKnhGx0IIMdAm38jx89eJvjb8a/G7SN4y+M/xd8WmXJceJvif451xH3feDxajr9zEQeMjYBwBjrXBV8T8Ev4GVYup/19r0aPa3wRxHe59xln7ODjSrJLOvEvhXAKycnlWUZvnDje10o4yWRXsn1cT/R58UfF74VeB43l8a/EnwH4OijUs8nirxf4e8OoirjcWbV9RswoXPOTxj6Z+T/Gv/BUH9gDwA8sevftV/Ca5mhDb7bwprk3jy5DIQCgg8DWfiORnzkBQOSPrj/PkkiilkaWaOOaZslpp1EsrHJ5aWVXkZjzklyTyc55MoO0bQQo6BUGB3GAOn6DnrmvKreJ2Pnph8qwtK99a1etXsuj/dxw+vo9+x+mZN+zg4Nw7i+IfE3iXNEre0jk2SZXkN9rqM8dieIrb21g97n9rXjn/gvh+wn4XEqeGZfi/wDEudQ3lf8ACKfDi40mzlZcYzeeP9S8HFY3IOJFt5SAc7Tivibx/wD8HHvyz2/ws/ZZuGbLi31T4j/Eu2tAMf6t5dA8KeG9UJzjLxp4mThtolGN1fy/dScZI6k5PHfAHXt9cH0xTFmjeZbZHR7h2CJbq4a4d2wQiQpukZiGG1VUscjArxsRx7xJiNIYmhhb7LDYWldbbSrrEST1tdSTs7eZ+xcP/QX+jzkzhPGZDn3FEqdpc/EHEuYxi3G15TpZA8hw84t7xqUpU+jja6f7M/Ef/gvD+3t42M8XhjVPhX8JbOUMiDwV4ATWdSjRuB/xMviDqni6AyqMHzotLtzuG5UXjH56fFD9sH9qn4zieP4oftE/GHxfZXJYy6Nd+Oda0zw2Q+dyL4Y0G40nw6kfUeWmlqmOMYGKh+HX7In7VHxc8hvhr+zn8afF1pcsqw6pYfD3xJa6Ad+3Y7+JNXsNO8PxRtuz5supRxhcsXAHP6EfC/8A4IUft6+Pjbz+KtB+G3wd0+cK7SePvHlrquqJGfvFdI+Hlp4yHnKM/wCj3l/YPuADMoya4L8W527XznH05Pb/AGmOG1trvDDJPV2fLp5H2Dj9FfwZ99Lwf4Nx2Fs1K2Q1eJYuFvhb+ucRYiUd7r2k/nY/G5Y0R3lSOJJZCTJKsa+ZKxJJaSQLvdiSSzsxJP3jnNK/XLdsks2AOCecngdufX61/Vb8Kv8Ag3M8GWZtbv42/tH+KfEDjY13oXwt8JaT4RtcjBaJfEPim58X3VxESCvmR6Jp0u3DAIWwP01+EP8AwSJ/YD+Dz2l3p/wF0Tx1rNmVYa58WNQ1P4kXE7r92WTSPEVxP4Vt5gQGDWPh+1VW+4FHA9XB+HvEGIs8RHCZfB2b9tXVWpZ2d1DDKrFu26lUg77tH5xxb9PbwMyBVKeR1eJeNsVBctP+x8nqZbgJTj0qYzP6mV1o07qyqYbA4tWd4xkj+Ff4ffCv4n/FvVF0P4V/Dnx18SdWdwn2DwJ4V1zxTPGxOM3B0ayu47SMcFpbqSGJFyzuqgmv1J+Cf/BDX9uf4rG0vfF/h/wb8C9BuAkj3fxH8Rwaj4gEDYJMHhHwYNfu0ulBwLLXNQ8PybgEd4/mI/tt8PeFfDPhLS7fRPCvh7RPDOi2ahLTSPD+l2OjaXaoM4S20/TYLa0gQA4CRxKoAAAwK3QqrnaoGeuABn64r67A+GuXUuWWYY7E41qzdOjGOEovylZ1qz16xq035LY/lbjX9ol4g5oq2H4G4P4e4SoSvGnjs1r4jifNYLpUpXp5VlVKb0bp4jLsfTXwtztd/gF8Cv8Ag3y/Zm8EfY9T+OHjzx58ctYhMck+jW0w+GngKRgAWhbTPDt3d+LbqNXGMz+M44pU4ltAGKV+znwg/Z9+CXwC0JPDnwZ+FfgX4aaUI0jnh8IeHdO0i41Dy8hJdW1KCAanrNyAfmu9WvLy5dvmeVm5r2KivtsvyXKcrVsBgMNhpWs6kYc1eX+KvUc60r9eaoz+OuOvGLxQ8S5yfG/G+f59QlP2kctr4x4bJqU73UqGSYCOFyihJaWlSwUJ6K8nYaEQEkKoJ6kKAT9SBk06iivUPzUKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCME8cdh1Pp6c4yD19O3qX49B2Pfn15Oc9fTNNGeOOoHfuO2PXjJI6YOMnkux6Dse/Pryc56+maX4/lo/nqvx/JLZP0169N9OvX0+5aKKKYwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBkjbVJHU8DAJOT0wByT7ZFf5/H/BVn9oFP2jv25vjJ4l029F94S8A6lB8HvBUkcpltn0T4eT3Wn6te2rglHg1bxlceJ9VgkTiW2vLZiSACP7NP+Chn7SMP7Kn7Ivxh+LcF3HbeKLbw/J4W+HsbNiS5+IXi/OheFjCgIM39l3d2fEF3EMf8S3SL2UnbGcf53f7xizzSyTzSOZJp5XMk08zuZJZppG+Z5ppGZ5XYlmdixJJNfk3idmaVPAZRCWs5PHYlJ7QjzUcNF91KTryaezpwfU/0+/Z1eHM6mL418VcdQ/dYalDgvh6pODcZYnEfVs0z+vTutJ4ehDKMNCrG6lDG4yk2nGadvPvx/8Aq/wH5UlFFfkCV3buf6lBWhpOkarr+q6ZoWg6bfa1rmtahZ6Ro2jaVbSX2qavquo3EdrYaXptlAGnvL++uZY7e1toUaSWWRVUZIqpb29xd3FtZ2dvPeXl5cwWdnZ2sMlzd3l3dSpBbWdnawK891d3U8kcFtbQRvNPNIkUSPI6qf7Ev+CRf/BKdP2erDSP2lf2iNFhm+O+sWHn+BfA9/GlxD8G9H1CDa15qMTGSKT4mapaSNDfyozJ4SsZZdHtXbVJ9Tnj+i4fyHF5/jY4XDp06FPlni8U03ChSb36c9SdmqNNNOpJNvlpQqTj+M+OHjbwv4G8IVuIs9nDGZvjI1sPwvw3TqqGNz3MoQi1FWUpYbLcI506uZ5jKDp4WhKEIKtjMRg8LiPfP+CTv/BOWy/Y0+Gcnj34i2Vle/tF/E3TbZvGFyhjuU+HvhtmgvbL4aaLeKZEke3uEivfGWpWriDWNdjitoXn03RNNnl/X2kVVUYVQoHQKAAPwHFLX9E5fgMNlmDoYHCU1ToUIKMVvKUt51JysuapUk3OcrK8m7JKyX+BfHfHHEfiPxXnHGXFeOlj86zrEvEYidnChh6UUqeFwGCouUlhsBgcPGnhsJh4t+zo0488qlRzqTKKKK7T5EKKKKACiiigAooooAKKKKACiiigAooooAKKKKAPF/2jfBlt8RfgD8avAd3EJoPGHwp+IXhpoyjSFm1nwnq1jEVRVcl0mmjkQhCQyAjnFf5p8cqpDB9okjjkaKIlZJFBLsq5xuILEscdMk9Rk1/qKyxxzRyRSoskUqPHJG6hkkR1KujqeGRlJVlPBBINfPvgn9kn9lz4b3g1LwF+zv8ABbwlqYme4XVdD+GvhCx1VJ5HMjypqcWki/Ry5LZW4GDjGAAB8VxXwpU4krYCpSxdPCfVY14VZTpSrSnGpKlKCjGM6a9xxqfFNfHp1P7D+jD9KHAfR+yfjbLsx4WzDin/AFjxeT47LaGEzPD5ZQwmJwFDH0MY8TWrYXGTisVCvglGVHDVZJYZqUV7p/A18Ev2I/2tP2iprT/hUPwD+InibS7x1WPxVfaM/hPwSqnBMjeMvFzaJ4dlRVJcpaX91cMqt5cEjAKf3E/Zs/4N4davTp3iD9q/4uw6ZasYp7j4b/Bgi5vnQrvNrq/xE8RaekFuQ+Ybq20HwvcMVLG019W2yj+qBLeFNuyMKFxsAztQDoEXO1QM8BQAO2OKmrmy3w7yTByjUxkq2Z1VZ2rv2OHutn7Ck+aXnGrWqwa0cWe74hfT18YOLKdfBcKUMo8PMurKUPa5VTebZ+6ctOWWc5lS9hRko25a+X5TgMTTleVOvF2a+cf2ev2S/wBnj9lnw63hz4F/Cvw14CiuYo4tX1ezgk1DxX4hMQBWTxJ4v1WS98Sa6wYeYkeo6nPb2zsy2kMEeEH0Yqqg2ooUDsoAH5CnUV9zRo0cPThRoUqdGlTXLClShGnThHtGEEoxXkkj+L81zbNc9zDE5tneZY/OM0xtR1cZmOZ4vEY/HYqo9PaYjF4qpVr1p205qlSTSSS0SQUUUVqeeFFFFADWRG+8qtwRyAeD1HPbr+Z9aYIYlztQLnI+XK9f90j/AOt26CpaKAOG8W/DD4bePoHtvHXw/wDBPjS3eMxtB4t8K6F4khZCCNpi1mwvUK8ngqRXxt46/wCCWP8AwT8+IUk8+ufsrfCuwubgOXuvBmm6j8OrnzGbd5gl8A6n4bBYHuyEcAYIOK/QKiuSvgMDilbE4PC4hP8A5/4elV/9LhI+kyTjLi/hqUZ8OcV8SZBKOsZZLnmaZU110+o4qh2PxJ8Xf8EC/wBg/wAQGZ9AtfjF4AkdWMS+GPifcanbxNn5QIPHWjeLmZAMYDTE44LDrXzF4p/4NxPhpcmZvA/7T3xG0ThjBD4u8CeEfFiA87Ukn0XUPBUjD1YRAkds4A/pTorxq3CHDVe7nk+Ejf8A58qeG3/7B50j9byf6U/0hMj5fqXirxPXUbWWb1cHxBe3d59hMyb87vXqfySeJv8Ag3N+OFo0h8G/tI/CvXkAJjXxN4M8W+FXfvhn0vUfGCqT04VgPQCup/ZV/wCCCvxg8H/tD+A/FX7Sev8Awm8SfBvwXqS+K9U0bwZrniLVr7xjrOiTRXHh3wzqGm634T0OKHw9d6mIL7xA7XVx9s02wm0YQEam09v/AFZVHJIsS7mP0/8Ar+w7muKnwFw1SxFLEQwdVOjUhVjTliq9SlJwlGajOFWdTng3FKUG+WUbxknFtP7LGfTZ+kJj8lzPJMbxTllalmmX4rLauYUuHcoy/NcNSxlGeHq18Di8rw+BjhcZGnUk6GJjQlUoVHGrS5asITj8nfts/tR+Gf2PP2cfiB8a9d+y3V9omnHSfA/h+eTyz4r+IWsxy2vhLw3EqlXeCe/H2/WGhw9l4f07V9R5WzcH/O18V+KfEXjrxX4k8b+L9Vudd8WeMfEOseKfE+tXbFrnVdf17UJ9U1a/mPY3F7dTSLGMRwoViiCxxqo/Wb/gsX+3Qn7Wfx+Pw98A6z9u+BnwKv8AVdD8NXVnMr6f438eOxsvF3jtWiYw3mnW0kDeGfCM4MkTaVa6hrFo6x+JJkX8gQvIGMDj8O56/j/9evzHjnP45xmawuGnz4HL3OjTcXeNau2lXrp7SjeKp0ndrkg5xaVVn+jP0NPBCr4UeG/9vZ7g3h+NeP4YTNMzo1qajicnyOEJTyPJJqS56Nd0q9TMsypfu6kMXjI4LFQc8rpyU9FFFfD2u+1/ktT+vn93/BCiilAyQKqEdbvZLv5dfl6dAEpRnPHX6ZpxxwB+fOOuAAMnqRzjJ6nnJr7V/Ye/YV+L/wC3N8TF8IeArV9B8C6Dc2kvxK+KuoWUtx4d8E6ZORItrDhoU1rxlqMCv/YPhi3nSWcg3+pTado8FxfDrwuFxGOr0sLhaM62IrzVOnSik5Sk9Xe7tGKjeUpyahCCc5tRTZ4nEnEmQ8H5HmXEvE+aYTJciyjDyxWYZjjanJRoUotRjGKSlUrV61SUKOGw1CFXEYrEVKWHw9KrXqU6cuf/AGNP2NPi1+218WrH4a/DWyaw0awa0v8A4ifEO+tJZ/Dfw+8NzSlH1C/dDGt9rt8sc8Xhvw3HMl3rN6jM7Wul2mo6haf3hfs6fs6/Bb9i34J2Hw4+HVnYeF/Bvhaxudc8VeKtcubS31HxBqkdosuv+OPHGvTLbQTX9xFbGe8vLhoLDS9Pt4bGyjsdJsLe2ht/su/su/Cb9kb4UaN8I/hFoKaXounH7Xq+s3fk3HiTxl4gmiiS/wDFPizVEhhbUtbv2jUMwSOzsLVLfTdLtbPTbS1tYvT/AIl/DHwD8YvBmrfDz4neFtK8aeCNeFqut+Gdcie40nVo7K7gvreDULVJIlurdLu2gma2mLwStEqzRyJlT+8cMcLQ4fws6zjSxGb16b9pVm3GnTuk1hqc1CUoUlJJ1akYOdVrmcLRp04/4ifSN+kvj/HTiXDZVSqZlkHhXlGZU5YHKsNTp1czzGMKnsq3EOa4WeKw+GxeaPDyqvK8sq4ung8upz9isR9Yr4vG1f46P+Ctv/BUe4/as168+A3wN1m5tP2b/DGpj+3PEFtJLaSfGzxDpkyvBfuu2KYfDnRrqJZvDenTon/CRagkfiXUYjBDodvZ/h+oHJPJ46/z/E9D6d+uP9Eif/gnh+w3Noeo+Hh+yl8CLfT9U0650u6ez+HHh2x1JbW6heGVrTW7Oyg1nT7xUbNvqNhf22oWkqpPaXUM8cbr/Jd/wUz/AOCWPjL9ijWrj4kfDk6z44/Zp1q/SG0126DX3iL4W399OkVl4c8ezRJGlzpV9cSLaeHPGSxQ299L5ek6zHZay9nJrX5/xdwzxDGdXO8biKOYp39t9WjUjHBUo2VOMKNS7WGhd+/FycXepW1lOo/7n+ir9IfwNxGHyzwd4PyPM+Aa1GEXkr4kxGAr1eMs1rRj9fxGLzPBuNKXEeNnThOOGxEadPEU40cBlPLSwuEy6n+RdFIDksOhUlWBxwR9CR9PbnvS1+dbPt6br8j+72raMKKKKLtWtpbzvf8ATsNK/W233bf5C5+ncHp3z/Q/Tp7UE5/z7579Pw/xpKKcW01933/0vU0lrHdaWv8Ahs+nfzFBI/z7Y/8A1flzX9h//BATWPhz46/Zc8SaVceCfBB+JPwg+JmtaDdeKY/CmgR+K73wv4ptrbxb4audR8QR6eusXxhvL7xDo9rLdXczx2ejQWyv5duip/HeOo/p1/Cv6F/+Ddn4kton7Q3x2+Fk1yUtfHvwl0rxjaWxYgTat8O/FEent5a95W0zx5dSMQGJitBkqqV9nwNilhuJMFGVuTFwr4aXMtnKn7SlZNaP21Kmk97yaT6P+Uvpn8O1eIPo+cX18NUrU8Xw1iMn4koKjUqU3Up4XH0sBmMKrg1z0VlGZZhVnTleEp06cpL3E4/16mKNgVZQQexJI49ient0/IU5UVfuqq/QAZ+uOtOHIB9aK/oM/wAHwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCMZ446gcE+mOgz1B6nHHb1L8e3OD36d8Z69fTNMXtx1A6n07DtkHkkZxyBz1fj25we/TvjPXr6Zpf1+O/XXt38uiWyfpr16b6devp9y0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFNZlQFmOFHUnoPrTq8D/af+PnhL9mL4D/ABL+OXjJll0j4feHLrVIdNEyw3Gva7MyWPhrw1aM2QLzxDr91p2kW5IYRPd+e6mOJyM61WnQpVa9acadGjTnVq1JaRhTpxc5zk+0Ypt+SO/K8sx+d5nl2TZVhauOzPNsdhcty7B0I81bF43G16eGwuHpRur1K1erCnFNpXkrtH8w3/BwR+1J/wAJv8XfAf7K/hvUBJoPwis4/HnxBS3m3xXPxF8Vae0Ph3SrlVYgyeF/BtzJfhGAKy+MWRlElqCv87oBJrtPiT8QvFXxa+IXjb4oeOL46l4w+IPijWfF/iS8+bY+q67ey3txDbq5JisbISLZadbglLawt7a2j2xwqo45T+J4GPQdsnHr+QPOcYH8x51mU86zbGZhNtRrVX7GD3p4eFoUKdujjSjHna0dRylvK7/6NvB3w5wfhP4acJcB4R0qlXJcspvNcVSXu47PcbKWNznGKTUZzp1cwr4hYbnvKnhI4ejflpRSkrovCfhLxT488TaJ4M8D+Hda8XeLvEuoQ6V4f8NeHbC41XXNY1GckRWmn2Fqkk07kfPLJhYbaFXnuJIoI5JU+sv2P/2Av2kP21NfhtPhT4Rex8D214LbxF8XPFUVzp3w80ERshuYYdSWJp/E+tRI4Meg+G4r+8Vyn9oyaZas17H/AGZfsMf8E3vgN+w54dE3hOxbxn8WtWsltvFvxg8S2dt/wkWoqwU3Gk+HLRTPB4P8LNMpdNF0yaS4vMRS63qesXMME8XscPcHZjns4VpRng8tunLF1Y2lVimrww1OTi6zeq9ppRhZtzlOKpz/ACTx6+lVwB4J4XFZXh61DizxAdNrCcLYDExlSy6tKP7vEcSY2l7SGWUIXVT6klPNMUnBUsNToVJY2j8R/wDBLr/gkLo37Nh0X49ftGWWkeKfj60SXnhbwkrQap4Y+DYni/1sU37y1174ixo5iuPEUAbTvD+6S18NvPP5uuXP7yKqooVRgDoMk/mSSSfckmlAAGAMAdhS1+8ZZleCyjCU8FgaKpUYatv3qlWo0lKrWnZOdSdlduySUYQjGEYxj/ih4j+JPF/itxTjeLuNM0qZlmmL/dUacU6WAyvAwlKVDLMqwalKng8Bh+eThSi5VKtSVTE4qriMXWr4ioUUUV6B8IFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADWZVGWIA9SQOpx39yK/n7/wCC2v8AwUSj+CfgO8/ZW+EOueX8YvibojJ8Qtb024ZL34Z/DTV4Xhmtop7dlmsfF3j2zaW00351utL8MPqGsqlvcahoF2/31/wUa/bw8F/sNfBS68T3P2DXfiz4wjvtF+EPgG4kBOu6/FCn2jXtahRluYfBvhUXEF/r11EY3upZLHQ7WaK/1a3ki/gd8ceN/F3xO8Z+KPiH4+16+8UeNfGmt33iLxP4g1KTzLzVNX1GUy3Fw+MJDBGClvZWcKR2thZQW1lZxRWtvBGn5xx3xSsuoSyjAVP9vxVO2JqQfvYTDzS91NfDXxEXaK+KnSbqe7KdGT/v76FX0bZ8e53h/FXjPAP/AFI4cxqlw9gMVS/dcVcQYSonGu6c1atkmSV4qpiJNOhj8zpwwDdejhc0w8eYSNFVVVEjVY0jVY1CIqoAFAA9Bxnv6YxUmB6Yx/8AX/xJpaK/D7vf0/Cz/Tbtof7G80m9N389dLvXfbd3sgooo/z/AJ/z/wDWcU212T39CWrb7rp/WgUf146ZPXtSMyqpZmCqoJZmIVVA6kk8AAc8479hmv3i/wCCbX/BGrxp+0TJoPxn/aY0/Wvh98CZPs+qeHvBb/adH8d/Fi0cLPazyZCX3g/wFephn1ORYPEXiC1cHQ4tOsbi38QH1ssyvHZxioYTAUXVqSs5zd40qMG0nVrVLNQpq++rk7QpxnNqL+C8R/Evg3wo4axHFXG+bUssy6kpQwuHilWzPN8Yoc9PLsowKnGrjcbVVrRi4UaFNvE4uthsJTq4in8gf8E+P+CbvxW/bo8Yw3yR6h4G+A+gaolt43+Ks9nxeS27RyXfhHwBFcr9n13xbNE2y4uis2jeGI5Fu9Zea5NlpGof3HfAv4EfC79m/wCGnh34TfB/wrY+EfBfhqApbWVopku9SvplT7fruv6jJm71vxDqsqfaNU1i/klu7ubALpBHBDF2fgbwN4S+G3hLQPAvgbw5o/hLwj4W02DSPD3hvQLGDTtH0fTrYEQ2tjZ26RxxICzPK5DTTzvLPPJLNLJI/W1+8cNcL4Ph6g3D9/jq0EsRi5xtJp2bpUYtv2dFSSbXxVJRUqjdoRh/h/8ASC+kfxb475zGOKVTI+CssxE6mQcJ0K7nSpytKnHNM4qxUI5jnNWlJx9q4LD4CnOph8BSpqpiq+LKKKK+oP5zCud8VeFPDfjXw9rfhXxboWleJfDfiLS73Rtd0LXLG31PSNY0q/hkgvNN1Swu0kt72xuYZHjmtp0eN1OSAwVl6Kik0pJxaTTTTTV009Gmno01dNPTvcunUqUalOtRqTo1qU4VaVWlOVOpSqU5KcKlOcWpQnCSUozi1KMknFppM/hm/wCCqP8AwTO1n9i3xp/wsn4Z2eqav+zR431Qw6PdTPNqF78KfEd6Wlj8CeJb6QvNPo96d48FeILt2ku4Im0PVZ31izgvNa/IgV/ppfE74a+Cvi74D8VfDb4ieHrDxX4K8Z6LeaD4j0HUo/MttR028TEiAgrJb3kMgju9P1C2eK902/t7W/sp4Lu2hmT+Bb/goH+w/wCMf2GPjhd+BNQOoa38MvFQvtd+D/j27jB/4SPw1DOi3GiatPEkdsnjLwi9xb6d4jt4ljW7jl07XraCGy1i3ii/DON+E1lVV5nl9O2XV52q0YrTBVZNJRS6YerJ2pdKU/3TaUqMX/s59D36TsvFLLYeHXHONjLxCyTBueV5niJqM+MMnwsL1Ks5OyqZ9llJc2YRX73McJF5oozqUM0qU/haiiivzs/uuLs7/IKByQPWipEHfn9MfT1759OnpTTs0+w5SurW/H8+/wDwwqr6+3Hbjv7859vwNfpv/wAEcvGB8Gf8FFfgCxl8q28W/wDCeeBLwZISZPEHgDxDNZROPl3f8TnTdLkUHI81IzjcBX5l19a/sC6w2gftwfsk6mHKBP2g/hhYysCVPkaz4kstEuFJHZ4dRkQjoQxBz0r1MlrSo5zlVZO3JmGCk32isTS5vvV0/U/O/FrLIZz4V+JWVVI86x/AXFuGirXftKmRY5UpL+9GrySi+jSP9FCMkxoT1KKTjpkqDxT6ag2oq+iqPyGPQfyp1f1Gf83AUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGpPHHYdT6Dt2yO5HTtz1fj25we/TvjPXr6ZpiknHHYdT9OnbIPUjp0HPV+PbnB79O+M9evpml2/rru97PstPQldPlru3tvp12fp9y0UUUygooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAA/5/wA4P8q/k1/4L1ftTat8T/iZ4J/Yt+Fiah4ltfA1xZ+Ovijp/he2vNavNV8eahavF4O8KPZaXDdXFy/hnRb241y/tVhkxfa/o4ZEu9Nwv9ZVcno3gLwP4c1DVdW8PeDvC+g6rrt9c6lrmqaNoOlaZqOs6heOZLq91W+srWG61C7uH+aa4u5ZpXIG5ztGPEz/ACvEZzl88uo4z6jTxE4LE1lSdapLDxfNKjTj7SkourNQU5ubSpqUOSSm7fr3gj4kZL4S8eYLj7NOFHxhjcjwuKnw/llTM45Xg8PnWIgsPQzTF13gcwnVWAoVMRUw1CnQjNYyVDExr0pYaPN/B58Cf+CSf7dvx6uLKbTvgxqHwy8N3Tx7vFvxmnbwBp0MMhDefH4euYLvxxfrsLFPsXhmWFzgGaMZZf36/ZV/4IHfs9fCuTTfFH7ReuXv7QfjC2MVyfDTW0vhj4S6ddABtn/CO291NrfixYJQMP4j1ZdKvIwwuPDSbyo/fJERMhF25JY9eSep5Jp9ePlXAmRZY41KlKeY142aqY1xnTjJW1hh4xjR3Sa9pGrKLStI/XPEr6a/jZ4g0cRl2BzTCcB5NXUqdTBcIQr4XH16UtOXE59ia1fNVJxvGo8urZbSqxbjOi1oYXh3wx4d8IaNpvh3wroek+G/D+i2kOn6PoWg6faaRo2k2MA2w2Wm6XYRQWVjaRDIjt7aCOJASEUA1u0UV9kkkkkkkkkklZJLRJJaJJbI/kipUqVak6tWc6tWrOVSrVqSlOpUqTblOpUnJuU5zk3KU5NylJtttsKKKKZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFfLX7Xv7Wvws/Y0+DWufF74oXzOlvu07wj4RsbiGPxF4+8VzQzPpnhjw7DOCrXNw0bXGo38qNZ6JpUN1q1+RBbbJe1/aJ/aE+F37L/wn8T/ABk+L/iGLw/4O8MW4LFdk2ra5q1wHXS/DXhrT2ZJNX8Sa1cp9l03TomUMfNubmW2sbW8u7f+BH9tz9tP4n/txfGW9+JXjt5dG8M6Y1zpnwy+HVrdyXGj+AfCstwrrAhASC+8S6wIYLzxV4g8tJdTvkjgt1ttJsdMsrX4/i3imlw/hfZUHCrmmJg/q1F+8qMW3F4mtHpCLuqUHrWqLlScI1JR/q76Ln0ac18deI3mWbwxWW+G/D+Kp/6wZtBSo1c2xMVCtHh3Jqrtz4zEU5QlmGKpqUcqwVRVZtYrEYCjiOK/aj/ad+KP7Xfxi8R/Gb4sagk2saswsND8P2Lzf8I94I8K2ssr6V4R8M20zFoNP08SyS3d24+161qs97rGoO95eSbfn5B3/wAjr+vT86YB0468D05/DHHt0/CpVGB0/Hjnv26jn2+gr+f61WtiK1TE4mpOtWrTlUq1JtynOpKWsm3u23ddEtElof7o5RlGV8P5Vl2R5HgMNleT5ThKGAy3LsHSjRw2DwmGhGnRo0qcdowhFXbblKV5zlKcpSbqcAMEn04+vPTn27jnmm0hYKrOzqqICXd3CIo7ksxAGM5P196zUVe7tayfL16brtf+rHfyq+i66eTdl8+rt8luSfLjg9c8HrwCO3TOen4c123w3+GfxB+MPjPRvh38LPB2v+PvG/iGbydJ8NeG7GS+1G4CkeddTgbbfTtLtFPnajq+pTWml6bbq1zfXdvCrOP0m/Yl/wCCRH7SP7XEmk+L/EOn3XwR+CV00N03j7xhpU6+IPE+msVkz8PfBl01nf6tHdRE/ZvEOsHS/DZG6eyutZeF7J/7AP2Uf2Kv2f8A9jXwZ/wifwX8HQ6df30UI8U+OtYaLVfHvjS4hwRceJPETwRSyQrJmS20fTotP0HT2LNp2l2jSSl/tuH+CMyziVPEYuMsvy73ZKpOK9viIOzth6MrWi1tWqpU0mpU41rOJ/Hfjt9Mbw+8JqeLyPhueF4649pe0ovLMBiubI8kxKVubP8ANaHPCVWjO/PlGAlVxzlCdDF1Mrc6eIPyq/4J3f8ABE3wZ8Ep9A+MX7VUWh/Ev4t2ptdV8P8Aw6hEeqfDT4c3q7ZoLnUPPi8rx54wsJAvl39zAPDGkXKs+k2OpXUNnr4/oERFQYXIHpngfQdAPYAD0FKAFAAAAHAA4Apa/bMrynAZPho4XAUI0aas5y+KrVnazqVajXNUm/O0Yr3YRhBRiv8AHTxH8T+NvFjiKtxNxxnVfNsfJSpYSgv3GW5ThHLmjgMoy+D9hgcJFpOUaadbEVE8Ri62IxM6laZRRRXpHwAUUUUAFFFFABXxz+3B+yB4I/bS+A/iX4QeLBDpmrsp1z4d+MhbrNeeBfHmnwzro3iCALiWXTpRNJpXiHS4njGq6BfahaK8V01rdW/2NRWOJw9HF0K2GxFONWhXpypVactpQkrNaap9U004tJpppM9bIc+zfhfO8q4iyDH18szrJcdh8xyzH4eSjVw2LwtSNWlNXTjOLlHlqUqkZ0q1NzpVoVKU5wl/mW/FX4XeOPgl8SPGfwl+JWiS+HvHHgHXbvw94i0uQs8aXdsQ8N7p9w4X7fo2rWclvquianEot9R0m8s72AmKda4Gv69P+C6v7CifFD4bxftb/DfRWl+Ifwi0j7H8T7DToMz+LPhNbu8x1uWOIb7nVvhvPPNqDzMDLJ4QudaSaWSPQ9Lt0/kJVgQCCCDggggggjIORkHI54J4weM1/NnEmR1chzOrg5c06Ev3uErSX8XDzb5G3p+8g06dVWSVSDaXJKJ/0F+AnjDlnjb4c5XxfhVQw2c0f+EvirKaU21lefYWnS+sxpxnKVRYHGwqUsfl8pym1hMTTo1KksTQxCg6pUHH+f8AP/181FUqHjHucfp/j+v1rwD9nH19D/shCQ/tafsuiIOZf+Givgr5YT727/hY3hw5H0GTkelfPFfXf/BP/Q38Rftyfsk6WiNJu+P/AMNtSkRQxY2/h/X7fxDdNhcnbHbaVNI5IKhEYtgZI78ri55lgILeeNwkUu7liaSR8px5iKeE4F42xVVpUsNwhxJiKjeyp0cnxlSbd9LKMXc/0TFGAOo+vWlpkZ3IhHdQeueo9eafX9Un/NClZJdlYKKKKBhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMBPy8DGBwT6e2eoPU446Dpy7Htzg9+nfGevX0zTB2OByAOT6dh7g4JI4HIHPV+PbnB79O+M9evpmjt/XXrvqum197dSVsn5LXq9t9Hv116b9looooKCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvHfjz8ePhh+zZ8LvE/xg+L3iW18L+CvCtr515dSsHv8AU72UFdP0Hw/YZWbWPEOsXIWz0rSrQme5nYsWhgiuLiGX46fHH4Zfs5/DDxR8Xvi74ns/CfgfwnZm61DUbl1NzeXLZWx0XRbLPnatr2r3G2z0nSrVXuL26dUjAVXkj/gp/wCCgf8AwUE+J37eXxT/ALc1n7b4V+EfhW+vIvhZ8Lo7ova6JZSt5L+JPEYhc2uq+OtZtlQ6nqAD22l27/2PpBSzSee8+U4o4ow3D2GUYuFbMq8H9Vwrd+VX5frFdJqUaMHflirSrSi4QaSqVKf9PfRq+jXxD49cQutVWJyfw/yXEU1xLxJGmlOrNKNVZHkjqxlSxGb4qk4upVcamHyrDVI4zFwqTqYPB47R/wCCgH7f/wATP28fikPEGti78K/Cfwpc3kPws+Fy3fnWmgWUx8mTxF4gMLG11bxxrVuFGp6iFa3062K6NpBWyjmnvfggADjtnJ/rj/PWq6ugkSEOhlZgkcSsHldyQFRIk3SOxLAAIpJzgZr69+DX7B37Y/x8NpL8L/2c/ijrml3rL9n8Sax4ffwT4RdGxiWPxT43k8O6JcRAHcWtLy5faCVQkYr8IqSzHOcZUryjiMfjMRNyn7OnOrOTdkrQpxfLGMUowjGMYU4JQilFI/2+wOE4B8I+EstyahieH+B+EckwqwuCjmOY4TKsDShC9SrUq4zMK9JYjFYipKeJxWJr1qmJxWJqVcRXqVK1Wc5fKdMd0QbndUX1dgoySAB82OSTjHXPav6J/gR/wbyfGzxI9lqf7Q/xc8IfDHS28uW78L/Du2n8f+LymQXtJ9b1KPRPCuk3BUMguLOLxbAhIISUcN+7H7Nn/BK/9iz9mF7DVvCPwpsvGnjiwKSJ8RPipJF468UpcoVYXemR6jbx+HvDlwrqGSXwzoOjSrgBncjcfp8t4Bz7HOMsTTp5ZQerniZKVZrS/Lh6Tc+bTarOh6uyv/NfiH9OXwR4Lp1sPkGOx3iJnEFKMMJw3RlQymNVbLE8QY+nSwboy6V8qpZx/wBemfyE/stf8EwP2v8A9rKTTtT8H/Dq58C/Dy9aOQ/FD4oxXvhTwtNZsx3XOg2M9pJ4k8XKyq4gk8P6RdabJKojuNUtATIP6g/2Nf8AgjD+y/8Asxto3jHxvp7fHr4vac8V0nirx7p1ofCeg6hF8y3Hgz4f+be6Rp8sMgSS01XX5vEOu200S3FlfaezeSn7BRQxQqFjQKo6DJO3jGF3E7RjgKuABwABUtfpWS8E5Nk7hWlTeYYyNmsRioxcYSVtaOHV6dOzScZS9rVi1pVP85/F76Y3i54qU8TlWGx0OBuFcQp0p5FwxWrUcTjMPNOLpZxn0uTMcfGcG4V6GG/s7LsRH+Nl8mk1GkSR/cGOMAZOAM5wo6KPQAADsBUlFFfYn8nhRRRQAUUUUAFFFFABRRRQAUUUUAUdSsLPU7G60/ULW3vrK9t57S7sruGK5tby1uYZIbi0ureZWhuLa5hkkhmgmV4pY3ZJEZSQf4CP+Cm/7GVx+xb+03r3hPQ7K4j+Efj9bvx38H7xhI9vbeHry8ZNX8GNcyFvMvvAuqyNpJVne5l0Kbw9qVztl1Igf6AtfmH/AMFYP2PU/a3/AGVPFOn+HtLF78Wvhf8Aa/iR8KpIYw1/f6tpVi58QeDYWAMrxeNtAjuNMgtQyQtr0Hh69mz9gWvkeM8iWd5TN0oc2OwKnicI0vemkl7bDrRt+2hH3V/z+hSvpe/9T/RH8aJ+EPijgaWZ4p0uDOM54XIOJ4VJ8uGwk6tVwyjPZp+7CWU4ys44iq78mVYvMrRlU9ly/wAFdSIeoz9P8/l/TvTARgjDqcAlZFKOpzgo6MS6OvKujgOrKQwBBAOR6cYPXPTPHHr3/DOK/nZJt2/qx/vK1yqS76p9WtGtfmtOmu5PX6u/8EUfAUnjf/gob8KL8wNPY/Dnw18RfiHqDBQywiz8KXvhXTZHJyEA1vxdpmxio+cDa6sBX5QbhjPt09/T86/p+/4N0fgxM0/7RP7Ql/aMLdk8O/BrwvdumEkeMp4z8cLFId2Qpl8CozIRllkjYZQivpeD8HLGcR5XBL3aOIWKndbRwieIu7rROcIQ83NJbn8+fSk4ppcI+AfiVj51VTrZlkFXhnBxvadXE8T1aWRuNLvOjh8dXxUktVSoVJ7RbX9RSDCIPRVHPXgAc06iiv6SP+fYKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjGeOOoHBPpjoM9Qepxx29S/Htzg9+nfGevX0zTQTxx1A6n0HYeo4JI6cgc9XY9B2Pfn15Oc9fTNL+vx366rptf8AKVsn5LXq9t9Hv116b9loooplBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHw5+1f8A8E/PgX+2lrHhe/8AjxqvxS1nRfB1uy6D4G0H4gah4Y8D2+oyyTNceIJtE0m2hku/EM8Ev2FtWuL17iGwH2SzNtFJMJfHvCn/AARl/wCCb/hMxSRfs5ab4gniC4m8YeNPiJ4oV2XHzS2eq+LJtOkJwNytZlDzlSDiv1EorzamTZTWxE8XWy3A1sTUac69bC0a1WTilGN51ISl7sYqMVe0UklZI/Q8t8W/FHJckw3DeS+IfGeS8P4ONSOGybJuI82ynLqSrVJVazWEy/FYai5Vas51KspRlKpOUpTcm2zwH4c/srfs1/CEwSfC/wCA3wi8BXNsAIdQ8LfDzwrpOqrgYBbV7bS11ORsYy8l2zEjcSTXvaoF5BbOMfeOOuR8v3QR0GAOODkU+iu6nSpUY8lGlTpQW0acI04/+AxSX4HxWYZpmWb4iWMzbMcdmmLl8WKzHF4jG4mV9XzV8TUq1ZXbbd5u7bCiiitDhCiiigAooooAKKKKACiiigAooooAKKKKACiiigApjoHAByMEEEHBBHI/DOMjv34zT6KAP4SP+Cw/7Jy/sxftc+INZ8OaabL4YfHhdQ+J/gtYYfL0/Stdu77b8RPClsUVIIhpfiO5XW7S0gRYrTRvEul2sWVtmx+VQ5DZ/TPXJx698dOP1r+7L/gsR+yz/wANKfsc+Mr3QdNN98Rvgq8/xc8DGCLzL68g0KymXxv4ctyuZZBrvhI6hJb2cYP2rW9M0PIYxKK/hFWRXVXQh1cKyEEYZXG5T1PUc9weMe388ca5P/Y+d1nSgo4THJ4vDpK0YupJqtRjZWXs693GK+GlUoxP97PofeKsvFXwdylZjiXiOJuCpQ4Tz6VSXNXxMMHQpvJszqczdSf9oZW6MK1ebbxGY4TMZX93S3BBc3U8FpZ29xeXl1PBa2lnbRtLc3l5cSLBa2ltAmXmubmd4oIIUBeWV0RFZmWv9DP/AIJ5fs2H9lH9kb4SfCO/tooPFsGjP4q+Ibx7WMvxA8YSnXfE0LyLkTLo91dJ4dtZtzF7DRrPDFQuP5kP+CIv7Dt58evjhb/tHeO9Gkk+EHwJ1q3u/Dxu4SbLxj8X7MQ3mjWUAcbLvTvAkcsPiXVWXMa603hqzbzEe+ij/tEACgBQAB0Ar7fw4ySdDD186xEOWeMi8PhFJWf1aMoTqVbP7NWrCMYXs7UZTV41Ys/jj9oJ4v4XOM7ybwfyLFQr4Xheus84tqUJqdN8QV8NKjlmVSlF2dXKsvxGIxGLhecVXzOjRny4jBVYxWiiiv1A/wA2gooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSeOOw6njj07ZHBJGcdOvV+PbnB79O+M9evpmmrnjjsOp4yB2HqOpI6YIGSMl2PQdj359eTnPX0zS/r7nv116pf0pWyfkter230e/XXpv2WiiimUFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBXuoI7iCSKWNJY3R1eKRRJHIjKVeOSNvkkR1JVkcFGBwwIzX8a/in/gi/8WfG/wDwUC+Jnwe8GaPf+C/2arLxHZ+Pv+Fr3NjJ/Yeg/Drxk7a1F4M8KSXKC313xrpN02peF9O02EPbadBp9trGtmCxkijuv7MKTaM5x2A/I5H49OfYV4mdcP5fnywccdGbWDr+2j7OXJKcJRtUoSmvejSquNN1HBqdqa5JQlaa/Z/Bzx1428D63FmJ4Mq4WFfivIXk1Z42k8RRwGLp4iNXA55h8O2qVbMsspzxtLBLExqYaLx1WVejXpp0Z+WfBT4M/D79n/4YeD/hD8LtBh8O+CPBOlRaVounxnzJ3ClpbvUtTuyBLqGs6teSXGpaxqU5M9/qN1c3MhBk2r6pRRXsU4QpQhSpwjTp04RhThBKMIQglGMIxVlGMYpKKSSSSS0PyHG43GZljMXmOYYqvjcfj8TXxmNxmKqzr4nF4vE1JVsRicRWqOVStXr1ZzqVas5Oc5ylKTbbYUUUVZzBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEak8cdh1PoO3bI7kdO3PV+PbnB79O+M9evpmmrk444wOp4yAMY989TjjkDkZLse3OD36d8Z69fTNL+vxXluun9WlbL5a9Xt677P0+aWiiimUFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAxc8cdh1PGcdB2yMZJGcYIHPV2PbnB79O+M9evpmmrk447DqeOOw7ZzjJHA6deS7Htzg9+nfGevX0zS/r8V5brp/VpWyfkter230e/XXpv2WiiimUFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGpPHHYdT6Dt2yO5HTtz1fj25we/TvjPXr6Zpi5446gdT6DsPUHkkdOQOeS/Htzg9+nfGevX0zS/4f8AH52a6L+lK2T8lr1e2+j3669N+y0UUUygooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI17cDkDqfT29QeSe2DjJ5L8e3OD36d8Z69fTNMHbjsOp/Qds5AJIzjGOvV+PbnB79O+M9evpml2+f57vezXRaei6JbJ+mvXpvp16+n3LRRRTGFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBGpPHHYdT6Dt2yO5HTtz1fj25we/TvjPXr6Zpik8cdh1PHTt2yOpI6YIAzyX49ucHv074z16+maH/X3/mun9MS2T9NevTfTr19PuWiiigYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADFJ447DqfQdhzznGSOmCOvJdj25we/TvjPXr6Zpik8cdh1PHHp2yOCSM46der8e3OD36d8Z69fTNL+vue/XXql/SS2T9NevTfTr19PuWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSeOOw6n0HbtkdyOnbnq/Htzg9+nfGevX0zTFJ444wOp4zjt2yMc46YOORy/Htzg9+nfGevX0zR2/rru97PstP1JWyfkter230e/XXpv2WiiigoKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCMZ444x3Pp+PUHqe2MDpy/Htzg9+nfGevX0zTFJ447DqeOB27ZB6kdMEdeS/Htzg9+nfGevX0zS/r8fnqunff0S2T9NevTfTr19PuWiiimMKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCNSePoOCf5c4yCOSOmDjkcvx7c4Pfp3xnr19M0xSeOOw6njgdu2QepHTBHXkvx7c4Pfp3xnr19M0Pp/XXd72a6LT9RLZP0169N9OvX0+5aKKKBhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqTxx2HU8cDsOec4yR06e5fj25we/TvjPXr6Zpi5447Dv6fpkHBJGcdBz1fj25we/TvjPXr6Zpf19z3669Uv6SWyfpr16b6devp9y0UUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqTxx2HU+g7dsjuR07c9X49ucHv074z16+maYpPHHGB1PGcdu2RjnHTBxyOX49ucHv074z16+maH0/rru97NdFp+pK2T9Ner0Xra/X0v5i0UUUFBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUARqTx9B1Pf25xkHrjp0Hu/Htzg9+nfGevX0zTFzxwOg6n6dO2QRk4zjHr1fj25we/TvjPXr6ZofT+uu73s10Wn6kro+9td3030621+/wBFooooX9f8HaxQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEa54+g4J7+3bI6nGcdByOX49u3ryM8kE9evcZpik8cdh1PHA7dsg9SOmCOvJfj25we/TvjPXr6ZofT+tn131XRafqJbJ+mvXpvp16+n3LRRRSW39f5L8v8hhRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAIwenHYdTx+HbIOMkdOgGeS/Ht29eRnkgnr17jNMUnjjsOp9B29weuM4wcc9X49ucHv074z16+maXbT+k93vqui09Oou2nb16b6ff6fctFFFC/r+rIYUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCMHp9B1Pf0GeMg9cZx0HPV+PbnB79O+M9evpmmKenHUDqf054yD1xkDoOer8e3OD36d8Z69fTNJ+i2/XrvZrpt6dRLp8tevTfTr19PuWiiihf193XRWGFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjXPHoQOCe/HA56g9fToPd+Pbt68jPJBPXr3GaYM8HAwQBye46D6g8n8cc9X49ucHv074z16+maX3dfwfXfVdFp6LolsvRa7vpvp16/f6LRRRQv6+7rov6+4YUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCMdvcDqePoM984Jx06AZ6vx6Dse/Pryc56+maaM8dDwO/p6e4xk8cfXq7HoOx78+vJznr6Zpfd1/CT33s10V16IXyt+L6b7/PXpv2Wiiihf193XRWGFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAjGeOmCB1Pf2yeueTxx0HI5fj27dc8+uCevX0zzTBnI4HQd+uOmPcHk8cdhnkvx7duuefXBPXr6Z5pfd1/CT33s10V16IX9d309fnr537LRRRQv67v10WowooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAEYPT6Dgn8sc9c9fTGAPV+Pbt1zz64J69fTPNMB5HToOp6+mOeoI5447c9X49u3XPPrgnr19M80vu6/hJ772a6K69EL+r7vpvp16+n3LRRRQtv67ei/L/IYUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCMHkcD7o6n8gOeoPXjjtz1fj27evIzyQT169xmmKeR0+6Op/IDnqCOeOO3qX49u3XPIzycnOfyJ5pf8H8Jdd9V0WnouiXT5a9em+nXr6fctFFFC2/r/JfkhhRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAI1JyOB90dT6dAPcEcnHHb1LwPb/Hnk/5zTFPI4xlRkEg8gcdO4IxkfkKk/DFLt/XXd76rptfe3Zfh59enrvbXV7bt7FFFFMYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFB6H+vT8aAGL2P+yuRnpx9MH049+KfTQV7EdMdeePb2Byfr0pcj1Hbv6/549aAFopMg9CD+Pp1/KjP09uf8+o/OgBaKMj1/yOtGR6j/P/AOsfnQAUUZHqKTI9R+dAC0UmQehB/H06/lRkeo/OgBaKTI9R+dLQAUUZHr/kdaMj1oAKKMj1FGR6igAopMj1H50tABRSZHqPzpaACikyPUfnS5HqOenvQAUUmR6j86XI9evSgAopMj1H50ZHqPzoAWikyPUfnS0AFFJkeo/OjI9R+dAC0UmR6j86XI9Rz096ACikyPUfnS0AFFGR6ijI9evSgAooyPX/ACOtGR69envQAUUmR6j86XI9f89f5c0AFFGR6jnp70ZHqOenvQAUUmR6j86XI9RQAUUZHqOenvRkevXpQAUUmR6j86XI9evSgAopMj1H50uR6jnp70AFFJkeo/OlyPUUAFFJkeo/OloAKKMj1/yOtGR69elABRSZHqPzpcj169KACikyPUfnS5HqOenvQAUUZHr/AJHWjI9Rz096ACijI9f8jrRQAUUZHqKMj169KACikyPUfnRkeo/OgBaKTI9R+dLQAUUZHqKMj1/z1/lzQAUUZHqOenvRQAUUZHr/AJHWigAooyPUUZHr16UAFFJkeo/OlyPUUAFFJkeo/OloAKKMj1/yOtFABRSZHqPzpcj1oAKKMj1HPT3oyPUc9PegAooyPUc9PeigAooyPX/I60UAFFGR6iigAooyPX/I60ZHrQAUUZHqKMj1oAKKTI9R+dLkeooAKKTI9R+dLQAUUZHr/kdaKACikyPUfnS5HrQAUUmR6j86Mj1H50ALRSZHqPzpcj1FABRSZHqPzoyPUfnQAtFJkeo/OjI9R+dAC0UmR6j86XI9RQAUUmR6j86Mj1H50ALRSZHqPzoyPUfnQAtFJkeo/OlyPUUAFFJkeo79x26/l3oyPUfnQAtFJkeo79x26/l3oyPUfnQAtITgH1wTjOOn+evajI9R37jt1/LvTSw+YfKeOm4cnpgj36e/A+gB/9k='],
    ];
    for (const [k, v] of keys) {
      const existing = await getByKey('settings', k);
      if (!existing) await put('settings', { key: k, value: v });
    }

    // Default Admin User
    const users = await getAll('users');
    if (!users.length) {
      const adminId = await add('users', {
        username: 'admin',
        password: 'admin123',
        full_name: 'Administrator',
        email: 'admin@redsharkpos.com',
        role: 'admin',
        status: 'active'
      });
    }

    // Default Currencies
    const currencies = await getAll('currencies');
    if (!currencies.length) {
      await add('currencies', { code: 'USD', name: 'US Dollar', name_ar: 'دولار أمريكي', symbol: '$', is_primary: true });
      await add('currencies', { code: 'LBP', name: 'Lebanese Pound', name_ar: 'ليرة لبنانية', symbol: 'ل.ل', is_primary: false });
    }

    // Default Warehouse
    const warehouses = await getAll('warehouses');
    if (!warehouses.length) {
      await add('warehouses', { name: 'Main Warehouse', name_ar: 'المستودع الرئيسي', code: 'WH-01', is_default: true });
    }

    // Default Categories with rich images
    const cats = await getAll('categories');
    if (!cats.length) {
      const serverResp = await callApi('/api/db/categories');
      if (!serverResp || !serverResp.data || serverResp.data.length === 0) {
        const defaultCategories = [
          { name: 'Fruits & Vegetables', name_en: 'Fruits & Vegetables', name_ar: 'خضار وفواكه', parent_id: null, sort_order: 1, image: 'assets/categories/fruits_vegetables.jpg' },
          { name: 'Dairy & Cheese', name_en: 'Dairy & Cheese', name_ar: 'ألبان وأجبان', parent_id: null, sort_order: 2, image: 'assets/categories/dairy_cheese.jpg' },
          { name: 'Bakery & Pastry', name_en: 'Bakery & Pastry', name_ar: 'مخبوزات وحلويات', parent_id: null, sort_order: 3, image: 'assets/categories/bakery_pastry.jpg' },
          { name: 'Beverages & Coffee', name_en: 'Beverages & Coffee', name_ar: 'مشروبات وقهوة', parent_id: null, sort_order: 4, image: 'assets/categories/beverages_coffee.jpg' },
          { name: 'Meats & Poultry', name_en: 'Meats & Poultry', name_ar: 'لحوم ودواجن', parent_id: null, sort_order: 5, image: 'assets/categories/meats_poultry.jpg' },
          { name: 'Snacks & Sweets', name_en: 'Snacks & Sweets', name_ar: 'سناكس وتسالي', parent_id: null, sort_order: 6, image: 'assets/categories/snacks_sweets.jpg' }
        ];
        for (const dc of defaultCategories) {
          await add('categories', dc);
        }
      }
    }

    // Default Chart of Accounts
    const accounts = await getAll('accounts');
    if (!accounts.length) {
      const defaultAccounts = [
        { code: '1000', name: 'Assets', name_ar: 'الأصول', type: 'asset', parent_id: null, level: 1 },
        { code: '1100', name: 'Cash', name_ar: 'الصندوق', type: 'asset', parent_id: null, level: 2 },
        { code: '1200', name: 'Bank', name_ar: 'البنك', type: 'asset', parent_id: null, level: 2 },
        { code: '1300', name: 'Accounts Receivable', name_ar: 'ذمم مدينة', type: 'asset', parent_id: null, level: 2 },
        { code: '1400', name: 'Inventory', name_ar: 'المخزون', type: 'asset', parent_id: null, level: 2 },
        { code: '2000', name: 'Liabilities', name_ar: 'الخصوم', type: 'liability', parent_id: null, level: 1 },
        { code: '2100', name: 'Accounts Payable', name_ar: 'ذمم دائنة', type: 'liability', parent_id: null, level: 2 },
        { code: '2200', name: 'VAT Payable', name_ar: 'ضريبة القيمة المضافة', type: 'liability', parent_id: null, level: 2 },
        { code: '3000', name: 'Equity', name_ar: 'حقوق الملكية', type: 'equity', parent_id: null, level: 1 },
        { code: '4000', name: 'Revenue', name_ar: 'الإيرادات', type: 'revenue', parent_id: null, level: 1 },
        { code: '4100', name: 'Sales Revenue', name_ar: 'إيرادات المبيعات', type: 'revenue', parent_id: null, level: 2 },
        { code: '5000', name: 'Expenses', name_ar: 'المصروفات', type: 'expense', parent_id: null, level: 1 },
        { code: '5100', name: 'Cost of Goods Sold', name_ar: 'تكلفة البضاعة المباعة', type: 'expense', parent_id: null, level: 2 },
        { code: '5200', name: 'Operating Expenses', name_ar: 'مصروفات تشغيلية', type: 'expense', parent_id: null, level: 2 },
        { code: '5300', name: 'Salaries Expense', name_ar: 'مصروف الرواتب', type: 'expense', parent_id: null, level: 2 },
      ];
      for (const acc of defaultAccounts) {
        await add('accounts', acc);
      }
    }
  }

  return { open, getAll, get, getByKey, add, insert: add, update, put, bulkPut, remove, bulkDelete, delete: remove, count, clear, getSetting, setSetting, nextSeq, peekSeq, seed, audit: _audit, purgeAuditLogs, repairDuplicates: _repairDuplicateRefs, syncFromServer, callApi, bulkAdd, bulkSyncToServer };
})();

window.DB = DB;
