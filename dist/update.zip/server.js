// Ring buffer of recent changes for polling fallback across Cloudflare tunnels
const recentRecordChanges = [];
const tableVersions = {
  warehouses: Date.now(),
  stock_transfers: Date.now(),
  items: Date.now(),
  customers: Date.now(),
  categories: Date.now(),
  offers: Date.now()
};

function bumpTableVersion(table) {
  if (!table) return;
  tableVersions[table] = Date.now();
}

function recordSyncChange(table, action, record) {
  if (!table || !record) return;
  bumpTableVersion(table);
  recentRecordChanges.push({
    table,
    action: action || 'update',
    record,
    timestamp: Date.now()
  });
  if (recentRecordChanges.length > 50) recentRecordChanges.shift();
}
/**
 * NexPOS — Local Server
 * Serves static files + exposes /api/printers to enumerate Windows printers
 */

const express = require('express');
const cp = require('child_process');

// Globally enforce windowsHide: true on all child processes to prevent any CMD/PowerShell windows from popping up
const _origExecSync = cp.execSync;
cp.execSync = function (cmd, options) {
  return _origExecSync.call(cp, cmd, { windowsHide: true, ...(options || {}) });
};

const _origExec = cp.exec;
cp.exec = function (cmd, options, callback) {
  if (typeof options === 'function') {
    callback = options;
    options = {};
  }
  return _origExec.call(cp, cmd, { windowsHide: true, ...(options || {}) }, callback);
};

const _origSpawn = cp.spawn;
cp.spawn = function (cmd, args, options) {
  if (!Array.isArray(args)) {
    options = args;
    args = [];
  }
  return _origSpawn.call(cp, cmd, args, { windowsHide: true, ...(options || {}) });
};

const { execSync, spawn, exec } = cp;
const path = require('path');
const os = require('os');
const fs = require('fs');
const XLSX = require('xlsx');

const app = express();
const PORT = process.env.PORT || 3000;

process.on('uncaughtException', (err) => {
  console.error('[Server UncaughtException]:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[Server UnhandledRejection]:', reason);
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// ── Disable browser caching for local scripts & assets ─────────
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// ── Serve static files ─────────────────────────────────────────
app.use(express.static(process.cwd(), { etag: false, maxAge: 0 }));

// ── Mount Storefront for direct self-hosted online ordering & manager app ────
const localStorefront = path.resolve(__dirname, 'storefront');
const parentStorefront = path.resolve(__dirname, '../RedSharkStorefront');
const activeStorefrontPath = fs.existsSync(localStorefront) ? localStorefront : (fs.existsSync(parentStorefront) ? parentStorefront : null);
if (activeStorefrontPath) {
  app.use('/storefront', express.static(activeStorefrontPath, { etag: false, maxAge: 0 }));
  app.use('/shop', express.static(activeStorefrontPath, { etag: false, maxAge: 0 }));
}

// ── CORS for development ───────────────────────────────────────
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// ── GET /api/hardware-id ───────────────────────────────────────
app.get('/api/hardware-id', (req, res) => {
  try {
    const validIds = getAllHardwareMachineIds();
    // 1. If this server has an active license, return that machine_id
    const db = readDb();
    const settings = db['settings'] || [];
    const rawLic = settings.find(s => s.key === 'license_active_data')?.value;
    if (rawLic) {
      try {
        const lic = typeof rawLic === 'string' ? JSON.parse(rawLic) : rawLic;
        if (lic && lic.machine_id && validIds.some(id => id.toUpperCase() === String(lic.machine_id).trim().toUpperCase())) {
          return res.json({ success: true, machine_id: lic.machine_id });
        }
      } catch { }
    }
    // 2. Return the primary persistent hardware ID
    const machineId = validIds.find(id => !id.startsWith('RS-' + (os.hostname() || 'SERVER').toUpperCase())) || validIds[0];
    res.json({ success: true, machine_id: machineId });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/network-info ───────────────────────────────────────
// Returns local LAN IP addresses for mobile app QR code & connections
app.get('/api/network-info', (req, res) => {
  try {
    const nets = os.networkInterfaces();
    const addresses = [];
    for (const name of Object.keys(nets)) {
      for (const net of (nets[name] || [])) {
        if (net.family === 'IPv4' && !net.internal) {
          addresses.push({ iface: name, address: net.address });
        }
      }
    }
    const primaryIp = addresses.length ? addresses[0].address : 'localhost';
    res.json({
      success: true,
      ip: primaryIp,
      port: PORT,
      httpsPort: 3443,
      addresses,
      mobileUrl: `http://${primaryIp}:${PORT}/mobile.html`,
      mobileHttpsUrl: `https://${primaryIp}:3443/mobile.html`,
      waiterUrl: `http://${primaryIp}:${PORT}/mobile_waiter.html`
    });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/printers ──────────────────────────────────────────
// Returns list of installed printers on this Windows machine
app.get('/api/printers', (req, res) => {
  try {
    let printers = [];
    let defaultPrinterName = '';

    if (os.platform() === 'win32') {
      // 1. Primary: Query Windows Registry (Ultra fast <20ms, zero dependency, works on Win 7/10/11 even if PowerShell/WMI is disabled)
      try {
        try {
          const defRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows" /v Device', { encoding: 'utf8', timeout: 3000 });
          const m = defRaw.match(/Device\s+REG_SZ\s+([^,\r\n]+)/i);
          if (m && m[1]) defaultPrinterName = m[1].trim();
        } catch { }

        const devRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices"', { encoding: 'utf8', timeout: 3000 });
        const lines = devRaw.split(/\r?\n/);
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith('HKEY_')) continue;
          const m = trimmed.match(/^([^\t]+?)\s+REG_SZ\s+/i);
          if (m && m[1]) {
            const name = m[1].trim();
            if (name && !printers.some(p => p.name.toLowerCase() === name.toLowerCase())) {
              printers.push({ name, isDefault: name.toLowerCase() === defaultPrinterName.toLowerCase() });
            }
          }
        }

        // Also check HKLM printers if HKCU was empty
        if (printers.length === 0) {
          try {
            const hklmRaw = execSync('reg query "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print\\Printers"', { encoding: 'utf8', timeout: 3000 });
            const hklmLines = hklmRaw.split(/\r?\n/);
            for (const line of hklmLines) {
              const trimmed = line.trim();
              if (trimmed.startsWith('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print\\Printers\\')) {
                const name = trimmed.split('\\').pop().trim();
                if (name && !printers.some(p => p.name.toLowerCase() === name.toLowerCase())) {
                  printers.push({ name, isDefault: name.toLowerCase() === defaultPrinterName.toLowerCase() });
                }
              }
            }
          } catch { }
        }
      } catch (regErr) {
        console.warn('Registry printer detection failed:', regErr.message);
      }

      // 2. Fallback: PowerShell CIM / WMI
      if (printers.length === 0) {
        try {
          const rawJson = execSync(
            'powershell -NoProfile -ExecutionPolicy Bypass -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Get-CimInstance Win32_Printer | Select-Object Name, Default | ConvertTo-Json -Compress"',
            { encoding: 'utf8', timeout: 10000 }
          );
          const trimmed = rawJson.trim();
          if (trimmed) {
            const list = JSON.parse(trimmed);
            const rawList = Array.isArray(list) ? list : (list ? [list] : []);
            printers = rawList.map(p => ({
              name: p.Name,
              isDefault: !!p.Default
            })).filter(p => p.name);
          }
        } catch (psErr) {
          console.warn('PowerShell CIM printer lookup failed:', psErr.message);
        }
      }

      // 3. Fallback: PowerShell .NET System.Drawing
      if (printers.length === 0) {
        try {
          const rawDotNet = execSync(
            'powershell -NoProfile -ExecutionPolicy Bypass -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Add-Type -AssemblyName System.Drawing; [System.Drawing.Printing.PrinterSettings]::InstalledPrinters"',
            { encoding: 'utf8', timeout: 8000 }
          );
          const lines = rawDotNet.trim().split(/\r?\n/);
          printers = lines.map(line => line.trim()).filter(Boolean).map(name => ({
            name,
            isDefault: name.toLowerCase() === defaultPrinterName.toLowerCase()
          }));
        } catch (dnErr) {
          console.warn('PowerShell .NET printer lookup failed:', dnErr.message);
        }
      }

      // 4. Fallback: WMIC (Legacy Windows 7 / 8 / XP)
      if (printers.length === 0) {
        try {
          const raw = execSync(
            'wmic printer get Name,Default /format:csv',
            { encoding: 'utf8', timeout: 5000, stdio: ['pipe', 'pipe', 'ignore'] }
          );
          const lines = raw.trim().split(/\r?\n/).slice(2);
          printers = lines
            .map(line => {
              const parts = line.trim().split(',');
              if (parts.length < 3) return null;
              const [, isDefault, name] = parts.map(p => p.trim());
              if (!name) return null;
              return { name: name, isDefault: isDefault === 'TRUE' };
            })
            .filter(Boolean);
        } catch { }
      }

      // Sort: default printer first, then alphabetical
      printers.sort((a, b) => {
        if (a.isDefault) return -1;
        if (b.isDefault) return 1;
        return a.name.localeCompare(b.name);
      });
    } else {
      // Linux/Mac fallback: use lpstat
      try {
        const raw = execSync('lpstat -a 2>/dev/null || lpstat -p 2>/dev/null', { encoding: 'utf8', timeout: 5000 });
        printers = raw.trim().split('\n').map(line => {
          const name = line.split(' ')[0];
          return name ? { name, isDefault: false } : null;
        }).filter(Boolean);
      } catch {
        printers = [];
      }
    }

    res.json({ success: true, printers });
  } catch (err) {
    console.error('Printer enumeration error:', err.message);
    res.json({ success: false, printers: [], error: err.message });
  }
});

// ── Customer Pole Display API (VFD / LED8N Serial Display) ─────────
app.get('/api/customer-display/ports', (req, res) => {
  try {
    if (os.platform() === 'win32') {
      const psCmd = `powershell -NoProfile -Command "[System.IO.Ports.SerialPort]::GetPortNames() -join ','"`;
      const out = execSync(psCmd, { encoding: 'utf8', timeout: 4000 });
      const ports = out.split(',').map(p => p.trim()).filter(Boolean);
      return res.json({ success: true, ports });
    }
    res.json({ success: true, ports: [] });
  } catch (e) {
    res.json({ success: false, ports: [], error: e.message });
  }
});

app.post('/api/customer-display/send', (req, res) => {
  try {
    const { amount, status, port = 'auto', baud = 2400 } = req.body;
    const amtStr = String(amount !== undefined ? amount : '0.00').trim();

    if (os.platform() !== 'win32') {
      return res.json({ success: false, error: 'Customer display only supported on Windows' });
    }

    let statusByte = 0x32; // '2' for Total (turns on Total LED lamp)
    if (status === 'price') statusByte = 0x31;
    if (status === 'change') statusByte = 0x33;
    if (status === 'clear') statusByte = 0x30;

    // Detect target ports
    let targetPorts = [];
    if (!port || port === 'auto' || port === 'all') {
      try {
        const psCmd = `powershell -NoProfile -Command "[System.IO.Ports.SerialPort]::GetPortNames() -join ','"`;
        const detected = execSync(psCmd, { encoding: 'utf8', timeout: 3000 }).trim();
        targetPorts = detected.split(',').map(p => p.trim()).filter(Boolean);
      } catch { }
      if (!targetPorts.length) targetPorts = ['COM1', 'COM2', 'COM3', 'COM4'];
    } else {
      targetPorts = [port];
    }

    const baudRates = [parseInt(baud) || 2400];
    if (port === 'all' || port === 'auto') {
      if (!baudRates.includes(9600)) baudRates.push(9600);
    }

    const ps = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', '-']);
    let stdout = '';
    let stderr = '';
    ps.stdout.on('data', d => stdout += d.toString());
    ps.stderr.on('data', d => stderr += d.toString());

    const psScript = `
      $ports = @(${targetPorts.map(p => `"${p}"`).join(',')});
      $bauds = @(${baudRates.join(',')});
      $amt = "${amtStr}";
      $statusByte = [byte]${statusByte};

      foreach ($p in $ports) {
        foreach ($b in $bauds) {
          try {
            $sp = New-Object System.IO.Ports.SerialPort;
            $sp.PortName = $p;
            $sp.BaudRate = $b;
            $sp.Parity = [System.IO.Ports.Parity]::None;
            $sp.DataBits = 8;
            $sp.StopBits = [System.IO.Ports.StopBits]::One;
            $sp.DtrEnable = $true;
            $sp.RtsEnable = $true;
            $sp.ReadTimeout = 400;
            $sp.WriteTimeout = 600;
            $sp.Open();

            # Send clear, status lamp, and ESC Q A amount in a single contiguous byte packet
            $header = [byte[]](0x0C, 0x1B, 0x73, $statusByte, 0x1B, 0x51, 0x41);
            $body = [System.Text.Encoding]::ASCII.GetBytes($amt);
            $trailer = [byte[]](0x0D);
            $packet = $header + $body + $trailer;

            $sp.Write($packet, 0, $packet.Length);
            $sp.BaseStream.Flush();
            Start-Sleep -Milliseconds 60;
            $sp.Close();
            Write-Host "OPENED_OK:$p"
          } catch {}
        }
      }
    `;

    ps.stdin.write(psScript);
    ps.stdin.end();

    ps.on('close', () => {
      const opened = [];
      stdout.split('\n').forEach(line => {
        if (line.includes('OPENED_OK:')) {
          const p = line.split('OPENED_OK:')[1].trim();
          if (p && !opened.includes(p)) opened.push(p);
        }
      });
      console.log(`[CustomerDisplay] Sent ${amtStr} | Target: ${targetPorts.join(',')} | Opened: ${opened.join(',') || 'None'}`);
      if (stderr) console.warn('[CustomerDisplay Error]:', stderr);
      res.json({
        success: true,
        port: opened.length ? opened.join(', ') : targetPorts[0],
        ports: opened.length ? opened : targetPorts,
        opened: opened,
        amount: amtStr
      });
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/printer/switch-default ──────────────────────────────
// Instantly switches Windows default printer to the specified printer using rundll32 / WScript (~40ms)
app.post('/api/printer/switch-default', (req, res) => {
  try {
    const { printer } = req.body || {};
    if (!printer) return res.json({ success: true, message: 'No printer specified' });
    let clean = printer.trim().replace(/^[\s★*]+|[\s★*]+$/g, '').trim();
    if (!clean) return res.json({ success: true });

    if (os.platform() === 'win32') {
      const { execSync } = require('child_process');
      // 1. Resolve exact installed Windows printer name
      try {
        const devRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices"', { encoding: 'utf8', timeout: 2000 });
        const installedPrinters = [];
        for (const line of devRaw.split(/\r?\n/)) {
          const m = line.trim().match(/^([^\t]+?)\s+REG_SZ\s+/i);
          if (m && m[1]) installedPrinters.push(m[1].trim());
        }
        const exact = installedPrinters.find(p => p.toLowerCase() === clean.toLowerCase());
        if (exact) {
          clean = exact;
        } else {
          const normClean = clean.toLowerCase().replace(/[^a-z0-9]/g, '');
          const fuzzy = installedPrinters.find(p => {
            const normP = p.toLowerCase().replace(/[^a-z0-9]/g, '');
            return normP.includes(normClean) || normClean.includes(normP);
          });
          if (fuzzy) clean = fuzzy;
        }
      } catch (e) { }

      // 2. Synchronous switch using rundll32
      let switched = false;
      try {
        execSync(`rundll32 printui.dll,PrintUIEntry /y /n "${clean.replace(/"/g, '')}"`, { timeout: 3000 });
        switched = true;
      } catch (e1) { }

      // 3. Fallback to fast VBScript if rundll32 didn't set it
      if (!switched) {
        try {
          const vbs = `CreateObject("WScript.Network").SetDefaultPrinter "${clean.replace(/"/g, '""')}"`;
          const tmp = path.join(os.tmpdir(), `sw_${Date.now()}.vbs`);
          fs.writeFileSync(tmp, vbs, 'utf8');
          execSync(`cscript //nologo "${tmp}"`, { timeout: 3000 });
          try { fs.unlinkSync(tmp); } catch (e) { }
        } catch (e2) { }
      }
    }
    console.log(`[Printer] Switched Windows default printer to: ${clean}`);
    res.json({ success: true, printer: clean });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/print-label ────────────────────────────────────────
// Prints barcode labels directly to Xprinter XP-365B via native Windows .NET Spooler
app.post('/api/print-label', (req, res) => {
  try {
    const data = req.body || {};
    let printer = (data.printer || '').trim().replace(/^[\s★*]+|[\s★*]+$/g, '').trim();
    if (!printer) printer = 'Xprinter XP-365B';

    const scriptPath = path.join(__dirname, 'bin', 'print_label.ps1');
    if (!fs.existsSync(scriptPath)) {
      return res.status(404).json({ success: false, error: 'print_label.ps1 not found' });
    }

    const uniqueId = Date.now() + '_' + Math.floor(Math.random() * 10000);
    const tempJson = path.join(os.tmpdir(), `label_${uniqueId}.json`);
    fs.writeFileSync(tempJson, JSON.stringify(data), 'utf8');

    const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -File "${scriptPath}" -JsonFile "${tempJson}"`;
    const { exec } = require('child_process');
    exec(psCmd, { timeout: 15000 }, (err, stdout, stderr) => {
      try { fs.unlinkSync(tempJson); } catch (e) { }
      if (err) {
        console.error('Label print error:', err.message || stderr);
        return res.json({ success: false, error: err.message || stderr });
      }
      console.log('Label print success:', stdout.trim());
      res.json({ success: true, message: `Label printed directly to ${printer}` });
    });
  } catch (err) {
    console.error('Label print exception:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/print-direct ──────────────────────────────────────
// Prints receipt directly to named Windows thermal printer using .NET Spooler
app.post('/api/print-direct', (req, res) => {
  try {
    const { printer, data, html } = req.body;
    let targetPrinter = (printer || '').trim().replace(/^★\s*|\s*★$/g, '').trim();

    if (html) {
      if (targetPrinter && os.platform() === 'win32') {
        try {
          const { exec } = require('child_process');
          exec(`rundll32 printui.dll,PrintUIEntry /y /n "${targetPrinter.replace(/"/g, '')}"`, () => { });
        } catch (e) { }
      }
      ensurePrintWorker();
      const jobId = Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      printJobQueue.push({
        id: jobId,
        html: html,
        printer: targetPrinter,
        created: Date.now()
      });
      return res.json({ success: true, message: `HTML Print job dispatched directly to ${targetPrinter || 'default printer'}` });
    }

    if (!targetPrinter) {
      try {
        const defRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows" /v Device', { encoding: 'utf8', timeout: 2000 });
        const m = defRaw.match(/Device\s+REG_SZ\s+([^,\r\n]+)/i);
        if (m && m[1]) targetPrinter = m[1].trim();
      } catch (e) { }
    }
    if (!targetPrinter) targetPrinter = 'XP-80C';

    const uniqueId = Date.now() + '_' + Math.floor(Math.random() * 1000);
    const tempDir = os.tmpdir();
    const tempJsonPath = path.join(tempDir, `receipt_${uniqueId}.json`);

    fs.writeFileSync(tempJsonPath, JSON.stringify(data || {}), 'utf8');

    const scriptPath = path.join(__dirname, 'bin', 'print_receipt.ps1');
    const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -File "${scriptPath}" -PrinterName "${targetPrinter.replace(/"/g, '')}" -JsonFile "${tempJsonPath}"`;

    const { exec } = require('child_process');
    exec(psCmd, (err, stdout, stderr) => {
      try { fs.unlinkSync(tempJsonPath); } catch (e) { }
      if (err) {
        console.error('Direct print error:', err.message || stderr);
        return res.json({ success: false, error: err.message || stderr });
      }
      console.log('Direct print success:', stdout.trim());
      res.json({ success: true, message: `Printed directly to ${targetPrinter}` });
    });
  } catch (err) {
    console.error('Print-direct exception:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── BACKGROUND PRINT WORKER QUEUE ────────────────────────────────
const printJobQueue = [];
let printWorkerLastActive = 0;

function ensurePrintWorker() {
  if (os.platform() !== 'win32') return;
  // If active in the last 4 seconds, worker is alive and polling
  if (Date.now() - printWorkerLastActive < 4000) return;

  const chromePaths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
  ];
  const edgePaths = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ];
  const browserExe = chromePaths.find(p => fs.existsSync(p)) || edgePaths.find(p => fs.existsSync(p));
  if (!browserExe) return;

  const workerProfileDir = path.join(os.homedir(), 'AppData', 'Local', 'RedSharkPOS', 'PrintWorkerProfile');
  if (!fs.existsSync(workerProfileDir)) {
    try { fs.mkdirSync(workerProfileDir, { recursive: true }); } catch (e) { }
  }

  const workerUrl = `http://localhost:${PORT}/print_worker.html`;
  // Start with -WindowStyle Hidden so Windows NEVER shows any window or taskbar icon!
  const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process '${browserExe}' -ArgumentList '--kiosk-printing','--user-data-dir=\\\"${workerProfileDir}\\\"','--window-position=-32000,-32000','--window-size=10,10','--no-first-run','--disable-fre','--no-default-browser-check','--disable-gpu','--disable-extensions','--disable-background-networking','--disable-sync','--disable-default-apps','--disable-component-update','--disable-features=Translate,OptimizationHints,MediaRouter','--renderer-process-limit=1','\\\"${workerUrl}\\\"' -WindowStyle Hidden"`;

  try {
    const { exec } = require('child_process');
    exec(psCmd, (err) => {
      if (err) console.warn('Worker launch warning:', err.message);
    });
    printWorkerLastActive = Date.now();
  } catch (e) { }
}

// ── GET /api/print-worker/next ──────────────────────────────────
app.get('/api/print-worker/next', (req, res) => {
  printWorkerLastActive = Date.now();
  if (printJobQueue.length > 0) {
    const job = printJobQueue.shift();
    return res.json({ job });
  }
  res.json({ job: null });
});

// ── POST /api/print-worker/ack ──────────────────────────────────
app.post('/api/print-worker/ack', (req, res) => {
  printWorkerLastActive = Date.now();
  res.json({ success: true });
});

// ── POST /api/print ─────────────────────────────────────────────
// Prints HTML silently to a specific printer without opening preview dialog
app.post('/api/print', (req, res) => {
  try {
    const { html, printer, pageSize } = req.body;
    if (!html) {
      return res.status(400).json({ success: false, error: 'HTML content is required' });
    }

    let cleanPrinter = printer ? printer.trim().replace(/^[\s★*]+|[\s★*]+$/g, '').trim() : '';

    // Smart printer name resolution: Match against installed Windows printers
    if (cleanPrinter && os.platform() === 'win32') {
      try {
        const devRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices"', { encoding: 'utf8', timeout: 2000 });
        const installedPrinters = [];
        for (const line of devRaw.split(/\r?\n/)) {
          const m = line.trim().match(/^([^\t]+?)\s+REG_SZ\s+/i);
          if (m && m[1]) installedPrinters.push(m[1].trim());
        }
        const exact = installedPrinters.find(p => p.toLowerCase() === cleanPrinter.toLowerCase());
        if (exact) {
          cleanPrinter = exact;
        } else {
          const normClean = cleanPrinter.toLowerCase().replace(/[^a-z0-9]/g, '');
          const fuzzy = installedPrinters.find(p => {
            const normP = p.toLowerCase().replace(/[^a-z0-9]/g, '');
            return normP.includes(normClean) || normClean.includes(normP);
          });
          if (fuzzy) {
            console.log(`[Print] Resolved printer '${cleanPrinter}' to '${fuzzy}'`);
            cleanPrinter = fuzzy;
          }
        }
      } catch (e) { }
    }

    // 1. Direct hardware printing via native FastPrinter.exe (Win32 Spooler)
    const fastPrinterExe = path.join(__dirname, 'bin', 'FastPrinter.exe');
    if (fs.existsSync(fastPrinterExe) && os.platform() === 'win32') {
      const uniqueId = Date.now() + '_' + Math.floor(Math.random() * 10000);
      const tempHtmlPath = path.join(os.tmpdir(), `print_doc_${uniqueId}.html`);
      fs.writeFileSync(tempHtmlPath, html, 'utf8');

      const targetArg = cleanPrinter ? `"${cleanPrinter.replace(/"/g, '')}"` : '';
      const printCmd = `"${fastPrinterExe}" "${tempHtmlPath}" ${targetArg}`;
      const { exec } = require('child_process');
      exec(printCmd, { timeout: 15000 }, (err, stdout, stderr) => {
        try { fs.unlinkSync(tempHtmlPath); } catch (e) { }
        if (err) {
          console.warn('FastPrinter warning, falling back to background worker:', err.message || stderr);
          return fallbackToPrintWorker();
        }
        console.log(`FastPrinter dispatched directly to (${cleanPrinter || 'Default'}):`, (stdout || '').trim());
        return res.json({ success: true, message: `Printed directly to ${cleanPrinter || 'default printer'}` });
      });
      return;
    }

    function fallbackToPrintWorker() {
      if (cleanPrinter && os.platform() === 'win32') {
        try {
          const { execSync } = require('child_process');
          execSync(`powershell -NoProfile -Command "(New-Object -ComObject WScript.Network).SetDefaultPrinter('${cleanPrinter.replace(/'/g, "''")}')"`, { timeout: 3000 });
        } catch (e) {
          try { const { exec } = require('child_process'); exec(`rundll32 printui.dll,PrintUIEntry /y /n "${cleanPrinter.replace(/"/g, '')}"`, () => { }); } catch (e2) { }
        }
      }

      ensurePrintWorker();

      const jobId = Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      printJobQueue.push({
        id: jobId,
        html: html,
        printer: cleanPrinter,
        created: Date.now()
      });

      res.json({ success: true, message: `Print job dispatched to worker for ${cleanPrinter || 'default printer'}` });
    }

    fallbackToPrintWorker();
  } catch (err) {
    console.error('Print error:', err.message);
    res.json({ success: false, error: err.message });
  }
});

const crypto = require('crypto');

// ── SERVER-SIDE CENTRAL DATABASE CONFIGURATION (AES-256 ENCRYPTED) ─
const DB_FILE = path.join(__dirname, 'data', 'db.dat');
const LEGACY_JSON_FILE = path.join(__dirname, 'data', 'db.json');

// Derive 32-byte AES key from Master Secret
const MASTER_SECRET = '0wner_RedSharkPOS_SuperSecret_Master_Key_2026';
const ENC_KEY = crypto.createHash('sha256').update(MASTER_SECRET).digest();

function encryptText(text) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

function decryptText(encryptedText) {
  try {
    const parts = encryptedText.split(':');
    if (parts.length !== 3) return null;
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    const decipher = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (e) {
    return null;
  }
}

// Initialize database folder and file with automatic migration
function initDatabase() {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  // Auto-migrate from unencrypted db.json if present
  if (!fs.existsSync(DB_FILE) && fs.existsSync(LEGACY_JSON_FILE)) {
    try {
      const raw = fs.readFileSync(LEGACY_JSON_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      fs.writeFileSync(DB_FILE, encryptText(JSON.stringify(parsed, null, 2)), 'utf8');
      console.log('🔒 Migrated database to AES-256 encrypted storage (db.dat).');
      try { fs.unlinkSync(LEGACY_JSON_FILE); } catch { }
      return;
    } catch (err) {
      console.warn('Migration warning:', err.message);
    }
  }

  if (!fs.existsSync(DB_FILE)) {
    const initialDb = {
      settings: [
        { key: 'company_name', value: 'Red Shark POS Store' },
        { key: 'vat_rate', value: 11 },
        { key: 'vat_enabled', value: false },
        { key: 'exchange_rate', value: 89500 },
        { key: 'currency_1', value: 'USD' },
        { key: 'currency_2', value: 'LBP' }
      ],
      warehouses: [
        { id: 1, code: 'WH-01', name: 'المستودع الرئيسي (السيرفر)', name_ar: 'المستودع الرئيسي (السيرفر)', is_default: true, updated_at: new Date().toISOString() },
        { id: 2, code: 'WH-02', name: 'TestBranch', name_ar: 'TestBranch', is_default: false, updated_at: new Date().toISOString() }
      ]
    };
    fs.writeFileSync(DB_FILE, encryptText(JSON.stringify(initialDb, null, 2)), 'utf8');
  }
}
initDatabase();

function ensureMasterWarehouses() {
  try {
    const db = readDb();
    if (db) {
      let modified = false;
      if (!Array.isArray(db.warehouses) || db.warehouses.length === 0) {
        db.warehouses = [
          { id: 1, code: 'WH-01', name: 'المستودع الرئيسي (السيرفر)', name_ar: 'المستودع الرئيسي (السيرفر)', is_default: true, updated_at: new Date().toISOString() },
          { id: 2, code: 'WH-02', name: 'TestBranch', name_ar: 'TestBranch', is_default: false, updated_at: new Date().toISOString() }
        ];
        modified = true;
      } else {
        const hasMain = db.warehouses.some(w => (w.code || '').toUpperCase() === 'WH-01');
        if (!hasMain) {
          db.warehouses.unshift({
            id: 1,
            code: 'WH-01',
            name: 'المستودع الرئيسي (السيرفر)',
            name_ar: 'المستودع الرئيسي (السيرفر)',
            is_default: true,
            updated_at: new Date().toISOString()
          });
          modified = true;
        }
      }
      if (modified) writeDb(db);
    }
  } catch (e) { }
}
ensureMasterWarehouses();

function readDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const rawEncrypted = fs.readFileSync(DB_FILE, 'utf8').trim();
      const decrypted = decryptText(rawEncrypted);
      if (decrypted) return JSON.parse(decrypted);
    }
    if (fs.existsSync(LEGACY_JSON_FILE)) {
      return JSON.parse(fs.readFileSync(LEGACY_JSON_FILE, 'utf8'));
    }
    return {};
  } catch (e) {
    console.error('Error reading database:', e.message);
    return {};
  }
}

function writeDb(data) {
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const cipher = encryptText(jsonStr);
    fs.writeFileSync(DB_FILE, cipher, 'utf8');
  } catch (e) {
    console.error('Error writing to encrypted database file:', e.message);
  }
}

// ── SERVER-SIDE HARDWARE FINGERPRINTING & LICENSE SHIELD ─────────
const LICENSE_SECRET_SALT = "RedSharkPOS_LicenseSalt_2026_Enterprise";

const HW_CACHE_FILE = path.join(__dirname, 'data', 'hardware_cache.json');

function getCachedHardwareIds() {
  try {
    if (fs.existsSync(HW_CACHE_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(HW_CACHE_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { }
  return [];
}

function saveCachedHardwareIds(idsArray) {
  try {
    const existing = new Set(getCachedHardwareIds().map(x => String(x).toUpperCase()));
    idsArray.forEach(id => {
      if (id && typeof id === 'string') existing.add(id.trim().toUpperCase());
    });
    fs.writeFileSync(HW_CACHE_FILE, JSON.stringify(Array.from(existing), null, 2), 'utf8');
  } catch { }
}

function getAllHardwareMachineIds() {
  const ids = new Set(getCachedHardwareIds());

  // 1. MAC-based hardware ID (used in standard activations)
  try {
    const ifaces = os.networkInterfaces();
    for (const iface of Object.values(ifaces)) {
      for (const alias of (iface || [])) {
        if (!alias.internal && alias.mac && alias.mac !== '00:00:00:00:00:00') {
          ids.add('RS-' + alias.mac.replace(/:/g, '').substring(0, 16).toUpperCase());
        }
      }
    }
  } catch { }

  // 2. Windows MachineGuid / UUID
  try {
    let rawId = '';
    if (os.platform() === 'win32') {
      try {
        const regOut = execSync('reg query "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: 'utf8', timeout: 3000 });
        const m = regOut.match(/MachineGuid\s+REG_SZ\s+([a-fA-F0-9\-]+)/i);
        if (m && m[1]) rawId += m[1].trim();
      } catch { }

      try {
        const wmicOut = execSync('wmic csproduct get uuid', { encoding: 'utf8', timeout: 2000, stdio: ['pipe', 'pipe', 'ignore'] });
        const lines = wmicOut.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        if (lines.length > 1 && lines[1] && !lines[1].toLowerCase().includes('uuid')) {
          rawId += '_' + lines[1];
        }
      } catch { }
    }
    if (rawId) {
      const hash = crypto.createHash('sha256').update(rawId).digest('hex').toUpperCase();
      ids.add(`RS-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`);
    }
  } catch { }

  // 3. Fallback hostname ID
  try {
    const hostId = 'RS-' + (os.hostname() || 'SERVER').replace(/[^a-zA-Z0-9]/g, '').substring(0, 16).toUpperCase();
    ids.add(hostId);
  } catch { }

  const result = Array.from(ids);
  if (result.length) {
    saveCachedHardwareIds(result);
  }
  return result;
}

function verifyLicenseData(lic) {
  // Verify signature first
  const modulesStr = (lic.allowed_modules || []).join(',');
  const checkText = `${lic.machine_id}|${lic.client_name || ''}|${lic.expiry_date}|${modulesStr}|${LICENSE_SECRET_SALT}`;
  const computedSig = crypto.createHash('sha256').update(checkText).digest('hex');
  if (computedSig !== lic.signature) return false;

  // 1. Direct hardware machine ID match
  const validIds = getAllHardwareMachineIds();
  const machineMatches = validIds.some(id => id.toUpperCase() === String(lic.machine_id).trim().toUpperCase());
  if (machineMatches) {
    saveCachedHardwareIds([lic.machine_id]);
    return true;
  }

  // 2. Wildcard or Master Enterprise (* or ALL)
  if (lic.machine_id === '*' || lic.machine_id === 'ALL') return true;

  // 3. Shop Slug or Company Name Match
  const db = readDb();
  const settings = db['settings'] || [];
  const getVal = (key) => settings.find(s => s.key === key)?.value;
  const shopSlug = getVal('online_store_slug') || '';
  const compName = getVal('company_name') || '';

  if (shopSlug && lic.machine_id.trim().toLowerCase() === String(shopSlug).trim().toLowerCase()) return true;
  if (compName && lic.machine_id.trim().toLowerCase() === String(compName).trim().toLowerCase()) return true;
  if (lic.client_name && shopSlug && lic.client_name.trim().toLowerCase() === String(shopSlug).trim().toLowerCase()) return true;
  if (lic.client_name && compName && lic.client_name.trim().toLowerCase() === String(compName).trim().toLowerCase()) return true;

  return false;
}

function getServerLicenseStatus() {
  const db = readDb();
  const settings = db['settings'] || [];
  const getVal = (key) => settings.find(s => s.key === key)?.value;
  const validIds = getAllHardwareMachineIds();

  const rawLic = getVal('license_active_data');
  if (rawLic) {
    try {
      const lic = typeof rawLic === 'string' ? JSON.parse(rawLic) : rawLic;
      if (verifyLicenseData(lic)) {
        const now = new Date();
        const expiry = new Date(lic.expiry_date + 'T23:59:59');
        if (now <= expiry) {
          return { active: true, status: 'active', data: lic, machine_id: lic.machine_id, is_licensed: true };
        } else {
          return { active: false, status: 'expired', data: lic, machine_id: lic.machine_id, is_licensed: true };
        }
      }
    } catch { }
  }

  const isDemo = getVal('demo_trial_active');
  if (isDemo === true || isDemo === 'true') {
    const expiresAt = getVal('demo_expires_at');
    const remainingMs = expiresAt ? (new Date(expiresAt).getTime() - Date.now()) : 0;
    if (remainingMs > 0) {
      return { active: true, status: 'demo_trial', expiresAt, machine_id: validIds[0], is_licensed: false, is_demo: true };
    } else {
      return { active: false, status: 'expired_demo', machine_id: validIds[0], is_licensed: false };
    }
  }

  return { active: false, status: 'unlicensed', machine_id: validIds[0], is_licensed: false };
}

// ── GET /api/license-status ──────────────────────────────────────
app.get('/api/license-status', (req, res) => {
  try {
    const status = getServerLicenseStatus();
    res.json({ success: true, ...status });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/db-all ──────────────────────────────────────────────
app.get('/api/db-all', (req, res) => {
  try {
    const db = readDb();
    res.json({ success: true, data: db });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/db-export-decrypted (Owner only with PIN) ────────────
app.get('/api/db-export-decrypted', (req, res) => {
  try {
    const pin = req.query.pin || req.headers['x-owner-pin'];
    if (pin !== '0wner' && pin !== 'Owner') {
      return res.status(403).json({ success: false, error: 'Unauthorized: Invalid Owner PIN' });
    }
    const db = readDb();
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="redshark_backup_${new Date().toISOString().split('T')[0]}.json"`);
    res.status(200).send(JSON.stringify(db, null, 2));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/db/:storeName ───────────────────────────────────────
app.get('/api/db/:storeName', (req, res) => {
  try {
    const db = readDb();
    const store = db[req.params.storeName] || [];
    res.json({ success: true, data: store });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/db/:storeName/:id ───────────────────────────────────
app.get('/api/db/:storeName/:id', (req, res) => {
  try {
    const db = readDb();
    const store = db[req.params.storeName] || [];
    const id = req.params.id;
    const item = store.find(x => String(x.id) === String(id) || (x.key && String(x.key) === String(id)));
    res.json({ success: true, data: item });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/db/:storeName ──────────────────────────────────────
app.post('/api/db/:storeName', (req, res) => {
  try {
    const { storeName } = req.params;
    const item = req.body;
    const db = readDb();
    if (!db[storeName]) db[storeName] = [];
    const store = db[storeName];

    const keyField = storeName === 'settings' || storeName === 'sequences' ? 'key' : 'id';

    if (keyField === 'key') {
      const idx = store.findIndex(x => x.key === item.key);
      if (idx > -1) {
        store[idx] = item;
      } else {
        store.push(item);
      }
    } else {
      if (item.id === undefined || item.id === null) {
        // Prevent duplicate categories with the same name
        if (storeName === 'categories') {
          const cName = (item.name_en || item.name || item.name_ar || '').toLowerCase().trim();
          const existing = store.find(x => (x.name_en || x.name || x.name_ar || '').toLowerCase().trim() === cName);
          if (existing) {
            Object.assign(existing, item, { id: existing.id });
            writeDb(db);
            return res.json({ success: true, data: existing });
          }
        }
        // Prevent duplicate items with the same barcode or item_code
        if (storeName === 'items') {
          const bCode = (item.barcode || item.item_code || item.code || '').toLowerCase().trim();
          if (bCode) {
            const existing = store.find(x => (x.barcode || x.item_code || x.code || '').toLowerCase().trim() === bCode);
            if (existing) {
              Object.assign(existing, item, { id: existing.id });
              writeDb(db);
              return res.json({ success: true, data: existing });
            }
          }
        }

        // Prevent duplicate customers / suppliers with the same phone or name
        if (storeName === 'customers' || storeName === 'suppliers') {
          const phone = (item.phone || '').trim();
          const name = (item.name_ar || item.name_en || item.name || '').trim().toLowerCase();
          const existing = store.find(x =>
            (phone && (x.phone || '').trim() === phone) ||
            (name && (x.name_ar || x.name_en || x.name || '').trim().toLowerCase() === name)
          );
          if (existing) {
            Object.assign(existing, item, { id: existing.id });
            writeDb(db);
            return res.json({ success: true, data: existing });
          }
        }

        const ids = store.map(x => parseInt(x.id)).filter(x => !isNaN(x));
        const maxId = ids.length ? Math.max(...ids) : 0;
        item.id = maxId + 1;
        store.push(item);
      } else {
        let idx = store.findIndex(x => String(x.id) === String(item.id));
        if (idx === -1 && (storeName === 'customers' || storeName === 'suppliers')) {
          const phone = (item.phone || '').trim();
          const name = (item.name_ar || item.name_en || item.name || '').trim().toLowerCase();
          idx = store.findIndex(x =>
            (phone && (x.phone || '').trim() === phone) ||
            (name && (x.name_ar || x.name_en || x.name || '').trim().toLowerCase() === name)
          );
          if (idx > -1) {
            item.id = store[idx].id;
          }
        }
        if (idx > -1) {
          store[idx] = item;
        } else {
          store.push(item);
        }
      }
    }

    writeDb(db);
    const tblPath = path.join(__dirname, 'data', 'sync', 'tables', `${storeName}.json`);
    if (fs.existsSync(tblPath)) {
      try { fs.writeFileSync(tblPath, JSON.stringify(db[storeName]), 'utf8'); } catch (e) { }
    }
    res.json({ success: true, data: item });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/db-bulk/:storeName (High-performance Batch Insert/Update) ──────────
app.post('/api/db-bulk/:storeName', (req, res) => {
  try {
    const { storeName } = req.params;
    const isReplace = Boolean(!Array.isArray(req.body) && req.body && req.body.replace);
    const incomingItems = Array.isArray(req.body) ? req.body : (req.body.items || []);
    if (!incomingItems.length && !isReplace) {
      return res.json({ success: true, count: 0 });
    }

    const db = readDb();
    if (!db[storeName]) db[storeName] = [];
    const store = db[storeName];

    const keyField = storeName === 'settings' || storeName === 'sequences' ? 'key' : 'id';

    const idMap = new Map();
    const barcodeMap = new Map();
    if (isReplace) store.length = 0;
    const codeMap = new Map();

    store.forEach((x, idx) => {
      if (x[keyField] !== undefined && x[keyField] !== null) {
        idMap.set(String(x[keyField]), idx);
      }
      if (storeName === 'items') {
        if (x.barcode) barcodeMap.set(String(x.barcode).toLowerCase().trim(), idx);
        if (x.item_code) codeMap.set(String(x.item_code).toLowerCase().trim(), idx);
      }
    });

    const ids = store.map(x => parseInt(x.id)).filter(x => !isNaN(x));
    let nextId = ids.length ? Math.max(...ids) + 1 : 1;

    for (const item of incomingItems) {
      if (keyField === 'key') {
        const k = String(item.key);
        if (idMap.has(k)) {
          store[idMap.get(k)] = item;
        } else {
          store.push(item);
          idMap.set(k, store.length - 1);
        }
      } else {
        let matchIdx = -1;
        if (item.id !== undefined && item.id !== null && idMap.has(String(item.id))) {
          matchIdx = idMap.get(String(item.id));
        } else if (storeName === 'items') {
          const bCode = (item.barcode || '').toLowerCase().trim();
          const iCode = (item.item_code || item.code || '').toLowerCase().trim();
          if (bCode && barcodeMap.has(bCode)) {
            matchIdx = barcodeMap.get(bCode);
          } else if (iCode && codeMap.has(iCode)) {
            matchIdx = codeMap.get(iCode);
          }
        }

        if (matchIdx > -1) {
          const existing = store[matchIdx];
          Object.assign(existing, item, { id: existing.id });
        } else {
          if (item.id === undefined || item.id === null) {
            item.id = nextId++;
          } else {
            const numId = parseInt(item.id);
            if (!isNaN(numId) && numId >= nextId) nextId = numId + 1;
          }
          store.push(item);
          const newIdx = store.length - 1;
          idMap.set(String(item.id), newIdx);
          if (storeName === 'items') {
            if (item.barcode) barcodeMap.set(String(item.barcode).toLowerCase().trim(), newIdx);
            if (item.item_code) codeMap.set(String(item.item_code).toLowerCase().trim(), newIdx);
          }
        }
      }
    }

    writeDb(db);
    const tblPath = path.join(__dirname, 'data', 'sync', 'tables', `${storeName}.json`);
    if (fs.existsSync(tblPath)) {
      try { fs.writeFileSync(tblPath, JSON.stringify(db[storeName]), 'utf8'); } catch (e) { }
    }
    res.json({ success: true, count: incomingItems.length, total: store.length });
  } catch (err) {
    console.error('Bulk save error:', err);
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/qr-code (100% Offline Local QR Generator) ───────────
app.get('/api/qr-code', async (req, res) => {
  try {
    const text = req.query.text || req.query.data || req.query.url || 'http://localhost:3000/mobile.html';
    const QRCode = require('qrcode');
    const dataUrl = await QRCode.toDataURL(text, { width: 240, margin: 1 });
    res.json({ success: true, dataUrl });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── DELETE /api/db/:storeName/:id ───────────────────────────────
app.delete('/api/db/:storeName/:id', (req, res) => {
  try {
    const { storeName, id } = req.params;
    const db = readDb();
    if (db[storeName]) {
      const keyField = storeName === 'settings' || storeName === 'sequences' ? 'key' : 'id';
      db[storeName] = db[storeName].filter(x => String(x[keyField]) !== String(id));
      writeDb(db);
      const tblPath = path.join(__dirname, 'data', 'sync', 'tables', `${storeName}.json`);
      if (fs.existsSync(tblPath)) {
        try { fs.writeFileSync(tblPath, JSON.stringify(db[storeName]), 'utf8'); } catch (e) { }
      }
      recordTombstone(storeName, id);
    }
    res.json({ success: true });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// ── SYNC DIRECTORIES & FILE PATHS ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════
const SYNC_DIR = path.join(__dirname, 'data', 'sync');
const TABLES_DIR = path.join(SYNC_DIR, 'tables');
if (!fs.existsSync(SYNC_DIR)) fs.mkdirSync(SYNC_DIR, { recursive: true });
if (!fs.existsSync(TABLES_DIR)) fs.mkdirSync(TABLES_DIR, { recursive: true });

const NODES_FILE = path.join(SYNC_DIR, 'nodes.json');
const CONFIG_FILE = path.join(SYNC_DIR, 'config.json');
const TRANSACTIONS_FILE = path.join(SYNC_DIR, 'transactions.json');
const TOMBSTONES_FILE = path.join(SYNC_DIR, 'tombstones.json');

function recordTombstone(table, id) {
  try {
    let list = [];
    if (fs.existsSync(TOMBSTONES_FILE)) {
      try { list = JSON.parse(fs.readFileSync(TOMBSTONES_FILE, 'utf8')); } catch (e) { }
    }
    const cleanId = String(id).trim();
    if (!cleanId) return;
    const now = new Date().toISOString();
    list = list.filter(t => !(t.table === table && String(t.id) === cleanId));
    list.push({ table, id: cleanId, deleted_at: now });
    const thirtyDaysAgo = Date.now() - 30 * 24 * 3600 * 1000;
    list = list.filter(t => new Date(t.deleted_at).getTime() > thirtyDaysAgo).slice(-2000);
    fs.writeFileSync(TOMBSTONES_FILE, JSON.stringify(list), 'utf8');
  } catch (e) {
    console.warn('[Sync] recordTombstone error:', e.message);
  }
}

function getTombstones(table, sinceMs) {
  try {
    if (!fs.existsSync(TOMBSTONES_FILE)) return [];
    const list = JSON.parse(fs.readFileSync(TOMBSTONES_FILE, 'utf8')) || [];
    return list
      .filter(t => t.table === table && new Date(t.deleted_at).getTime() > sinceMs)
      .map(t => t.id);
  } catch (e) {
    return [];
  }
}

// ── POST /api/db-clear/:storeName ───────────────────────────────
app.post('/api/db-clear/:storeName', (req, res) => {
  try {
    const { storeName } = req.params;
    const db = readDb();
    db[storeName] = [];
    writeDb(db);

    // Also remove or reset table snapshot in TABLES_DIR
    const tblPath = path.join(TABLES_DIR, `${storeName}.json`);
    if (fs.existsSync(tblPath)) {
      try { fs.writeFileSync(tblPath, JSON.stringify([]), 'utf8'); } catch (e) { }
    }

    // If clearing sales or transactional data, also reset TRANSACTIONS_FILE
    if (['sales', 'sale_items', 'sales_invoice', 'sales_returns', 'purchase_invoices', 'cash_transactions'].includes(storeName)) {
      if (fs.existsSync(TRANSACTIONS_FILE)) {
        try {
          const trans = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8'));
          if (storeName === 'sales' || storeName === 'sales_invoice') trans.sales = [];
          if (storeName === 'sales_returns') trans.salesReturns = [];
          if (storeName === 'purchase_invoices') trans.purchases = [];
          if (storeName === 'purchase_returns') trans.purchaseReturns = [];
          if (storeName === 'cash_transactions') trans.cashTransactions = [];
          fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(trans, null, 2), 'utf8');
        } catch (e) { }
      }
    }

    res.json({ success: true });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/sync/delete-batch (Bulk Delete Items / Master Records) ──────────
app.post('/api/sync/delete-batch', (req, res) => {
  try {
    const table = String(req.body?.table || 'items').replace(/[^a-zA-Z0-9_-]/g, '');
    const ids = Array.isArray(req.body?.ids) ? req.body.ids : [];
    if (!ids.length) return res.json({ success: true, count: 0 });

    const idSet = new Set(ids.map(id => String(id).trim()));
    const db = readDb();
    if (Array.isArray(db[table])) {
      db[table] = db[table].filter(r => !idSet.has(String(r.id).trim()));
      writeDb(db);
    }

    const tblPath = path.join(TABLES_DIR, `${table}.json`);
    if (fs.existsSync(tblPath)) {
      try {
        let records = JSON.parse(fs.readFileSync(tblPath, 'utf8'));
        if (Array.isArray(records)) {
          records = records.filter(r => !idSet.has(String(r.id).trim()));
          fs.writeFileSync(tblPath, JSON.stringify(records, null, 2), 'utf8');
        }
      } catch (e) { }
    }

    // Record tombstones so branches remove them on next delta sync
    for (const id of ids) {
      recordTombstone(table, id);
    }

    broadcastSyncEvent('table_updated', { table, action: 'batch_delete', count: ids.length });
    res.json({ success: true, count: ids.length });
  } catch (err) {
    console.error('[Sync] delete-batch error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/sync/clean-reset (Complete Clean Reset & Cloud Purge) ──
app.post('/api/sync/clean-reset', async (req, res) => {
  try {
    const { cleanCloud, cleanLocalServer } = require('./reset_and_start_fresh.js');
    const slug = req.body?.slug || 'bobmarket';
    await cleanCloud(slug);
    cleanLocalServer();
    res.json({ success: true, message: 'Clean reset completed successfully' });
  } catch (err) {
    console.error('[Sync] Clean reset error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/sync/clear-transactions (Full Wipe of Reports & Consolidated Transactions) ──
app.post('/api/sync/clear-transactions', (req, res) => {
  try {
    const emptyTrans = { sales: [], purchases: [], purchaseReturns: [], salesReturns: [], cashboxSessions: [], cashTransactions: [] };
    fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(emptyTrans, null, 2), 'utf8');

    const db = readDb();
    const transKeys = [
      'sales', 'sale_items', 'sales_invoice', 'sales_returns', 'quotation', 'sales_orders', 'delivery_order',
      'purchase_orders', 'po_items', 'goods_receipts', 'grn_items', 'purchase_invoices', 'purchase_returns',
      'stock_adjustments', 'stock_movements', 'cash_transactions', 'bank_transactions', 'cashbox_sessions',
      'cashbox_movements', 'journals', 'journal_lines', 'audit_log', 'sequences'
    ];
    transKeys.forEach(k => {
      db[k] = [];
      const tblPath = path.join(TABLES_DIR, `${k}.json`);
      if (fs.existsSync(tblPath)) {
        try { fs.writeFileSync(tblPath, JSON.stringify([]), 'utf8'); } catch (e) { }
      }
    });
    writeDb(db);

    broadcastSyncEvent('table_updated', { table: 'all', action: 'reset' });
    res.json({ success: true, message: 'All backend transactions and report caches cleared.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/sync/clear-catalog (Full Wipe of Catalog Tables on Server) ──
app.post('/api/sync/clear-catalog', (req, res) => {
  try {
    const db = readDb();
    const catalogKeys = ['items', 'categories', 'units', 'offers', 'warehouses', 'suppliers', 'stock_transfers'];
    catalogKeys.forEach(k => {
      db[k] = [];
      const tblPath = path.join(TABLES_DIR, `${k}.json`);
      try { fs.writeFileSync(tblPath, JSON.stringify([]), 'utf8'); } catch (e) { }
    });
    writeDb(db);

    catalogKeys.forEach(tbl => {
      broadcastSyncEvent('table_updated', { table: tbl, action: 'reset', count: 0 });
    });
    res.json({ success: true, message: 'All backend catalog tables and snapshots cleared.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});


// ── System Safe Updater API ──────────────────────────────────────
// Lets technician browse release folder and apply updates with zero data loss
app.get('/api/system/browse-release-folder', (req, res) => {
  try {
    if (os.platform() === 'win32') {
      const psCmd = `powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = 'Select Red Shark POS Release Folder'; $d.ShowNewFolderButton = $false; $top = New-Object System.Windows.Forms.Form -Property @{TopMost=$true}; if ($d.ShowDialog($top) -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }"`;
      const selected = execSync(psCmd, { encoding: 'utf8', timeout: 60000 }).trim();
      return res.json({ success: true, folderPath: selected || '' });
    }
    res.json({ success: false, error: 'Browse dialog is only supported on Windows' });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

app.post('/api/system/apply-release-update', (req, res) => {
  try {
    const { releasePath } = req.body;
    if (!releasePath || !fs.existsSync(releasePath)) {
      return res.status(400).json({ success: false, error: 'Release folder path is invalid or does not exist.' });
    }

    const currentDir = process.cwd();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(currentDir, 'Backup', `PreUpdate_${timestamp}`);

    // 1. Create Pre-Update Safety Backup
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    const dataDir = path.join(currentDir, 'data');
    if (fs.existsSync(dataDir)) {
      fs.cpSync(dataDir, path.join(backupDir, 'data'), { recursive: true });
    }

    // 2. Protected customer directories & files
    const PROTECTED = new Set(['data', 'Backup', 'temp_edge_profile', '.env', 'scratch', '.git', '.agents']);

    // 3. Copy release items
    const releaseItems = fs.readdirSync(releasePath);
    let copiedCount = 0;

    for (const item of releaseItems) {
      if (PROTECTED.has(item)) continue;
      if (['developer_generator.html', 'developer_decryptor.html', 'license_generator.html', 'generate_license.js'].includes(item)) continue;

      const src = path.join(releasePath, item);
      const dest = path.join(currentDir, item);
      const stat = fs.statSync(src);

      if (stat.isDirectory()) {
        try { fs.cpSync(src, dest, { recursive: true, force: true }); } catch (cpErr) { const copySafe = (s, d) => { if (!fs.existsSync(s)) return; const st = fs.statSync(s); if (st.isDirectory()) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); for (const f of fs.readdirSync(s)) copySafe(path.join(s, f), path.join(d, f)); } else { try { fs.copyFileSync(s, d); } catch (e) { } } }; copySafe(src, dest); }
      } else {
        fs.copyFileSync(src, dest);
      }
      copiedCount++;
    }

    res.json({
      success: true,
      message: `Update applied successfully! (${copiedCount} modules updated)`,
      backupLocation: backupDir
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Upload .zip / .rar Update Package API ─────────────────────────
// Allows customer or admin to upload an update ZIP directly in the browser
app.post('/api/system/upload-update-package', (req, res) => {
  const currentDir = process.cwd();
  const tempDir = path.join(currentDir, 'Backup', 'temp_update_' + Date.now());

  try {
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'Cannot create temp update folder: ' + e.message });
  }

  const tempZipPath = path.join(tempDir, 'incoming_update.zip');
  const writeStream = fs.createWriteStream(tempZipPath);

  req.pipe(writeStream);

  writeStream.on('error', (err) => {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch { }
    res.status(500).json({ success: false, error: 'Failed writing uploaded package: ' + err.message });
  });

  writeStream.on('finish', () => {
    try {
      if (!fs.existsSync(tempZipPath) || fs.statSync(tempZipPath).size < 1000) {
        throw new Error('Uploaded file is empty or too small to be a valid update archive.');
      }

      // 1. Create Pre-Update Safety Backup of customer databases & data
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupDir = path.join(currentDir, 'Backup', `PreUpdate_${timestamp}`);
      if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

      const dataDir = path.join(currentDir, 'data');
      if (fs.existsSync(dataDir)) {
        fs.cpSync(dataDir, path.join(backupDir, 'data'), { recursive: true });
      }

      // 2. Extract ZIP archive into temp extract folder
      const extractDir = path.join(tempDir, 'extracted');
      if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });

      let extractedOk = false;
      try {
        execSync(`tar -xf "${tempZipPath}" -C "${extractDir}"`, { timeout: 120000 });
        extractedOk = true;
      } catch (tarErr) {
        try {
          const psExtract = `powershell -NoProfile -Command "Expand-Archive -Path '${tempZipPath}' -DestinationPath '${extractDir}' -Force"`;
          execSync(psExtract, { timeout: 180000 });
          extractedOk = true;
        } catch (psErr) {
          throw new Error('Failed extracting update archive: ' + psErr.message);
        }
      }

      // 3. Find root folder containing core POS files (handles any zip structure, partial patches, or wrapped folders)
      let sourceDir = extractDir;
      function findCoreDirectory(dir, depth = 0) {
        if (depth > 5) return null;
        if (
          fs.existsSync(path.join(dir, 'index.html')) ||
          fs.existsSync(path.join(dir, 'js')) ||
          fs.existsSync(path.join(dir, 'server.js')) ||
          fs.existsSync(path.join(dir, 'version.json')) ||
          fs.existsSync(path.join(dir, 'modules')) ||
          fs.existsSync(path.join(dir, 'admin.js')) ||
          fs.existsSync(path.join(dir, 'print.js')) ||
          fs.existsSync(path.join(dir, 'pos.js'))
        ) {
          return dir;
        }
        try {
          const entries = fs.readdirSync(dir);
          for (const entry of entries) {
            if (entry === '__MACOSX' || entry === '.git') continue;
            const full = path.join(dir, entry);
            if (fs.statSync(full).isDirectory()) {
              const found = findCoreDirectory(full, depth + 1);
              if (found) return found;
            }
          }
        } catch (e) { }
        return null;
      }

      const detectedCore = findCoreDirectory(extractDir);
      if (detectedCore) {
        sourceDir = detectedCore;
      }

      // Verify that source has core POS files or valid patch modules
      const hasCore = fs.existsSync(path.join(sourceDir, 'index.html')) ||
        fs.existsSync(path.join(sourceDir, 'server.js')) ||
        fs.existsSync(path.join(sourceDir, 'js')) ||
        fs.existsSync(path.join(sourceDir, 'modules')) ||
        fs.existsSync(path.join(sourceDir, 'admin.js')) ||
        fs.existsSync(path.join(sourceDir, 'print.js')) ||
        fs.existsSync(path.join(sourceDir, 'pos.js'));
      if (!hasCore) {
        throw new Error('The uploaded archive does not contain valid Red Shark POS files (index.html or js folder not found).');
      }

      // 4. Customer Data Blacklist (100% PRESERVED - NEVER OVERWRITTEN)
      const PROTECTED = new Set([
        'data',
        'Backup',
        'temp_edge_profile',
        '.env',
        'scratch',
        '.git',
        '.agents',
        'node_modules'
      ]);

      // 5. Copy update items
      const itemsToCopy = fs.readdirSync(sourceDir);
      let copiedCount = 0;

      for (const item of itemsToCopy) {
        if (PROTECTED.has(item)) continue;
        if (['developer_generator.html', 'developer_decryptor.html', 'license_generator.html', 'generate_license.js'].includes(item)) continue;
        if (item.endsWith('.db') || item.endsWith('.lic') || item.endsWith('.req')) continue;

        const src = path.join(sourceDir, item);
        const stat = fs.statSync(src);

        // Smart patch routing: if standalone module files are uploaded at root of archive
        let dest = path.join(currentDir, item);
        if (!stat.isDirectory()) {
          if (['admin.js', 'pos.js', 'print.js', 'items.js', 'customers.js', 'sales.js', 'reports.js', 'finance.js', 'inventory.js'].includes(item)) {
            const modDir = path.join(currentDir, 'js', 'modules');
            if (fs.existsSync(modDir)) dest = path.join(modDir, item);
          } else if (['utils.js', 'db.js', 'app.js', 'auth.js', 'i18n.js'].includes(item)) {
            const jsDir = path.join(currentDir, 'js');
            if (fs.existsSync(jsDir)) dest = path.join(jsDir, item);
          }
        } else if (item === 'modules') {
          const jsDir = path.join(currentDir, 'js');
          if (fs.existsSync(jsDir)) dest = path.join(jsDir, 'modules');
        }

        if (stat.isDirectory()) {
          try { fs.cpSync(src, dest, { recursive: true, force: true }); } catch (cpErr) { const copySafe = (s, d) => { if (!fs.existsSync(s)) return; const st = fs.statSync(s); if (st.isDirectory()) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); for (const f of fs.readdirSync(s)) copySafe(path.join(s, f), path.join(d, f)); } else { try { fs.copyFileSync(s, d); } catch (e) { } } }; copySafe(src, dest); }
        } else {
          fs.copyFileSync(src, dest);
        }
        copiedCount++;
      }

      // 6. Get new version info
      let newVersion = '';
      let newBuild = '';
      const verPath = path.join(currentDir, 'version.json');
      if (fs.existsSync(verPath)) {
        try {
          const vObj = JSON.parse(fs.readFileSync(verPath, 'utf8'));
          newVersion = vObj.version;
          newBuild = vObj.build;
        } catch { }
      }

      // 7. Cleanup temp folder
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch { }

      res.json({
        success: true,
        message: `Update applied successfully! (${copiedCount} modules updated)`,
        version: newVersion,
        build: newBuild,
        backupLocation: backupDir
      });
    } catch (err) {
      try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch { }
      res.status(500).json({ success: false, error: err.message });
    }
  });
});

// ── 1-Click Cloud OTA Update Downloader & Safe Applier ────────────
app.post('/api/system/apply-cloud-update', async (req, res) => {
  const currentDir = process.cwd();
  const tempDir = path.join(currentDir, 'Backup', 'temp_ota_' + Date.now());
  const downloadUrl = req.body?.downloadUrl || 'https://shop.redshark-ai.com/dist/update.zip';

  try {
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    const tempZipPath = path.join(tempDir, 'ota_update.zip');

    // 1. Download update package
    const https = require('https');
    const http = require('http');

    const downloadFile = (url) => new Promise((resolve, reject) => {
      const client = url.startsWith('https') ? https : http;
      client.get(url, { timeout: 30000 }, (resp) => {
        if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
          return resolve(downloadFile(resp.headers.location));
        }
        if (resp.statusCode !== 200) {
          return reject(new Error('Download failed with status ' + resp.statusCode));
        }
        const fileStream = fs.createWriteStream(tempZipPath);
        resp.pipe(fileStream);
        fileStream.on('finish', () => fileStream.close(resolve));
        fileStream.on('error', reject);
      }).on('error', reject);
    });

    await downloadFile(downloadUrl);

    if (!fs.existsSync(tempZipPath) || fs.statSync(tempZipPath).size < 1000) {
      throw new Error('Downloaded update file is invalid or too small.');
    }

    // 2. Pre-Update Backup of customer database
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(currentDir, 'Backup', `PreUpdate_${timestamp}`);
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const dataDir = path.join(currentDir, 'data');
    if (fs.existsSync(dataDir)) {
      fs.cpSync(dataDir, path.join(backupDir, 'data'), { recursive: true });
    }

    // 3. Extract ZIP
    const extractDir = path.join(tempDir, 'extracted');
    if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });

    try {
      execSync(`tar -xf "${tempZipPath}" -C "${extractDir}"`, { timeout: 60000 });
    } catch (e1) {
      try {
        execSync(`powershell -NoProfile -Command "Expand-Archive -Path '${tempZipPath}' -DestinationPath '${extractDir}' -Force"`, { timeout: 120000 });
      } catch (e2) {
        throw new Error('Could not extract update archive: ' + e2.message);
      }
    }

    // 4. Copy update items, strictly preserving customer databases & data
    const PROTECTED = new Set(['data', 'Backup', 'temp_edge_profile', '.env', 'scratch', '.git', '.agents', 'node_modules']);
    const itemsToCopy = fs.readdirSync(extractDir);
    let copiedCount = 0;

    for (const item of itemsToCopy) {
      if (PROTECTED.has(item)) continue;
      if (item.endsWith('.db') || item.endsWith('.lic') || item.endsWith('.req')) continue;

      const src = path.join(extractDir, item);
      const dest = path.join(currentDir, item);
      const stat = fs.statSync(src);

      if (stat.isDirectory()) {
        try { fs.cpSync(src, dest, { recursive: true, force: true }); } catch (cpErr) { const copySafe = (s, d) => { if (!fs.existsSync(s)) return; const st = fs.statSync(s); if (st.isDirectory()) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); for (const f of fs.readdirSync(s)) copySafe(path.join(s, f), path.join(d, f)); } else { try { fs.copyFileSync(s, d); } catch (e) { } } }; copySafe(src, dest); }
      } else {
        fs.copyFileSync(src, dest);
      }
      copiedCount++;
    }

    // Cleanup temp
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch { }

    // Version info
    let newVersion = '1.2.33';
    let newBuild = 49;
    const vPath = path.join(currentDir, 'version.json');
    if (fs.existsSync(vPath)) {
      try {
        const vObj = JSON.parse(fs.readFileSync(vPath, 'utf8'));
        newVersion = vObj.version;
        newBuild = vObj.build;
      } catch { }
    }

    res.json({
      success: true,
      message: `OTA Update applied successfully! (${copiedCount} modules updated)`,
      version: newVersion,
      build: newBuild,
      backupLocation: backupDir
    });

    // Automatically restart server process so new endpoints and scripts become active
    setTimeout(() => {
      try {
        const { spawn } = require('child_process');
        const child = spawn(process.argv[0], process.argv.slice(1), {
          detached: true,
          stdio: 'ignore'
        });
        child.unref();
        process.exit(0);
      } catch (e) { }
    }, 1200);
  } catch (err) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch { }
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Launch Standalone Update_Customer_Software.bat ────────────────
app.post('/api/system/launch-update-bat', (req, res) => {
  try {
    const batPath = path.join(process.cwd(), 'Update_Customer_Software.bat');
    if (!fs.existsSync(batPath)) {
      return res.status(404).json({ success: false, error: 'Update_Customer_Software.bat was not found in the application directory.' });
    }

    const { spawn } = require('child_process');
    const child = spawn('cmd.exe', ['/c', 'start', '""', batPath], {
      cwd: process.cwd(),
      detached: true,
      stdio: 'ignore'
    });
    child.unref();

    res.json({ success: true, message: 'Update assistant launched on Windows desktop.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Get System Version ────────────────────────────────────────────
app.get('/api/system/version', (req, res) => {
  try {
    const verPath = path.join(process.cwd(), 'version.json');
    if (fs.existsSync(verPath)) {
      const vObj = JSON.parse(fs.readFileSync(verPath, 'utf8'));
      return res.json({ success: true, ...vObj });
    }
    res.json({ success: true, version: '1.2.0', build: 16 });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// ── MULTI-POS & BRANCH SYNC ENGINE ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════

function getLocalIpAddress() {
  const interfaces = os.networkInterfaces();
  for (const ifaceName of Object.keys(interfaces)) {
    for (const iface of interfaces[ifaceName]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

function loadSyncConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    }
  } catch (e) { }
  return {
    nodeRole: 'server', // 'server' (default) | 'pos' | 'branch'
    serverIp: getLocalIpAddress(),
    serverPort: PORT,
    nodeName: 'Main Server (Central Branch)',
    nodeId: 'SRV-01',
    branchId: 'main',
    syncTables: ['items', 'categories', 'offers', 'units']
  };
}

function saveSyncConfig(cfg) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving sync config:', e);
  }
}

function loadRegisteredNodes() {
  try {
    if (fs.existsSync(NODES_FILE)) {
      return JSON.parse(fs.readFileSync(NODES_FILE, 'utf8'));
    }
  } catch (e) { }
  return [];
}

function saveRegisteredNodes(nodes) {
  try {
    fs.writeFileSync(NODES_FILE, JSON.stringify(nodes, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving registered nodes:', e);
  }
}

// Active Server-Sent Events (SSE) client connections
const sseClients = new Map(); // clientId -> { res, info }

// Send 25s keepalive ping to maintain SSE connection across Cloudflare tunnels & proxies
setInterval(() => {
  for (const [clientId, client] of sseClients.entries()) {
    try {
      client.res.write(': keepalive\n\n');
    } catch (err) {
      sseClients.delete(clientId);
    }
  }
}, 25000);

function broadcastSyncEvent(eventName, payload = {}) {
  const msg = `data: ${JSON.stringify({ event: eventName, ...payload, timestamp: Date.now() })}\n\n`;
  for (const [clientId, client] of sseClients.entries()) {
    try {
      client.res.write(msg);
    } catch (err) {
      console.warn(`Error writing SSE to client ${clientId}:`, err.message);
      sseClients.delete(clientId);
    }
  }
}

function touchNode(nodeId, name, role, clientIp) {
  if (!nodeId) return;
  try {
    const nodes = loadRegisteredNodes();
    const cleanIp = (clientIp || '').replace(/^::ffff:/, '');
    const existing = nodes.find(n => n.nodeId === nodeId);
    if (existing) {
      existing.lastSeen = new Date().toISOString();
      if (cleanIp) existing.ip = cleanIp;
      if (name) existing.name = name;
      if (role) existing.role = role;
      saveRegisteredNodes(nodes);
    } else {
      nodes.push({
        nodeId,
        name: name || nodeId,
        role: role || 'branch',
        ip: cleanIp || '127.0.0.1',
        lastSeen: new Date().toISOString()
      });
      saveRegisteredNodes(nodes);
    }
  } catch (e) {
    console.warn('Error in touchNode:', e.message);
  }
}

// Keep-alive heartbeat every 15 seconds (prevents Cloudflare/proxy timeouts)
setInterval(() => {
  for (const [clientId, client] of sseClients.entries()) {
    try {
      client.res.write(': keep-alive\n\n');
    } catch (e) {
      sseClients.delete(clientId);
    }
  }
}, 15000);

// 1. GET /api/sync/status (Also registers/touches the node if parameters passed)
// GET /api/sync/cloud-status
app.get('/api/sync/cloud-status', (req, res) => {
  try {
    const db = readDb();
    const settings = db.settings || [];
    const getVal = (k, def) => {
      const found = settings.find(s => s.key === k);
      return found ? found.value : def;
    };
    res.json({
      success: true,
      role: getVal('sync_node_role', 'server'),
      nodeId: getVal('sync_node_id', 'main'),
      nodeName: getVal('sync_node_name', 'Main Store'),
      branchId: getVal('sync_branch_id', 'main'),
      terminalName: getVal('pos_terminal_name', 'POS-1'),
      shopSlug: getVal('online_store_shop_slug', 'shop101'),
      supabaseUrl: getVal('online_store_url', 'https://mcebwpiswvwqcdwjpagy.supabase.co'),
      lastSyncTime: getVal('last_cloud_sync_time', new Date().toISOString())
    });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

app.get('/api/sync/status', (req, res) => {
  const nodeId = req.query.nodeId;
  const name = req.query.name || req.query.nodeName;
  const role = req.query.role;
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';
  if (nodeId) {
    touchNode(nodeId, name, role, clientIp);
    broadcastSyncEvent('nodes_updated', { nodeId, lastSeen: new Date().toISOString() });
  }

  const localIp = getLocalIpAddress();
  const cfg = loadSyncConfig();
  res.json({
    success: true,
    localIp,
    port: PORT,
    serverUrl: `http://${localIp}:${PORT}`,
    connectedClients: sseClients.size,
    config: cfg
  });
});

// 1b. ALL /api/sync/ping (Explicit lightweight heartbeat endpoint for remote branches)
app.all('/api/sync/ping', (req, res) => {
  const nodeId = req.query.nodeId || req.body?.nodeId;
  const name = req.query.name || req.query.nodeName || req.body?.name || req.body?.nodeName;
  const role = req.query.role || req.body?.role || 'branch';
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';

  if (nodeId) {
    touchNode(nodeId, name, role, clientIp);
    broadcastSyncEvent('nodes_updated', { nodeId, lastSeen: new Date().toISOString() });
  }

  const since = parseInt(req.query.since || req.body?.since) || 0;
  const changes = since > 0 ? recentRecordChanges.filter(c => c.timestamp > since) : [];

  res.json({
    success: true,
    serverTime: new Date().toISOString(),
    timestamp: Date.now(),
    connectedClients: sseClients.size,
    receivedNodeId: nodeId || null,
    tableVersions,
    changes
  });
});

// 2. GET /api/sync/config
app.get('/api/sync/config', (req, res) => {
  res.json({ success: true, config: loadSyncConfig() });
});

// 3. POST /api/sync/config
app.post('/api/sync/config', (req, res) => {
  const cur = loadSyncConfig();
  const updated = { ...cur, ...req.body };
  saveSyncConfig(updated);
  broadcastSyncEvent('config_updated', { config: updated });
  res.json({ success: true, config: updated });
});

// 4. GET /api/sync/nodes (Enriched with real-time online status)
app.get('/api/sync/nodes', (req, res) => {
  const nodes = loadRegisteredNodes();
  const now = Date.now();
  const enriched = nodes.map(n => ({
    ...n,
    isOnline: sseClients.has(n.nodeId) || (n.lastSeen && (now - new Date(n.lastSeen).getTime() < 90000))
  }));
  res.json({ success: true, nodes: enriched, connectedClients: sseClients.size });
});

// 5. POST /api/sync/nodes (Add/Update/Delete nodes)
app.post('/api/sync/nodes', (req, res) => {
  const { action, node } = req.body;
  let nodes = loadRegisteredNodes();

  if (action === 'delete') {
    nodes = nodes.filter(n => n.nodeId !== node.nodeId);
  } else if (action === 'save') {
    const idx = nodes.findIndex(n => n.nodeId === node.nodeId);
    if (idx >= 0) {
      nodes[idx] = { ...nodes[idx], ...node, updatedAt: new Date().toISOString() };
    } else {
      nodes.push({ ...node, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
  }
  saveRegisteredNodes(nodes);
  broadcastSyncEvent('nodes_updated', { nodesCount: nodes.length });
  res.json({ success: true, nodes });
});

// 6. GET /api/sync/events (Real-time SSE Stream)
app.get('/api/sync/events', (req, res) => {
  const nodeId = req.query.nodeId || `CLIENT-${Date.now()}`;
  const nodeName = req.query.nodeName || 'Remote POS';
  const role = req.query.role || 'pos';
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.flushHeaders?.();

  // Send initial welcome & config
  const cfg = loadSyncConfig();
  res.write(`data: ${JSON.stringify({
    event: 'connected',
    nodeId,
    serverTime: new Date().toISOString(),
    syncTables: cfg.syncTables || []
  })}\n\n`);

  // Register in active connections
  sseClients.set(nodeId, {
    res,
    info: { nodeId, nodeName, role, clientIp, connectedAt: new Date().toISOString() }
  });

  // Also touch/update registered nodes list lastSeen
  touchNode(nodeId, nodeName, role, clientIp);

  req.on('close', () => {
    sseClients.delete(nodeId);
  });
});

// 6b. GET /api/sync/delta/:table (Bandwidth-Optimized Incremental Delta Sync)
app.get('/api/sync/delta/:table', (req, res) => {
  const tbl = req.params.table.replace(/[^a-zA-Z0-9_-]/g, '');
  const nodeId = req.query.nodeId;
  const clientIp = (req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '').replace(/^::ffff:/, '');
  const isLocalhost = (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp === 'localhost' || clientIp === '');
  const callerRole = (req.query.role || req.headers['x-sync-role'] || (isLocalhost ? 'server' : 'branch')).toLowerCase();
  const callerBranch = (req.query.branchId || req.headers['x-sync-branch-id'] || 'main').trim().toLowerCase();
  const since = req.query.since;
  let sinceMs = 0;
  if (since) {
    const parsed = new Date(since).getTime();
    if (!isNaN(parsed)) sinceMs = parsed;
    else if (/^\d+$/.test(since)) sinceMs = parseInt(since, 10);
  }

  if (nodeId) {
    touchNode(nodeId, req.query.name || nodeId, callerRole, clientIp);
  }

  const TRANSACTIONAL_TABLES = [
    'sales', 'sales_invoice', 'sale_items', 'quotation', 'sales_orders', 'delivery_order', 'sales_returns', 'deliveries',
    'purchase_invoices', 'purchase_returns', 'purchase_orders', 'goods_receipts', 'po_items', 'grn_items',
    'cash_transactions', 'bank_transactions', 'cashbox_sessions', 'cashbox_movements',
    'stock_movements', 'stock_adjustments'
  ];

  const filterForCaller = (records) => {
    if (!Array.isArray(records)) return [];
    if (callerRole === 'server') return records;

    if (tbl === 'stock_transfers') {
      return records.filter(r => {
        const toN = String(r.to_wh_name || '').toLowerCase();
        const fromN = String(r.from_wh_name || '').toLowerCase();
        const toId = String(r.to_wh_id || '').toLowerCase();
        const fromId = String(r.from_wh_id || '').toLowerCase();
        return toN.includes(callerBranch) || fromN.includes(callerBranch) ||
          toId === callerBranch || fromId === callerBranch ||
          callerBranch === 'main' || callerRole === 'server';
      });
    }

    if (!TRANSACTIONAL_TABLES.includes(tbl)) return records;

    return records.filter(r => {
      const rBranch = String(r.branch_id || r.syncBranchId || 'main').trim().toLowerCase();
      return rBranch === callerBranch;
    });
  };

  let allRecords = [];
  const filePath = path.join(TABLES_DIR, `${tbl}.json`);
  if (fs.existsSync(filePath)) {
    try {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (Array.isArray(data)) allRecords = data;
    } catch (e) { }
  }
  if (!allRecords.length) {
    try {
      const db = readDb();
      if (db && Array.isArray(db[tbl])) allRecords = db[tbl];
    } catch (e) { }
  }

  let filtered = filterForCaller(allRecords);

  // For items table sent to a branch: preserve branch autonomy by sending master attributes only
  if (tbl === 'items' && callerRole !== 'server') {
    filtered = filtered.map(r => ({
      id: r.id,
      barcode: r.barcode,
      item_code: r.item_code,
      name: r.name,
      name_ar: r.name_ar,
      name_en: r.name_en,
      category_id: r.category_id,
      category: r.category,
      selling_price: r.selling_price,
      cost_price: r.cost_price,
      wholesale_price: r.wholesale_price,
      min_price: r.min_price,
      vat_type: r.vat_type,
      vat_rate: r.vat_rate,
      unit: r.unit,
      min_stock: r.min_stock,
      is_active: r.is_active !== undefined ? r.is_active : true,
      created_at: r.created_at,
      updated_at: r.updated_at
    }));
  }

  let deltaRecords = filtered;
  if (sinceMs > 0) {
    deltaRecords = filtered.filter(r => {
      const u = r.updated_at ? new Date(r.updated_at).getTime() : 0;
      const c = r.created_at ? new Date(r.created_at).getTime() : 0;
      return (u > sinceMs || c > sinceMs);
    });
  }

  const deletedIds = (sinceMs > 0) ? getTombstones(tbl, sinceMs) : [];
  const nowIso = new Date().toISOString();

  res.json({
    success: true,
    table: tbl,
    delta: true,
    records: deltaRecords,
    deletedIds: deletedIds,
    count: deltaRecords.length,
    serverTime: nowIso
  });
});

// 7. GET /api/sync/table/:table (Download table data with strict branch isolation & lightweight delta)
app.get('/api/sync/table/:table', (req, res) => {
  const tbl = req.params.table.replace(/[^a-zA-Z0-9_-]/g, '');
  const nodeId = req.query.nodeId;
  const sinceQuery = req.query.since;
  const sinceMs = sinceQuery ? (isNaN(Number(sinceQuery)) ? new Date(sinceQuery).getTime() : Number(sinceQuery)) : 0;
  const clientIp = (req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '').replace(/^::ffff:/, '');
  const isLocalhost = (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp === 'localhost' || clientIp === '');
  const callerRole = (req.query.role || req.headers['x-sync-role'] || (isLocalhost ? 'server' : 'branch')).toLowerCase();
  const callerBranch = (req.query.branchId || req.headers['x-sync-branch-id'] || 'main').trim().toLowerCase();

  if (nodeId) {
    touchNode(nodeId, req.query.name || nodeId, callerRole, clientIp);
  }

  const TRANSACTIONAL_TABLES = [
    'sales', 'sales_invoice', 'sale_items', 'quotation', 'sales_orders', 'delivery_order', 'sales_returns', 'deliveries',
    'purchase_invoices', 'purchase_returns', 'purchase_orders', 'goods_receipts', 'po_items', 'grn_items',
    'cash_transactions', 'bank_transactions', 'cashbox_sessions', 'cashbox_movements',
    'stock_movements', 'stock_adjustments'
  ];

  const filterForCaller = (records) => {
    if (!Array.isArray(records)) return [];
    if (callerRole === 'server') return records; // Server admin receives full company-wide records

    // For stock transfers: branch sees transfers sent TO it or FROM it
    if (tbl === 'stock_transfers') {
      return records.filter(r => {
        const toN = String(r.to_wh_name || '').toLowerCase();
        const fromN = String(r.from_wh_name || '').toLowerCase();
        const toCode = String(r.to_wh_code || '').toLowerCase();
        const fromCode = String(r.from_wh_code || '').toLowerCase();
        const toId = String(r.to_wh_id || '').toLowerCase();
        const fromId = String(r.from_wh_id || '').toLowerCase();
        const b = callerBranch.toLowerCase();
        return toN.includes(b) || fromN.includes(b) ||
          toCode === b || fromCode === b ||
          toId === b || fromId === b ||
          b === 'main' || callerRole === 'server' ||
          // If branch is calling, also include any transfer destined to any non-server warehouse
          (toCode.startsWith('wh-0') && toCode !== 'wh-01') ||
          (toN.includes('branch') || toN.includes('فرع'));
      });
    }

    if (!TRANSACTIONAL_TABLES.includes(tbl)) return records; // Shared master tables (items, categories, etc.) are open

    // Strict backend branch isolation: branch caller ONLY receives its own branch records
    return records.filter(r => {
      const rBranch = String(r.branch_id || r.syncBranchId || 'main').trim().toLowerCase();
      return rBranch === callerBranch;
    });
  };

  // 1. Primary: If cached table snapshot exists in TABLES_DIR, read it first (has latest published records)
  const applyDeltaFilter = (records) => {
    const callerRecords = filterForCaller(records);
    if (sinceMs > 0) {
      return callerRecords.filter(r => {
        const u = r.updated_at ? new Date(r.updated_at).getTime() : 0;
        const c = r.created_at ? new Date(r.created_at).getTime() : 0;
        return (u > sinceMs || c > sinceMs);
      });
    }
    return callerRecords;
  };

  const filePath = path.join(TABLES_DIR, `${tbl}.json`);
  if (fs.existsSync(filePath)) {
    try {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (Array.isArray(data)) {
        const resultRecords = applyDeltaFilter(data);
        return res.json({ success: true, table: tbl, delta: sinceMs > 0, count: resultRecords.length, records: resultRecords });
      }
    } catch (e) { }
  }

  // 2. Secondary: Central database (db.dat)
  try {
    const db = readDb();
    if (db && Array.isArray(db[tbl])) {
      const resultRecords = applyDeltaFilter(db[tbl]);
      return res.json({ success: true, table: tbl, delta: sinceMs > 0, count: resultRecords.length, records: resultRecords });
    }
  } catch (dbErr) {
    console.warn(`[Sync] readDb fallback error for table ${tbl}:`, dbErr.message);
  }

  res.json({ success: true, table: tbl, records: [] });
});

// 8. POST /api/sync/table/:table (Save table snapshot & broadcast)
app.post('/api/sync/table/:table', (req, res) => {
  const tbl = req.params.table.replace(/[^a-zA-Z0-9_-]/g, '');
  let records = req.body.records || [];
  const clientIp = (req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '').replace(/^::ffff:/, '');
  const isLocalhost = (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp === 'localhost' || clientIp === '');
  const callerRole = (req.query.role || req.headers['x-sync-role'] || req.body?.role || (isLocalhost ? 'server' : 'branch')).toLowerCase();

  if (tbl === 'warehouses') {
    // Branch nodes are forbidden from overwriting the server's master warehouses table!
    const isBranchExplicit = (callerRole === 'branch' || req.query.role === 'branch' || req.body?.role === 'branch');
    if (isBranchExplicit || (!isLocalhost && callerRole !== 'server')) {
      console.warn(`[Sync] Blocked branch caller (${callerRole}, IP: ${clientIp}) from overwriting warehouses table`);
      return res.json({ success: true, table: tbl, ignored: true, reason: 'branch_cannot_overwrite_warehouses' });
    }
    // Always guarantee WH-01 is present as id: 1 and is_default: true
    const hasMainWh = records.some(w => (w.code || '').toUpperCase() === 'WH-01');
    if (!hasMainWh && records.length > 0) {
      records.unshift({
        id: 1,
        code: 'WH-01',
        name: 'المستودع الرئيسي (السيرفر)',
        name_ar: 'المستودع الرئيسي (السيرفر)',
        phone: '',
        address: '',
        is_default: true,
        updated_at: new Date().toISOString()
      });
    }
  }

  const filePath = path.join(TABLES_DIR, `${tbl}.json`);
  try {
    fs.writeFileSync(filePath, JSON.stringify(records), 'utf8');
    try {
      const db = readDb();
      if (db) {
        db[tbl] = records;
        writeDb(db);
      }
    } catch (dbErr) {
      console.warn(`[Sync] writeDb error for table ${tbl}:`, dbErr.message);
    }
    bumpTableVersion(tbl);
    broadcastSyncEvent('table_updated', { table: tbl, count: records.length });
    res.json({ success: true, table: tbl, count: records.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 9. POST /api/sync/notify (Trigger instant push on record change)
app.post('/api/sync/notify', (req, res) => {
  const { table, action, record, records } = req.body;
  const clientIp = (req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '').replace(/^::ffff:/, '');
  const isLocalhost = (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp === 'localhost' || clientIp === '');
  const callerRole = (req.query.role || req.headers['x-sync-role'] || req.body?.role || (isLocalhost ? 'server' : 'branch')).toLowerCase();

  if (table === 'warehouses') {
    if (callerRole !== 'server' && !isLocalhost) {
      return res.json({ success: true, ignored: true });
    }
  }

  if (table && records && Array.isArray(records)) {
    const filePath = path.join(TABLES_DIR, `${table}.json`);
    try {
      fs.writeFileSync(filePath, JSON.stringify(records), 'utf8');
      const db = readDb();
      if (db) {
        db[table] = records;
        writeDb(db);
      }
    } catch (e) { }
    broadcastSyncEvent('table_updated', { table, action: action || 'update', count: records.length });
    return res.json({ success: true });
  }

  if (table && record) {
    const filePath = path.join(TABLES_DIR, `${table}.json`);
    try {
      let currentRecords = [];
      if (fs.existsSync(filePath)) {
        try { currentRecords = JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch (e) { }
      }
      if (!Array.isArray(currentRecords) || currentRecords.length === 0) {
        const dbFallback = readDb();
        if (dbFallback && Array.isArray(dbFallback[table])) {
          currentRecords = [...dbFallback[table]];
        }
      }
      if (!Array.isArray(currentRecords)) currentRecords = [];

      const nowIso = new Date().toISOString();
      const enrichedRecord = { ...record, updated_at: record.updated_at || nowIso };

      if (action === 'delete' || record.deleted) {
        const delId = record.id != null ? String(record.id) : null;
        const delCode = (record.item_code || record.code || '').trim().toLowerCase();
        const delBarcode = record.barcode ? String(record.barcode).trim() : '';
        currentRecords = currentRecords.filter(r => {
          const rId = r.id != null ? String(r.id) : null;
          const rCode = (r.item_code || r.code || '').trim().toLowerCase();
          const rBarcode = r.barcode ? String(r.barcode).trim() : '';
          if (delId && rId && rId === delId) return false;
          if (delCode && rCode && rCode === delCode) return false;
          if (delBarcode && rBarcode && rBarcode === delBarcode) return false;
          return true;
        });
      } else {
        const recId = record.id != null ? String(record.id) : null;
        const recRef = (record.ref || record.invoice_no || record.receipt_no || '').trim().toLowerCase();
        const recUuid = record.uuid ? String(record.uuid).trim().toLowerCase() : null;
        const recCode = (record.item_code || record.code || '').trim().toLowerCase();
        const recBarcode = record.barcode ? String(record.barcode).trim() : '';

        const idx = currentRecords.findIndex(r => {
          const rId = r.id != null ? String(r.id) : null;
          const rRef = (r.ref || r.invoice_no || r.receipt_no || '').trim().toLowerCase();
          const rUuid = r.uuid ? String(r.uuid).trim().toLowerCase() : null;
          // For vouchers / transfers / invoices: match strictly by ref, uuid, or id
          if (recRef && rRef && rRef === recRef) return true;
          if (recUuid && rUuid && rUuid === recUuid) return true;
          if (recId && rId && rId === recId) return true;
          // ONLY for catalog items table: match by item_code or barcode
          if (table === 'items') {
            const rCode = (r.item_code || r.code || '').trim().toLowerCase();
            const rBarcode = r.barcode ? String(r.barcode).trim() : '';
            if (recCode && rCode && rCode === recCode) return true;
            if (recBarcode && rBarcode && rBarcode === recBarcode) return true;
          }
          return false;
        });
        if (idx >= 0) {
          currentRecords[idx] = { ...currentRecords[idx], ...enrichedRecord };
        } else {
          currentRecords.push(enrichedRecord);
        }
      }

      fs.writeFileSync(filePath, JSON.stringify(currentRecords), 'utf8');
      const db = readDb();
      if (db) {
        db[table] = currentRecords;
        writeDb(db);
      }

      recordSyncChange(table, action, enrichedRecord);
      broadcastSyncEvent('record_changed', { table, action: action || 'update', record: enrichedRecord });
      broadcastSyncEvent('table_updated', { table, action: action || 'update' });
      return res.json({ success: true, record: enrichedRecord });
    } catch (e) {
      console.warn(`[Sync] notify record error:`, e.message);
    }
  }

  broadcastSyncEvent('table_updated', { table, action: action || 'update' });
  res.json({ success: true });
});

// 10. POST /api/sync/push-transactions (Branches upload sales, purchases & cashbox sessions)
app.post('/api/sync/push-transactions', (req, res) => {
  try {
    const {
      nodeId, branchId, branchName,
      sales, salesInvoices, salesReturns,
      purchaseInvoices, purchaseReturns,
      cashboxSessions, cashboxMovements, cashTransactions,
      stockAdjustments, branchStockSnapshot,
      customers,
      deletedTxnRefs
    } = req.body;

    let existing = { sales: [], purchases: [], purchaseReturns: [], salesReturns: [], cashboxSessions: [], cashboxMovements: [], cashTransactions: [] };
    if (fs.existsSync(TRANSACTIONS_FILE)) {
      try { existing = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8')); } catch (e) { }
    }
    if (!existing.sales) existing.sales = [];
    if (!existing.purchases) existing.purchases = [];
    if (!existing.purchaseReturns) existing.purchaseReturns = [];
    if (!existing.salesReturns) existing.salesReturns = [];
    if (!existing.cashboxSessions) existing.cashboxSessions = [];
    if (!existing.cashTransactions) existing.cashTransactions = [];

    const db = readDb();
    if (!db['sales']) db['sales'] = [];
    if (!db['sales_invoice']) db['sales_invoice'] = [];
    if (!db['sales_returns']) db['sales_returns'] = [];
    if (!db['purchase_invoices']) db['purchase_invoices'] = [];
    if (!db['purchase_returns']) db['purchase_returns'] = [];
    if (!db['cash_transactions']) db['cash_transactions'] = [];
    if (!db['bank_transactions']) db['bank_transactions'] = [];

    // Purge any deleted transaction references immediately
    if (Array.isArray(deletedTxnRefs) && deletedTxnRefs.length > 0) {
      const delSet = new Set(deletedTxnRefs.map(r => String(r).trim()));
      existing.cashTransactions = (existing.cashTransactions || []).filter(t => !delSet.has(String(t.ref || t.id)));
      existing.sales = (existing.sales || []).filter(t => !delSet.has(String(t.ref || t.id)));
      if (Array.isArray(db['cash_transactions'])) {
        db['cash_transactions'] = db['cash_transactions'].filter(t => !delSet.has(String(t.ref || t.id)));
      }
      if (Array.isArray(db['bank_transactions'])) {
        db['bank_transactions'] = db['bank_transactions'].filter(t => !delSet.has(String(t.ref || t.id)));
      }
    }

    const effectiveBranchId = branchId || nodeId || 'branch-1';
    const effectiveBranchName = branchName || (effectiveBranchId === 'main' ? 'الفرع الرئيسي' : effectiveBranchId);

    // Identity matcher: strict UUID or (same branch + same ref)
    const isSameTxn = (a, b) => {
      if (a.uuid && b.uuid && String(a.uuid).trim() === String(b.uuid).trim()) return true;
      const aBranch = String(a.branch_id || a.syncBranchId || effectiveBranchId).trim().toLowerCase();
      const bBranch = String(b.branch_id || b.syncBranchId || effectiveBranchId).trim().toLowerCase();
      if (aBranch === bBranch) {
        const aRef = String(a.ref || a.invoice_no || '').trim();
        const bRef = String(b.ref || b.invoice_no || '').trim();
        if (aRef && bRef && aRef === bRef) return true;
      }
      return false;
    };

    // 1. Merge sales (sales & sales_invoice)
    const allIncomingSales = [...(Array.isArray(sales) ? sales : []), ...(Array.isArray(salesInvoices) ? salesInvoices : [])];
    for (const s of allIncomingSales) {
      const enriched = {
        ...s,
        syncNodeId: nodeId,
        syncBranchId: effectiveBranchId,
        branch_id: s.branch_id || effectiveBranchId,
        branch_name: s.branch_name || effectiveBranchName,
        sync_status: 'synced',
        synced_at: new Date().toISOString()
      };

      const idx = existing.sales.findIndex(x => isSameTxn(s, x));
      if (idx >= 0) existing.sales[idx] = { ...existing.sales[idx], ...enriched };
      else existing.sales.push(enriched);

      const targetStore = (s.store === 'sales_invoice') ? db['sales_invoice'] : db['sales'];
      const dbIdx = targetStore.findIndex(x => isSameTxn(s, x));
      if (dbIdx >= 0) {
        targetStore[dbIdx] = { ...targetStore[dbIdx], ...enriched, id: targetStore[dbIdx].id };
      } else {
        const ids = targetStore.map(x => parseInt(x.id)).filter(x => !isNaN(x));
        const maxId = ids.length ? Math.max(...ids) : 0;
        targetStore.push({ ...enriched, id: maxId + 1, original_client_id: s.id });
      }
    }

    // 2. Merge sales returns
    if (Array.isArray(salesReturns)) {
      for (const sr of salesReturns) {
        const enriched = {
          ...sr,
          syncNodeId: nodeId,
          syncBranchId: effectiveBranchId,
          branch_id: sr.branch_id || effectiveBranchId,
          branch_name: sr.branch_name || effectiveBranchName,
          sync_status: 'synced',
          synced_at: new Date().toISOString()
        };
        const idx = existing.salesReturns.findIndex(x => isSameTxn(sr, x));
        if (idx >= 0) existing.salesReturns[idx] = { ...existing.salesReturns[idx], ...enriched };
        else existing.salesReturns.push(enriched);

        const dbIdx = db['sales_returns'].findIndex(x => isSameTxn(sr, x));
        if (dbIdx >= 0) {
          db['sales_returns'][dbIdx] = { ...db['sales_returns'][dbIdx], ...enriched, id: db['sales_returns'][dbIdx].id };
        } else {
          const ids = db['sales_returns'].map(x => parseInt(x.id)).filter(x => !isNaN(x));
          const maxId = ids.length ? Math.max(...ids) : 0;
          db['sales_returns'].push({ ...enriched, id: maxId + 1, original_client_id: sr.id });
        }
      }
    }

    // 3. Merge purchase invoices
    if (Array.isArray(purchaseInvoices)) {
      for (const p of purchaseInvoices) {
        const enriched = {
          ...p,
          syncNodeId: nodeId,
          syncBranchId: effectiveBranchId,
          branch_id: p.branch_id || effectiveBranchId,
          branch_name: p.branch_name || effectiveBranchName,
          sync_status: 'synced',
          synced_at: new Date().toISOString()
        };
        const idx = existing.purchases.findIndex(x => isSameTxn(p, x));
        if (idx >= 0) existing.purchases[idx] = { ...existing.purchases[idx], ...enriched };
        else existing.purchases.push(enriched);

        const dbIdx = db['purchase_invoices'].findIndex(x => isSameTxn(p, x));
        if (dbIdx >= 0) {
          db['purchase_invoices'][dbIdx] = { ...db['purchase_invoices'][dbIdx], ...enriched, id: db['purchase_invoices'][dbIdx].id };
        } else {
          const ids = db['purchase_invoices'].map(x => parseInt(x.id)).filter(x => !isNaN(x));
          const maxId = ids.length ? Math.max(...ids) : 0;
          db['purchase_invoices'].push({ ...enriched, id: maxId + 1, original_client_id: p.id });
        }
      }
    }

    // 4. Merge purchase returns
    if (Array.isArray(purchaseReturns)) {
      for (const pr of purchaseReturns) {
        const enriched = {
          ...pr,
          syncNodeId: nodeId,
          syncBranchId: effectiveBranchId,
          branch_id: pr.branch_id || effectiveBranchId,
          branch_name: pr.branch_name || effectiveBranchName,
          sync_status: 'synced',
          synced_at: new Date().toISOString()
        };
        const idx = existing.purchaseReturns.findIndex(x => isSameTxn(pr, x));
        if (idx >= 0) existing.purchaseReturns[idx] = { ...existing.purchaseReturns[idx], ...enriched };
        else existing.purchaseReturns.push(enriched);

        const dbIdx = db['purchase_returns'].findIndex(x => isSameTxn(pr, x));
        if (dbIdx >= 0) {
          db['purchase_returns'][dbIdx] = { ...db['purchase_returns'][dbIdx], ...enriched, id: db['purchase_returns'][dbIdx].id };
        } else {
          const ids = db['purchase_returns'].map(x => parseInt(x.id)).filter(x => !isNaN(x));
          const maxId = ids.length ? Math.max(...ids) : 0;
          db['purchase_returns'].push({ ...enriched, id: maxId + 1, original_client_id: pr.id });
        }
      }
    }

    // 5b. Merge cashbox movements
    if (!existing.cashboxMovements) existing.cashboxMovements = [];
    if (!db['cashbox_movements']) db['cashbox_movements'] = [];
    if (Array.isArray(cashboxMovements)) {
      for (const cm of cashboxMovements) {
        const enriched = {
          ...cm,
          syncNodeId: nodeId,
          syncBranchId: effectiveBranchId,
          branch_id: cm.branch_id || effectiveBranchId
        };
        const idx = existing.cashboxMovements.findIndex(x => {
          if (cm.uuid && x.uuid && cm.uuid === x.uuid) return true;
          if (cm.id && x.id && String(cm.id) === String(x.id) && cm.session_id === x.session_id) return true;
          return false;
        });
        if (idx >= 0) existing.cashboxMovements[idx] = { ...existing.cashboxMovements[idx], ...enriched };
        else existing.cashboxMovements.push(enriched);

        if (Array.isArray(db['cashbox_movements'])) {
          const dbIdx = db['cashbox_movements'].findIndex(x => {
            if (cm.uuid && x.uuid && cm.uuid === x.uuid) return true;
            if (cm.id && x.id && String(cm.id) === String(x.id) && cm.session_id === x.session_id) return true;
            return false;
          });
          if (dbIdx >= 0) {
            db['cashbox_movements'][dbIdx] = { ...db['cashbox_movements'][dbIdx], ...enriched };
          } else {
            db['cashbox_movements'].push(enriched);
          }
        }
      }
    }

    // 5. Merge cashbox sessions
    if (Array.isArray(cashboxSessions)) {
      for (const cb of cashboxSessions) {
        const enriched = {
          ...cb,
          syncNodeId: nodeId,
          syncBranchId: effectiveBranchId,
          branch_id: cb.branch_id || effectiveBranchId,
          branch_name: cb.branch_name || effectiveBranchName,
          sync_status: 'synced',
          synced_at: new Date().toISOString()
        };
        const idx = existing.cashboxSessions.findIndex(x => {
          if (cb.session_id && x.session_id && String(x.session_id).trim() === String(cb.session_id).trim()) return true;
          if (cb.uuid && x.uuid && cb.uuid === x.uuid) return true;
          return false;
        });
        if (idx >= 0) existing.cashboxSessions[idx] = { ...existing.cashboxSessions[idx], ...enriched };
        else existing.cashboxSessions.push(enriched);

        if (Array.isArray(db['cashbox_sessions'])) {
          const dbIdx = db['cashbox_sessions'].findIndex(x => {
            if (cb.session_id && x.session_id && String(x.session_id).trim() === String(cb.session_id).trim()) return true;
            if (cb.uuid && x.uuid && cb.uuid === x.uuid) return true;
            return false;
          });
          if (dbIdx >= 0) {
            db['cashbox_sessions'][dbIdx] = { ...db['cashbox_sessions'][dbIdx], ...enriched };
          } else {
            db['cashbox_sessions'].push(enriched);
          }
        }
      }
    }

    // 6. Merge cash transactions
    if (Array.isArray(cashTransactions)) {
      for (const ct of cashTransactions) {
        const enriched = {
          ...ct,
          syncNodeId: nodeId,
          syncBranchId: effectiveBranchId,
          branch_id: ct.branch_id || effectiveBranchId,
          branch_name: ct.branch_name || effectiveBranchName,
          sync_status: 'synced',
          synced_at: new Date().toISOString()
        };
        const idx = existing.cashTransactions.findIndex(x => isSameTxn(ct, x));
        if (idx >= 0) existing.cashTransactions[idx] = { ...existing.cashTransactions[idx], ...enriched };
        else existing.cashTransactions.push(enriched);

        if (Array.isArray(db['cash_transactions'])) {
          const dbIdx = db['cash_transactions'].findIndex(x => isSameTxn(ct, x));
          if (dbIdx >= 0) {
            db['cash_transactions'][dbIdx] = { ...db['cash_transactions'][dbIdx], ...enriched };
          } else {
            const ids = db['cash_transactions'].map(x => parseInt(x.id)).filter(x => !isNaN(x));
            const maxId = ids.length ? Math.max(...ids) : 0;
            db['cash_transactions'].push({ ...enriched, id: maxId + 1, original_client_id: ct.id });
          }
        }
      }
    }

    // 7. Merge customer updates & balance from branch
    const incomingCustomers = Array.isArray(customers) ? customers : [];
    let custModified = false;
    if (incomingCustomers.length > 0) {
      if (!db['customers']) db['customers'] = [];
      for (const cust of incomingCustomers) {
        if (!cust) continue;
        const cPhone = cust.phone ? String(cust.phone).trim() : null;
        const cName = (cust.name_ar || cust.name_en || cust.name || '').trim().toLowerCase();
        const cId = (cust.id != null) ? String(cust.id) : null;

        const idx = db['customers'].findIndex(x => {
          if (cId && String(x.id) === cId) return true;
          if (cPhone && x.phone && String(x.phone).trim() === cPhone) return true;
          const xName = (x.name_ar || x.name_en || x.name || '').trim().toLowerCase();
          if (cName && xName && cName === xName) return true;
          return false;
        });

        const incomingTime = cust.updated_at ? new Date(cust.updated_at).getTime() : Date.now();

        if (idx >= 0) {
          const localTime = db['customers'][idx].updated_at ? new Date(db['customers'][idx].updated_at).getTime() : 0;
          const incomingBal = parseFloat(cust.balance) || 0;
          const localBal = parseFloat(db['customers'][idx].balance) || 0;
          // Protect server: never accept an incoming negative balance if server has a non-negative balance
          if (incomingBal < 0 && localBal >= 0) {
            continue;
          }
          // Only accept incoming branch balance if incoming record is strictly newer than server
          if (incomingTime > localTime) {
            db['customers'][idx] = {
              ...db['customers'][idx],
              ...cust,
              id: db['customers'][idx].id, // preserve server ID
              balance: incomingBal,
              points_balance: parseInt(cust.points_balance) || 0,
              updated_at: cust.updated_at || new Date().toISOString()
            };
            custModified = true;
          }
        } else {
          const ids = db['customers'].map(x => parseInt(x.id)).filter(x => !isNaN(x));
          const maxId = ids.length ? Math.max(...ids) : 0;
          db['customers'].push({
            ...cust,
            id: maxId + 1,
            balance: parseFloat(cust.balance) || 0,
            points_balance: parseInt(cust.points_balance) || 0,
            updated_at: cust.updated_at || new Date().toISOString()
          });
          custModified = true;
        }
      }

      if (custModified) {
        try {
          fs.writeFileSync(path.join(TABLES_DIR, 'customers.json'), JSON.stringify(db['customers']), 'utf8');
        } catch (e) { }
        broadcastSyncEvent('table_updated', { table: 'customers', count: db['customers'].length });
      }
    }

    // 8. Merge Stock Adjustments from Branch Physical Inventory Count
    const incomingAdjustments = Array.isArray(stockAdjustments) ? stockAdjustments : [];
    if (incomingAdjustments.length > 0) {
      if (!db['stock_adjustments']) db['stock_adjustments'] = [];
      for (const adj of incomingAdjustments) {
        if (!adj) continue;
        const aRef = adj.ref || ('ADJ-' + adj.id);
        const exists = db['stock_adjustments'].some(x => (x.ref && x.ref === aRef) || (x.id && adj.id && String(x.id) === String(adj.id)));
        if (!exists) {
          const ids = db['stock_adjustments'].map(x => parseInt(x.id)).filter(x => !isNaN(x));
          const maxId = ids.length ? Math.max(...ids) : 0;
          db['stock_adjustments'].push({
            ...adj,
            id: maxId + 1,
            syncBranchId: effectiveBranchId,
            branch_id: adj.branch_id || effectiveBranchId,
            branch_name: adj.branch_name || effectiveBranchName,
            sync_status: 'synced'
          });
        }
      }
    }

    // 9. Update Branch Warehouse Stock Levels from Positive Stock Snapshot
    const incomingStockSnapshot = Array.isArray(branchStockSnapshot) ? branchStockSnapshot : [];
    if (incomingStockSnapshot.length > 0) {
      const warehouses = db['warehouses'] || [];
      const branchWh = warehouses.find(w => {
        const wid = String(w.id);
        const wCode = (w.code || '').trim().toLowerCase();
        const wName = (w.name || '').trim().toLowerCase();
        const bId = String(effectiveBranchId).trim().toLowerCase();
        return wid === bId || wCode === bId || (bId && (wName.includes(bId) || bId.includes(wName)));
      }) || warehouses.find(w => !w.is_default && String(w.id) !== '1');

      if (branchWh && Array.isArray(db['items'])) {
        const whIdStr = String(branchWh.id);
        for (const snap of incomingStockSnapshot) {
          if (!snap || snap.stock_qty == null) continue;
          const sBc = snap.barcode ? String(snap.barcode).trim() : '';
          const sCode = snap.item_code ? String(snap.item_code).trim().toLowerCase() : '';
          const sId = snap.id != null ? String(snap.id) : null;

          const sItem = (sBc && db['items'].find(i => i.barcode && String(i.barcode).trim() === sBc))
            || (sCode && db['items'].find(i => i.item_code && String(i.item_code).trim().toLowerCase() === sCode))
            || (sId && db['items'].find(i => String(i.id) === sId));

          if (sItem) {
            if (!sItem.warehouse_stocks || typeof sItem.warehouse_stocks !== 'object') {
              sItem.warehouse_stocks = {};
            }
            sItem.warehouse_stocks[whIdStr] = parseFloat(snap.stock_qty) || 0;
            sItem.updated_at = new Date().toISOString();
          }
        }
        try {
          fs.writeFileSync(path.join(TABLES_DIR, 'items.json'), JSON.stringify(db['items']), 'utf8');
        } catch (e) { }
      }
    }

    fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(existing, null, 2), 'utf8');
    writeDb(db);

    if (nodeId) {
      const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';
      touchNode(nodeId, nodeId, 'branch', clientIp);
    }
    broadcastSyncEvent('transactions_received', { nodeId, branchId: effectiveBranchId, count: allIncomingSales.length });
    res.json({
      success: true,
      message: 'Transactions merged successfully',
      salesCount: allIncomingSales.length,
      purchasesCount: (purchaseInvoices || []).length
    });
  } catch (err) {
    console.error('[Sync] Error pushing transactions:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 11. GET /api/sync/transactions (Server reports & branches fetch consolidated cross-branch transactions)
app.get('/api/sync/transactions', (req, res) => {
  try {
    let existing = { sales: [], purchases: [], purchaseReturns: [], salesReturns: [], cashboxSessions: [], cashTransactions: [] };
    if (fs.existsSync(TRANSACTIONS_FILE)) {
      try { existing = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8')); } catch (e) { }
    }
    const db = readDb();
    const serverSales = (db['sales'] || []).map(s => ({
      ...s,
      syncBranchId: s.branch_id || s.syncBranchId || 'main',
      branch_name: s.branch_name || 'الفرع الرئيسي (Main Branch)'
    }));
    const serverInvoices = (db['sales_invoice'] || []).map(i => ({
      ...i,
      store: 'sales_invoice',
      syncBranchId: i.branch_id || i.syncBranchId || 'main',
      branch_name: i.branch_name || 'الفرع الرئيسي (Main Branch)'
    }));
    const serverReturns = (db['sales_returns'] || []).map(r => ({
      ...r,
      store: 'sales_returns',
      syncBranchId: r.branch_id || r.syncBranchId || 'main',
      branch_name: r.branch_name || 'الفرع الرئيسي (Main Branch)'
    }));
    const serverPurchases = (db['purchase_invoices'] || []).map(p => ({
      ...p,
      store: 'purchase_invoices',
      syncBranchId: p.branch_id || p.syncBranchId || 'main',
      branch_name: p.branch_name || 'الفرع الرئيسي (Main Branch)'
    }));
    const serverPurReturns = (db['purchase_returns'] || []).map(pr => ({
      ...pr,
      store: 'purchase_returns',
      syncBranchId: pr.branch_id || pr.syncBranchId || 'main',
      branch_name: pr.branch_name || 'الفرع الرئيسي (Main Branch)'
    }));
    const serverCashTxns = (db['cash_transactions'] || []).map(t => ({
      ...t,
      syncBranchId: t.branch_id || t.syncBranchId || 'main',
      branch_name: t.branch_name || 'الفرع الرئيسي (Main Branch)'
    }));

    // Combine avoiding duplicate records using UUID or (branch_id + ref)
    const seenSaleKeys = new Set();
    const unifiedSales = [];
    [...(existing.sales || []), ...serverSales, ...serverInvoices, ...(existing.salesReturns || []), ...serverReturns].forEach(s => {
      const k = s.uuid ? `uuid::${s.uuid}` : `${s.syncBranchId || s.branch_id || 'main'}::${s.ref || s.invoice_no || s.id}`;
      if (!seenSaleKeys.has(k)) {
        seenSaleKeys.add(k);
        unifiedSales.push(s);
      }
    });

    const seenPurKeys = new Set();
    const unifiedPurchases = [];
    [...(existing.purchases || []), ...serverPurchases, ...(existing.purchaseReturns || []), ...serverPurReturns].forEach(p => {
      const k = p.uuid ? `uuid::${p.uuid}` : `${p.syncBranchId || p.branch_id || 'main'}::${p.ref || p.supplier_invoice_no || p.id}`;
      if (!seenPurKeys.has(k)) {
        seenPurKeys.add(k);
        unifiedPurchases.push(p);
      }
    });

    const seenTxnKeys = new Set();
    const unifiedCashTxns = [];
    [...(existing.cashTransactions || []), ...serverCashTxns].forEach(t => {
      const k = t.uuid ? `uuid::${t.uuid}` : `${t.syncBranchId || t.branch_id || 'main'}::${t.ref || t.id}`;
      if (!seenTxnKeys.has(k)) {
        seenTxnKeys.add(k);
        unifiedCashTxns.push(t);
      }
    });

    const clientIp = (req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '').replace(/^::ffff:/, '');
    const isLocalhost = (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp === 'localhost' || clientIp === '');
    const callerRole = (req.query.role || req.headers['x-sync-role'] || (isLocalhost ? 'server' : 'branch')).toLowerCase();
    const callerBranch = (req.query.clientBranchId || req.headers['x-sync-branch-id'] || 'main').trim().toLowerCase();
    const requestedBranch = (req.query.branchId || '').trim().toLowerCase();
    const nodeId = req.query.nodeId;
    const customerId = req.query.customerId;
    const supplierId = req.query.supplierId;

    let effectiveBranch = '';
    if (callerRole !== 'server') {
      const trustedBranch = callerBranch || 'branch-1';
      // Attempting to access another branch's transactions is forbidden
      if (requestedBranch && requestedBranch !== 'all' && requestedBranch !== trustedBranch) {
        return res.status(403).json({
          success: false,
          error: `Access Denied: Station assigned to '${trustedBranch}' is not authorized to access transactions of branch '${requestedBranch}'`
        });
      }
      if (requestedBranch === 'all') {
        return res.status(403).json({
          success: false,
          error: "Access Denied: Consolidated multi-branch reports are restricted to authorized Server Administrators"
        });
      }
      effectiveBranch = trustedBranch;
    } else {
      effectiveBranch = requestedBranch;
    }

    let filteredSales = unifiedSales;
    let filteredPurchases = unifiedPurchases;
    let filteredCashbox = existing.cashboxSessions || [];
    let filteredMovements = existing.cashboxMovements || [];
    let filteredTxns = unifiedCashTxns;

    if (effectiveBranch && effectiveBranch !== 'all') {
      filteredSales = filteredSales.filter(s => {
        const b = String(s.syncBranchId || s.branch_id || 'main').trim().toLowerCase();
        return b === effectiveBranch;
      });
      filteredPurchases = filteredPurchases.filter(p => {
        const b = String(p.syncBranchId || p.branch_id || 'main').trim().toLowerCase();
        return b === effectiveBranch;
      });
      filteredCashbox = filteredCashbox.filter(cb => {
        const b = String(cb.syncBranchId || cb.branch_id || 'main').trim().toLowerCase();
        return b === effectiveBranch;
      });
      filteredTxns = filteredTxns.filter(t => {
        const b = String(t.syncBranchId || t.branch_id || 'main').trim().toLowerCase();
        return b === effectiveBranch;
      });
    }
    if (nodeId && nodeId !== 'all') {
      filteredSales = filteredSales.filter(s => s.syncNodeId === nodeId);
      filteredPurchases = filteredPurchases.filter(p => p.syncNodeId === nodeId);
      filteredCashbox = filteredCashbox.filter(cb => cb.syncNodeId === nodeId);
    }
    if (customerId) {
      filteredSales = filteredSales.filter(s => String(s.customer_id) === String(customerId));
      filteredTxns = filteredTxns.filter(t => String(t.customer_id) === String(customerId));
    }
    if (supplierId) {
      filteredPurchases = filteredPurchases.filter(p => String(p.supplier_id) === String(supplierId));
      filteredTxns = filteredTxns.filter(t => String(t.supplier_id) === String(supplierId));
    }

    return res.json({
      success: true,
      sales: filteredSales,
      purchases: filteredPurchases,
      cashboxSessions: filteredCashbox,
      cashboxMovements: filteredMovements,
      cashTransactions: filteredTxns,
      customers: db['customers'] || []
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Persistent Background Cloud Heartbeat Daemon ──────────────────
// Runs 24/7 at the OS/Node.js level so neither server nor branches ever go offline
async function runCloudHeartbeatDaemon() {
  try {
    const db = readDb();
    const settings = db.settings || [];
    const getVal = (k, def) => {
      const found = settings.find(s => s.key === k);
      return (found && found.value != null && found.value !== '') ? found.value : def;
    };

    let slug = (getVal('online_store_shop_slug') || getVal('online_store_slug') || '').trim();
    if (!slug) {
      const slugFile = path.join(__dirname, 'data', 'shop_slug.txt');
      if (fs.existsSync(slugFile)) {
        try { slug = fs.readFileSync(slugFile, 'utf8').trim(); } catch (e) { }
      }
    }
    if (!slug) slug = 'bobmarket';

    const url = (getVal('online_store_url') || 'https://mcebwpiswvwqcdwjpagy.supabase.co').trim();
    const key = (getVal('online_store_key') || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg').trim();
    const role = (getVal('sync_node_role') || 'server').trim();
    const nodeId = (getVal('sync_node_id') || (role === 'server' ? 'SRV-01' : 'POS-01')).trim();
    const nodeName = (getVal('sync_node_name') || (role === 'server' ? 'Main Server' : 'POS Terminal')).trim();
    const branchId = (getVal('sync_branch_id') || 'main').trim();

    const res = await fetch(`${url}/rest/v1/tenants?slug=eq.${encodeURIComponent(slug)}&select=id,banner_url`, {
      headers: { 'apikey': key, 'Authorization': `Bearer ${key}` },
      signal: AbortSignal.timeout(6000)
    });
    if (!res.ok) return;
    const tData = await res.json();
    if (!tData || !tData[0]) return;

    let bObj = {};
    try {
      bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
    } catch (e) { }

    bObj.connected_branches = bObj.connected_branches || [];
    const existingIdx = bObj.connected_branches.findIndex(b => b.nodeId === nodeId);
    const branchEntry = {
      nodeId: nodeId,
      name: nodeName,
      branchId: branchId,
      role: role,
      lastSeen: new Date().toISOString(),
      isOnline: true,
      appBuild: (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, 'version.json'), 'utf8')).build || 105; } catch (e) { return 105; } })()
    };

    if (existingIdx >= 0) {
      bObj.connected_branches[existingIdx] = branchEntry;
    } else {
      bObj.connected_branches.push(branchEntry);
    }

    await fetch(`${url}/rest/v1/tenants?id=eq.${tData[0].id}`, {
      method: 'PATCH',
      headers: {
        'apikey': key,
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
    });
  } catch (err) {
    // Silent fail if network unreachable
  }
}

// Start cloud daemon loop (runs every 25s persistently)
setInterval(runCloudHeartbeatDaemon, 25000);
setTimeout(runCloudHeartbeatDaemon, 2500);

// ══════════════════════════════════════════════════════════════════════════════
// ── DIRECT SELF-HOSTED STOREFRONT & MANAGER REST API (100% ZERO-COST / NO SUPABASE) ──
// ══════════════════════════════════════════════════════════════════════════════

function getOnlineOrders() {
  const ordersFile = path.join(TABLES_DIR, 'online_orders.json');
  try {
    if (fs.existsSync(ordersFile)) {
      const parsed = JSON.parse(fs.readFileSync(ordersFile, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) { }
  try {
    const db = readDb();
    if (Array.isArray(db.online_orders)) return db.online_orders;
  } catch (e) { }
  return [];
}

function saveOnlineOrders(orders) {
  const ordersFile = path.join(TABLES_DIR, 'online_orders.json');
  try {
    fs.writeFileSync(ordersFile, JSON.stringify(orders, null, 2), 'utf8');
  } catch (e) { }
  try {
    const db = readDb();
    db.online_orders = orders;
    writeDb(db);
  } catch (e) { }
}

// 1. GET /rest/v1/tenants (Local Shop Profile compatibility for Storefront & Manager App)
app.get('/rest/v1/tenants', (req, res) => {
  try {
    const db = readDb();
    const settings = db.settings || [];
    const getVal = (k, def) => {
      const found = settings.find(s => s.key === k);
      return found ? found.value : def;
    };

    const slugReq = (req.query.slug || '').replace(/^eq\./, '').trim().toLowerCase();
    const configuredSlug = (getVal('online_store_shop_slug') || getVal('online_store_slug') || 'shop101').toLowerCase();
    const adminPin = getVal('online_store_cloud_pin') || getVal('cloud_pin') || '';
    const shopName = getVal('company_name') || getVal('company_name_ar') || 'Red Shark Store';
    const phone = getVal('company_phone') || '';
    const address = getVal('company_address') || '';
    const exRate = parseFloat(getVal('exchange_rate') || 89500);

    // Collect branches & cashboxes
    const warehouses = db.warehouses || [
      { id: 1, code: 'WH-01', name: 'المستودع الرئيسي (السيرفر)' }
    ];
    const posCashboxes = warehouses.map(w => ({
      branch_id: w.code || `WH-${w.id}`,
      name: w.name || w.name_ar || `Branch ${w.id}`,
      current_balance: 0
    }));

    const bannerObj = {
      admin_password: adminPin,
      delivery_fee: parseFloat(getVal('online_store_delivery_fee', 2.00)) || 2.00,
      phone: phone,
      address: address,
      pos_cashboxes: posCashboxes
    };

    const tenant = {
      id: 'tenant-local-01',
      slug: slugReq || configuredSlug,
      shop_name: shopName,
      is_active: true,
      link_pos_stock: true,
      currency: getVal('currency_1', 'USD'),
      currency_lbp_rate: exRate,
      banner_url: JSON.stringify(bannerObj),
      created_at: new Date().toISOString()
    };

    res.json([tenant]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. GET /rest/v1/shops (Alternate alias for tenants)
app.get('/rest/v1/shops', (req, res) => {
  try {
    const db = readDb();
    const settings = db.settings || [];
    const getVal = (k, def) => {
      const found = settings.find(s => s.key === k);
      return found ? found.value : def;
    };
    const slugReq = (req.query.slug || '').replace(/^eq\./, '').trim().toLowerCase();
    const configuredSlug = (getVal('online_store_shop_slug') || getVal('online_store_slug') || 'shop101').toLowerCase();
    res.json([{
      id: 'tenant-local-01',
      name: getVal('company_name') || 'Red Shark Store',
      slug: slugReq || configuredSlug,
      is_active: true
    }]);
  } catch (e) {
    res.json([]);
  }
});

// 3. GET /rest/v1/categories (Categories for Storefront)
app.get('/rest/v1/categories', (req, res) => {
  try {
    let categories = [];
    const catTbl = path.join(TABLES_DIR, 'categories.json');
    if (fs.existsSync(catTbl)) {
      try { categories = JSON.parse(fs.readFileSync(catTbl, 'utf8')); } catch (e) { }
    }
    if (!Array.isArray(categories) || categories.length === 0) {
      const db = readDb();
      categories = db.categories || [];
    }

    const mapped = (categories || []).filter(c => c.is_active !== false && !c.deleted).map((c, idx) => ({
      id: c.id || (idx + 1),
      shop_id: 'tenant-local-01',
      name: c.name || c.name_en || c.name_ar || 'Category',
      name_ar: c.name_ar || c.name || '',
      name_en: c.name_en || c.name || '',
      display_order: c.display_order !== undefined ? c.display_order : idx,
      is_active: true
    }));
    res.json(mapped);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 4. GET /rest/v1/products (Items & Catalog for Storefront & Manager Scanner)
app.get('/rest/v1/products', (req, res) => {
  try {
    let items = [];
    const itemsTbl = path.join(TABLES_DIR, 'items.json');
    if (fs.existsSync(itemsTbl)) {
      try { items = JSON.parse(fs.readFileSync(itemsTbl, 'utf8')); } catch (e) { }
    }
    if (!Array.isArray(items) || items.length === 0) {
      const db = readDb();
      items = db.items || [];
    }

    const sinceParam = req.query.updated_at ? req.query.updated_at.replace(/^gt\./, '') : null;
    const sinceTime = sinceParam ? new Date(sinceParam).getTime() : 0;

    const mapped = (items || []).filter(it => {
      if (it.is_active === false || it.deleted) return false;
      if (sinceTime > 0) {
        const u = it.updated_at ? new Date(it.updated_at).getTime() : 0;
        if (u <= sinceTime) return false;
      }
      return true;
    }).map(it => {
      const price = parseFloat(it.online_price || it.selling_price || it.price || 0);
      const cost = parseFloat(it.cost_price || 0);
      const stock = (it.stock_qty !== undefined && it.stock_qty !== null) ? parseFloat(it.stock_qty) : parseFloat(it.stock || 0);
      return {
        id: it.id,
        pos_product_id: it.id,
        shop_id: 'tenant-local-01',
        name: it.name || it.name_en || it.name_ar || 'Product',
        name_ar: it.name_ar || it.name || '',
        name_en: it.name_en || it.name || '',
        barcode: it.barcode || it.item_code || it.code || '',
        price: price,
        selling_price: price,
        cost_price: cost,
        stock_quantity: Math.max(0, stock),
        stock: Math.max(0, stock),
        category_id: it.category_id || null,
        image_url: it.image_url || it.image || '',
        is_published: (typeof it.show_online !== 'undefined') ? Boolean(it.show_online) : true,
        updated_at: it.updated_at || new Date().toISOString()
      };
    });

    res.json(mapped);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 5. GET /rest/v1/orders (Fetch Online Orders)
app.get('/rest/v1/orders', (req, res) => {
  try {
    const orders = getOnlineOrders();
    const idFilter = req.query.id ? req.query.id.replace(/^eq\./, '') : null;
    if (idFilter) {
      const matched = orders.filter(o => String(o.id) === String(idFilter) || String(o.order_number) === String(idFilter));
      return res.json(matched);
    }
    // Return recent orders sorted descending
    const sorted = [...orders].sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0)).slice(0, 100);
    res.json(sorted);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 6. POST /rest/v1/orders (Customer Submits New Online Order)
app.post('/rest/v1/orders', (req, res) => {
  try {
    const body = req.body;
    const rawOrder = Array.isArray(body) ? body[0] : body;
    if (!rawOrder) return res.status(400).json({ error: 'No order payload provided' });

    const orders = getOnlineOrders();
    const orderNum = rawOrder.order_number || ('RS-' + Math.floor(100000 + Math.random() * 900000));
    const nowIso = new Date().toISOString();

    const newOrder = {
      ...rawOrder,
      id: rawOrder.id || `ord-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      order_number: orderNum,
      order_status: rawOrder.order_status || 'received',
      payment_status: rawOrder.payment_status || 'pending',
      created_at: rawOrder.created_at || nowIso,
      updated_at: nowIso,
      pos_synced: false
    };

    orders.unshift(newOrder);
    saveOnlineOrders(orders);

    // Broadcast SSE alert to POS so chime rings immediately
    broadcastSyncEvent('new_online_order', { order: newOrder });

    // Auto-Print Receipt if enabled in settings
    try {
      const db = readDb();
      const settings = db.settings || [];
      const autoPrint = settings.some(s => s.key === 'online_store_autoprint' && (s.value === true || s.value === 'true'));
      if (autoPrint) {
        let itemsHtml = '';
        const orderItems = Array.isArray(newOrder.items) ? newOrder.items : (Array.isArray(newOrder.order_items) ? newOrder.order_items : []);
        orderItems.forEach(it => {
          itemsHtml += `
            <tr style="border-bottom:1px dashed #ccc">
              <td style="padding:4px 0">${it.quantity || it.qty || 1}x ${it.product_name || it.name || 'Item'}</td>
              <td style="padding:4px 0;text-align:right">$${parseFloat(it.total_price || it.price || 0).toFixed(2)}</td>
            </tr>
          `;
        });

        const printHtml = `
          <div style="font-family:sans-serif;width:80mm;padding:8px;font-size:13px;direction:rtl">
            <h2 style="text-align:center;margin:0 0 6px">🛒 طلب أونلاين جديد</h2>
            <div style="text-align:center;font-weight:bold;font-size:16px;margin-bottom:8px">#${newOrder.order_number}</div>
            <div style="border-top:1px dashed #000;border-bottom:1px dashed #000;padding:6px 0;margin-bottom:8px">
              <div><strong>الزبون:</strong> ${newOrder.customer_name || 'زبون'}</div>
              <div><strong>الهاتف:</strong> ${newOrder.customer_phone || '-'}</div>
              <div><strong>العنوان:</strong> ${newOrder.delivery_address || 'توصيل'}</div>
              ${newOrder.notes ? `<div><strong>ملاحظات:</strong> ${newOrder.notes}</div>` : ''}
              <div><strong>الوقت:</strong> ${new Date().toLocaleTimeString()}</div>
            </div>
            <table style="width:100%;border-collapse:collapse;margin-bottom:8px">
              ${itemsHtml}
            </table>
            <div style="border-top:2px solid #000;padding-top:6px;display:flex;justify-content:space-between;font-weight:bold;font-size:15px">
              <span>المجموع الإجمالي:</span>
              <span>$${parseFloat(newOrder.total || 0).toFixed(2)}</span>
            </div>
          </div>
        `;

        const fastPrinterExe = path.join(__dirname, 'bin', 'FastPrinter.exe');
        if (fs.existsSync(fastPrinterExe) && os.platform() === 'win32') {
          const tempHtmlPath = path.join(os.tmpdir(), `print_order_${Date.now()}.html`);
          fs.writeFileSync(tempHtmlPath, printHtml, 'utf8');
          exec(`"${fastPrinterExe}" "${tempHtmlPath}"`, () => {
            try { fs.unlinkSync(tempHtmlPath); } catch (e) { }
          });
        }
      }
    } catch (printErr) {
      console.warn('[Storefront] Order auto-print warning:', printErr.message);
    }

    res.status(201).json([newOrder]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 7. PATCH /rest/v1/orders (Cashier or Manager Updates Order Status)
app.patch('/rest/v1/orders', (req, res) => {
  try {
    const idFilter = req.query.id ? req.query.id.replace(/^eq\./, '') : null;
    const body = req.body || {};
    const orders = getOnlineOrders();

    const idx = orders.findIndex(o => (idFilter && String(o.id) === String(idFilter)) || (body.id && String(o.id) === String(body.id)));
    if (idx >= 0) {
      orders[idx] = { ...orders[idx], ...body, updated_at: new Date().toISOString() };
      saveOnlineOrders(orders);
      broadcastSyncEvent('order_status_updated', { order: orders[idx] });
      return res.json([orders[idx]]);
    }

    res.status(404).json({ error: 'Order not found' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 8. GET /rest/v1/order_items (Order Items Query)
app.get('/rest/v1/order_items', (req, res) => {
  try {
    const orderId = req.query.order_id ? req.query.order_id.replace(/^eq\./, '') : null;
    const orders = getOnlineOrders();
    const matched = orderId ? orders.find(o => String(o.id) === String(orderId)) : null;
    if (matched && Array.isArray(matched.items)) {
      return res.json(matched.items);
    }
    res.json([]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 9. GET /api/storefront/catalog (Consolidated 1-Call Catalog for Storefront)
app.get('/api/storefront/catalog', (req, res) => {
  try {
    const db = readDb();
    const settings = db.settings || [];
    const getVal = (k, def) => {
      const found = settings.find(s => s.key === k);
      return found ? found.value : def;
    };

    let categories = [];
    const catTbl = path.join(TABLES_DIR, 'categories.json');
    if (fs.existsSync(catTbl)) {
      try { categories = JSON.parse(fs.readFileSync(catTbl, 'utf8')); } catch (e) { }
    }
    if (!Array.isArray(categories) || !categories.length) categories = db.categories || [];

    let items = [];
    const itemsTbl = path.join(TABLES_DIR, 'items.json');
    if (fs.existsSync(itemsTbl)) {
      try { items = JSON.parse(fs.readFileSync(itemsTbl, 'utf8')); } catch (e) { }
    }
    if (!Array.isArray(items) || !items.length) items = db.items || [];

    const exRate = parseFloat(getVal('exchange_rate') || 89500);

    res.json({
      success: true,
      shop: {
        name: getVal('company_name') || 'Red Shark Store',
        phone: getVal('company_phone') || '',
        address: getVal('company_address') || '',
        currency: getVal('currency_1', 'USD'),
        currency_rate: exRate,
        delivery_fee: parseFloat(getVal('online_store_delivery_fee', 2.00)) || 2.00
      },
      categories: (categories || []).filter(c => c.is_active !== false && !c.deleted),
      products: (items || []).filter(it => it.is_active !== false && !it.deleted).map(it => ({
        id: it.id,
        name: it.name || it.name_en || it.name_ar || 'Product',
        name_ar: it.name_ar || '',
        name_en: it.name_en || '',
        barcode: it.barcode || it.item_code || '',
        price: parseFloat(it.online_price || it.selling_price || it.price || 0),
        cost_price: parseFloat(it.cost_price || 0),
        stock: (it.stock_qty !== undefined && it.stock_qty !== null) ? parseFloat(it.stock_qty) : parseFloat(it.stock || 0),
        category_id: it.category_id || null,
        image_url: it.image_url || it.image || ''
      }))
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10. GET /api/manager/dashboard (Live Branch Reports & Drawer for Mobile Manager App)
app.get('/api/manager/dashboard', (req, res) => {
  try {
    const db = readDb();
    const branchFilter = (req.query.branch || 'all').toLowerCase();
    const dateFilter = req.query.date || 'today';

    let transactions = { sales: [], cashboxSessions: [] };
    if (fs.existsSync(TRANSACTIONS_FILE)) {
      try { transactions = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8')); } catch (e) { }
    }

    const allSales = [...(db.sales || []), ...(transactions.sales || [])];
    const now = new Date();

    const filtered = allSales.filter(s => {
      // Branch filter
      if (branchFilter !== 'all') {
        const b = String(s.branch_id || s.syncBranchId || 'main').trim().toLowerCase();
        if (b !== branchFilter) return false;
      }
      // Date filter
      if (!s.created_at) return true;
      const d = new Date(s.created_at);
      if (dateFilter === 'today') return d.toDateString() === now.toDateString();
      if (dateFilter === 'yesterday') {
        const yest = new Date(now);
        yest.setDate(yest.getDate() - 1);
        return d.toDateString() === yest.toDateString();
      }
      if (dateFilter === 'week') return (now - d) <= (7 * 24 * 60 * 60 * 1000);
      if (dateFilter === 'month') return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      return true;
    });

    let totalSales = 0;
    let totalCost = 0;
    const productCounts = {};

    filtered.forEach(s => {
      const total = parseFloat(s.grand_total || s.total || 0);
      totalSales += total;
      let items = [];
      try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch (e) { }
      items.forEach(it => {
        const cost = parseFloat(it.cost_price || 0) * (parseFloat(it.qty) || 1);
        totalCost += cost;
        const name = it.name_ar || it.name_en || it.name || 'Product';
        if (!productCounts[name]) productCounts[name] = { qty: 0, revenue: 0 };
        productCounts[name].qty += (parseFloat(it.qty) || 1);
        productCounts[name].revenue += parseFloat(it.total || 0);
      });
    });

    const topItems = Object.keys(productCounts).map(name => ({
      name,
      qty: productCounts[name].qty,
      revenue: productCounts[name].revenue
    })).sort((a, b) => b.qty - a.qty).slice(0, 10);

    const netProfit = totalSales - totalCost;
    const margin = totalSales > 0 ? ((netProfit / totalSales) * 100).toFixed(1) : '0';

    res.json({
      success: true,
      branch: branchFilter,
      salesCount: filtered.length,
      totalSales: totalSales,
      totalCost: totalCost,
      netProfit: netProfit,
      margin: margin,
      topItems: topItems,
      branches: (db.warehouses || []).map(w => ({ id: w.code || `WH-${w.id}`, name: w.name || w.code }))
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/status ───────────────────────────────────────────
// Info endpoint - actual printing is done via browser window.print()
app.get('/api/status', (req, res) => {
  res.json({
    status: 'running',
    platform: os.platform(),
    version: '1.0.0',
    port: PORT
  });
});
// ── GET /api/download-sample ─────────────────────────────────────
app.get('/api/download-sample', (req, res) => {
  try {
    const headers = [
      {
        'Item Code': 'ITM-00001',
        'Barcode': '6901234567890',
        'Name English': 'Single Pen',
        'Name Arabic': 'قلم فردي',
        'Category Name': 'Stationery',
        'Brand': 'Pilot',
        'Cost Price': 0.50,
        'Profit %': 100.0,
        'Selling Price': 1.00,
        'Stock Qty': 100,
        'Min Qty (Reorder)': 10,
        'Selling Unit (piece/box)': 'piece',
        'Pieces per Box': 1,
        'Linked Item Code': ''
      },
      {
        'Item Code': 'ITM-00002',
        'Barcode': '6901234567891',
        'Name English': 'Box of 12 Pens',
        'Name Arabic': 'علبة 12 قلم',
        'Category Name': 'Stationery',
        'Brand': 'Pilot',
        'Cost Price': 5.00,
        'Profit %': 100.0,
        'Selling Price': 10.00,
        'Stock Qty': 10,
        'Min Qty (Reorder)': 2,
        'Selling Unit (piece/box)': 'box',
        'Pieces per Box': 12,
        'Linked Item Code': 'ITM-00001'
      }
    ];

    const ws = XLSX.utils.json_to_sheet(headers);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Items Template");

    const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="items_import_template.xlsx"');
    res.status(200).send(buf);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Cloud Software Update (OTA) API ─────────────────────────────
app.get('/api/system/version', (req, res) => {
  try {
    const vPath = path.join(__dirname, 'version.json');
    if (fs.existsSync(vPath)) {
      return res.json(JSON.parse(fs.readFileSync(vPath, 'utf8')));
    }
    res.json({ name: 'Red Shark POS', version: '1.2.31', build: 47 });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/system/check-cloud-update', async (req, res) => {
  try {
    const currentVerFile = path.join(__dirname, 'version.json');
    let localVer = { version: '1.2.31', build: 47 };
    if (fs.existsSync(currentVerFile)) {
      try { localVer = JSON.parse(fs.readFileSync(currentVerFile, 'utf8')); } catch (e) { }
    }

    const baseManifestUrl = req.body?.manifestUrl || 'https://shop.redshark-ai.com/version.json';
    const parsedManifest = new URL(baseManifestUrl);
    parsedManifest.searchParams.set('_t', Date.now().toString());
    const finalManifestUrl = parsedManifest.toString();

    const https = require('https');
    const http = require('http');
    const client = finalManifestUrl.startsWith('https') ? https : http;

    const reqOptions = {
      timeout: 10000,
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'User-Agent': 'RedSharkPOS-OTA-Checker'
      }
    };

    client.get(finalManifestUrl, reqOptions, (manifestRes) => {
      if (manifestRes.statusCode < 200 || manifestRes.statusCode >= 300) {
        return res.json({
          hasUpdate: false,
          currentVersion: localVer.version,
          currentBuild: localVer.build,
          message: `Cloud server returned status ${manifestRes.statusCode}`
        });
      }
      let rawData = '';
      manifestRes.on('data', chunk => rawData += chunk);
      manifestRes.on('end', () => {
        try {
          const cloudVer = JSON.parse(rawData);
          const hasUpdate = (cloudVer.build > (localVer.build || 0)) ||
            (cloudVer.version && cloudVer.version !== localVer.version);
          return res.json({
            success: true,
            hasUpdate: !!hasUpdate,
            currentVersion: localVer.version,
            currentBuild: localVer.build,
            latestVersion: cloudVer.version || localVer.version,
            latestBuild: cloudVer.build || localVer.build,
            releaseDate: cloudVer.releaseDate || 'Latest',
            releaseNotes: cloudVer.releaseNotes || cloudVer.description || 'New improvements & performance fixes',
            downloadUrl: cloudVer.downloadUrl || ''
          });
        } catch (parseErr) {
          return res.json({ success: false, hasUpdate: false, currentVersion: localVer.version, message: 'Invalid manifest format' });
        }
      });
    }).on('error', (err) => {
      res.json({
        success: false,
        hasUpdate: false,
        currentVersion: localVer.version,
        currentBuild: localVer.build,
        message: 'Could not connect to update cloud server'
      });
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── SPA fallback for Local Desktop POS ─────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'index.html'));
});

// ── Start HTTP Server ───────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ Red Shark POS Server running at: http://localhost:${PORT}`);
  console.log(`   Open the app at:           http://localhost:${PORT}/login.html`);
  console.log(`   Printers API:              http://localhost:${PORT}/api/printers\n`);
  try { ensurePrintWorker(); } catch (e) { }
});

// ── HTTPS Server for Mobile Camera & Secure Context ────────────
async function startHttpsServer() {
  const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
  try {
    const selfsigned = require('selfsigned');
    const https = require('https');
    const certCachePath = path.join(__dirname, 'data', 'server_cert.json');
    let certData = null;
    if (fs.existsSync(certCachePath)) {
      try {
        certData = JSON.parse(fs.readFileSync(certCachePath, 'utf8'));
      } catch (e) { }
    }
    if (!certData || !certData.cert || !certData.private || typeof certData.cert !== 'string') {
      const nets = os.networkInterfaces();
      const altNames = [
        { type: 2, value: 'localhost' },
        { type: 7, ip: '127.0.0.1' }
      ];
      for (const name of Object.keys(nets)) {
        for (const net of (nets[name] || [])) {
          if (net.family === 'IPv4' && !net.internal) {
            altNames.push({ type: 7, ip: net.address });
          }
        }
      }
      const primaryIp = altNames.find(a => a.type === 7 && a.ip !== '127.0.0.1')?.ip || '127.0.0.1';
      const attrs = [{ name: 'commonName', value: primaryIp }];
      const extensions = [{
        name: 'subjectAltName',
        altNames
      }];
      const pems = await selfsigned.generate(attrs, { days: 3650, keySize: 2048, extensions });
      certData = { cert: pems.cert, private: pems.private };
      try {
        if (!fs.existsSync(path.join(__dirname, 'data'))) {
          fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
        }
        fs.writeFileSync(certCachePath, JSON.stringify(certData, null, 2), 'utf8');
      } catch (e) { }
    }
    const httpsServer = https.createServer({ cert: certData.cert, key: certData.private }, app);
    httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
      console.log(`🔒 Red Shark HTTPS Secure Server running at: https://0.0.0.0:${HTTPS_PORT}`);
    });
  } catch (err) {
    console.warn('HTTPS server setup failed:', err.message);
  }
}
startHttpsServer();

// ── Background Cloud Sync Engine (Auto-sync sales to Supabase) ────────
const CLOUD_SYNC_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
const CLOUD_SYNC_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";
let _cachedShopUuid = null;
let _cachedSlug = null;

async function resolveCloudShopId(slug) {
  if (!slug) slug = 'shop101';
  if (slug === 'shop101') return 'a1000000-0000-0000-0000-000000000101';
  if (_cachedSlug === slug && _cachedShopUuid) return _cachedShopUuid;
  try {
    const r = await fetch(`${CLOUD_SYNC_URL}/rest/v1/tenants?slug=eq.${encodeURIComponent(slug)}&select=id`, {
      headers: { "apikey": CLOUD_SYNC_KEY, "Authorization": "Bearer " + CLOUD_SYNC_KEY }
    });
    if (r.ok) {
      const rows = await r.json();
      if (rows && rows[0]) {
        _cachedSlug = slug;
        _cachedShopUuid = rows[0].id;
        return _cachedShopUuid;
      }
    }
  } catch (e) { }
  return 'a1000000-0000-0000-0000-000000000101';
}

async function autoSyncSalesToCloud() {
  try {
    const db = readDb();
    const settings = db['settings'] || [];
    const providerSetting = settings.find(s => s.key === 'online_store_provider');
    if (providerSetting && providerSetting.value !== 'cloud') {
      return; // Direct Server Mode (Zero-Cost / No Supabase): skip cloud push
    }
    const sales = db['sales'] || [];
    if (!sales.length) return;

    const slugSetting = settings.find(s => s.key === 'online_store_shop_slug');
    const roleSetting = settings.find(s => s.key === 'sync_node_role');
    if (_isSyncingItems && roleSetting && roleSetting.value && String(roleSetting.value).trim().toLowerCase() !== 'server') { _isSyncingItems = false; return; }
    const slug = slugSetting ? slugSetting.value : 'shop101';
    const activeShopId = await resolveCloudShopId(slug);

    // Fetch existing order refs from Supabase
    const res = await fetch(`${CLOUD_SYNC_URL}/rest/v1/orders?shop_id=eq.${activeShopId}&select=order_number`, {
      headers: { "apikey": CLOUD_SYNC_KEY, "Authorization": "Bearer " + CLOUD_SYNC_KEY }
    });
    if (!res.ok) return;
    const existing = await res.json();
    const existingRefs = new Set((existing || []).map(o => o.order_number));

    const missingSales = sales.filter(s => s.ref && !existingRefs.has(s.ref));
    if (!missingSales.length) return;

    console.log(`[CloudSync] Auto-syncing ${missingSales.length} new POS sales to Supabase...`);
    const formatted = missingSales.slice(-25).map(s => {
      let items = [];
      try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch (e) { }
      let cost = 0;
      items.forEach(it => { cost += (parseFloat(it.cost_price || 0) * (parseFloat(it.qty) || 1)); });
      const total = parseFloat(s.grand_total) || 0;

      return {
        shop_id: activeShopId,
        order_number: s.ref,
        customer_name: s.customer_name || 'عميل عابر',
        customer_phone: s.customer_phone || '',
        delivery_address: s.branch_id || 'main',
        subtotal: parseFloat(s.subtotal || s.grand_total) || 0,
        total: total,
        currency_code: 'USD',
        payment_method: s.payment_method || 'cash',
        payment_status: 'paid',
        order_status: 'completed',
        items: items.map(it => ({
          product_name: it.name_ar || it.name_en || 'Product',
          quantity: parseFloat(it.qty) || 1,
          unit_price: parseFloat(it.price) || 0,
          total_price: parseFloat(it.total) || 0,
          cost_price: parseFloat(it.cost_price) || 0
        })),
        pos_synced: true,
        pos_invoice_ref: s.ref,
        notes: JSON.stringify({
          source: 'pos',
          branch_id: s.branch_id || 'main',
          terminal_id: s.terminal_id || 'POS-1',
          cashier: s.cashier || s.salesperson_name || 'Administrator',
          cost: cost,
          profit: total - cost
        }),
        created_at: s.created_at,
        updated_at: s.updated_at || s.created_at
      };
    });

    await fetch(`${CLOUD_SYNC_URL}/rest/v1/orders`, {
      method: 'POST',
      headers: {
        "apikey": CLOUD_SYNC_KEY,
        "Authorization": "Bearer " + CLOUD_SYNC_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(formatted)
    });
    console.log(`[CloudSync] Successfully pushed ${formatted.length} sales to Cloud.`);
    try {
      const dbUpdate = readDb();
      if (!dbUpdate.settings) dbUpdate.settings = [];
      const now = new Date().toISOString();
      const sIdx = dbUpdate.settings.findIndex(s => s.key === 'last_cloud_sync_time');
      if (sIdx !== -1) dbUpdate.settings[sIdx].value = now;
      else dbUpdate.settings.push({ key: 'last_cloud_sync_time', value: now });
      writeDb(dbUpdate);
    } catch (err) { }
  } catch (e) { }
}

setInterval(autoSyncSalesToCloud, 6000);
setTimeout(autoSyncSalesToCloud, 1500);

// ── Background Cloud Items Sync Engine (Watches items.json & pushes to Supabase) ──
let _lastItemsSyncMtime = Date.now();
let _isSyncingItems = false;

async function autoSyncItemsToCloud() {
  if (_isSyncingItems) return;
  try {
    const db = readDb();
    const settings = db['settings'] || [];
    const providerSetting = settings.find(s => s.key === 'online_store_provider');
    if (providerSetting && providerSetting.value !== 'cloud') {
      return; // Direct Server Mode (Zero-Cost / No Supabase): skip cloud push
    }
    const itemsFile = path.join(TABLES_DIR, 'items.json');
    if (!fs.existsSync(itemsFile)) return;
    const stat = fs.statSync(itemsFile);
    if (stat.mtimeMs <= _lastItemsSyncMtime) return;

    _isSyncingItems = true;
    const checkTime = _lastItemsSyncMtime;
    _lastItemsSyncMtime = stat.mtimeMs;

    const items = JSON.parse(fs.readFileSync(itemsFile, 'utf8'));
    if (!Array.isArray(items) || !items.length) {
      _isSyncingItems = false;
      return;
    }

    const slugSetting = settings.find(s => s.key === 'online_store_shop_slug');
    const roleSetting = settings.find(s => s.key === 'sync_node_role');
    if (_isSyncingItems && roleSetting && roleSetting.value && String(roleSetting.value).trim().toLowerCase() !== 'server') { _isSyncingItems = false; return; }
    const slug = slugSetting && slugSetting.value ? slugSetting.value : 'bobmarket';
    const activeShopId = await resolveCloudShopId(slug);

    // Filter items updated since the last check
    const itemsToPush = items.filter(i => {
      if (!i.updated_at) return false;
      const d = new Date(i.updated_at).getTime();
      return d >= (checkTime - 10000); // modified within recent window
    });

    if (!itemsToPush.length) {
      _isSyncingItems = false;
      return;
    }

    console.log(`[CloudSync] Auto-syncing ${itemsToPush.length} modified items to Supabase...`);

    const payload = itemsToPush.slice(0, 50).map(it => ({
      shop_id: activeShopId,
      pos_product_id: String(it.id),
      name: it.name_en || it.name_ar || 'Product',
      name_ar: it.name_ar || '',
      name_en: it.name_en || '',
      description: it.item_code ? ('CODE:' + it.item_code) : (it.description || ''),
      barcode: it.barcode || null,
      price: parseFloat(it.online_price) || parseFloat(it.selling_price) || parseFloat(it.price) || 0,
      cost_price: parseFloat(it.cost_price) || 0,
      stock_quantity: Math.max(0, parseInt(it.stock_qty) || 0),
      track_inventory: true,
      is_published: (typeof it.show_online !== 'undefined') ? Boolean(it.show_online) : true,
      image_url: it.image_url || it.image || null,
      updated_at: it.updated_at || new Date().toISOString()
    }));

    await fetch(`${CLOUD_SYNC_URL}/rest/v1/products?on_conflict=shop_id,pos_product_id`, {
      method: 'POST',
      headers: {
        "apikey": CLOUD_SYNC_KEY,
        "Authorization": "Bearer " + CLOUD_SYNC_KEY,
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates"
      },
      body: JSON.stringify(payload)
    });

    console.log(`[CloudSync] Successfully pushed ${payload.length} updated item(s) to Supabase.`);
  } catch (err) {
    console.warn('[CloudSync] autoSyncItemsToCloud error:', err.message);
  } finally {
    _isSyncingItems = false;
  }
}

setInterval(autoSyncItemsToCloud, 5000);
setTimeout(autoSyncItemsToCloud, 2000);


