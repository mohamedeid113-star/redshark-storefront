/**
 * NexPOS — Local Server
 * Serves static files + exposes /api/printers to enumerate Windows printers
 */

const express = require('express');
const { execSync, spawn, exec } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');
const XLSX = require('xlsx');

const app = express();
const PORT = process.env.PORT || 3000;

process.on('uncaughtException', (err) => {
  console.error('[Server UncaughtException]:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[Server UnhandledRejection]:', reason);
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// ── Disable browser caching for local scripts & assets ─────────
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// ── Serve static files ─────────────────────────────────────────
app.use(express.static(process.cwd(), { etag: false, maxAge: 0 }));

// ── Mount Storefront for easy local testing ────────────────────
const storefrontPath = path.resolve(__dirname, '../RedSharkStorefront');
if (fs.existsSync(storefrontPath)) {
  app.use('/storefront', express.static(storefrontPath, { etag: false, maxAge: 0 }));
}

// ── CORS for development ───────────────────────────────────────
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// ── GET /api/hardware-id ───────────────────────────────────────
app.get('/api/hardware-id', (req, res) => {
  try {
    const validIds = getAllHardwareMachineIds();
    // 1. If this server has an active license, return that machine_id
    const db = readDb();
    const settings = db['settings'] || [];
    const rawLic = settings.find(s => s.key === 'license_active_data')?.value;
    if (rawLic) {
      try {
        const lic = typeof rawLic === 'string' ? JSON.parse(rawLic) : rawLic;
        if (lic && lic.machine_id && validIds.some(id => id.toUpperCase() === String(lic.machine_id).trim().toUpperCase())) {
          return res.json({ success: true, machine_id: lic.machine_id });
        }
      } catch {}
    }
    // 2. Return the primary persistent hardware ID
    const machineId = validIds.find(id => !id.startsWith('RS-' + (os.hostname() || 'SERVER').toUpperCase())) || validIds[0];
    res.json({ success: true, machine_id: machineId });
  } catch(err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/network-info ───────────────────────────────────────
// Returns local LAN IP addresses for mobile app QR code & connections
app.get('/api/network-info', (req, res) => {
  try {
    const nets = os.networkInterfaces();
    const addresses = [];
    for (const name of Object.keys(nets)) {
      for (const net of (nets[name] || [])) {
        if (net.family === 'IPv4' && !net.internal) {
          addresses.push({ iface: name, address: net.address });
        }
      }
    }
    const primaryIp = addresses.length ? addresses[0].address : 'localhost';
    res.json({
      success: true,
      ip: primaryIp,
      port: PORT,
      httpsPort: 3443,
      addresses,
      mobileUrl: `http://${primaryIp}:${PORT}/mobile.html`,
      mobileHttpsUrl: `https://${primaryIp}:3443/mobile.html`,
      waiterUrl: `http://${primaryIp}:${PORT}/mobile_waiter.html`
    });
  } catch(err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/printers ──────────────────────────────────────────
// Returns list of installed printers on this Windows machine
app.get('/api/printers', (req, res) => {
  try {
    let printers = [];
    let defaultPrinterName = '';

    if (os.platform() === 'win32') {
      // 1. Primary: Query Windows Registry (Ultra fast <20ms, zero dependency, works on Win 7/10/11 even if PowerShell/WMI is disabled)
      try {
        try {
          const defRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows" /v Device', { encoding: 'utf8', timeout: 3000 });
          const m = defRaw.match(/Device\s+REG_SZ\s+([^,\r\n]+)/i);
          if (m && m[1]) defaultPrinterName = m[1].trim();
        } catch {}

        const devRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices"', { encoding: 'utf8', timeout: 3000 });
        const lines = devRaw.split(/\r?\n/);
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith('HKEY_')) continue;
          const m = trimmed.match(/^([^\t]+?)\s+REG_SZ\s+/i);
          if (m && m[1]) {
            const name = m[1].trim();
            if (name && !printers.some(p => p.name.toLowerCase() === name.toLowerCase())) {
              printers.push({ name, isDefault: name.toLowerCase() === defaultPrinterName.toLowerCase() });
            }
          }
        }

        // Also check HKLM printers if HKCU was empty
        if (printers.length === 0) {
          try {
            const hklmRaw = execSync('reg query "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print\\Printers"', { encoding: 'utf8', timeout: 3000 });
            const hklmLines = hklmRaw.split(/\r?\n/);
            for (const line of hklmLines) {
              const trimmed = line.trim();
              if (trimmed.startsWith('HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Print\\Printers\\')) {
                const name = trimmed.split('\\').pop().trim();
                if (name && !printers.some(p => p.name.toLowerCase() === name.toLowerCase())) {
                  printers.push({ name, isDefault: name.toLowerCase() === defaultPrinterName.toLowerCase() });
                }
              }
            }
          } catch {}
        }
      } catch (regErr) {
        console.warn('Registry printer detection failed:', regErr.message);
      }

      // 2. Fallback: PowerShell CIM / WMI
      if (printers.length === 0) {
        try {
          const rawJson = execSync(
            'powershell -NoProfile -ExecutionPolicy Bypass -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Get-CimInstance Win32_Printer | Select-Object Name, Default | ConvertTo-Json -Compress"',
            { encoding: 'utf8', timeout: 10000 }
          );
          const trimmed = rawJson.trim();
          if (trimmed) {
            const list = JSON.parse(trimmed);
            const rawList = Array.isArray(list) ? list : (list ? [list] : []);
            printers = rawList.map(p => ({
              name: p.Name,
              isDefault: !!p.Default
            })).filter(p => p.name);
          }
        } catch (psErr) {
          console.warn('PowerShell CIM printer lookup failed:', psErr.message);
        }
      }

      // 3. Fallback: PowerShell .NET System.Drawing
      if (printers.length === 0) {
        try {
          const rawDotNet = execSync(
            'powershell -NoProfile -ExecutionPolicy Bypass -Command "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Add-Type -AssemblyName System.Drawing; [System.Drawing.Printing.PrinterSettings]::InstalledPrinters"',
            { encoding: 'utf8', timeout: 8000 }
          );
          const lines = rawDotNet.trim().split(/\r?\n/);
          printers = lines.map(line => line.trim()).filter(Boolean).map(name => ({
            name,
            isDefault: name.toLowerCase() === defaultPrinterName.toLowerCase()
          }));
        } catch (dnErr) {
          console.warn('PowerShell .NET printer lookup failed:', dnErr.message);
        }
      }

      // 4. Fallback: WMIC (Legacy Windows 7 / 8 / XP)
      if (printers.length === 0) {
        try {
          const raw = execSync(
            'wmic printer get Name,Default /format:csv',
            { encoding: 'utf8', timeout: 5000, stdio: ['pipe', 'pipe', 'ignore'] }
          );
          const lines = raw.trim().split(/\r?\n/).slice(2);
          printers = lines
            .map(line => {
              const parts = line.trim().split(',');
              if (parts.length < 3) return null;
              const [, isDefault, name] = parts.map(p => p.trim());
              if (!name) return null;
              return { name: name, isDefault: isDefault === 'TRUE' };
            })
            .filter(Boolean);
        } catch {}
      }

      // Sort: default printer first, then alphabetical
      printers.sort((a, b) => {
        if (a.isDefault) return -1;
        if (b.isDefault) return 1;
        return a.name.localeCompare(b.name);
      });
    } else {
      // Linux/Mac fallback: use lpstat
      try {
        const raw = execSync('lpstat -a 2>/dev/null || lpstat -p 2>/dev/null', { encoding: 'utf8', timeout: 5000 });
        printers = raw.trim().split('\n').map(line => {
          const name = line.split(' ')[0];
          return name ? { name, isDefault: false } : null;
        }).filter(Boolean);
      } catch {
        printers = [];
      }
    }

    res.json({ success: true, printers });
  } catch (err) {
    console.error('Printer enumeration error:', err.message);
    res.json({ success: false, printers: [], error: err.message });
  }
});

// ── Customer Pole Display API (VFD / LED8N Serial Display) ─────────
app.get('/api/customer-display/ports', (req, res) => {
  try {
    if (os.platform() === 'win32') {
      const psCmd = `powershell -NoProfile -Command "[System.IO.Ports.SerialPort]::GetPortNames() -join ','"`;
      const out = execSync(psCmd, { encoding: 'utf8', timeout: 4000 });
      const ports = out.split(',').map(p => p.trim()).filter(Boolean);
      return res.json({ success: true, ports });
    }
    res.json({ success: true, ports: [] });
  } catch (e) {
    res.json({ success: false, ports: [], error: e.message });
  }
});

app.post('/api/customer-display/send', (req, res) => {
  try {
    const { amount, status, port = 'auto', baud = 2400 } = req.body;
    const amtStr = String(amount !== undefined ? amount : '0.00').trim();

    if (os.platform() !== 'win32') {
      return res.json({ success: false, error: 'Customer display only supported on Windows' });
    }

    let statusByte = 0x32; // '2' for Total (turns on Total LED lamp)
    if (status === 'price') statusByte = 0x31;
    if (status === 'change') statusByte = 0x33;
    if (status === 'clear') statusByte = 0x30;

    // Detect target ports
    let targetPorts = [];
    if (!port || port === 'auto' || port === 'all') {
      try {
        const psCmd = `powershell -NoProfile -Command "[System.IO.Ports.SerialPort]::GetPortNames() -join ','"`;
        const detected = execSync(psCmd, { encoding: 'utf8', timeout: 3000 }).trim();
        targetPorts = detected.split(',').map(p => p.trim()).filter(Boolean);
      } catch {}
      if (!targetPorts.length) targetPorts = ['COM1', 'COM2', 'COM3', 'COM4'];
    } else {
      targetPorts = [port];
    }

    const baudRates = [parseInt(baud) || 2400];
    if (port === 'all' || port === 'auto') {
      if (!baudRates.includes(9600)) baudRates.push(9600);
    }

    const ps = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', '-']);
    let stdout = '';
    let stderr = '';
    ps.stdout.on('data', d => stdout += d.toString());
    ps.stderr.on('data', d => stderr += d.toString());

    const psScript = `
      $ports = @(${targetPorts.map(p => `"${p}"`).join(',')});
      $bauds = @(${baudRates.join(',')});
      $amt = "${amtStr}";
      $statusByte = [byte]${statusByte};

      foreach ($p in $ports) {
        foreach ($b in $bauds) {
          try {
            $sp = New-Object System.IO.Ports.SerialPort;
            $sp.PortName = $p;
            $sp.BaudRate = $b;
            $sp.Parity = [System.IO.Ports.Parity]::None;
            $sp.DataBits = 8;
            $sp.StopBits = [System.IO.Ports.StopBits]::One;
            $sp.DtrEnable = $true;
            $sp.RtsEnable = $true;
            $sp.ReadTimeout = 400;
            $sp.WriteTimeout = 600;
            $sp.Open();

            # Send clear, status lamp, and ESC Q A amount in a single contiguous byte packet
            $header = [byte[]](0x0C, 0x1B, 0x73, $statusByte, 0x1B, 0x51, 0x41);
            $body = [System.Text.Encoding]::ASCII.GetBytes($amt);
            $trailer = [byte[]](0x0D);
            $packet = $header + $body + $trailer;

            $sp.Write($packet, 0, $packet.Length);
            $sp.BaseStream.Flush();
            Start-Sleep -Milliseconds 60;
            $sp.Close();
            Write-Host "OPENED_OK:$p"
          } catch {}
        }
      }
    `;

    ps.stdin.write(psScript);
    ps.stdin.end();

    ps.on('close', () => {
      const opened = [];
      stdout.split('\n').forEach(line => {
        if (line.includes('OPENED_OK:')) {
          const p = line.split('OPENED_OK:')[1].trim();
          if (p && !opened.includes(p)) opened.push(p);
        }
      });
      console.log(`[CustomerDisplay] Sent ${amtStr} | Target: ${targetPorts.join(',')} | Opened: ${opened.join(',') || 'None'}`);
      if (stderr) console.warn('[CustomerDisplay Error]:', stderr);
      res.json({
        success: true,
        port: opened.length ? opened.join(', ') : targetPorts[0],
        ports: opened.length ? opened : targetPorts,
        opened: opened,
        amount: amtStr
      });
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/printer/switch-default ──────────────────────────────
// Instantly switches Windows default printer to the specified printer using rundll32 / WScript (~40ms)
app.post('/api/printer/switch-default', (req, res) => {
  try {
    const { printer } = req.body || {};
    if (!printer) return res.json({ success: true, message: 'No printer specified' });
    const clean = printer.trim().replace(/^[\s★*]+|[\s★*]+$/g, '').trim();
    if (!clean) return res.json({ success: true });
    
    if (os.platform() === 'win32') {
      const { exec } = require('child_process');
      try {
        // Fast instant switch via native Windows printui rundll32 (~30ms)
        exec(`rundll32 printui.dll,PrintUIEntry /y /n "${clean.replace(/"/g, '')}"`, (err) => {
          if (err) {
            try {
              const { execSync } = require('child_process');
              execSync(`powershell -NoProfile -Command "(New-Object -ComObject WScript.Network).SetDefaultPrinter('${clean.replace(/'/g, "''")}')"`, { timeout: 3000 });
            } catch (e2) {}
          }
        });
      } catch (err) {}
    }
    res.json({ success: true, printer: clean });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/print-direct ──────────────────────────────────────
// Prints receipt directly to named Windows thermal printer using .NET Spooler
app.post('/api/print-direct', (req, res) => {
  try {
    const { printer, data, html } = req.body;
    let targetPrinter = (printer || '').trim().replace(/^★\s*|\s*★$/g, '').trim();

    if (html) {
      if (targetPrinter && os.platform() === 'win32') {
        try {
          const { exec } = require('child_process');
          exec(`rundll32 printui.dll,PrintUIEntry /y /n "${targetPrinter.replace(/"/g, '')}"`, () => {});
        } catch (e) {}
      }
      ensurePrintWorker();
      const jobId = Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      printJobQueue.push({
        id: jobId,
        html: html,
        printer: targetPrinter,
        created: Date.now()
      });
      return res.json({ success: true, message: `HTML Print job dispatched directly to ${targetPrinter || 'default printer'}` });
    }

    if (!targetPrinter) {
      try {
        const defRaw = execSync('reg query "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows" /v Device', { encoding: 'utf8', timeout: 2000 });
        const m = defRaw.match(/Device\s+REG_SZ\s+([^,\r\n]+)/i);
        if (m && m[1]) targetPrinter = m[1].trim();
      } catch (e) {}
    }
    if (!targetPrinter) targetPrinter = 'XP-80C';

    const uniqueId = Date.now() + '_' + Math.floor(Math.random() * 1000);
    const tempDir = os.tmpdir();
    const tempJsonPath = path.join(tempDir, `receipt_${uniqueId}.json`);

    fs.writeFileSync(tempJsonPath, JSON.stringify(data || {}), 'utf8');

    const scriptPath = path.join(__dirname, 'bin', 'print_receipt.ps1');
    const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -File "${scriptPath}" -PrinterName "${targetPrinter.replace(/"/g, '')}" -JsonFile "${tempJsonPath}"`;

    const { exec } = require('child_process');
    exec(psCmd, (err, stdout, stderr) => {
      try { fs.unlinkSync(tempJsonPath); } catch (e) {}
      if (err) {
        console.error('Direct print error:', err.message || stderr);
        return res.json({ success: false, error: err.message || stderr });
      }
      console.log('Direct print success:', stdout.trim());
      res.json({ success: true, message: `Printed directly to ${targetPrinter}` });
    });
  } catch (err) {
    console.error('Print-direct exception:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── BACKGROUND PRINT WORKER QUEUE ────────────────────────────────
const printJobQueue = [];
let printWorkerLastActive = 0;

function ensurePrintWorker() {
  if (os.platform() !== 'win32') return;
  // If active in the last 4 seconds, worker is alive and polling
  if (Date.now() - printWorkerLastActive < 4000) return;

  const chromePaths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
  ];
  const edgePaths = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ];
  const browserExe = chromePaths.find(p => fs.existsSync(p)) || edgePaths.find(p => fs.existsSync(p));
  if (!browserExe) return;

  const workerProfileDir = path.join(os.homedir(), 'AppData', 'Local', 'RedSharkPOS', 'PrintWorkerProfile');
  if (!fs.existsSync(workerProfileDir)) {
    try { fs.mkdirSync(workerProfileDir, { recursive: true }); } catch (e) {}
  }

  const workerUrl = `http://localhost:${PORT}/print_worker.html`;
  // Start with -WindowStyle Hidden so Windows NEVER shows any window or taskbar icon!
  const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process '${browserExe}' -ArgumentList '--kiosk-printing','--user-data-dir=\\\"${workerProfileDir}\\\"','--window-position=-32000,-32000','--window-size=10,10','--no-first-run','--disable-fre','--no-default-browser-check','--disable-gpu','--disable-extensions','--disable-background-networking','--disable-sync','--disable-default-apps','--disable-component-update','--disable-features=Translate,OptimizationHints,MediaRouter','--renderer-process-limit=1','\\\"${workerUrl}\\\"' -WindowStyle Hidden"`;

  try {
    const { exec } = require('child_process');
    exec(psCmd, (err) => {
      if (err) console.warn('Worker launch warning:', err.message);
    });
    printWorkerLastActive = Date.now();
  } catch (e) {}
}

// ── GET /api/print-worker/next ──────────────────────────────────
app.get('/api/print-worker/next', (req, res) => {
  printWorkerLastActive = Date.now();
  if (printJobQueue.length > 0) {
    const job = printJobQueue.shift();
    return res.json({ job });
  }
  res.json({ job: null });
});

// ── POST /api/print-worker/ack ──────────────────────────────────
app.post('/api/print-worker/ack', (req, res) => {
  printWorkerLastActive = Date.now();
  res.json({ success: true });
});

// ── POST /api/print ─────────────────────────────────────────────
// Prints HTML silently to a specific printer without opening preview dialog
app.post('/api/print', (req, res) => {
  try {
    const { html, printer, pageSize } = req.body;
    if (!html) {
      return res.status(400).json({ success: false, error: 'HTML content is required' });
    }

    const cleanPrinter = printer ? printer.trim().replace(/^[\s★*]+|[\s★*]+$/g, '').trim() : '';

    // 1. Direct hardware printing via native FastPrinter.exe (Win32 Spooler)
    const fastPrinterExe = path.join(__dirname, 'bin', 'FastPrinter.exe');
    if (fs.existsSync(fastPrinterExe) && os.platform() === 'win32') {
      const uniqueId = Date.now() + '_' + Math.floor(Math.random() * 10000);
      const tempHtmlPath = path.join(os.tmpdir(), `print_doc_${uniqueId}.html`);
      fs.writeFileSync(tempHtmlPath, html, 'utf8');

      const targetArg = cleanPrinter ? `"${cleanPrinter.replace(/"/g, '')}"` : '';
      const printCmd = `"${fastPrinterExe}" "${tempHtmlPath}" ${targetArg}`;
      const { exec } = require('child_process');
      exec(printCmd, { timeout: 15000 }, (err, stdout, stderr) => {
        try { fs.unlinkSync(tempHtmlPath); } catch (e) {}
        if (err) {
          console.warn('FastPrinter warning, falling back to background worker:', err.message || stderr);
          return fallbackToPrintWorker();
        }
        console.log(`FastPrinter dispatched directly to (${cleanPrinter || 'Default'}):`, (stdout || '').trim());
        return res.json({ success: true, message: `Printed directly to ${cleanPrinter || 'default printer'}` });
      });
      return;
    }

    function fallbackToPrintWorker() {
      if (cleanPrinter && os.platform() === 'win32') {
        try {
          const { execSync } = require('child_process');
          execSync(`powershell -NoProfile -Command "(New-Object -ComObject WScript.Network).SetDefaultPrinter('${cleanPrinter.replace(/'/g, "''")}')"`, { timeout: 3000 });
        } catch (e) {
          try { const { exec } = require('child_process'); exec(`rundll32 printui.dll,PrintUIEntry /y /n "${cleanPrinter.replace(/"/g, '')}"`, () => {}); } catch(e2) {}
        }
      }

      ensurePrintWorker();

      const jobId = Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      printJobQueue.push({
        id: jobId,
        html: html,
        printer: cleanPrinter,
        created: Date.now()
      });

      res.json({ success: true, message: `Print job dispatched to worker for ${cleanPrinter || 'default printer'}` });
    }

    fallbackToPrintWorker();
  } catch (err) {
    console.error('Print error:', err.message);
    res.json({ success: false, error: err.message });
  }
});

const crypto = require('crypto');

// ── SERVER-SIDE CENTRAL DATABASE CONFIGURATION (AES-256 ENCRYPTED) ─
const DB_FILE = path.join(__dirname, 'data', 'db.dat');
const LEGACY_JSON_FILE = path.join(__dirname, 'data', 'db.json');

// Derive 32-byte AES key from Master Secret
const MASTER_SECRET = '0wner_RedSharkPOS_SuperSecret_Master_Key_2026';
const ENC_KEY = crypto.createHash('sha256').update(MASTER_SECRET).digest();

function encryptText(text) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENC_KEY, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

function decryptText(encryptedText) {
  try {
    const parts = encryptedText.split(':');
    if (parts.length !== 3) return null;
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    const decipher = crypto.createDecipheriv('aes-256-gcm', ENC_KEY, iv);
    decipher.setAuthTag(authTag);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (e) {
    return null;
  }
}

// Initialize database folder and file with automatic migration
function initDatabase() {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  // Auto-migrate from unencrypted db.json if present
  if (!fs.existsSync(DB_FILE) && fs.existsSync(LEGACY_JSON_FILE)) {
    try {
      const raw = fs.readFileSync(LEGACY_JSON_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      fs.writeFileSync(DB_FILE, encryptText(JSON.stringify(parsed, null, 2)), 'utf8');
      console.log('🔒 Migrated database to AES-256 encrypted storage (db.dat).');
      try { fs.unlinkSync(LEGACY_JSON_FILE); } catch {}
      return;
    } catch (err) {
      console.warn('Migration warning:', err.message);
    }
  }

  if (!fs.existsSync(DB_FILE)) {
    const initialDb = {
      settings: [
        { key: 'company_name', value: 'Red Shark POS Store' },
        { key: 'vat_rate', value: 11 },
        { key: 'vat_enabled', value: false },
        { key: 'exchange_rate', value: 89500 },
        { key: 'currency_1', value: 'USD' },
        { key: 'currency_2', value: 'LBP' }
      ]
    };
    fs.writeFileSync(DB_FILE, encryptText(JSON.stringify(initialDb, null, 2)), 'utf8');
  }
}
initDatabase();

function readDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const rawEncrypted = fs.readFileSync(DB_FILE, 'utf8').trim();
      const decrypted = decryptText(rawEncrypted);
      if (decrypted) return JSON.parse(decrypted);
    }
    if (fs.existsSync(LEGACY_JSON_FILE)) {
      return JSON.parse(fs.readFileSync(LEGACY_JSON_FILE, 'utf8'));
    }
    return {};
  } catch (e) {
    console.error('Error reading database:', e.message);
    return {};
  }
}

function writeDb(data) {
  try {
    const jsonStr = JSON.stringify(data, null, 2);
    const cipher = encryptText(jsonStr);
    fs.writeFileSync(DB_FILE, cipher, 'utf8');
  } catch (e) {
    console.error('Error writing to encrypted database file:', e.message);
  }
}

// ── SERVER-SIDE HARDWARE FINGERPRINTING & LICENSE SHIELD ─────────
const LICENSE_SECRET_SALT = "RedSharkPOS_LicenseSalt_2026_Enterprise";

const HW_CACHE_FILE = path.join(__dirname, 'data', 'hardware_cache.json');

function getCachedHardwareIds() {
  try {
    if (fs.existsSync(HW_CACHE_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(HW_CACHE_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

function saveCachedHardwareIds(idsArray) {
  try {
    const existing = new Set(getCachedHardwareIds().map(x => String(x).toUpperCase()));
    idsArray.forEach(id => {
      if (id && typeof id === 'string') existing.add(id.trim().toUpperCase());
    });
    fs.writeFileSync(HW_CACHE_FILE, JSON.stringify(Array.from(existing), null, 2), 'utf8');
  } catch {}
}

function getAllHardwareMachineIds() {
  const ids = new Set(getCachedHardwareIds());
  
  // 1. MAC-based hardware ID (used in standard activations)
  try {
    const ifaces = os.networkInterfaces();
    for (const iface of Object.values(ifaces)) {
      for (const alias of (iface || [])) {
        if (!alias.internal && alias.mac && alias.mac !== '00:00:00:00:00:00') {
          ids.add('RS-' + alias.mac.replace(/:/g, '').substring(0, 16).toUpperCase());
        }
      }
    }
  } catch {}

  // 2. Windows MachineGuid / UUID
  try {
    let rawId = '';
    if (os.platform() === 'win32') {
      try {
        const regOut = execSync('reg query "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: 'utf8', timeout: 3000 });
        const m = regOut.match(/MachineGuid\s+REG_SZ\s+([a-fA-F0-9\-]+)/i);
        if (m && m[1]) rawId += m[1].trim();
      } catch {}

      try {
        const wmicOut = execSync('wmic csproduct get uuid', { encoding: 'utf8', timeout: 2000, stdio: ['pipe', 'pipe', 'ignore'] });
        const lines = wmicOut.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        if (lines.length > 1 && lines[1] && !lines[1].toLowerCase().includes('uuid')) {
          rawId += '_' + lines[1];
        }
      } catch {}
    }
    if (rawId) {
      const hash = crypto.createHash('sha256').update(rawId).digest('hex').toUpperCase();
      ids.add(`RS-${hash.substring(0, 4)}-${hash.substring(4, 8)}-${hash.substring(8, 12)}-${hash.substring(12, 16)}`);
    }
  } catch {}

  // 3. Fallback hostname ID
  try {
    const hostId = 'RS-' + (os.hostname() || 'SERVER').replace(/[^a-zA-Z0-9]/g, '').substring(0, 16).toUpperCase();
    ids.add(hostId);
  } catch {}

  const result = Array.from(ids);
  if (result.length) {
    saveCachedHardwareIds(result);
  }
  return result;
}

function verifyLicenseData(lic) {
  if (!lic || !lic.machine_id || !lic.expiry_date || !lic.signature) return false;
  
  // Verify machine lock against all valid IDs of this server (including cached persistent hardware IDs)
  const validIds = getAllHardwareMachineIds();
  const machineMatches = validIds.some(id => id.toUpperCase() === String(lic.machine_id).trim().toUpperCase());
  if (!machineMatches) return false;

  const modulesStr = (lic.allowed_modules || []).join(',');
  const checkText = `${lic.machine_id}|${lic.client_name || ''}|${lic.expiry_date}|${modulesStr}|${LICENSE_SECRET_SALT}`;
  const computedSig = crypto.createHash('sha256').update(checkText).digest('hex');
  if (computedSig === lic.signature) {
    // Lock in this verified machine_id so disconnecting network/WiFi never breaks license
    saveCachedHardwareIds([lic.machine_id]);
    return true;
  }
  return false;
}

function getServerLicenseStatus() {
  const db = readDb();
  const settings = db['settings'] || [];
  const getVal = (key) => settings.find(s => s.key === key)?.value;
  const validIds = getAllHardwareMachineIds();

  const rawLic = getVal('license_active_data');
  if (rawLic) {
    try {
      const lic = typeof rawLic === 'string' ? JSON.parse(rawLic) : rawLic;
      if (verifyLicenseData(lic)) {
        const now = new Date();
        const expiry = new Date(lic.expiry_date + 'T23:59:59');
        if (now <= expiry) {
          return { active: true, status: 'active', data: lic, machine_id: lic.machine_id, is_licensed: true };
        } else {
          return { active: false, status: 'expired', data: lic, machine_id: lic.machine_id, is_licensed: true };
        }
      }
    } catch {}
  }

  const isDemo = getVal('demo_trial_active');
  if (isDemo === true || isDemo === 'true') {
    const expiresAt = getVal('demo_expires_at');
    const remainingMs = expiresAt ? (new Date(expiresAt).getTime() - Date.now()) : 0;
    if (remainingMs > 0) {
      return { active: true, status: 'demo_trial', expiresAt, machine_id: validIds[0], is_licensed: false, is_demo: true };
    } else {
      return { active: false, status: 'expired_demo', machine_id: validIds[0], is_licensed: false };
    }
  }

  return { active: false, status: 'unlicensed', machine_id: validIds[0], is_licensed: false };
}

// ── GET /api/license-status ──────────────────────────────────────
app.get('/api/license-status', (req, res) => {
  try {
    const status = getServerLicenseStatus();
    res.json({ success: true, ...status });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/db-all ──────────────────────────────────────────────
app.get('/api/db-all', (req, res) => {
  try {
    const db = readDb();
    res.json({ success: true, data: db });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/db-export-decrypted (Owner only with PIN) ────────────
app.get('/api/db-export-decrypted', (req, res) => {
  try {
    const pin = req.query.pin || req.headers['x-owner-pin'];
    if (pin !== '0wner' && pin !== 'Owner') {
      return res.status(403).json({ success: false, error: 'Unauthorized: Invalid Owner PIN' });
    }
    const db = readDb();
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="redshark_backup_${new Date().toISOString().split('T')[0]}.json"`);
    res.status(200).send(JSON.stringify(db, null, 2));
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/db/:storeName ───────────────────────────────────────
app.get('/api/db/:storeName', (req, res) => {
  try {
    const db = readDb();
    const store = db[req.params.storeName] || [];
    res.json({ success: true, data: store });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/db/:storeName/:id ───────────────────────────────────
app.get('/api/db/:storeName/:id', (req, res) => {
  try {
    const db = readDb();
    const store = db[req.params.storeName] || [];
    const id = req.params.id;
    const item = store.find(x => String(x.id) === String(id) || (x.key && String(x.key) === String(id)));
    res.json({ success: true, data: item });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/db/:storeName ──────────────────────────────────────
app.post('/api/db/:storeName', (req, res) => {
  try {
    const { storeName } = req.params;
    const item = req.body;
    const db = readDb();
    if (!db[storeName]) db[storeName] = [];
    const store = db[storeName];

    const keyField = storeName === 'settings' || storeName === 'sequences' ? 'key' : 'id';

    if (keyField === 'key') {
      const idx = store.findIndex(x => x.key === item.key);
      if (idx > -1) {
        store[idx] = item;
      } else {
        store.push(item);
      }
    } else {
      if (item.id === undefined || item.id === null) {
        // Prevent duplicate categories with the same name
        if (storeName === 'categories') {
          const cName = (item.name_en || item.name || item.name_ar || '').toLowerCase().trim();
          const existing = store.find(x => (x.name_en || x.name || x.name_ar || '').toLowerCase().trim() === cName);
          if (existing) {
            Object.assign(existing, item, { id: existing.id });
            writeDb(db);
            return res.json({ success: true, data: existing });
          }
        }
        // Prevent duplicate items with the same barcode or item_code
        if (storeName === 'items') {
          const bCode = (item.barcode || item.item_code || item.code || '').toLowerCase().trim();
          if (bCode) {
            const existing = store.find(x => (x.barcode || x.item_code || x.code || '').toLowerCase().trim() === bCode);
            if (existing) {
              Object.assign(existing, item, { id: existing.id });
              writeDb(db);
              return res.json({ success: true, data: existing });
            }
          }
        }

        const ids = store.map(x => parseInt(x.id)).filter(x => !isNaN(x));
        const maxId = ids.length ? Math.max(...ids) : 0;
        item.id = maxId + 1;
        store.push(item);
      } else {
        const idx = store.findIndex(x => String(x.id) === String(item.id));
        if (idx > -1) {
          store[idx] = item;
        } else {
          store.push(item);
        }
      }
    }

    writeDb(db);
    res.json({ success: true, data: item });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/db-bulk/:storeName (High-performance Batch Insert/Update) ──────────
app.post('/api/db-bulk/:storeName', (req, res) => {
  try {
    const { storeName } = req.params;
    const incomingItems = Array.isArray(req.body) ? req.body : (req.body.items || []);
    if (!incomingItems.length) {
      return res.json({ success: true, count: 0 });
    }

    const db = readDb();
    if (!db[storeName]) db[storeName] = [];
    const store = db[storeName];

    const keyField = storeName === 'settings' || storeName === 'sequences' ? 'key' : 'id';
    
    const idMap = new Map();
    const barcodeMap = new Map();
    const codeMap = new Map();

    store.forEach((x, idx) => {
      if (x[keyField] !== undefined && x[keyField] !== null) {
        idMap.set(String(x[keyField]), idx);
      }
      if (storeName === 'items') {
        if (x.barcode) barcodeMap.set(String(x.barcode).toLowerCase().trim(), idx);
        if (x.item_code) codeMap.set(String(x.item_code).toLowerCase().trim(), idx);
      }
    });

    const ids = store.map(x => parseInt(x.id)).filter(x => !isNaN(x));
    let nextId = ids.length ? Math.max(...ids) + 1 : 1;

    for (const item of incomingItems) {
      if (keyField === 'key') {
        const k = String(item.key);
        if (idMap.has(k)) {
          store[idMap.get(k)] = item;
        } else {
          store.push(item);
          idMap.set(k, store.length - 1);
        }
      } else {
        let matchIdx = -1;
        if (item.id !== undefined && item.id !== null && idMap.has(String(item.id))) {
          matchIdx = idMap.get(String(item.id));
        } else if (storeName === 'items') {
          const bCode = (item.barcode || '').toLowerCase().trim();
          const iCode = (item.item_code || item.code || '').toLowerCase().trim();
          if (bCode && barcodeMap.has(bCode)) {
            matchIdx = barcodeMap.get(bCode);
          } else if (iCode && codeMap.has(iCode)) {
            matchIdx = codeMap.get(iCode);
          }
        }

        if (matchIdx > -1) {
          const existing = store[matchIdx];
          Object.assign(existing, item, { id: existing.id });
        } else {
          if (item.id === undefined || item.id === null) {
            item.id = nextId++;
          } else {
            const numId = parseInt(item.id);
            if (!isNaN(numId) && numId >= nextId) nextId = numId + 1;
          }
          store.push(item);
          const newIdx = store.length - 1;
          idMap.set(String(item.id), newIdx);
          if (storeName === 'items') {
            if (item.barcode) barcodeMap.set(String(item.barcode).toLowerCase().trim(), newIdx);
            if (item.item_code) codeMap.set(String(item.item_code).toLowerCase().trim(), newIdx);
          }
        }
      }
    }

    writeDb(db);
    res.json({ success: true, count: incomingItems.length, total: store.length });
  } catch (err) {
    console.error('Bulk save error:', err);
    res.json({ success: false, error: err.message });
  }
});

// ── GET /api/qr-code (100% Offline Local QR Generator) ───────────
app.get('/api/qr-code', async (req, res) => {
  try {
    const text = req.query.text || req.query.data || req.query.url || 'http://localhost:3000/mobile.html';
    const QRCode = require('qrcode');
    const dataUrl = await QRCode.toDataURL(text, { width: 240, margin: 1 });
    res.json({ success: true, dataUrl });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── DELETE /api/db/:storeName/:id ───────────────────────────────
app.delete('/api/db/:storeName/:id', (req, res) => {
  try {
    const { storeName, id } = req.params;
    const db = readDb();
    if (db[storeName]) {
      const keyField = storeName === 'settings' || storeName === 'sequences' ? 'key' : 'id';
      db[storeName] = db[storeName].filter(x => String(x[keyField]) !== String(id));
      writeDb(db);
    }
    res.json({ success: true });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── POST /api/db-clear/:storeName ───────────────────────────────
app.post('/api/db-clear/:storeName', (req, res) => {
  try {
    const { storeName } = req.params;
    const db = readDb();
    db[storeName] = [];
    writeDb(db);
    res.json({ success: true });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ── System Safe Updater API ──────────────────────────────────────
// Lets technician browse release folder and apply updates with zero data loss
app.get('/api/system/browse-release-folder', (req, res) => {
  try {
    if (os.platform() === 'win32') {
      const psCmd = `powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = 'Select Red Shark POS Release Folder'; $d.ShowNewFolderButton = $false; $top = New-Object System.Windows.Forms.Form -Property @{TopMost=$true}; if ($d.ShowDialog($top) -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.SelectedPath }"`;
      const selected = execSync(psCmd, { encoding: 'utf8', timeout: 60000 }).trim();
      return res.json({ success: true, folderPath: selected || '' });
    }
    res.json({ success: false, error: 'Browse dialog is only supported on Windows' });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

app.post('/api/system/apply-release-update', (req, res) => {
  try {
    const { releasePath } = req.body;
    if (!releasePath || !fs.existsSync(releasePath)) {
      return res.status(400).json({ success: false, error: 'Release folder path is invalid or does not exist.' });
    }

    const currentDir = process.cwd();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(currentDir, 'Backup', `PreUpdate_${timestamp}`);

    // 1. Create Pre-Update Safety Backup
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    const dataDir = path.join(currentDir, 'data');
    if (fs.existsSync(dataDir)) {
      fs.cpSync(dataDir, path.join(backupDir, 'data'), { recursive: true });
    }

    // 2. Protected customer directories & files
    const PROTECTED = new Set(['data', 'Backup', 'temp_edge_profile', '.env', 'scratch', '.git', '.agents']);

    // 3. Copy release items
    const releaseItems = fs.readdirSync(releasePath);
    let copiedCount = 0;

    for (const item of releaseItems) {
      if (PROTECTED.has(item)) continue;
      if (['developer_generator.html', 'developer_decryptor.html', 'license_generator.html', 'generate_license.js'].includes(item)) continue;

      const src = path.join(releasePath, item);
      const dest = path.join(currentDir, item);
      const stat = fs.statSync(src);

      if (stat.isDirectory()) {
        fs.cpSync(src, dest, { recursive: true, force: true });
      } else {
        fs.copyFileSync(src, dest);
      }
      copiedCount++;
    }

    res.json({
      success: true,
      message: `Update applied successfully! (${copiedCount} modules updated)`,
      backupLocation: backupDir
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Upload .zip / .rar Update Package API ─────────────────────────
// Allows customer or admin to upload an update ZIP directly in the browser
app.post('/api/system/upload-update-package', (req, res) => {
  const currentDir = process.cwd();
  const tempDir = path.join(currentDir, 'Backup', 'temp_update_' + Date.now());
  
  try {
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
  } catch (e) {
    return res.status(500).json({ success: false, error: 'Cannot create temp update folder: ' + e.message });
  }

  const tempZipPath = path.join(tempDir, 'incoming_update.zip');
  const writeStream = fs.createWriteStream(tempZipPath);

  req.pipe(writeStream);

  writeStream.on('error', (err) => {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
    res.status(500).json({ success: false, error: 'Failed writing uploaded package: ' + err.message });
  });

  writeStream.on('finish', () => {
    try {
      if (!fs.existsSync(tempZipPath) || fs.statSync(tempZipPath).size < 1000) {
        throw new Error('Uploaded file is empty or too small to be a valid update archive.');
      }

      // 1. Create Pre-Update Safety Backup of customer databases & data
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupDir = path.join(currentDir, 'Backup', `PreUpdate_${timestamp}`);
      if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });

      const dataDir = path.join(currentDir, 'data');
      if (fs.existsSync(dataDir)) {
        fs.cpSync(dataDir, path.join(backupDir, 'data'), { recursive: true });
      }

      // 2. Extract ZIP archive into temp extract folder
      const extractDir = path.join(tempDir, 'extracted');
      if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });

      let extractedOk = false;
      try {
        execSync(`tar -xf "${tempZipPath}" -C "${extractDir}"`, { timeout: 120000 });
        extractedOk = true;
      } catch (tarErr) {
        try {
          const psExtract = `powershell -NoProfile -Command "Expand-Archive -Path '${tempZipPath}' -DestinationPath '${extractDir}' -Force"`;
          execSync(psExtract, { timeout: 180000 });
          extractedOk = true;
        } catch (psErr) {
          throw new Error('Failed extracting update archive: ' + psErr.message);
        }
      }

      // 3. Find root folder containing core POS files (handles any zip structure, partial patches, or wrapped folders)
      let sourceDir = extractDir;
      function findCoreDirectory(dir, depth = 0) {
        if (depth > 5) return null;
        if (
          fs.existsSync(path.join(dir, 'index.html')) || 
          fs.existsSync(path.join(dir, 'js')) ||
          fs.existsSync(path.join(dir, 'server.js')) ||
          fs.existsSync(path.join(dir, 'version.json')) ||
          fs.existsSync(path.join(dir, 'modules')) ||
          fs.existsSync(path.join(dir, 'admin.js')) ||
          fs.existsSync(path.join(dir, 'print.js')) ||
          fs.existsSync(path.join(dir, 'pos.js'))
        ) {
          return dir;
        }
        try {
          const entries = fs.readdirSync(dir);
          for (const entry of entries) {
            if (entry === '__MACOSX' || entry === '.git') continue;
            const full = path.join(dir, entry);
            if (fs.statSync(full).isDirectory()) {
              const found = findCoreDirectory(full, depth + 1);
              if (found) return found;
            }
          }
        } catch (e) {}
        return null;
      }

      const detectedCore = findCoreDirectory(extractDir);
      if (detectedCore) {
        sourceDir = detectedCore;
      }

      // Verify that source has core POS files or valid patch modules
      const hasCore = fs.existsSync(path.join(sourceDir, 'index.html')) || 
                      fs.existsSync(path.join(sourceDir, 'server.js')) || 
                      fs.existsSync(path.join(sourceDir, 'js')) ||
                      fs.existsSync(path.join(sourceDir, 'modules')) ||
                      fs.existsSync(path.join(sourceDir, 'admin.js')) ||
                      fs.existsSync(path.join(sourceDir, 'print.js')) ||
                      fs.existsSync(path.join(sourceDir, 'pos.js'));
      if (!hasCore) {
        throw new Error('The uploaded archive does not contain valid Red Shark POS files (index.html or js folder not found).');
      }

      // 4. Customer Data Blacklist (100% PRESERVED - NEVER OVERWRITTEN)
      const PROTECTED = new Set([
        'data',
        'Backup',
        'temp_edge_profile',
        '.env',
        'scratch',
        '.git',
        '.agents',
        'node_modules'
      ]);

      // 5. Copy update items
      const itemsToCopy = fs.readdirSync(sourceDir);
      let copiedCount = 0;

      for (const item of itemsToCopy) {
        if (PROTECTED.has(item)) continue;
        if (['developer_generator.html', 'developer_decryptor.html', 'license_generator.html', 'generate_license.js'].includes(item)) continue;
        if (item.endsWith('.db') || item.endsWith('.lic') || item.endsWith('.req')) continue;

        const src = path.join(sourceDir, item);
        const stat = fs.statSync(src);

        // Smart patch routing: if standalone module files are uploaded at root of archive
        let dest = path.join(currentDir, item);
        if (!stat.isDirectory()) {
          if (['admin.js', 'pos.js', 'print.js', 'items.js', 'customers.js', 'sales.js', 'reports.js', 'finance.js', 'inventory.js'].includes(item)) {
            const modDir = path.join(currentDir, 'js', 'modules');
            if (fs.existsSync(modDir)) dest = path.join(modDir, item);
          } else if (['utils.js', 'db.js', 'app.js', 'auth.js', 'i18n.js'].includes(item)) {
            const jsDir = path.join(currentDir, 'js');
            if (fs.existsSync(jsDir)) dest = path.join(jsDir, item);
          }
        } else if (item === 'modules') {
          const jsDir = path.join(currentDir, 'js');
          if (fs.existsSync(jsDir)) dest = path.join(jsDir, 'modules');
        }

        if (stat.isDirectory()) {
          fs.cpSync(src, dest, { recursive: true, force: true });
        } else {
          fs.copyFileSync(src, dest);
        }
        copiedCount++;
      }

      // 6. Get new version info
      let newVersion = '';
      let newBuild = '';
      const verPath = path.join(currentDir, 'version.json');
      if (fs.existsSync(verPath)) {
        try {
          const vObj = JSON.parse(fs.readFileSync(verPath, 'utf8'));
          newVersion = vObj.version;
          newBuild = vObj.build;
        } catch {}
      }

      // 7. Cleanup temp folder
      try {
        fs.rmSync(tempDir, { recursive: true, force: true });
      } catch {}

      res.json({
        success: true,
        message: `Update applied successfully! (${copiedCount} modules updated)`,
        version: newVersion,
        build: newBuild,
        backupLocation: backupDir
      });
    } catch (err) {
      try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
      res.status(500).json({ success: false, error: err.message });
    }
  });
});

// ── 1-Click Cloud OTA Update Downloader & Safe Applier ────────────
app.post('/api/system/apply-cloud-update', async (req, res) => {
  const currentDir = process.cwd();
  const tempDir = path.join(currentDir, 'Backup', 'temp_ota_' + Date.now());
  const downloadUrl = req.body?.downloadUrl || 'https://shop.redshark-ai.com/dist/update.zip';

  try {
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    const tempZipPath = path.join(tempDir, 'ota_update.zip');

    // 1. Download update package
    const https = require('https');
    const http = require('http');

    const downloadFile = (url) => new Promise((resolve, reject) => {
      const client = url.startsWith('https') ? https : http;
      client.get(url, { timeout: 30000 }, (resp) => {
        if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
          return resolve(downloadFile(resp.headers.location));
        }
        if (resp.statusCode !== 200) {
          return reject(new Error('Download failed with status ' + resp.statusCode));
        }
        const fileStream = fs.createWriteStream(tempZipPath);
        resp.pipe(fileStream);
        fileStream.on('finish', () => fileStream.close(resolve));
        fileStream.on('error', reject);
      }).on('error', reject);
    });

    await downloadFile(downloadUrl);

    if (!fs.existsSync(tempZipPath) || fs.statSync(tempZipPath).size < 1000) {
      throw new Error('Downloaded update file is invalid or too small.');
    }

    // 2. Pre-Update Backup of customer database
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(currentDir, 'Backup', `PreUpdate_${timestamp}`);
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const dataDir = path.join(currentDir, 'data');
    if (fs.existsSync(dataDir)) {
      fs.cpSync(dataDir, path.join(backupDir, 'data'), { recursive: true });
    }

    // 3. Extract ZIP
    const extractDir = path.join(tempDir, 'extracted');
    if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });

    try {
      execSync(`tar -xf "${tempZipPath}" -C "${extractDir}"`, { timeout: 60000 });
    } catch (e1) {
      try {
        execSync(`powershell -NoProfile -Command "Expand-Archive -Path '${tempZipPath}' -DestinationPath '${extractDir}' -Force"`, { timeout: 120000 });
      } catch (e2) {
        throw new Error('Could not extract update archive: ' + e2.message);
      }
    }

    // 4. Copy update items, strictly preserving customer databases & data
    const PROTECTED = new Set(['data', 'Backup', 'temp_edge_profile', '.env', 'scratch', '.git', '.agents', 'node_modules']);
    const itemsToCopy = fs.readdirSync(extractDir);
    let copiedCount = 0;

    for (const item of itemsToCopy) {
      if (PROTECTED.has(item)) continue;
      if (item.endsWith('.db') || item.endsWith('.lic') || item.endsWith('.req')) continue;

      const src = path.join(extractDir, item);
      const dest = path.join(currentDir, item);
      const stat = fs.statSync(src);

      if (stat.isDirectory()) {
        fs.cpSync(src, dest, { recursive: true, force: true });
      } else {
        fs.copyFileSync(src, dest);
      }
      copiedCount++;
    }

    // Cleanup temp
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}

    // Version info
    let newVersion = '1.2.33';
    let newBuild = 49;
    const vPath = path.join(currentDir, 'version.json');
    if (fs.existsSync(vPath)) {
      try {
        const vObj = JSON.parse(fs.readFileSync(vPath, 'utf8'));
        newVersion = vObj.version;
        newBuild = vObj.build;
      } catch {}
    }

    res.json({
      success: true,
      message: `OTA Update applied successfully! (${copiedCount} modules updated)`,
      version: newVersion,
      build: newBuild,
      backupLocation: backupDir
    });
  } catch (err) {
    try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Launch Standalone Update_Customer_Software.bat ────────────────
app.post('/api/system/launch-update-bat', (req, res) => {
  try {
    const batPath = path.join(process.cwd(), 'Update_Customer_Software.bat');
    if (!fs.existsSync(batPath)) {
      return res.status(404).json({ success: false, error: 'Update_Customer_Software.bat was not found in the application directory.' });
    }

    const { spawn } = require('child_process');
    const child = spawn('cmd.exe', ['/c', 'start', '""', batPath], {
      cwd: process.cwd(),
      detached: true,
      stdio: 'ignore'
    });
    child.unref();

    res.json({ success: true, message: 'Update assistant launched on Windows desktop.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Get System Version ────────────────────────────────────────────
app.get('/api/system/version', (req, res) => {
  try {
    const verPath = path.join(process.cwd(), 'version.json');
    if (fs.existsSync(verPath)) {
      const vObj = JSON.parse(fs.readFileSync(verPath, 'utf8'));
      return res.json({ success: true, ...vObj });
    }
    res.json({ success: true, version: '1.2.0', build: 16 });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════════════
// ── MULTI-POS & BRANCH SYNC ENGINE ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════
const SYNC_DIR = path.join(__dirname, 'data', 'sync');
const TABLES_DIR = path.join(SYNC_DIR, 'tables');
if (!fs.existsSync(SYNC_DIR)) fs.mkdirSync(SYNC_DIR, { recursive: true });
if (!fs.existsSync(TABLES_DIR)) fs.mkdirSync(TABLES_DIR, { recursive: true });

const NODES_FILE = path.join(SYNC_DIR, 'nodes.json');
const CONFIG_FILE = path.join(SYNC_DIR, 'config.json');
const TRANSACTIONS_FILE = path.join(SYNC_DIR, 'transactions.json');

function getLocalIpAddress() {
  const interfaces = os.networkInterfaces();
  for (const ifaceName of Object.keys(interfaces)) {
    for (const iface of interfaces[ifaceName]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}

function loadSyncConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    }
  } catch (e) {}
  return {
    nodeRole: 'server', // 'server' (default) | 'pos' | 'branch'
    serverIp: getLocalIpAddress(),
    serverPort: PORT,
    nodeName: 'Main Server (Central Branch)',
    nodeId: 'SRV-01',
    branchId: 'main',
    syncTables: ['items', 'categories', 'offers', 'units']
  };
}

function saveSyncConfig(cfg) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving sync config:', e);
  }
}

function loadRegisteredNodes() {
  try {
    if (fs.existsSync(NODES_FILE)) {
      return JSON.parse(fs.readFileSync(NODES_FILE, 'utf8'));
    }
  } catch (e) {}
  return [];
}

function saveRegisteredNodes(nodes) {
  try {
    fs.writeFileSync(NODES_FILE, JSON.stringify(nodes, null, 2), 'utf8');
  } catch (e) {
    console.error('Error saving registered nodes:', e);
  }
}

// Active Server-Sent Events (SSE) client connections
const sseClients = new Map(); // clientId -> { res, info }

// Send 25s keepalive ping to maintain SSE connection across Cloudflare tunnels & proxies
setInterval(() => {
  for (const [clientId, client] of sseClients.entries()) {
    try {
      client.res.write(': keepalive\n\n');
    } catch (err) {
      sseClients.delete(clientId);
    }
  }
}, 25000);

function broadcastSyncEvent(eventName, payload = {}) {
  const msg = `data: ${JSON.stringify({ event: eventName, ...payload, timestamp: Date.now() })}\n\n`;
  for (const [clientId, client] of sseClients.entries()) {
    try {
      client.res.write(msg);
    } catch (err) {
      console.warn(`Error writing SSE to client ${clientId}:`, err.message);
      sseClients.delete(clientId);
    }
  }
}

function touchNode(nodeId, name, role, clientIp) {
  if (!nodeId) return;
  try {
    const nodes = loadRegisteredNodes();
    const cleanIp = (clientIp || '').replace(/^::ffff:/, '');
    const existing = nodes.find(n => n.nodeId === nodeId);
    if (existing) {
      existing.lastSeen = new Date().toISOString();
      if (cleanIp) existing.ip = cleanIp;
      if (name) existing.name = name;
      if (role) existing.role = role;
      saveRegisteredNodes(nodes);
    } else {
      nodes.push({
        nodeId,
        name: name || nodeId,
        role: role || 'branch',
        ip: cleanIp || '127.0.0.1',
        lastSeen: new Date().toISOString()
      });
      saveRegisteredNodes(nodes);
    }
  } catch (e) {
    console.warn('Error in touchNode:', e.message);
  }
}

// Keep-alive heartbeat every 15 seconds (prevents Cloudflare/proxy timeouts)
setInterval(() => {
  for (const [clientId, client] of sseClients.entries()) {
    try {
      client.res.write(': keep-alive\n\n');
    } catch (e) {
      sseClients.delete(clientId);
    }
  }
}, 15000);

// 1. GET /api/sync/status (Also registers/touches the node if parameters passed)
// GET /api/sync/cloud-status
app.get('/api/sync/cloud-status', (req, res) => {
  try {
    const db = readDb();
    const settings = db.settings || [];
    const getVal = (k, def) => {
      const found = settings.find(s => s.key === k);
      return found ? found.value : def;
    };
    res.json({
      success: true,
      role: getVal('sync_node_role', 'server'),
      nodeId: getVal('sync_node_id', 'main'),
      nodeName: getVal('sync_node_name', 'Main Store'),
      branchId: getVal('sync_branch_id', 'main'),
      terminalName: getVal('pos_terminal_name', 'POS-1'),
      shopSlug: getVal('online_store_shop_slug', 'shop101'),
      supabaseUrl: getVal('online_store_url', 'https://mcebwpiswvwqcdwjpagy.supabase.co'),
      lastSyncTime: getVal('last_cloud_sync_time', new Date().toISOString())
    });
  } catch(e) {
    res.json({ success: false, error: e.message });
  }
});

app.get('/api/sync/status', (req, res) => {
  const nodeId = req.query.nodeId;
  const name = req.query.name || req.query.nodeName;
  const role = req.query.role;
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';
  if (nodeId) {
    touchNode(nodeId, name, role, clientIp);
  }

  const localIp = getLocalIpAddress();
  const cfg = loadSyncConfig();
  res.json({
    success: true,
    localIp,
    port: PORT,
    serverUrl: `http://${localIp}:${PORT}`,
    connectedClients: sseClients.size,
    config: cfg
  });
});

// 1b. ALL /api/sync/ping (Explicit lightweight heartbeat endpoint for remote branches)
app.all('/api/sync/ping', (req, res) => {
  const nodeId = req.query.nodeId || req.body?.nodeId;
  const name = req.query.name || req.query.nodeName || req.body?.name || req.body?.nodeName;
  const role = req.query.role || req.body?.role || 'branch';
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';

  if (nodeId) {
    touchNode(nodeId, name, role, clientIp);
  }

  res.json({
    success: true,
    serverTime: new Date().toISOString(),
    connectedClients: sseClients.size,
    receivedNodeId: nodeId || null
  });
});

// 2. GET /api/sync/config
app.get('/api/sync/config', (req, res) => {
  res.json({ success: true, config: loadSyncConfig() });
});

// 3. POST /api/sync/config
app.post('/api/sync/config', (req, res) => {
  const cur = loadSyncConfig();
  const updated = { ...cur, ...req.body };
  saveSyncConfig(updated);
  broadcastSyncEvent('config_updated', { config: updated });
  res.json({ success: true, config: updated });
});

// 4. GET /api/sync/nodes (Enriched with real-time online status)
app.get('/api/sync/nodes', (req, res) => {
  const nodes = loadRegisteredNodes();
  const now = Date.now();
  const enriched = nodes.map(n => ({
    ...n,
    isOnline: sseClients.has(n.nodeId) || (n.lastSeen && (now - new Date(n.lastSeen).getTime() < 90000))
  }));
  res.json({ success: true, nodes: enriched, connectedClients: sseClients.size });
});

// 5. POST /api/sync/nodes (Add/Update/Delete nodes)
app.post('/api/sync/nodes', (req, res) => {
  const { action, node } = req.body;
  let nodes = loadRegisteredNodes();

  if (action === 'delete') {
    nodes = nodes.filter(n => n.nodeId !== node.nodeId);
  } else if (action === 'save') {
    const idx = nodes.findIndex(n => n.nodeId === node.nodeId);
    if (idx >= 0) {
      nodes[idx] = { ...nodes[idx], ...node, updatedAt: new Date().toISOString() };
    } else {
      nodes.push({ ...node, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
  }
  saveRegisteredNodes(nodes);
  broadcastSyncEvent('nodes_updated', { nodesCount: nodes.length });
  res.json({ success: true, nodes });
});

// 6. GET /api/sync/events (Real-time SSE Stream)
app.get('/api/sync/events', (req, res) => {
  const nodeId = req.query.nodeId || `CLIENT-${Date.now()}`;
  const nodeName = req.query.nodeName || 'Remote POS';
  const role = req.query.role || 'pos';
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.flushHeaders?.();

  // Send initial welcome & config
  const cfg = loadSyncConfig();
  res.write(`data: ${JSON.stringify({
    event: 'connected',
    nodeId,
    serverTime: new Date().toISOString(),
    syncTables: cfg.syncTables || []
  })}\n\n`);

  // Register in active connections
  sseClients.set(nodeId, {
    res,
    info: { nodeId, nodeName, role, clientIp, connectedAt: new Date().toISOString() }
  });

  // Also touch/update registered nodes list lastSeen
  touchNode(nodeId, nodeName, role, clientIp);

  req.on('close', () => {
    sseClients.delete(nodeId);
  });
});

// 7. GET /api/sync/table/:table (Download table data)
app.get('/api/sync/table/:table', (req, res) => {
  const tbl = req.params.table.replace(/[^a-zA-Z0-9_-]/g, '');
  const nodeId = req.query.nodeId;
  if (nodeId) {
    const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';
    touchNode(nodeId, req.query.name || nodeId, req.query.role || 'branch', clientIp);
  }

  // 1. Primary: Return live records directly from central database (db.dat)
  try {
    const db = readDb();
    if (db && Array.isArray(db[tbl])) {
      return res.json({ success: true, table: tbl, records: db[tbl] });
    }
  } catch (dbErr) {
    console.warn(`[Sync] readDb fallback error for table ${tbl}:`, dbErr.message);
  }

  // 2. Secondary: Fallback to cached table snapshot if table not in central db
  const filePath = path.join(TABLES_DIR, `${tbl}.json`);
  if (fs.existsSync(filePath)) {
    try {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      return res.json({ success: true, table: tbl, records: data });
    } catch (e) {
      return res.status(500).json({ success: false, error: e.message });
    }
  }
  res.json({ success: true, table: tbl, records: [] });
});

// 8. POST /api/sync/table/:table (Save table snapshot & broadcast)
app.post('/api/sync/table/:table', (req, res) => {
  const tbl = req.params.table.replace(/[^a-zA-Z0-9_-]/g, '');
  const records = req.body.records || [];
  const filePath = path.join(TABLES_DIR, `${tbl}.json`);
  try {
    fs.writeFileSync(filePath, JSON.stringify(records), 'utf8');
    broadcastSyncEvent('table_updated', { table: tbl, count: records.length });
    res.json({ success: true, table: tbl, count: records.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 9. POST /api/sync/notify (Trigger instant push on record change)
app.post('/api/sync/notify', (req, res) => {
  const { table, action, record, records } = req.body;
  if (table && records) {
    const filePath = path.join(TABLES_DIR, `${table}.json`);
    try {
      fs.writeFileSync(filePath, JSON.stringify(records), 'utf8');
    } catch (e) {}
  }
  broadcastSyncEvent('table_updated', { table, action: action || 'update' });
  res.json({ success: true });
});

// 10. POST /api/sync/push-transactions (Branches upload sales & cashbox sessions)
app.post('/api/sync/push-transactions', (req, res) => {
  try {
    const { nodeId, branchId, sales, cashboxSessions } = req.body;
    let existing = { sales: [], cashboxSessions: [] };
    if (fs.existsSync(TRANSACTIONS_FILE)) {
      try { existing = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8')); } catch (e) {}
    }
    if (!existing.sales) existing.sales = [];
    if (!existing.cashboxSessions) existing.cashboxSessions = [];

    // Merge sales avoiding duplicates by id/invoice_no
    if (Array.isArray(sales)) {
      for (const s of sales) {
        const enriched = { ...s, syncNodeId: nodeId, syncBranchId: branchId || nodeId };
        const idx = existing.sales.findIndex(x => x.id === s.id || (x.invoice_no && x.invoice_no === s.invoice_no));
        if (idx >= 0) existing.sales[idx] = enriched;
        else existing.sales.push(enriched);
      }
    }

    // Merge cashboxSessions avoiding duplicates
    if (Array.isArray(cashboxSessions)) {
      for (const cb of cashboxSessions) {
        const enriched = { ...cb, syncNodeId: nodeId, syncBranchId: branchId || nodeId };
        const idx = existing.cashboxSessions.findIndex(x => x.id === cb.id || x.session_id === cb.session_id);
        if (idx >= 0) existing.cashboxSessions[idx] = enriched;
        else existing.cashboxSessions.push(enriched);
      }
    }

    fs.writeFileSync(TRANSACTIONS_FILE, JSON.stringify(existing, null, 2), 'utf8');
    if (nodeId) {
      const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip || req.connection.remoteAddress || '';
      touchNode(nodeId, nodeId, 'branch', clientIp);
    }
    broadcastSyncEvent('transactions_received', { nodeId, branchId, count: (sales?.length || 0) });
    res.json({ success: true, message: 'Transactions merged successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 11. GET /api/sync/transactions (Server reports fetch consolidated transactions)
app.get('/api/sync/transactions', (req, res) => {
  try {
    if (fs.existsSync(TRANSACTIONS_FILE)) {
      const data = JSON.parse(fs.readFileSync(TRANSACTIONS_FILE, 'utf8'));
      const branchId = req.query.branchId;
      const nodeId = req.query.nodeId;
      let sales = data.sales || [];
      let cashboxSessions = data.cashboxSessions || [];

      if (branchId && branchId !== 'all') {
        sales = sales.filter(s => s.syncBranchId === branchId || s.branch_id === branchId);
        cashboxSessions = cashboxSessions.filter(cb => cb.syncBranchId === branchId || cb.branch_id === branchId);
      }
      if (nodeId && nodeId !== 'all') {
        sales = sales.filter(s => s.syncNodeId === nodeId);
        cashboxSessions = cashboxSessions.filter(cb => cb.syncNodeId === nodeId);
      }

      return res.json({ success: true, sales, cashboxSessions });
    }
    res.json({ success: true, sales: [], cashboxSessions: [] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/status ───────────────────────────────────────────
// Info endpoint - actual printing is done via browser window.print()
app.get('/api/status', (req, res) => {
  res.json({
    status: 'running',
    platform: os.platform(),
    version: '1.0.0',
    port: PORT
  });
});
// ── GET /api/download-sample ─────────────────────────────────────
app.get('/api/download-sample', (req, res) => {
  try {
    const headers = [
      {
        'Item Code': 'ITM-00001',
        'Barcode': '6901234567890',
        'Name English': 'Single Pen',
        'Name Arabic': 'قلم فردي',
        'Category Name': 'Stationery',
        'Brand': 'Pilot',
        'Cost Price': 0.50,
        'Profit %': 100.0,
        'Selling Price': 1.00,
        'Stock Qty': 100,
        'Min Qty (Reorder)': 10,
        'Selling Unit (piece/box)': 'piece',
        'Pieces per Box': 1,
        'Linked Item Code': ''
      },
      {
        'Item Code': 'ITM-00002',
        'Barcode': '6901234567891',
        'Name English': 'Box of 12 Pens',
        'Name Arabic': 'علبة 12 قلم',
        'Category Name': 'Stationery',
        'Brand': 'Pilot',
        'Cost Price': 5.00,
        'Profit %': 100.0,
        'Selling Price': 10.00,
        'Stock Qty': 10,
        'Min Qty (Reorder)': 2,
        'Selling Unit (piece/box)': 'box',
        'Pieces per Box': 12,
        'Linked Item Code': 'ITM-00001'
      }
    ];

    const ws = XLSX.utils.json_to_sheet(headers);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Items Template");

    const buf = XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="items_import_template.xlsx"');
    res.status(200).send(buf);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Cloud Software Update (OTA) API ─────────────────────────────
app.get('/api/system/version', (req, res) => {
  try {
    const vPath = path.join(__dirname, 'version.json');
    if (fs.existsSync(vPath)) {
      return res.json(JSON.parse(fs.readFileSync(vPath, 'utf8')));
    }
    res.json({ name: 'Red Shark POS', version: '1.2.31', build: 47 });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/system/check-cloud-update', async (req, res) => {
  try {
    const currentVerFile = path.join(__dirname, 'version.json');
    let localVer = { version: '1.2.31', build: 47 };
    if (fs.existsSync(currentVerFile)) {
      try { localVer = JSON.parse(fs.readFileSync(currentVerFile, 'utf8')); } catch(e){}
    }

    const manifestUrl = req.body?.manifestUrl || 'https://shop.redshark-ai.com/version.json';
    const https = require('https');
    const http = require('http');
    const client = manifestUrl.startsWith('https') ? https : http;

    client.get(manifestUrl, { timeout: 8000 }, (manifestRes) => {
      if (manifestRes.statusCode < 200 || manifestRes.statusCode >= 300) {
        return res.json({
          hasUpdate: false,
          currentVersion: localVer.version,
          currentBuild: localVer.build,
          message: `Cloud server returned status ${manifestRes.statusCode}`
        });
      }
      let rawData = '';
      manifestRes.on('data', chunk => rawData += chunk);
      manifestRes.on('end', () => {
        try {
          const cloudVer = JSON.parse(rawData);
          const hasUpdate = (cloudVer.build > (localVer.build || 0)) || 
                            (cloudVer.version && cloudVer.version !== localVer.version);
          return res.json({
            success: true,
            hasUpdate: !!hasUpdate,
            currentVersion: localVer.version,
            currentBuild: localVer.build,
            latestVersion: cloudVer.version || localVer.version,
            latestBuild: cloudVer.build || localVer.build,
            releaseDate: cloudVer.releaseDate || 'Latest',
            releaseNotes: cloudVer.releaseNotes || cloudVer.description || 'New improvements & performance fixes',
            downloadUrl: cloudVer.downloadUrl || ''
          });
        } catch (parseErr) {
          return res.json({ success: false, hasUpdate: false, currentVersion: localVer.version, message: 'Invalid manifest format' });
        }
      });
    }).on('error', (err) => {
      res.json({
        success: false,
        hasUpdate: false,
        currentVersion: localVer.version,
        currentBuild: localVer.build,
        message: 'Could not connect to update cloud server'
      });
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── SPA fallback for Local Desktop POS ─────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'index.html'));
});

// ── Start HTTP Server ───────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ Red Shark POS Server running at: http://localhost:${PORT}`);
  console.log(`   Open the app at:           http://localhost:${PORT}/login.html`);
  console.log(`   Printers API:              http://localhost:${PORT}/api/printers\n`);
  try { ensurePrintWorker(); } catch (e) {}
});

// ── HTTPS Server for Mobile Camera & Secure Context ────────────
async function startHttpsServer() {
  const HTTPS_PORT = process.env.HTTPS_PORT || 3443;
  try {
    const selfsigned = require('selfsigned');
    const https = require('https');
    const certCachePath = path.join(__dirname, 'data', 'server_cert.json');
    let certData = null;
    if (fs.existsSync(certCachePath)) {
      try {
        certData = JSON.parse(fs.readFileSync(certCachePath, 'utf8'));
      } catch (e) {}
    }
    if (!certData || !certData.cert || !certData.private || typeof certData.cert !== 'string') {
      const nets = os.networkInterfaces();
      const altNames = [
        { type: 2, value: 'localhost' },
        { type: 7, ip: '127.0.0.1' }
      ];
      for (const name of Object.keys(nets)) {
        for (const net of (nets[name] || [])) {
          if (net.family === 'IPv4' && !net.internal) {
            altNames.push({ type: 7, ip: net.address });
          }
        }
      }
      const primaryIp = altNames.find(a => a.type === 7 && a.ip !== '127.0.0.1')?.ip || '127.0.0.1';
      const attrs = [{ name: 'commonName', value: primaryIp }];
      const extensions = [{
        name: 'subjectAltName',
        altNames
      }];
      const pems = await selfsigned.generate(attrs, { days: 3650, keySize: 2048, extensions });
      certData = { cert: pems.cert, private: pems.private };
      try {
        if (!fs.existsSync(path.join(__dirname, 'data'))) {
          fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
        }
        fs.writeFileSync(certCachePath, JSON.stringify(certData, null, 2), 'utf8');
      } catch (e) {}
    }
    const httpsServer = https.createServer({ cert: certData.cert, key: certData.private }, app);
    httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
      console.log(`🔒 Red Shark HTTPS Secure Server running at: https://0.0.0.0:${HTTPS_PORT}`);
    });
  } catch (err) {
    console.warn('HTTPS server setup failed:', err.message);
  }
}
startHttpsServer();

// ── Background Cloud Sync Engine (Auto-sync sales to Supabase) ────────
const CLOUD_SYNC_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
const CLOUD_SYNC_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";
let _cachedShopUuid = null;
let _cachedSlug = null;

async function resolveCloudShopId(slug) {
  if (!slug) slug = 'shop101';
  if (slug === 'shop101') return 'a1000000-0000-0000-0000-000000000101';
  if (_cachedSlug === slug && _cachedShopUuid) return _cachedShopUuid;
  try {
    const r = await fetch(`${CLOUD_SYNC_URL}/rest/v1/tenants?slug=eq.${encodeURIComponent(slug)}&select=id`, {
      headers: { "apikey": CLOUD_SYNC_KEY, "Authorization": "Bearer " + CLOUD_SYNC_KEY }
    });
    if (r.ok) {
      const rows = await r.json();
      if (rows && rows[0]) {
        _cachedSlug = slug;
        _cachedShopUuid = rows[0].id;
        return _cachedShopUuid;
      }
    }
  } catch(e) {}
  return 'a1000000-0000-0000-0000-000000000101';
}

async function autoSyncSalesToCloud() {
  try {
    const db = readDb();
    const sales = db['sales'] || [];
    if (!sales.length) return;

    const settings = db['settings'] || [];
    const slugSetting = settings.find(s => s.key === 'online_store_shop_slug');
    const slug = slugSetting ? slugSetting.value : 'shop101';
    const activeShopId = await resolveCloudShopId(slug);

    // Fetch existing order refs from Supabase
    const res = await fetch(`${CLOUD_SYNC_URL}/rest/v1/orders?shop_id=eq.${activeShopId}&select=order_number`, {
      headers: { "apikey": CLOUD_SYNC_KEY, "Authorization": "Bearer " + CLOUD_SYNC_KEY }
    });
    if (!res.ok) return;
    const existing = await res.json();
    const existingRefs = new Set((existing || []).map(o => o.order_number));

    const missingSales = sales.filter(s => s.ref && !existingRefs.has(s.ref));
    if (!missingSales.length) return;

    console.log(`[CloudSync] Auto-syncing ${missingSales.length} new POS sales to Supabase...`);
    const formatted = missingSales.slice(-25).map(s => {
      let items = [];
      try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
      let cost = 0;
      items.forEach(it => { cost += (parseFloat(it.cost_price || 0) * (parseFloat(it.qty) || 1)); });
      const total = parseFloat(s.grand_total) || 0;

      return {
        shop_id: activeShopId,
        order_number: s.ref,
        customer_name: s.customer_name || 'عميل عابر',
        customer_phone: s.customer_phone || '',
        delivery_address: s.branch_id || 'main',
        subtotal: parseFloat(s.subtotal || s.grand_total) || 0,
        total: total,
        currency_code: 'USD',
        payment_method: s.payment_method || 'cash',
        payment_status: 'paid',
        order_status: 'completed',
        items: items.map(it => ({
          product_name: it.name_ar || it.name_en || 'Product',
          quantity: parseFloat(it.qty) || 1,
          unit_price: parseFloat(it.price) || 0,
          total_price: parseFloat(it.total) || 0,
          cost_price: parseFloat(it.cost_price) || 0
        })),
        pos_synced: true,
        pos_invoice_ref: s.ref,
        notes: JSON.stringify({
          source: 'pos',
          branch_id: s.branch_id || 'main',
          terminal_id: s.terminal_id || 'POS-1',
          cashier: s.cashier || s.salesperson_name || 'Administrator',
          cost: cost,
          profit: total - cost
        }),
        created_at: s.created_at,
        updated_at: s.updated_at || s.created_at
      };
    });

    await fetch(`${CLOUD_SYNC_URL}/rest/v1/orders`, {
      method: 'POST',
      headers: {
        "apikey": CLOUD_SYNC_KEY,
        "Authorization": "Bearer " + CLOUD_SYNC_KEY,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(formatted)
    });
    console.log(`[CloudSync] Successfully pushed ${formatted.length} sales to Cloud.`);
    try {
      const dbUpdate = readDb();
      if (!dbUpdate.settings) dbUpdate.settings = [];
      const now = new Date().toISOString();
      const sIdx = dbUpdate.settings.findIndex(s => s.key === 'last_cloud_sync_time');
      if (sIdx !== -1) dbUpdate.settings[sIdx].value = now;
      else dbUpdate.settings.push({ key: 'last_cloud_sync_time', value: now });
      writeDb(dbUpdate);
    } catch(err) {}
  } catch(e) {}
}

setInterval(autoSyncSalesToCloud, 6000);
setTimeout(autoSyncSalesToCloud, 1500);

// ── Background Cloud Items Sync Engine (Watches items.json & pushes to Supabase) ──
let _lastItemsSyncMtime = Date.now();
let _isSyncingItems = false;

async function autoSyncItemsToCloud() {
  if (_isSyncingItems) return;
  try {
    const itemsFile = path.join(TABLES_DIR, 'items.json');
    if (!fs.existsSync(itemsFile)) return;
    const stat = fs.statSync(itemsFile);
    if (stat.mtimeMs <= _lastItemsSyncMtime) return;

    _isSyncingItems = true;
    const checkTime = _lastItemsSyncMtime;
    _lastItemsSyncMtime = stat.mtimeMs;

    const items = JSON.parse(fs.readFileSync(itemsFile, 'utf8'));
    if (!Array.isArray(items) || !items.length) {
      _isSyncingItems = false;
      return;
    }

    const activeShopId = await resolveCloudShopId('shop101');

    // Filter items updated since the last check
    const itemsToPush = items.filter(i => {
      if (!i.updated_at) return false;
      const d = new Date(i.updated_at).getTime();
      return d >= (checkTime - 10000); // modified within recent window
    });

    if (!itemsToPush.length) {
      _isSyncingItems = false;
      return;
    }

    console.log(`[CloudSync] Auto-syncing ${itemsToPush.length} modified items to Supabase...`);

    const payload = itemsToPush.slice(0, 50).map(it => ({
      shop_id: activeShopId,
      pos_product_id: String(it.id),
      name: it.name_en || it.name_ar || 'Product',
      name_ar: it.name_ar || '',
      name_en: it.name_en || '',
      description: it.item_code ? ('CODE:' + it.item_code) : (it.description || ''),
      barcode: it.barcode || null,
      price: parseFloat(it.online_price) || parseFloat(it.selling_price) || parseFloat(it.price) || 0,
      cost_price: parseFloat(it.cost_price) || 0,
      stock_quantity: Math.max(0, parseInt(it.stock_qty) || 0),
      track_inventory: true,
      is_published: (typeof it.show_online !== 'undefined') ? Boolean(it.show_online) : true,
      image_url: it.image_url || it.image || null,
      updated_at: it.updated_at || new Date().toISOString()
    }));

    await fetch(`${CLOUD_SYNC_URL}/rest/v1/products?on_conflict=shop_id,pos_product_id`, {
      method: 'POST',
      headers: {
        "apikey": CLOUD_SYNC_KEY,
        "Authorization": "Bearer " + CLOUD_SYNC_KEY,
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates"
      },
      body: JSON.stringify(payload)
    });

    console.log(`[CloudSync] Successfully pushed ${payload.length} updated item(s) to Supabase.`);
  } catch(err) {
    console.warn('[CloudSync] autoSyncItemsToCloud error:', err.message);
  } finally {
    _isSyncingItems = false;
  }
}

setInterval(autoSyncItemsToCloud, 5000);
setTimeout(autoSyncItemsToCloud, 2000);


