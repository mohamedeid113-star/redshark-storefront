@echo off
title Red Shark POS - Direct Printing Launcher
set APP_DIR=%~dp0
cd /d "%APP_DIR%"

set "TARGET_URL=%~1"
if "%TARGET_URL%"=="" set "TARGET_URL=http://localhost:3000/login.html"

:: If target is localhost, ensure backend server is running
if "%TARGET_URL:~0,16%"=="http://localhost" (
  powershell -NoProfile -Command "if (-not (Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue)) { Start-Process 'node.exe' -ArgumentList 'server.js' -WorkingDirectory '%APP_DIR%' -WindowStyle Hidden }" 2>nul
)

:: Find Chrome or Edge for Kiosk Direct Printing (No Preview Dialog)
set BROWSER_EXE=""
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" set BROWSER_EXE="C:\Program Files\Google\Chrome\Application\chrome.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" set BROWSER_EXE="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set BROWSER_EXE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" set BROWSER_EXE="C:\Program Files\Microsoft\Edge\Application\msedge.exe"

set PROFILE_DIR=%LOCALAPPDATA%\RedSharkPOS\BrowserPOS
if not exist "%PROFILE_DIR%" mkdir "%PROFILE_DIR%"

if not %BROWSER_EXE%=="" (
  start "" %BROWSER_EXE% --kiosk-printing --user-data-dir="%PROFILE_DIR%" --app="%TARGET_URL%"
) else (
  start "" "%TARGET_URL%"
)
exit
