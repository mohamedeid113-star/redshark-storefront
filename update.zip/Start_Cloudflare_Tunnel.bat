@echo off
setlocal EnableDelayedExpansion
title Red Shark POS - Cloudflare Multi-Branch Tunnel
cd /d "%~dp0"
color 0B

echo ================================================================
echo           RED SHARK POS - CLOUDFLARE MULTI-BRANCH TUNNEL
echo ================================================================
echo.
echo  This tool exposes your Central POS Server securely to the
echo  internet so other branches or mobile stations can connect
echo  without requiring a public static IP or router port-forwarding.
echo.
echo ================================================================
echo.

set "CLOUDFLARED_BIN=%~dp0bin\cloudflared.exe"
if not exist "%CLOUDFLARED_BIN%" (
    echo [ERROR] cloudflared.exe not found at: "%CLOUDFLARED_BIN%"
    echo Please make sure the bin folder contains cloudflared.exe.
    echo.
    pause
    exit /b 1
)

echo Checking POS Server status...
powershell -NoProfile -Command "$conn = Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue; if ($conn) { exit 0 } else { exit 1 }"
if %ERRORLEVEL% NEQ 0 (
    echo [NOTICE] POS Server on port 3000 is not currently running.
    echo Launching Red Shark POS backend server in background...
    start "" /b powershell -NoProfile -Command "Start-Process 'node.exe' -ArgumentList 'server.js' -WorkingDirectory '%~dp0' -WindowStyle Hidden"
    timeout /t 3 >nul
)

echo [OK] POS Server is active on http://127.0.0.1:3000.
echo.
echo ----------------------------------------------------------------
echo Choose Tunnel Mode:
echo ----------------------------------------------------------------
echo  [1] Quick Free Tunnel (Instant, No Account Needed, trycloudflare.com)
echo  [2] Persistent Named Tunnel via Cloudflare Token (Permanent Custom Domain)
echo  [3] Exit
echo ----------------------------------------------------------------
set "CHOICE=1"
set /p "CHOICE=Enter choice [1, 2, or 3] (Default 1): "

if "%CHOICE%"=="1" goto QUICK_TUNNEL
if "%CHOICE%"=="2" goto TOKEN_TUNNEL
if "%CHOICE%"=="3" exit /b 0

:QUICK_TUNNEL
echo.
echo ================================================================
echo Starting Cloudflare Quick Tunnel...
echo ================================================================
echo  * Look for the link ending in: .trycloudflare.com below.
echo  * Copy that URL and paste it on your other branch machines under:
echo    Settings -^> Multi-POS ^& Branch Sync -^> Main Server IP / URL.
echo.
echo Keep this window OPEN on the server machine.
echo (Press Ctrl+C in this window if you want to stop the tunnel)
echo ================================================================
echo.
"%CLOUDFLARED_BIN%" tunnel --url http://127.0.0.1:3000
echo.
echo Tunnel closed.
pause
exit /b 0

:TOKEN_TUNNEL
echo.
set "TOKEN_FILE=%~dp0cloudflare_token.txt"
set "TOKEN="

if exist "%TOKEN_FILE%" (
    set /p "TOKEN="<"%TOKEN_FILE%"
)

if "%TOKEN%"=="" (
    echo Please paste your Cloudflare Tunnel Token below:
    set /p "TOKEN=Token: "
) else (
    echo Found saved tunnel token in cloudflare_token.txt.
    echo To change it, edit or delete cloudflare_token.txt.
)

if "%TOKEN%"=="" (
    echo [ERROR] No token entered.
    pause
    exit /b 1
)

echo %TOKEN%> "%TOKEN_FILE%"

echo.
echo ================================================================
echo Starting Cloudflare Named Tunnel with Token...
echo ================================================================
echo Keep this window OPEN on the server machine.
echo.
"%CLOUDFLARED_BIN%" tunnel run --token %TOKEN%
echo.
echo Tunnel closed.
pause
exit /b 0
