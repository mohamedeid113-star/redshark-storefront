@echo off
title Red Shark POS Setup
color 0B

echo ========================================================
echo       RED SHARK POS - SYSTEM INSTALLER & AUTO-BOOT
echo ========================================================
echo.

set APP_DIR=%~dp0
set APP_DIR=%APP_DIR:~0,-1%
set VBS_LAUNCHER=%APP_DIR%\Launch_Silent.vbs
set VBS_SERVER=%APP_DIR%\Launch_Silent_ServerOnly.vbs
set DESKTOP_DIR=%USERPROFILE%\Desktop
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

:: 1. Check Node.js Runtime
if exist "%APP_DIR%\bin\node.exe" (
  echo [] Portable Node.js Runtime Engine detected in bin\
) else (
  where node >nul 2>nul
  if %errorlevel% neq 0 (
    echo [!] Node.js not detected. Downloading portable runtime...
    powershell -Command "New-Item -ItemType Directory -Force -Path '%APP_DIR%\bin'; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v20.11.1/win-x64/node.exe' -OutFile '%APP_DIR%\bin\node.exe'" >nul 2>nul
  )
)

echo [1/3] Creating Silent Launcher Scripts...
(
  echo Set WshShell = CreateObject^("WScript.Shell"^)
  echo Set FSO = CreateObject^("Scripting.FileSystemObject"^)
  echo appDir = "%APP_DIR%"
  echo WshShell.CurrentDirectory = appDir
  echo nodeCmd = "node"
  echo If FSO.FileExists^(appDir ^& "\bin\node.exe"^) Then
  echo   nodeCmd = """" ^& appDir ^& "\bin\node.exe"""
  echo End If
  echo WshShell.Run "cmd /c " ^& nodeCmd ^& " server.js", 0, False
  echo WScript.Sleep 1800
  echo browserExe = ""
  echo If FSO.FileExists^("C:\Program Files\Google\Chrome\Application\chrome.exe"^) Then
  echo   browserExe = "C:\Program Files\Google\Chrome\Application\chrome.exe"
  echo ElseIf FSO.FileExists^("C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"^) Then
  echo   browserExe = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
  echo ElseIf FSO.FileExists^("C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"^) Then
  echo   browserExe = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
  echo ElseIf FSO.FileExists^("C:\Program Files\Microsoft\Edge\Application\msedge.exe"^) Then
  echo   browserExe = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
  echo End If
  echo localAppData = WshShell.ExpandEnvironmentStrings^("%LOCALAPPDATA%"^)
  echo profileDir = localAppData ^& "\RedSharkPOS\BrowserPOS"
  echo If browserExe ^<^> "" Then
  echo   WshShell.Run """" ^& browserExe ^& """ --kiosk-printing --user-data-dir=""" ^& profileDir ^& """ --app=""http://localhost:3000/login.html""", 1, False
  echo Else
  echo   WshShell.Run "http://localhost:3000/login.html", 1, False
  echo End If
) > "%VBS_LAUNCHER%"

(
  echo Set WshShell = CreateObject^("WScript.Shell"^)
  echo Set FSO = CreateObject^("Scripting.FileSystemObject"^)
  echo appDir = "%APP_DIR%"
  echo WshShell.CurrentDirectory = appDir
  echo nodeCmd = "node"
  echo If FSO.FileExists^(appDir ^& "\bin\node.exe"^) Then
  echo   nodeCmd = """" ^& appDir ^& "\bin\node.exe"""
  echo End If
  echo WshShell.Run "cmd /c " ^& nodeCmd ^& " server.js", 0, False
) > "%VBS_SERVER%"

echo [2/3] Creating Desktop Shortcut with Red Shark Icon...
(
  echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
  echo sLinkFile = "%DESKTOP_DIR%\Red Shark POS.lnk"
  echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
  echo oLink.TargetPath = "wscript.exe"
  echo oLink.Arguments = """%VBS_LAUNCHER%"""
  echo oLink.WorkingDirectory = "%APP_DIR%"
  echo oLink.Description = "Red Shark POS Enterprise Suite"
  echo oLink.IconLocation = "%APP_DIR%\assets\RedSharkPOS.ico,0"
  echo oLink.Save
) > "%TEMP%\create_desktop_shortcut.vbs"
cscript //nologo "%TEMP%\create_desktop_shortcut.vbs"
del "%TEMP%\create_desktop_shortcut.vbs"

echo [3/3] Setting up Windows Auto-Start on Boot...
(
  echo Set oWS = WScript.CreateObject^("WScript.Shell"^)
  echo sLinkFile = "%STARTUP_DIR%\RedSharkPOS_Background_Server.lnk"
  echo Set oLink = oWS.CreateShortcut^(sLinkFile^)
  echo oLink.TargetPath = "wscript.exe"
  echo oLink.Arguments = """%VBS_SERVER%"""
  echo oLink.WorkingDirectory = "%APP_DIR%"
  echo oLink.Description = "Red Shark POS Background Server"
  echo oLink.IconLocation = "%APP_DIR%\assets\RedSharkPOS.ico,0"
  echo oLink.Save
) > "%TEMP%\create_startup_shortcut.vbs"
cscript //nologo "%TEMP%\create_startup_shortcut.vbs"
del "%TEMP%\create_startup_shortcut.vbs"

echo.
echo [Starting Application Now...]
start "" wscript.exe "%VBS_LAUNCHER%"

echo ========================================================
echo  [SUCCESS] Setup Completed!
echo   - Portable Server Engine Configured
echo   - Desktop Shortcut Created with Red Shark Icon
echo   - Server Auto-Start Registered in Windows
echo   - POS App Launched at http://localhost:3000
echo ========================================================
echo.
pause
