@echo off
title Red Shark POS - Customer Software Safe Updater
cd /d "%~dp0"

echo ================================================================
echo           RED SHARK POS - CUSTOMER SAFE UPDATER
echo ================================================================
echo.
echo Launching Update Assistant...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update_Customer_Software.ps1"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo An error occurred during the update process.
    pause
)
