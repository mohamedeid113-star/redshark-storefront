@echo off
setlocal EnableDelayedExpansion
title Red Shark POS - Install Cloudflare Permanent Windows Service
cd /d "%~dp0"
color 0B

echo ================================================================
echo    RED SHARK POS - PERMANENT CLOUDFLARE WINDOWS SERVICE SETUP
echo ================================================================
echo.

:: 1. Check for Administrator Privileges
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [REQUESTING ADMINISTRATOR PRIVILEGES]
    echo Windows Services require Administrator permissions to install.
    echo Prompting for elevation now...
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b 0
)

:: 2. Locate cloudflared.exe
set "CLOUDFLARED_BIN=%~dp0bin\cloudflared.exe"
if not exist "%CLOUDFLARED_BIN%" (
    if exist "C:\Windows\System32\cloudflared.exe" (
        set "CLOUDFLARED_BIN=C:\Windows\System32\cloudflared.exe"
    ) else (
        echo [ERROR] cloudflared.exe was not found in: "%CLOUDFLARED_BIN%"
        echo Please ensure bin\cloudflared.exe is present.
        pause
        exit /b 1
    )
)

:: 3. Copy cloudflared.exe to System32 so "cloudflared" works anywhere
echo [1/5] Registering cloudflared globally in Windows System32...
copy /y "%CLOUDFLARED_BIN%" "C:\Windows\System32\cloudflared.exe" >nul 2>&1
if exist "C:\Windows\System32\cloudflared.exe" (
    echo [OK] cloudflared is now available from ANY Command Prompt!
) else (
    echo [NOTE] Could not copy to System32 directly, using local bin path.
)

:: 4. Get Tunnel Token
:PROMPT_TOKEN
echo.
echo [2/5] Checking Tunnel Token...
set "TOKEN_FILE=%~dp0cloudflare_token.txt"
set "TOKEN="

if exist "%TOKEN_FILE%" (
    set /p "TOKEN="<"%TOKEN_FILE%"
    :: Check if the saved token is valid base64
    powershell -NoProfile -Command "try { [Convert]::FromBase64String('%TOKEN%'); exit 0 } catch { exit 1 }" >nul 2>&1
    if !ERRORLEVEL! NEQ 0 (
        echo [WARNING] The saved token in cloudflare_token.txt is invalid or corrupted.
        del /f /q "%TOKEN_FILE%" >nul 2>&1
        set "TOKEN="
    )
)

if "%TOKEN%"=="" (
    echo.
    echo How to get your Token from Cloudflare:
    echo  1. In Cloudflare Dashboard, go to your Tunnel (Redsharktest).
    echo  2. Click 'Rotate token' or go to 'Install connector' -^> Windows.
    echo  3. Copy the token (or copy the entire 'cloudflared.exe service install ...' command).
    echo.
    set /p "USER_INPUT=Paste Token or Command here: "
    
    :: Clean up input in case user pasted the whole command
    set "TOKEN=!USER_INPUT!"
    set "TOKEN=!TOKEN:cloudflared.exe=!"
    set "TOKEN=!TOKEN:cloudflared=!"
    set "TOKEN=!TOKEN:service=!"
    set "TOKEN=!TOKEN:install=!"
    set "TOKEN=!TOKEN:"=!"
    set "TOKEN=!TOKEN: =!"
)

if "%TOKEN%"=="" (
    echo [ERROR] No token entered.
    pause
    goto PROMPT_TOKEN
)

:: Validate base64 format
powershell -NoProfile -Command "try { [Convert]::FromBase64String('%TOKEN%'); exit 0 } catch { exit 1 }" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] The token you pasted is NOT a valid Cloudflare Token.
    echo Make sure you copy the token directly from the Cloudflare Dashboard.
    echo (Do not type it by hand; click the Copy button in Cloudflare).
    echo.
    del /f /q "%TOKEN_FILE%" >nul 2>&1
    pause
    goto PROMPT_TOKEN
)

:: Save clean validated token
echo %TOKEN%> "%TOKEN_FILE%"
echo [OK] Valid Cloudflare token confirmed.

:: 5. Configure System-wide HTTP/2 Protocol (Prevents timeout/packet drops)
echo.
echo [3/5] Configuring Protocol to HTTP/2...
setx TUNNEL_TRANSPORT_PROTOCOL http2 /M >nul 2>&1
echo [OK] TUNNEL_TRANSPORT_PROTOCOL set to http2 system-wide.

:: 6. Clean up any existing service
echo.
echo [4/5] Installing Permanent Windows Service...
sc stop cloudflared >nul 2>&1
timeout /t 1 >nul
"%CLOUDFLARED_BIN%" service uninstall >nul 2>&1
timeout /t 1 >nul

:: Install fresh service with token
"%CLOUDFLARED_BIN%" service install %TOKEN%
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install cloudflared service.
    pause
    exit /b 1
)

:: 7. Start the Service
echo.
echo [5/5] Starting cloudflared Service...
sc start cloudflared >nul 2>&1
timeout /t 3 >nul

sc query cloudflared | findstr /i "STATE"
echo.
echo ================================================================
echo       SUCCESS! CLOUDFLARE SERVICE IS PERMANENTLY INSTALLED
echo ================================================================
echo  * The tunnel is now running as a background Windows Service.
echo  * It will START AUTOMATICALLY whenever the computer powers on.
echo  * You do NOT need to keep any CMD window open!
echo  * Check your Cloudflare Dashboard - Status will be HEALTHY.
echo ================================================================
echo.
pause
exit /b 0
