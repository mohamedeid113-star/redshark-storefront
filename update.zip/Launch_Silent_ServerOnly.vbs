Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")
appDir = "D:\GravityProject\POSSoftware"
WshShell.CurrentDirectory = appDir
nodeCmd = "node"
If FSO.FileExists(appDir & "\bin\node.exe") Then
  nodeCmd = """" & appDir & "\bin\node.exe"""
End If
WshShell.Run "cmd /c " & nodeCmd & " server.js", 0, False
