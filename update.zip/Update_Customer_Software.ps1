# ==============================================================================
# Red Shark POS - Customer Software Safe Updater
# Upgrades application code & assets without affecting customer database or work.
# ==============================================================================

[CmdletBinding()]
param (
    [string]$ReleaseSourcePath = "",
    [string]$TargetPOSPath = ""
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

function Show-Header {
    Clear-Host
    Write-Host "=================================================================" -ForegroundColor Cyan
    Write-Host "         RED SHARK POS - CUSTOMER SOFTWARE SAFE UPDATER          " -ForegroundColor Yellow
    Write-Host "=================================================================" -ForegroundColor Cyan
    Write-Host "  This tool safely updates the POS software to a new release.    " -ForegroundColor White
    Write-Host "  * All sales data, items, customers, settings are PRESERVED.    " -ForegroundColor Green
    Write-Host "  * Automatic safety backup is created before updating.          " -ForegroundColor Green
    Write-Host "=================================================================`n" -ForegroundColor Cyan
}

function Select-Folder-Dialog([string]$title, [string]$initialPath = "") {
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = $title
    $dialog.ShowNewFolderButton = $false
    if ($initialPath -and (Test-Path $initialPath)) {
        $dialog.SelectedPath = $initialPath
    }
    
    $result = $dialog.ShowDialog((New-Object System.Windows.Forms.Form -Property @{TopMost = $true}))
    if ($result -eq [System.Windows.Forms.DialogResult]::OK -and $dialog.SelectedPath) {
        return $dialog.SelectedPath
    }
    return $null
}

Show-Header

# 1. Determine Target POS Installation Directory (Customer folder)
$currentScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Check if current directory looks like customer POS
$isCurrentPOS = (Test-Path (Join-Path $currentScriptDir "server.js")) -or (Test-Path (Join-Path $currentScriptDir "index.html"))

if (-not $TargetPOSPath) {
    if ($isCurrentPOS) {
        $TargetPOSPath = $currentScriptDir
        Write-Host "Detected POS Installation Folder: " -NoNewline -ForegroundColor White
        Write-Host "$TargetPOSPath" -ForegroundColor Green
    } else {
        Write-Host "Please select the Customer POS Installation folder to update..." -ForegroundColor Yellow
        $TargetPOSPath = Select-Folder-Dialog "Select Customer POS Installation Folder (e.g. C:\RedSharkPOS)"
        if (-not $TargetPOSPath) {
            Write-Host "`n[CANCELLED] No target installation directory selected. Exiting." -ForegroundColor Red
            Read-Host "Press Enter to exit..."
            exit 1
        }
    }
}

# 2. Select the Release Folder (Source of new files)
if (-not $ReleaseSourcePath) {
    Write-Host "`nOpening Folder Picker: Please select the New Release / Update Folder..." -ForegroundColor Yellow
    $ReleaseSourcePath = Select-Folder-Dialog "Select the New Release Folder (Folder containing updated Red Shark POS files)" $currentScriptDir
    
    if (-not $ReleaseSourcePath) {
        Write-Host "`n[CANCELLED] No release folder selected. Exiting." -ForegroundColor Red
        Read-Host "Press Enter to exit..."
        exit 1
    }
}

# Validate Release Folder
if (-not (Test-Path $ReleaseSourcePath)) {
    Write-Host "`n[ERROR] Release folder does not exist: $ReleaseSourcePath" -ForegroundColor Red
    Read-Host "Press Enter to exit..."
    exit 1
}

# Verify release folder has core files
$hasIndex = Test-Path (Join-Path $ReleaseSourcePath "index.html")
$hasServer = Test-Path (Join-Path $ReleaseSourcePath "server.js")
$hasJs = Test-Path (Join-Path $ReleaseSourcePath "js")

if (-not ($hasIndex -or $hasServer -or $hasJs)) {
    Write-Host "`n[WARNING] The selected folder does not appear to contain Red Shark POS release files." -ForegroundColor Yellow
    Write-Host "Selected: $ReleaseSourcePath" -ForegroundColor White
    $confirm = Read-Host "Do you still want to proceed? (Y/N)"
    if ($confirm -ne 'Y' -and $confirm -ne 'y') {
        Write-Host "Update cancelled." -ForegroundColor Red
        Read-Host "Press Enter to exit..."
        exit 1
    }
}

Write-Host "`n-----------------------------------------------------------------" -ForegroundColor Cyan
Write-Host "  Source (Release Folder):  $ReleaseSourcePath" -ForegroundColor White
Write-Host "  Destination (Customer):   $TargetPOSPath" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------`n" -ForegroundColor Cyan

# 3. Create Safety Pre-Update Backup
$timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$backupDir = Join-Path $TargetPOSPath "Backup\PreUpdate_$timestamp"

Write-Host "[1/5] [BACKUP] Creating safety pre-update backup of customer files..." -ForegroundColor Yellow
try {
    if (-not (Test-Path $backupDir)) {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    }
    
    # Backup data folder and key files if they exist
    $dataDir = Join-Path $TargetPOSPath "data"
    if (Test-Path $dataDir) {
        Copy-Item -Path $dataDir -Destination (Join-Path $backupDir "data") -Recurse -Force
    }
    
    $criticalFiles = @("server.js", "index.html", ".env", "package.json")
    foreach ($cf in $criticalFiles) {
        $src = Join-Path $TargetPOSPath $cf
        if (Test-Path $src) {
            Copy-Item -Path $src -Destination $backupDir -Force
        }
    }
    Write-Host "      [OK] Safety backup stored at: $backupDir" -ForegroundColor Green
} catch {
    Write-Host "      [WARN] Notice: Safety backup created with warnings: $_" -ForegroundColor Yellow
}

# 4. Gracefully Stop Running POS Process (to unlock files)
Write-Host "`n[2/5] [PAUSE] Stopping running server processes temporarily to release file locks..." -ForegroundColor Yellow
try {
    # Stop RedSharkPOS.exe or node instances on port 3000 if running
    Get-Process -Name "RedSharkPOS" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    
    # Also find any node process running server.js in target dir
    $netstat = netstat -ano | Select-String ":3000\s+.*LISTENING"
    if ($netstat) {
        $parts = ($netstat -split "\s+") | Where-Object { $_ -ne "" }
        $pidToKill = $parts[-1]
        if ($pidToKill -and $pidToKill -ne "0") {
            Stop-Process -Id $pidToKill -Force -ErrorAction SilentlyContinue
        }
    }
    Start-Sleep -Milliseconds 800
    Write-Host "      [OK] Server paused safely." -ForegroundColor Green
} catch {
    Write-Host "      [OK] Ready." -ForegroundColor Green
}

# 5. Protected Items Blacklist (Items that must NEVER be overwritten from release)
$PROTECTED_PRESERVE = @(
    "data",
    "Backup",
    "temp_edge_profile",
    ".env",
    "scratch"
)

# 6. Copy Release Files to Customer Directory
Write-Host "`n[3/5] [UPDATE] Updating application code, UI modules, and print templates..." -ForegroundColor Yellow

$itemsToCopy = Get-ChildItem -Path $ReleaseSourcePath

$updatedCount = 0
foreach ($item in $itemsToCopy) {
    $itemName = $item.Name
    
    # Skip protected customer data
    if ($PROTECTED_PRESERVE -contains $itemName) {
        Write-Host "      [PRESERVED] Customer data: $itemName" -ForegroundColor Cyan
        continue
    }
    
    # Skip developer generator tools if any exist in release
    if ($itemName -in @("developer_generator.html", "developer_decryptor.html", "license_generator.html", "generate_license.js", ".git", ".agents")) {
        continue
    }
    
    $dest = Join-Path $TargetPOSPath $itemName
    try {
        if ($item.PSIsContainer) {
            Copy-Item -Path $item.FullName -Destination $dest -Recurse -Force
        } else {
            Copy-Item -Path $item.FullName -Destination $dest -Force
        }
        $updatedCount++
    } catch {
        Write-Host "      [WARN] Could not update $itemName : $_" -ForegroundColor DarkYellow
    }
}

Write-Host "      [OK] Successfully updated $updatedCount modules and files!" -ForegroundColor Green

# 7. Restart Server & POS
Write-Host "`n[4/5] [RESTART] Relaunching Red Shark POS Server..." -ForegroundColor Yellow
$launcherExe = Join-Path $TargetPOSPath "RedSharkPOS.exe"
$launcherBat = Join-Path $TargetPOSPath "Start_RedSharkPOS.bat"
$serverJs = Join-Path $TargetPOSPath "server.js"

if (Test-Path $launcherExe) {
    Start-Process -FilePath $launcherExe -WorkingDirectory $TargetPOSPath
} elseif (Test-Path $serverJs) {
    Start-Process -FilePath "node" -ArgumentList "server.js" -WorkingDirectory $TargetPOSPath -WindowStyle Hidden
}

Start-Sleep -Seconds 1

# 8. Success Report
Write-Host "`n[5/5] [DONE] Complete!" -ForegroundColor Green
Write-Host "`n=================================================================" -ForegroundColor Green
Write-Host "  *** UPDATE COMPLETED SUCCESSFULLY! ***                         " -ForegroundColor Yellow
Write-Host "=================================================================" -ForegroundColor Green
Write-Host "  * All new features, print designs & fixes are now ACTIVE.      " -ForegroundColor White
Write-Host "  * All customer databases, sales & stock are 100% INTACT.       " -ForegroundColor White
Write-Host "  * Safety backup is available in:                               " -ForegroundColor White
Write-Host "    $backupDir                                                   " -ForegroundColor Cyan
Write-Host "=================================================================`n" -ForegroundColor Green

[System.Windows.Forms.MessageBox]::Show(
    "Red Shark POS has been successfully updated!`n`nAll customer data, sales records, and settings were preserved.`n`nThe software is ready for use.",
    "Red Shark POS - Update Successful",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null
