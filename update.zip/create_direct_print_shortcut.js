const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');

const desktopPath = path.join(os.homedir(), 'Desktop');
const shortcutPath = path.join(desktopPath, 'Red Shark POS.lnk');
const iconPath = path.join(__dirname, 'assets', 'RedSharkPOS.ico');

let edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
if (!fs.existsSync(edgePath)) {
  edgePath = 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe';
}

const vbsScript = `
Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "${shortcutPath}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "${edgePath}"
oLink.Arguments = "--kiosk-printing --app=http://localhost:3000/login.html"
oLink.Description = "Red Shark POS Enterprise (Direct Printing)"
oLink.WorkingDirectory = "${__dirname}"
If oWS.ExpandEnvironmentStrings("%SystemDrive%") <> "" Then
  oLink.IconLocation = "${iconPath},0"
End If
oLink.Save
`;

const tempVbs = path.join(os.tmpdir(), 'make_shortcut.vbs');
fs.writeFileSync(tempVbs, vbsScript, 'utf8');
try {
  execSync(`cscript //nologo "${tempVbs}"`);
  console.log('SUCCESS: Desktop Shortcut created at: ' + shortcutPath);
} catch (e) {
  console.error('Failed to create shortcut:', e.message);
} finally {
  try { fs.unlinkSync(tempVbs); } catch(e) {}
}
