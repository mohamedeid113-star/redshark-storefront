@echo off
title Red Shark POS Launcher
set APP_DIR=%~dp0
cd /d "%APP_DIR%"

:: 1. Launch backend server if not running
powershell -NoProfile -Command "if (-not (Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue)) { Start-Process 'node.exe' -ArgumentList 'server.js' -WorkingDirectory '%APP_DIR%' -WindowStyle Hidden }" 2>nul
timeout /t 1 >nul

:: 2. Find Chrome or Edge for Kiosk Direct Printing (No Preview Dialog)
set BROWSER_EXE=""
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" set BROWSER_EXE="C:\Program Files\Google\Chrome\Application\chrome.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" set BROWSER_EXE="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set BROWSER_EXE="C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if %BROWSER_EXE%=="" if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" set BROWSER_EXE="C:\Program Files\Microsoft\Edge\Application\msedge.exe"

set PROFILE_DIR=%LOCALAPPDATA%\RedSharkPOS\BrowserPOS
if not exist "%PROFILE_DIR%" mkdir "%PROFILE_DIR%"

if not %BROWSER_EXE%=="" (
  start "" %BROWSER_EXE% --kiosk-printing --user-data-dir="%PROFILE_DIR%" --app="http://localhost:3000/login.html"
) else (
  start "" "http://localhost:3000/login.html"
)
exit
