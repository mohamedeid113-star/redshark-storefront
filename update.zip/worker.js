export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    
    // Redirect HTTP to HTTPS
    if (url.protocol === 'http:' && !url.hostname.includes('localhost') && !url.hostname.match(/^\d+\.\d+\.\d+\.\d+$/)) {
      url.protocol = 'https:';
      return Response.redirect(url.toString(), 301);
    }
    
    // Route root to index.html
    if (url.pathname === '/' || url.pathname === '') {
      return env.ASSETS.fetch(new Request(new URL('/index.html', request.url), request));
    }

    // Try fetching static asset directly
    const response = await env.ASSETS.fetch(request);
    if (response.status === 404) {
      if (!url.pathname.includes('.')) {
        return env.ASSETS.fetch(new Request(new URL('/index.html', request.url), request));
      }
    }
    return response;
  }
};
