Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")
appDir = "D:\GravityProject\POSSoftware"
WshShell.CurrentDirectory = appDir
nodeCmd = "node"
If FSO.FileExists(appDir & "\bin\node.exe") Then
  nodeCmd = """" & appDir & "\bin\node.exe"""
End If
WshShell.Run "cmd /c " & nodeCmd & " server.js", 0, False
WScript.Sleep 1800
browserExe = ""
If FSO.FileExists("C:\Program Files\Google\Chrome\Application\chrome.exe") Then
  browserExe = "C:\Program Files\Google\Chrome\Application\chrome.exe"
ElseIf FSO.FileExists("C:\Program Files (x86)\Google\Chrome\Application\chrome.exe") Then
  browserExe = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
ElseIf FSO.FileExists("C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe") Then
  browserExe = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
ElseIf FSO.FileExists("C:\Program Files\Microsoft\Edge\Application\msedge.exe") Then
  browserExe = "C:\Program Files\Microsoft\Edge\Application\msedge.exe"
End If
localAppData = WshShell.ExpandEnvironmentStrings("C:\Users\mohamad.eid\AppData\Local")
profileDir = localAppData & "\RedSharkPOS\BrowserPOS"
If browserExe <> "" Then
  WshShell.Run """" & browserExe & """ --kiosk-printing --user-data-dir=""" & profileDir & """ --app=""http://localhost:3000/login.html""", 1, False
Else
  WshShell.Run "http://localhost:3000/login.html", 1, False
End If
