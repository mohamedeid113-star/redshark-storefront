/* ================================================================
   NexPOS — Print Engine Module
   Handles all printing: 80mm receipts, A4 invoices, POs, payslips
   ================================================================ */

const PrintEngine = (() => {

  // ── Company Info ──────────────────────────────────────────────
  async function getCompanyInfo() {
    const keys = [
      'company_name', 'company_name_ar', 'company_address',
      'company_phone', 'company_email', 'vat_number',
      'currency_1', 'currency_2', 'exchange_rate', 'vat_rate', 'vat_enabled',
      'company_logo', 'print_logo',
      'inv_template', 'inv_primary_color', 'inv_font_family', 'inv_font_size',
      'inv_logo_position', 'inv_logo_size', 'inv_header_align', 'inv_custom_subtitle',
      'inv_show_company_name', 'inv_show_phone', 'inv_show_email', 'inv_show_address', 'inv_show_vat',
      'inv_show_customer_info', 'inv_show_salesperson', 'inv_show_item_code', 'inv_show_discount_col',
      'inv_show_dual_currency', 'inv_show_qr', 'inv_show_barcode', 'inv_show_stamp_signature',
      'inv_terms_text', 'inv_footer_note',
      'inv_item_show_brand', 'inv_item_show_model', 'inv_item_show_color',
      'inv_item_show_origin', 'inv_item_show_type', 'inv_item_show_barcode',
      'inv_item_show_weight', 'inv_item_show_size', 'inv_item_show_notes',
      'inv_item_display_mode', 'inv_item_separator', 'inv_receipt_item_layout',
      // Custom Font Sizes per Box
      'inv_fs_company_name', 'inv_fs_subtitle', 'inv_fs_header_contact',
      'inv_fs_doc_title', 'inv_fs_doc_num', 'inv_fs_meta_text',
      'inv_fs_customer_box', 'inv_fs_cashier_box',
      'inv_fs_table_header', 'inv_fs_table_rows', 'inv_fs_item_subline',
      'inv_fs_totals_box', 'inv_fs_grand_total', 'inv_fs_cur2_total',
      'inv_fs_terms', 'inv_fs_signatures', 'inv_fs_footer_note',
      // Custom Fixed Texts / Labels
      'inv_txt_doc_title', 'inv_txt_date_label', 'inv_txt_duedate_label', 'inv_txt_tax_id_label',
      'inv_txt_bill_to_label', 'inv_txt_cashier_label', 'inv_txt_payment_label',
      'inv_txt_col_hash', 'inv_txt_col_item', 'inv_txt_col_sku', 'inv_txt_col_qty',
      'inv_txt_col_price', 'inv_txt_col_disc', 'inv_txt_col_total',
      'inv_txt_subtotal_label', 'inv_txt_discount_label', 'inv_txt_vat_label',
      'inv_txt_grand_total_label', 'inv_txt_cur2_label',
      'inv_txt_terms_label', 'inv_txt_cust_sig_label', 'inv_txt_store_sig_label'
    ];
    const info = {};
    try {
      const allSettings = await DB.getAll('settings');
      const settingsMap = new Map((allSettings || []).map(s => [s.key, s.value]));
      for (const k of keys) {
        info[k] = settingsMap.has(k) ? settingsMap.get(k) : '';
      }
    } catch (e) {
      for (const k of keys) {
        info[k] = await DB.getSetting(k, '');
      }
    }
    return info;
  }

  function resolveCompanyName(co, isAR) {
    if (!isAR) return co.company_name || 'Store';
    const ar = (co.company_name_ar || '').trim();
    if (ar && ar !== 'المتجر' && ar !== 'Store' && ar !== 'Company') {
      return ar;
    }
    return co.company_name || 'Store';
  }

  // ── Open a print window or send to hardware printer ───────────
  async function openPrintWindow(html, title = 'Print Document', pageSize = 'A4') {
    if (typeof Utils !== 'undefined' && typeof Utils.printElement === 'function') {
      await Utils.printElement(html, title, pageSize);
      return;
    }
    const win = window.open('', '_blank', 'width=880,height=920');
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); }, 400);
  }

  // ── Base print styles ─────────────────────────────────────────
  function baseStyles() {
    return `
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body { font-family: 'Segoe UI', 'Cairo', 'Tahoma', 'Arial', sans-serif; color: #111; background: #fff; }
      @media print {
        body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .no-print { display: none !important; }
        @page { margin: 10mm; }
      }
      .print-actions {
        display: flex; gap: 10px; justify-content: center;
        padding: 12px; background: #f5f5f5; border-bottom: 1px solid #ddd;
      }
      .print-actions button {
        padding: 8px 20px; border-radius: 6px; cursor: pointer;
        font-family: inherit; font-size: 13px; font-weight: 600; border: none;
      }
      .btn-print { background: #0055CC; color: white; }
      .btn-close { background: #eee; color: #333; }
    </style>`;
  }

  function isItemTaxable(item) {
    if (!item) return false;
    const vt = String(item.vat_type || '').toLowerCase().trim();
    if (vt === 'none' || vt === 'exempt' || vt === 'zero') return false;
    if (vt === 'standard' || vt === 'taxable' || vt === 'vat') return true;
    if (item.is_taxable === false || item.taxable === false) return false;
    if (item.is_taxable === true || item.taxable === true || item.is_vat_taxable === true) return true;
    if (parseFloat(item.vat_rate) > 0) return true;
    return false;
  }

  // ── Item Details Formatter & DB Enricher ────────────────────────
  async function enrichItemsWithDetails(itemsList) {
    if (!itemsList || !itemsList.length) return [];
    try {
      const itemIds = itemsList.map(i => i.item_id || i.id).filter(Boolean);
      const dbItems = await Promise.all(itemIds.map(id => DB.get('items', id).catch(() => null)));
      const itemMap = new Map();
      dbItems.forEach(di => { if (di && di.id) itemMap.set(di.id, di); });

      return itemsList.map(item => {
        const dbItem = item.item_id ? itemMap.get(item.item_id) : (item.id ? itemMap.get(item.id) : null);
        if (dbItem) {
          const effectiveVatType = item.vat_type || dbItem.vat_type || 'none';
          const effectiveVatRate = item.vat_rate !== undefined ? item.vat_rate : (dbItem.vat_rate || 0);
          const taxable = isItemTaxable({ ...dbItem, ...item, vat_type: effectiveVatType, vat_rate: effectiveVatRate });
          return {
            ...dbItem,
            ...item,
            vat_type: effectiveVatType,
            vat_rate: effectiveVatRate,
            is_taxable: taxable,
            brand: item.brand || dbItem.brand || '',
            model: item.model || dbItem.model || '',
            color: item.color || dbItem.color || '',
            origin_country: item.origin_country || dbItem.origin_country || '',
            origin_country_code: item.origin_country_code || dbItem.origin_country_code || '',
            origin_flag: item.origin_flag || dbItem.origin_flag || '',
            type: item.type || dbItem.type || dbItem.item_type || '',
            barcode: item.barcode || dbItem.barcode || '',
            gross_weight: item.gross_weight || dbItem.gross_weight || '',
            size1: item.size1 || dbItem.size1 || '',
            size2: item.size2 || dbItem.size2 || '',
            notes: item.notes || dbItem.notes || ''
          };
        }
        return {
          ...item,
          is_taxable: isItemTaxable(item)
        };
      });
    } catch (e) {
      return itemsList;
    }
  }

  function formatItemExtraDetails(item, isAR, co) {
    const parts = [];
    if (co.inv_item_show_brand && item.brand) {
      parts.push((isAR ? 'الماركة: ' : 'Brand: ') + item.brand);
    }
    if (co.inv_item_show_model && item.model) {
      parts.push((isAR ? 'الموديل: ' : 'Model: ') + item.model);
    }
    if (co.inv_item_show_color && item.color) {
      parts.push((isAR ? 'اللون: ' : 'Color: ') + item.color);
    }
    if (co.inv_item_show_origin && (item.origin_country || item.origin)) {
      const flag = item.origin_flag ? (item.origin_flag + ' ') : '';
      parts.push((isAR ? 'بلد الصنع: ' : 'Made in: ') + flag + (item.origin_country || item.origin));
    }
    if (co.inv_item_show_type && (item.type || item.item_type)) {
      parts.push((isAR ? 'النوع: ' : 'Type: ') + (item.type || item.item_type));
    }
    if (co.inv_item_show_barcode && item.barcode) {
      parts.push((isAR ? 'الباركود: ' : 'Barcode: ') + item.barcode);
    }
    if (co.inv_item_show_weight && (item.gross_weight || item.weight)) {
      parts.push((isAR ? 'الوزن: ' : 'Weight: ') + (item.gross_weight || item.weight));
    }
    if (co.inv_item_show_size && (item.size1 || item.size)) {
      const sizeStr = item.size1 && item.size2 ? `${item.size1}x${item.size2}cm` : (item.size1 || item.size);
      parts.push((isAR ? 'المقاس: ' : 'Size: ') + sizeStr);
    }
    if (co.inv_item_show_notes && (item.notes || item.description)) {
      parts.push(item.notes || item.description);
    }

    if (!parts.length) return { hasExtra: false, text: '' };

    const separator = co.inv_item_separator || ' - ';
    const text = parts.join(separator);
    const mode = co.inv_item_display_mode || 'subline';
    return { hasExtra: true, text, mode, separator };
  }

  // ═══════════════════════════════════════════════════════════════
  // 80mm / 58mm THERMAL RECEIPT GENERATOR (Single Source of Truth)
  // ═══════════════════════════════════════════════════════════════
  async function generateReceiptHtml(sale, rawItems, customer, options = {}) {
    const co = options.coOverride || await getCompanyInfo();
    const refNo = sale.invoice_no || sale.receipt_no || sale.ref || ('# INV-' + (sale.id || '1'));
    let itemsList = rawItems;
    if (!itemsList || !itemsList.length) {
      itemsList = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (Array.isArray(sale.items) ? sale.items : []);
    }
    const items = await enrichItemsWithDetails(itemsList);
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? (i18n.getLang() === 'ar') : true;
    const date = Utils.formatDateTime(sale.created_at || sale.doc_date || Date.now());

    let custObj = customer;
    if (!custObj && sale.customer_id) {
      try { custObj = await DB.get('customers', sale.customer_id); } catch(e) {}
    }

    const custName = custObj ? (isAR ? (custObj.name_ar || custObj.name_en) : (custObj.name_en || custObj.name_ar)) : (sale.customer_name || (isAR ? 'عميل عابر' : 'Walk-in Customer'));

    const showLogo = co.print_logo !== false && co.company_logo && co.inv_logo_position !== 'hidden';
    const logoSize = parseInt(co.inv_logo_size) || 70;
    const showCompName = co.inv_show_company_name !== false;
    const showPhone = co.inv_show_phone !== false;
    const showAddress = co.inv_show_address !== false;
    const showVat = co.inv_show_vat !== false;
    const showSalesperson = co.inv_show_salesperson !== false;
    const showCust = co.inv_show_customer_info !== false;
    const showDualCur = co.inv_show_dual_currency !== false;
    const showQr = co.inv_show_qr !== false;

    const resolvedCompName = resolveCompanyName(co, isAR);
    const cur1 = co.currency_1 || 'USD';
    const cur2 = co.currency_2 || 'LBP';
    const exchRate = parseFloat(co.exchange_rate) || 89500;
    const subtotal = parseFloat(sale.subtotal !== undefined ? sale.subtotal : (sale.grand_total || 0));
    const discountAmt = parseFloat(sale.discount || sale.discount_amount || sale.discount_amt || 0);
    const vatAmt = parseFloat(sale.vat || sale.vat_amount || 0);
    const grandTotal = parseFloat(sale.grand_total || 0);
    const cur2Total = sale.grand_total_2 !== undefined ? parseFloat(sale.grand_total_2) : (typeof Utils.calcSecondaryPrice === 'function' ? Utils.calcSecondaryPrice(grandTotal, cur1, cur2, exchRate) : (grandTotal * exchRate));

    const lblDocNum    = co.inv_txt_doc_num_label    || (isAR ? 'رقم الفاتورة:' : 'Receipt No:');
    const lblDate      = co.inv_txt_date_label       || (isAR ? 'تاريخ الإصدار:' : 'Date & Time:');
    const lblCust      = co.inv_txt_bill_to_label    || (isAR ? 'العميل:' : 'Customer:');
    const lblCashier   = co.inv_txt_cashier_label   || (isAR ? 'الكاشير:' : 'Cashier:');
    const lblSubtotal  = co.inv_txt_subtotal_label   || (isAR ? 'المجموع الفرعي:' : 'Subtotal:');
    const lblDisc      = co.inv_txt_discount_label   || (isAR ? 'الخصم:' : 'Discount:');
    const lblVat       = co.inv_txt_vat_label        || (isAR ? `الضريبة (${co.vat_rate || 11}%):` : `VAT (${co.vat_rate || 11}%):`);
    const lblGrand     = co.inv_txt_grand_total_label || (isAR ? 'الإجمالي:' : 'GRAND TOTAL:');
    const lblCur2      = co.inv_txt_cur2_label       || (isAR ? 'المعادل:' : `In ${cur2}:`);
    const lblPay       = co.inv_txt_payment_label    || (isAR ? 'طريقة الدفع:' : 'Payment:');

    const colItem      = co.inv_txt_col_item         || (isAR ? 'الصنف والمواصفات' : 'Item Description');
    const colQty       = co.inv_txt_col_qty          || (isAR ? 'الكمية' : 'Qty');
    const colPrice     = co.inv_txt_col_price        || (isAR ? 'السعر' : 'Price');
    const colTotal     = co.inv_txt_col_total        || (isAR ? 'الإجمالي' : 'Total');
    const receiptItemLayout = co.inv_receipt_item_layout || 'table';

    const showBarcode = co.inv_show_barcode !== false;
    const barcodeSvg = showBarcode && typeof Utils !== 'undefined' && typeof Utils.generateBarcodeSVG === 'function' ? 
      Utils.generateBarcodeSVG(refNo, { height: 34, barWidth: 1.5 }) : '';

    const dec2 = (typeof Utils.isLbp === 'function' && Utils.isLbp(cur2)) || cur2 === 'LBP' || cur2 === 'IQD' ? 0 : 2;
    const tenderedAmt = parseFloat(sale.amount_tendered !== undefined ? sale.amount_tendered : (sale.tendered !== undefined ? sale.tendered : grandTotal));
    const tendered2 = sale.amount_tendered_2 !== undefined ? parseFloat(sale.amount_tendered_2) : (typeof Utils.calcSecondaryPrice === 'function' ? Utils.calcSecondaryPrice(tenderedAmt, cur1, cur2, exchRate) : (tenderedAmt * exchRate));
    const changeC1 = sale.change_amount !== undefined ? parseFloat(sale.change_amount) : (sale.change_c1 !== undefined ? parseFloat(sale.change_c1) : Math.max(0, tenderedAmt - grandTotal));
    const changeC2 = sale.change_c2 !== undefined ? parseFloat(sale.change_c2) : (typeof Utils.calcSecondaryPrice === 'function' ? Utils.calcSecondaryPrice(changeC1, cur1, cur2, exchRate) : (changeC1 * exchRate));

    // Custom Font Sizes (Synchronized with Invoice Designer)
    const fsCompName   = co.inv_fs_company_name   || '16px';
    const fsSubtitle   = co.inv_fs_subtitle       || '10px';
    const fsContact    = co.inv_fs_header_contact || '10px';
    const fsDocTitle   = co.inv_fs_doc_title      || '12px';
    const fsDocNum     = co.inv_fs_doc_num        || '11px';
    const fsMetaText   = co.inv_fs_meta_text      || '11px';
    const fsCustBox    = co.inv_fs_customer_box   || '11px';
    const fsCashierBox = co.inv_fs_cashier_box    || '11px';
    const fsTblHeader  = co.inv_fs_table_header   || '11px';
    const fsTblRows    = co.inv_fs_table_rows     || '11px';
    const fsItemSub    = co.inv_fs_item_subline   || '9.5px';
    const fsTotals     = co.inv_fs_totals_box     || '11px';
    const fsGrandTotal = co.inv_fs_grand_total    || '14px';
    const fsCur2Total  = co.inv_fs_cur2_total     || '12px';
    const fsTerms      = co.inv_fs_terms          || '9px';
    const fsFooter     = co.inv_fs_footer_note    || '10.5px';

    const innerReceiptHtml = `
      <!-- Header -->
      <div class="center" style="text-align:center">
        ${showLogo ? `<div style="margin-bottom:4px"><img src="${co.company_logo}" style="max-width:${Math.min(logoSize, 120)}px;max-height:${Math.min(logoSize, 80)}px;object-fit:contain"></div>` : ''}
        ${showCompName ? `<div class="xlarge" style="font-size:${fsCompName};font-weight:900;letter-spacing:0.5px">${Utils.sanitize(resolvedCompName)}</div>` : ''}
        ${co.inv_custom_subtitle ? `<div style="font-size:${fsSubtitle};font-weight:700;margin-top:1px">${Utils.sanitize(co.inv_custom_subtitle)}</div>` : ''}
        ${showAddress && co.company_address ? `<div style="font-size:${fsContact};margin-top:1px">📍 ${Utils.sanitize(co.company_address)}</div>` : ''}
        ${showPhone && co.company_phone ? `<div style="font-size:${fsContact};margin-top:1px">📞 ${isAR ? 'هاتف: ' : 'TEL: '}<bdi>${Utils.sanitize(co.company_phone)}</bdi></div>` : ''}
        ${showVat && co.vat_number ? `<div style="font-size:${fsContact};margin-top:1px">${isAR ? 'الرقم المالي: ' : 'Tax ID: '}<bdi>${Utils.sanitize(co.vat_number)}</bdi></div>` : ''}
        <div style="font-size:${fsDocTitle};font-weight:bold;margin-top:3px">${Utils.sanitize(sale.order_type === 'delivery' ? (isAR ? 'فاتورة توصيل (دليفري)' : 'DELIVERY INVOICE') : (co.inv_txt_doc_title || options.doc_title || (isAR ? 'فاتورة ضريبية' : 'TAX INVOICE')))}</div>
      </div>

      <div class="divider" style="border-top:1.5px dashed #000;margin:5px 0"></div>

      <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsDocNum};font-weight:600">
        <span>${lblDocNum}</span>
        <span class="bold" style="font-weight:800"><bdi>${refNo}</bdi></span>
      </div>
      <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsMetaText};font-weight:600">
        <span>${lblDate}</span>
        <span><bdi>${date}</bdi></span>
      </div>
      ${showDualCur && exchRate ? `
      <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsMetaText};font-weight:600">
        <span>${isAR ? 'سعر الصرف:' : 'Exchange Rate:'}</span>
        <span class="bold" style="font-weight:800"><bdi>$1 = ${exchRate.toLocaleString()} ${cur2}</bdi></span>
      </div>` : ''}
      ${showCust ? `
      <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsCustBox};font-weight:600">
        <span>${lblCust}</span>
        <span class="bold" style="font-weight:800">${Utils.sanitize(custName)}</span>
      </div>` : ''}
      ${(sale.order_type === 'delivery' || sale.delivery_phone || (cust && cust.phone)) ? `
      <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsCustBox};font-weight:600">
        <span>${isAR ? 'هاتف العميل:' : 'Phone:'}</span>
        <span class="bold" style="font-weight:800"><bdi>${Utils.sanitize(sale.delivery_phone || (cust && cust.phone) || '-')}</bdi></span>
      </div>` : ''}
      ${(sale.order_type === 'delivery' || sale.delivery_address || (cust && cust.address)) ? `
      <div class="row" style="display:flex;justify-content:space-between;align-items:flex-start;margin:3px 0;font-size:${fsCustBox};font-weight:600">
        <span style="white-space:nowrap">${isAR ? 'عنوان التوصيل:' : 'Address:'}</span>
        <span class="bold" style="font-weight:800;text-align:${isAR ? 'left' : 'right'};max-width:65%">${Utils.sanitize(sale.delivery_address || (cust && cust.address) || '-')}</span>
      </div>` : ''}
      ${sale.delivery_notes ? `
      <div class="row" style="display:flex;justify-content:space-between;align-items:flex-start;margin:3px 0;font-size:${fsCustBox};font-weight:600">
        <span>${isAR ? 'ملاحظات:' : 'Notes:'}</span>
        <span style="font-style:italic;max-width:65%">${Utils.sanitize(sale.delivery_notes)}</span>
      </div>` : ''}
      ${showSalesperson ? `
      <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsCashierBox};font-weight:600">
        <span>${lblCashier}</span>
        <span>${Utils.sanitize(sale.salesperson || sale.cashier || 'Admin')}</span>
      </div>` : ''}

      <div class="divider-solid" style="border-top:2px solid #000;margin:5px 0"></div>

      <!-- Items (Column Table or 2-Line Stacked) -->
      ${receiptItemLayout === 'stacked' ? `
      <div style="margin: 5px 0;">
        ${items.map(item => {
          const ex = formatItemExtraDetails(item, isAR, co);
          let nameStr = isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name_ar || item.name);
          if (ex.hasExtra) {
            if (ex.mode === 'merged') {
              nameStr += ` ${ex.separator} ${ex.text}`;
            } else if (ex.mode === 'bracketed') {
              nameStr += ` (${ex.text})`;
            }
          }
          const itemPrice = parseFloat(item.price || item.unit_price || 0);
          const itemQty = parseFloat(item.qty || item.quantity || 1);
          const itemTotal = parseFloat(item.total !== undefined ? item.total : (itemPrice * itemQty));
          const isTaxable = (item.is_taxable || isItemTaxable(item));
          const taxableMark = isTaxable ? ` <span style="font-weight:900;color:#000">*</span>` : '';
          const hasDisc = (item.discount || item.disc) && parseFloat(item.disc_amount || item.discount || 0) > 0;

          return `
          <div style="margin-bottom:4px;font-size:${fsTblRows}">
            <div style="font-weight:800;color:#000">${Utils.sanitize(nameStr)}${taxableMark}</div>
            ${(ex.hasExtra && (!ex.mode || ex.mode === 'subline')) ? `<div style="font-size:${fsItemSub};color:#000;font-weight:600;margin-top:1px">${Utils.sanitize(ex.text)}</div>` : ''}
            <div style="display:flex;justify-content:space-between;align-items:center;color:#000;padding-left:4px;margin-top:2px">
              <span style="font-weight:700">${itemQty} x ${cur1} ${Utils.formatCurrency(itemPrice)}</span>
              <span style="font-weight:900">${cur1} ${Utils.formatCurrency(itemTotal)}</span>
            </div>
            ${hasDisc ? `<div style="font-size:${fsItemSub};color:#000;font-weight:800;text-align:${isAR?'left':'right'}">${isAR?'(حسم: ':'(Disc: '}-${cur1} ${Utils.formatCurrency(item.disc_amount || item.discount)})</div>` : ''}
          </div>`;
        }).join('')}
      </div>
      ` : `
      <table style="width:100%;border-collapse:collapse;margin:4px 0;font-size:${fsTblRows};color:#000">
        <thead>
          <tr style="border-top:1.5px solid #000;border-bottom:1.5px solid #000;font-weight:900;font-size:${fsTblHeader}">
            <th style="text-align:${isAR?'right':'left'};padding:3px 1px;width:44%">${Utils.sanitize(colItem)}</th>
            <th style="text-align:center;padding:3px 1px;width:14%">${Utils.sanitize(colQty)}</th>
            <th style="text-align:center;padding:3px 1px;width:20%">${Utils.sanitize(colPrice)}</th>
            <th style="text-align:${isAR?'left':'right'};padding:3px 1px;width:22%">${Utils.sanitize(colTotal)}</th>
          </tr>
        </thead>
        <tbody>
          ${items.map(item => {
            const ex = formatItemExtraDetails(item, isAR, co);
            let nameStr = isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name_ar || item.name);
            if (ex.hasExtra) {
              if (ex.mode === 'merged') {
                nameStr += ` ${ex.separator} ${ex.text}`;
              } else if (ex.mode === 'bracketed') {
                nameStr += ` (${ex.text})`;
              }
            }
            const itemPrice = parseFloat(item.price || item.unit_price || 0);
            const itemQty = parseFloat(item.qty || item.quantity || 1);
            const itemTotal = parseFloat(item.total !== undefined ? item.total : (itemPrice * itemQty));
            const isTaxable = (item.is_taxable || isItemTaxable(item));
            const taxableMark = isTaxable ? ` *` : '';
            const hasDisc = (item.discount || item.disc) && parseFloat(item.disc_amount || item.discount || 0) > 0;

            return `
            <tr style="border-bottom:1px dashed #000;vertical-align:top">
              <td style="text-align:${isAR?'right':'left'};padding:3px 1px;font-weight:700">
                <div>${Utils.sanitize(nameStr)}${taxableMark}</div>
                ${(ex.hasExtra && (!ex.mode || ex.mode === 'subline')) ? `<div style="font-size:${fsItemSub};color:#000;font-weight:600;margin-top:1px">${Utils.sanitize(ex.text)}</div>` : ''}
                ${hasDisc ? `<div style="font-size:${fsItemSub};color:#000;font-weight:800;margin-top:1px">${isAR?'(حسم: ':'(Disc: '}-${cur1} ${Utils.formatCurrency(item.disc_amount || item.discount)})</div>` : ''}
              </td>
              <td style="text-align:center;padding:3px 1px;font-weight:800;white-space:nowrap">${itemQty}</td>
              <td style="text-align:center;padding:3px 1px;font-weight:700;white-space:nowrap">${Utils.formatCurrency(itemPrice)}</td>
              <td style="text-align:${isAR?'left':'right'};padding:3px 1px;font-weight:900;white-space:nowrap">${Utils.formatCurrency(itemTotal)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
      `}

      <div class="divider-solid" style="border-top:2px solid #000;margin:5px 0"></div>

      <!-- Totals -->
      <div class="totals" style="margin-top:5px;font-size:${fsTotals}">
        <div class="total-row" style="display:flex;justify-content:space-between;align-items:center;padding:2px 0;font-weight:700">
          <span>${lblSubtotal}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(subtotal)}</bdi></span>
        </div>
        ${discountAmt > 0 ? `
        <div class="total-row" style="display:flex;justify-content:space-between;align-items:center;padding:2px 0;font-weight:800;color:#000 !important">
          <span>${lblDisc}</span>
          <span><bdi>-${cur1} ${Utils.formatCurrency(discountAmt)}</bdi></span>
        </div>` : ''}
        ${vatAmt > 0 ? `
        <div class="total-row" style="display:flex;justify-content:space-between;align-items:center;padding:2px 0;font-weight:700">
          <span>${lblVat}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(vatAmt)}</bdi></span>
        </div>` : ''}
        ${parseFloat(sale.delivery_fee || 0) > 0 ? `
        <div class="total-row" style="display:flex;justify-content:space-between;align-items:center;padding:2px 0;font-weight:700">
          <span>${isAR ? 'أجرة التوصيل:' : 'Delivery Fee:'}</span>
          <span><bdi>+${cur1} ${Utils.formatCurrency(sale.delivery_fee)}</bdi></span>
        </div>` : ''}
      </div>

      <!-- Highlighted Dual Currency Net Total Box (Pure Solid Contrast for Thermal) -->
      <div class="net-total-box" style="border:2px solid #000;background:#ffffff;padding:6px 8px;margin:6px 0 5px;border-radius:4px">
        <div class="net-total-row primary-cur" style="display:flex;justify-content:space-between;align-items:center;font-size:${fsGrandTotal};font-weight:900;color:#000;padding-bottom:4px;margin-bottom:4px;border-bottom:1.5px dashed #000">
          <span>${lblGrand}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(grandTotal)}</bdi></span>
        </div>
        ${showDualCur && cur2 ? `
        <div class="net-total-row" style="display:flex;justify-content:space-between;align-items:center;font-size:${fsCur2Total};font-weight:900;color:#000;padding:2px 0">
          <span>${lblCur2}</span>
          <span><bdi>${Utils.isLbp(cur2) ? Math.round(cur2Total).toLocaleString() : Utils.formatCurrency(cur2Total, cur2, 2)} ${cur2}</bdi></span>
        </div>` : ''}
        ${(sale.points_earned || sale.customer_points || sale.new_points_balance !== undefined || (custObj && custObj.points_balance !== undefined)) ? `
        <div style="border-top:1.5px dashed #000;margin-top:4px;padding-top:4px">
          ${(sale.points_earned > 0) ? `
          <div class="net-total-row" style="display:flex;justify-content:space-between;align-items:center;font-size:${fsTotals};font-weight:900;color:#000 !important;padding:2px 0">
            <span style="color:#000 !important;font-weight:900">⭐ ${isAR ? 'النقاط المكتسبة للفاتورة:' : 'Points Earned:'}</span>
            <span style="color:#000 !important;font-weight:900"><bdi>+${sale.points_earned.toLocaleString()}</bdi></span>
          </div>` : ''}
          <div class="net-total-row" style="display:flex;justify-content:space-between;align-items:center;font-size:${fsTotals};font-weight:900;color:#000 !important;padding:2px 0">
            <span style="color:#000 !important;font-weight:900">⭐ ${isAR ? 'رصيد النقاط المتاح للعميل:' : 'Available Points Balance:'}</span>
            <span style="color:#000 !important;font-weight:900"><bdi>${(sale.new_points_balance !== undefined ? sale.new_points_balance : (custObj?.points_balance !== undefined ? custObj.points_balance : (sale.customer_points || 0))).toLocaleString()} ${isAR ? 'نقطة' : 'pts'}</bdi></span>
          </div>
        </div>` : ''}
      </div>

      ${(sale.order_type === 'delivery' || sale.delivery_address) ? `
      <div style="border:1.5px solid #000;border-radius:4px;padding:5px 8px;margin:6px 0;background:#ffffff">
        <div style="display:flex;justify-content:space-between;font-size:${fsTotals};font-weight:700">
          <span>${isAR ? 'المبلغ المسدد:' : 'Amount Paid:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(sale.paid_amount !== undefined ? sale.paid_amount : tenderedAmt)}</bdi></span>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:900;border-top:1px dashed #000;margin-top:3px;padding-top:3px">
          <span>${isAR ? 'المستحق عند الاستلام:' : 'Balance Due on Delivery:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(Math.max(0, Utils.round(grandTotal - (sale.paid_amount !== undefined ? sale.paid_amount : tenderedAmt))))}</bdi></span>
        </div>
      </div>` : ''}

      <!-- Payment details (Intense Pure Black for Thermal Printing) -->
      <div class="payment-methods" style="margin:4px 0">
        <div class="row" style="display:flex;justify-content:space-between;align-items:center;margin:3px 0;font-size:${fsTotals};font-weight:700">
          <span>${lblPay}</span>
          <span class="bold" style="font-weight:900">${isAR ? _paymentLabelAR(sale.payment_method) : _paymentLabelEN(sale.payment_method)}</span>
        </div>
        ${(sale.payment_method === 'credit' || parseFloat(sale.credit_amount) > 0) ? `
        ${parseFloat(sale.paid_amount || sale.tendered || 0) > 0 ? `
        <div class="row" style="display:flex;justify-content:space-between;color:#000 !important;font-weight:800;margin:2px 0;font-size:11px">
          <span>${isAR ? 'المدفوع نقداً / Down Payment:' : 'Down Payment:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(parseFloat(sale.paid_amount || sale.tendered || 0))}</bdi></span>
        </div>` : ''}
        <div class="row" style="display:flex;justify-content:space-between;color:#000 !important;font-weight:900;margin:2px 0;font-size:11px">
          <span>${isAR ? 'المتبقي آجل / Credit Due:' : 'Remaining Due:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(parseFloat(sale.credit_amount !== undefined ? sale.credit_amount : Math.max(0, grandTotal - (parseFloat(sale.paid_amount || sale.tendered || 0)))))}</bdi></span>
        </div>
        ${custObj && custObj.balance !== undefined ? `
        <div class="row bold" style="display:flex;justify-content:space-between;border-top:1.5px dashed #000;padding-top:2px;margin-top:2px;font-weight:900;font-size:11.5px;color:#000 !important">
          <span>${isAR ? 'رصيد العميل / Total Balance:' : 'Total Balance:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(custObj.balance)}</bdi></span>
        </div>` : ''}
        ` : `
        ${sale.amount_tendered ? `
        <div class="row" style="display:flex;justify-content:space-between;margin:2px 0;font-size:11px;font-weight:600">
          <span>${isAR ? 'المستلم / Tendered:' : 'Tendered:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(sale.amount_tendered)}</bdi> (${Utils.formatCurrency(tendered2, '', dec2)} ${cur2})</span>
        </div>` : ''}
        ${(sale.change_amount || sale.change_c1 || changeC1 > 0) ? `
        <div class="row bold" style="display:flex;justify-content:space-between;margin:2px 0;font-size:11px;font-weight:800">
          <span>${isAR ? 'الباقي / Change:' : 'Change:'}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(changeC1)}</bdi> (${Utils.formatCurrency(changeC2, '', dec2)} ${cur2})</span>
        </div>` : ''}
        `}
      </div>

      <!-- TVA Taxable Footnote Note (Crisp Black) -->
      <div style="font-size:9.5px;color:#000 !important;font-weight:800;text-align:center;margin:3px 0 2px;padding:2px 0">
        <span style="font-weight:900;color:#000">*</span> ${isAR ? 'خاضع لضريبة القيمة المضافة (TVA Taxable)' : 'TVA Taxable Items'}
      </div>

      <div class="divider" style="border-top:1.5px dashed #000;margin:5px 0"></div>

      <!-- Barcode Section (Real SVG Barcode) -->
      ${showBarcode && barcodeSvg ? `
      <div class="barcode-container" style="text-align:center;margin:8px 0 4px;display:flex;flex-direction:column;align-items:center;justify-content:center">
        ${barcodeSvg}
        <div class="barcode-text" style="font-family:monospace;font-size:10.5px;font-weight:800;letter-spacing:1.5px;margin-top:3px">${refNo}</div>
      </div>` : ''}

      <!-- QR Code & Marketing Footer -->
      ${(showQr || co.inv_footer_note || co.inv_terms_text) ? `
      <div class="footer-promo" style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;gap:8px">
        ${showQr ? `
        <div style="flex-shrink:0">
          <svg width="60" height="60" viewBox="0 0 100 100" fill="#000">
            <rect x="4" y="4" width="32" height="32" fill="none" stroke="#000" stroke-width="7"/>
            <rect x="12" y="12" width="16" height="16" fill="#000"/>
            <rect x="64" y="4" width="32" height="32" fill="none" stroke="#000" stroke-width="7"/>
            <rect x="72" y="12" width="16" height="16" fill="#000"/>
            <rect x="4" y="64" width="32" height="32" fill="none" stroke="#000" stroke-width="7"/>
            <rect x="12" y="72" width="16" height="16" fill="#000"/>
            <rect x="44" y="14" width="12" height="12"/>
            <rect x="44" y="44" width="12" height="12"/>
            <rect x="64" y="54" width="14" height="14"/>
            <rect x="80" y="76" width="16" height="16"/>
            <rect x="44" y="76" width="12" height="12"/>
          </svg>
        </div>` : ''}
        <div class="footer-promo-text" style="font-size:10.5px;font-weight:700;line-height:1.4;flex:1;text-align:${isAR ? 'right' : 'left'}">
          <div>${Utils.sanitize(co.inv_footer_note || (isAR ? 'شكراً لتعاملكم معنا ونسعد بخدمتكم' : 'Thank you for your business!'))}</div>
          ${co.inv_terms_text ? `<div style="font-size:8.5px;margin-top:2px">${Utils.sanitize(co.inv_terms_text)}</div>` : ''}
        </div>
      </div>` : ''}
    `;

    if (options.isPreview) {
      return `
      <div class="receipt-80mm-preview" style="background:#ffffff;color:#000000;font-family:'Segoe UI','Tahoma','Arial','Cairo',sans-serif;font-size:11.5px;padding:10px 8px;line-height:1.35;font-weight:600;width:100%;max-width:320px;margin:0 auto;box-sizing:border-box" dir="${isAR ? 'rtl' : 'ltr'}">
        <div class="receipt" style="width:100%;padding:2px 0;">
          ${innerReceiptHtml}
        </div>
      </div>`;
    }

    return `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${isAR ? 'إيصال' : 'Receipt'} ${refNo}</title>
  <style>
    @page { size: 80mm auto; margin: 0; }
  </style>
  ${baseStyles()}
  <style>
    * { 
      box-sizing: border-box; 
      margin: 0; 
      padding: 0; 
      -webkit-print-color-adjust: exact !important; 
      print-color-adjust: exact !important; 
    }
    body { 
      width: 76mm; 
      margin: 0 auto; 
      font-size: 11.5px; 
      font-family: 'Segoe UI', 'Tahoma', 'Arial', 'Cairo', sans-serif; 
      direction: ${isAR ? 'rtl' : 'ltr'}; 
      text-align: ${isAR ? 'right' : 'left'}; 
      color: #000000 !important;
      background: #ffffff !important;
      font-weight: 600;
      -webkit-font-smoothing: antialiased;
      text-rendering: geometricPrecision;
    }
    .receipt { padding: 2mm 1mm; width: 100%; }
    .center { text-align: center; }
    .bold   { font-weight: 800; }
    .large  { font-size: 13.5px; font-weight: 800; }
    .xlarge { font-size: 16.5px; font-weight: 900; letter-spacing: 0.5px; }
    .divider { border-top: 1.5px dashed #000; margin: 5px 0; }
    .divider-solid { border-top: 2px solid #000; margin: 5px 0; }
    .row { display: flex; justify-content: space-between; align-items: center; margin: 3px 0; font-size: 11px; color: #000 !important; font-weight: 600; }
    .totals { margin-top: 5px; font-size: 11px; }
    .total-row { display: flex; justify-content: space-between; align-items: center; padding: 2.5px 0; font-weight: 700; color: #000 !important; }
    
    .net-total-box {
      border: 2px solid #000;
      background: #ffffff !important;
      padding: 6px 8px;
      margin: 6px 0 5px;
      border-radius: 4px;
    }
    .net-total-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 13px;
      font-weight: 900;
      color: #000 !important;
      padding: 2px 0;
    }
    .net-total-row.primary-cur {
      font-size: 15px;
      border-bottom: 1.5px dashed #000;
      padding-bottom: 4px;
      margin-bottom: 4px;
    }
    
    .barcode-container { text-align: center; margin: 8px 0 4px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
    .barcode-container svg { max-width: 95%; height: 38px; }
    .barcode-text { font-family: monospace; font-size: 10.5px; font-weight: 800; letter-spacing: 1.5px; margin-top: 3px; }
    
    .footer-promo { display: flex; align-items: center; justify-content: space-between; margin-top: 8px; gap: 8px; }
    .footer-promo-text { font-size: 10.5px; font-weight: 700; line-height: 1.4; flex: 1; text-align: ${isAR ? 'right' : 'left'}; }
    
    bdi { unicode-bidi: isolate; }
    @media print { 
      @page { margin: 0; size: 80mm auto; } 
      .no-print { display: none !important; } 
      body { width: 100%; font-size: 11.5px; color: #000000 !important; background: #fff !important; }
      * {
        color: #000000 !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        text-shadow: none !important;
      }
      .net-total-box { background: #ffffff !important; }
    }
  </style>
</head>
<body>
  ${options.showPreviewToolbar ? `
  <div class="no-print print-actions">
    <button class="btn-print" onclick="window.print()">🖨 ${isAR ? 'طباعة' : 'Print'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>` : ''}
  <div class="receipt">
    ${innerReceiptHtml}
  </div>
</body>
</html>`;
  }

  async function printReceipt(sale, rawItems, customer, options = {}) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? (i18n.getLang() === 'ar') : true;
    const pageSize = options.pageSize || (typeof DB !== 'undefined' ? await DB.getSetting('receipt_size', '80mm') : '80mm');
    
    // If paper size is set to standard document page (A4, A5, Letter), route to full invoice layout
    if (['a4', 'a5', 'letter', 'legal'].includes(String(pageSize).toLowerCase())) {
      return printInvoice(sale, rawItems, customer, { ...options, pageSize });
    }

    const html = await generateReceiptHtml(sale, rawItems, customer, { ...options, pageSize, isPreview: false });
    await openPrintWindow(html, isAR ? 'إيصال' : 'Receipt', pageSize);
  }

  // ═══════════════════════════════════════════════════════════════
  // A4 SALES INVOICE (Matching Modern Invoice Designer Exactly)
  // ═══════════════════════════════════════════════════════════════
  async function generateInvoiceHtml(sale, rawItems, customer, options = {}) {
    const co = options.coOverride || await getCompanyInfo();
    let itemsList = rawItems;
    if (!itemsList || !itemsList.length) {
      itemsList = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (Array.isArray(sale.items) ? sale.items : []);
    }
    const items = await enrichItemsWithDetails(itemsList);
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? (i18n.getLang() === 'ar') : true;
    const date = Utils.formatDate(sale.created_at || sale.doc_date || Utils.today());
    const dueDate = sale.due_date ? Utils.formatDate(sale.due_date) : date;

    let custObj = customer;
    if (!custObj && sale.customer_id) {
      try { custObj = await DB.get('customers', sale.customer_id); } catch(e) {}
    }
    const custName = custObj ? (isAR ? (custObj.name_ar || custObj.name_en) : (custObj.name_en || custObj.name_ar)) : (sale.customer_name || (isAR ? 'عميل عابر' : 'Walk-in Customer'));

    const primaryColor = co.inv_primary_color || '#2563eb';
    const fontFamily = co.inv_font_family || 'Cairo';
    const logoPos = co.inv_logo_position || 'left';
    const logoSize = parseInt(co.inv_logo_size) || 80;
    const showLogo = co.print_logo !== false && co.company_logo && logoPos !== 'hidden';
    const headerAlign = co.inv_header_align || 'left';
    
    const showCompName = co.inv_show_company_name !== false;
    const showPhone = co.inv_show_phone !== false;
    const showEmail = co.inv_show_email !== false;
    const showAddress = co.inv_show_address !== false;
    const showVat = co.inv_show_vat !== false;
    
    const showCust = co.inv_show_customer_info !== false;
    const showSalesperson = co.inv_show_salesperson !== false;
    const showItemCode = co.inv_show_item_code !== false;
    const showDisc = co.inv_show_discount_col !== false;
    const showDualCur = co.inv_show_dual_currency !== false;
    const showStamp = co.inv_show_stamp_signature !== false;
    const showQr = co.inv_show_qr !== false;
    const showBarcode = co.inv_show_barcode !== false;

    const cur1 = co.currency_1 || 'USD';
    const cur2 = co.currency_2 || 'LBP';
    const exchRate = parseFloat(co.exchange_rate) || 89500;
    const subtotal = parseFloat(sale.subtotal !== undefined ? sale.subtotal : (sale.grand_total || 0));
    const discountAmt = parseFloat(sale.discount || sale.discount_amount || sale.discount_amt || 0);
    const vatAmt = parseFloat(sale.vat || sale.vat_amount || 0);
    const grandTotal = parseFloat(sale.grand_total || 0);
    const grandTotal2 = sale.grand_total_2 !== undefined ? parseFloat(sale.grand_total_2) : (typeof Utils.calcSecondaryPrice === 'function' ? Utils.calcSecondaryPrice(grandTotal, cur1, cur2, exchRate) : (grandTotal * exchRate));

    // Custom Font Sizes Per Box
    const fsCompName   = co.inv_fs_company_name   || '24px';
    const fsSubtitle   = co.inv_fs_subtitle       || '13px';
    const fsContact    = co.inv_fs_header_contact || '12px';
    const fsDocTitle   = co.inv_fs_doc_title      || '22px';
    const fsDocNum     = co.inv_fs_doc_num        || '15px';
    const fsMetaText   = co.inv_fs_meta_text      || '12px';
    const fsCustBox    = co.inv_fs_customer_box   || '13px';
    const fsCashierBox = co.inv_fs_cashier_box    || '13px';
    const fsTblHeader  = co.inv_fs_table_header   || '12px';
    const fsTblRows    = co.inv_fs_table_rows     || '12px';
    const fsItemSub    = co.inv_fs_item_subline   || '11px';
    const fsTotals     = co.inv_fs_totals_box     || '12px';
    const fsGrandTotal = co.inv_fs_grand_total    || '16px';
    const fsCur2Total  = co.inv_fs_cur2_total     || '13px';
    const fsTerms      = co.inv_fs_terms          || '11px';
    const fsSigs       = co.inv_fs_signatures     || '12px';
    const fsFooter     = co.inv_fs_footer_note    || '11px';

    // Custom Fixed Texts / Labels overrides
    const docTitleFinal    = co.inv_txt_doc_title    || options.doc_title || (isAR ? 'فاتورة ضريبية' : 'TAX INVOICE');
    const lblDate          = co.inv_txt_date_label   || (isAR ? 'تاريخ الإصدار: ' : 'Issue Date: ');
    const lblDueDate       = co.inv_txt_duedate_label|| (isAR ? 'الاستحقاق: ' : 'Due Date: ');
    const lblTaxId         = co.inv_txt_tax_id_label || (isAR ? 'الرقم الضريبي / المالي: ' : 'Tax ID: ');
    const lblBillTo        = co.inv_txt_bill_to_label|| (isAR ? 'فاتورة إلى / العميل:' : 'BILL TO / CUSTOMER:');
    const lblCashier       = co.inv_txt_cashier_label|| (isAR ? 'المبيعات / الكاشير:' : 'SALES / CASHIER:');
    const lblPayment       = co.inv_txt_payment_label|| (isAR ? 'طريقة الدفع: ' : 'Payment: ');
    
    // Table column labels
    const colHash          = co.inv_txt_col_hash     || '#';
    const colItem          = co.inv_txt_col_item     || (isAR ? 'الصنف والمواصفات' : 'Item Description & Attributes');
    const colSku           = co.inv_txt_col_sku      || (isAR ? 'الكود' : 'SKU');
    const colQty           = co.inv_txt_col_qty      || (isAR ? 'الكمية' : 'Qty');
    const colPrice         = co.inv_txt_col_price    || (isAR ? 'السعر' : 'Price');
    const colDisc          = co.inv_txt_col_disc     || (isAR ? 'الخصم' : 'Disc');
    const colTotal         = co.inv_txt_col_total    || (isAR ? 'الإجمالي' : 'Total');

    // Totals labels
    const lblSubtotal      = co.inv_txt_subtotal_label   || (isAR ? 'المجموع الفرعي:' : 'Subtotal:');
    const lblDiscount      = co.inv_txt_discount_label   || (isAR ? 'الخصم:' : 'Discount:');
    const lblVat           = co.inv_txt_vat_label        || (isAR ? `الضريبة (${co.vat_rate || 11}%):` : `VAT (${co.vat_rate || 11}%):`);
    const lblGrandTotal    = co.inv_txt_grand_total_label|| (isAR ? `الإجمالي (<bdi>${cur1}</bdi>):` : `GRAND TOTAL (${cur1}):`);
    const lblCur2          = co.inv_txt_cur2_label       || (isAR ? `المعادل بـ ${cur2}:` : `In ${cur2}:`);
    const lblTerms         = co.inv_txt_terms_label      || (isAR ? 'الشروط: ' : 'Terms: ');
    const lblCustSig       = co.inv_txt_cust_sig_label   || (isAR ? 'توقيع المستلم / العميل' : 'Customer Signature');
    const lblStoreSig      = co.inv_txt_store_sig_label  || (isAR ? 'ختم وتوقيع المتجر' : 'Store Stamp & Signature');

    const refNo = sale.invoice_no || sale.receipt_no || sale.ref || ('# INV-' + (sale.id || '1'));

    let logoBlock = showLogo ? `<img src="${co.company_logo}" style="max-width:${logoSize}px;max-height:${logoSize}px;object-fit:contain;border-radius:4px">` : '';

    let headerFlexJustify = 'space-between';
    if (headerAlign === 'center') headerFlexJustify = 'center';
    else if (headerAlign === 'right') headerFlexJustify = isAR ? 'flex-start' : 'flex-end';

    let headerCompanyHtml = `
      <div style="display:flex;flex-direction:${logoPos==='center'?'column':(logoPos==='right'?'row-reverse':'row')};gap:14px;align-items:${headerAlign==='center'?'center':'flex-start'};text-align:${headerAlign}">
        ${(logoPos !== 'hidden' && showLogo) ? logoBlock : ''}
        <div>
          ${showCompName ? `<h1 style="font-size:${fsCompName};font-weight:900;color:${primaryColor};margin:0 0 3px">${Utils.sanitize(resolveCompanyName(co, isAR))}</h1>` : ''}
          ${co.inv_custom_subtitle ? `<div style="font-size:${fsSubtitle};font-weight:600;color:#64748b;margin-bottom:3px">${Utils.sanitize(co.inv_custom_subtitle)}</div>` : ''}
          ${showAddress && co.company_address ? `<div style="font-size:${fsContact};color:#475569;margin-bottom:1px">📍 ${Utils.sanitize(co.company_address)}</div>` : ''}
          ${showPhone && co.company_phone ? `<div style="font-size:${fsContact};color:#475569;margin-bottom:1px">📞 <bdi>${Utils.sanitize(co.company_phone)}</bdi></div>` : ''}
          ${showEmail && co.company_email ? `<div style="font-size:${fsContact};color:#475569;margin-bottom:1px">✉️ ${Utils.sanitize(co.company_email)}</div>` : ''}
          ${showVat && co.vat_number ? `<div style="font-size:${fsContact};color:#334155;font-weight:700;margin-top:3px">🏷️ ${lblTaxId}<bdi>${Utils.sanitize(co.vat_number)}</bdi></div>` : ''}
        </div>
      </div>
    `;

    const docPageSize = options.pageSize || options.page_size || 'A4';

    const html = `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${docTitleFinal} ${refNo}</title>
  ${baseStyles()}
  <style>
    body { font-size: 12px; font-family: '${fontFamily}', 'Cairo', 'Inter', sans-serif; background: #fff; color: #0f172a; direction: ${isAR ? 'rtl' : 'ltr'}; }
    .a4-page { width: 210mm; min-height: 297mm; margin: 0 auto; padding: 12mm 15mm; background: white; line-height: 1.4; box-sizing: border-box; }
    bdi { unicode-bidi: isolate; }
    @media print {
      @page { size: ${docPageSize}; margin: 8mm; }
      body { font-size: 11px; }
      .no-print { display: none !important; }
      .a4-page { width: 100%; min-height: auto; padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print print-actions">
    <button class="btn-print" onclick="window.print()">🖨 ${isAR ? 'طباعة' : 'Print'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>
  <div class="a4-page">
    
    <!-- Header section -->
    <div style="display:flex;justify-content:${headerFlexJustify};align-items:flex-start;border-bottom:2px solid ${primaryColor};padding-bottom:14px;margin-bottom:14px;flex-wrap:wrap;gap:12px">
      ${headerCompanyHtml}
      <div style="text-align:${isAR?'left':'right'};min-width:170px">
        <h2 style="font-size:${fsDocTitle};font-weight:900;color:${primaryColor};margin:0 0 3px;text-transform:uppercase">${docTitleFinal}</h2>
        <div style="font-size:${fsDocNum};font-weight:800;color:#1e293b"><bdi>${refNo}</bdi></div>
        <div style="font-size:${fsMetaText};color:#64748b;margin-top:2px">${lblDate}<bdi>${date}</bdi></div>
        <div style="font-size:${fsMetaText};color:#64748b">${lblDueDate}<bdi>${dueDate}</bdi></div>
      </div>
    </div>

    <!-- Customer & Cashier block -->
    ${(showCust || showSalesperson) ? `
    <div style="display:grid;grid-template-columns:${showCust&&showSalesperson?'2fr 1fr':'1fr'};gap:10px;margin-bottom:14px">
      ${showCust ? `
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;font-size:${fsCustBox}">
        <div style="font-size:0.85em;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:3px">${lblBillTo}</div>
        <div style="font-weight:800;font-size:1.05em;color:#0f172a">${Utils.sanitize(custName)}</div>
        ${custObj && (custObj.phone || custObj.address || custObj.email) ? `
        <div style="font-size:0.9em;color:#475569;margin-top:2px">
          ${custObj.phone ? `<span>📞 <bdi>${Utils.sanitize(custObj.phone)}</bdi></span>` : ''}
          ${custObj.address ? `<span> • 📍 ${Utils.sanitize(custObj.address)}</span>` : ''}
          ${custObj.vat_number ? `<span> • 🏷️ <bdi>${Utils.sanitize(custObj.vat_number)}</bdi></span>` : ''}
        </div>` : ''}
      </div>` : ''}
      ${showSalesperson ? `
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;text-align:${isAR?'left':'right'};font-size:${fsCashierBox}">
        <div style="font-size:0.85em;font-weight:700;color:#64748b;text-transform:uppercase;margin-bottom:3px">${lblCashier}</div>
        <div style="font-weight:800;font-size:1.05em;color:#0f172a">${Utils.sanitize(sale.salesperson || sale.cashier || 'Admin')}</div>
        <div style="font-size:0.9em;color:#475569;margin-top:2px">${lblPayment} ${isAR ? _paymentLabelAR(sale.payment_method || 'cash') : _paymentLabelEN(sale.payment_method || 'cash')}</div>
      </div>` : ''}
    </div>` : ''}

    <!-- Items Table -->
    <table style="width:100%;border-collapse:collapse;margin-bottom:14px">
      <thead>
        <tr style="background:${primaryColor};color:#ffffff;text-align:${isAR?'right':'left'};font-size:${fsTblHeader}">
          <th style="padding:7px 8px;width:30px;text-align:center">${colHash}</th>
          <th style="padding:7px 8px">${colItem}</th>
          ${showItemCode ? `<th style="padding:7px 8px;width:85px">${colSku}</th>` : ''}
          <th style="padding:7px 8px;width:50px;text-align:center">${colQty}</th>
          <th style="padding:7px 8px;width:80px;text-align:${isAR?'left':'right'}">${colPrice}</th>
          ${showDisc ? `<th style="padding:7px 8px;width:60px;text-align:${isAR?'left':'right'}">${colDisc}</th>` : ''}
          <th style="padding:7px 8px;width:95px;text-align:${isAR?'left':'right'}">${colTotal}</th>
        </tr>
      </thead>
      <tbody style="font-size:${fsTblRows}">
        ${items.map((item, idx) => {
          const ex = formatItemExtraDetails(item, isAR, co);
          const isTaxable = (item.is_taxable || isItemTaxable(item));
          const taxableMark = isTaxable ? ' <span style="color:#dc2626;font-weight:900;font-size:1.15em;margin-inline-start:3px;vertical-align:middle" title="TVA">*</span>' : '';
          let nameCell = `<div style="font-weight:700;color:#1e293b">${Utils.sanitize(isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name_ar || item.name))}${taxableMark}`;
          if (ex.hasExtra) {
            if (ex.mode === 'merged') {
              nameCell += ` <span style="font-size:0.85em;color:#64748b;font-weight:normal">${ex.separator} ${Utils.sanitize(ex.text)}</span>`;
            } else if (ex.mode === 'bracketed') {
              nameCell += ` <span style="font-size:0.85em;color:#64748b;font-weight:normal">(${Utils.sanitize(ex.text)})</span>`;
            }
          }
          nameCell += `</div>`;
          if (ex.hasExtra && ex.mode === 'subline') {
            nameCell += `<div style="font-size:${fsItemSub};color:#64748b;margin-top:2px;font-weight:500">${Utils.sanitize(ex.text)}</div>`;
          }

          const itemPrice = parseFloat(item.price || item.unit_price || 0);
          const itemQty = parseFloat(item.qty || item.quantity || 1);
          const itemDisc = parseFloat(item.discount || item.disc || 0);
          const lineTotal = parseFloat(item.total !== undefined ? item.total : (itemQty * itemPrice - (item.disc_amount || 0)));

          return `
          <tr style="background:${idx%2===0?'#ffffff':'#f8fafc'};border-bottom:1px solid #e2e8f0">
            <td style="padding:6px 8px;text-align:center;color:#64748b;vertical-align:top">${idx+1}</td>
            <td style="padding:6px 8px;vertical-align:top">${nameCell}</td>
            ${showItemCode ? `<td style="padding:6px 8px;font-family:monospace;color:#64748b;vertical-align:top">${item.code || item.sku || '-'}</td>` : ''}
            <td style="padding:6px 8px;text-align:center;font-weight:600;vertical-align:top">${itemQty}</td>
            <td style="padding:6px 8px;text-align:${isAR?'left':'right'};vertical-align:top"><bdi>${cur1} ${Utils.formatCurrency(itemPrice)}</bdi></td>
            ${showDisc ? `<td style="padding:6px 8px;text-align:${isAR?'left':'right'};color:#dc2626;vertical-align:top">${itemDisc > 0 ? (item.discount_type === 'pct' ? itemDisc + '%' : Utils.formatCurrency(itemDisc)) : '-'}</td>` : ''}
            <td style="padding:6px 8px;text-align:${isAR?'left':'right'};font-weight:700;vertical-align:top"><bdi>${cur1} ${Utils.formatCurrency(lineTotal)}</bdi></td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>

    <!-- TVA Footnote Notice -->
    <div style="font-size:0.72rem;color:#64748b;margin-top:2px;margin-bottom:12px;display:flex;align-items:center;gap:4px">
      <span style="color:#dc2626;font-weight:900;font-size:1.1em">*</span>
      <span>${isAR ? 'الأصناف المميزة بعلامة (*) خاضعة للضريبة على القيمة المضافة (TVA Taxable) — باقي الأصناف معفاة أو غير خاضعة.' : 'Items marked with (*) are subject to Value Added Tax (TVA Taxable) — other items are exempt.'}</span>
    </div>

    <!-- Totals and QR block -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;gap:16px">
      <div style="flex:1;display:flex;gap:14px;align-items:center">
        ${showQr ? `
        <div style="border:1px solid #cbd5e1;padding:5px;border-radius:6px;background:#fff;text-align:center">
          <svg width="60" height="60" viewBox="0 0 100 100" fill="#0f172a">
            <rect x="5" y="5" width="30" height="30" fill="none" stroke="#0f172a" stroke-width="6"/>
            <rect x="13" y="13" width="14" height="14" fill="#0f172a"/>
            <rect x="65" y="5" width="30" height="30" fill="none" stroke="#0f172a" stroke-width="6"/>
            <rect x="73" y="13" width="14" height="14" fill="#0f172a"/>
            <rect x="5" y="65" width="30" height="30" fill="none" stroke="#0f172a" stroke-width="6"/>
            <rect x="13" y="73" width="14" height="14" fill="#0f172a"/>
            <rect x="45" y="15" width="10" height="10"/>
            <rect x="45" y="45" width="10" height="10"/>
            <rect x="65" y="55" width="12" height="12"/>
            <rect x="80" y="75" width="15" height="15"/>
            <rect x="45" y="75" width="10" height="10"/>
          </svg>
          <div style="font-size:0.65rem;color:#64748b;margin-top:2px">e-Invoice QR</div>
        </div>` : ''}
        ${showBarcode ? `
        <div style="text-align:center">
          ${(typeof Utils !== 'undefined' && Utils.generateBarcodeSVG) ? Utils.generateBarcodeSVG(refNo, { height: 36, barWidth: 1.4 }) : ''}
          <div style="font-family:monospace;font-size:0.75rem;font-weight:700;color:#0f172a;margin-top:2px">${refNo}</div>
        </div>` : ''}
      </div>

      <!-- Totals Box -->
      <div style="width:250px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:10px;font-size:${fsTotals}">
        <div style="display:flex;justify-content:space-between;padding:2px 0;color:#64748b">
          <span>${lblSubtotal}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(subtotal)}</bdi></span>
        </div>
        ${discountAmt > 0 ? `
        <div style="display:flex;justify-content:space-between;padding:2px 0;color:#dc2626">
          <span>${lblDiscount}</span>
          <span><bdi>-${cur1} ${Utils.formatCurrency(discountAmt)}</bdi></span>
        </div>` : ''}
        ${vatAmt > 0 ? `
        <div style="display:flex;justify-content:space-between;padding:2px 0;color:#64748b">
          <span>${lblVat}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(vatAmt)}</bdi></span>
        </div>` : ''}
        <div style="border-top:2px solid ${primaryColor};margin-top:4px;padding-top:4px;display:flex;justify-content:space-between;font-size:${fsGrandTotal};font-weight:900;color:${primaryColor}">
          <span>${lblGrandTotal}</span>
          <span><bdi>${cur1} ${Utils.formatCurrency(grandTotal)}</bdi></span>
        </div>
        ${showDualCur && cur2 ? `
        <div style="display:flex;justify-content:space-between;margin-top:3px;padding-top:3px;border-top:1px dashed #cbd5e1;font-size:${fsCur2Total};font-weight:800;color:#059669">
          <span>${lblCur2}</span>
          <span><bdi>${Utils.isLbp(cur2) ? Math.round(grandTotal2).toLocaleString() : Utils.formatCurrency(grandTotal2, cur2, 2)} ${cur2}</bdi></span>
        </div>` : ''}
        ${(sale.payment_method === 'credit' || parseFloat(sale.credit_amount) > 0 || (sale.paid_amount !== undefined && parseFloat(sale.paid_amount) < grandTotal)) ? `
        <div style="margin-top:6px;padding-top:6px;border-top:1.5px dashed #cbd5e1;font-size:0.75rem">
          ${parseFloat(sale.paid_amount || sale.tendered || 0) > 0 ? `
          <div style="display:flex;justify-content:space-between;color:#0284c7;font-weight:700;margin-bottom:2px">
            <span>${isAR ? 'المدفوع نقداً (دفعة مقدمة):' : 'Paid Down Payment:'}</span>
            <span><bdi>${cur1} ${Utils.formatCurrency(parseFloat(sale.paid_amount || sale.tendered || 0))}</bdi></span>
          </div>` : ''}
          <div style="display:flex;justify-content:space-between;color:#dc2626;font-weight:800;margin-bottom:2px">
            <span>${isAR ? 'المبلغ الآجل المتبقي:' : 'Credit Remaining Due:'}</span>
            <span><bdi>${cur1} ${Utils.formatCurrency(parseFloat(sale.credit_amount !== undefined ? sale.credit_amount : Math.max(0, grandTotal - (parseFloat(sale.paid_amount || sale.tendered || 0)))))}</bdi></span>
          </div>
          ${custObj && custObj.balance !== undefined ? `
          <div style="display:flex;justify-content:space-between;color:#1e293b;font-weight:800;border-top:1px solid #e2e8f0;padding-top:3px;margin-top:3px">
            <span>${isAR ? 'إجمالي رصيد العميل الحالي:' : 'Customer Total Balance:'}</span>
            <span><bdi>${cur1} ${Utils.formatCurrency(custObj.balance)}</bdi></span>
          </div>` : ''}
        </div>` : ''}
        ${(sale.points_earned || (custObj && custObj.points_balance !== undefined) || sale.customer_points || sale.new_points_balance !== undefined) ? `
        <div style="margin-top:6px;padding-top:6px;border-top:1.5px dashed #cbd5e1;font-size:0.75rem">
          ${(sale.points_earned > 0) ? `
          <div style="display:flex;justify-content:space-between;color:#059669;font-weight:700;margin-bottom:2px">
            <span>⭐ ${isAR ? 'النقاط المكتسبة للفاتورة:' : 'Points Earned:'}</span>
            <span>+${sale.points_earned.toLocaleString()}</span>
          </div>` : ''}
          <div style="display:flex;justify-content:space-between;color:#7c3aed;font-weight:800">
            <span>⭐ ${isAR ? 'رصيد نقاط الولاء المتاح:' : 'Available Points Balance:'}</span>
            <span>${(sale.new_points_balance !== undefined ? sale.new_points_balance : (custObj?.points_balance !== undefined ? custObj.points_balance : (sale.customer_points || 0))).toLocaleString()} pts</span>
          </div>
        </div>` : ''}
      </div>
    </div>

    <!-- Terms & Policy -->
    ${co.inv_terms_text || sale.notes ? `
    <div style="background:#fffbeb;border:1px solid #fef3c7;border-${isAR?'right':'left'}:4px solid #f59e0b;padding:6px 10px;border-radius:4px;font-size:${fsTerms};color:#92400e;margin-bottom:12px">
      ${sale.notes ? `<div><strong>${isAR?'ملاحظات: ':'Notes: '}</strong>${Utils.sanitize(sale.notes)}</div>` : ''}
      ${co.inv_terms_text ? `<div style="margin-top:${sale.notes?'3px':'0'}"><strong>${lblTerms}</strong>${Utils.sanitize(co.inv_terms_text)}</div>` : ''}
    </div>` : ''}

    <!-- Stamp & Signature Boxes -->
    ${showStamp ? `
    <div style="display:flex;justify-content:space-between;margin-top:24px;padding-top:8px;font-size:${fsSigs}">
      <div style="text-align:center;width:160px;border-top:1px dashed #94a3b8;padding-top:4px">
        <div style="color:#64748b">${lblCustSig}</div>
      </div>
      <div style="text-align:center;width:160px;border-top:1px dashed #94a3b8;padding-top:4px">
        <div style="color:#64748b">${lblStoreSig}</div>
      </div>
    </div>` : ''}

    <!-- Footer Note -->
    <div style="margin-top:14px;padding-top:8px;border-top:1px solid #e2e8f0;text-align:center;font-size:${fsFooter};color:#94a3b8">
      ${co.inv_footer_note ? `<div>${Utils.sanitize(co.inv_footer_note)}</div>` : ''}
      <div style="margin-top:1px">${Utils.sanitize(resolveCompanyName(co, isAR))} • ${isAR?'فاتورة إلكترونية':'Electronic Invoice'}</div>
    </div>

  </div>
</body>
</html>`;
    return html;
  }

  async function printInvoice(sale, rawItems, customer, options = {}) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? (i18n.getLang() === 'ar') : true;
    const docTitle = options.doc_title || (isAR ? 'فاتورة ضريبية' : 'Tax Invoice');
    const pageSize = options.pageSize || options.page_size || (typeof DB !== 'undefined' ? await DB.getSetting('invoice_size', 'A4') : 'A4');
    const html = await generateInvoiceHtml(sale, rawItems, customer, { ...options, pageSize, isPreview: false });
    await openPrintWindow(html, docTitle, pageSize);
  }


  // ═══════════════════════════════════════════════════════════════
  // A4 PURCHASE ORDER
  // ═══════════════════════════════════════════════════════════════
  async function printPurchaseOrder(po, items, supplier) {
    const co = await getCompanyInfo();
    const isAR = i18n.getLang() === 'ar';
    const date = Utils.formatDate(po.created_at || Date.now());
    const deliveryDate = po.expected_delivery ? Utils.formatDate(po.expected_delivery) : '-';
    const poSize = (typeof DB !== 'undefined') ? await DB.getSetting('invoice_size', 'A4') : 'A4';

    if (poSize === '80mm' || poSize === '58mm') {
      const supName = supplier ? (isAR ? (supplier.name_ar || supplier.name_en) : (supplier.name_en || supplier.name_ar)) : (po.supplier_name || '-');
      const lines = items || [];
      const receiptHtml = `
      <div class="receipt-80mm" dir="${isAR ? 'rtl' : 'ltr'}" style="width:76mm;margin:0 auto;font-family:'Segoe UI','Cairo','Arial',sans-serif;color:#000;font-size:10px;padding:2mm">
        <div style="text-align:center;margin-bottom:8px">
          ${(co.company_logo) ? `<img src="${co.company_logo}" style="max-width:65px;max-height:55px;object-fit:contain;margin-bottom:4px">` : ''}
          <div style="font-size:1.1rem;font-weight:900">${Utils.sanitize(resolveCompanyName(co, isAR))}</div>
          <div style="font-size:0.75rem;font-weight:700;color:#333;margin-top:2px">${isAR ? 'أمر شراء' : 'Purchase Order'}</div>
        </div>
        <div style="border-top:1px dashed #000;margin:6px 0"></div>
        <div style="font-size:0.8rem;line-height:1.4">
          <div><strong>${isAR ? 'الرقم:' : 'PO #:'}</strong> <span style="font-weight:800">${po.po_number || '#' + po.id}</span></div>
          <div><strong>${isAR ? 'التاريخ:' : 'Date:'}</strong> ${date}</div>
          <div><strong>${isAR ? 'المورد:' : 'Supplier:'}</strong> <span style="font-weight:800">${Utils.sanitize(supName)}</span></div>
          <div><strong>${isAR ? 'الحالة:' : 'Status:'}</strong> ${po.status || 'Draft'}</div>
        </div>
        <div style="border-top:1px dashed #000;margin:6px 0"></div>
        <table style="width:100%;border-collapse:collapse;font-size:9.5px">
          <thead>
            <tr style="border-bottom:1px solid #000">
              <th style="text-align:${isAR ? 'right' : 'left'};padding:3px 0">${isAR ? 'الصنف' : 'Item'}</th>
              <th style="text-align:center;padding:3px 2px">${isAR ? 'كمية' : 'Qty'}</th>
              <th style="text-align:right;padding:3px 2px">${isAR ? 'سعر' : 'Price'}</th>
              <th style="text-align:right;padding:3px 0">${isAR ? 'الإجمالي' : 'Total'}</th>
            </tr>
          </thead>
          <tbody>
            ${lines.map(l => `
            <tr style="border-bottom:1px dashed #ddd">
              <td style="padding:3px 0"><div style="font-weight:700">${Utils.sanitize(isAR ? (l.item_name_ar || l.item_name || l.name) : (l.item_name || l.name))}</div></td>
              <td style="text-align:center;padding:3px 2px;font-weight:700">${l.quantity || l.qty}</td>
              <td style="text-align:right;padding:3px 2px">${co.currency_1 || 'USD'} ${Utils.formatCurrency(l.unit_price || l.price || 0)}</td>
              <td style="text-align:right;padding:3px 0;font-weight:800">${co.currency_1 || 'USD'} ${Utils.formatCurrency((l.quantity || l.qty) * (l.unit_price || l.price || 0))}</td>
            </tr>`).join('')}
          </tbody>
        </table>
        <div style="border-top:1px dashed #000;margin:6px 0"></div>
        <div style="font-size:10px;line-height:1.5">
          <div style="display:flex;justify-content:space-between;font-size:12px;font-weight:900;border-top:1px solid #000;border-bottom:1px solid #000;padding:3px 0;margin:3px 0">
            <span>${isAR ? 'الإجمالي العام:' : 'Grand Total:'}</span>
            <span>${co.currency_1 || 'USD'} ${Utils.formatCurrency(po.grand_total || po.total || 0)}</span>
          </div>
        </div>
        <div style="border-top:1px dashed #000;margin:8px 0;text-align:center;font-size:9px;color:#444">
          ${isAR ? 'أمر شراء إلكتروني • نظام RedShark POS' : 'Electronic PO • RedShark POS'}
        </div>
      </div>`;
      await openPrintWindow(receiptHtml, isAR ? 'أمر شراء' : 'Purchase Order', poSize);
      return;
    }

    const statusColors = { draft: '#888', sent: '#0055CC', received: '#10B981', cancelled: '#EF4444', 'partially received': '#F59E0B' };
    const statusColor = statusColors[po.status] || '#888';

    const html = `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${isAR ? 'أمر شراء' : 'Purchase Order'} ${po.po_number || '#' + po.id}</title>
  ${baseStyles()}
  <style>
    body { font-size: 13px; }
    .a4-page { width: 210mm; min-height: 297mm; margin: 0 auto; padding: 15mm; background: white; }
    .po-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 3px solid #0055CC; }
    .company-name { font-size: 26px; font-weight: 800; color: #0055CC; }
    .po-title { text-align: right; }
    .po-title h2 { font-size: 22px; font-weight: 800; color: #111; }
    .po-number { font-size: 16px; color: #0055CC; font-weight: 700; margin-top: 4px; }
    .status-badge { display: inline-block; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 700; color: white; background: ${statusColor}; margin-top: 6px; }
    .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
    .info-box { background: #f8f9fc; border-radius: 8px; padding: 12px 16px; }
    .info-box h3 { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #888; margin-bottom: 8px; }
    .info-row { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 3px; }
    .info-row span:first-child { color: #666; }
    .items-table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 12px; }
    .items-table th { background: #0055CC; color: white; padding: 8px 10px; text-align: left; font-weight: 600; }
    .items-table td { padding: 7px 10px; border-bottom: 1px solid #eee; }
    .items-table tr:nth-child(even) td { background: #f8f9fc; }
    .totals-box { width: 250px; margin-left: auto; margin-top: 12px; }
    .total-line { display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid #eee; font-size: 13px; }
    .total-line.grand { font-size: 16px; font-weight: 800; color: #0055CC; border-top: 2px solid #0055CC; padding-top: 8px; }
    .terms { margin-top: 20px; padding: 12px; background: #f8f9fc; border-radius: 6px; font-size: 11px; color: #666; }
    .footer { margin-top: 40px; display: flex; justify-content: space-between; }
    .sign-box { text-align: center; }
    .sign-line { width: 150px; border-top: 1px solid #999; margin: 40px auto 4px; }
    @media print { @page { size: A4; margin: 10mm; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="no-print print-actions">
    <button class="btn-print" onclick="window.print()">🖨 ${isAR ? 'طباعة' : 'Print'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>
  <div class="a4-page">
    <div class="po-header">
      <div>
        <div class="company-name">${Utils.sanitize(resolveCompanyName(co, isAR))}</div>
        ${co.company_address ? `<div style="color:#666;font-size:12px">${co.company_address}</div>` : ''}
        ${co.company_phone ? `<div style="color:#666;font-size:12px">${co.company_phone}</div>` : ''}
        ${co.vat_number ? `<div style="color:#666;font-size:12px">${isAR ? 'الرقم الضريبي: ' : 'VAT No: '}${co.vat_number}</div>` : ''}
      </div>
      <div class="po-title">
        <h2>${isAR ? 'أمر شراء' : 'PURCHASE ORDER'}</h2>
        <div class="po-number">${po.po_number || '#' + po.id}</div>
        <div><span class="status-badge">${(po.status || 'Draft').toUpperCase()}</span></div>
      </div>
    </div>

    <div class="info-grid">
      <div class="info-box">
        <h3>${isAR ? 'بيانات أمر الشراء' : 'Order Details'}</h3>
        <div class="info-row"><span>${isAR ? 'التاريخ:' : 'Date:'}</span><span>${date}</span></div>
        <div class="info-row"><span>${isAR ? 'تاريخ الاستلام:' : 'Expected Delivery:'}</span><span>${deliveryDate}</span></div>
        ${po.reference ? `<div class="info-row"><span>${isAR ? 'المرجع:' : 'Reference:'}</span><span>${po.reference}</span></div>` : ''}
      </div>
      <div class="info-box">
        <h3>${isAR ? 'بيانات المورد' : 'Supplier Details'}</h3>
        ${supplier ? `
          <div style="font-weight:700">${isAR ? (supplier.name_ar || supplier.name_en) : (supplier.name_en || supplier.name_ar)}</div>
          ${supplier.phone ? `<div class="info-row"><span>${isAR ? 'هاتف:' : 'Tel:'}</span><span>${supplier.phone}</span></div>` : ''}
          ${supplier.email ? `<div class="info-row"><span>${isAR ? 'بريد:' : 'Email:'}</span><span>${supplier.email}</span></div>` : ''}
          ${supplier.vat_number ? `<div class="info-row"><span>${isAR ? 'ر.ض:' : 'VAT:'}</span><span>${supplier.vat_number}</span></div>` : ''}
        ` : `<div style="color:#aaa">${isAR ? 'غير محدد' : 'Not specified'}</div>`}
      </div>
    </div>

    <table class="items-table">
      <thead>
        <tr>
          <th>#</th>
          <th>${isAR ? 'الصنف' : 'Item'}</th>
          <th style="text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>
          <th style="text-align:center">${isAR ? 'الوحدة' : 'Unit'}</th>
          <th style="text-align:right">${isAR ? 'سعر الوحدة' : 'Unit Cost'}</th>
          <th style="text-align:right">${isAR ? 'المجموع' : 'Total'}</th>
        </tr>
      </thead>
      <tbody>
        ${items.map((item, idx) => `
        <tr>
          <td>${idx + 1}</td>
          <td>
            <div style="font-weight:600">${isAR ? (item.name_ar || item.name_en || item.name) : (item.name_en || item.name_ar || item.name)}</div>
            ${item.code ? `<div style="font-size:10px;color:#888">${item.code}</div>` : ''}
          </td>
          <td style="text-align:center">${item.qty}</td>
          <td style="text-align:center">${item.unit || '-'}</td>
          <td style="text-align:right">${co.currency_1} ${Utils.formatCurrency(item.cost_price || item.price || 0)}</td>
          <td style="text-align:right;font-weight:600">${co.currency_1} ${Utils.formatCurrency(item.qty * (item.cost_price || item.price || 0))}</td>
        </tr>
        `).join('')}
      </tbody>
    </table>

    <div class="totals-box">
      <div class="total-line">
        <span>${isAR ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
        <span>${co.currency_1} ${Utils.formatCurrency(po.subtotal || 0)}</span>
      </div>
      ${po.vat_amount ? `<div class="total-line"><span>${isAR ? 'ضريبة:' : 'VAT:'}</span><span>${co.currency_1} ${Utils.formatCurrency(po.vat_amount)}</span></div>` : ''}
      <div class="total-line grand">
        <span>${isAR ? 'الإجمالي:' : 'Grand Total:'}</span>
        <span>${co.currency_1} ${Utils.formatCurrency(po.grand_total || po.total || 0)}</span>
      </div>
    </div>

    ${po.notes ? `<div class="terms"><strong>${isAR ? 'ملاحظات:' : 'Notes:'}</strong> ${po.notes}</div>` : ''}
    ${po.payment_terms ? `<div class="terms"><strong>${isAR ? 'شروط الدفع:' : 'Payment Terms:'}</strong> ${po.payment_terms}</div>` : ''}

    <div class="footer">
      <div class="sign-box">
        <div class="sign-line"></div>
        <div style="font-size:11px;color:#888">${isAR ? 'توقيع المفوض بالشراء' : 'Authorized Purchaser'}</div>
      </div>
      <div class="sign-box">
        <div class="sign-line"></div>
        <div style="font-size:11px;color:#888">${isAR ? 'توقيع المورد' : 'Supplier Signature'}</div>
      </div>
      <div class="sign-box">
        <div class="sign-line"></div>
        <div style="font-size:11px;color:#888">${isAR ? 'الموافقة' : 'Approval'}</div>
      </div>
    </div>
  </div>
</body>
</html>`;

    openPrintWindow(html, isAR ? 'أمر شراء' : 'Purchase Order', 'A4');
  }

  // ═══════════════════════════════════════════════════════════════
  // A4 PAYSLIP
  // ═══════════════════════════════════════════════════════════════
  async function printPayslip(payrollLine, employee) {
    const co = await getCompanyInfo();
    const isAR = i18n.getLang() === 'ar';
    const monthName = payrollLine.month ? new Date(payrollLine.month + '-01').toLocaleDateString('en-US', { year: 'numeric', month: 'long' }) : '-';

    const earnings = JSON.parse(payrollLine.earnings_detail || '[]');
    const deductions = JSON.parse(payrollLine.deductions_detail || '[]');
    const totalEarnings = earnings.reduce((s, e) => s + (e.amount || 0), 0);
    const totalDeductions = deductions.reduce((s, d) => s + (d.amount || 0), 0);
    const netPay = totalEarnings - totalDeductions;

    const html = `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${isAR ? 'قسيمة راتب' : 'Payslip'} — ${employee ? (isAR ? (employee.name_ar || employee.name_en) : (employee.name_en || employee.name_ar)) : ''} — ${monthName}</title>
  ${baseStyles()}
  <style>
    body { font-size: 13px; }
    .a4-page { width: 210mm; min-height: 180mm; margin: 0 auto; padding: 12mm 15mm; background: white; border: 1px solid #eee; }
    .payslip-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 3px solid #0055CC; }
    .company-name { font-size: 22px; font-weight: 800; color: #0055CC; }
    .payslip-title { text-align: right; }
    .payslip-title h2 { font-size: 18px; font-weight: 700; color: #111; }
    .payslip-title .month { color: #0055CC; font-size: 14px; font-weight: 600; }
    .emp-info { background: #f0f4ff; border-radius: 8px; padding: 12px 16px; margin-bottom: 16px; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }
    .emp-field { font-size: 12px; }
    .emp-field .label { color: #888; font-size: 10px; text-transform: uppercase; }
    .emp-field .value { font-weight: 600; margin-top: 2px; }
    .pay-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
    .pay-table { width: 100%; border-collapse: collapse; font-size: 12px; }
    .pay-table th { background: #f0f4ff; padding: 7px 10px; text-align: left; font-weight: 700; color: #0055CC; }
    .pay-table td { padding: 6px 10px; border-bottom: 1px solid #eee; }
    .pay-table .total-row td { font-weight: 700; background: #f0f4ff; }
    .net-pay { background: #0055CC; color: white; border-radius: 8px; padding: 16px; text-align: center; margin-top: 12px; }
    .net-pay .label { font-size: 11px; opacity: 0.8; text-transform: uppercase; }
    .net-pay .amount { font-size: 28px; font-weight: 800; margin-top: 4px; }
    .in-words { text-align: center; margin-top: 8px; font-size: 11px; color: #666; font-style: italic; }
    .sign-row { display: flex; justify-content: space-between; margin-top: 30px; }
    .sign-box { text-align: center; }
    .sign-line { width: 120px; border-top: 1px solid #999; margin: 30px auto 4px; }
    @media print { @page { size: A4; margin: 8mm; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="no-print print-actions">
    <button class="btn-print" onclick="window.print()">🖨 ${isAR ? 'طباعة' : 'Print'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>
  <div class="a4-page">
    <div class="payslip-header">
      <div>
        <div class="company-name">${Utils.sanitize(resolveCompanyName(co, isAR))}</div>
        ${co.company_address ? `<div style="color:#666;font-size:11px">${co.company_address}</div>` : ''}
      </div>
      <div class="payslip-title">
        <h2>${isAR ? 'قسيمة الراتب' : 'PAYSLIP'}</h2>
        <div class="month">${monthName}</div>
      </div>
    </div>

    ${employee ? `
    <div class="emp-info">
      <div class="emp-field">
        <div class="label">${isAR ? 'اسم الموظف' : 'Employee Name'}</div>
        <div class="value">${isAR ? (employee.name_ar || employee.name_en) : (employee.name_en || employee.name_ar)}</div>
      </div>
      <div class="emp-field">
        <div class="label">${isAR ? 'رقم الموظف' : 'Employee ID'}</div>
        <div class="value">${employee.employee_id || employee.id}</div>
      </div>
      <div class="emp-field">
        <div class="label">${isAR ? 'القسم' : 'Department'}</div>
        <div class="value">${employee.department || '-'}</div>
      </div>
      <div class="emp-field">
        <div class="label">${isAR ? 'المسمى الوظيفي' : 'Position'}</div>
        <div class="value">${employee.position || '-'}</div>
      </div>
      <div class="emp-field">
        <div class="label">${isAR ? 'تاريخ الالتحاق' : 'Join Date'}</div>
        <div class="value">${employee.join_date ? Utils.formatDate(employee.join_date) : '-'}</div>
      </div>
      <div class="emp-field">
        <div class="label">${isAR ? 'البنك' : 'Bank'}</div>
        <div class="value">${employee.bank_name || '-'}</div>
      </div>
    </div>
    ` : ''}

    <div class="pay-grid">
      <!-- Earnings -->
      <div>
        <table class="pay-table">
          <thead>
            <tr><th colspan="2">${isAR ? 'المستحقات' : 'Earnings'}</th></tr>
          </thead>
          <tbody>
            ${earnings.map(e => `<tr><td>${isAR ? (e.label_ar || e.label) : e.label}</td><td style="text-align:right">${co.currency_1} ${Utils.formatCurrency(e.amount)}</td></tr>`).join('')}
            <tr class="total-row">
              <td>${isAR ? 'إجمالي المستحقات' : 'Total Earnings'}</td>
              <td style="text-align:right">${co.currency_1} ${Utils.formatCurrency(totalEarnings)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- Deductions -->
      <div>
        <table class="pay-table">
          <thead>
            <tr><th colspan="2">${isAR ? 'الاستقطاعات' : 'Deductions'}</th></tr>
          </thead>
          <tbody>
            ${deductions.length ? deductions.map(d => `<tr><td>${isAR ? (d.label_ar || d.label) : d.label}</td><td style="text-align:right;color:#e55">${co.currency_1} ${Utils.formatCurrency(d.amount)}</td></tr>`).join('') : `<tr><td colspan="2" style="color:#aaa;text-align:center">${isAR ? 'لا استقطاعات' : 'No deductions'}</td></tr>`}
            <tr class="total-row">
              <td>${isAR ? 'إجمالي الاستقطاعات' : 'Total Deductions'}</td>
              <td style="text-align:right;color:#e55">${co.currency_1} ${Utils.formatCurrency(totalDeductions)}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="net-pay">
      <div class="label">${isAR ? 'صافي الراتب' : 'NET PAY'}</div>
      <div class="amount">${co.currency_1} ${Utils.formatCurrency(netPay)}</div>
    </div>

    ${payrollLine.working_days ? `<div class="in-words">${isAR ? `أيام العمل: ${payrollLine.working_days} | أيام الغياب: ${payrollLine.absent_days || 0} | ساعات إضافية: ${payrollLine.overtime_hours || 0}` : `Working Days: ${payrollLine.working_days} | Absent: ${payrollLine.absent_days || 0} | Overtime: ${payrollLine.overtime_hours || 0} hrs`}</div>` : ''}

    <div class="sign-row">
      <div class="sign-box">
        <div class="sign-line"></div>
        <div style="font-size:11px;color:#888">${isAR ? 'توقيع الموظف' : 'Employee Signature'}</div>
      </div>
      <div class="sign-box">
        <div class="sign-line"></div>
        <div style="font-size:11px;color:#888">${isAR ? 'مدير الموارد البشرية' : 'HR Manager'}</div>
      </div>
      <div class="sign-box">
        <div class="sign-line"></div>
        <div style="font-size:11px;color:#888">${isAR ? 'المدير المالي' : 'Finance Manager'}</div>
      </div>
    </div>
  </div>
</body>
</html>`;

    openPrintWindow(html, isAR ? 'قسيمة راتب' : 'Payslip', 'A4');
  }

  // ═══════════════════════════════════════════════════════════════
  // BARCODE LABEL (80mm label sheet)
  // ═══════════════════════════════════════════════════════════════
  function printBarcodeLabels(items, qty = 1) {
    const isAR = i18n.getLang() === 'ar';
    const labels = [];
    items.forEach(item => {
      for (let i = 0; i < (item._printQty || qty); i++) {
        labels.push(`
        <div class="label">
          <div class="item-name">${Utils.truncate(isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar), 24)}</div>
          ${item.barcode ? `<div class="barcode-text">||||| ${item.barcode} |||||</div>` : ''}
          <div class="barcode-num">${item.barcode || item.code || item.id}</div>
          <div class="label-footer">
            <span>${item.code || ''}</span>
            <span style="font-weight:700">${Utils.formatMoney(item.price_1 || item.price || 0)}</span>
          </div>
        </div>`);
      }
    });

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${isAR ? 'ملصقات الباركود' : 'Barcode Labels'}</title>
  ${baseStyles()}
  <style>
    body { font-size: 11px; }
    .labels-grid { display: flex; flex-wrap: wrap; gap: 4px; padding: 8px; }
    .label { width: 62mm; height: 29mm; border: 1px solid #ccc; border-radius: 3px; padding: 4px 6px; display: flex; flex-direction: column; justify-content: space-between; overflow: hidden; }
    .item-name { font-size: 9px; font-weight: 700; line-height: 1.2; }
    .barcode-text { text-align: center; font-size: 18px; letter-spacing: 3px; color: #000; }
    .barcode-num { text-align: center; font-size: 9px; color: #444; }
    .label-footer { display: flex; justify-content: space-between; font-size: 9px; }
    @media print { @page { margin: 4mm; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="no-print print-actions">
    <button class="btn-print" onclick="window.print()">🖨 ${isAR ? 'طباعة' : 'Print'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>
  <div class="labels-grid">${labels.join('')}</div>
</body>
</html>`;

    openPrintWindow(html);
  }

  // ═══════════════════════════════════════════════════════════════
  // GENERIC LIST / REPORT PRINT
  // ═══════════════════════════════════════════════════════════════
  async function printReport(title, subtitle, columns, rows, summary = null) {
    const co = await getCompanyInfo();
    const isAR = i18n.getLang() === 'ar';
    const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    const html = `<!DOCTYPE html>
<html lang="${isAR ? 'ar' : 'en'}" dir="${isAR ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  ${baseStyles()}
  <style>
    body { font-size: 12px; }
    .a4-page { width: 250mm; margin: 0 auto; padding: 12mm; background: white; }
    .report-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; padding-bottom: 10px; border-bottom: 2px solid #0055CC; }
    .report-title h1 { font-size: 18px; font-weight: 800; color: #0055CC; }
    .report-title p { color: #888; font-size: 11px; margin-top: 4px; }
    .data-table { width: 100%; border-collapse: collapse; font-size: 11px; }
    .data-table th { background: #0055CC; color: white; padding: 6px 8px; font-weight: 600; white-space: nowrap; }
    .data-table td { padding: 5px 8px; border-bottom: 1px solid #eee; }
    .data-table tr:nth-child(even) td { background: #f8f9fc; }
    .summary-box { background: #f0f4ff; border-radius: 6px; padding: 12px 16px; margin-top: 16px; display: flex; flex-wrap: wrap; gap: 20px; }
    .summary-item .label { font-size: 10px; color: #888; text-transform: uppercase; }
    .summary-item .value { font-size: 16px; font-weight: 700; color: #0055CC; margin-top: 2px; }
    .report-footer { margin-top: 20px; padding-top: 10px; border-top: 1px solid #eee; display: flex; justify-content: space-between; font-size: 10px; color: #aaa; }
    @media print { @page { size: A4 landscape; margin: 8mm; } .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="no-print print-actions">
    <button class="btn-print" onclick="window.print()">🖨 ${isAR ? 'طباعة' : 'Print'}</button>
    <button class="btn-close" onclick="window.close()">✕ ${isAR ? 'إغلاق' : 'Close'}</button>
  </div>
  <div class="a4-page">
    <div class="report-header">
      <div class="report-title">
        <h1>${title}</h1>
        ${subtitle ? `<p>${subtitle}</p>` : ''}
      </div>
      <div style="text-align:right">
        <div style="font-weight:700;font-size:14px">${Utils.sanitize(resolveCompanyName(co, isAR))}</div>
        <div style="color:#888;font-size:11px">${isAR ? 'تاريخ التقرير:' : 'Report Date:'} ${date}</div>
        <div style="color:#888;font-size:11px">${isAR ? 'عدد السجلات:' : 'Records:'} ${rows.length}</div>
      </div>
    </div>

    <table class="data-table">
      <thead>
        <tr>${columns.map(c => `<th${c.align ? ` style="text-align:${c.align}"` : ''}>${c.label}</th>`).join('')}</tr>
      </thead>
      <tbody>
        ${rows.map(row => `<tr>${columns.map(c => `<td${c.align ? ` style="text-align:${c.align}"` : ''}>${c.render ? c.render(row) : (row[c.key] ?? '-')}</td>`).join('')}</tr>`).join('')}
      </tbody>
    </table>

    ${summary ? `<div class="summary-box">${Object.entries(summary).map(([k, v]) => `<div class="summary-item"><div class="label">${k}</div><div class="value">${v}</div></div>`).join('')}</div>` : ''}

    <div class="report-footer">
      <div>${isAR ? 'تم إنشاء التقرير إلكترونياً' : 'Electronically Generated Report'}</div>
      <div>${date}</div>
    </div>
  </div>
</body>
</html>`;

    openPrintWindow(html, title, 'A4');
  }

  // ── Payment label helpers ───────────────────────────────────────
  function _paymentLabelEN(method) {
    const map = { cash: 'Cash', card: 'Card', cheque: 'Cheque', credit: 'On Account', transfer: 'Bank Transfer', voucher: 'Voucher', mixed: 'Mixed' };
    return map[method] || method || 'Cash';
  }
  function _paymentLabelAR(method) {
    const map = { cash: 'نقداً', card: 'بطاقة', cheque: 'شيك', credit: 'على الحساب', transfer: 'تحويل', voucher: 'قسيمة', mixed: 'مختلط' };
    return map[method] || method || 'نقداً';
  }

  // ── Public API ─────────────────────────────────────────────────
  return {
    printReceipt,
    printInvoice,
    generateReceiptHtml,
    generateInvoiceHtml,
    printPurchaseOrder,
    printPayslip,
    printBarcodeLabels,
    printReport,
    openPrintWindow
  };

})();

window.PrintEngine = PrintEngine;
window.PrintModule = PrintEngine;
