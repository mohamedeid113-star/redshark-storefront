/* ================================================================
   NexPOS — Inventory Module (Adjustment, Damage, Transfer, Barcode)
   ================================================================ */

const InventoryMgr = (() => {

  // ── Stock Adjustment ──────────────────────────────────────────
  // ── Stock Adjustment & Movements ──────────────────────────────
  let _invActiveTab = 'adjustments';

  async function renderAdjustment(container, activeTab = 'adjustments') {
    _invActiveTab = activeTab;
    const adjustments = (await DB.getAll('stock_adjustments')) || [];
    const movements   = (await DB.getAll('stock_movements')) || [];
    const items       = (await DB.getAll('items')) || [];
    const itemMap     = new Map(items.map(i => [i.id, i]));
    const isAR        = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'إدارة المخزون والحركات' : 'Stock Adjustments & Movements'}</h1>
          <p>${isAR ? 'سجل التسويات الجردية وكافة حركات الأصناف من مبيعات ومشتريات وتحويلات' : 'Inventory adjustments log and comprehensive stock movement ledger'}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="InventoryMgr.openAdjForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'تعديل مخزون جديد' : 'New Adjustment'}
          </button>
        </div>
      </div>

      <!-- Navigation Tabs: Manual Adjustments vs All Stock Movements vs Physical Audit -->
      <div style="display:flex;gap:10px;margin-bottom:16px;border-bottom:2px solid var(--border-color);padding-bottom:10px;flex-wrap:wrap">
        <button class="btn ${_invActiveTab === 'adjustments' ? 'btn-primary' : 'btn-secondary'}" id="inv-tab-adj" onclick="InventoryMgr.switchTab('adjustments')">
          📑 ${isAR ? 'التسويات والتعديلات الفردية' : 'Single Adjustments'} (${adjustments.length})
        </button>
        <button class="btn ${_invActiveTab === 'audit' ? 'btn-primary' : 'btn-secondary'}" id="inv-tab-audit" onclick="InventoryMgr.switchTab('audit')">
          📋 ${isAR ? 'الجرد المخزني الفعلي ومطابقة العجز والزيادة' : 'Physical Stock Audit & Count'}
        </button>
        <button class="btn ${_invActiveTab === 'movements' ? 'btn-primary' : 'btn-secondary'}" id="inv-tab-mov" onclick="InventoryMgr.switchTab('movements')">
          🔄 ${isAR ? 'كافة حركات المخزون الشاملة' : 'All Stock Movements'} (${movements.length})
        </button>
      </div>

      <!-- TAB 1: Manual Adjustments -->
      <div id="inv-view-adjustments" style="display:${_invActiveTab === 'adjustments' ? 'block' : 'none'}">
        <div class="table-wrapper card">
          <table>
            <thead><tr>
              <th>${isAR?'الرقم':'Ref'}</th>
              <th>${isAR?'التاريخ':'Date'}</th>
              <th>${isAR?'النوع':'Type'}</th>
              <th>${isAR?'الصنف':'Item'}</th>
              <th>${isAR?'الكمية':'Qty'}</th>
              <th>${isAR?'الرصيد الجديد':'New Stock'}</th>
              <th>${isAR?'السبب':'Reason'}</th>
              <th>${isAR?'ملاحظات':'Notes'}</th>
            </tr></thead>
            <tbody>
              ${adjustments.slice().reverse().map(a => `
              <tr>
                <td style="font-weight:700;color:var(--primary)">${a.ref || '-'}</td>
                <td style="font-size:0.78rem">${Utils.formatDate(a.created_at || a.date)}</td>
                <td><span class="badge badge-${a.type==='in'?'success':a.type==='set'?'warning':'danger'}">${a.type==='in'?(isAR?'وارد (+)':'Stock In (+)'):a.type==='set'?(isAR?'ضبط':'Set'):(isAR?'صادر (-)':'Stock Out (-)')}</span></td>
                <td style="font-weight:600">${Utils.truncate(a.item_name || (itemMap.get(a.item_id)?.name_en) || '-', 28)}</td>
                <td style="font-weight:800;color:${a.type==='in'?'var(--success)':a.type==='set'?'var(--warning)':'var(--danger)'}">${a.type==='in'?'+':(a.type==='out'?'-':'')}${a.qty}</td>
                <td style="font-weight:700">${a.new_qty !== undefined ? a.new_qty : '-'}</td>
                <td><span class="badge badge-secondary" style="font-size:0.72rem">${a.reason || '-'}</span></td>
                <td style="font-size:0.75rem;color:var(--text-muted)">${a.notes || '-'}</td>
              </tr>`).join('') || `<tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد تعديلات يدوية مسجلة':'No manual adjustments recorded'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>

      <!-- TAB 2: Physical Stock Take & Audit Worksheet -->
      <div id="inv-view-audit" style="display:${_invActiveTab === 'audit' ? 'block' : 'none'}">
        <div class="card mb-3" style="padding:16px;background:var(--surface)">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:10px">
            <div>
              <h3 style="margin:0;font-size:1.1rem;font-weight:800">📋 ${isAR ? 'ورقة الجرد الدوري ومطابقة الأرصدة' : 'Periodic Stock Take & Reconciliation'}</h3>
              <p style="margin:2px 0 0;font-size:0.8rem;color:var(--text-muted)">${isAR ? 'أدخل الكميات المجرودة فعلياً أو استخدم قارئ الباركود، وسيقوم النظام باحتساب الفروقات وتسويتها آلياً' : 'Enter counted quantities or scan barcodes; the system calculates variances and auto-adjusts stock'}</p>
            </div>
            <div style="display:flex;gap:8px">
              <button class="btn btn-secondary btn-sm" onclick="InventoryMgr.printBlankAuditSheet()">
                🖨️ ${isAR ? 'طباعة كشف جرد ورقي' : 'Print Blank Count Sheet'}
              </button>
              <button class="btn btn-success" onclick="InventoryMgr.reconcileAllAudit()" style="font-weight:800">
                💾 ${isAR ? 'اعتماد الجرد وتسوية الفروقات' : 'Post & Reconcile All Adjustments'}
              </button>
            </div>
          </div>

          <div class="grid grid-3" style="gap:10px;margin-bottom:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label" style="font-size:0.75rem">${isAR ? '📷 مسح الباركود أثناء الجرد (سريع)' : '📷 Live Barcode Scanner (+1 Count)'}</label>
              <input type="text" class="form-control" id="audit-scan-input" placeholder="${isAR ? 'امسح الباركود لزيادة العدد +1...' : 'Scan barcode to increment count...'}" onkeydown="if(event.key==='Enter') InventoryMgr.handleAuditScan(this.value)">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'المستودع / الفرع' : 'Warehouse / Store'}</label>
              <select class="form-control" id="audit-wh-select" onchange="InventoryMgr.buildAuditTable()">
                <!-- Warehouses -->
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'تصفية بالتصنيف' : 'Filter by Category'}</label>
              <select class="form-control" id="audit-cat-select" onchange="InventoryMgr.buildAuditTable()">
                <option value="">${isAR ? 'كافة التصنيفات (All)' : 'All Categories'}</option>
              </select>
            </div>
          </div>
        </div>

        <div class="table-wrapper card" style="max-height:550px;overflow-y:auto">
          <table>
            <thead style="position:sticky;top:0;background:var(--surface);z-index:2">
              <tr>
                <th>${isAR ? 'الرمز / الباركود' : 'Code / Barcode'}</th>
                <th>${isAR ? 'الصنف' : 'Item Name'}</th>
                <th style="text-align:center">${isAR ? 'الرصيد الدفتري (النظام)' : 'Book Stock (System)'}</th>
                <th style="text-align:center;width:170px">${isAR ? 'العدد الفعلي بالجرد' : 'Physical Count'}</th>
                <th style="text-align:center">${isAR ? 'الفارق (عجز / زيادة)' : 'Variance (Diff)'}</th>
                <th style="text-align:right">${isAR ? 'قيمة الفارق' : 'Variance Value'}</th>
              </tr>
            </thead>
            <tbody id="audit-tbody">
              <!-- Populated by buildAuditTable -->
            </tbody>
          </table>
        </div>

        <!-- Audit Summary Bar -->
        <div id="audit-summary-bar" class="card mt-3" style="padding:14px;background:var(--surface-2);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div style="font-size:0.85rem">
            <span style="font-weight:700" id="audit-stat-items">0 ${isAR ? 'صنف' : 'items'}</span> | 
            <span style="color:var(--danger);font-weight:700" id="audit-stat-missing">0 ${isAR ? 'عجز' : 'shortage'}</span> | 
            <span style="color:var(--success);font-weight:700" id="audit-stat-surplus">0 ${isAR ? 'زيادة' : 'surplus'}</span>
          </div>
          <div style="display:flex;align-items:center;gap:12px">
            <span style="font-size:0.9rem;font-weight:800">${isAR ? 'صافي قيمة الفروقات:' : 'Net Variance Value:'}</span>
            <span id="audit-stat-netval" style="font-size:1.1rem;font-weight:900;color:var(--primary)">$0.00</span>
          </div>
        </div>
      </div>

      <!-- TAB 3: All Stock Movements Ledger -->
      <div id="inv-view-movements" style="display:${_invActiveTab === 'movements' ? 'block' : 'none'}">
        <div class="card mb-3" style="padding:14px">
          <div class="grid grid-3" style="gap:10px">
            <div class="form-group" style="margin:0">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'بحث بالصنف أو الرقم' : 'Search Item or Ref'}</label>
              <input type="text" class="form-control" id="mov-filter-q" placeholder="${isAR ? 'اكتب اسم الصنف أو الرقم المرجعي...' : 'Search item name, code, ref...'}" oninput="InventoryMgr.filterMovementsTable()">
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label" style="font-size:0.75rem">${isAR ? 'نوع الحركة' : 'Movement Type'}</label>
              <select class="form-control" id="mov-filter-type" onchange="InventoryMgr.filterMovementsTable()">
                <option value="">${isAR ? '⚡ كافة الحركات (All)' : '⚡ All Movement Types'}</option>
                <option value="sale">${isAR ? '🛒 مبيعات (Sale)' : '🛒 Sale'}</option>
                <option value="return">${isAR ? '🔄 مرتجع مبيعات (Return)' : '🔄 Sales Return'}</option>
                <option value="purchase">${isAR ? '🚚 مشتريات (Purchase / GRN)' : '🚚 Purchase / GRN'}</option>
                <option value="adjustment">${isAR ? '📑 تسوية جرد (Adjustment)' : '📑 Adjustment'}</option>
                <option value="transfer">${isAR ? '🏬 تحويل مخزني (Transfer)' : '🏬 Transfer'}</option>
                <option value="damage">${isAR ? '⚠️ تالف / هدر (Damage)' : '⚠️ Damage / Write-off'}</option>
              </select>
            </div>
            <div class="form-group" style="margin:0;display:flex;align-items:flex-end">
              <button class="btn btn-secondary" onclick="InventoryMgr.exportMovementsCSV()" style="width:100%">
                📥 ${isAR ? 'تصدير الحركات (CSV)' : 'Export Movements (CSV)'}
              </button>
            </div>
          </div>
        </div>

        <div class="table-wrapper card">
          <table>
            <thead><tr>
              <th>${isAR?'الرقم المرجعي':'Ref'}</th>
              <th>${isAR?'التاريخ':'Date'}</th>
              <th>${isAR?'نوع الحركة':'Movement Type'}</th>
              <th>${isAR?'الصنف':'Item'}</th>
              <th>${isAR?'الكمية (وارد / صادر)':'Quantity (In / Out)'}</th>
              <th>${isAR?'البيان / ملاحظات':'Notes & Description'}</th>
            </tr></thead>
            <tbody id="mov-tbody">
              <!-- populated dynamically -->
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Adjustment Modal -->
    <div class="modal-overlay" id="adj-modal">
      <div class="modal" style="max-width:520px">
        <div class="modal-header">
          <div class="modal-title">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
            ${isAR ? 'تسوية وتعديل المخزون' : 'Stock Adjustment'}
          </div>
          <button class="btn-icon" onclick="Utils.closeModal('adj-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="form-label">${isAR ? 'الصنف' : 'Item'} *</label>
            <select class="form-control" id="adj-item">
              <option value="">-- ${isAR ? 'اختر صنفاً' : 'Select Item'} --</option>
            </select>
          </div>
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR ? 'نوع التعديل' : 'Adjustment Type'}</label>
              <select class="form-control" id="adj-type">
                <option value="in">${isAR ? 'وارد (+)' : 'Stock In (+)'}</option>
                <option value="out">${isAR ? 'صادر (-)' : 'Stock Out (-)'}</option>
                <option value="set">${isAR ? 'ضبط الكمية إلى' : 'Set Exact Quantity'}</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR ? 'الكمية' : 'Quantity'} *</label>
              <input type="number" class="form-control" id="adj-qty" placeholder="0" min="0" step="0.001" value="1">
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'سبب التعديل' : 'Adjustment Reason'}</label>
            <select class="form-control" id="adj-reason">
              <option value="opening">${isAR ? 'رصيد افتتاحي (Opening Stock)' : 'Opening Stock'}</option>
              <option value="found">${isAR ? 'بضاعة معثور عليها (Found / Discovered)' : 'Found / Discovered'}</option>
              <option value="loss">${isAR ? 'فقدان / عجز جرد (Loss / Missing)' : 'Loss / Missing'}</option>
              <option value="damage">${isAR ? 'تلف بضاعة (Damaged)' : 'Damaged'}</option>
              <option value="correction">${isAR ? 'تصحيح رصيد (Correction)' : 'Correction'}</option>
              <option value="other">${isAR ? 'أخرى (Other)' : 'Other'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'ملاحظات' : 'Notes'}</label>
            <textarea class="form-control" id="adj-notes" rows="2" placeholder="${isAR?'ملاحظات توضيحية عن سبب التسوية...':'Notes explaining the adjustment...'}"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('adj-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="InventoryMgr.saveAdjustment()">${isAR?'حفظ التسوية':'Save Adjustment'}</button>
        </div>
      </div>
    </div>`;

    // Load items for modal select
    const sel = document.getElementById('adj-item');
    items.forEach(i => {
      const opt = document.createElement('option');
      opt.value = i.id;
      opt.textContent = `[${i.item_code||''}] ${isAR ? (i.name_ar||i.name_en) : (i.name_en||i.name_ar)} (${isAR?'المخزون':'Stock'}: ${i.stock_qty||0})`;
      sel.appendChild(opt);
    });

    window._allMovementsData = movements;
    window._allItemsMap = itemMap;
    window._allAuditItems = items;
    await initStockAudit();
    filterMovementsTable();
  }

  async function initStockAudit() {
    const isAR = i18n.getLang() === 'ar';
    const warehouses = (await DB.getAll('warehouses')) || [];
    const categories = (await DB.getAll('categories')) || [];

    const whSel = document.getElementById('audit-wh-select');
    if (whSel) {
      whSel.innerHTML = warehouses.map(w => `
        <option value="${w.id}" ${w.is_default ? 'selected' : ''}>${isAR ? (w.name_ar || w.name) : (w.name || w.name_ar)}</option>
      `).join('') || `<option value="1">${isAR ? 'المستودع الرئيسي' : 'Main Store'}</option>`;
    }

    const catSel = document.getElementById('audit-cat-select');
    if (catSel) {
      catSel.innerHTML = `<option value="">${isAR ? '⚡ كافة التصنيفات (All)' : '⚡ All Categories'}</option>` +
        categories.map(c => `<option value="${c.id}">${isAR ? (c.name_ar || c.name || c.name_en) : (c.name_en || c.name || c.name_ar)}</option>`).join('');
    }

    buildAuditTable();
  }

  function buildAuditTable() {
    const isAR = i18n.getLang() === 'ar';
    const tbody = document.getElementById('audit-tbody');
    if (!tbody) return;

    const items = window._allAuditItems || [];
    const whId = parseInt(document.getElementById('audit-wh-select')?.value) || 1;
    const catId = document.getElementById('audit-cat-select')?.value;

    const filtered = items.filter(i => {
      if (i.status === 'inactive') return false;
      if (catId && String(i.category_id) !== String(catId)) return false;
      return true;
    });

    tbody.innerHTML = filtered.map(item => {
      const name = isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar);
      const bookStock = (item.warehouse_stocks && item.warehouse_stocks[whId] !== undefined)
        ? (parseFloat(item.warehouse_stocks[whId]) || 0)
        : (parseFloat(item.stock_qty) || 0);
      const cost = parseFloat(item.cost_price) || 0;

      return `
      <tr id="audit-row-${item.id}" data-item-id="${item.id}" data-book-stock="${bookStock}" data-cost="${cost}">
        <td style="font-family:monospace;font-size:0.8rem;font-weight:700;color:var(--primary)">${item.barcode || item.item_code || '-'}</td>
        <td style="font-weight:600">${Utils.sanitize(name)}</td>
        <td style="text-align:center;font-weight:800;font-size:0.9rem">${bookStock}</td>
        <td style="text-align:center">
          <div style="display:inline-flex;align-items:center;gap:4px">
            <button type="button" class="btn btn-secondary btn-sm" onclick="InventoryMgr.stepAuditCount(${item.id}, -1)" style="padding:2px 8px;font-weight:900">−</button>
            <input type="number" class="form-control" id="audit-input-${item.id}" value="${bookStock}" min="0" step="1"
              style="width:75px;text-align:center;font-weight:800;padding:4px"
              oninput="InventoryMgr.updateAuditRow(${item.id})">
            <button type="button" class="btn btn-secondary btn-sm" onclick="InventoryMgr.stepAuditCount(${item.id}, 1)" style="padding:2px 8px;font-weight:900">+</button>
          </div>
        </td>
        <td style="text-align:center" id="audit-variance-${item.id}">
          <span class="badge badge-secondary" style="font-size:0.8rem">0</span>
        </td>
        <td style="text-align:right;font-weight:700;font-size:0.85rem" id="audit-val-${item.id}">
          $0.00
        </td>
      </tr>`;
    }).join('') || `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد أصناف مطابقة' : 'No items found'}</td></tr>`;

    recalcAuditSummary();
  }

  function stepAuditCount(itemId, delta) {
    const input = document.getElementById(`audit-input-${itemId}`);
    if (!input) return;
    const current = parseFloat(input.value) || 0;
    input.value = Math.max(0, current + delta);
    updateAuditRow(itemId);
  }

  function handleAuditScan(rawVal) {
    const val = (rawVal || '').trim();
    if (!val) return;
    const isAR = i18n.getLang() === 'ar';
    const items = window._allAuditItems || [];
    const match = items.find(i => (i.barcode && i.barcode.toLowerCase() === val.toLowerCase()) || (i.item_code && i.item_code.toLowerCase() === val.toLowerCase()));

    const scanInput = document.getElementById('audit-scan-input');
    if (scanInput) { scanInput.value = ''; scanInput.focus(); }

    if (!match) {
      Utils.toast(isAR ? `الصنف بالرمز ${val} غير موجود!` : `Item ${val} not found!`, 'warning');
      return;
    }

    const row = document.getElementById(`audit-row-${match.id}`);
    if (row) {
      row.scrollIntoView({ behavior: 'smooth', block: 'center' });
      row.style.background = 'rgba(59,130,246,0.15)';
      setTimeout(() => { row.style.background = ''; }, 1200);
      stepAuditCount(match.id, 1);
      Utils.toast(isAR ? `تم عد +1 للصنف: ${match.name_ar || match.name_en}` : `Counted +1 for: ${match.name_en || match.name_ar}`, 'success');
      if (window.AICopilot && typeof AICopilot.playAudio === 'function') {
        AICopilot.playAudio('scan');
      }
    }
  }

  function updateAuditRow(itemId) {
    const row = document.getElementById(`audit-row-${itemId}`);
    if (!row) return;

    const bookStock = parseFloat(row.dataset.bookStock) || 0;
    const cost = parseFloat(row.dataset.cost) || 0;
    const physical = parseFloat(document.getElementById(`audit-input-${itemId}`)?.value) || 0;
    const diff = physical - bookStock;
    const valDiff = diff * cost;

    const varEl = document.getElementById(`audit-variance-${itemId}`);
    const valEl = document.getElementById(`audit-val-${itemId}`);

    if (diff === 0) {
      if (varEl) varEl.innerHTML = `<span class="badge badge-secondary" style="font-size:0.8rem">0</span>`;
      if (valEl) { valEl.textContent = '$0.00'; valEl.style.color = 'var(--text-muted)'; }
    } else if (diff < 0) {
      if (varEl) varEl.innerHTML = `<span class="badge badge-danger" style="font-size:0.8rem">عجز: ${diff}</span>`;
      if (valEl) { valEl.textContent = `-$${Math.abs(valDiff).toFixed(2)}`; valEl.style.color = 'var(--danger)'; }
    } else {
      if (varEl) varEl.innerHTML = `<span class="badge badge-success" style="font-size:0.8rem">زيادة: +${diff}</span>`;
      if (valEl) { valEl.textContent = `+$${valDiff.toFixed(2)}`; valEl.style.color = 'var(--success)'; }
    }

    recalcAuditSummary();
  }

  function recalcAuditSummary() {
    const isAR = i18n.getLang() === 'ar';
    const rows = document.querySelectorAll('#audit-tbody tr[id^="audit-row-"]');
    let totalItems = 0;
    let missingCount = 0;
    let surplusCount = 0;
    let netVarianceValue = 0;

    rows.forEach(row => {
      totalItems++;
      const itemId = row.dataset.itemId;
      const bookStock = parseFloat(row.dataset.bookStock) || 0;
      const cost = parseFloat(row.dataset.cost) || 0;
      const physical = parseFloat(document.getElementById(`audit-input-${itemId}`)?.value) || 0;
      const diff = physical - bookStock;

      if (diff < 0) missingCount++;
      if (diff > 0) surplusCount++;
      netVarianceValue += (diff * cost);
    });

    const statItems = document.getElementById('audit-stat-items');
    const statMiss  = document.getElementById('audit-stat-missing');
    const statSurp  = document.getElementById('audit-stat-surplus');
    const statVal   = document.getElementById('audit-stat-netval');

    if (statItems) statItems.textContent = `${totalItems} ${isAR ? 'صنف بالجرد' : 'items in audit'}`;
    if (statMiss)  statMiss.textContent  = `${missingCount} ${isAR ? 'صنف به عجز' : 'shortage'}`;
    if (statSurp)  statSurp.textContent  = `${surplusCount} ${isAR ? 'صنف به زيادة' : 'surplus'}`;
    if (statVal) {
      statVal.textContent = (netVarianceValue >= 0 ? '+' : '') + `$${netVarianceValue.toFixed(2)}`;
      statVal.style.color = netVarianceValue === 0 ? 'var(--text-muted)' : (netVarianceValue > 0 ? 'var(--success)' : 'var(--danger)');
    }
  }

  async function reconcileAllAudit() {
    const isAR = i18n.getLang() === 'ar';
    const rows = document.querySelectorAll('#audit-tbody tr[id^="audit-row-"]');
    const whId = parseInt(document.getElementById('audit-wh-select')?.value) || 1;
    const discrepancies = [];

    rows.forEach(row => {
      const itemId = parseInt(row.dataset.itemId);
      const bookStock = parseFloat(row.dataset.bookStock) || 0;
      const physical = parseFloat(document.getElementById(`audit-input-${itemId}`)?.value) || 0;
      const diff = physical - bookStock;
      if (diff !== 0) {
        discrepancies.push({ itemId, bookStock, physical, diff });
      }
    });

    if (discrepancies.length === 0) {
      Utils.toast(isAR ? 'المخزون الفعلي مطابق تماماً للرصيد الدفتري، لا توجد فروقات للتسوية' : 'No discrepancies found! Physical count matches book stock perfectly.', 'info');
      return;
    }

    const confirmMsg = isAR
      ? `هل أنت متأكد من اعتماد الجرد؟ سيتم تسوية وتحديث أرصدة ${discrepancies.length} صنف تلقائياً.`
      : `Are you sure you want to reconcile? ${discrepancies.length} items with discrepancies will be adjusted.`;

    if (!confirm(confirmMsg)) return;

    const nowIso = new Date().toISOString();
    for (const d of discrepancies) {
      const item = await DB.get('items', d.itemId);
      if (!item) continue;

      const isShortage = d.diff < 0;
      const adjType = isShortage ? 'out' : 'in';
      const adjQty = Math.abs(d.diff);
      const reason = isShortage ? 'loss' : 'found';
      const notes = isAR ? `تسوية جرد دوري (كان: ${d.bookStock}, الفعلي: ${d.physical})` : `Audit reconciliation (Was: ${d.bookStock}, Counted: ${d.physical})`;

      const ref = await DB.nextSeq('stock_adjustments', 'ADJ-', 5);
      await DB.add('stock_adjustments', {
        ref,
        item_id: item.id,
        item_name: isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar),
        type: adjType,
        qty: adjQty,
        new_qty: d.physical,
        reason: reason,
        notes: notes,
        created_at: nowIso
      });

      await DB.add('stock_movements', {
        item_id: item.id,
        type: 'adjustment',
        ref: ref,
        qty: d.diff,
        notes: notes,
        created_at: nowIso
      });

      if (!item.warehouse_stocks) item.warehouse_stocks = {};
      item.warehouse_stocks[whId] = d.physical;
      item.stock_qty = Object.values(item.warehouse_stocks).reduce((sum, v) => sum + (parseFloat(v) || 0), 0);
      await DB.update('items', item);
    }

    Utils.toast(isAR ? `✅ تم بنجاح اعتماد الجرد وتسوية فروقات ${discrepancies.length} صنف!` : `Successfully reconciled ${discrepancies.length} items!`, 'success');
    await renderAdjustment(document.getElementById('page-content'), 'audit');
  }

  function printBlankAuditSheet() {
    const isAR = i18n.getLang() === 'ar';
    const items = window._allAuditItems || [];
    const whSel = document.getElementById('audit-wh-select');
    const whName = whSel ? whSel.options[whSel.selectedIndex]?.text : '';
    const dateStr = Utils.formatDate(new Date());

    const html = `
    <div style="font-family:Arial,sans-serif;direction:${isAR?'rtl':'ltr'};padding:20px">
      <div style="text-align:center;margin-bottom:20px">
        <h2>${isAR ? '📋 كشف الجرد المخزني الفعلي' : '📋 Physical Inventory Count Sheet'}</h2>
        <div style="font-size:0.9rem;color:#555">
          <span>${isAR ? 'المستودع / الفرع:' : 'Store / Warehouse:'} <b>${whName}</b></span> | 
          <span>${isAR ? 'التاريخ:' : 'Date:'} <b>${dateStr}</b></span>
        </div>
      </div>
      <table style="width:100%;border-collapse:collapse;font-size:0.85rem">
        <thead>
          <tr style="background:#f1f5f9;border-bottom:2px solid #cbd5e1">
            <th style="padding:8px;border:1px solid #cbd5e1">#</th>
            <th style="padding:8px;border:1px solid #cbd5e1">${isAR ? 'الرمز / الباركود' : 'Item Code / Barcode'}</th>
            <th style="padding:8px;border:1px solid #cbd5e1">${isAR ? 'اسم الصنف' : 'Item Name'}</th>
            <th style="padding:8px;border:1px solid #cbd5e1;text-align:center">${isAR ? 'الرصيد الدفتري' : 'Book Stock'}</th>
            <th style="padding:8px;border:1px solid #cbd5e1;text-align:center;width:120px">${isAR ? 'العدد الفعلي (قلم)' : 'Physical Count'}</th>
            <th style="padding:8px;border:1px solid #cbd5e1">${isAR ? 'ملاحظات' : 'Notes'}</th>
          </tr>
        </thead>
        <tbody>
          ${items.map((it, idx) => `
          <tr style="border-bottom:1px solid #e2e8f0">
            <td style="padding:6px;border:1px solid #cbd5e1;text-align:center">${idx + 1}</td>
            <td style="padding:6px;border:1px solid #cbd5e1;font-family:monospace">${it.barcode || it.item_code || '-'}</td>
            <td style="padding:6px;border:1px solid #cbd5e1;font-weight:bold">${isAR ? (it.name_ar || it.name_en) : (it.name_en || it.name_ar)}</td>
            <td style="padding:6px;border:1px solid #cbd5e1;text-align:center">${it.stock_qty || 0}</td>
            <td style="padding:6px;border:1px solid #cbd5e1;height:28px"></td>
            <td style="padding:6px;border:1px solid #cbd5e1"></td>
          </tr>`).join('')}
        </tbody>
      </table>
      <div style="margin-top:40px;display:flex;justify-content:space-between">
        <div>${isAR ? 'توقيع مسؤول الجرد:' : 'Auditor Signature:'} ____________________</div>
        <div>${isAR ? 'اعتماد مدير المستودع:' : 'Manager Approval:'} ____________________</div>
      </div>
    </div>`;

    Utils.printElement(html, 'Physical Stocktake Sheet');
  }

  function switchTab(tab) {
    _invActiveTab = tab;
    const isAR = i18n.getLang() === 'ar';
    const btnAdj = document.getElementById('inv-tab-adj');
    const btnAudit = document.getElementById('inv-tab-audit');
    const btnMov = document.getElementById('inv-tab-mov');
    const viewAdj = document.getElementById('inv-view-adjustments');
    const viewAudit = document.getElementById('inv-view-audit');
    const viewMov = document.getElementById('inv-view-movements');

    if (btnAdj) btnAdj.className = `btn ${tab === 'adjustments' ? 'btn-primary' : 'btn-secondary'}`;
    if (btnAudit) btnAudit.className = `btn ${tab === 'audit' ? 'btn-primary' : 'btn-secondary'}`;
    if (btnMov) btnMov.className = `btn ${tab === 'movements' ? 'btn-primary' : 'btn-secondary'}`;

    if (viewAdj) viewAdj.style.display = tab === 'adjustments' ? 'block' : 'none';
    if (viewAudit) viewAudit.style.display = tab === 'audit' ? 'block' : 'none';
    if (viewMov) viewMov.style.display = tab === 'movements' ? 'block' : 'none';
  }

  function filterMovementsTable() {
    const isAR = i18n.getLang() === 'ar';
    const tbody = document.getElementById('mov-tbody');
    if (!tbody) return;

    const q = (document.getElementById('mov-filter-q')?.value || '').trim().toLowerCase();
    const filterType = (document.getElementById('mov-filter-type')?.value || '').trim().toLowerCase();

    const movements = window._allMovementsData || [];
    const itemMap = window._allItemsMap || new Map();

    const filtered = movements.filter(m => {
      const itm = itemMap.get(m.item_id);
      const nameEn = (itm?.name_en || '').toLowerCase();
      const nameAr = (itm?.name_ar || '').toLowerCase();
      const code = (itm?.item_code || itm?.code || '').toLowerCase();
      const ref = (m.ref || '').toLowerCase();
      const notes = (m.notes || '').toLowerCase();

      const matchQ = !q || nameEn.includes(q) || nameAr.includes(q) || code.includes(q) || ref.includes(q) || notes.includes(q);
      const matchType = !filterType || (m.type || '').toLowerCase() === filterType;
      return matchQ && matchType;
    });

    const typeBadges = {
      sale:       { cls: 'badge-primary', label: isAR ? '🛒 بيع' : 'Sale' },
      return:     { cls: 'badge-warning', label: isAR ? '🔄 مرتجع' : 'Return' },
      purchase:   { cls: 'badge-success', label: isAR ? '🚚 توريد' : 'Purchase' },
      adjustment: { cls: 'badge-secondary', label: isAR ? '📑 تسوية' : 'Adjustment' },
      transfer:   { cls: 'badge-info', label: isAR ? '🏬 تحويل' : 'Transfer' },
      damage:     { cls: 'badge-danger', label: isAR ? '⚠️ تالف' : 'Damage' }
    };

    tbody.innerHTML = filtered.slice().reverse().map(m => {
      const itm = itemMap.get(m.item_id);
      const itemName = isAR ? (itm?.name_ar || itm?.name_en || '-') : (itm?.name_en || itm?.name_ar || '-');
      const bInfo = typeBadges[m.type] || { cls: 'badge-secondary', label: m.type };
      const qtyVal = parseFloat(m.qty) || 0;
      const isPositive = qtyVal > 0;

      return `
      <tr>
        <td style="font-weight:700;color:var(--primary)">${m.ref || '-'}</td>
        <td style="font-size:0.78rem">${Utils.formatDate(m.created_at || m.date)}</td>
        <td><span class="badge ${bInfo.cls}">${bInfo.label}</span></td>
        <td style="font-weight:600">${Utils.truncate(itemName, 30)}</td>
        <td style="font-weight:800;color:${isPositive ? 'var(--success)' : 'var(--danger)'}">
          ${isPositive ? '+' : ''}${qtyVal}
        </td>
        <td style="font-size:0.75rem;color:var(--text-muted)">${m.notes || '-'}</td>
      </tr>`;
    }).join('') || `<tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR ? 'لا توجد حركات مطابقة' : 'No matching movements found'}</td></tr>`;
  }

  function exportMovementsCSV() {
    const movements = window._allMovementsData || [];
    const itemMap = window._allItemsMap || new Map();
    Utils.exportCSV(movements.map(m => {
      const itm = itemMap.get(m.item_id);
      return {
        Ref: m.ref || '',
        Date: m.created_at || '',
        Type: m.type || '',
        ItemCode: itm?.item_code || '',
        ItemName: itm?.name_en || '',
        Qty: m.qty || 0,
        Notes: m.notes || ''
      };
    }), 'stock_movements');
  }

  async function openAdjForm() { Utils.openModal('adj-modal'); }

  async function saveAdjustment() {
    const isAR   = i18n.getLang() === 'ar';
    const itemId = parseInt(document.getElementById('adj-item').value);
    const type   = document.getElementById('adj-type').value;
    const qty    = parseFloat(document.getElementById('adj-qty').value) || 0;
    const reason = document.getElementById('adj-reason').value;
    const notes  = document.getElementById('adj-notes').value;
    if (!itemId) { Utils.toast(isAR?'اختر صنفاً':'Select an item', 'warning'); return; }
    if (qty <= 0) { Utils.toast(isAR?'أدخل كمية صحيحة':'Enter valid qty', 'warning'); return; }

    const item = await DB.get('items', itemId);
    if (!item) return;

    const oldQty = item.stock_qty || 0;
    let delta = 0;
    if (type === 'in')  delta = qty;
    if (type === 'out') delta = -qty;
    if (type === 'set') delta = qty - oldQty;

    let newQty = Math.max(0, oldQty + delta);
    const nowIso = new Date().toISOString();

    const ref = await DB.nextSeq('stock_adjustments', 'ADJ-', 5);
    await DB.add('stock_adjustments', {
      ref, item_id: itemId, item_name: isAR ? (item.name_ar||item.name_en) : (item.name_en||item.name_ar),
      type, qty, new_qty: newQty, reason, notes,
      created_at: nowIso
    });

    await DB.add('stock_movements', {
      item_id: itemId,
      type: 'adjustment',
      ref,
      qty: delta,
      notes: `Adjustment (${reason}): ${notes || ''}`,
      created_at: nowIso
    });

    const whId = 1; // Default Warehouse ID
    if (!item.warehouse_stocks) item.warehouse_stocks = {};
    item.warehouse_stocks[whId] = Math.max(0, (item.warehouse_stocks[whId] || 0) + delta);
    item.stock_qty = newQty;
    await DB.update('items', item);

    // Box Link Logic
    if (item.selling_unit === 'box' && item.linked_item_id && item.pieces_per_box > 1) {
      const linked = await DB.get('items', item.linked_item_id);
      if (linked) {
        const linkedDelta = delta * item.pieces_per_box;
        if (!linked.warehouse_stocks) linked.warehouse_stocks = {};
        linked.warehouse_stocks[whId] = Math.max(0, (linked.warehouse_stocks[whId] || 0) + linkedDelta);
        linked.stock_qty = Math.max(0, (linked.stock_qty || 0) + linkedDelta);
        await DB.update('items', linked);
      }
    }

    Utils.closeModal('adj-modal');
    Utils.toast(i18n.t('common.saved'), 'success');
    await renderAdjustment(document.getElementById('page-content'), 'adjustments');
  }

  // ── Damaged Items ─────────────────────────────────────────────
  async function renderDamage(container) {
    const damages = await DB.getAll('stock_adjustments', a => a.reason === 'damage');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'البضاعة التالفة' : 'Damaged Items'}</h1>
          <p>${isAR ? `${damages.length} سجل` : `${damages.length} records`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-danger" onclick="InventoryMgr.recordDamage()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            ${isAR ? 'تسجيل تلف' : 'Record Damage'}
          </button>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR?'الرقم':'Ref'}</th>
            <th>${isAR?'التاريخ':'Date'}</th>
            <th>${isAR?'الصنف':'Item'}</th>
            <th>${isAR?'الكمية':'Qty'}</th>
            <th>${isAR?'ملاحظات':'Notes'}</th>
          </tr></thead>
          <tbody>
            ${damages.map(d => `<tr>
              <td style="font-weight:600;color:var(--danger)">${d.ref||'-'}</td>
              <td style="font-size:0.78rem">${Utils.formatDate(d.created_at)}</td>
              <td>${Utils.truncate(d.item_name||'-',30)}</td>
              <td style="font-weight:700;color:var(--danger)">${d.qty}</td>
              <td style="font-size:0.78rem;color:var(--text-muted)">${d.notes||'-'}</td>
            </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد سجلات':'No records'}</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>`;
  }

  async function recordDamage() { await renderAdjustment(document.getElementById('page-content')); openAdjForm(); document.getElementById('adj-reason').value = 'damage'; document.getElementById('adj-type').value = 'out'; }

  // ── Stock Transfer ────────────────────────────────────────────
  // ── Stores & Warehouses Management ───────────────────────────
  async function renderWarehouses(container) {
    const warehouses = (await DB.getAll('warehouses')) || [];
    const items = (await DB.getAll('items')) || [];
    const isAR = i18n.getLang() === 'ar';

    // Calculate item count per warehouse
    const whStats = {};
    warehouses.forEach(w => { whStats[w.id] = { itemCount: 0, totalUnits: 0 }; });
    items.forEach(item => {
      if (item.warehouse_stocks) {
        Object.entries(item.warehouse_stocks).forEach(([whId, qty]) => {
          if (whStats[whId] && qty > 0) {
            whStats[whId].itemCount += 1;
            whStats[whId].totalUnits += parseFloat(qty) || 0;
          }
        });
      } else {
        // Fallback default warehouse 1
        if (whStats[1] && item.stock_qty > 0) {
          whStats[1].itemCount += 1;
          whStats[1].totalUnits += parseFloat(item.stock_qty) || 0;
        }
      }
    });

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>🏬 ${isAR ? 'إدارة المستودعات والفروع' : 'Stores & Warehouses Management'}</h1>
          <p>${isAR ? `إجمالي الفروع والمستودعات: ${warehouses.length}` : `Total Stores & Branches: ${warehouses.length}`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="InventoryMgr.openWarehouseModal()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            ${isAR ? 'إضافة فرع / مستودع جديد' : 'Add New Store / Branch'}
          </button>
        </div>
      </div>

      <div class="grid grid-3" style="gap:20px">
        ${warehouses.map(w => {
          const stats = whStats[w.id] || { itemCount: 0, totalUnits: 0 };
          const isPrimaryWithStock = (w.id === 1 || (w.is_default && stats.totalUnits > 0));
          const canDelete = !isPrimaryWithStock && warehouses.length > 1;
          return `
          <div class="card" style="border: 1px solid ${w.is_default ? 'var(--primary)' : 'var(--border-color)'};">
            <div class="card-header" style="justify-content:space-between;background:${w.is_default ? 'rgba(239,68,68,0.05)' : 'var(--surface)'}">
              <div class="card-title" style="display:flex;align-items:center;gap:8px">
                🏬 <strong>${isAR ? (w.name_ar || w.name) : (w.name || w.name_ar)}</strong>
                ${w.is_default ? `<span class="badge badge-primary" style="font-size:0.68rem">${isAR?'الفرع الافتراضي':'Default Branch'}</span>` : ''}
              </div>
              <span class="badge badge-secondary" style="font-size:0.75rem">${w.code || 'WH'}</span>
            </div>
            <div class="modal-body" style="padding:16px">
              <div style="font-size:0.82rem;color:var(--text-muted);margin-bottom:10px">
                <div>📍 <strong>${isAR?'العنوان:':'Address:'}</strong> ${w.address || (isAR?'غير محدد':'N/A')}</div>
                <div style="margin-top:4px">📞 <strong>${isAR?'الهاتف:':'Phone:'}</strong> ${w.phone || (isAR?'غير محدد':'N/A')}</div>
              </div>
              <div style="display:flex;gap:12px;background:var(--surface-2);padding:10px;border-radius:8px;margin-bottom:14px">
                <div style="flex:1;text-align:center">
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'عدد الأصناف':'Active Items'}</div>
                  <div style="font-size:1.1rem;font-weight:700;color:var(--text-primary)">${stats.itemCount}</div>
                </div>
                <div style="flex:1;text-align:center;border-left:1px solid var(--border-color)">
                  <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'إجمالي القطع':'Total Stock Qty'}</div>
                  <div style="font-size:1.1rem;font-weight:700;color:var(--primary)">${stats.totalUnits.toLocaleString()}</div>
                </div>
              </div>
              <div style="display:flex;gap:8px;justify-content:flex-end">
                <button class="btn btn-secondary btn-sm" onclick="InventoryMgr.openWarehouseModal(${w.id})">✏️ ${isAR?'تعديل':'Edit'}</button>
                ${canDelete ? `<button class="btn btn-danger btn-sm" onclick="InventoryMgr.deleteWarehouse(${w.id})">✕ ${isAR?'حذف':'Delete'}</button>` : ''}
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>
    </div>`;
  }

  async function openWarehouseModal(id = null) {
    const isAR = i18n.getLang() === 'ar';
    let wh = { code: 'WH-0' + (Date.now() % 100), name: '', name_ar: '', phone: '', address: '', is_default: false };
    if (id) {
      wh = (await DB.get('warehouses', id)) || wh;
    }

    const modalId = 'wh-edit-modal';
    document.getElementById(modalId)?.remove();

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9990">
      <div class="modal" style="max-width:520px">
        <div class="modal-header">
          <div class="modal-title">🏬 ${id ? (isAR?'تعديل الفرع/المستودع':'Edit Store/Warehouse') : (isAR?'إضافة فرع/مستودع جديد':'Add New Store/Warehouse')}</div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'رمز الفرع (Code) *':'Store Code *'}</label>
              <input type="text" class="form-control" id="wh-code" value="${wh.code||''}" required>
            </div>
            <div class="form-group" style="display:flex;align-items:center;margin-top:24px">
              <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                <input type="checkbox" id="wh-is-default" ${wh.is_default ? 'checked' : ''}>
                <span style="font-weight:700;font-size:0.85rem">${isAR?'تعيين كفرع رئيسي افتراضي':'Set as Default Store'}</span>
              </label>
            </div>
          </div>
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'اسم الفرع (إنجليزي) *':'Store Name (English) *'}</label>
              <input type="text" class="form-control" id="wh-name-en" value="${wh.name||''}" required placeholder="e.g. Branch 2 - Verdun">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'اسم الفرع (عربي) *':'Store Name (Arabic) *'}</label>
              <input type="text" class="form-control" id="wh-name-ar" value="${wh.name_ar||''}" required placeholder="مثال: فرع 2 - فردان">
            </div>
          </div>
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'رقم الهاتف':'Phone Number'}</label>
              <input type="text" class="form-control" id="wh-phone" value="${wh.phone||''}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'العنوان / الموقع':'Address / Location'}</label>
              <input type="text" class="form-control" id="wh-address" value="${wh.address||''}">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="InventoryMgr.saveWarehouse(${id || 'null'})">${isAR?'حفظ الفرع':'Save Store'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  async function saveWarehouse(id) {
    const isAR = i18n.getLang() === 'ar';
    const code = document.getElementById('wh-code')?.value.trim();
    const name = document.getElementById('wh-name-en')?.value.trim();
    const name_ar = document.getElementById('wh-name-ar')?.value.trim();
    const phone = document.getElementById('wh-phone')?.value.trim();
    const address = document.getElementById('wh-address')?.value.trim();
    const is_default = document.getElementById('wh-is-default')?.checked;

    if (!code || !name) {
      return Utils.toast(isAR ? 'يرجى إدخال رمز واسم الفرع' : 'Please enter code and store name', 'warning');
    }

    if (is_default) {
      const allWh = await DB.getAll('warehouses');
      for (const w of allWh) {
        if (w.is_default) {
          w.is_default = false;
          await DB.update('warehouses', w);
        }
      }
    }

    const payload = {
      code, name, name_ar: name_ar || name, phone, address, is_default: !!is_default
    };

    if (id) {
      payload.id = id;
      await DB.update('warehouses', payload);
    } else {
      await DB.add('warehouses', payload);
    }

    if (typeof BranchSync !== 'undefined' && BranchSync.notifyChange) {
      BranchSync.notifyChange('warehouses', payload);
    }

    document.getElementById('wh-edit-modal')?.remove();
    Utils.toast(isAR ? 'تم حفظ بيانات الفرع بنجاح' : 'Store saved successfully', 'success');
    await renderWarehouses(document.getElementById('page-content'));
  }

  async function deleteWarehouse(id) {
    const isAR = i18n.getLang() === 'ar';
    Utils.confirm(
      isAR ? 'هل أنت متأكد من رغبتك في حذف هذا الفرع/المستودع؟' : 'Are you sure you want to delete this store/warehouse?',
      async () => {
        try {
          const numId = Number(id);
          const targetId = !isNaN(numId) ? numId : id;
          if (typeof DB.remove === 'function') {
            await DB.remove('warehouses', targetId);
          } else if (typeof DB.delete === 'function') {
            await DB.delete('warehouses', targetId);
          }
          if (typeof DB.callApi === 'function') {
            await DB.callApi(`/api/db/warehouses/${id}`, { method: 'DELETE' }).catch(console.warn);
          }
          if (typeof BranchSync !== 'undefined' && BranchSync.notifyChange) {
            BranchSync.notifyChange('warehouses');
          }
          Utils.toast(isAR ? 'تم حذف الفرع بنجاح' : 'Store deleted successfully', 'success');
          await renderWarehouses(document.getElementById('page-content'));
        } catch (err) {
          console.error('Failed to delete warehouse:', err);
          Utils.toast(isAR ? 'حدث خطأ أثناء حذف الفرع: ' + err.message : 'Failed to delete store: ' + err.message, 'danger');
        }
      }
    );
  }

  // ── Stock Transfers (Moving Between Stores) ───────────────────
  async function renderTransfer(container) {
    const transfers = (await DB.getAll('stock_transfers')) || [];
    const warehouses = (await DB.getAll('warehouses')) || [];
    const whMap = {};
    warehouses.forEach(w => { whMap[w.id] = i18n.getLang() === 'ar' ? (w.name_ar || w.name) : (w.name || w.name_ar); });

    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>🔄 ${isAR ? 'التحويل بين المستودعات والفروع' : 'Inter-Store Stock Transfers'}</h1>
          <p>${isAR ? `سجل تحويلات البضائع بين الفروع: ${transfers.length} عملية` : `Stock transfer vouchers: ${transfers.length} transfers`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="InventoryMgr.openTransferForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 014-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 01-4 4H3"/></svg>
            ${isAR ? 'إنشاء تحويل جديد' : 'New Stock Transfer'}
          </button>
        </div>
      </div>
      <div class="table-wrapper">
        <table>
          <thead><tr>
            <th>${isAR?'رقم التحويل':'Transfer Ref'}</th>
            <th>${isAR?'التاريخ':'Date'}</th>
            <th>${isAR?'من فرع / مستودع':'From Store'}</th>
            <th>${isAR?'إلى فرع / مستودع':'To Store'}</th>
            <th>${isAR?'الصنف المحول':'Item Transferred'}</th>
            <th>${isAR?'الكمية':'Qty'}</th>
            <th>${isAR?'المسؤول':'Created By'}</th>
            <th>${isAR?'ملاحظات':'Notes'}</th>
            <th style="text-align:center">${isAR?'طباعة':'Print'}</th>
          </tr></thead>
          <tbody>
            ${transfers.slice().reverse().map(t => `<tr>
              <td style="font-weight:700;color:var(--primary)">${t.ref||'-'}</td>
              <td style="font-size:0.78rem">${Utils.formatDate(t.created_at)}</td>
              <td><span class="badge badge-secondary">📤 ${whMap[t.from_wh_id] || t.from_wh_name || 'Branch 1'}</span></td>
              <td><span class="badge badge-success">📥 ${whMap[t.to_wh_id] || t.to_wh_name || 'Branch 2'}</span></td>
              <td style="font-weight:600">${t.item_name || '-'}</td>
              <td style="font-weight:700;color:var(--primary)">${t.qty}</td>
              <td style="font-size:0.78rem">${t.user_name || 'Admin'}</td>
              <td style="font-size:0.78rem;color:var(--text-muted)">${t.notes||'-'}</td>
              <td style="text-align:center">
                <button class="btn btn-secondary btn-xs" onclick="InventoryMgr.printTransferNote('${t.ref}')" title="${isAR?'طباعة إذن التحويل':'Print Transfer Note'}">🖨️</button>
              </td>
            </tr>`).join('') || `<tr><td colspan="9" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد تحويلات بين الفروع مسجلة':'No inter-store transfers recorded'}</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>`;
  }

  async function openTransferForm() {
    const isAR = i18n.getLang() === 'ar';
    let warehouses = (await DB.getAll('warehouses')) || [];
    if (warehouses.length < 2 && window.OnlineOrders && typeof OnlineOrders.pullCloudTables === 'function') {
      try {
        await OnlineOrders.pullCloudTables();
        warehouses = (await DB.getAll('warehouses')) || [];
      } catch(e) {}
    }
    const items = (await DB.getAll('items')) || [];

    if (warehouses.length < 2) {
      return Utils.toast(
        isAR 
          ? 'يجب تعريف فرعين أو مستودعين على الأقل للتحويل بينهما. انتقل لصفحة "إدارة المستودعات والفروع" أولاً أو اضغط مزامنة السحابة.' 
          : 'You need at least 2 stores/branches to make a transfer. Please add branches first or sync cloud.',
        'warning'
      );
    }

    const modalId = 'transfer-modal';
    document.getElementById(modalId)?.remove();

    const html = `
    <div class="modal-overlay open" id="${modalId}" style="z-index:9990">
      <div class="modal" style="max-width:580px">
        <div class="modal-header">
          <div class="modal-title">🔄 ${isAR ? 'تحويل بضاعة بين الفروع والمستودعات' : 'Transfer Stock Between Stores'}</div>
          <button class="modal-close" onclick="document.getElementById('${modalId}').remove()">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-2">
            <div class="form-group">
              <label class="form-label">${isAR?'من فرع / مستودع (المصدر) *':'From Store (Source) *'}</label>
              <select class="form-control" id="trf-from-wh" onchange="InventoryMgr.onTransferSourceChange()">
                ${warehouses.map(w => `<option value="${w.id}">${isAR ? (w.name_ar||w.name) : (w.name||w.name_ar)} (${w.code})</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'إلى فرع / مستودع (الوجهة) *':'To Store (Destination) *'}</label>
              <select class="form-control" id="trf-to-wh">
                ${warehouses.map((w, idx) => `<option value="${w.id}" ${idx===1?'selected':''}>${isAR ? (w.name_ar||w.name) : (w.name||w.name_ar)} (${w.code})</option>`).join('')}
              </select>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">${isAR?'اختر الصنف المراد تحويله *':'Select Item *'}</label>
            <select class="form-control" id="trf-item" onchange="InventoryMgr.onTransferItemChange()">
              <option value="">${isAR?'-- اختر صنفاً --':'-- Select Item --'}</option>
              ${items.map(i => `<option value="${i.id}">${i.item_code||''} - ${isAR ? (i.name_ar||i.name_en) : (i.name_en||i.name_ar)} (${i.stock_qty||0} in total)</option>`).join('')}
            </select>
          </div>

          <div style="background:var(--surface-2);padding:12px;border-radius:8px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:0.85rem">${isAR?'الكمية المتوفرة في الفرع المصدر:':'Stock Available in Source Store:'}</span>
            <strong id="trf-avail-qty" style="color:var(--primary);font-size:1.1rem">0</strong>
          </div>

          <div class="form-group">
            <label class="form-label">${isAR?'الكمية المحولة *':'Transfer Quantity *'}</label>
            <input type="number" class="form-control" id="trf-qty" min="1" step="any" placeholder="1" style="font-weight:700;font-size:1.1rem">
          </div>

          <div class="form-group">
            <label class="form-label">${isAR?'سبب التحويل / ملاحظات':'Transfer Reason / Notes'}</label>
            <input type="text" class="form-control" id="trf-notes" placeholder="${isAR?'مثال: تزويد فرع فردان بالبضاعة':'e.g. Stock replenishment for Branch 2'}">
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="document.getElementById('${modalId}').remove()">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-primary" onclick="InventoryMgr.saveTransfer()">${isAR?'تنفيذ التحويل الآن':'Execute Transfer'}</button>
        </div>
      </div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
    onTransferSourceChange();
  }

  async function onTransferSourceChange() {
    await onTransferItemChange();
  }

  async function onTransferItemChange() {
    const fromWhId = document.getElementById('trf-from-wh')?.value;
    const itemId = document.getElementById('trf-item')?.value;
    const badge = document.getElementById('trf-avail-qty');
    if (!badge) return;

    if (!itemId) {
      badge.textContent = '0';
      return;
    }

    const item = await DB.get('items', parseInt(itemId));
    if (!item) {
      badge.textContent = '0';
      return;
    }

    const avail = (item.warehouse_stocks && item.warehouse_stocks[fromWhId] !== undefined) 
      ? item.warehouse_stocks[fromWhId] 
      : (fromWhId == 1 ? (item.stock_qty || 0) : 0);

    badge.textContent = String(avail);
  }

  async function saveTransfer() {
    const isAR = i18n.getLang() === 'ar';
    const fromWhId = parseInt(document.getElementById('trf-from-wh')?.value);
    const toWhId   = parseInt(document.getElementById('trf-to-wh')?.value);
    const itemId   = parseInt(document.getElementById('trf-item')?.value);
    const qty      = parseFloat(document.getElementById('trf-qty')?.value);
    const notes    = document.getElementById('trf-notes')?.value.trim();

    if (!itemId) return Utils.toast(isAR ? 'يرجى اختيار الصنف' : 'Please select an item', 'warning');
    if (fromWhId === toWhId) return Utils.toast(isAR ? 'لا يمكن التحويل لنفس الفرع!' : 'Source and Destination store cannot be the same!', 'warning');
    if (!qty || qty <= 0) return Utils.toast(isAR ? 'أدخل كمية تحويل صحيحة' : 'Enter valid transfer quantity', 'warning');

    const item = await DB.get('items', itemId);
    if (!item) return;

    const fromWh = await DB.get('warehouses', fromWhId);
    const toWh   = await DB.get('warehouses', toWhId);

    if (!item.warehouse_stocks) {
      item.warehouse_stocks = { 1: item.stock_qty || 0 };
    }

    const fromStock = item.warehouse_stocks[fromWhId] !== undefined 
      ? parseFloat(item.warehouse_stocks[fromWhId]) 
      : ((fromWhId === 1 || fromWh?.code === 'WH-01' || fromWh?.is_default) ? (parseFloat(item.stock_qty) || 0) : 0);

    if (qty > fromStock) {
      return Utils.toast(
        isAR ? `الكمية المطلوبة (${qty}) تتجاوز المتوفر في الفرع المصدر (${fromStock})!` : `Requested qty (${qty}) exceeds stock available at source store (${fromStock})!`,
        'error'
      );
    }

    // Execute transfer and update all possible identifier keys (id, code, lowercase code, name)
    const newFromStock = Math.max(0, fromStock - qty);
    const toStock = item.warehouse_stocks[toWhId] !== undefined 
      ? parseFloat(item.warehouse_stocks[toWhId]) 
      : ((toWhId === 1 || toWh?.code === 'WH-01' || toWh?.is_default) ? (parseFloat(item.stock_qty) || 0) : 0);
    const newToStock = toStock + qty;

    const fromKeys = [
      String(fromWhId),
      fromWh?.code ? String(fromWh.code).trim().toLowerCase() : null,
      fromWh?.code ? String(fromWh.code).trim() : null,
      fromWh?.name ? String(fromWh.name).trim().toLowerCase() : null,
      fromWh?.name_ar ? String(fromWh.name_ar).trim().toLowerCase() : null
    ].filter(Boolean);

    const toKeys = [
      String(toWhId),
      toWh?.code ? String(toWh.code).trim().toLowerCase() : null,
      toWh?.code ? String(toWh.code).trim() : null,
      toWh?.name ? String(toWh.name).trim().toLowerCase() : null,
      toWh?.name_ar ? String(toWh.name_ar).trim().toLowerCase() : null
    ].filter(Boolean);

    for (const k of fromKeys) item.warehouse_stocks[k] = newFromStock;
    for (const k of toKeys)   item.warehouse_stocks[k] = newToStock;

    // Adjust main stock_qty if source or destination is the main warehouse
    if (fromWhId === 1 || fromWh?.code === 'WH-01' || fromWh?.is_default) {
      item.stock_qty = newFromStock;
    } else if (toWhId === 1 || toWh?.code === 'WH-01' || toWh?.is_default) {
      item.stock_qty = newToStock;
    }

    await DB.update('items', item);

    // If box item with linked pieces
    if (item.selling_unit === 'box' && item.linked_item_id && item.pieces_per_box > 1) {
      const linked = await DB.get('items', item.linked_item_id);
      if (linked) {
        if (!linked.warehouse_stocks) linked.warehouse_stocks = { 1: linked.stock_qty || 0 };
        const pieceDelta = qty * item.pieces_per_box;
        const linkedFromStock = (linked.warehouse_stocks[fromWhId] !== undefined) ? parseFloat(linked.warehouse_stocks[fromWhId]) : (parseFloat(linked.stock_qty) || 0);
        const linkedToStock = (linked.warehouse_stocks[toWhId] !== undefined) ? parseFloat(linked.warehouse_stocks[toWhId]) : 0;
        const newLinkedFrom = Math.max(0, linkedFromStock - pieceDelta);
        const newLinkedTo = linkedToStock + pieceDelta;

        for (const k of fromKeys) linked.warehouse_stocks[k] = newLinkedFrom;
        for (const k of toKeys)   linked.warehouse_stocks[k] = newLinkedTo;

        if (fromWhId === 1 || fromWh?.code === 'WH-01' || fromWh?.is_default) {
          linked.stock_qty = newLinkedFrom;
        } else if (toWhId === 1 || toWh?.code === 'WH-01' || toWh?.is_default) {
          linked.stock_qty = newLinkedTo;
        }
        await DB.update('items', linked);
      }
    }

    const ref    = await DB.nextSeq('stock_transfers', 'TRF-', 5);
    const user   = Auth.getUser();

    const transferRecord = {
      ref,
      from_wh_id: fromWhId,
      from_wh_name: isAR ? (fromWh?.name_ar || fromWh?.name) : (fromWh?.name || fromWh?.name_ar),
      to_wh_id: toWhId,
      to_wh_name: isAR ? (toWh?.name_ar || toWh?.name) : (toWh?.name || toWh?.name_ar),
      item_id: itemId,
      item_name: isAR ? (item.name_ar || item.name_en) : (item.name_en || item.name_ar),
      qty,
      notes: notes || '',
      user_name: user?.full_name || user?.username || 'Admin',
      created_at: new Date().toISOString()
    };

    await DB.add('stock_transfers', transferRecord);
    await DB.add('stock_movements', {
      item_id: itemId,
      type: 'transfer',
      ref,
      qty,
      notes: `Transfer from ${transferRecord.from_wh_name} to ${transferRecord.to_wh_name}`
    });

    if (typeof BranchSync !== 'undefined' && BranchSync.notifyChange) {
      await BranchSync.notifyChange('items', item);
      await BranchSync.notifyChange('stock_transfers', transferRecord);
      if (typeof BranchSync.syncNow === 'function') {
        BranchSync.syncNow(true).catch(() => {});
      }
    }

    document.getElementById('transfer-modal')?.remove();
    Utils.toast(isAR ? 'تم تنفيذ تحويل البضاعة وتعديل الرصيد بنجاح!' : 'Stock transfer executed and quantity adjusted successfully!', 'success');
    await renderTransfer(document.getElementById('page-content'));
  }

  async function printTransferNote(ref) {
    const transfers = (await DB.getAll('stock_transfers')) || [];
    const t = transfers.find(x => x.ref === ref);
    if (!t) return;
    const isAR = i18n.getLang() === 'ar';

    const html = `
    <div style="font-family:'Cairo','Inter',sans-serif;padding:20px;max-width:600px;margin:0 auto;border:1px solid #ddd;direction:${isAR?'rtl':'ltr'}">
      <div style="text-align:center;border-bottom:2px solid #333;padding-bottom:10px;margin-bottom:15px">
        <h2 style="margin:0">${isAR?'إذن تحويل بضاعة بين المستودعات والفروع':'Inter-Store Stock Transfer Voucher'}</h2>
        <div style="font-size:0.9rem;color:#666;margin-top:4px">${t.ref} | ${Utils.formatDate(t.created_at)}</div>
      </div>
      <table style="width:100%;border-collapse:collapse;margin-bottom:15px;font-size:0.9rem">
        <tr><td style="padding:4px;font-weight:700">${isAR?'من فرع:':'From Store:'}</td><td>${t.from_wh_name}</td></tr>
        <tr><td style="padding:4px;font-weight:700">${isAR?'إلى فرع:':'To Store:'}</td><td>${t.to_wh_name}</td></tr>
        <tr><td style="padding:4px;font-weight:700">${isAR?'الصنف المحول:':'Item:'}</td><td>${t.item_name}</td></tr>
        <tr><td style="padding:4px;font-weight:700">${isAR?'الكمية المحولة:':'Transferred Quantity:'}</td><td style="font-size:1.1rem;font-weight:900">${t.qty}</td></tr>
        <tr><td style="padding:4px;font-weight:700">${isAR?'المسؤول:':'Issued By:'}</td><td>${t.user_name}</td></tr>
        <tr><td style="padding:4px;font-weight:700">${isAR?'الملاحظات:':'Notes:'}</td><td>${t.notes||'-'}</td></tr>
      </table>
      <div style="display:flex;justify-content:space-between;margin-top:40px;padding-top:10px;border-top:1px dashed #aaa;font-size:0.85rem">
        <div>${isAR?'توقيع مسؤول الفرع المصدر: __________':'Source Store Signature: __________'}</div>
        <div>${isAR?'توقيع مسؤول الفرع المستلم: __________':'Recipient Store Signature: __________'}</div>
      </div>
    </div>`;

    Utils.printElement(html, `TransferNote-${t.ref}`);
  }

  // ── Barcode Labels ────────────────────────────────────────────
  async function renderBarcode(container) {
    const items = await DB.getAll('items');
    const isAR  = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'طباعة الباركود' : 'Barcode Labels'}</h1>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="InventoryMgr.printBarcodes()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
            ${isAR ? 'طباعة المحدد' : 'Print Selected'}
          </button>
        </div>
      </div>

      <div class="card mb-4">
        <div class="card-header">
          <div class="card-title">${isAR ? 'إعدادات الطباعة' : 'Print Settings'}</div>
        </div>
        <div class="grid grid-4">
          <div class="form-group">
            <label class="form-label">${isAR ? 'الحجم' : 'Label Size'}</label>
            <select class="form-control" id="bc-size">
              <option value="40x25">40×25mm</option>
              <option value="50x30">50×30mm</option>
              <option value="60x40">60×40mm</option>
              <option value="80x50">80×50mm</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'في الصف' : 'Per Row'}</label>
            <select class="form-control" id="bc-per-row">
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'إظهار الاسم' : 'Show Name'}</label>
            <select class="form-control" id="bc-show-name">
              <option value="1">${isAR?'نعم':'Yes'}</option>
              <option value="0">${isAR?'لا':'No'}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">${isAR ? 'إظهار السعر' : 'Show Price'}</label>
            <select class="form-control" id="bc-show-price">
              <option value="1">${isAR?'نعم':'Yes'}</option>
              <option value="0">${isAR?'لا':'No'}</option>
            </select>
          </div>
        </div>
      </div>

      <div class="toolbar mb-3">
        <div class="search-bar flex-1">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="form-control" placeholder="${isAR?'بحث...':'Search...'}" oninput="InventoryMgr.filterBarcodeItems(this.value)" style="padding-left:34px">
        </div>
        <label style="display:flex;align-items:center;gap:6px;font-size:0.8rem;cursor:pointer">
          <input type="checkbox" id="bc-select-all" onchange="InventoryMgr.selectAllBarcodes(this.checked)">
          ${isAR ? 'تحديد الكل' : 'Select All'}
        </label>
      </div>

      <div class="grid grid-4" id="bc-items-grid">
        ${items.map(i => {
          const name = isAR ? (i.name_ar||i.name_en) : (i.name_en||i.name_ar);
          return `
          <div class="card" style="padding:10px;cursor:pointer" onclick="this.classList.toggle('selected')" data-item-id="${i.id}">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:6px">
              <input type="checkbox" class="bc-item-check" value="${i.id}" onchange="event.stopPropagation()">
              <span style="font-weight:600;font-size:0.78rem">${Utils.truncate(name, 25)}</span>
            </label>
            <div style="font-size:0.7rem;color:var(--text-muted);margin-bottom:4px">${i.item_code||''} | ${i.barcode||'N/A'}</div>
            <div style="font-size:0.82rem;font-weight:700;color:var(--primary)">${Utils.formatMoney(i.selling_price||0)}</div>
            <div style="margin-top:4px">
              <input type="number" value="1" min="1" max="100" style="width:60px;padding:3px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;font-size:0.72rem" onclick="event.stopPropagation()" title="${isAR?'الكمية':'Qty'}">
              <span style="font-size:0.68rem;color:var(--text-muted);margin-left:3px">${isAR?'عدد':'labels'}</span>
            </div>
          </div>`;
        }).join('')}
        ${items.length===0 ? `<div class="empty-state" style="grid-column:1/-1"><h3>${isAR?'لا توجد أصناف':'No items'}</h3></div>` : ''}
      </div>
    </div>`;

    window._bcItems = items;
  }

  function filterBarcodeItems(q) {
    const isAR = i18n.getLang() === 'ar';
    document.querySelectorAll('#bc-items-grid .card').forEach(card => {
      const id = parseInt(card.dataset.itemId);
      const item = (window._bcItems||[]).find(i => i.id === id);
      if (!item) return;
      const matches = !q || (item.name_en||'').toLowerCase().includes(q.toLowerCase()) || (item.name_ar||'').toLowerCase().includes(q.toLowerCase()) || (item.item_code||'').toLowerCase().includes(q.toLowerCase());
      card.style.display = matches ? '' : 'none';
    });
  }

  function selectAllBarcodes(checked) {
    document.querySelectorAll('.bc-item-check').forEach(cb => cb.checked = checked);
  }

  function printBarcodes() {
    const isAR   = i18n.getLang() === 'ar';
    const checked = [...document.querySelectorAll('.bc-item-check:checked')];
    if (!checked.length) { Utils.toast(isAR?'اختر أصناف أولاً':'Select items first', 'warning'); return; }

    const items = window._bcItems || [];
    const showName  = document.getElementById('bc-show-name')?.value === '1';
    const showPrice = document.getElementById('bc-show-price')?.value === '1';
    const perRow    = parseInt(document.getElementById('bc-per-row')?.value) || 3;

    const labels = checked.map(cb => {
      const item = items.find(i => i.id === parseInt(cb.value));
      if (!item) return '';
      const name = isAR ? (item.name_ar||item.name_en) : (item.name_en||item.name_ar);
      return `
      <div style="display:inline-block;border:1px solid #ccc;padding:4mm;text-align:center;width:${Math.floor(100/perRow)-2}%;margin:1%;box-sizing:border-box;font-family:Arial,sans-serif;vertical-align:top">
        ${showName ? `<div style="font-size:7pt;font-weight:700;margin-bottom:2mm;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">${name}</div>` : ''}
        <div style="font-size:7pt;letter-spacing:1px;margin-bottom:1mm">${item.item_code||''}</div>
        <div style="font-size:22pt;letter-spacing:4px;font-family:'Libre Barcode 39',monospace">*${item.barcode||item.item_code||'000000'}*</div>
        <div style="font-size:7pt;margin-top:1mm">${item.barcode||item.item_code||''}</div>
        ${showPrice ? `<div style="font-size:9pt;font-weight:900;margin-top:2mm">${Utils.formatMoney(item.selling_price||0)}</div>` : ''}
      </div>`;
    }).join('');

    Utils.printElement(`
    <link href="https://fonts.googleapis.com/css2?family=Libre+Barcode+39&display=swap" rel="stylesheet">
    <div style="width:100%">${labels}</div>`, 'Barcode Labels');
  }

  return {
    renderAdjustment, openAdjForm, saveAdjustment, switchTab, filterMovementsTable, exportMovementsCSV,
    buildAuditTable, stepAuditCount, handleAuditScan, updateAuditRow, reconcileAllAudit, printBlankAuditSheet,
    renderDamage, recordDamage,
    renderTransfer, openTransferForm, onTransferSourceChange, onTransferItemChange, saveTransfer, printTransferNote,
    renderWarehouses, openWarehouseModal, saveWarehouse, deleteWarehouse,
    renderBarcode, filterBarcodeItems, selectAllBarcodes, printBarcodes
  };
})();

window.InventoryMgr = InventoryMgr;

// Auto-refresh Transfers list and Warehouse stocks on sync complete
if (typeof window !== 'undefined') {
  window.addEventListener('redshark_sync_complete', async (e) => {
    const activeTransferTable = document.getElementById('transfers-table-body');
    if (activeTransferTable && typeof InventoryMgr.renderTransfer === 'function') {
      const container = document.getElementById('page-content');
      if (container) {
        try { await InventoryMgr.renderTransfer(container); } catch(err) {}
      }
    }
  });
}
