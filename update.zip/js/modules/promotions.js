/* ================================================================
   Red Shark POS — Dynamic Promotions & Happy Hour Engine
   ================================================================ */

const Promotions = (() => {

  async function getActivePromotions(cart = [], subtotal = 0) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const cur1 = window._primaryCurrency || 'USD';

    // ── 1. Evaluate Item-Specific Bundle & Quantity Offers from DB ──
    let itemOffersDiscAmt = 0;
    let activeDeals = [];
    const todayStr = new Date().toISOString().slice(0, 10);

    try {
      const allOffers = await DB.getAll('offers');
      const activeOffers = (allOffers || []).filter(o => {
        if (o.status === 'inactive') return false;
        if (o.start_date && o.start_date > todayStr) return false;
        if (o.end_date && o.end_date < todayStr) return false;
        return true;
      });

      for (const offer of activeOffers) {
        const cartItem = cart.find(c => c.item_id === offer.item_id && c.line_type !== 'return' && c.line_type !== 'damage');
        if (!cartItem) continue;

        const qty = cartItem.qty || 0;
        const unitPrice = cartItem.price || 0;

        if (offer.type === 'bundle_price' && qty >= offer.min_qty && offer.min_qty > 0) {
          // e.g. Buy 3 for $5.00
          const bundles = Math.floor(qty / offer.min_qty);
          const regularPriceForBundles = bundles * (offer.min_qty * unitPrice);
          const offerPriceForBundles = bundles * offer.bundle_price;
          const savings = Math.max(0, regularPriceForBundles - offerPriceForBundles);

          if (savings > 0) {
            itemOffersDiscAmt += savings;
            activeDeals.push({
              type: 'bundle_price',
              item_id: offer.item_id,
              name: `${offer.name || 'Special Offer'}: ${offer.min_qty} for ${cur1} ${Utils.formatCurrency(offer.bundle_price)} (-${cur1} ${Utils.formatCurrency(savings)})`,
              name_ar: `${offer.name || 'عرض خاص'}: ${offer.min_qty} حبات بـ ${cur1} ${Utils.formatCurrency(offer.bundle_price)} (وفرت ${cur1} ${Utils.formatCurrency(savings)})`,
              savings
            });
          }
        } else if (offer.type === 'buy_x_get_y' && qty >= offer.min_qty && offer.min_qty > 0) {
          // e.g. Buy 2 Get 1 Free
          const groupSize = offer.min_qty + (offer.free_qty || 1);
          const sets = Math.floor(qty / groupSize);
          const freeUnits = sets * (offer.free_qty || 1);
          const savings = freeUnits * unitPrice;

          if (savings > 0) {
            itemOffersDiscAmt += savings;
            activeDeals.push({
              type: 'buy_x_get_y',
              item_id: offer.item_id,
              name: `Buy ${offer.min_qty} Get ${offer.free_qty||1} Free (-${cur1} ${Utils.formatCurrency(savings)})`,
              name_ar: `اشتري ${offer.min_qty} واحصل على ${offer.free_qty||1} مجاناً (وفرت ${cur1} ${Utils.formatCurrency(savings)})`,
              savings
            });
          }
        } else if (offer.type === 'discount_pct' && offer.discount_pct > 0) {
          const savings = (unitPrice * (offer.discount_pct / 100)) * qty;
          itemOffersDiscAmt += savings;
          activeDeals.push({
            type: 'discount_pct',
            item_id: offer.item_id,
            name: `${offer.discount_pct}% OFF on item (-${cur1} ${Utils.formatCurrency(savings)})`,
            name_ar: `خصم ${offer.discount_pct}% على الصنف (وفرت ${cur1} ${Utils.formatCurrency(savings)})`,
            savings
          });
        }
      }
    } catch (e) {
      console.warn('Offers calculation warning:', e);
    }

    // ── 2. Evaluate Global Store-Level Promotions ──
    const hhEnabled  = await DB.getSetting('promo_happy_hour_enabled', false);
    const hhPct      = parseFloat(await DB.getSetting('promo_happy_hour_pct', 10)) || 10;
    const hhStart    = await DB.getSetting('promo_happy_hour_start', '14:00');
    const hhEnd      = await DB.getSetting('promo_happy_hour_end', '17:00');

    const threshEnabled = await DB.getSetting('promo_threshold_enabled', false);
    const threshAmt     = parseFloat(await DB.getSetting('promo_threshold_amt', 100)) || 100;
    const threshPct     = parseFloat(await DB.getSetting('promo_threshold_pct', 5)) || 5;

    let totalGlobalDiscPct = 0;

    // Check Happy Hour Time Window
    if (hhEnabled && hhStart && hhEnd) {
      const now = new Date();
      const currentHM = now.toTimeString().slice(0, 5); // "HH:MM"
      if (currentHM >= hhStart && currentHM <= hhEnd) {
        totalGlobalDiscPct += hhPct;
        activeDeals.push({
          type: 'happy_hour',
          name: `Happy Hour (${hhPct}% OFF)`,
          name_ar: `ساعات السعادة (خصم ${hhPct}%)`,
          pct: hhPct
        });
      }
    }

    // Check Spend Threshold
    if (threshEnabled && subtotal >= threshAmt) {
      totalGlobalDiscPct += threshPct;
      activeDeals.push({
        type: 'threshold',
        name: `Spend & Save (${threshPct}% OFF over ${cur1} ${threshAmt})`,
        name_ar: `تجاوز ${threshAmt} ${cur1} (خصم ${threshPct}%)`,
        pct: threshPct
      });
    }

    const globalDiscAmt = Utils.round(Math.max(0, subtotal - itemOffersDiscAmt) * (totalGlobalDiscPct / 100));
    const totalDiscAmt = Utils.round(itemOffersDiscAmt + globalDiscAmt);

    return {
      hasPromotion: activeDeals.length > 0,
      itemOffersDiscount: itemOffersDiscAmt,
      globalDiscount: globalDiscAmt,
      discountAmount: totalDiscAmt,
      deals: activeDeals,
      label: activeDeals.map(d => isAR ? d.name_ar : d.name).join(' | ')
    };
  }

  return {
    getActivePromotions
  };
})();

window.Promotions = Promotions;
