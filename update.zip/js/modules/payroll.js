/* ================================================================
   NexPOS — Payroll Module
   ================================================================ */

const Payroll = (() => {

  async function render(container) {
    const payrolls  = await DB.getAll('payroll_runs');
    const employees = await DB.getAll('employees');
    const isAR = i18n.getLang() === 'ar';

    container.innerHTML = `
    <div class="animate-slide">
      <div class="page-header">
        <div class="page-header-left">
          <h1>${isAR ? 'الرواتب' : 'Payroll'}</h1>
          <p>${isAR ? `${payrolls.length} دورة راتب` : `${payrolls.length} payroll runs`}</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-primary" onclick="Payroll.openRunForm()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            ${isAR ? 'تشغيل الرواتب' : 'Run Payroll'}
          </button>
        </div>
      </div>

      <!-- Summary KPIs -->
      <div class="grid grid-4 mb-4">
        <div class="stat-card primary">
          <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
          <div class="stat-info">
            <div class="stat-label">${isAR?'إجمالي الموظفين':'Total Employees'}</div>
            <div class="stat-value">${employees.filter(e=>e.status==='active').length}</div>
          </div>
        </div>
        <div class="stat-card success">
          <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg></div>
          <div class="stat-info">
            <div class="stat-label">${isAR?'إجمالي الرواتب الشهرية':'Total Monthly Payroll'}</div>
            <div class="stat-value">${Utils.formatMoney(employees.filter(e=>e.status==='active').reduce((s,e)=>s+(e.basic_salary||0)+(e.transport||0)+(e.housing||0)+(e.other_allowances||0),0))}</div>
          </div>
        </div>
        <div class="stat-card warning">
          <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg></div>
          <div class="stat-info">
            <div class="stat-label">${isAR?'آخر دورة':'Last Run'}</div>
            <div class="stat-value" style="font-size:0.9rem">${payrolls.length ? Utils.formatDate(payrolls[payrolls.length-1].created_at) : '-'}</div>
          </div>
        </div>
        <div class="stat-card danger">
          <div class="stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg></div>
          <div class="stat-info">
            <div class="stat-label">${isAR?'NSSF الشهري':'Monthly NSSF'}</div>
            <div class="stat-value">${Utils.formatMoney(employees.filter(e=>e.status==='active').reduce((s,e)=>s+((e.basic_salary||0)*(e.nssf_pct||9)/100),0))}</div>
          </div>
        </div>
      </div>

      <!-- Payroll Runs History -->
      <div class="card mb-4">
        <div class="card-header"><div class="card-title">${isAR?'سجل الرواتب':'Payroll History'}</div></div>
        <div class="table-wrapper">
          <table>
            <thead><tr>
              <th>${isAR?'الفترة':'Period'}</th>
              <th>${isAR?'الموظفون':'Employees'}</th>
              <th>${isAR?'إجمالي الرواتب':'Gross'}</th>
              <th>${isAR?'الخصومات':'Deductions'}</th>
              <th>${isAR?'الصافي':'Net'}</th>
              <th>${isAR?'الحالة':'Status'}</th>
              <th>${isAR?'إجراءات':'Actions'}</th>
            </tr></thead>
            <tbody>
              ${payrolls.slice().reverse().map(p => `
              <tr>
                <td style="font-weight:700">${p.period||'-'}</td>
                <td>${p.emp_count||0}</td>
                <td style="font-weight:700">${Utils.formatMoney(p.gross_total||0)}</td>
                <td style="color:var(--danger)">${Utils.formatMoney(p.deduction_total||0)}</td>
                <td style="font-weight:900;color:var(--success)">${Utils.formatMoney(p.net_total||0)}</td>
                <td><span class="badge badge-${p.status==='posted'?'success':'warning'}">${p.status||'draft'}</span></td>
                <td>
                  <div style="display:flex;gap:4px">
                    <button class="btn btn-ghost btn-sm" onclick="Payroll.viewSlips(${p.id})">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    </button>
                    <button class="btn btn-ghost btn-sm" onclick="Payroll.printPayrollReport(${p.id})">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                    </button>
                  </div>
                </td>
              </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-muted)">${isAR?'لا توجد سجلات':'No payroll runs'}</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Payslip Preview (per employee) -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">${isAR?'كشف الراتب الفردي':'Individual Payslip'}</div>
          <div style="display:flex;gap:8px">
            <select class="form-control" id="payslip-emp" style="width:200px" onchange="Payroll.previewPayslip()">
              <option value="">-- ${isAR?'اختر موظفاً':'Select Employee'} --</option>
              ${employees.filter(e=>e.status==='active').map(e => `<option value="${e.id}">${isAR?(e.name_ar||e.name_en):(e.name_en||e.name_ar)}</option>`).join('')}
            </select>
            <input type="month" class="form-control" id="payslip-month" value="${new Date().toISOString().slice(0,7)}" style="width:150px" onchange="Payroll.previewPayslip()">
          </div>
        </div>
        <div class="modal-body" id="payslip-preview-area">
          <div class="empty-state" style="padding:30px">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:36px;height:36px"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <p>${isAR?'اختر موظفاً لعرض كشف راتبه':'Select an employee to preview their payslip'}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Run Payroll Modal -->
    <div class="modal-overlay" id="payroll-run-modal">
      <div class="modal" style="max-width:700px">
        <div class="modal-header">
          <div class="modal-title">${isAR?'تشغيل الرواتب':'Run Payroll'}</div>
          <button class="btn-icon" onclick="Utils.closeModal('payroll-run-modal')">✕</button>
        </div>
        <div class="modal-body">
          <div class="grid grid-2 mb-3">
            <div class="form-group">
              <label class="form-label">${isAR?'الشهر/الفترة':'Period (Month)'}</label>
              <input type="month" class="form-control" id="run-period" value="${new Date().toISOString().slice(0,7)}">
            </div>
            <div class="form-group">
              <label class="form-label">${isAR?'تاريخ الصرف':'Pay Date'}</label>
              <input type="date" class="form-control" id="run-pay-date" value="${Utils.today()}">
            </div>
          </div>
          <div class="table-wrapper" style="max-height:380px;overflow-y:auto">
            <table>
              <thead style="position:sticky;top:0;z-index:1">
                <tr>
                  <th style="width:30px"><input type="checkbox" id="run-sel-all" onchange="Payroll.selectAllEmp(this.checked)"></th>
                  <th>${isAR?'الموظف':'Employee'}</th>
                  <th>${isAR?'الراتب الأساسي':'Basic'}</th>
                  <th>${isAR?'البدلات':'Allowances'}</th>
                  <th>${isAR?'مكافأة':'Bonus'}</th>
                  <th>${isAR?'خصومات':'Deductions'}</th>
                  <th>${isAR?'الصافي':'Net'}</th>
                </tr>
              </thead>
              <tbody id="run-emp-tbody">
                ${employees.filter(e=>e.status==='active').map(e => {
                  const allowances = (e.transport||0)+(e.housing||0)+(e.other_allowances||0);
                  const nssf       = Utils.round((e.basic_salary||0)*(e.nssf_pct||9)/100);
                  const gross      = (e.basic_salary||0) + allowances;
                  const net        = Utils.round(gross - nssf);
                  return `<tr data-emp-id="${e.id}" data-basic="${e.basic_salary||0}" data-allow="${allowances}" data-nssf="${nssf}" data-gross="${gross}" data-net="${net}">
                    <td><input type="checkbox" class="run-emp-check" value="${e.id}" checked></td>
                    <td style="font-weight:600">${isAR?(e.name_ar||e.name_en):(e.name_en||e.name_ar)}</td>
                    <td>${Utils.formatMoney(e.basic_salary||0)}</td>
                    <td>${Utils.formatMoney(allowances)}</td>
                    <td><input type="number" value="0" min="0" step="0.01" style="width:80px;padding:4px 6px;background:var(--input-bg);border:1px solid var(--border-color);border-radius:6px;font-size:0.78rem;color:var(--success)" data-bonus></td>
                    <td style="color:var(--danger)">${Utils.formatMoney(nssf)}</td>
                    <td style="font-weight:800;color:var(--primary)">${Utils.formatMoney(net)}</td>
                  </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-ghost" onclick="Utils.closeModal('payroll-run-modal')">${isAR?'إلغاء':'Cancel'}</button>
          <button class="btn btn-secondary" onclick="Payroll.processPayroll('draft')">${isAR?'حفظ كمسودة':'Save Draft'}</button>
          <button class="btn btn-primary" onclick="Payroll.processPayroll('posted')">${isAR?'ترحيل الرواتب':'Post Payroll'}</button>
        </div>
      </div>
    </div>`;

    window._allEmpsPayroll = employees;
  }

  function openRunForm() { Utils.openModal('payroll-run-modal'); }

  function selectAllEmp(checked) {
    document.querySelectorAll('.run-emp-check').forEach(cb => cb.checked = checked);
  }

  async function processPayroll(status) {
    const isAR  = i18n.getLang() === 'ar';
    const period = document.getElementById('run-period')?.value;
    const payDate = document.getElementById('run-pay-date')?.value;
    const rows  = [...document.querySelectorAll('#run-emp-tbody tr')].filter(r => r.querySelector('.run-emp-check')?.checked);

    if (!rows.length) { Utils.toast(isAR?'اختر موظفين':'Select employees', 'warning'); return; }

    let grossTotal = 0, dedTotal = 0, netTotal = 0;
    const slips = rows.map(r => {
      const basic  = parseFloat(r.dataset.basic)||0;
      const allow  = parseFloat(r.dataset.allow)||0;
      const bonus  = parseFloat(r.querySelector('[data-bonus]')?.value)||0;
      const deduct = parseFloat(r.dataset.nssf)||0;
      const gross  = basic + allow + bonus;
      const net    = Utils.round(gross - deduct);
      grossTotal += gross; dedTotal += deduct; netTotal += net;
      return { emp_id: parseInt(r.dataset.empId), basic, allow, bonus, deduct, gross, net };
    });

    await DB.add('payroll_runs', {
      period, pay_date: payDate, status,
      emp_count:       slips.length,
      gross_total:     Utils.round(grossTotal),
      deduction_total: Utils.round(dedTotal),
      net_total:       Utils.round(netTotal),
      slips_json:      JSON.stringify(slips),
    });

    Utils.closeModal('payroll-run-modal');
    Utils.toast(isAR?'تم تشغيل الرواتب بنجاح':'Payroll processed!', 'success');
    await render(document.getElementById('page-content'));
  }

  async function previewPayslip() {
    const empId = parseInt(document.getElementById('payslip-emp')?.value);
    const month = document.getElementById('payslip-month')?.value;
    if (!empId || !month) return;

    const emp = (window._allEmpsPayroll||[]).find(e => e.id === empId);
    if (!emp) return;

    const isAR = i18n.getLang() === 'ar';
    const name = isAR ? (emp.name_ar||emp.name_en) : (emp.name_en||emp.name_ar);
    const basic = emp.basic_salary || 0;
    const transport = emp.transport || 0;
    const housing = emp.housing || 0;
    const other = emp.other_allowances || 0;
    const gross = basic + transport + housing + other;
    const nssf  = Utils.round(gross * (emp.nssf_pct||9) / 100);
    const tax   = Utils.round(gross * (emp.tax_pct||0) / 100);
    const net   = Utils.round(gross - nssf - tax);

    const comp = await DB.getSetting('company_name', 'Store');
    Utils.setHTML('#payslip-preview-area', `
    <div style="border:1px solid var(--border-color);border-radius:12px;padding:20px;max-width:600px;margin:0 auto" dir="${isAR?'rtl':'ltr'}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;padding-bottom:12px;border-bottom:2px solid var(--border-color)">
        <div>
          <div style="font-size:1.1rem;font-weight:900;color:var(--primary)">${Utils.sanitize(comp)}</div>
          <div style="font-size:0.75rem;color:var(--text-muted)">${isAR?'كشف راتب':'Payslip'}</div>
        </div>
        <div style="text-align:right">
          <div style="font-weight:700">${name}</div>
          <div style="font-size:0.75rem;color:var(--text-muted)">${emp.position||''}</div>
          <div style="font-size:0.75rem;color:var(--text-muted)">${month}</div>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
        <div>
          <div style="font-weight:700;font-size:0.82rem;margin-bottom:8px;color:var(--success)">${isAR?'المستحقات':'Earnings'}</div>
          ${rowLine(isAR?'الراتب الأساسي':'Basic Salary', emp.basic_salary||0)}
          ${rowLine(isAR?'بدل النقل':'Transport', emp.transport||0)}
          ${rowLine(isAR?'بدل السكن':'Housing', emp.housing||0)}
          ${rowLine(isAR?'بدلات أخرى':'Other Allowances', emp.other_allowances||0)}
          <div style="border-top:1px solid var(--border-color);margin-top:6px;padding-top:6px;display:flex;justify-content:space-between;font-weight:700">
            <span>${isAR?'الإجمالي':'Gross'}</span><span>${Utils.formatMoney(gross)}</span>
          </div>
        </div>
        <div>
          <div style="font-weight:700;font-size:0.82rem;margin-bottom:8px;color:var(--danger)">${isAR?'الخصومات':'Deductions'}</div>
          ${rowLine(isAR?`NSSF (${emp.nssf_pct||9}%)`:`NSSF (${emp.nssf_pct||9}%)`, nssf)}
          ${tax > 0 ? rowLine(isAR?'ضريبة الدخل':'Income Tax', tax) : ''}
          <div style="border-top:1px solid var(--border-color);margin-top:6px;padding-top:6px;display:flex;justify-content:space-between;font-weight:700;color:var(--danger)">
            <span>${isAR?'إجمالي الخصومات':'Total Deductions'}</span><span>${Utils.formatMoney(nssf+tax)}</span>
          </div>
        </div>
      </div>

      <div style="background:var(--primary-alpha);border:1px solid var(--primary);border-radius:10px;padding:12px;display:flex;justify-content:space-between;align-items:center">
        <span style="font-weight:900;font-size:1rem">${isAR?'الراتب الصافي':'Net Salary'}</span>
        <span style="font-weight:900;font-size:1.4rem;color:var(--primary)">${Utils.formatMoney(net)}</span>
      </div>

      <div style="margin-top:16px;text-align:center">
        <button class="btn btn-secondary btn-sm" onclick="Payroll.printPayslip(${empId},'${month}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
          ${isAR?'طباعة':'Print'}
        </button>
      </div>
    </div>`);

    window._payslipData = { emp, month, basic, transport, housing, other, gross, nssf, tax, net };
  }

  function rowLine(label, amount) {
    return `<div style="display:flex;justify-content:space-between;font-size:0.8rem;margin-bottom:3px;padding:3px 0;border-bottom:1px dashed var(--border-color)">
      <span style="color:var(--text-secondary)">${label}</span>
      <span style="font-weight:600">${Utils.formatMoney(amount)}</span>
    </div>`;
  }

  async function printPayslip(empId, month) {
    const d   = window._payslipData;
    if (!d) return;
    const isAR = i18n.getLang() === 'ar';
    const name = isAR ? (d.emp.name_ar||d.emp.name_en) : (d.emp.name_en||d.emp.name_ar);
    const comp = await DB.getSetting('company_name', 'Store');
    const logo = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    Utils.printElement(`
    <div class="doc-a4" dir="${isAR?'rtl':'ltr'}" style="font-family:'Cairo','Inter',sans-serif;padding:20px">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #333;padding-bottom:12px;margin-bottom:20px">
        <div class="doc-company-info" style="display:flex;align-items:center;gap:12px">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain">` : ''}
          <div><h2 style="margin:0">${Utils.sanitize(comp)}</h2><p style="margin:2px 0 0;color:#666">${isAR?'كشف راتب':'Payslip'}</p></div>
        </div>
        <div class="doc-title-block" style="text-align:${isAR?'left':'right'}"><h1 style="font-size:1.4rem;margin:0 0 4px">${isAR?'كشف الراتب':'PAYSLIP'}</h1><div class="doc-date" style="color:#666">${d.month}</div></div>
      </div>
      <div class="doc-parties">
        <div class="doc-party"><h3>${isAR?'الموظف':'Employee'}</h3><p>${name}</p><span>${d.emp.position||''}</span></div>
        <div class="doc-party"><h3>${isAR?'رقم الموظف':'Employee ID'}</h3><p>${d.emp.emp_code||'-'}</p></div>
      </div>
      <table class="doc-table">
        <thead><tr><th>${isAR?'البند':'Item'}</th><th style="text-align:right">${isAR?'المبلغ':'Amount'}</th></tr></thead>
        <tbody>
          <tr style="background:#f0f9f0"><td>${isAR?'الراتب الأساسي':'Basic Salary'}</td><td style="text-align:right">${Utils.formatMoney(d.basic)}</td></tr>
          ${d.transport?`<tr><td>${isAR?'بدل المواصلات':'Transport'}</td><td style="text-align:right">${Utils.formatMoney(d.transport)}</td></tr>`:''}
          ${d.housing?`<tr><td>${isAR?'بدل السكن':'Housing'}</td><td style="text-align:right">${Utils.formatMoney(d.housing)}</td></tr>`:''}
          ${d.other?`<tr><td>${isAR?'بدلات أخرى':'Other Allowances'}</td><td style="text-align:right">${Utils.formatMoney(d.other)}</td></tr>`:''}
          <tr style="font-weight:700;background:#e8f5e9"><td>${isAR?'إجمالي الراتب':'Gross Salary'}</td><td style="text-align:right">${Utils.formatMoney(d.gross)}</td></tr>
          <tr style="color:#c0392b"><td>NSSF (${d.emp.nssf_pct||9}%)</td><td style="text-align:right">-${Utils.formatMoney(d.nssf)}</td></tr>
          ${d.tax?`<tr style="color:#c0392b"><td>${isAR?'ضريبة الدخل':'Income Tax'}</td><td style="text-align:right">-${Utils.formatMoney(d.tax)}</td></tr>`:''}
          <tr style="font-weight:900;font-size:12pt;background:#e8f4fd"><td>${isAR?'الراتب الصافي':'NET SALARY'}</td><td style="text-align:right">${Utils.formatMoney(d.net)}</td></tr>
        </tbody>
      </table>
      <div style="margin-top:60px;display:flex;justify-content:space-between">
        <div style="border-top:1px solid #999;padding-top:8px;text-align:center;width:180px">${isAR?'توقيع الموظف':'Employee Signature'}</div>
        <div style="border-top:1px solid #999;padding-top:8px;text-align:center;width:180px">${isAR?'توقيع مدير الموارد البشرية':'HR Manager'}</div>
      </div>
    </div>`, `Payslip - ${name}`);
  }

  async function printPayrollReport(runId) {
    const run  = await DB.get('payroll_runs', runId);
    if (!run) return;
    const isAR = i18n.getLang() === 'ar';
    const slips = JSON.parse(run.slips_json||'[]');
    const emps  = window._allEmpsPayroll || await DB.getAll('employees');
    const comp  = await DB.getSetting('company_name', 'Store');
    const logo  = await DB.getSetting('company_logo', '');
    const printLogo = await DB.getSetting('print_logo', true);
    Utils.printElement(`
    <div class="doc-a4" dir="${isAR?'rtl':'ltr'}" style="font-family:'Cairo','Inter',sans-serif;padding:20px">
      <div class="doc-header" style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #333;padding-bottom:12px;margin-bottom:20px">
        <div class="doc-company-info" style="display:flex;align-items:center;gap:12px">
          ${(printLogo && logo) ? `<img src="${logo}" style="max-width:60px;max-height:60px;object-fit:contain">` : ''}
          <h2 style="margin:0">${Utils.sanitize(comp)}</h2>
        </div>
        <div class="doc-title-block" style="text-align:${isAR?'left':'right'}"><h1 style="font-size:1.4rem;margin:0 0 4px">${isAR?'كشف رواتب':'PAYROLL REPORT'}</h1><div class="doc-date" style="color:#666">${run.period}</div></div>
      </div>
      <table class="doc-table">
        <thead><tr>
          <th>#</th><th>${isAR?'الموظف':'Employee'}</th>
          <th>${isAR?'الإجمالي':'Gross'}</th><th>${isAR?'NSSF':'NSSF'}</th><th>${isAR?'الصافي':'Net'}</th>
        </tr></thead>
        <tbody>
          ${slips.map((s,i) => {
            const emp  = emps.find(e => e.id === s.emp_id);
            const name = emp ? (isAR?(emp.name_ar||emp.name_en):(emp.name_en||emp.name_ar)) : '-';
            return `<tr><td>${i+1}</td><td>${name}</td><td>${Utils.formatMoney(s.gross)}</td><td>${Utils.formatMoney(s.deduct)}</td><td>${Utils.formatMoney(s.net)}</td></tr>`;
          }).join('')}
        </tbody>
        <tfoot><tr style="font-weight:900">
          <td colspan="2">${isAR?'الإجمالي':'TOTAL'}</td>
          <td>${Utils.formatMoney(run.gross_total)}</td>
          <td>${Utils.formatMoney(run.deduction_total)}</td>
          <td>${Utils.formatMoney(run.net_total)}</td>
        </tr></tfoot>
      </table>
    </div>`, 'Payroll Report');
  }

  async function viewSlips(runId) {
    Utils.toast('Coming soon', 'info');
  }

  return { render, openRunForm, selectAllEmp, processPayroll, previewPayslip, printPayslip, printPayrollReport, viewSlips };
})();

window.Payroll = Payroll;
window.PayrollModule = Payroll; // alias
