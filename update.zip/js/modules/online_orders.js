/**
 * Red Shark POS — Online Orders & Storefront Bridge Module
 * Integrates with Supabase Multi-Tenant E-Commerce Storefront
 * - Real-time incoming order sound notifications (Talabat/UberEats style chime)
 * - Complete lifecycle: Received -> Preparing -> Out for Delivery -> Completed / Cancelled
 * - 1-Click Print Thermal Packing Slip & Invoice for delivery bag attachment
 * - Full POS Integration: Converts to Sale, deducts inventory, records in CashBox, updates Customer & Reports
 * - Catalog & Stock Sync from Red Shark POS to Supabase
 */

const OnlineOrders = (() => {
  // Default connection credentials matching Supabase CloudSync
  const DEFAULT_SUPABASE_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
  const DEFAULT_SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";

  let _orders = [];
  let _activeFilter = 'all'; // 'all', 'received', 'preparing', 'out_for_delivery', 'completed', 'cancelled'
  let _pollInterval = null;
  let _chimeInterval = null;
  let _audioCtx = null;
  let _isMuted = false;
  let _lastNotifiedOrderId = null;
  let _resolvedShopId = null;

  // ── 1. Settings & Config Helpers ──────────────────────────────────────────
  async function getConfig() {
    let url = DEFAULT_SUPABASE_URL;
    let key = DEFAULT_SUPABASE_KEY;
    let slug = '';
    let autoPrint = false;
    let savedPin = null;

    if (typeof DB !== 'undefined') {
      try {
        const savedUrl = await DB.getSetting('online_store_url', null);
        const savedKey = await DB.getSetting('online_store_key', null);
        const savedSlug = await DB.getSetting('online_store_shop_slug', null);
        savedPin = await DB.getSetting('online_store_cloud_pin', null);
        const savedAutoPrint = await DB.getSetting('online_store_autoprint', false);

        if (savedUrl) url = savedUrl.trim();
        if (savedKey) key = savedKey.trim();
        if (savedSlug) slug = savedSlug.trim();
        autoPrint = savedAutoPrint === true || savedAutoPrint === 'true';
      } catch (e) {}
    }

    // If user is currently editing or viewing the Settings screen, prioritize active input
    if (typeof document !== 'undefined') {
      const slugInput = document.getElementById('cfg-shop-slug');
      if (slugInput && slugInput.value && slugInput.value.trim()) {
        slug = slugInput.value.trim().toLowerCase();
      }
    }

    if (!slug) {
      slug = (localStorage.getItem('redshark_shop_slug') || '').trim();
    }

    const pin = savedPin || localStorage.getItem('redshark_cloud_pin') || '';
    return { url, key, slug, autoPrint, pin };
  }

  function getHeaders(key) {
    return {
      "apikey": key,
      "Authorization": `Bearer ${key}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation"
    };
  }

  let _resolvedShopSlug = '';

  // Resolves the Shop UUID from the slug (e.g. 'bobmarket')
  async function resolveShopId(cfg, forceFresh = false) {
    if (!cfg || !cfg.slug || !cfg.slug.trim()) return null;
    const cleanSlug = cfg.slug.trim().toLowerCase();

    // 1. If in-memory already verified during this session and not forced fresh
    if (!forceFresh && _resolvedShopId && _resolvedShopSlug === cleanSlug) {
      return _resolvedShopId;
    }

    // 2. ALWAYS query Supabase directly first to get the authoritative, current tenant UUID
    try {
      const resTenant = await fetch(`${cfg.url}/rest/v1/tenants?slug=eq.${encodeURIComponent(cleanSlug)}&select=id,shop_name,is_active`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(4500)
      });
      if (resTenant.ok) {
        const tenants = await resTenant.json();
        if (tenants && tenants.length > 0) {
          const t = tenants[0];
          _resolvedShopId = t.id;
          _resolvedShopSlug = cleanSlug;
          try { localStorage.setItem('rs_resolved_shop_id_' + cleanSlug, t.id); } catch(e) {}
          return _resolvedShopId;
        } else {
          // Auto-provision tenant in Supabase if not yet created in Master Portal
          try {
            const createRes = await fetch(`${cfg.url}/rest/v1/tenants`, {
              method: 'POST',
              headers: getHeaders(cfg.key),
              body: JSON.stringify({
                shop_name: cfg.slug,
                slug: cfg.slug,
                is_active: true,
                link_pos_stock: true,
                currency: 'USD',
                currency_lbp_rate: 89500
              })
            });
            if (createRes.ok) {
              const created = await createRes.json();
              if (created && created[0]) {
                _resolvedShopId = created[0].id;
                _resolvedShopSlug = cleanSlug;
                try { localStorage.setItem('rs_resolved_shop_id_' + cleanSlug, created[0].id); } catch(e) {}
                console.log('[OnlineOrders] Auto-provisioned new tenant in cloud for slug:', cfg.slug);
                return _resolvedShopId;
              }
            }
          } catch(err) {}
        }
      }

      // Fallback to shops view/table
      const res = await fetch(`${cfg.url}/rest/v1/shops?slug=eq.${encodeURIComponent(cleanSlug)}&select=id,name,is_active`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(4500)
      });
      if (res.ok) {
        const shops = await res.json();
        if (shops && shops.length > 0) {
          _resolvedShopId = shops[0].id;
          _resolvedShopSlug = cleanSlug;
          try { localStorage.setItem('rs_resolved_shop_id_' + cleanSlug, shops[0].id); } catch(e) {}
          return _resolvedShopId;
        }
      }
    } catch (e) {
      console.warn('[OnlineOrders] Could not resolve shop UUID by slug over network, trying cache:', e);
    }

    // 3. Fallback to cache ONLY if network is down
    const cached = localStorage.getItem('rs_resolved_shop_id_' + cleanSlug);
    if (cached) {
      _resolvedShopId = cached;
      _resolvedShopSlug = cleanSlug;
      return _resolvedShopId;
    }
    return null;
  }

  // ── 2. Audio Chime (Synthesized Alert Sound) ───────────────────────────────
  function playAlertChime() {
    if (_isMuted) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      if (!_audioCtx) _audioCtx = new AudioContext();
      if (_audioCtx.state === 'suspended') _audioCtx.resume();

      const now = _audioCtx.currentTime;
      // High-energy 2-tone chime
      const tones = [
        { freq: 880, start: 0.0, dur: 0.15 },
        { freq: 1174.66, start: 0.18, dur: 0.22 },
        { freq: 880, start: 0.45, dur: 0.15 },
        { freq: 1318.51, start: 0.63, dur: 0.35 }
      ];

      tones.forEach(t => {
        const osc = _audioCtx.createOscillator();
        const gain = _audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(t.freq, now + t.start);

        gain.gain.setValueAtTime(0.01, now + t.start);
        gain.gain.exponentialRampToValueAtTime(0.35, now + t.start + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + t.start + t.dur);

        osc.connect(gain);
        gain.connect(_audioCtx.destination);

        osc.start(now + t.start);
        osc.stop(now + t.start + t.dur);
      });
    } catch (err) {
      console.warn('[OnlineOrders] Audio chime warning:', err);
    }
  }

  function startChimeLoop() {
    if (_chimeInterval) return;
    playAlertChime();
    _chimeInterval = setInterval(() => {
      const hasPending = _orders.some(o => o.order_status === 'received');
      if (hasPending) {
        playAlertChime();
      } else {
        stopChimeLoop();
      }
    }, 4500);
  }

  function stopChimeLoop() {
    if (_chimeInterval) {
      clearInterval(_chimeInterval);
      _chimeInterval = null;
    }
  }

  // ── 3. Real-Time Fetch & State Sync ────────────────────────────────────────
  async function fetchOrders(silent = false) {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);

      let query = `${cfg.url}/rest/v1/orders?select=*,order_items(*)&order=created_at.desc&limit=60`;
      if (shopId) {
        query += `&shop_id=eq.${shopId}`;
      }

      const res = await fetch(query, { headers: getHeaders(cfg.key) });
      if (!res.ok) {
        if (!silent) console.warn('[OnlineOrders] Orders fetch returned status:', res.status);
        return;
      }

      const incoming = await res.json();
      if (!Array.isArray(incoming)) return;

      // Filter to ONLY genuine online store orders (exclude in-store POS walk-in sales)
      const genuineOnlineOrders = incoming.filter(o => {
        if (o.pos_synced === true) return false;
        if (o.order_number && (o.order_number.startsWith('INV-') || o.order_number.includes('-INV-'))) return false;
        try {
          const n = typeof o.notes === 'string' ? JSON.parse(o.notes) : (o.notes || {});
          if (n.source === 'pos') return false;
        } catch(e) {}
        return true;
      });

      const previousPending = _orders.filter(o => o.order_status === 'received').map(o => o.id);
      _orders = genuineOnlineOrders;

      // Check for brand new received orders
      const currentPending = _orders.filter(o => o.order_status === 'received');
      const newOrders = currentPending.filter(o => !previousPending.includes(o.id));

      if (newOrders.length > 0 && currentPending.length > 0) {
        const latest = newOrders[0];
        if (latest.id !== _lastNotifiedOrderId) {
          _lastNotifiedOrderId = latest.id;
          startChimeLoop();

          const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
          const msg = isAR
            ? `🛍️ طلب أونلاين جديد #${latest.order_number || ''} من ${latest.customer_name} (${latest.total || 0} ${latest.currency_code || 'USD'})`
            : `🛍️ New Online Order #${latest.order_number || ''} from ${latest.customer_name} (${latest.total || 0} ${latest.currency_code || 'USD'})`;

          if (typeof Utils !== 'undefined' && Utils.toast) {
            Utils.toast(msg, 'warning', 8000);
          }

          // Browser Desktop Notification if granted
          if ('Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification('Red Shark POS — New Online Order', {
                body: `${latest.customer_name} placed order #${latest.order_number} for ${latest.total} ${latest.currency_code || 'USD'}`,
                icon: 'favicon.png'
              });
            } catch (e) {}
          }

          // Auto-print receipt if enabled
          if (cfg.autoPrint) {
            printOrderSlip(latest, true);
          }
        }
      } else if (currentPending.length === 0) {
        stopChimeLoop();
      }

      updateBadges();

      // Refresh UI if online-orders page is currently active
      const container = document.getElementById('online-orders-container');
      if (container) {
        renderOrderList();
      }
    } catch (e) {
      if (!silent) console.warn('[OnlineOrders] Error fetching orders:', e);
    }
  }

  function updateBadges() {
    const receivedCount = _orders.filter(o => o.order_status === 'received').length;

    // Topbar live count badge
    const topBadge = document.getElementById('online-orders-count-badge');
    if (topBadge) {
      if (receivedCount > 0) {
        topBadge.textContent = receivedCount;
        topBadge.style.display = 'inline-block';
      } else {
        topBadge.style.display = 'none';
      }
    }

    // Sidebar badge
    const sideBadge = document.getElementById('sidebar-online-orders-badge');
    if (sideBadge) {
      if (receivedCount > 0) {
        sideBadge.textContent = receivedCount;
        sideBadge.style.display = 'inline-block';
      } else {
        sideBadge.style.display = 'none';
      }
    }
  }

  // ── 4. Order Status Lifecycle Management ───────────────────────────────────
  async function updateOrderStatus(orderId, newStatus, extraData = {}) {
    try {
      const cfg = await getConfig();
      let payload = {
        order_status: newStatus,
        updated_at: new Date().toISOString(),
        ...extraData
      };

      let res = await fetch(`${cfg.url}/rest/v1/orders?id=eq.${encodeURIComponent(orderId)}`, {
        method: 'PATCH',
        headers: getHeaders(cfg.key),
        body: JSON.stringify(payload)
      });

      // If failed due to missing column (e.g. PGRST204), retry with basic status update
      if (!res.ok) {
        const errTxt = await res.text();
        if (errTxt.includes('PGRST204')) {
          console.warn('[OnlineOrders] Column mismatch in Supabase, retrying with basic status update...', errTxt);
          res = await fetch(`${cfg.url}/rest/v1/orders?id=eq.${encodeURIComponent(orderId)}`, {
            method: 'PATCH',
            headers: getHeaders(cfg.key),
            body: JSON.stringify({
              order_status: newStatus,
              updated_at: new Date().toISOString()
            })
          });
        }
        if (!res.ok) {
          const finalErr = await res.text();
          throw new Error(`Failed to update status: ${finalErr}`);
        }
      }

      // Update local copy
      const local = _orders.find(o => o.id === orderId);
      if (local) {
        local.order_status = newStatus;
        Object.assign(local, extraData);
      }

      updateBadges();
      renderOrderList();

      const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
      const statusLabels = {
        preparing: isAR ? 'جاري تحضير الطلب' : 'Order marked as Preparing',
        out_for_delivery: isAR ? 'الطلب خرج للتوصيل' : 'Order Out for Delivery',
        completed: isAR ? 'تم إتمام الطلب' : 'Order Completed',
        cancelled: isAR ? 'تم إلغاء الطلب' : 'Order Cancelled'
      };

      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(`✅ ${statusLabels[newStatus] || newStatus}`, 'success');
      }
      return true;
    } catch (e) {
      console.error('[OnlineOrders] Status update error:', e);
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(`⚠️ ${e.message}`, 'error');
      }
      return false;
    }
  }

  // Helper to extract items from either order_items relation OR items JSONB column
  function getOrderItems(order) {
    if (!order) return [];
    if (Array.isArray(order.order_items) && order.order_items.length > 0) {
      return order.order_items;
    }
    if (Array.isArray(order.items) && order.items.length > 0) {
      return order.items;
    }
    if (typeof order.items === 'string' && order.items.trim()) {
      try {
        const p = JSON.parse(order.items);
        if (Array.isArray(p) && p.length > 0) return p;
      } catch (e) {}
    }
    return [];
  }

  // ── 5. Full POS Sale Conversion & Inventory Deduction ──────────────────────
  async function convertOrderToSale(orderId) {
    const order = _orders.find(o => o.id === orderId);
    if (!order) return;

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');

    if (order.pos_synced && order.pos_invoice_ref) {
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? `⚠️ هذا الطلب تم تحويله بالفعل لفاتورة رقم ${order.pos_invoice_ref}` : `⚠️ Order already converted to sale invoice #${order.pos_invoice_ref}`, 'warning');
      }
      return;
    }

    try {
      // 1. Resolve or Create Customer in Local POS Database
      let localCustId = null;
      let custName = order.customer_name || (isAR ? 'عميل أونلاين' : 'Online Customer');

      if (typeof DB !== 'undefined') {
        const customers = (await DB.getAll('customers')) || [];
        const phoneClean = (order.customer_phone || '').replace(/[^0-9]/g, '');

        let match = customers.find(c => {
          const cPhone = (c.phone || '').replace(/[^0-9]/g, '');
          return (cPhone && phoneClean && cPhone.includes(phoneClean)) ||
                 (c.name_en && c.name_en.toLowerCase() === custName.toLowerCase()) ||
                 (c.name_ar && c.name_ar === custName);
        });

        if (match) {
          localCustId = match.id;
          custName = match.name_en || match.name_ar || custName;
        } else {
          // Add new customer to local database
          const deliveryAddr = typeof order.delivery_address === 'object' && order.delivery_address
            ? `${order.delivery_address.city || ''}, ${order.delivery_address.street_address || ''} ${order.delivery_address.building || ''}`
            : (order.delivery_address || '');

          const newCust = {
            name_en: custName,
            name_ar: custName,
            phone: order.customer_phone || '',
            email: order.customer_email || '',
            address: deliveryAddr,
            balance: 0,
            points_balance: 0,
            created_at: new Date().toISOString()
          };
          localCustId = await DB.add('customers', newCust);
        }
      }

      // 2. Build Cart Items & Deduct Stock from Local DB
      const orderItems = getOrderItems(order);
      const localCart = [];
      const allLocalItems = (typeof DB !== 'undefined') ? (await DB.getAll('items')) || [] : [];
      const whId = (typeof window !== 'undefined' && window._posWarehouseId) ? window._posWarehouseId : 1;

      for (const oi of orderItems) {
        const itName = oi.product_name || oi.name || oi.title || '';
        // Try matching by barcode, sku, pos_product_id, product_id, or name
        let matched = allLocalItems.find(i =>
          (i.barcode && oi.barcode && i.barcode === oi.barcode) ||
          (i.id && oi.pos_product_id && String(i.id) === String(oi.pos_product_id)) ||
          (i.id && oi.product_id && String(i.id) === String(oi.product_id)) ||
          (i.name_en && itName && i.name_en.toLowerCase() === itName.toLowerCase()) ||
          (i.name_ar && itName && i.name_ar === itName)
        );

        const qty = parseFloat(oi.quantity || oi.qty) || 1;
        const unitPrice = parseFloat(oi.unit_price || oi.price) || 0;
        const itemTotal = parseFloat(oi.total_price || oi.total) || (qty * unitPrice);

        if (matched) {
          localCart.push({
            item_id: matched.id,
            name_en: matched.name_en || itName,
            name_ar: matched.name_ar || itName,
            barcode: matched.barcode || '',
            qty: qty,
            price: unitPrice,
            cost_price: matched.cost_price || 0,
            total: itemTotal,
            line_type: 'sale',
            selling_unit: matched.selling_unit || 'piece'
          });

          // Deduct stock from local items table
          if (typeof DB !== 'undefined') {
            if (!matched.warehouse_stocks) matched.warehouse_stocks = {};
            if (matched.warehouse_stocks[whId] === undefined) matched.warehouse_stocks[whId] = matched.stock_qty || 0;

            const newWhQty = (matched.warehouse_stocks[whId] || 0) - qty;
            const newTotalQty = (matched.stock_qty || 0) - qty;

            matched.warehouse_stocks[whId] = Math.max(0, newWhQty);
            matched.stock_qty = Math.max(0, newTotalQty);

            await DB.update('items', matched);

            // Add stock movement record
            await DB.add('stock_movements', {
              item_id: matched.id,
              type: 'sale',
              ref: order.order_number,
              qty: -qty,
              notes: `Online Order #${order.order_number} (${order.fulfillment_type || 'delivery'})`,
              date: new Date().toISOString()
            });
          }
        } else {
          // Unmatched custom product from online catalog
          localCart.push({
            item_id: null,
            name_en: itName || 'Item',
            name_ar: itName || 'صنف',
            qty: qty,
            price: unitPrice,
            cost_price: 0,
            total: itemTotal,
            line_type: 'sale'
          });
        }
      }

      // Add Delivery Fee as separate item line if applicable
      const deliveryFee = parseFloat(order.delivery_fee) || 0;
      if (deliveryFee > 0) {
        localCart.push({
          item_id: null,
          name_en: 'Delivery Fee',
          name_ar: 'أجور توصيل',
          qty: 1,
          price: deliveryFee,
          total: deliveryFee,
          line_type: 'fee'
        });
      }

      // 3. Generate Official POS Invoice Number
      let invoicePrefix = 'INV-';
      if (typeof POS !== 'undefined' && typeof POS._getInvoicePrefix === 'function') {
        invoicePrefix = POS._getInvoicePrefix();
      }
      const ref = (typeof DB !== 'undefined')
        ? await DB.nextSeq('sales', invoicePrefix, 6)
        : `INV-${Date.now().toString().slice(-6)}`;

      const grandTotalUSD = parseFloat(order.total) || 0;
      const rate = parseFloat(order.exchange_rate) || 89500;
      const grandTotalLBP = parseFloat(order.total_secondary) || Math.round(grandTotalUSD * rate);

      const payMethod = (order.payment_method === 'cod' || order.payment_method === 'cash_in_store')
        ? 'cash'
        : (order.payment_method === 'card_on_delivery' ? 'card' : 'online');

      const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;

      // 4. Construct Full POS Sale Record
      const sale = {
        ref,
        customer_id: localCustId,
        customer_name: custName,
        customer_phone: order.customer_phone || '',
        salesperson_id: user?.id || null,
        salesperson_name: user?.full_name || user?.username || 'Online Storefront',
        items: JSON.stringify(localCart),
        subtotal: parseFloat(order.subtotal) || grandTotalUSD,
        discount: parseFloat(order.discount_amount) || 0,
        discount_amount: parseFloat(order.discount_amount) || 0,
        vat: 0,
        grand_total: grandTotalUSD,
        grand_total_2: grandTotalLBP,
        payment_method: payMethod,
        amount_tendered: grandTotalUSD,
        amount_tendered_2: grandTotalLBP,
        paid_amount: grandTotalUSD,
        change_c1: 0,
        change_c2: 0,
        status: 'paid',
        source: 'online_store',
        online_order_id: order.id,
        online_order_number: order.order_number,
        fulfillment_type: order.fulfillment_type || 'delivery',
        delivery_address: order.delivery_address,
        notes: `Online Store #${order.order_number}${order.notes ? ' — ' + order.notes : ''}`,
        created_at: new Date().toISOString()
      };

      let saleId = null;
      if (typeof DB !== 'undefined') {
        saleId = await DB.add('sales', sale);
      }

      // 5. Record movement in CashBox Session
      const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
      if (cb && typeof cb.recordSale === 'function') {
        try {
          await cb.recordSale(grandTotalUSD, `Online Order #${order.order_number} (${order.fulfillment_type}) -> Invoice ${ref}`);
        } catch (errCb) {
          console.warn('[OnlineOrders] Cashbox recording note:', errCb);
        }
      }

      // 6. Update Order Status in Supabase
      await updateOrderStatus(order.id, 'completed', {
        pos_synced: true,
        payment_status: 'paid',
        pos_invoice_ref: ref
      });

      // 7. Auto Print Finished Invoice for Delivery Packing
      await printOrderSlip({ ...order, pos_invoice_ref: ref }, false);

      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? `✅ تم إتمام البيع بنجاح وتوليد فاتورة رقم ${ref}` : `✅ Order processed as Sale Invoice #${ref}`, 'success');
      }

      return ref;
    } catch (err) {
      console.error('[OnlineOrders] Convert to sale error:', err);
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(`⚠️ Error processing sale: ${err.message}`, 'error');
      }
    }
  }

  // ── 6. 1-Click Thermal Print Packing Slip & Invoice ─────────────────────────
  async function printOrderSlip(order, isPackingSlip = false) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const items = getOrderItems(order);
    const orderNum = order.order_number || 'N/A';
    const totalUSD = (parseFloat(order.total) || 0).toFixed(2);
    const rate = parseFloat(order.exchange_rate) || 89500;
    const totalLBP = (parseFloat(order.total_secondary) || Math.round(totalUSD * rate)).toLocaleString();

    let addressStr = '';
    if (order.delivery_address) {
      if (typeof order.delivery_address === 'object') {
        const a = order.delivery_address;
        addressStr = [a.city, a.street_address, a.building, a.floor, a.apartment, a.landmark].filter(Boolean).join(', ');
      } else {
        addressStr = String(order.delivery_address);
      }
    }

    const title = isPackingSlip ? (isAR ? 'إشعار تحضير وتغليف طلبية' : 'ONLINE ORDER PACKING SLIP') : (isAR ? 'فاتورة توصيل طلبية أونلاين' : 'DELIVERY ORDER INVOICE');

    const html = `
      <div style="font-family:'Segoe UI',Tahoma,sans-serif;width:100%;max-width:320px;margin:0 auto;color:#000;font-size:12px;padding:4px">
        <div style="text-align:center;border-bottom:2px dashed #000;padding-bottom:8px;margin-bottom:8px">
          <div style="font-size:16px;font-weight:900;text-transform:uppercase">RED SHARK POS</div>
          <div style="font-size:13px;font-weight:800;margin-top:2px;background:#000;color:#fff;padding:2px 6px;display:inline-block;border-radius:3px">${title}</div>
          <div style="font-size:18px;font-weight:900;margin-top:6px;letter-spacing:1px">#${orderNum}</div>
          <div style="font-size:10px;color:#444">${new Date(order.created_at || Date.now()).toLocaleString()}</div>
          ${order.pos_invoice_ref ? `<div style="font-size:11px;font-weight:800;margin-top:2px">POS Inv: ${order.pos_invoice_ref}</div>` : ''}
        </div>

        <div style="border-bottom:1px solid #000;padding-bottom:6px;margin-bottom:6px">
          <div style="font-weight:800;font-size:13px">👤 ${order.customer_name}</div>
          <div style="font-size:12px;font-weight:700">📞 ${order.customer_phone}</div>
          <div style="font-size:11px;margin-top:2px">🛵 <strong>${order.fulfillment_type === 'pickup' ? 'In-Store Pickup (استلام بالمحل)' : 'Home Delivery (توصيل)'}</strong></div>
          ${addressStr ? `<div style="font-size:11px;margin-top:3px;background:#f3f4f6;padding:4px;border-radius:4px">📍 ${addressStr}</div>` : ''}
          ${order.notes ? `<div style="font-size:11px;color:#b91c1c;margin-top:3px">⚠️ Note: ${order.notes}</div>` : ''}
        </div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:8px;font-size:12px">
          <thead>
            <tr style="border-bottom:1px solid #000;text-align:left">
              <th style="padding:4px 0">${isAR ? 'الصنف' : 'Item'}</th>
              <th style="padding:4px 0;text-align:center">${isAR ? 'الكمية' : 'Qty'}</th>
              <th style="padding:4px 0;text-align:right">${isAR ? 'المجموع' : 'Total'}</th>
            </tr>
          </thead>
          <tbody>
            ${items.map(it => `
              <tr style="border-bottom:1px dotted #ccc">
                <td style="padding:4px 0;font-weight:700">${it.product_name}${it.variant_name ? ` (${it.variant_name})` : ''}</td>
                <td style="padding:4px 0;text-align:center;font-weight:800">x${it.quantity}</td>
                <td style="padding:4px 0;text-align:right;font-weight:800">$${(parseFloat(it.total_price) || 0).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="border-top:1px solid #000;padding-top:4px;font-size:12px">
          <div style="display:flex;justify-content:space-between;margin-bottom:2px">
            <span>${isAR ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
            <span>$${(parseFloat(order.subtotal) || 0).toFixed(2)}</span>
          </div>
          ${parseFloat(order.delivery_fee) > 0 ? `
          <div style="display:flex;justify-content:space-between;margin-bottom:2px">
            <span>${isAR ? 'أجور التوصيل:' : 'Delivery Fee:'}</span>
            <span>$${(parseFloat(order.delivery_fee) || 0).toFixed(2)}</span>
          </div>` : ''}
          <div style="display:flex;justify-content:space-between;font-size:15px;font-weight:900;border-top:2px solid #000;padding-top:4px;margin-top:4px">
            <span>TOTAL:</span>
            <span>$${totalUSD} USD</span>
          </div>
          <div style="text-align:right;font-size:12px;font-weight:800;color:#1e40af">
            ≈ ${totalLBP} L.L.
          </div>
        </div>

        <div style="text-align:center;border-top:1px dashed #000;margin-top:10px;padding-top:6px;font-size:11px">
          <div>💳 Method: <strong>${(order.payment_method || 'COD').toUpperCase()}</strong></div>
          <div style="margin-top:4px;font-weight:700">Thank you for ordering with us!</div>
        </div>
      </div>
    `;

    try {
      if (window.PrintEngine && typeof window.PrintEngine.printReceipt === 'function') {
        const dummySale = {
          ref: order.order_number,
          customer_name: order.customer_name,
          grand_total: parseFloat(order.total) || 0,
          grand_total_2: parseFloat(order.total_secondary) || 0,
          created_at: order.created_at
        };
        const rawItems = items.map(it => ({
          name_en: it.product_name,
          name_ar: it.product_name,
          qty: it.quantity,
          price: it.unit_price,
          total: it.total_price
        }));
        await window.PrintEngine.printReceipt(dummySale, rawItems, { name_en: order.customer_name, phone: order.customer_phone }, { pageSize: '80mm' });
      } else if (typeof Utils !== 'undefined' && Utils.printElement) {
        await Utils.printElement(html, `Order-${orderNum}`, '80mm');
      }
    } catch (e) {
      console.error('[OnlineOrders] Print error:', e);
      if (typeof Utils !== 'undefined' && Utils.printElement) {
        await Utils.printElement(html, `Order-${orderNum}`, '80mm');
      }
    }
  }

  // ── 7. Catalog & Stock Sync to Supabase ────────────────────────────────────
  async function syncCatalogToCloud() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    if (typeof DB === 'undefined') return;

    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) {
        throw new Error(`Shop with slug "${cfg.slug}" was not found in Supabase. Please check your Shop ID.`);
      }

      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? '⏳ جاري مزامنة الأصناف والمخزون مع المتجر الإلكتروني...' : '⏳ Syncing catalog & stock with Online Store...', 'info');
      }

      // 1. Sync Categories
      const localCats = (await DB.getAll('categories')) || [];
      const cloudCats = [];

      for (const c of localCats) {
        const catSlug = (c.name_en || c.name || `cat-${c.id}`).toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
        cloudCats.push({
          shop_id: shopId,
          name: c.name_en || c.name_ar || c.name,
          name_ar: c.name_ar || c.name || '',
          name_en: c.name_en || c.name || '',
          slug: catSlug,
          display_order: c.sort_order || 0,
          is_active: true
        });
      }

      if (cloudCats.length > 0) {
        await fetch(`${cfg.url}/rest/v1/categories?on_conflict=shop_id,slug`, {
          method: 'POST',
          headers: { ...getHeaders(cfg.key), 'Prefer': 'resolution=merge-duplicates' },
          body: JSON.stringify(cloudCats)
        });
      }

      // Fetch cloud categories to map IDs
      const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=id,name,slug`, {
        headers: getHeaders(cfg.key)
      });
      const catMap = new Map();
      if (catRes.ok) {
        const cats = await catRes.json();
        cats.forEach(c => {
          catMap.set(c.slug, c.id);
          catMap.set((c.name || '').toLowerCase(), c.id);
        });
      }

      // Sync category images into tenant's category_images map
      try {
        const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key)
        });
        if (tenantRes.ok) {
          const tData = await tenantRes.json();
          if (tData && tData[0]) {
            let bObj = {};
            try {
              bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
            } catch(e) {}
            bObj.category_images = bObj.category_images || {};
            let hasNewCatImg = false;
            for (const c of localCats) {
              const slug = (c.name_en || c.name || `cat-${c.id}`).toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');
              const cloudCatId = catMap.get(slug) || catMap.get((c.name || '').toLowerCase());
              const catImg = c.image_url || c.image || null;
              if (cloudCatId && catImg && bObj.category_images[cloudCatId] !== catImg) {
                bObj.category_images[cloudCatId] = catImg;
                hasNewCatImg = true;
              }
            }
            if (hasNewCatImg) {
              await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
                method: 'PATCH',
                headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
                body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
              });
            }
          }
        }
      } catch(catImgErr) {
        console.warn('Sync category images error:', catImgErr);
      }

      // 2. Sync Items
      const localItems = (await DB.getAll('items')) || [];
      // Include items marked for online or all active items
      const itemsToSync = localItems.filter(i => i.status !== 'inactive');

      // Fetch existing cloud products to detect deleted/inactive items in POS
      let cloudExistingIds = [];
      try {
        let fromIdx = 0;
        let hasMore = true;
        while (hasMore) {
          const checkRes = await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=pos_product_id`, {
            headers: {
              ...getHeaders(cfg.key),
              'Range': `${fromIdx}-${fromIdx + 999}`
            }
          });
          if (checkRes.ok) {
            const batch = await checkRes.json();
            if (Array.isArray(batch) && batch.length > 0) {
              cloudExistingIds.push(...batch.map(p => p.pos_product_id).filter(Boolean));
              if (batch.length < 1000) hasMore = false;
              else fromIdx += 1000;
            } else {
              hasMore = false;
            }
          } else {
            hasMore = false;
          }
        }
      } catch (err) {
        console.warn('Could not query existing cloud products for delete sync:', err);
      }

      // Identify items that were deleted or deactivated in POS
      const localActivePosIds = new Set(itemsToSync.map(i => String(i.id)));
      const posIdsToDelete = cloudExistingIds.filter(id => !localActivePosIds.has(id));

      if (posIdsToDelete.length > 0) {
        try {
          const delChunkSize = 80;
          for (let i = 0; i < posIdsToDelete.length; i += delChunkSize) {
            const chunk = posIdsToDelete.slice(i, i + delChunkSize);
            const inQuery = chunk.map(id => encodeURIComponent(String(id).trim())).join(',');
            await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&pos_product_id=in.(${inQuery})`, {
              method: 'DELETE',
              headers: getHeaders(cfg.key)
            });
          }
        } catch (delErr) {
          console.warn('[OnlineOrders] Delete sync warning:', delErr);
        }
      }

      const cloudProducts = [];
      for (const item of itemsToSync) {
        // Resolve category UUID
        let matchedCatId = null;
        if (item.category_id) {
          const lCat = localCats.find(c => c.id === item.category_id);
          if (lCat) {
            const slug = (lCat.name_en || lCat.name || '').toLowerCase().replace(/[^a-z0-9]/g, '-');
            matchedCatId = catMap.get(slug) || catMap.get((lCat.name || '').toLowerCase());
          }
        }

        const isPublished = (typeof item.show_online !== 'undefined') ? Boolean(item.show_online) : true;
        const itemSellingPrice = parseFloat(item.selling_price) || parseFloat(item.price) || 0;
        const onlinePrice = (item.online_price !== undefined && item.online_price !== null && !isNaN(parseFloat(item.online_price)) && parseFloat(item.online_price) > 0)
          ? parseFloat(item.online_price)
          : itemSellingPrice;

        cloudProducts.push({
          shop_id: shopId,
          pos_product_id: String(item.id),
          category_id: matchedCatId,
          name: item.name_en || item.name_ar || item.name || 'Product',
          name_ar: item.name_ar || '',
          name_en: item.name_en || item.name || '',
          description: item.item_code ? ('CODE:' + item.item_code) : (item.description || ''),
          barcode: item.barcode || null,
          price: onlinePrice,
          cost_price: parseFloat(item.cost_price) || 0,
          stock_quantity: Math.max(0, parseInt(item.stock_qty) || 0),
          track_inventory: true,
          is_published: isPublished,
          is_featured: Boolean(item.is_featured),
          image_url: item.image_url || item.image || null,
          updated_at: new Date().toISOString()
        });
      }

      if (cloudProducts.length > 0) {
        // Upload in fast, robust batches of 200 items with on_conflict upsert
        const chunkSize = 200;
        for (let i = 0; i < cloudProducts.length; i += chunkSize) {
          const chunk = cloudProducts.slice(i, i + chunkSize);
          const prodRes = await fetch(`${cfg.url}/rest/v1/products?on_conflict=shop_id,pos_product_id`, {
            method: 'POST',
            headers: { ...getHeaders(cfg.key), 'Prefer': 'resolution=merge-duplicates' },
            body: JSON.stringify(chunk)
          });

          if (!prodRes.ok) {
            const err = await prodRes.text();
            if (err.includes('23503') || err.includes('tenants')) {
              try { localStorage.removeItem('rs_resolved_shop_id_' + (cfg.slug || '').toLowerCase().trim()); } catch(e) {}
              _resolvedShopId = null;
              _resolvedShopSlug = '';
            }
            throw new Error(`Product sync error at item ${i}: ${err}`);
          }
        }
      }

      await broadcastCloudUpdate('items', isAR ? `مزامنة الكتالوج: ${cloudProducts.length} صنف` : `Catalog synced: ${cloudProducts.length} items`);
      await syncPosSalesToCloud();
      await syncCashboxStatusToCloud();
      await pullCloudStockUpdates();

      if (typeof Utils !== 'undefined' && Utils.toast) {
        const delMsg = posIdsToDelete.length > 0 ? (isAR ? ` وحذف ${posIdsToDelete.length}` : ` & removed ${posIdsToDelete.length}`) : '';
        Utils.toast(isAR ? `✅ تمت مزامنة ${cloudProducts.length} صنفاً بنجاح${delMsg}!` : `✅ Synced ${cloudProducts.length} items${delMsg}!`, 'success');
      }
    } catch (err) {
      console.error('[OnlineOrders] Sync catalog error:', err);
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(`⚠️ ${err.message}`, 'error');
      }
    }
  }

  // ── 6.5 Instant Single Product Cloud Sync (Real-time Price & Info Push) ────
  async function syncSingleProductToCloud(item) {
    if (!item) return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const itemSellingPrice = parseFloat(item.selling_price) || parseFloat(item.price) || 0;
      const onlinePrice = (item.online_price !== undefined && item.online_price !== null && !isNaN(parseFloat(item.online_price)) && parseFloat(item.online_price) > 0)
        ? parseFloat(item.online_price)
        : itemSellingPrice;
      const isPublished = (typeof item.show_online !== 'undefined') ? Boolean(item.show_online) : true;

      // Resolve category UUID if possible
      let matchedCatId = null;
      if (item.category_id && typeof DB !== 'undefined') {
        try {
          const lCat = await DB.get('categories', item.category_id);
          if (lCat) {
            const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=id,name,name_en,name_ar`, { headers: getHeaders(cfg.key) });
            if (catRes.ok) {
              const cloudCats = await catRes.json();
              const norm = (str) => (str || '').trim().toLowerCase();
              const found = cloudCats.find(c => norm(c.name) === norm(lCat.name) || norm(c.name_en) === norm(lCat.name_en) || norm(c.name_ar) === norm(lCat.name_ar));
              if (found) matchedCatId = found.id;
            }
          }
        } catch(e) {}
      }

      const payload = [{
        shop_id: shopId,
        pos_product_id: String(item.id),
        category_id: matchedCatId,
        name: item.name_en || item.name_ar || item.name || 'Product',
        name_ar: item.name_ar || item.name || '',
        name_en: item.name_en || item.name || '',
        description: item.item_code ? ('CODE:' + item.item_code) : (item.description || ''),
        barcode: item.barcode || null,
        price: onlinePrice,
        cost_price: parseFloat(item.cost_price) || 0,
        stock_quantity: Math.max(0, parseInt(item.stock_qty) || 0),
        track_inventory: true,
        is_published: isPublished,
        is_featured: Boolean(item.is_featured),
        image_url: item.image_url || item.image || null,
        updated_at: new Date().toISOString()
      }];

      const res = await fetch(`${cfg.url}/rest/v1/products?on_conflict=shop_id,pos_product_id`, {
        method: 'POST',
        headers: { ...getHeaders(cfg.key), 'Prefer': 'resolution=merge-duplicates,return=representation' },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        console.log('[OnlineOrders] Instant product sync success for barcode:', item.barcode, 'price:', onlinePrice);
        broadcastCloudUpdate('items', item.name || item.barcode || 'Item updated');
      } else {
        const errText = await res.text();
        console.warn('[OnlineOrders] syncSingleProductToCloud error response:', errText);
      }
    } catch(err) {
      console.warn('[OnlineOrders] syncSingleProductToCloud error:', err);
    }
  }

  // ── 6.6 Instant Delete Product From Cloud With Tombstone Tracking ─────────
  async function deleteProductFromCloud(posProductId, itemBarcode = null) {
    if (!posProductId && !itemBarcode) return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      // 1. Delete matching product from Supabase products table
      if (posProductId) {
        await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&pos_product_id=eq.${encodeURIComponent(String(posProductId))}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }
      if (itemBarcode) {
        await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&barcode=eq.${encodeURIComponent(String(itemBarcode).trim())}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }
      console.log('[OnlineOrders] Deleted cloud product for POS ID:', posProductId, 'Barcode:', itemBarcode);

      // 2. Fetch tenant banner_url to record tombstone and broadcast to all branches
      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        if (tData && tData[0]) {
          let bObj = {};
          try {
            bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}

          let myNodeId = 'SRV-01';
          if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
            const sc = await BranchSync.getConfig();
            if (sc && sc.nodeId) myNodeId = sc.nodeId;
          }

          let deletedList = Array.isArray(bObj.pos_deleted_products) ? bObj.pos_deleted_products : [];
          // Keep tombstones from past 30 days
          const cutoff = Date.now() - (30 * 24 * 60 * 60 * 1000);
          deletedList = deletedList.filter(d => !d.deleted_at || new Date(d.deleted_at).getTime() > cutoff);

          const exists = deletedList.some(d => 
            (posProductId && String(d.id) === String(posProductId)) ||
            (itemBarcode && d.barcode && String(d.barcode).trim() === String(itemBarcode).trim())
          );
          if (!exists) {
            deletedList.push({
              id: posProductId || null,
              barcode: itemBarcode ? String(itemBarcode).trim() : null,
              deleted_at: new Date().toISOString()
            });
          }
          if (deletedList.length > 500) deletedList = deletedList.slice(-500);

          bObj.pos_deleted_products = deletedList;
          bObj.cloud_sync_seq = Date.now();
          bObj.last_change_type = 'items_deleted';
          bObj.last_change_desc = `Deleted item ${itemBarcode || posProductId}`;
          bObj.last_change_by = myNodeId;
          bObj.last_change_time = new Date().toISOString();

          await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
            method: 'PATCH',
            headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
            body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
          });
          console.log('[OnlineOrders] Broadcasted deletion tombstone to cloud banner_url seq:', bObj.cloud_sync_seq);
        }
      }
    } catch(e) {
      console.warn('[OnlineOrders] deleteProductFromCloud error:', e);
    }
  }

  // ── 6.6b Instant Delete Category From Cloud ────────────────────────────────
  async function deleteCategoryFromCloud(catId, catName = null) {
    if (!catId && !catName) return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      if (catId) {
        await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&id=eq.${encodeURIComponent(String(catId))}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }
      if (catName) {
        await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&name=eq.${encodeURIComponent(String(catName).trim())}`, {
          method: 'DELETE',
          headers: getHeaders(cfg.key)
        });
      }

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        if (tData && tData[0]) {
          let bObj = {};
          try {
            bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}

          let myNodeId = 'SRV-01';
          if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
            const sc = await BranchSync.getConfig();
            if (sc && sc.nodeId) myNodeId = sc.nodeId;
          }

          let deletedCats = Array.isArray(bObj.pos_deleted_categories) ? bObj.pos_deleted_categories : [];
          deletedCats.push({
            id: catId || null,
            name: catName || null,
            deleted_at: new Date().toISOString()
          });
          if (deletedCats.length > 200) deletedCats = deletedCats.slice(-200);

          bObj.pos_deleted_categories = deletedCats;
          bObj.cloud_sync_seq = Date.now();
          bObj.last_change_type = 'categories_deleted';
          bObj.last_change_desc = `Deleted category ${catName || catId}`;
          bObj.last_change_by = myNodeId;
          bObj.last_change_time = new Date().toISOString();

          await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
            method: 'PATCH',
            headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
            body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
          });
        }
      }
    } catch(e) {
      console.warn('[OnlineOrders] deleteCategoryFromCloud error:', e);
    }
  }

  // ── 6.6c Apply Deleted Products from Cloud (Branch Side) ────────────────────
  async function applyDeletedProducts(bObj = null) {
    if (typeof DB === 'undefined') return { success: false, count: 0 };
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      if (syncCfg.role === 'server') {
        return { success: true, count: 0, skipped: 'server_is_master' };
      }

      let bannerData = bObj;
      if (!bannerData || !bannerData.pos_deleted_products) {
        const cfg = await getConfig();
        const shopId = await resolveShopId(cfg);
        if (!shopId) return { success: false, count: 0 };
        const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key),
          signal: AbortSignal.timeout(6000)
        });
        if (!tRes.ok) return { success: false, count: 0 };
        const tData = await tRes.json();
        if (tData && tData[0]) {
          try {
            bannerData = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
          } catch(e) {}
        }
      }

      const deletedList = bannerData?.pos_deleted_products;
      if (!Array.isArray(deletedList) || deletedList.length === 0) {
        return { success: true, count: 0 };
      }

      const localItems = (await DB.getAll('items')) || [];
      if (localItems.length === 0) return { success: true, count: 0 };

      const deletedIds = new Set();
      const deletedBarcodes = new Set();
      for (const d of deletedList) {
        if (d.id != null) deletedIds.add(String(d.id));
        if (d.barcode) deletedBarcodes.add(String(d.barcode).trim());
      }

      const itemsToRemove = [];
      for (const itm of localItems) {
        const idStr = String(itm.id);
        const barcodeStr = itm.barcode ? String(itm.barcode).trim() : null;
        if (deletedIds.has(idStr) || (barcodeStr && deletedBarcodes.has(barcodeStr))) {
          itemsToRemove.push(itm);
        }
      }

      if (itemsToRemove.length === 0) {
        return { success: true, count: 0 };
      }

      console.log(`[OnlineOrders] Removing ${itemsToRemove.length} deleted items from branch local database...`);

      // 1. Delete from local IndexedDB
      try {
        const rawDb = await DB.getDB();
        const tx = rawDb.transaction('items', 'readwrite');
        const store = tx.objectStore('items');
        for (const itm of itemsToRemove) {
          store.delete(itm.id);
          if (typeof itm.id === 'string' && !isNaN(Number(itm.id))) {
            try { store.delete(Number(itm.id)); } catch(e){}
          }
        }
        await new Promise((resolve, reject) => {
          tx.oncomplete = resolve;
          tx.onerror = () => reject(tx.error);
          tx.onabort = () => reject(tx.error);
        });
      } catch(dbErr) {
        console.warn('[OnlineOrders] Direct store delete error:', dbErr);
        for (const itm of itemsToRemove) {
          try { await DB.remove('items', itm.id); } catch(e){}
        }
      }

      // 2. Delete from branch local backend (localhost:3000 db.dat)
      for (const itm of itemsToRemove) {
        try {
          if (typeof DB.callApi === 'function') {
            await DB.callApi(`/api/db/items/${itm.id}`, { method: 'DELETE' });
          }
        } catch(e) {}
      }

      // 3. Dispatch sync complete and refresh views
      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', {
          detail: { table: 'items', deleted: true, count: itemsToRemove.length }
        }));
      }

      if (window.POS && typeof POS.refreshCatalog === 'function') {
        try { await POS.refreshCatalog(); } catch(e) {}
      }

      const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
      if (typeof Utils !== 'undefined' && Utils.toast) {
        Utils.toast(isAR ? `🗑️ تم إزالة ${itemsToRemove.length} صنف تم حذفه من السيرفر!` : `🗑️ Removed ${itemsToRemove.length} deleted item(s) from server!`, 'info', 3000);
      }

      return { success: true, count: itemsToRemove.length };
    } catch(err) {
      console.warn('[OnlineOrders] applyDeletedProducts error:', err);
      return { success: false, error: err.message, count: 0 };
    }
  }

  // ── 6.6d Apply Deleted Categories from Cloud (Branch Side) ──────────────────
  async function applyDeletedCategories(bObj = null) {
    if (typeof DB === 'undefined') return { success: false, count: 0 };
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      if (syncCfg.role === 'server') return { success: true, count: 0, skipped: 'server_is_master' };

      const deletedCats = bObj?.pos_deleted_categories;
      if (!Array.isArray(deletedCats) || deletedCats.length === 0) return { success: true, count: 0 };

      const localCats = (await DB.getAll('categories')) || [];
      if (localCats.length === 0) return { success: true, count: 0 };

      const delIds = new Set(deletedCats.map(c => c.id != null ? String(c.id) : null).filter(Boolean));
      const delNames = new Set(deletedCats.map(c => c.name ? String(c.name).trim().toLowerCase() : null).filter(Boolean));

      const catsToRemove = [];
      for (const c of localCats) {
        const idStr = String(c.id);
        const cloudIdStr = c.cloud_id ? String(c.cloud_id) : null;
        const normName = (c.name || c.name_en || c.name_ar || '').trim().toLowerCase();
        if (delIds.has(idStr) || (cloudIdStr && delIds.has(cloudIdStr)) || (normName && delNames.has(normName))) {
          catsToRemove.push(c);
        }
      }

      if (catsToRemove.length === 0) return { success: true, count: 0 };

      try {
        const rawDb = await DB.getDB();
        const tx = rawDb.transaction('categories', 'readwrite');
        const store = tx.objectStore('categories');
        for (const c of catsToRemove) {
          store.delete(c.id);
        }
        await new Promise((res, rej) => {
          tx.oncomplete = res;
          tx.onerror = () => rej(tx.error);
          tx.onabort = () => rej(tx.error);
        });
      } catch(e) {}

      for (const c of catsToRemove) {
        try {
          if (typeof DB.callApi === 'function') {
            await DB.callApi(`/api/db/categories/${c.id}`, { method: 'DELETE' });
          }
        } catch(e) {}
      }

      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', {
          detail: { table: 'categories', deleted: true, count: catsToRemove.length }
        }));
      }

      return { success: true, count: catsToRemove.length };
    } catch(err) {
      console.warn('[OnlineOrders] applyDeletedCategories error:', err);
      return { success: false, count: 0 };
    }
  }

  // ── 6.7 Instant Real-Time Cloud Update Broadcaster ─────────────────────────
  async function broadcastCloudUpdate(changeType = 'items', changeDesc = '') {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tRes.ok) return;
      const tData = await tRes.json();
      if (!tData || !tData[0]) return;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      let myNodeId = 'SRV-01';
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        const sc = await BranchSync.getConfig();
        if (sc && sc.nodeId) myNodeId = sc.nodeId;
      }

      bObj.cloud_sync_seq = Date.now();
      bObj.last_change_type = changeType;
      bObj.last_change_desc = changeDesc;
      bObj.last_change_by = myNodeId;
      bObj.last_change_time = new Date().toISOString();

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
      console.log(`[OnlineOrders] Broadcasted cloud update seq ${bObj.cloud_sync_seq} (${changeType}): ${changeDesc}`);
    } catch(err) {
      console.warn('[OnlineOrders] broadcastCloudUpdate error:', err);
    }
  }

  // ── 6.8 Sync Supporting Tables to Cloud (Units, Warehouses, Offers, Suppliers, Stock Transfers) ──
  async function syncCloudTables(allowedTables = null) {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      const targetTables = allowedTables || syncCfg.syncTables || ['units', 'warehouses', 'offers', 'suppliers', 'stock_transfers'];

      const tablePayload = {};
      const tablesToStore = ['units', 'warehouses', 'offers', 'suppliers', 'stock_transfers'].filter(t => targetTables.includes(t));

      for (const t of tablesToStore) {
        try {
          const records = await DB.getAll(t);
          if (records && Array.isArray(records)) {
            tablePayload[t] = records;
          }
        } catch(e) {}
      }

      // Collect all warehouse stocks per item so both server and branch know stock at every warehouse
      try {
        const allItems = (await DB.getAll('items')) || [];
        const whStocksMap = {};
        for (const itm of allItems) {
          if (itm.warehouse_stocks && Object.keys(itm.warehouse_stocks).length > 0) {
            if (itm.barcode) whStocksMap['barcode::' + String(itm.barcode).trim()] = itm.warehouse_stocks;
            if (itm.id != null) whStocksMap['id::' + itm.id] = itm.warehouse_stocks;
            if (itm.name) whStocksMap['name::' + String(itm.name).trim().toLowerCase()] = itm.warehouse_stocks;
            if (itm.name_ar) whStocksMap['name::' + String(itm.name_ar).trim().toLowerCase()] = itm.warehouse_stocks;
          }
        }
        tablePayload['_warehouse_stocks'] = whStocksMap;
      } catch(e) {}

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(6000)
      });
      if (!tRes.ok) return;
      const tData = await tRes.json();
      if (!tData || !tData[0]) return;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      bObj.pos_cloud_tables = { ...(bObj.pos_cloud_tables || {}), ...tablePayload };
      bObj.tables_updated_at = new Date().toISOString();
      bObj.cloud_sync_seq = Date.now();
      bObj.last_change_type = 'tables';
      bObj.last_change_desc = 'Warehouses, Stock Transfers & Stock updated';
      bObj.last_change_by = (syncCfg.nodeId || 'SRV-01');
      bObj.last_change_time = new Date().toISOString();

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
      console.log('[OnlineOrders] Synced supporting tables & warehouse stocks to cloud:', Object.keys(tablePayload));
    } catch(err) {
      console.warn('[OnlineOrders] syncCloudTables error:', err);
    }
  }

  // ── 6.9 Pull Supporting Tables from Cloud (Units, Warehouses, Offers, Suppliers, Stock Transfers) ──
  async function pullCloudTables(bObj = null) {
    if (typeof DB === 'undefined') return;
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      const isServer = (syncCfg.role === 'server');

      let bannerData = bObj;
      if (!bannerData) {
        const cfg = await getConfig();
        const shopId = await resolveShopId(cfg);
        if (!shopId) return;
        const res = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key),
          signal: AbortSignal.timeout(6000)
        });
        if (!res.ok) return;
        const tData = await res.json();
        if (!tData || !tData[0]) return;
        try {
          bannerData = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
        } catch(e) {}
      }

      const cloudTables = bannerData?.pos_cloud_tables;
      if (!cloudTables || typeof cloudTables !== 'object') return;

      const allowedTables = syncCfg.syncTables || ['units', 'warehouses', 'offers', 'suppliers', 'stock_transfers'];
      let tablesUpdated = false;

      // 1. Pull Warehouses (Reconcile by code so Server & Branch both get all warehouses!)
      if (cloudTables.warehouses && Array.isArray(cloudTables.warehouses) && allowedTables.includes('warehouses')) {
        try {
          const localWh = (await DB.getAll('warehouses')) || [];
          const localByCode = new Map();
          localWh.forEach(w => {
            if (w.code) localByCode.set(String(w.code).trim().toLowerCase(), w);
          });
          for (const cw of cloudTables.warehouses) {
            const code = (cw.code ? String(cw.code).trim().toLowerCase() : '');
            const match = code ? localByCode.get(code) : null;
            if (match) {
              await DB.put('warehouses', { ...match, ...cw, id: match.id });
            } else {
              const copy = { ...cw };
              delete copy.id;
              await DB.add('warehouses', copy);
              localByCode.set(code, copy);
              tablesUpdated = true;
            }
          }
        } catch(whErr) {
          console.warn('[OnlineOrders] pullCloudTables warehouses error:', whErr);
        }
      }

      // 2. Identify this node's warehouse
      const allWarehouses = (await DB.getAll('warehouses')) || [];
      const myBranchId = (syncCfg.branchId || syncCfg.nodeId || '').trim().toLowerCase();
      const myNodeName = (syncCfg.nodeName || '').trim().toLowerCase();

      let myWh = null;
      if (!isServer) {
        myWh = allWarehouses.find(w => w.code && w.code.trim().toLowerCase() === myBranchId);
        if (!myWh) {
          myWh = allWarehouses.find(w => {
            const c = (w.code || '').trim().toLowerCase();
            const n = (w.name || w.name_ar || '').trim().toLowerCase();
            return (c && (myBranchId.includes(c) || c.includes(myBranchId))) ||
                   (n && (myNodeName.includes(n) || n.includes(myBranchId) || myBranchId.includes(n)));
          });
        }
        if (!myWh && allWarehouses.length > 1) {
          myWh = allWarehouses.find(w => w.id !== 1 && (w.code || '').toUpperCase() !== 'WH-01');
        }
        if (myWh) {
          if (typeof window !== 'undefined') window._posWarehouseId = myWh.id;
          try { await DB.setSetting('pos_warehouse_id', myWh.id); } catch(e){}
        }
      }

      // 3. Pull Stock Transfers (Merge by ref so neither side loses inter-branch transfers!)
      if (cloudTables.stock_transfers && Array.isArray(cloudTables.stock_transfers) && allowedTables.includes('stock_transfers')) {
        try {
          const localTransfers = (await DB.getAll('stock_transfers')) || [];
          const localRefs = new Set(localTransfers.map(t => t.ref).filter(Boolean));
          for (const ct of cloudTables.stock_transfers) {
            if (ct && ct.ref && !localRefs.has(ct.ref)) {
              const copy = { ...ct };
              delete copy.id;
              await DB.add('stock_transfers', copy);
              localRefs.add(ct.ref);
              tablesUpdated = true;
            }
          }
        } catch(trfErr) {
          console.warn('[OnlineOrders] pullCloudTables transfers error:', trfErr);
        }
      }

      // 4. Pull Warehouse Stocks per item & ADJUST item.stock_qty for Branch or Server
      const whStocks = cloudTables._warehouse_stocks || bannerData.pos_warehouse_stocks;
      if (whStocks && typeof whStocks === 'object') {
        try {
          const localItems = (await DB.getAll('items')) || [];
          const byBarcode = new Map();
          const byId = new Map();
          const byName = new Map();
          localItems.forEach(i => {
            if (i.barcode) byBarcode.set('barcode::' + String(i.barcode).trim(), i);
            if (i.id != null) byId.set('id::' + i.id, i);
            if (i.name) byName.set('name::' + String(i.name).trim().toLowerCase(), i);
            if (i.name_ar) byName.set('name::' + String(i.name_ar).trim().toLowerCase(), i);
          });

          for (const [k, stocks] of Object.entries(whStocks)) {
            const itm = byBarcode.get(k) || byId.get(k) || byName.get(k);
            if (itm && stocks && typeof stocks === 'object') {
              itm.warehouse_stocks = { ...(itm.warehouse_stocks || {}), ...stocks };

              if (!isServer && myWh) {
                // Find stock specifically for THIS branch station
                const myWhIdStr = String(myWh.id);
                const myWhCode = (myWh.code || '').trim().toLowerCase();
                const myWhName = (myWh.name || myWh.name_ar || '').trim().toLowerCase();

                let branchQty = null;
                const lookupKeys = [myWhIdStr, myWhCode, myBranchId, myWhName, 'koubayat', 'bobmarektkatelbi'];
                for (const testKey of lookupKeys) {
                  if (testKey && stocks[testKey] !== undefined && !isNaN(parseFloat(stocks[testKey]))) {
                    branchQty = parseFloat(stocks[testKey]);
                    break;
                  }
                }
                if (branchQty !== null) {
                  itm.stock_qty = branchQty;
                }
              } else if (isServer) {
                // On Server, stock_qty is the Main Warehouse stock (WH-01)
                const srvQty = stocks['1'] ?? stocks['WH-01'] ?? stocks['wh-01'];
                if (srvQty !== undefined && !isNaN(parseFloat(srvQty))) {
                  itm.stock_qty = parseFloat(srvQty);
                }
              }

              await DB.put('items', itm);
              tablesUpdated = true;
            }
          }
        } catch(stkErr) {
          console.warn('[OnlineOrders] pullCloudTables whStocks error:', stkErr);
        }
      }

      // 5. Automatic Transfer Reconciliation: ensure branch receives stock even if whStocks was missed
      if (!isServer && myWh) {
        try {
          const allTransfers = (await DB.getAll('stock_transfers')) || [];
          const myWhId = myWh.id;
          const myWhCode = (myWh.code || '').trim().toLowerCase();

          const netTransfersByItem = new Map();
          for (const t of allTransfers) {
            const toName = (t.to_wh_name || '').trim().toLowerCase();
            const fromName = (t.from_wh_name || '').trim().toLowerCase();
            const isToMe = (t.to_wh_id === myWhId || toName.includes(myWhCode) || toName.includes(myBranchId) || toName.includes('koubayat') || toName.includes('bobmarektkatelbi'));
            const isFromMe = (t.from_wh_id === myWhId || fromName.includes(myWhCode) || fromName.includes(myBranchId));

            if (isToMe || isFromMe) {
              const delta = (isToMe ? 1 : -1) * (parseFloat(t.qty) || 0);
              const key = t.item_id ? ('id::' + t.item_id) : ('name::' + (t.item_name || '').trim().toLowerCase());
              netTransfersByItem.set(key, (netTransfersByItem.get(key) || 0) + delta);
            }
          }

          if (netTransfersByItem.size > 0) {
            const localItems = (await DB.getAll('items')) || [];
            for (const itm of localItems) {
              const netTrf = netTransfersByItem.get('id::' + itm.id) || netTransfersByItem.get('name::' + (itm.name || itm.name_ar || itm.name_en || '').trim().toLowerCase());
              if (netTrf && netTrf > 0) {
                if (!itm.stock_qty || itm.stock_qty < netTrf) {
                  itm.stock_qty = netTrf;
                  if (!itm.warehouse_stocks) itm.warehouse_stocks = {};
                  itm.warehouse_stocks[myWh.id] = netTrf;
                  itm.warehouse_stocks[myWhCode] = netTrf;
                  await DB.put('items', itm);
                  tablesUpdated = true;
                }
              }
            }
          }
        } catch(trfReconcileErr) {
          console.warn('[OnlineOrders] transfer reconciliation error:', trfReconcileErr);
        }
      }

      // 4. Other supporting tables (units, offers, suppliers) - only branch pulls from server
      if (!isServer) {
        for (const tbl of ['units', 'offers', 'suppliers']) {
          const records = cloudTables[tbl];
          if (!records || !Array.isArray(records) || !allowedTables.includes(tbl)) continue;
          try {
            const rawDb = await DB.getDB();
            if (rawDb && rawDb.objectStoreNames.contains(tbl)) {
              const tx = rawDb.transaction(tbl, 'readwrite');
              const store = tx.objectStore(tbl);
              for (const rec of records) {
                store.put(rec);
              }
              await new Promise((res, rej) => {
                tx.oncomplete = res;
                tx.onerror = () => rej(tx.error);
                tx.onabort = () => rej(tx.error);
              });
            }
          } catch(e) {}
        }
      }

      if (tablesUpdated) {
        if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'warehouses' } }));
        }
      }
    } catch(e) {
      console.warn('[OnlineOrders] pullCloudTables error:', e);
    }
  }

  // ── 7.0a Instant Delta Catalog Sync (Resilient to clock skew & timezone drift) ──
  let _isPullingDelta = false;

  async function pullCloudDelta(bObj = null) {
    if (_isPullingDelta || typeof DB === 'undefined') return { success: false, count: 0 };
    _isPullingDelta = true;
    try {
      const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
      // Server is the Master Source of Truth (SSOT). It only pushes to Cloud, never pulls products!
      if (syncCfg.role === 'server') {
        return { success: true, count: 0, skipped: 'server_is_master' };
      }
      const syncTables = syncCfg.syncTables || ['items'];
      if (!syncTables.includes('items')) {
        return { success: true, count: 0, skipped: 'items_not_selected' };
      }

      // 0. Immediately apply tombstones for deleted items and categories
      try {
        await applyDeletedProducts(bObj);
        await applyDeletedCategories(bObj);
      } catch(delErr) {
        console.warn('[OnlineOrders] pullCloudDelta deletion error:', delErr);
      }

      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return { success: false, count: 0 };

      // 1. Fetch the 150 most recently modified products from cloud
      const deltaUrl = `${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=*&order=updated_at.desc&limit=150`;
      const res = await fetch(deltaUrl, { 
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(8000)
      });
      if (!res.ok) return { success: false, count: 0 };

      const updatedProds = await res.json();
      if (!Array.isArray(updatedProds) || updatedProds.length === 0) {
        // Still pull supporting tables
        try { await pullCloudTables(bObj); } catch(tErr) {}
        return { success: true, count: 0 };
      }

      const localItems = (await DB.getAll('items')) || [];
      const localById = new Map();
      const localByBarcode = new Map();
      const localByName = new Map();
      for (const itm of localItems) {
        if (itm.id != null) localById.set(String(itm.id), itm);
        if (itm.barcode) localByBarcode.set(String(itm.barcode).trim(), itm);
        if (itm.name) {
          const normName = String(itm.name).trim().toLowerCase().replace(/\s+/g, ' ');
          if (normName) localByName.set(normName, itm);
        }
      }

      const syncStock = syncCfg.syncTables ? (syncCfg.syncTables.includes('stock') || syncCfg.syncTables.includes('stock_qty')) : false;

      const itemsToUpdate = [];

      for (const p of updatedProds) {
        const cleanBarcode = (p.barcode ? String(p.barcode).trim() : '');
        const cleanName = (p.name || p.name_en || p.name_ar || '').trim().toLowerCase().replace(/\s+/g, ' ');
        // CRITICAL: Barcode is the primary universal identifier between different POS machines!
        const existing = (cleanBarcode ? localByBarcode.get(cleanBarcode) : null)
          || (cleanName ? localByName.get(cleanName) : null)
          || (p.pos_product_id ? localById.get(String(p.pos_product_id)) : null);

        const rawId = p.pos_product_id || (existing ? existing.id : p.id);
        const numId = (!isNaN(rawId) && String(rawId).length < 10) ? Number(rawId) : rawId;
        const itemPrice = parseFloat(p.price) || 0;
        const costPrice = parseFloat(p.cost_price) || 0;

        let needsUpdate = false;
        if (!existing) {
          needsUpdate = true;
        } else {
          const curPrice = parseFloat(existing.selling_price) || parseFloat(existing.price) || 0;
          const curCost = parseFloat(existing.cost_price) || 0;
          const curName = existing.name || '';
          const curBarcode = existing.barcode || '';
          const newName = p.name || p.name_en || p.name_ar || curName;

          if (Math.abs(curPrice - itemPrice) > 0.001 ||
              (costPrice > 0 && Math.abs(curCost - costPrice) > 0.001) ||
              (cleanBarcode && curBarcode !== cleanBarcode) ||
              (newName && curName !== newName) ||
              (p.updated_at && existing.updated_at && p.updated_at > existing.updated_at)) {
            needsUpdate = true;
          }
        }

        if (needsUpdate) {
          const mergedItem = {
            ...(existing || {}),
            id: existing ? existing.id : numId,
            name: p.name || p.name_en || p.name_ar || (existing ? existing.name : 'Product'),
            name_ar: p.name_ar || (existing ? existing.name_ar : ''),
            name_en: p.name_en || (existing ? existing.name_en : ''),
            barcode: cleanBarcode || (existing ? existing.barcode : '') || '',
            selling_price: itemPrice,
            price: itemPrice,
            online_price: itemPrice,
            cost_price: (costPrice > 0 ? costPrice : (existing?.cost_price || 0)),
            stock_qty: syncStock ? (parseInt(p.stock_quantity) || 0) : (existing ? (existing.stock_qty || 0) : (parseInt(p.stock_quantity) || 0)),
            status: p.is_published !== false ? 'active' : 'inactive',
            updated_at: p.updated_at || new Date().toISOString()
          };
          itemsToUpdate.push(mergedItem);
        }
      }

      if (itemsToUpdate.length > 0) {
        console.log(`[OnlineOrders] Cloud Delta: applying ${itemsToUpdate.length} item updates!`);
        // Direct fast IndexedDB write bypassing localhost:3000 network hang on branches
        try {
          const rawDb = await DB.getDB();
          const tx = rawDb.transaction('items', 'readwrite');
          const store = tx.objectStore('items');
          for (const itm of itemsToUpdate) {
            store.put(itm);
          }
          await new Promise((resolve, reject) => {
            tx.oncomplete = resolve;
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error);
          });
        } catch (dbErr) {
          console.warn('[OnlineOrders] Direct DB put fallback:', dbErr);
          for (const itm of itemsToUpdate) {
            try { await DB.put('items', itm); } catch(e) {}
          }
        }

        // Also persist to branch local backend so localhost:3000 db.dat stays synchronized
        if (typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
          DB.bulkSyncToServer('items', itemsToUpdate).catch(() => {});
        }

        if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', {
            detail: { table: 'items', count: itemsToUpdate.length, delta: true }
          }));
        }

        const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
        if (typeof Utils !== 'undefined' && Utils.toast) {
          Utils.toast(isAR ? `⚡ تم تحديث أسعار ${itemsToUpdate.length} صنف تلقائياً من السيرفر!` : `⚡ Updated ${itemsToUpdate.length} item prices in real-time from server!`, 'success');
        }
      }

      // 2. Also sync categories in delta if categories is in syncTables
      if (syncTables.includes('categories')) {
        try {
          const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=*`, {
            headers: getHeaders(cfg.key),
            signal: AbortSignal.timeout(6000)
          });
          if (catRes.ok) {
            const cloudCats = await catRes.json();
            if (Array.isArray(cloudCats) && cloudCats.length > 0) {
              const localCats = (await DB.getAll('categories')) || [];
              const catByName = new Map();
              localCats.forEach(c => {
                if (c.name) catByName.set(c.name.trim().toLowerCase(), c);
                if (c.name_en) catByName.set(c.name_en.trim().toLowerCase(), c);
                if (c.name_ar) catByName.set(c.name_ar.trim().toLowerCase(), c);
              });
              const catsToSave = [];
              for (const c of cloudCats) {
                const normName = (c.name || c.name_en || c.name_ar || '').trim().toLowerCase();
                const existing = catByName.get(normName);
                if (!existing || existing.name !== c.name || (c.name_ar && existing.name_ar !== c.name_ar)) {
                  const catRecord = {
                    ...(existing || {}),
                    id: existing ? existing.id : c.id,
                    cloud_id: c.id,
                    name: c.name || c.name_en || c.name_ar,
                    name_ar: c.name_ar || '',
                    name_en: c.name_en || c.name || '',
                    sort_order: c.display_order || 0
                  };
                  catsToSave.push(catRecord);
                  try { await DB.put('categories', catRecord); } catch(e){}
                }
              }
              if (catsToSave.length > 0 && typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
                DB.bulkSyncToServer('categories', catsToSave).catch(() => {});
              }
            }
          }
        } catch(cErr) {}
      }

      // 3. Pull supporting tables (units, warehouses, offers, suppliers)
      try {
        await pullCloudTables();
      } catch(tErr) {}

      const nowIso = new Date().toISOString();
      localStorage.setItem('rs_last_cloud_sync', nowIso);
      localStorage.setItem('rs_last_cloud_sync_iso', nowIso);
      try { 
        await DB.setSetting('last_cloud_sync_time', nowIso);
        await DB.setSetting('last_cloud_delta_sync', nowIso);
      } catch(e) {}

      const timeEl = document.getElementById('sync-last-cloud-time');
      if (timeEl) {
        const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
        timeEl.textContent = isAR ? 'الآن (منذ لحظات)' : 'Just now';
      }

      return { success: true, count: itemsToUpdate.length };
    } catch (err) {
      console.warn('[OnlineOrders] pullCloudDelta error:', err);
      return { success: false, error: err.message, count: 0 };
    } finally {
      _isPullingDelta = false;
    }
  }

  // ── 7.0 Pull Catalog & Categories From Cloud (For Remote Branches) ─────────
  async function pullCatalogFromCloud(options = {}) {
    if (typeof DB === 'undefined') return { success: false, count: 0 };
    const syncCfg = (window.BranchSync && typeof BranchSync.getConfig === 'function') ? await BranchSync.getConfig() : {};
    // Server is the Master Source of Truth: prevent accidental cloud overwrites
    if (syncCfg.role === 'server' && !options.forceServerPull) {
      console.log('[OnlineOrders] pullCatalogFromCloud skipped: this node is Server (Master Authority).');
      return { success: true, count: 0, skipped: 'server_is_master' };
    }

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang) ? i18n.getLang() === 'ar' : true;
    const allowedTables = Array.isArray(options.syncTables) ? options.syncTables : (syncCfg.syncTables || ['items', 'categories']);
    const syncItems = allowedTables.includes('items');
    const syncCats = allowedTables.includes('categories');
    const syncStock = allowedTables.includes('stock') || allowedTables.includes('stock_qty');

    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) throw new Error(`Shop "${cfg.slug}" not found in Cloud.`);

      // 1. Fetch Cloud Categories (only if categories is in allowedTables)
      if (syncCats) {
        try {
          const catRes = await fetch(`${cfg.url}/rest/v1/categories?shop_id=eq.${shopId}&select=*`, {
            headers: getHeaders(cfg.key)
          });
          if (catRes.ok) {
            const cloudCats = await catRes.json();
            if (Array.isArray(cloudCats) && cloudCats.length > 0) {
              const localCats = (await DB.getAll('categories')) || [];
              const catByName = new Map();
              localCats.forEach(c => {
                if (c.name) catByName.set(c.name.trim().toLowerCase(), c);
                if (c.name_en) catByName.set(c.name_en.trim().toLowerCase(), c);
                if (c.name_ar) catByName.set(c.name_ar.trim().toLowerCase(), c);
              });

              const allSavedCats = [];
              for (const c of cloudCats) {
                const normName = (c.name || c.name_en || c.name_ar || '').trim().toLowerCase();
                const existing = catByName.get(normName);
                const catRecord = {
                  ...(existing || {}),
                  id: existing ? existing.id : c.id,
                  cloud_id: c.id,
                  name: c.name || c.name_en || c.name_ar,
                  name_ar: c.name_ar || '',
                  name_en: c.name_en || c.name || '',
                  sort_order: c.display_order || 0
                };
                allSavedCats.push(catRecord);
                try {
                  await DB.put('categories', catRecord);
                } catch(e) {}
              }
              if (allSavedCats.length > 0 && typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
                DB.bulkSyncToServer('categories', allSavedCats).catch(() => {});
              }
            }
          }
        } catch(catErr) {
          console.warn('[OnlineOrders] pull categories error:', catErr);
        }
      }

      // 2. Fetch All Cloud Products (Chunked by 1000 - only if items is in allowedTables)
      let importedCount = 0;
      if (syncItems) {
        // Build fast lookup maps of existing local items
        const localItems = (await DB.getAll('items')) || [];
        const localById = new Map();
        const localByBarcode = new Map();
        const localByName = new Map();
        for (const itm of localItems) {
          if (itm.id != null) localById.set(String(itm.id), itm);
          if (itm.barcode) localByBarcode.set(String(itm.barcode).trim(), itm);
          if (itm.name) {
            const normName = String(itm.name).trim().toLowerCase().replace(/\s+/g, ' ');
            if (normName) localByName.set(normName, itm);
          }
        }

        let fromIdx = 0;
        let hasMore = true;
        const allCloudProducts = [];

        while (hasMore) {
          const prodRes = await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=*&limit=1000&offset=${fromIdx}&order=created_at.asc`, {
            headers: getHeaders(cfg.key),
            signal: AbortSignal.timeout(12000)
          });
          if (!prodRes.ok) break;
          const prods = await prodRes.json();
          if (!Array.isArray(prods) || prods.length === 0) {
            hasMore = false;
            break;
          }
          allCloudProducts.push(...prods);
          if (prods.length < 1000) {
            hasMore = false;
          } else {
            fromIdx += 1000;
          }
        }

        if (allCloudProducts.length > 0) {
          // Reconcile and purge deleted items from branch
          const cloudBarcodes = new Set(allCloudProducts.map(p => p.barcode ? String(p.barcode).trim() : null).filter(Boolean));
          const cloudPosIds = new Set(allCloudProducts.map(p => String(p.pos_product_id || p.id)));
          const itemsToDelete = [];
          for (const itm of localItems) {
            const bCode = itm.barcode ? String(itm.barcode).trim() : null;
            const idStr = String(itm.id);
            const inCloud = (bCode && cloudBarcodes.has(bCode)) || cloudPosIds.has(idStr);
            if (!inCloud) {
              itemsToDelete.push(itm);
            }
          }

          if (itemsToDelete.length > 0) {
            console.log(`[OnlineOrders] Purging ${itemsToDelete.length} obsolete/deleted items on branch...`);
            try {
              const rawDb = await DB.getDB();
              const tx = rawDb.transaction('items', 'readwrite');
              const store = tx.objectStore('items');
              for (const itm of itemsToDelete) {
                store.delete(itm.id);
                if (typeof itm.id === 'string' && !isNaN(Number(itm.id))) {
                  try { store.delete(Number(itm.id)); } catch(e){}
                }
              }
              await new Promise((res, rej) => {
                tx.oncomplete = res;
                tx.onerror = () => rej(tx.error);
                tx.onabort = () => rej(tx.error);
              });
            } catch(e) {}
            for (const itm of itemsToDelete) {
              try {
                if (typeof DB.callApi === 'function') {
                  await DB.callApi(`/api/db/items/${itm.id}`, { method: 'DELETE' });
                }
              } catch(e) {}
            }
          }

          const itemsToSave = [];
          for (const p of allCloudProducts) {
            const rawId = p.pos_product_id || p.id;
            const numId = (!isNaN(rawId) && String(rawId).length < 10) ? Number(rawId) : rawId;
            const itemPrice = parseFloat(p.price) || 0;
            const costPrice = parseFloat(p.cost_price) || 0;
            const cleanBarcode = (p.barcode ? String(p.barcode).trim() : '');
            const cleanName = (p.name || p.name_en || p.name_ar || '').trim().toLowerCase().replace(/\s+/g, ' ');

            // Match existing item by Barcode (Primary), then by Name, then by POS ID, then raw ID
            const existing = (cleanBarcode ? localByBarcode.get(cleanBarcode) : null)
              || (cleanName ? localByName.get(cleanName) : null)
              || (p.pos_product_id ? localById.get(String(p.pos_product_id)) : null)
              || localById.get(String(numId));

            const itemCode = existing?.item_code || (p.description && p.description.startsWith('CODE:') ? p.description.replace('CODE:', '') : String(numId));

            const finalItem = {
              ...(existing || {}),
              id: existing ? existing.id : numId,
              item_code: itemCode,
              name: p.name || p.name_en || p.name_ar || 'Product',
              name_ar: p.name_ar || (existing ? existing.name_ar : ''),
              name_en: p.name_en || p.name || (existing ? existing.name_en : ''),
              barcode: cleanBarcode || (existing ? existing.barcode : '') || '',
              selling_price: itemPrice,
              price: itemPrice,
              cost_price: (costPrice > 0 ? costPrice : (existing?.cost_price || 0)),
              stock_qty: syncStock ? (parseInt(p.stock_quantity) || 0) : (existing ? (existing.stock_qty || 0) : (parseInt(p.stock_quantity) || 0)),
              category_id: p.category_id || (existing ? existing.category_id : null),
              status: p.is_published !== false ? 'active' : 'inactive',
              updated_at: new Date().toISOString()
            };

            itemsToSave.push(finalItem);
            importedCount++;
          }

          // Ultra-fast bulk write into IndexedDB (bypassing localhost:3000 network hang)
          if (itemsToSave.length > 0) {
            try {
              const rawDb = await DB.getDB();
              const tx = rawDb.transaction('items', 'readwrite');
              const store = tx.objectStore('items');
              for (const itm of itemsToSave) {
                store.put(itm);
              }
              await new Promise((resolve, reject) => {
                tx.oncomplete = resolve;
                tx.onerror = () => reject(tx.error);
                tx.onabort = () => reject(tx.error);
              });
            } catch (dbErr) {
              for (const itm of itemsToSave) {
                try { await DB.put('items', itm); } catch(e) {}
              }
            }

            // Also persist to branch local backend so localhost:3000 db.dat stays synchronized
            if (typeof DB !== 'undefined' && typeof DB.bulkSyncToServer === 'function') {
              DB.bulkSyncToServer('items', itemsToSave).catch(() => {});
            }
          }
        } else if (fromIdx === 0 && !hasMore && localItems.length > 0) {
          // Cloud has 0 items: clear branch items to match server
          console.log('[OnlineOrders] Cloud catalog has 0 products. Clearing branch items...');
          try {
            const rawDb = await DB.getDB();
            const tx = rawDb.transaction('items', 'readwrite');
            tx.objectStore('items').clear();
            await new Promise(r => { tx.oncomplete = r; });
          } catch(e) {}
          try {
            if (typeof DB.callApi === 'function') {
              await DB.callApi('/api/db-clear/items', { method: 'POST' });
            }
          } catch(e) {}
        }
      } // end if (syncItems)

      // 3. Pull Supporting Tables (units, warehouses, offers, suppliers)
      try {
        await pullCloudTables();
      } catch(stErr) {}

      if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'all', count: importedCount } }));
      }
      return { success: true, count: importedCount };
    } catch (err) {
      console.error('[OnlineOrders] pullCatalogFromCloud error:', err);
      return { success: false, error: err.message, count: 0 };
    }
  }

  // ── 7.0b Register / Heartbeat Branch Node in Cloud ──────────────────────────
  async function heartbeatBranchToCloud(nodeInfo) {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key),
        signal: AbortSignal.timeout(6000)
      });
      if (!tenantRes.ok) return;
      const tData = await tenantRes.json();
      if (!tData || !tData[0]) return;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      bObj.connected_branches = bObj.connected_branches || [];
      const nodeId = nodeInfo.nodeId || 'main';
      const existingIdx = bObj.connected_branches.findIndex(b => b.nodeId === nodeId);

      const branchEntry = {
        nodeId: nodeId,
        name: nodeInfo.name || nodeInfo.nodeName || nodeId,
        branchId: nodeInfo.branchId || nodeId,
        role: nodeInfo.role || 'branch',
        lastSeen: new Date().toISOString(),
        isOnline: true,
        appBuild: 61
      };

      if (existingIdx >= 0) {
        bObj.connected_branches[existingIdx] = branchEntry;
      } else {
        bObj.connected_branches.push(branchEntry);
      }

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
    } catch(err) {
      console.warn('[OnlineOrders] heartbeatBranchToCloud error:', err);
    }
  }

  // ── 7.0c Fetch Cloud Connected Branches (for Server Table) ───────────────────
  async function fetchCloudConnectedBranches() {
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return [];

      const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tenantRes.ok) return [];
      const tData = await tenantRes.json();
      if (!tData || !tData[0]) return [];

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      const branches = bObj.connected_branches || [];
      const now = Date.now();
      return branches.map(b => ({
        ...b,
        ip: 'Cloud Supabase (Internet)',
        isOnline: b.lastSeen ? (now - new Date(b.lastSeen).getTime() < 300000) : false
      }));
    } catch(err) {
      return [];
    }
  }

  // ── 7.0d Remove Cloud Connected Branch (Delete from Supabase) ─────────────────
  async function removeCloudConnectedBranch(nodeId) {
    if (!nodeId) return false;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return false;

      const tenantRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tenantRes.ok) return false;
      const tData = await tenantRes.json();
      if (!tData || !tData[0]) return false;

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      if (Array.isArray(bObj.connected_branches)) {
        bObj.connected_branches = bObj.connected_branches.filter(b => b.nodeId !== nodeId);
        await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
          method: 'PATCH',
          headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
          body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
        });
        return true;
      }
    } catch(err) {
      console.warn('[OnlineOrders] removeCloudConnectedBranch error:', err);
    }
    return false;
  }

  // ── 7.1 Sync POS Sales To Supabase Cloud ──────────────────────────────────
  async function syncPosSalesToCloud() {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      // 1. Get existing order numbers from Supabase to prevent duplicates
      const oRes = await fetch(`${cfg.url}/rest/v1/orders?shop_id=eq.${shopId}&select=order_number`, {
        headers: getHeaders(cfg.key)
      });
      if (!oRes.ok) return;
      const existing = await oRes.json();
      const existingRefs = new Set((existing || []).map(o => o.order_number));

      // 2. Fetch local POS sales
      let sales = (await DB.getAll('sales')) || [];
      // Also fetch from sync transactions if available
      try {
        const trRes = await fetch('/api/db/sales');
        if (trRes.ok) {
          const sData = await trRes.json();
          const serverSales = sData.data || sData || [];
          if (Array.isArray(serverSales) && serverSales.length > sales.length) {
            sales = serverSales;
          }
        }
      } catch(e) {}

      // Identify sales that are missing from cloud
      const missingSales = sales.filter(s => s.ref && !existingRefs.has(s.ref));
      if (missingSales.length === 0) return;

      // Batch upload in chunks of 40
      const chunkSize = 40;
      for (let i = 0; i < missingSales.length; i += chunkSize) {
        const chunk = missingSales.slice(i, i + chunkSize);
        const formatted = chunk.map(s => {
          let items = [];
          try { items = typeof s.items === 'string' ? JSON.parse(s.items) : (s.items || []); } catch(e) {}
          
          let cost = 0;
          items.forEach(it => { cost += (parseFloat(it.cost_price || 0) * (parseFloat(it.qty) || 1)); });
          const total = parseFloat(s.grand_total) || 0;
          const profit = total - cost;

          return {
            shop_id: shopId,
            order_number: s.ref,
            customer_name: s.customer_name || 'عميل عابر',
            customer_phone: s.customer_phone || '',
            delivery_address: s.branch_id || 'main',
            subtotal: parseFloat(s.subtotal || s.grand_total) || 0,
            total: total,
            currency_code: 'USD',
            payment_method: s.payment_method || 'cash',
            payment_status: 'paid',
            order_status: 'completed',
            items: items.map(it => ({
              product_name: it.name_ar || it.name_en || 'Product',
              quantity: parseFloat(it.qty) || 1,
              unit_price: parseFloat(it.price) || 0,
              total_price: parseFloat(it.total) || 0,
              cost_price: parseFloat(it.cost_price) || 0
            })),
            pos_synced: true,
            pos_invoice_ref: s.ref,
            notes: JSON.stringify({
              source: 'pos',
              branch_id: s.branch_id || 'main',
              terminal_id: s.terminal_id || 'POS-2',
              cashier: s.cashier || s.salesperson_name || 'Administrator',
              cost: cost,
              profit: profit
            }),
            created_at: s.created_at,
            updated_at: s.updated_at || s.created_at
          };
        });

        await fetch(`${cfg.url}/rest/v1/orders`, {
          method: 'POST',
          headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
          body: JSON.stringify(formatted)
        });
      }
      console.log('[OnlineOrders] Synced ' + missingSales.length + ' POS sales to Cloud.');
    } catch (err) {
      console.warn('[OnlineOrders] Sales cloud sync note:', err);
    }
  }

  // ── 7.2 Sync Branch Cashbox Drawers To Supabase Cloud ─────────────────────
  async function syncCashboxStatusToCloud() {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const sessions = (await DB.getAll('cashbox_sessions')) || [];
      const movements = (await DB.getAll('cashbox_movements')) || [];
      const activeSession = sessions.find(s => s.status === 'open') || sessions[sessions.length - 1];

      let salesCash = 0;
      let cashIn = 0;
      let cashOut = 0;
      if (activeSession) {
        const sMov = movements.filter(m => m.session_id === activeSession.id);
        salesCash = sMov.filter(m => m.type === 'sale').reduce((sum, m) => sum + (parseFloat(m.amount) || 0), 0);
        cashIn = sMov.filter(m => m.type === 'in').reduce((sum, m) => sum + (parseFloat(m.amount) || 0), 0);
        cashOut = sMov.filter(m => m.type === 'out').reduce((sum, m) => sum + (parseFloat(m.amount) || 0), 0);
      }

      // Also calculate from today's sales if movements empty
      const sales = (await DB.getAll('sales')) || [];
      const todayCashSales = sales.filter(s => {
        const isToday = s.created_at && new Date(s.created_at).toDateString() === new Date().toDateString();
        return isToday && (s.payment_method === 'cash' || !s.payment_method);
      }).reduce((sum, s) => sum + (parseFloat(s.grand_total) || 0), 0);

      const openingAmount = activeSession ? (parseFloat(activeSession.opening_amount) || 0) : 0;
      const actualSalesCash = salesCash > 0 ? salesCash : todayCashSales;
      const currentBalance = openingAmount + actualSalesCash + cashIn - cashOut;

      let myBranchId = 'main';
      let myBranchName = 'الفرع الرئيسي (Main Branch)';
      let myNodeId = (activeSession && activeSession.terminal_id) || localStorage.getItem('redshark_pos_terminal') || 'POS-1';

      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        try {
          const syncCfg = await BranchSync.getConfig();
          if (syncCfg.branchId) myBranchId = syncCfg.branchId;
          if (syncCfg.nodeId) myNodeId = syncCfg.nodeId;
          myBranchName = (myBranchId === 'main') ? 'الفرع الرئيسي (Main Branch)' : (syncCfg.nodeName || myBranchId);
        } catch(e) {}
      }

      const boxEntry = {
        terminal_id: myNodeId,
        branch_id: myBranchId,
        branch_name: myBranchName,
        cashier_name: (activeSession && activeSession.cashier_name) || (window.Auth && typeof Auth.getUser === 'function' ? (Auth.getUser()?.full_name || Auth.getUser()?.username) : 'Administrator'),
        status: activeSession ? activeSession.status : 'open',
        opening_amount: openingAmount,
        cash_sales: actualSalesCash,
        cash_in: cashIn,
        cash_out: cashOut,
        balance_usd: currentBalance,
        balance_lbp: Math.round(currentBalance * 89500),
        opened_at: activeSession ? activeSession.opened_at : new Date().toISOString(),
        last_updated: new Date().toISOString()
      };

      // Update tenant banner_url JSON
      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (tRes.ok) {
        const tData = await tRes.json();
        let bObj = {};
        try {
          bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
        } catch(e) {}

        let existingBoxes = Array.isArray(bObj.pos_cashboxes) ? bObj.pos_cashboxes : [];
        const existingIdx = existingBoxes.findIndex(b => b.branch_id === myBranchId || b.terminal_id === myNodeId);
        if (existingIdx >= 0) {
          existingBoxes[existingIdx] = boxEntry;
        } else {
          existingBoxes.push(boxEntry);
        }

        bObj.pos_cashboxes = existingBoxes;

        await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
          method: 'PATCH',
          headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
          body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
        });
      }
    } catch(err) {
      console.warn('[OnlineOrders] Cashbox cloud sync note:', err);
    }
  }

  // ── 7.3 Pull Cloud Stock Updates Down To POS ──────────────────────────────
  async function pullCloudStockUpdates() {
    if (typeof DB === 'undefined') return;
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return;

      const pRes = await fetch(`${cfg.url}/rest/v1/products?shop_id=eq.${shopId}&select=pos_product_id,stock_quantity,price,updated_at`, {
        headers: getHeaders(cfg.key)
      });
      if (!pRes.ok) return;

      const cloudProds = await pRes.json();
      if (!Array.isArray(cloudProds)) return;

      let updatedCount = 0;
      for (const p of cloudProds) {
        if (!p.pos_product_id) continue;
        const itemId = parseInt(p.pos_product_id);
        if (isNaN(itemId)) continue;

        const localItem = await DB.get('items', itemId);
        if (localItem) {
          const cloudStock = parseInt(p.stock_quantity);
          if (!isNaN(cloudStock) && localItem.stock_qty !== cloudStock) {
            localItem.stock_qty = cloudStock;
            await DB.put('items', localItem);
            updatedCount++;
          }
        }
      }

      if (updatedCount > 0) {
        console.log('[OnlineOrders] Updated ' + updatedCount + ' items stock from cloud.');
        if (window.Items && typeof Items.render === 'function') {
          Items.render();
        }
      }
    } catch(err) {
      console.warn('[OnlineOrders] Stock pull note:', err);
    }
  }

  // ── Universal Customer Matching Key Helper ─────────────────────────────────
  function getCustomerKey(c) {
    if (!c) return null;
    const cleanPhone = (c.phone ? String(c.phone).replace(/\D/g, '') : '');
    if (cleanPhone && cleanPhone.length >= 6) return 'phone::' + cleanPhone;
    const normName = (c.name_ar || c.name_en || c.name || '').trim().toLowerCase().replace(/\s+/g, ' ');
    if (normName) return 'name::' + normName;
    if (c.code) return 'code::' + String(c.code).trim().toLowerCase();
    return (c.id != null) ? ('id::' + c.id) : null;
  }

  // ── 7.4 Sync Customers & Balances To Supabase Cloud ───────────────────────
  async function syncCustomersToCloud() {
    if (typeof DB === 'undefined') return { success: false };
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return { success: false };

      const customers = (await DB.getAll('customers')) || [];
      const cashTxns = (await DB.getAll('cash_transactions')) || [];
      const custTxns = cashTxns.filter(t => t.customer_id != null || (t.type === 'receipt' && t.customer_name));

      const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
        headers: getHeaders(cfg.key)
      });
      if (!tRes.ok) return { success: false };
      const tData = await tRes.json();
      if (!tData || !tData[0]) return { success: false };

      let bObj = {};
      try {
        bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
      } catch(e) {}

      const existingCloud = Array.isArray(bObj.pos_customers) ? bObj.pos_customers : [];
      const cloudMap = new Map();
      existingCloud.forEach(c => {
        const k = getCustomerKey(c);
        if (k) cloudMap.set(k, c);
      });

      let hasChanges = false;
      for (const loc of customers) {
        const k = getCustomerKey(loc);
        if (!k) continue;

        const match = cloudMap.get(k);
        const locBal = parseFloat(loc.balance) || 0;
        const locPts = parseInt(loc.points_balance) || 0;

        if (!match) {
          hasChanges = true;
          cloudMap.set(k, {
            ...loc,
            balance: locBal,
            points_balance: locPts,
            updated_at: loc.updated_at || new Date().toISOString()
          });
        } else {
          const matchBal = parseFloat(match.balance) || 0;
          const matchPts = parseInt(match.points_balance) || 0;

          if (Math.abs(matchBal - locBal) > 0.001 || matchPts !== locPts || match.name !== loc.name || match.phone !== loc.phone || match.max_debt !== loc.max_debt) {
            hasChanges = true;
            cloudMap.set(k, {
              ...match,
              ...loc,
              balance: locBal,
              points_balance: locPts,
              updated_at: new Date().toISOString()
            });
          }
        }
      }

      // Merge customer payment vouchers
      const existingCloudTxns = Array.isArray(bObj.pos_customer_txns) ? bObj.pos_customer_txns : [];
      const cloudTxnRefs = new Set(existingCloudTxns.map(t => t.ref).filter(Boolean));
      let newTxnAdded = false;
      const combinedTxns = [...existingCloudTxns];
      for (const ct of custTxns) {
        if (ct && ct.ref && !cloudTxnRefs.has(ct.ref)) {
          combinedTxns.push(ct);
          cloudTxnRefs.add(ct.ref);
          newTxnAdded = true;
        }
      }
      if (newTxnAdded) hasChanges = true;

      if (!hasChanges && existingCloud.length > 0) {
        return { success: true, count: customers.length, skipped: 'no_changes' };
      }

      bObj.pos_customers = Array.from(cloudMap.values());
      bObj.pos_customer_txns = combinedTxns.slice(-300);
      bObj.customers_updated_at = new Date().toISOString();

      let myNodeId = 'SRV-01';
      if (window.BranchSync && typeof BranchSync.getConfig === 'function') {
        const sc = await BranchSync.getConfig();
        if (sc && sc.nodeId) myNodeId = sc.nodeId;
      }
      bObj.cloud_sync_seq = Date.now();
      bObj.last_change_type = 'customers';
      bObj.last_change_desc = 'Customer balances & debits updated';
      bObj.last_change_by = myNodeId;
      bObj.last_change_time = new Date().toISOString();

      await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}`, {
        method: 'PATCH',
        headers: { ...getHeaders(cfg.key), 'Content-Type': 'application/json' },
        body: JSON.stringify({ banner_url: JSON.stringify(bObj) })
      });
      console.log(`[OnlineOrders] Synced ${customers.length} customer(s) to cloud with seq ${bObj.cloud_sync_seq}.`);
      return { success: true, count: customers.length };
    } catch(err) {
      console.warn('[OnlineOrders] syncCustomersToCloud error:', err);
      return { success: false, error: err.message };
    }
  }

  // ── 7.5 Pull Customers & Balances From Supabase Cloud ─────────────────────
  async function pullCustomersFromCloud(cachedBObj = null) {
    if (typeof DB === 'undefined') return { success: false };
    try {
      const cfg = await getConfig();
      const shopId = await resolveShopId(cfg);
      if (!shopId) return { success: false };

      let bObj = cachedBObj;
      if (!bObj) {
        const tRes = await fetch(`${cfg.url}/rest/v1/tenants?id=eq.${shopId}&select=banner_url`, {
          headers: getHeaders(cfg.key)
        });
        if (!tRes.ok) return { success: false };
        const tData = await tRes.json();
        if (!tData || !tData[0]) return { success: false };

        try {
          bObj = typeof tData[0].banner_url === 'string' ? JSON.parse(tData[0].banner_url) : (tData[0].banner_url || {});
        } catch(e) {}
      }

      const cloudCustomers = Array.isArray(bObj?.pos_customers) ? bObj.pos_customers : [];
      if (cloudCustomers.length === 0) return { success: true, count: 0 };

      const localCustomers = (await DB.getAll('customers')) || [];
      const localByKey = new Map();
      localCustomers.forEach(c => {
        const k = getCustomerKey(c);
        if (k) localByKey.set(k, c);
      });

      let updatedCount = 0;
      for (const cc of cloudCustomers) {
        const k = getCustomerKey(cc);
        if (!k) continue;

        const match = localByKey.get(k);
        const cloudBal = parseFloat(cc.balance) || 0;
        const cloudPts = parseInt(cc.points_balance) || 0;

        if (match) {
          const locBal = parseFloat(match.balance) || 0;
          const locPts = parseInt(match.points_balance) || 0;
          if (Math.abs(locBal - cloudBal) > 0.001 || locPts !== cloudPts || match.name !== cc.name || match.phone !== cc.phone) {
            match.balance = cloudBal;
            match.points_balance = cloudPts;
            if (cc.phone && !match.phone) match.phone = cc.phone;
            if (cc.address && !match.address) match.address = cc.address;
            match.updated_at = cc.updated_at || new Date().toISOString();
            await DB.put('customers', match);
            updatedCount++;
          }
        } else {
          // New customer added from another branch or server
          const newRec = {
            ...cc,
            balance: cloudBal,
            points_balance: cloudPts,
            updated_at: cc.updated_at || new Date().toISOString()
          };
          delete newRec.id; // Let local store assign proper auto-increment id
          const newId = await DB.add('customers', newRec);
          newRec.id = newId;
          localByKey.set(k, newRec);
          updatedCount++;
        }
      }

      // Merge customer payment vouchers / receipts avoiding duplicates by ref
      const cloudTxns = Array.isArray(bObj.pos_customer_txns) ? bObj.pos_customer_txns : [];
      if (cloudTxns.length > 0) {
        const localTxns = (await DB.getAll('cash_transactions')) || [];
        const localRefs = new Set(localTxns.map(t => t.ref).filter(Boolean));
        for (const ctxn of cloudTxns) {
          if (ctxn && ctxn.ref && !localRefs.has(ctxn.ref)) {
            const copy = { ...ctxn };
            delete copy.id;
            await DB.add('cash_transactions', copy);
            localRefs.add(ctxn.ref);
          }
        }
      }

      if (updatedCount > 0) {
        if (window.CustomersModule && typeof CustomersModule.refresh === 'function') {
          await CustomersModule.refresh();
        }
        if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
          window.dispatchEvent(new CustomEvent('redshark_sync_complete', { detail: { table: 'customers', count: updatedCount } }));
        }
      }

      return { success: true, count: updatedCount };
    } catch(err) {
      console.warn('[OnlineOrders] pullCustomersFromCloud error:', err);
      return { success: false, error: err.message };
    }
  }

  // ── 8. Settings Modal ──────────────────────────────────────────────────────
  async function openSettingsModal() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const cfg = await getConfig();

    const modalHtml = `
      <div class="modal-overlay" id="online-orders-settings-modal" style="display:flex;align-items:center;justify-content:center;position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;backdrop-filter:blur(4px)">
        <div style="background:var(--surface,#fff);border:1px solid var(--border-color,#e5e7eb);border-radius:16px;width:90%;max-width:520px;padding:24px;box-shadow:0 20px 40px rgba(0,0,0,0.3);position:relative">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;border-bottom:1px solid var(--border-color,#eee);padding-bottom:12px">
            <h3 style="margin:0;font-size:1.15rem;font-weight:800;display:flex;align-items:center;gap:8px">
              <span>⚙️</span>
              <span>${isAR ? 'إعدادات ربط المتجر الإلكتروني (Supabase)' : 'Online Storefront & Supabase Settings'}</span>
            </h3>
            <button class="btn-icon" onclick="document.getElementById('online-orders-settings-modal').remove()" style="cursor:pointer;border:none;background:none;font-size:1.2rem">✕</button>
          </div>

          <div style="display:flex;flex-direction:column;gap:14px">
            <div>
              <label style="font-size:0.82rem;font-weight:700;display:block;margin-bottom:4px">
                ${isAR ? 'معرف المتجر (Shop Slug / ID)' : 'Shop Identifier (Slug / Subdomain)'}
              </label>
              <input type="text" id="setting-shop-slug" value="${cfg.slug}" class="form-control" placeholder="e.g. shop101" style="width:100%;padding:9px 12px;border-radius:8px;font-weight:700;font-family:monospace">
              <div style="font-size:0.7rem;color:var(--text-muted,#6b7280);margin-top:3px">${isAR ? 'نفس المعرف المحدد في نفق Cloudflare أو رابط المتجر' : 'Matches your unique Cloudflare tunnel subdomain (e.g. shop101.yourdomain.com)'}</div>
            </div>

            <div>
              <label style="font-size:0.82rem;font-weight:700;display:block;margin-bottom:4px">Supabase Project URL</label>
              <input type="text" id="setting-supabase-url" value="${cfg.url}" class="form-control" placeholder="https://xyz.supabase.co" style="width:100%;padding:9px 12px;border-radius:8px;font-size:0.85rem">
            </div>

            <div>
              <label style="font-size:0.82rem;font-weight:700;display:block;margin-bottom:4px">Supabase Anon Key</label>
              <textarea id="setting-supabase-key" class="form-control" rows="2" style="width:100%;padding:9px 12px;border-radius:8px;font-size:0.75rem;font-family:monospace">${cfg.key}</textarea>
            </div>

            <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:rgba(16,185,129,0.08);border-radius:8px;border:1px solid rgba(16,185,129,0.2)">
              <input type="checkbox" id="setting-auto-print" ${cfg.autoPrint ? 'checked' : ''} style="width:18px;height:18px;cursor:pointer">
              <label for="setting-auto-print" style="font-size:0.85rem;font-weight:700;cursor:pointer;margin:0">
                ${isAR ? '🖨️ طباعة إيصال التحضير تلقائياً فور وصول طلبية جديدة' : '🖨️ Automatically print packing slip when new order arrives'}
              </label>
            </div>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;border-top:1px solid var(--border-color,#eee);padding-top:14px">
            <button class="btn btn-ghost" onclick="document.getElementById('online-orders-settings-modal').remove()">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button class="btn btn-primary" onclick="OnlineOrders.saveSettings()">${isAR ? 'حفظ الإعدادات' : 'Save Settings'}</button>
          </div>
        </div>
      </div>
    `;

    const existing = document.getElementById('online-orders-settings-modal');
    if (existing) existing.remove();
    document.body.insertAdjacentHTML('beforeend', modalHtml);
  }

  async function saveSettings() {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const slug = document.getElementById('setting-shop-slug')?.value.trim() || 'shop101';
    const url = document.getElementById('setting-supabase-url')?.value.trim() || DEFAULT_SUPABASE_URL;
    const key = document.getElementById('setting-supabase-key')?.value.trim() || DEFAULT_SUPABASE_KEY;
    const autoPrint = document.getElementById('setting-auto-print')?.checked || false;

    if (typeof DB !== 'undefined') {
      await DB.setSetting('online_store_shop_slug', slug);
      await DB.setSetting('online_store_url', url);
      await DB.setSetting('online_store_key', key);
      await DB.setSetting('online_store_autoprint', autoPrint);
    }
    localStorage.setItem('redshark_shop_slug', slug);

    _resolvedShopId = null;
    document.getElementById('online-orders-settings-modal')?.remove();

    if (typeof Utils !== 'undefined' && Utils.toast) {
      Utils.toast(isAR ? '✅ تم حفظ إعدادات المتجر بنجاح' : '✅ Online store settings saved successfully', 'success');
    }

    await fetchOrders();
  }

  // ── 9. Main UI View Rendering ──────────────────────────────────────────────
  async function render(container) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    stopChimeLoop(); // Cashier opened the screen, stop audio alert

    container.innerHTML = `
      <div id="online-orders-container" style="padding:16px 20px;max-width:1400px;margin:0 auto">
        <!-- Header Bar -->
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:20px">
          <div>
            <h1 style="margin:0;font-size:1.6rem;font-weight:900;display:flex;align-items:center;gap:10px">
              <span>🛍️</span>
              <span>${isAR ? 'طلبات المتجر الإلكتروني (Online Orders)' : 'Online Store Orders'}</span>
              <span class="badge badge-success" id="oo-active-count" style="font-size:0.75rem;padding:3px 8px">Live</span>
            </h1>
            <p style="margin:4px 0 0;font-size:0.82rem;color:var(--text-muted,#6b7280)">
              ${isAR ? 'استقبال وإدارة الطلبات الواردة مباشرة من المتجر الإلكتروني وتحويلها إلى فواتير بيع مع طباعة فورية' : 'Live incoming order management, thermal kitchen packing slips, and 1-click POS sale conversion.'}
            </p>
          </div>

          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-outline" onclick="OnlineOrders.toggleMute()" id="btn-toggle-mute" title="Toggle Sound Alerts" style="display:flex;align-items:center;gap:6px">
              <span>${_isMuted ? '🔇' : '🔔'}</span>
              <span>${_isMuted ? (isAR ? 'تشغيل الصوت' : 'Unmute') : (isAR ? 'كتم الصوت' : 'Mute')}</span>
            </button>

            <button class="btn btn-outline" onclick="OnlineOrders.syncCatalogToCloud()" title="Push POS Items & Stock to Online Store" style="display:flex;align-items:center;gap:6px">
              <span>🔄</span>
              <span>${isAR ? 'مزامنة الأصناف مع المتجر' : 'Sync Catalog & Stock'}</span>
            </button>

            <button class="btn btn-outline" onclick="OnlineOrders.openSettingsModal()" title="Supabase & Shop Settings" style="display:flex;align-items:center;gap:6px">
              <span>⚙️</span>
              <span>${isAR ? 'الإعدادات' : 'Settings'}</span>
            </button>

            <button class="btn btn-primary" onclick="OnlineOrders.fetchOrders()" style="display:flex;align-items:center;gap:6px">
              <span>↻</span>
              <span>${isAR ? 'تحديث' : 'Refresh'}</span>
            </button>
          </div>
        </div>

        <!-- Filter Tabs & Search -->
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;background:var(--surface,#fff);border:1px solid var(--border-color,#e5e7eb);padding:12px 16px;border-radius:12px;margin-bottom:20px">
          <div style="display:flex;gap:6px;flex-wrap:wrap" id="oo-filter-tabs">
            <button class="btn btn-sm ${(!_activeFilter || _activeFilter === 'all') ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('all')">
              ${isAR ? 'الكل' : 'All'} (<span id="count-all">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'received' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('received')" style="position:relative">
              🔔 ${isAR ? 'جديد بانتظار التأكيد' : 'Received'} (<span id="count-received">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'preparing' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('preparing')">
              👨‍🍳 ${isAR ? 'جاري التحضير' : 'Preparing'} (<span id="count-preparing">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'out_for_delivery' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('out_for_delivery')">
              🛵 ${isAR ? 'خرج للتوصيل' : 'Out for Delivery'} (<span id="count-out_for_delivery">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'completed' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('completed')">
              ✅ ${isAR ? 'مكتمل' : 'Completed'} (<span id="count-completed">0</span>)
            </button>
            <button class="btn btn-sm ${_activeFilter === 'cancelled' ? 'btn-primary' : 'btn-ghost'}" onclick="OnlineOrders.setFilter('cancelled')">
              ❌ ${isAR ? 'ملغي' : 'Cancelled'} (<span id="count-cancelled">0</span>)
            </button>
          </div>

          <div style="min-width:260px">
            <input type="text" id="oo-search-input" oninput="OnlineOrders.renderOrderList()" placeholder="${isAR ? '🔍 ابحث برقم الطلب، الاسم، أو الهاتف...' : '🔍 Search by Order #, Name, Phone...'}" class="form-control" style="font-size:0.85rem;padding:7px 12px;border-radius:8px;width:100%;box-sizing:border-box">
          </div>
        </div>

        <!-- Orders Grid Container -->
        <div id="oo-orders-grid" style="display:grid;grid-template-columns:repeat(auto-fill, minmax(360px, 1fr));gap:16px">
          <!-- Populated by renderOrderList() -->
        </div>
      </div>
    `;

    await fetchOrders(true);
      syncPosSalesToCloud();
      syncCashboxStatusToCloud();
      pullCloudStockUpdates();
    renderOrderList();
  }

  function renderOrderList() {
    const grid = document.getElementById('oo-orders-grid');
    if (!grid) return;

    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const search = (document.getElementById('oo-search-input')?.value || '').toLowerCase().trim();

    // Update Counts
    const counts = {
      all: _orders.length,
      received: _orders.filter(o => o.order_status === 'received').length,
      preparing: _orders.filter(o => o.order_status === 'preparing').length,
      out_for_delivery: _orders.filter(o => o.order_status === 'out_for_delivery').length,
      completed: _orders.filter(o => o.order_status === 'completed').length,
      cancelled: _orders.filter(o => o.order_status === 'cancelled').length
    };

    Object.keys(counts).forEach(k => {
      const el = document.getElementById(`count-${k}`);
      if (el) el.textContent = counts[k];
    });

    let filtered = _orders;
    if (_activeFilter && _activeFilter !== 'all') {
      filtered = filtered.filter(o => o.order_status === _activeFilter);
    }

    if (search) {
      filtered = filtered.filter(o =>
        (o.order_number && o.order_number.toLowerCase().includes(search)) ||
        (o.customer_name && o.customer_name.toLowerCase().includes(search)) ||
        (o.customer_phone && o.customer_phone.includes(search)) ||
        (o.pos_invoice_ref && o.pos_invoice_ref.toLowerCase().includes(search))
      );
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div style="grid-column:1/-1;text-align:center;padding:60px 20px;background:var(--surface,#fff);border:1px dashed var(--border-color,#d1d5db);border-radius:16px">
          <div style="font-size:3rem;margin-bottom:10px">📭</div>
          <h3 style="margin:0 0 6px;font-size:1.1rem;font-weight:700">${isAR ? 'لا توجد طلبات في هذا القسم حالياً' : 'No orders found in this section'}</h3>
          <p style="margin:0;font-size:0.8rem;color:var(--text-muted,#6b7280)">${isAR ? 'أي طلبية جديدة يقوم الزبون بطلبها عبر المتجر ستظهر هنا تلقائياً مع جرس تنبيه.' : 'Any new orders placed via the online shop will appear here automatically with sound notification.'}</p>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(order => {
      const statusBadge = getStatusBadge(order.order_status, isAR);
      const isReceived = order.order_status === 'received';
      const isPreparing = order.order_status === 'preparing';
      const isOutForDelivery = order.order_status === 'out_for_delivery';
      const isCompleted = order.order_status === 'completed';
      const isCancelled = order.order_status === 'cancelled';

      const items = getOrderItems(order);
      const totalUSD = (parseFloat(order.total) || 0).toFixed(2);
      const rate = parseFloat(order.exchange_rate) || 89500;
      const totalLBP = (parseFloat(order.total_secondary) || Math.round(totalUSD * rate)).toLocaleString();

      let addrText = '';
      if (order.delivery_address) {
        if (typeof order.delivery_address === 'object') {
          const a = order.delivery_address;
          addrText = [a.city, a.street_address, a.building].filter(Boolean).join(', ');
        } else {
          addrText = String(order.delivery_address);
        }
      }

      return `
        <div style="background:var(--surface,#fff);border:1.5px solid ${isReceived ? '#f59e0b' : 'var(--border-color,#e5e7eb)'};border-radius:14px;padding:16px;display:flex;flex-direction:column;justify-content:space-between;box-shadow:${isReceived ? '0 8px 24px rgba(245,158,11,0.18)' : '0 2px 8px rgba(0,0,0,0.04)'};position:relative;animation:${isReceived ? 'pulseBorder 2s infinite' : 'none'}">
          <!-- Card Top Bar with Direct Status Selector -->
          <div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;gap:8px">
              <div>
                <span style="font-family:monospace;font-weight:900;font-size:1.05rem;color:var(--primary,#2563eb)">#${order.order_number || 'RS-ORD'}</span>
                <div style="font-size:0.72rem;color:var(--text-muted,#6b7280);margin-top:2px">
                  ${new Date(order.created_at || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • ${new Date(order.created_at || Date.now()).toLocaleDateString()}
                </div>
              </div>

              <!-- Direct Status Dropdown Selector -->
              <div style="display:flex;align-items:center;gap:6px">
                <select class="form-control" style="font-size:0.76rem;font-weight:800;padding:5px 10px;border-radius:20px;border:1.5px solid ${order.order_status === 'received' ? '#f59e0b' : (order.order_status === 'preparing' ? '#0284c7' : (order.order_status === 'out_for_delivery' ? '#9333ea' : (order.order_status === 'completed' ? '#10b981' : '#ef4444')))};background:var(--surface,#fff);color:var(--text-main,#111827);cursor:pointer;outline:none"
                  onchange="OnlineOrders.updateOrderStatus('${order.id}', this.value)">
                  <option value="received" ${order.order_status === 'received' ? 'selected' : ''}>🔔 ${isAR ? 'جديد (Received)' : 'Received'}</option>
                  <option value="preparing" ${order.order_status === 'preparing' ? 'selected' : ''}>👨‍🍳 ${isAR ? 'قيد التحضير (Preparing)' : 'Preparing'}</option>
                  <option value="out_for_delivery" ${order.order_status === 'out_for_delivery' ? 'selected' : ''}>🛵 ${isAR ? 'خرج للتوصيل (Out for Delivery)' : 'Out for Delivery'}</option>
                  <option value="completed" ${order.order_status === 'completed' ? 'selected' : ''}>✅ ${isAR ? 'مكتمل (Completed)' : 'Completed'}</option>
                  <option value="cancelled" ${order.order_status === 'cancelled' ? 'selected' : ''}>❌ ${isAR ? 'ملغي (Cancelled)' : 'Cancelled'}</option>
                </select>
              </div>
            </div>

            <!-- Customer & Delivery Info -->
            <div style="background:var(--input-bg,rgba(0,0,0,0.02));border-radius:10px;padding:10px 12px;margin-bottom:12px;border:1px solid var(--border-color,#eee)">
              <div style="font-weight:800;font-size:0.95rem;display:flex;align-items:center;justify-content:space-between">
                <span>👤 ${order.customer_name}</span>
                <span style="font-size:0.75rem;font-weight:700;color:#0284c7">
                  ${order.fulfillment_type === 'pickup' ? (isAR ? '🏬 استلام بالمحل' : '🏬 Pickup') : (isAR ? '🛵 توصيل' : '🛵 Delivery')}
                </span>
              </div>
              <div style="display:flex;align-items:center;gap:8px;margin-top:4px">
                <span style="font-size:0.85rem;font-weight:700">📞 ${order.customer_phone}</span>
                ${order.customer_phone ? `
                <a href="https://wa.me/${order.customer_phone.replace(/[^0-9]/g, '')}" target="_blank" style="text-decoration:none;font-size:0.75rem;background:#25d366;color:#fff;padding:2px 7px;border-radius:12px;font-weight:700">
                  WhatsApp
                </a>` : ''}
              </div>
              ${addrText ? `
              <div style="font-size:0.75rem;color:var(--text-muted,#4b5563);margin-top:4px;line-height:1.3">
                📍 ${addrText}
              </div>` : ''}
              ${order.notes ? `
              <div style="font-size:0.75rem;color:#b91c1c;margin-top:4px;font-weight:600">
                📝 ${order.notes}
              </div>` : ''}
            </div>

            <!-- Items List Summary -->
            <div style="margin-bottom:12px">
              <div style="font-size:0.75rem;font-weight:800;text-transform:uppercase;color:var(--text-muted,#6b7280);margin-bottom:6px;display:flex;justify-content:space-between;align-items:center">
                <span>${isAR ? 'الأصناف المطلوبة' : 'Ordered Items'} (${items.length}):</span>
                <span style="font-size:0.72rem;color:var(--text-muted,#6b7280);font-weight:600">${items.reduce((s, it) => s + (parseFloat(it.quantity || it.qty) || 1), 0)} pcs</span>
              </div>
              <div style="max-height:160px;overflow-y:auto;display:flex;flex-direction:column;gap:4px;background:var(--bg-secondary,rgba(0,0,0,0.02));padding:8px 10px;border-radius:10px;border:1px solid var(--border-color,#f1f5f9)">
                ${items.length === 0 ? `
                  <div style="text-align:center;padding:12px;color:var(--text-muted,#9ca3af);font-size:0.8rem">
                    ${isAR ? 'لا توجد أصناف في هذا الطلب' : 'No items recorded in this order'}
                  </div>
                ` : items.map(it => {
                  const itName = it.product_name || it.name || it.title || (isAR ? 'صنف' : 'Product');
                  const itQty = parseFloat(it.quantity || it.qty) || 1;
                  const itPrice = parseFloat(it.unit_price || it.price) || 0;
                  const itTotal = parseFloat(it.total_price || it.total) || (itQty * itPrice);
                  return `
                    <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.84rem;padding:4px 0;border-bottom:1px dashed var(--border-color,#e5e7eb)">
                      <div style="display:flex;align-items:center;gap:6px">
                        <span style="background:rgba(2,132,199,0.12);color:#0284c7;font-weight:900;font-size:0.76rem;padding:2px 7px;border-radius:6px">${itQty}x</span>
                        <span style="font-weight:700;color:var(--text-main,#111827)">${itName}</span>
                        ${it.variant_name ? `<span style="font-size:0.72rem;color:var(--text-muted,#6b7280)">(${it.variant_name})</span>` : ''}
                      </div>
                      <span style="font-weight:800;color:var(--text-main,#111827)">$${itTotal.toFixed(2)}</span>
                    </div>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- Financials Summary -->
            <div style="display:flex;justify-content:space-between;align-items:baseline;padding-top:8px;border-top:1px solid var(--border-color,#eee);margin-bottom:14px">
              <div>
                <span style="font-size:0.75rem;color:var(--text-muted,#6b7280)">${(order.payment_method || 'cod').toUpperCase()} • </span>
                <span style="font-size:0.78rem;font-weight:700;color:${order.payment_status === 'paid' ? '#10b981' : '#f59e0b'}">
                  ${order.payment_status === 'paid' ? (isAR ? 'مدفوع' : 'Paid') : (isAR ? 'الدفع عند الاستلام' : 'Pending Payment')}
                </span>
              </div>
              <div style="text-align:right">
                <div style="font-size:1.15rem;font-weight:900;color:var(--text-main,#111827)">$${totalUSD} <span style="font-size:0.8rem">USD</span></div>
                <div style="font-size:0.75rem;font-weight:700;color:#0284c7">≈ ${totalLBP} L.L.</div>
              </div>
            </div>

            ${order.pos_invoice_ref ? `
            <div style="background:rgba(16,185,129,0.1);color:#059669;padding:6px 10px;border-radius:6px;font-size:0.78rem;font-weight:800;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between">
              <span>🧾 ${isAR ? 'فاتورة نقاط البيع:' : 'POS Invoice Ref:'}</span>
              <span style="font-family:monospace">${order.pos_invoice_ref}</span>
            </div>` : ''}
          </div>

          <!-- Bottom Action Buttons -->
          <div style="display:flex;flex-direction:column;gap:6px;padding-top:8px;border-top:1px solid var(--border-color,#eee)">
            ${isReceived ? `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-primary btn-sm" onclick="OnlineOrders.acceptAndPrepare('${order.id}')" style="font-weight:800">
                👨‍🍳 ${isAR ? 'قبول وتحضير' : 'Accept & Prepare'}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.printOrderSlipById('${order.id}', true)">
                🖨️ ${isAR ? 'طباعة التغليف' : 'Print Slip'}
              </button>
            </div>
            ` : ''}

            ${isPreparing ? `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <button class="btn btn-primary btn-sm" onclick="OnlineOrders.updateOrderStatus('${order.id}', 'out_for_delivery')" style="background:#0284c7;border-color:#0284c7;font-weight:800">
                🛵 ${isAR ? 'خرج للتوصيل' : 'Out for Delivery'}
              </button>
              <button class="btn btn-outline btn-sm" onclick="OnlineOrders.printOrderSlipById('${order.id}', false)">
                🖨️ ${isAR ? 'طباعة الفاتورة' : 'Print Invoice'}
              </button>
            </div>
            ` : ''}

            ${(isPreparing || isOutForDelivery || (isReceived && !order.pos_synced)) ? `
            <button class="btn btn-success btn-sm" onclick="OnlineOrders.convertOrderToSale('${order.id}')" style="background:#10b981;border-color:#10b981;color:#fff;font-weight:900;display:flex;align-items:center;justify-content:center;gap:6px">
              <span>💰</span>
              <span>${isAR ? 'إتمام البيع وخصم المخزون (POS Sale)' : 'Process as Sale & Deduct Stock'}</span>
            </button>
            ` : ''}

            ${isCompleted ? `
            <div style="display:flex;gap:6px">
              <button class="btn btn-outline btn-sm" style="flex:1" onclick="OnlineOrders.printOrderSlipById('${order.id}', false)">
                🖨️ ${isAR ? 'إعادة طباعة الفاتورة' : 'Reprint Invoice'}
              </button>
            </div>
            ` : ''}

            ${(!isCompleted && !isCancelled) ? `
            <button class="btn btn-ghost btn-sm" onclick="OnlineOrders.cancelOrderPrompt('${order.id}')" style="color:var(--danger,#ef4444);font-size:0.75rem;padding:2px">
              ✕ ${isAR ? 'إلغاء الطلب' : 'Cancel Order'}
            </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  }

  function getStatusBadge(status, isAR) {
    switch (status) {
      case 'received':
        return `<span style="background:#fef3c7;color:#b45309;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #fde68a">🔔 ${isAR ? 'جديد بانتظار التأكيد' : 'Received'}</span>`;
      case 'preparing':
        return `<span style="background:#e0f2fe;color:#0369a1;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #bae6fd">👨‍🍳 ${isAR ? 'جاري التحضير' : 'Preparing'}</span>`;
      case 'out_for_delivery':
        return `<span style="background:#f3e8ff;color:#7e22ce;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #e9d5ff">🛵 ${isAR ? 'خرج للتوصيل' : 'Out for Delivery'}</span>`;
      case 'completed':
        return `<span style="background:#d1fae5;color:#047857;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #a7f3d0">✅ ${isAR ? 'مكتمل' : 'Completed'}</span>`;
      case 'cancelled':
        return `<span style="background:#fee2e2;color:#b91c1c;font-weight:800;font-size:0.72rem;padding:3px 8px;border-radius:12px;border:1px solid #fecaca">❌ ${isAR ? 'ملغي' : 'Cancelled'}</span>`;
      default:
        return `<span class="badge">${status}</span>`;
    }
  }

  // Helper actions
  async function acceptAndPrepare(orderId) {
    stopChimeLoop();
    await updateOrderStatus(orderId, 'preparing');
  }

  function printOrderSlipById(orderId, isPackingSlip) {
    const o = _orders.find(ord => ord.id === orderId);
    if (o) printOrderSlip(o, isPackingSlip);
  }

  async function cancelOrderPrompt(orderId) {
    const isAR = (typeof i18n !== 'undefined' && i18n.getLang() === 'ar');
    const reason = prompt(isAR ? 'يرجى كتابة سبب الإلغاء (اختياري):' : 'Enter cancellation reason (optional):');
    if (reason === null) return; // User cancelled prompt
    await updateOrderStatus(orderId, 'cancelled', { cancel_reason: reason });
  }

  function setFilter(filter) {
    _activeFilter = filter;
    const tabs = document.querySelectorAll('#oo-filter-tabs button');
    tabs.forEach(t => t.classList.remove('btn-primary'));
    renderOrderList();
  }

  function toggleMute() {
    _isMuted = !_isMuted;
    if (_isMuted) stopChimeLoop();
    const btn = document.getElementById('btn-toggle-mute');
    if (btn) {
      btn.innerHTML = `<span>${_isMuted ? '🔇' : '🔔'}</span><span>${_isMuted ? 'Unmute' : 'Mute'}</span>`;
    }
  }

  // ── 10. Initialization ─────────────────────────────────────────────────────
  async function init() {
    // Start background order polling every 12 seconds
    if (_pollInterval) clearInterval(_pollInterval);
    _pollInterval = setInterval(() => {
      fetchOrders(true);
    }, 12000);

    // Initial silent check
    setTimeout(() => {
      fetchOrders(true);
    }, 2000);

    // Request desktop notification permission if supported
    if ('Notification' in window && Notification.permission === 'default') {
      try { Notification.requestPermission(); } catch (e) {}
    }
  }

  return {
    getConfig,
    resolveShopId,
    init,
    render,
    fetchOrders,
    updateOrderStatus,
    acceptAndPrepare,
    convertOrderToSale,
    printOrderSlip,
    printOrderSlipById,
    syncCatalogToCloud,
    syncSingleProductToCloud,
    deleteProductFromCloud,
    deleteCategoryFromCloud,
    applyDeletedProducts,
    applyDeletedCategories,
    pullCatalogFromCloud,
    pullCloudDelta,
    heartbeatBranchToCloud,
    fetchCloudConnectedBranches,
    removeCloudConnectedBranch,
    syncPosSalesToCloud,
    syncCashboxStatusToCloud,
    syncCustomersToCloud,
    pullCustomersFromCloud,
    broadcastCloudUpdate,
    syncCloudTables,
    pullCloudTables,
    pullCloudStockUpdates,
    openSettingsModal,
    saveSettings,
    setFilter,
    toggleMute,
    playAlertChime,
    stopChimeLoop
  };
})();

// Attach globally
window.OnlineOrders = OnlineOrders;
