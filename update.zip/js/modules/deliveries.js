/* ================================================================
   NexPOS — Retail Deliveries Management Module
   Simple, Role-Based Delivery Management for Retail POS
   ================================================================ */

const Deliveries = (() => {
  let _deliveries = [];
  let _activeFilter = 'all'; // 'all', 'active', 'unpaid', 'delivered'
  let _searchQuery = '';

  async function render(container) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    
    // Check RBAC permission
    if (!Auth.can('deliveries') && !Auth.isAdmin()) {
      container.innerHTML = `
        <div class="animate-slide" style="max-width:540px;margin:60px auto;text-align:center">
          <div style="font-size:3rem;margin-bottom:12px">🔒</div>
          <h2 style="font-weight:900;color:var(--danger)">${isAR ? 'غير مصرح بالدخول' : 'Access Denied'}</h2>
          <p style="color:var(--text-muted);margin:8px 0 20px">${isAR ? 'ليس لديك صلاحية للوصول إلى إدارة التوصيل (دليفري).' : 'You do not have permission to access Retail Delivery Management.'}</p>
        </div>`;
      return;
    }

    _deliveries = await DB.getAll('deliveries') || [];
    // Sort newest first
    _deliveries.sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));

    container.innerHTML = `
      <div class="animate-slide" style="padding:16px 22px;max-width:1400px;margin:0 auto">
        
        <!-- Header & Summary Cards -->
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:18px">
          <div>
            <h1 style="font-size:1.45rem;font-weight:900;margin:0;display:flex;align-items:center;gap:10px">
              <span style="font-size:1.6rem">🛵</span>
              <span>${isAR ? 'إدارة توصيل الطلبات (الدليفري)' : 'Retail Delivery Management'}</span>
            </h1>
            <p style="font-size:0.84rem;color:var(--text-muted);margin:4px 0 0">
              ${isAR ? 'متابعة وتوصيل فواتير المحل، تحصيل المبالغ عند العودة، وقفل الطلبات' : 'Track retail shop deliveries, collect money upon return, and settle invoices'}
            </p>
          </div>
          <div style="display:flex;align-items:center;gap:8px">
            <button class="btn btn-secondary btn-sm" onclick="Deliveries.refresh()" style="font-weight:700;display:flex;align-items:center;gap:6px">
              🔄 <span>${isAR ? 'تحديث' : 'Refresh'}</span>
            </button>
            <button class="btn btn-primary btn-sm" onclick="App.navigate('pos')" style="font-weight:800;display:flex;align-items:center;gap:6px;background:#ef4444;border-color:#dc2626">
              🛒 <span>${isAR ? 'فاتورة توصيل جديدة (POS)' : 'New Delivery Sale (POS)'}</span>
            </button>
          </div>
        </div>

        <!-- Metric KPI Cards -->
        ${renderMetricCards(isAR)}

        <!-- Toolbar: Search + Filter Tabs -->
        <div style="background:var(--surface-1);border:1px solid var(--border-color);border-radius:12px;padding:12px 16px;margin-bottom:16px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px">
          <!-- Filter Tabs -->
          <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap" id="deliv-filter-tabs">
            <button type="button" class="btn btn-sm ${!_activeFilter || _activeFilter === 'all' ? 'btn-primary' : 'btn-ghost'}" onclick="Deliveries.setFilter('all')">
              🌐 ${isAR ? 'الكل' : 'All'} (${_deliveries.length})
            </button>
            <button type="button" class="btn btn-sm ${_activeFilter === 'active' ? 'btn-primary' : 'btn-ghost'}" onclick="Deliveries.setFilter('active')" style="${_activeFilter === 'active' ? 'background:#f59e0b;border-color:#d97706;color:#fff' : ''}">
              🕒 ${isAR ? 'طلبات قيد التوصيل (مفتوحة)' : 'Active / Open'} (${getActiveCount()})
            </button>
            <button type="button" class="btn btn-sm ${_activeFilter === 'unpaid' ? 'btn-primary' : 'btn-ghost'}" onclick="Deliveries.setFilter('unpaid')" style="${_activeFilter === 'unpaid' ? 'background:#ef4444;border-color:#dc2626;color:#fff' : ''}">
              💳 ${isAR ? 'غير محصل (بانتظار السائق)' : 'Unpaid COD'} (${getUnpaidCount()})
            </button>
            <button type="button" class="btn btn-sm ${_activeFilter === 'delivered' ? 'btn-primary' : 'btn-ghost'}" onclick="Deliveries.setFilter('delivered')" style="${_activeFilter === 'delivered' ? 'background:#10b981;border-color:#059669;color:#fff' : ''}">
              ✅ ${isAR ? 'تم التسليم والقفل' : 'Closed / Delivered'} (${getDeliveredCount()})
            </button>
          </div>

          <!-- Search Bar -->
          <div style="position:relative;min-width:280px;flex:1;max-width:400px">
            <input type="text" id="deliv-search-input" class="form-control" 
              placeholder="${isAR ? '🔍 بحث برقم الفاتورة، اسم العميل، أو الهاتف...' : '🔍 Search invoice #, customer, phone...'}"
              value="${Utils.sanitize(_searchQuery)}"
              oninput="Deliveries.onSearch(this.value)"
              style="padding-inline-start:12px;font-size:0.86rem;border-radius:8px">
          </div>
        </div>

        <!-- Deliveries Table Container -->
        <div id="deliv-table-container">
          ${renderTable(isAR)}
        </div>

      </div>

      <!-- Payment & Close Settlement Modal -->
      <div id="deliv-settle-modal-slot"></div>
    `;

    updateSidebarBadge();
  }

  function getActiveCount() {
    return _deliveries.filter(d => d.delivery_status !== 'delivered' && d.delivery_status !== 'cancelled').length;
  }

  function getUnpaidCount() {
    return _deliveries.filter(d => d.payment_status !== 'paid' && d.delivery_status !== 'cancelled').length;
  }

  function getDeliveredCount() {
    return _deliveries.filter(d => d.delivery_status === 'delivered').length;
  }

  function renderMetricCards(isAR) {
    const cur1 = window._primaryCurrency || 'USD';
    const cur2 = window._secondaryCurrency || 'LBP';
    const active = getActiveCount();
    const unpaidList = _deliveries.filter(d => d.payment_status !== 'paid' && d.delivery_status !== 'cancelled');
    const totalUnpaidUsd = unpaidList.reduce((sum, d) => sum + (parseFloat(d.remaining_balance !== undefined ? d.remaining_balance : (d.total - (d.paid_amount || 0))) || 0), 0);
    const todayStr = new Date().toISOString().slice(0, 10);
    const completedToday = _deliveries.filter(d => d.delivery_status === 'delivered' && (d.settled_at || d.created_at || '').slice(0, 10) === todayStr).length;

    return `
      <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:14px;margin-bottom:18px">
        <!-- Active Deliveries -->
        <div style="background:var(--surface-1);border:1.5px solid rgba(245,158,11,0.3);border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:14px">
          <div style="width:44px;height:44px;border-radius:10px;background:rgba(245,158,11,0.15);display:flex;align-items:center;justify-content:center;font-size:1.4rem">
            🛵
          </div>
          <div>
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);text-transform:uppercase">${isAR ? 'الطلبات المفتوحة حالياً' : 'Active Open Deliveries'}</div>
            <div style="font-size:1.55rem;font-weight:900;color:#f59e0b">${active}</div>
          </div>
        </div>

        <!-- Unpaid COD -->
        <div style="background:var(--surface-1);border:1.5px solid rgba(239,68,68,0.3);border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:14px">
          <div style="width:44px;height:44px;border-radius:10px;background:rgba(239,68,68,0.15);display:flex;align-items:center;justify-content:center;font-size:1.4rem">
            💳
          </div>
          <div>
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);text-transform:uppercase">${isAR ? 'مبالغ قيد التحصيل (COD مع السائق)' : 'Pending COD Collection'}</div>
            <div style="font-size:1.35rem;font-weight:900;color:#ef4444">
              ${cur1} ${Utils.formatCurrency(totalUnpaidUsd)}
              <span style="font-size:0.78rem;font-weight:700;color:var(--text-muted)">(${unpaidList.length} ${isAR ? 'طلب' : 'orders'})</span>
            </div>
          </div>
        </div>

        <!-- Completed Today -->
        <div style="background:var(--surface-1);border:1.5px solid rgba(16,185,129,0.3);border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:14px">
          <div style="width:44px;height:44px;border-radius:10px;background:rgba(16,185,129,0.15);display:flex;align-items:center;justify-content:center;font-size:1.4rem">
            ✅
          </div>
          <div>
            <div style="font-size:0.75rem;font-weight:700;color:var(--text-muted);text-transform:uppercase">${isAR ? 'تم تسليمها وتحصيلها اليوم' : 'Delivered & Closed Today'}</div>
            <div style="font-size:1.55rem;font-weight:900;color:#10b981">${completedToday}</div>
          </div>
        </div>
      </div>
    `;
  }

  function getFilteredList() {
    let list = [..._deliveries];

    // Filter tab
    if (_activeFilter === 'active') {
      list = list.filter(d => d.delivery_status !== 'delivered' && d.delivery_status !== 'cancelled');
    } else if (_activeFilter === 'unpaid') {
      list = list.filter(d => d.payment_status !== 'paid' && d.delivery_status !== 'cancelled');
    } else if (_activeFilter === 'delivered') {
      list = list.filter(d => d.delivery_status === 'delivered');
    }

    // Search query
    if (_searchQuery) {
      const q = _searchQuery.toLowerCase().trim();
      list = list.filter(d => {
        const inv = String(d.invoice_no || '').toLowerCase();
        const name = String(d.customer_name || '').toLowerCase();
        const phone = String(d.customer_phone || '').toLowerCase();
        const addr = String(d.delivery_address || '').toLowerCase();
        return inv.includes(q) || name.includes(q) || phone.includes(q) || addr.includes(q);
      });
    }

    return list;
  }

  function renderTable(isAR) {
    const list = getFilteredList();
    const canSettle = Auth.isAdmin() || Auth.can('deliveries.settle') || Auth.can('deliveries');
    const cur1 = window._primaryCurrency || 'USD';
    const cur2 = window._secondaryCurrency || 'LBP';
    const exchRate = window._exchangeRate || 89500;

    if (!list.length) {
      return `
        <div style="background:var(--surface-1);border:1px solid var(--border-color);border-radius:12px;padding:48px 20px;text-align:center">
          <div style="font-size:3rem;margin-bottom:12px">🛵</div>
          <h3 style="font-weight:800;color:var(--text-primary);margin-bottom:6px">${isAR ? 'لا توجد طلبات توصيل مطابقة' : 'No Delivery Records Found'}</h3>
          <p style="color:var(--text-muted);font-size:0.86rem;margin-bottom:18px">${isAR ? 'قم بإنشاء فاتورة توصيل مباشرة من شاشة نقطة البيع POS' : 'Create a delivery sale directly from the POS cockpit'}</p>
          <button class="btn btn-primary btn-sm" onclick="App.navigate('pos')" style="font-weight:800">
            🛒 ${isAR ? 'الانتقال إلى نقطة البيع' : 'Go to POS Cockpit'}
          </button>
        </div>
      `;
    }

    return `
      <div class="table-wrapper" style="background:var(--surface-1);border:1px solid var(--border-color);border-radius:12px;overflow:hidden;box-shadow:0 4px 14px rgba(0,0,0,0.03)">
        <table style="width:100%;border-collapse:collapse;font-size:0.85rem">
          <thead>
            <tr style="background:var(--surface-2);border-bottom:1.5px solid var(--border-color);text-align:${isAR ? 'right' : 'left'}">
              <th style="padding:11px 14px;font-weight:800">${isAR ? 'رقم الفاتورة' : 'Invoice #'}</th>
              <th style="padding:11px 14px;font-weight:800">${isAR ? 'التاريخ والوقت' : 'Date & Time'}</th>
              <th style="padding:11px 14px;font-weight:800">${isAR ? 'العميل والهاتف' : 'Customer & Phone'}</th>
              <th style="padding:11px 14px;font-weight:800">${isAR ? 'عنوان التوصيل وملاحظات' : 'Address & Notes'}</th>
              <th style="padding:11px 14px;font-weight:800">${isAR ? 'المبلغ المستحق' : 'Amount Due'}</th>
              <th style="padding:11px 14px;font-weight:800;text-align:center">${isAR ? 'حالة الدفع' : 'Payment'}</th>
              <th style="padding:11px 14px;font-weight:800;text-align:center">${isAR ? 'حالة التوصيل' : 'Delivery'}</th>
              <th style="padding:11px 14px;font-weight:800;text-align:center">${isAR ? 'إجراءات أساسية' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody>
            ${list.map(d => {
              const totalVal = parseFloat(d.total) || 0;
              const paidVal = parseFloat(d.paid_amount) || 0;
              const remVal = Math.max(0, Utils.round(totalVal - paidVal));
              const isPaid = d.payment_status === 'paid' || remVal <= 0.001;
              const isDelivered = d.delivery_status === 'delivered';
              const isCancelled = d.delivery_status === 'cancelled';

              // Payment badge
              let payBadge = `<span class="badge" style="background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid rgba(239,68,68,0.3);font-weight:800">🔴 ${isAR ? 'غير مدفوع (COD)' : 'Unpaid COD'}</span>`;
              if (isPaid) {
                payBadge = `<span class="badge" style="background:rgba(16,185,129,0.15);color:#10b981;border:1px solid rgba(16,185,129,0.3);font-weight:800">🟢 ${isAR ? 'مسدد بالكامل' : 'Paid in Full'}</span>`;
              } else if (paidVal > 0) {
                payBadge = `<span class="badge" style="background:rgba(245,158,11,0.15);color:#f59e0b;border:1px solid rgba(245,158,11,0.3);font-weight:800">🟡 ${isAR ? 'مدفوع جزئياً' : 'Partial'}</span>`;
              }

              // Delivery badge
              let delBadge = `<span class="badge" style="background:rgba(245,158,11,0.15);color:#f59e0b;font-weight:800">🕒 ${isAR ? 'قيد التجهيز' : 'Pending'}</span>`;
              if (d.delivery_status === 'out_for_delivery') {
                delBadge = `<span class="badge" style="background:rgba(59,130,246,0.15);color:#3b82f6;font-weight:800">🛵 ${isAR ? 'في الطريق' : 'Out for Delivery'}</span>`;
              } else if (isDelivered) {
                delBadge = `<span class="badge" style="background:rgba(16,185,129,0.15);color:#10b981;font-weight:800">✅ ${isAR ? 'تم التسليم' : 'Delivered'}</span>`;
              } else if (isCancelled) {
                delBadge = `<span class="badge" style="background:rgba(148,163,184,0.15);color:#94a3b8;font-weight:800">❌ ${isAR ? 'ملغي' : 'Cancelled'}</span>`;
              }

              const secondaryTotal = d.secondary_total || (totalVal * exchRate);

              return `
                <tr style="border-bottom:1px solid var(--border-color);background:${!isDelivered ? 'rgba(245,158,11,0.02)' : 'transparent'};transition:background 0.15s">
                  <!-- Invoice # -->
                  <td style="padding:12px 14px;vertical-align:middle">
                    <div style="font-weight:800;color:var(--text-primary);cursor:pointer;display:inline-flex;align-items:center;gap:4px" onclick="Deliveries.previewInvoice(${d.id})" title="${isAR ? 'انقر لمعاينة وطباعة الفاتورة' : 'Click to view/print invoice'}">
                      <span style="color:#ef4444">🧾</span>
                      <span style="text-decoration:underline"><bdi>${Utils.sanitize(d.invoice_no)}</bdi></span>
                    </div>
                    <div style="font-size:0.73rem;color:var(--text-muted);margin-top:2px">${isAR ? 'الكاشير:' : 'Cashier:'} ${Utils.sanitize(d.cashier || 'Admin')}</div>
                  </td>

                  <!-- Date -->
                  <td style="padding:12px 14px;vertical-align:middle;white-space:nowrap">
                    <div style="font-weight:600;color:var(--text-primary)"><bdi>${Utils.formatDateTime(d.created_at)}</bdi></div>
                    ${d.settled_at ? `<div style="font-size:0.72rem;color:var(--text-muted)">${isAR ? 'أغلقت:' : 'Closed:'} <bdi>${Utils.formatDateTime(d.settled_at)}</bdi></div>` : ''}
                  </td>

                  <!-- Customer & Phone -->
                  <td style="padding:12px 14px;vertical-align:middle">
                    <div style="font-weight:800;color:var(--text-primary);display:flex;align-items:center;gap:6px">
                      <span>👤 ${Utils.sanitize(d.customer_name || (isAR ? 'عميل' : 'Customer'))}</span>
                    </div>
                    ${d.customer_phone ? `
                    <div style="font-size:0.78rem;color:var(--text-muted);margin-top:3px;display:flex;align-items:center;gap:6px">
                      <span>📞 <bdi>${Utils.sanitize(d.customer_phone)}</bdi></span>
                      <a href="https://wa.me/${String(d.customer_phone).replace(/[^0-9]/g,'')}" target="_blank" style="color:#10b981;font-weight:700;text-decoration:none" title="WhatsApp">💬</a>
                    </div>` : ''}
                  </td>

                  <!-- Address & Notes -->
                  <td style="padding:12px 14px;vertical-align:middle;max-width:280px">
                    <div style="font-weight:700;color:var(--text-primary);line-height:1.3">
                      📍 ${Utils.sanitize(d.delivery_address || (isAR ? 'العنوان غير محدد' : 'No address specified'))}
                    </div>
                    ${d.delivery_notes ? `
                    <div style="font-size:0.76rem;color:var(--text-muted);font-style:italic;margin-top:3px">
                      📝 ${Utils.sanitize(d.delivery_notes)}
                    </div>` : ''}
                    ${d.delivery_fee > 0 ? `
                    <div style="font-size:0.73rem;color:#f59e0b;font-weight:700;margin-top:2px">
                      🛵 ${isAR ? 'أجرة التوصيل:' : 'Delivery Fee:'} ${cur1} ${Utils.formatCurrency(d.delivery_fee)}
                    </div>` : ''}
                  </td>

                  <!-- Amounts -->
                  <td style="padding:12px 14px;vertical-align:middle">
                    <div style="font-weight:900;color:var(--text-primary);font-size:0.95rem">
                      ${cur1} ${Utils.formatCurrency(totalVal)}
                    </div>
                    <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">
                      ${Math.round(secondaryTotal).toLocaleString()} ${cur2}
                    </div>
                    ${!isPaid ? `
                    <div style="font-size:0.76rem;font-weight:800;color:#ef4444;margin-top:3px">
                      ${isAR ? 'مستحق الدفع: ' : 'Due: '}${cur1} ${Utils.formatCurrency(remVal)}
                    </div>` : ''}
                  </td>

                  <!-- Payment Status -->
                  <td style="padding:12px 14px;vertical-align:middle;text-align:center">
                    ${payBadge}
                  </td>

                  <!-- Delivery Status -->
                  <td style="padding:12px 14px;vertical-align:middle;text-align:center">
                    ${delBadge}
                    ${!isDelivered && !isCancelled ? `
                    <div style="margin-top:4px">
                      <select class="form-control" style="height:24px;padding:0 4px;font-size:0.72rem;font-weight:700;border-radius:4px" onchange="Deliveries.updateStatus(${d.id}, this.value)">
                        <option value="pending" ${d.delivery_status === 'pending' ? 'selected' : ''}>${isAR ? '🕒 قيد التجهيز' : 'Pending'}</option>
                        <option value="out_for_delivery" ${d.delivery_status === 'out_for_delivery' ? 'selected' : ''}>${isAR ? '🛵 في الطريق' : 'Out for Delivery'}</option>
                      </select>
                    </div>` : ''}
                  </td>

                  <!-- Actions -->
                  <td style="padding:12px 14px;vertical-align:middle;text-align:center">
                    <div style="display:flex;align-items:center;justify-content:center;gap:6px;flex-wrap:wrap">
                      
                      <!-- Action 1: Receive Payment & Close -->
                      ${(!isDelivered || !isPaid) && canSettle ? `
                      <button type="button" class="btn btn-sm" onclick="Deliveries.openReceivePaymentModal(${d.id})"
                        title="${isAR ? 'استلام المبلغ من السائق وقفل الطلب في الصندوق' : 'Receive money from delivery driver & close delivery'}"
                        style="background:#10b981;color:#fff;border-color:#059669;font-weight:800;font-size:0.75rem;padding:4px 9px;border-radius:6px;display:inline-flex;align-items:center;gap:4px">
                        💵 <span>${isAR ? 'تحصيل وقفل' : 'Receive & Close'}</span>
                      </button>` : ''}

                      <!-- Action 2: Send & Close -->
                      ${!isDelivered && canSettle ? `
                      <button type="button" class="btn btn-sm" onclick="Deliveries.sendAndClose(${d.id})"
                        title="${isAR ? 'تسليم فوري مدفوع وقفل الطلب بعملية واحدة' : 'Send delivery & receive payment immediately in one operation'}"
                        style="background:#3b82f6;color:#fff;border-color:#2563eb;font-weight:800;font-size:0.75rem;padding:4px 9px;border-radius:6px;display:inline-flex;align-items:center;gap:4px">
                        🚀 <span>${isAR ? 'إرسال وقفل' : 'Send & Close'}</span>
                      </button>` : ''}

                      <!-- Print Receipt Copy -->
                      <button type="button" class="btn btn-ghost btn-sm" onclick="Deliveries.printDeliveryReceipt(${d.id})"
                        title="${isAR ? 'طباعة نسخة فاتورة التوصيل' : 'Print Delivery Invoice Copy'}"
                        style="font-size:0.78rem;padding:4px 8px;border-radius:6px">
                        🖨️
                      </button>

                    </div>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function setFilter(filter) {
    _activeFilter = filter;
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    
    // Update filter tab buttons UI
    document.querySelectorAll('#deliv-filter-tabs button').forEach(b => {
      b.classList.remove('btn-primary');
      b.classList.add('btn-ghost');
      b.style.background = '';
      b.style.borderColor = '';
      b.style.color = '';
    });
    
    const container = document.getElementById('deliv-table-container');
    if (container) container.innerHTML = renderTable(isAR);
  }

  function onSearch(query) {
    _searchQuery = query;
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const container = document.getElementById('deliv-table-container');
    if (container) container.innerHTML = renderTable(isAR);
  }

  async function updateStatus(deliveryId, newStatus) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    try {
      const del = await DB.get('deliveries', deliveryId);
      if (!del) return;
      del.delivery_status = newStatus;
      del.updated_at = new Date().toISOString();
      await DB.update('deliveries', del);

      // Also update linked sale
      if (del.sale_id) {
        const sale = await DB.get('sales', del.sale_id);
        if (sale) {
          sale.delivery_status = newStatus;
          await DB.update('sales', sale);
        }
      }

      Utils.toast(isAR ? `✅ تم تحديث حالة الطلب إلى: ${newStatus}` : `✅ Delivery status updated to: ${newStatus}`, 'success');
      await refresh();
    } catch (e) {
      console.error('updateStatus error:', e);
      Utils.toast(e.message, 'error');
    }
  }

  // ── Action 1: Receive Payment & Close ─────────────────────────────
  async function openReceivePaymentModal(deliveryId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const del = await DB.get('deliveries', deliveryId);
    if (!del) {
      Utils.toast(isAR ? 'لم يتم العثور على سجل التوصيل' : 'Delivery record not found', 'error');
      return;
    }

    const cur1 = window._primaryCurrency || 'USD';
    const cur2 = window._secondaryCurrency || 'LBP';
    const exchRate = window._exchangeRate || 89500;
    const totalVal = parseFloat(del.total) || 0;
    const paidVal = parseFloat(del.paid_amount) || 0;
    const remainingVal = Math.max(0, Utils.round(totalVal - paidVal));
    const remSecondary = remainingVal * exchRate;

    const modalSlot = document.getElementById('deliv-settle-modal-slot');
    if (!modalSlot) return;

    modalSlot.innerHTML = `
      <div class="modal-overlay open" id="deliv-settle-modal" style="display:flex;align-items:center;justify-content:center;z-index:99999">
        <div class="modal" style="max-width:520px;width:95vw;border-radius:14px;box-shadow:0 20px 50px rgba(0,0,0,0.5)">
          <div class="modal-header" style="padding:14px 20px;border-bottom:1.5px solid var(--border-color);display:flex;justify-content:space-between;align-items:center">
            <div style="font-size:1.1rem;font-weight:900;display:flex;align-items:center;gap:8px">
              <span>💵</span>
              <span>${isAR ? 'تحصيل المبلغ وقفل الطلب (عائد من التوصيل)' : 'Receive Payment & Close Delivery'}</span>
            </div>
            <button class="btn-icon" onclick="Deliveries.closeSettleModal()" style="font-size:1.2rem">✕</button>
          </div>
          <div class="modal-body" style="padding:18px 20px">
            
            <!-- Summary card -->
            <div style="background:var(--surface-2);border:1px solid var(--border-color);border-radius:10px;padding:12px 14px;margin-bottom:14px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <span style="font-size:0.8rem;color:var(--text-muted);font-weight:700">${isAR ? 'رقم الفاتورة:' : 'Invoice Ref:'}</span>
                <span style="font-weight:900;color:#ef4444"><bdi>${Utils.sanitize(del.invoice_no)}</bdi></span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <span style="font-size:0.8rem;color:var(--text-muted);font-weight:700">${isAR ? 'العميل:' : 'Customer:'}</span>
                <span style="font-weight:800;color:var(--text-primary)">${Utils.sanitize(del.customer_name)} (${Utils.sanitize(del.customer_phone || '-')})</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <span style="font-size:0.8rem;color:var(--text-muted);font-weight:700">${isAR ? 'العنوان:' : 'Address:'}</span>
                <span style="font-size:0.82rem;font-weight:700;color:var(--text-primary);max-width:260px;text-align:${isAR ? 'left' : 'right'}">${Utils.sanitize(del.delivery_address)}</span>
              </div>
              <div style="border-top:1px dashed var(--border-color);margin:8px 0;padding-top:8px;display:flex;justify-content:space-between;align-items:center">
                <span style="font-size:0.82rem;font-weight:700">${isAR ? 'إجمالي الفاتورة:' : 'Invoice Total:'}</span>
                <span style="font-weight:800">${cur1} ${Utils.formatCurrency(totalVal)}</span>
              </div>
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="font-size:0.82rem;font-weight:700">${isAR ? 'المسدد مسبقاً:' : 'Already Paid:'}</span>
                <span style="font-weight:800;color:#10b981">${cur1} ${Utils.formatCurrency(paidVal)}</span>
              </div>
              <div style="border-top:1.5px solid var(--border-color);margin:8px 0;padding-top:8px;display:flex;justify-content:space-between;align-items:center">
                <span style="font-size:0.95rem;font-weight:900;color:#ef4444">${isAR ? 'المتبقي للتحصيل من السائق:' : 'Remaining Due from Driver:'}</span>
                <span style="font-size:1.15rem;font-weight:900;color:#ef4444">${cur1} ${Utils.formatCurrency(remainingVal)}</span>
              </div>
            </div>

            <!-- Input for amount received -->
            <div class="form-group" style="margin-bottom:14px">
              <label class="form-label" style="font-weight:800;font-size:0.86rem">${isAR ? `المبلغ المستلم نقداً بالـ (${cur1}) *` : `Amount Received in (${cur1}) *`}</label>
              <input type="number" id="deliv-settle-amount" class="form-control" 
                value="${remainingVal.toFixed(2)}" step="0.01" min="0" max="${remainingVal.toFixed(2)}"
                style="font-size:1.3rem;font-weight:900;text-align:center;color:#10b981;height:48px;border-radius:8px">
              <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;text-align:center">
                ≈ ${Math.round(remSecondary).toLocaleString()} ${cur2} (${isAR ? 'سعر الصرف' : 'Rate'}: ${exchRate.toLocaleString()})
              </div>
            </div>

            <div class="form-group" style="margin-bottom:14px">
              <label class="form-label" style="font-weight:700;font-size:0.82rem">${isAR ? 'ملاحظات التحصيل (اختياري)' : 'Settlement Notes (optional)'}</label>
              <input type="text" id="deliv-settle-notes" class="form-control" placeholder="${isAR ? 'مثال: استلم الكاشير المبلغ بالكامل من السائق' : 'e.g. Full cash collected by driver'}" style="font-size:0.85rem">
            </div>

            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.25);border-radius:8px;padding:9px 12px;font-size:0.78rem;color:var(--text-primary);line-height:1.4">
              ℹ️ <strong>${isAR ? 'الأثر المالي:' : 'Accounting Notice:'}</strong> ${isAR ? 'سيتم تسجيل المبلغ في الصندوق النقدي فوراً وتحديث رصيد الفاتورة إلى مسددة وإغلاق التوصيل. لن يتم خصم المخزون مرة أخرى.' : 'Payment will immediately update the cash register, mark the original invoice paid, and close the delivery. Stock will NOT be deducted again.'}
            </div>

          </div>
          <div class="modal-footer" style="padding:14px 20px;border-top:1.5px solid var(--border-color);display:flex;justify-content:flex-end;gap:10px">
            <button type="button" class="btn btn-ghost" onclick="Deliveries.closeSettleModal()">${isAR ? 'إلغاء' : 'Cancel'}</button>
            <button type="button" class="btn btn-success" onclick="Deliveries.confirmReceivePayment(${del.id})" style="font-weight:900;background:#10b981;border-color:#059669;padding:8px 18px">
              ✅ <span>${isAR ? 'تأكيد القبض وإغلاق الطلب' : 'Confirm & Close Delivery'}</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  function closeSettleModal() {
    const slot = document.getElementById('deliv-settle-modal-slot');
    if (slot) slot.innerHTML = '';
  }

  async function confirmReceivePayment(deliveryId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    try {
      const del = await DB.get('deliveries', deliveryId);
      if (!del) throw new Error('Delivery record not found');

      // Duplicate payment protection
      if (del.payment_status === 'paid' && del.delivery_status === 'delivered') {
        Utils.toast(isAR ? '⚠️ هذه الفاتورة مسددة ومغلقة مسبقاً' : '⚠️ This delivery is already settled and closed', 'warning');
        closeSettleModal();
        return;
      }

      const inputAmount = parseFloat(document.getElementById('deliv-settle-amount')?.value) || 0;
      if (inputAmount <= 0) {
        Utils.toast(isAR ? 'يرجى إدخال مبلغ صحيح' : 'Please enter a valid payment amount', 'error');
        return;
      }

      const user = Auth.getUser();
      const cashierName = user?.full_name || user?.username || 'Cashier';
      const notes = document.getElementById('deliv-settle-notes')?.value.trim() || '';

      const totalVal = parseFloat(del.total) || 0;
      const prevPaid = parseFloat(del.paid_amount) || 0;
      const newPaid = Utils.round(prevPaid + inputAmount);
      const newRemaining = Math.max(0, Utils.round(totalVal - newPaid));
      const newPayStatus = (newRemaining <= 0.001) ? 'paid' : 'partial';

      // 1. Update linked Sale record in 'sales' table (without touching inventory or re-deducting stock!)
      let linkedSale = null;
      if (del.sale_id) {
        linkedSale = await DB.get('sales', del.sale_id);
      }
      if (!linkedSale && del.invoice_no) {
        const allSales = await DB.getAll('sales') || [];
        linkedSale = allSales.find(s => s.ref === del.invoice_no);
      }

      if (linkedSale) {
        linkedSale.paid_amount = newPaid;
        linkedSale.status = (newPayStatus === 'paid') ? 'paid' : 'partial';
        linkedSale.delivery_payment_status = newPayStatus;
        linkedSale.delivery_status = 'delivered';
        linkedSale.settled_at = new Date().toISOString();
        linkedSale.settled_by = cashierName;
        await DB.update('sales', linkedSale);
      }

      // 2. Update CashBox cash register with the collected cash
      const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
      if (cb && typeof cb.recordSale === 'function') {
        await cb.recordSale(inputAmount, `Delivery Settlement #${del.invoice_no} (${del.customer_name})`);
      }

      // 3. Record in cash_transactions for financial audit
      try {
        const rcptRef = await DB.nextSeq('cash_transactions', 'DELIV-PAY-', 5);
        await DB.add('cash_transactions', {
          ref: rcptRef,
          type: 'receipt',
          date: new Date().toISOString(),
          amount: inputAmount,
          customer_id: del.customer_id || null,
          customer_name: del.customer_name,
          description: isAR 
            ? `تحصيل قيمة توصيل من السائق - فاتورة #${del.invoice_no}` 
            : `Delivery payment collected from driver - Invoice #${del.invoice_no}`,
          payment_method: 'cash',
          sale_id: del.sale_id || null,
          sale_ref: del.invoice_no
        });
      } catch (errTxn) {
        console.warn('Could not record in cash_transactions:', errTxn);
      }

      // 4. Update the delivery record
      del.paid_amount = newPaid;
      del.remaining_balance = newRemaining;
      del.payment_status = newPayStatus;
      del.delivery_status = 'delivered';
      del.delivered_at = new Date().toISOString();
      del.settled_at = new Date().toISOString();
      del.settled_by = cashierName;
      del.settle_notes = notes;
      del.updated_at = new Date().toISOString();
      await DB.update('deliveries', del);

      closeSettleModal();
      Utils.toast(isAR ? `✅ تم تحصيل ${inputAmount}$ بنجاح وإغلاق الطلب #${del.invoice_no}` : `✅ Received $${inputAmount.toFixed(2)} & closed delivery #${del.invoice_no}`, 'success');
      await refresh();
    } catch (e) {
      console.error('confirmReceivePayment error:', e);
      Utils.toast(e.message, 'error');
    }
  }

  // ── Action 2: Send & Close (Immediately Paid upon dispatch) ───────
  async function sendAndClose(deliveryId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    try {
      const del = await DB.get('deliveries', deliveryId);
      if (!del) throw new Error('Delivery record not found');

      if (del.delivery_status === 'delivered') {
        Utils.toast(isAR ? '⚠️ هذا الطلب مسلم ومغلق مسبقاً' : '⚠️ This delivery is already delivered and closed', 'warning');
        return;
      }

      const totalVal = parseFloat(del.total) || 0;
      const prevPaid = parseFloat(del.paid_amount) || 0;
      const unpaidDue = Math.max(0, Utils.round(totalVal - prevPaid));

      const user = Auth.getUser();
      const cashierName = user?.full_name || user?.username || 'Cashier';

      // If unpaid, record the payment against CashBox and original sale in one operation
      if (unpaidDue > 0) {
        const cb = window.CashBox || (typeof CashBox !== 'undefined' ? CashBox : null);
        if (cb && typeof cb.recordSale === 'function') {
          await cb.recordSale(unpaidDue, `Delivery Send & Close #${del.invoice_no} (${del.customer_name})`);
        }

        try {
          const rcptRef = await DB.nextSeq('cash_transactions', 'DELIV-PAY-', 5);
          await DB.add('cash_transactions', {
            ref: rcptRef,
            type: 'receipt',
            date: new Date().toISOString(),
            amount: unpaidDue,
            customer_id: del.customer_id || null,
            customer_name: del.customer_name,
            description: isAR 
              ? `سداد مباشر فوري عند الإرسال - توصيل #${del.invoice_no}` 
              : `Upfront payment on send - Delivery #${del.invoice_no}`,
            payment_method: 'cash',
            sale_id: del.sale_id || null,
            sale_ref: del.invoice_no
          });
        } catch (errTxn) {}
      }

      // Update linked Sale
      if (del.sale_id) {
        const sale = await DB.get('sales', del.sale_id);
        if (sale) {
          sale.paid_amount = totalVal;
          sale.status = 'paid';
          sale.delivery_payment_status = 'paid';
          sale.delivery_status = 'delivered';
          sale.settled_at = new Date().toISOString();
          sale.settled_by = cashierName;
          await DB.update('sales', sale);
        }
      }

      // Update delivery record
      del.paid_amount = totalVal;
      del.remaining_balance = 0;
      del.payment_status = 'paid';
      del.delivery_status = 'delivered';
      del.delivered_at = new Date().toISOString();
      del.settled_at = new Date().toISOString();
      del.settled_by = cashierName;
      del.updated_at = new Date().toISOString();
      await DB.update('deliveries', del);

      Utils.toast(isAR ? `✅ تم إرسال وقفل الطلب #${del.invoice_no} بنجاح` : `✅ Delivery #${del.invoice_no} sent & closed successfully`, 'success');
      await refresh();
    } catch (e) {
      console.error('sendAndClose error:', e);
      Utils.toast(e.message, 'error');
    }
  }

  // ── Preview & Print Invoice ──────────────────────────────────────
  async function previewInvoice(deliveryId) {
    try {
      const del = await DB.get('deliveries', deliveryId);
      if (!del) return;
      let sale = null;
      if (del.sale_id) sale = await DB.get('sales', del.sale_id);
      if (!sale && del.invoice_no) {
        const allSales = await DB.getAll('sales') || [];
        sale = allSales.find(s => s.ref === del.invoice_no);
      }

      if (sale && window.POS && typeof POS.showReceipt === 'function') {
        POS.showReceipt(sale);
      } else {
        await printDeliveryReceipt(deliveryId);
      }
    } catch (e) {
      console.error('previewInvoice error:', e);
    }
  }

  async function printDeliveryReceipt(deliveryId) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    try {
      const del = await DB.get('deliveries', deliveryId);
      if (!del) return;

      let sale = null;
      if (del.sale_id) sale = await DB.get('sales', del.sale_id);
      if (!sale && del.invoice_no) {
        const allSales = await DB.getAll('sales') || [];
        sale = allSales.find(s => s.ref === del.invoice_no);
      }

      // Synthetic sale if not found
      if (!sale) {
        sale = {
          ref: del.invoice_no,
          created_at: del.created_at,
          customer_name: del.customer_name,
          customer_phone: del.customer_phone,
          delivery_address: del.delivery_address,
          delivery_notes: del.delivery_notes,
          delivery_fee: del.delivery_fee,
          order_type: 'delivery',
          items: del.items,
          subtotal: del.subtotal,
          grand_total: del.total,
          paid_amount: del.paid_amount,
          amount_tendered: del.paid_amount,
          cashier: del.cashier
        };
      }

      // Ensure delivery details are attached
      sale.order_type = 'delivery';
      sale.delivery_address = del.delivery_address;
      sale.delivery_phone = del.customer_phone;
      sale.delivery_notes = del.delivery_notes;
      sale.delivery_fee = del.delivery_fee;
      sale.paid_amount = del.paid_amount;

      const items = typeof sale.items === 'string' ? JSON.parse(sale.items || '[]') : (sale.items || []);
      let cust = null;
      if (del.customer_id) {
        try { cust = await DB.get('customers', del.customer_id); } catch(e){}
      }
      if (!cust) {
        cust = { name_en: del.customer_name, name_ar: del.customer_name, phone: del.customer_phone, address: del.delivery_address };
      }

      if (window.PrintEngine && typeof PrintEngine.printReceipt === 'function') {
        await PrintEngine.printReceipt(sale, items, cust, { doc_title: isAR ? 'فاتورة توصيل' : 'DELIVERY INVOICE' });
      } else if (window.POS && typeof POS.generateReceiptHTML === 'function') {
        const html = await POS.generateReceiptHTML(sale);
        await Utils.printElement(`<div class="receipt-80mm" dir="${isAR ? 'rtl' : 'ltr'}">${html}</div>`, 'Delivery Invoice', '80mm');
      }
    } catch (e) {
      console.error('printDeliveryReceipt error:', e);
      Utils.toast(e.message, 'error');
    }
  }

  // ── Pending Deliveries Modal (For Quick Access directly inside POS Cockpit) ──
  let _lastPendingList = [];

  function renderPendingCardsHtml(list, isAR) {
    if (!list || !list.length) {
      return `
        <div style="text-align:center;padding:45px 15px;color:var(--text-muted)">
          <div style="font-size:2.8rem;margin-bottom:10px">🎉</div>
          <div style="font-weight:900;font-size:1.05rem;color:var(--success)">${isAR ? 'رائع! لا توجد طلبات توصيل معلقة حالياً' : 'All Deliveries Settled!'}</div>
          <div style="font-size:0.82rem;margin-top:6px">${isAR ? 'جميع فواتير التوصيل تم تسليمها وتسديد مبالغها بالكامل.' : 'No active deliveries currently on the road or pending payment.'}</div>
        </div>
      `;
    }

    const cur1 = 'USD';
    const cur2 = 'LBP';

    return list.map(del => {
      const isUnpaid = (del.payment_status === 'unpaid' || parseFloat(del.balance_due) > 0 || parseFloat(del.remaining_balance) > 0);
      const balDue = (parseFloat(del.balance_due) !== undefined && parseFloat(del.balance_due) > 0)
        ? parseFloat(del.balance_due)
        : (parseFloat(del.remaining_balance) || parseFloat(del.total_c1) || 0);

      const statusBadge = isUnpaid
        ? `<span style="background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid rgba(239,68,68,0.3);padding:3px 9px;border-radius:20px;font-size:0.75rem;font-weight:900">⚠️ ${isAR ? 'دفع عند الاستلام (غير مسدد)' : 'Unpaid COD'} — ${balDue.toFixed(2)}$</span>`
        : `<span style="background:rgba(16,185,129,0.15);color:#10b981;border:1px solid rgba(16,185,129,0.3);padding:3px 9px;border-radius:20px;font-size:0.75rem;font-weight:900">✅ ${isAR ? 'مسددة بالكامل' : 'Paid'}</span>`;

      let deliveryBadge = `<span style="background:rgba(245,158,11,0.15);color:#f59e0b;padding:3px 8px;border-radius:6px;font-size:0.72rem;font-weight:800">${isAR ? 'قيد التوصيل 🛵' : 'Out for Delivery 🛵'}</span>`;
      if (del.delivery_status === 'delivered') {
        deliveryBadge = `<span style="background:rgba(16,185,129,0.15);color:#10b981;padding:3px 8px;border-radius:6px;font-size:0.72rem;font-weight:800">${isAR ? 'تم التسليم ✔️' : 'Delivered ✔️'}</span>`;
      }

      return `
        <div style="background:var(--surface-1);border:1.5px solid var(--border-color);border-radius:10px;padding:12px 16px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:12px;transition:all 0.15s">
          <div style="flex:1;min-width:260px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
              <span style="font-weight:900;font-size:0.95rem;color:var(--primary);cursor:pointer" onclick="Deliveries.previewInvoice(${del.id})" title="${isAR ? 'عرض الفاتورة' : 'View Invoice'}">
                #${del.invoice_no}
              </span>
              <span style="font-size:0.72rem;color:var(--text-muted)">⏰ ${Utils.formatDateTime(del.created_at)}</span>
              ${deliveryBadge}
              ${statusBadge}
            </div>

            <div style="display:flex;align-items:center;gap:12px;margin:6px 0 4px;flex-wrap:wrap">
              <span style="font-weight:800;font-size:0.9rem;color:var(--text-primary)">
                👤 ${Utils.sanitize(del.customer_name || (isAR ? 'عميل عابر' : 'Walk-in'))}
              </span>
              ${del.customer_phone ? `
                <a href="tel:${del.customer_phone}" style="font-size:0.82rem;font-weight:700;color:var(--primary);text-decoration:none" dir="ltr">
                  📞 ${Utils.sanitize(del.customer_phone)}
                </a>
              ` : ''}
              ${parseFloat(del.delivery_fee) > 0 ? `
                <span style="font-size:0.75rem;color:#f59e0b;font-weight:800">
                  + أجرة التوصيل: $${parseFloat(del.delivery_fee).toFixed(2)}
                </span>
              ` : ''}
            </div>

            <div style="font-size:0.8rem;color:var(--text-muted);display:flex;align-items:center;gap:6px">
              <span>📍</span> <span>${Utils.sanitize(del.delivery_address || (isAR ? 'العنوان غير محدد' : 'No address specified'))}</span>
              ${del.delivery_notes ? ` | <span style="font-style:italic">"${Utils.sanitize(del.delivery_notes)}"</span>` : ''}
            </div>
          </div>

          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <div style="text-align:${isAR ? 'left' : 'right'};margin-inline-end:6px">
              <div style="font-size:1.15rem;font-weight:900;color:var(--text-primary)">
                $${(parseFloat(del.total_c1) || 0).toFixed(2)}
              </div>
              ${del.total_c2 ? `
                <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">
                  ${Math.round(del.total_c2).toLocaleString()} LBP
                </div>
              ` : ''}
            </div>

            <div style="display:flex;align-items:center;gap:6px">
              ${isUnpaid ? `
                <button type="button" class="btn btn-sm btn-success" onclick="Deliveries.openReceivePaymentModal(${del.id})" style="font-weight:900;display:inline-flex;align-items:center;gap:4px;padding:6px 12px">
                  <span>💰</span> <span>${isAR ? 'تحصيل المبلغ وإغلاق' : 'Receive & Settle'}</span>
                </button>
              ` : `
                <button type="button" class="btn btn-sm btn-primary" onclick="Deliveries.sendAndClose(${del.id})" style="font-weight:800;display:inline-flex;align-items:center;gap:4px;padding:6px 12px">
                  <span>🚀</span> <span>${isAR ? 'إرسال وإنهاء' : 'Send & Close'}</span>
                </button>
              `}
              <button type="button" class="btn btn-sm btn-secondary" onclick="Deliveries.printDeliveryReceipt(${del.id})" title="${isAR ? 'طباعة نسخة إيصال التوصيل' : 'Print Delivery Receipt'}" style="padding:6px 10px">
                🖨️
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  async function openPendingModal() {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    _deliveries = await DB.getAll('deliveries') || [];
    _deliveries.sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));

    // Active deliveries: not yet delivered, or unpaid
    _lastPendingList = _deliveries.filter(d => d.delivery_status !== 'delivered' || d.payment_status === 'unpaid' || (parseFloat(d.balance_due) > 0) || (parseFloat(d.remaining_balance) > 0));
    const unpaidCount = _lastPendingList.filter(d => d.payment_status === 'unpaid' || (parseFloat(d.balance_due) > 0) || (parseFloat(d.remaining_balance) > 0)).length;
    const unpaidSum = _lastPendingList.filter(d => d.payment_status === 'unpaid' || (parseFloat(d.balance_due) > 0) || (parseFloat(d.remaining_balance) > 0))
      .reduce((s, d) => s + (parseFloat(d.balance_due) || parseFloat(d.remaining_balance) || parseFloat(d.total_c1) || 0), 0);

    let modalEl = document.getElementById('modal-pending-deliveries');
    if (!modalEl) {
      modalEl = document.createElement('div');
      modalEl.id = 'modal-pending-deliveries';
      modalEl.className = 'modal-overlay';
      modalEl.style.zIndex = '99999';
      modalEl.onclick = (e) => { if (e.target === modalEl) closePendingModal(); };
      document.body.appendChild(modalEl);
    }

    modalEl.innerHTML = `
      <div class="modal-dialog animate-scale" style="max-width:880px;width:96%;max-height:90vh;display:flex;flex-direction:column;background:var(--surface-1, #1e293b);color:var(--text-primary, #f8fafc);border:1.5px solid var(--border-color, #334155);border-radius:14px;box-shadow:0 24px 60px rgba(0,0,0,0.7);overflow:hidden" onclick="event.stopPropagation()">
        
        <!-- Header -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 20px;border-bottom:1px solid var(--border-color);background:rgba(245,158,11,0.08)">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:1.6rem">🛵</span>
            <div>
              <h2 style="margin:0;font-size:1.15rem;font-weight:900;color:#f59e0b">
                ${isAR ? 'طلبات التوصيل المعلقة والتحصيل (Pending Deliveries)' : 'Pending Deliveries & Settle'}
              </h2>
              <div style="font-size:0.78rem;color:var(--text-muted)">
                ${isAR ? 'متابعة الطلبات المفتوحة في الطريق، وتحصيل مبالغ الدفع عند الاستلام (COD)' : 'Track open deliveries on the road, collect COD cash, and close orders'}
              </div>
            </div>
          </div>
          <button type="button" class="btn-icon" onclick="Deliveries.closePendingModal()" style="font-size:1.2rem;cursor:pointer">✕</button>
        </div>

        <!-- Metrics Strip -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:12px;padding:12px 20px;background:var(--surface-2);border-bottom:1px solid var(--border-color)">
          <div style="display:flex;align-items:center;gap:10px;background:var(--surface-1);padding:10px 14px;border-radius:8px;border:1px solid var(--border-color)">
            <span style="font-size:1.5rem">📦</span>
            <div>
              <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'طلبات قيد التوصيل والمتابعة:' : 'Active Deliveries:'}</div>
              <div style="font-size:1.15rem;font-weight:900;color:var(--primary)">${_lastPendingList.length}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;background:var(--surface-1);padding:10px 14px;border-radius:8px;border:1px solid var(--border-color)">
            <span style="font-size:1.5rem">⚠️</span>
            <div>
              <div style="font-size:0.75rem;color:var(--text-muted);font-weight:700">${isAR ? 'غير مسددة (COD تحصيل السائق):' : 'Unpaid COD Due:'}</div>
              <div style="font-size:1.15rem;font-weight:900;color:#ef4444">${unpaidCount} <span style="font-size:0.85rem">($${unpaidSum.toFixed(2)})</span></div>
            </div>
          </div>
        </div>

        <!-- Search Bar -->
        <div style="padding:10px 20px;border-bottom:1px solid var(--border-color);display:flex;gap:10px;align-items:center">
          <input type="text" id="pending-deliv-search" class="form-control" 
            placeholder="${isAR ? '🔍 ابحث برقم الفاتورة، اسم العميل، الهاتف، أو العنوان...' : '🔍 Search by invoice #, customer name, phone, or address...'}"
            oninput="Deliveries.filterPendingModalList(this.value)"
            style="font-size:0.85rem;height:36px;border-radius:8px;background:var(--surface-2)">
          <button class="btn btn-secondary btn-sm" onclick="Deliveries.openPendingModal()" title="${isAR ? 'تحديث' : 'Refresh'}" style="height:36px;padding:0 12px">
            🔄
          </button>
        </div>

        <!-- Orders List Body (Scrollable) -->
        <div id="pending-deliv-list-container" style="padding:14px 20px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:10px">
          ${renderPendingCardsHtml(_lastPendingList, isAR)}
        </div>

        <!-- Footer -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 20px;border-top:1px solid var(--border-color);background:var(--surface-2)">
          <button type="button" class="btn btn-outline-primary btn-sm" onclick="Deliveries.closePendingModal(); App.navigate('deliveries')" style="font-weight:800;display:flex;align-items:center;gap:6px">
            📂 <span>${isAR ? 'عرض الشاشة الكاملة للتوصيل' : 'Open Full Deliveries Dashboard'}</span>
          </button>
          <button type="button" class="btn btn-secondary btn-sm" onclick="Deliveries.closePendingModal()" style="font-weight:700">
            ${isAR ? 'إغلاق' : 'Close'}
          </button>
        </div>

      </div>
    `;

    modalEl.style.display = 'flex';
    modalEl.classList.add('open');
    updateSidebarBadge();
  }

  function closePendingModal() {
    const modalEl = document.getElementById('modal-pending-deliveries');
    if (modalEl) {
      modalEl.classList.remove('open');
      modalEl.style.display = 'none';
    }
  }

  function filterPendingModalList(query) {
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const q = (query || '').toLowerCase().trim();
    const container = document.getElementById('pending-deliv-list-container');
    if (!container) return;

    if (!q) {
      container.innerHTML = renderPendingCardsHtml(_lastPendingList, isAR);
      return;
    }

    const filtered = _lastPendingList.filter(d => {
      const inv = (d.invoice_no || '').toLowerCase();
      const name = (d.customer_name || '').toLowerCase();
      const phone = (d.customer_phone || '').toLowerCase();
      const addr = (d.delivery_address || '').toLowerCase();
      return inv.includes(q) || name.includes(q) || phone.includes(q) || addr.includes(q);
    });

    container.innerHTML = renderPendingCardsHtml(filtered, isAR);
  }

  async function updateSidebarBadge() {
    try {
      const all = await DB.getAll('deliveries') || [];
      const pendingCount = all.filter(d => d.delivery_status !== 'delivered' || d.payment_status === 'unpaid' || (parseFloat(d.balance_due) > 0) || (parseFloat(d.remaining_balance) > 0)).length;
      
      const badge = document.getElementById('sidebar-deliveries-badge');
      if (badge) {
        if (pendingCount > 0) {
          badge.textContent = pendingCount;
          badge.style.display = 'inline-block';
        } else {
          badge.style.display = 'none';
        }
      }

      const topBadge = document.getElementById('topbar-deliveries-count-badge');
      if (topBadge) {
        if (pendingCount > 0) {
          topBadge.textContent = pendingCount;
          topBadge.style.display = 'inline-block';
        } else {
          topBadge.style.display = 'none';
        }
      }

      const cartBadge = document.getElementById('pos-cart-deliv-badge');
      if (cartBadge) {
        if (pendingCount > 0) {
          cartBadge.textContent = pendingCount;
          cartBadge.style.display = 'inline-block';
        } else {
          cartBadge.style.display = 'none';
        }
      }
    } catch(e) {}
  }

  async function refresh() {
    _deliveries = await DB.getAll('deliveries') || [];
    _deliveries.sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));
    const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
    const container = document.getElementById('deliv-table-container');
    if (container) container.innerHTML = renderTable(isAR);
    updateSidebarBadge();

    // If pending modal is currently open, refresh it as well
    const pendingModal = document.getElementById('modal-pending-deliveries');
    if (pendingModal && pendingModal.style.display === 'flex') {
      _lastPendingList = _deliveries.filter(d => d.delivery_status !== 'delivered' || d.payment_status === 'unpaid' || (parseFloat(d.balance_due) > 0) || (parseFloat(d.remaining_balance) > 0));
      const pContainer = document.getElementById('pending-deliv-list-container');
      if (pContainer) pContainer.innerHTML = renderPendingCardsHtml(_lastPendingList, isAR);
    }
  }

  return {
    render,
    setFilter,
    onSearch,
    updateStatus,
    openReceivePaymentModal,
    closeSettleModal,
    confirmReceivePayment,
    sendAndClose,
    previewInvoice,
    printDeliveryReceipt,
    refresh,
    updateSidebarBadge,
    openPendingModal,
    closePendingModal,
    filterPendingModalList
  };
})();

window.Deliveries = Deliveries;
