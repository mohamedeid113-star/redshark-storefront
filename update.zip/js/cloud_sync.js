/* ================================================================
   RedShark POS — Supabase Cloud Multi-Tenant Sync Engine
   ================================================================ */

const CloudSync = (() => {
  const SUPABASE_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
  const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";

  function getHeaders() {
    return {
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation"
    };
  }

  // Resiliently resolve active tenant ID from session, DB settings, or localStorage
  async function getTenantId() {
    let tenantId = null;
    const session = sessionStorage.getItem('nexpos_session');
    if (session) {
      try {
        const s = JSON.parse(session);
        if (s && s.tenant_id) tenantId = s.tenant_id;
      } catch (e) {}
    }
    if (!tenantId && typeof DB !== 'undefined') {
      try {
        tenantId = await DB.getSetting('tenant_id', null);
      } catch (e) {}
    }
    if (!tenantId) {
      tenantId = localStorage.getItem('redshark_active_tenant_id') || localStorage.getItem('redshark_tenant_id');
    }
    return tenantId;
  }

  // Authenticate across devices via Supabase
  async function cloudAuthenticate(username, password) {
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/tenant_users?username=eq.${encodeURIComponent(username)}&select=*,tenants(*)`, {
        headers: getHeaders()
      });
      if (!res.ok) return null;
      const users = await res.json();
      if (!users || users.length === 0) return null;

      const user = users.find(u => u.password_hash === password || u.password_hash === String(password));
      if (!user) return null;

      const tenant = user.tenants;
      const tenantId = user.tenant_id || (tenant ? tenant.id : null);
      if (tenantId) {
        localStorage.setItem('redshark_active_tenant_id', tenantId);
        localStorage.setItem('redshark_tenant_id', tenantId);
      }

      return {
        user: {
          id: user.id,
          tenant_id: tenantId,
          username: user.username,
          full_name: user.full_name || (tenant ? tenant.shop_name + ' Admin' : 'Admin'),
          role: user.role || 'demo',
          status: 'active'
        },
        tenant: tenant
      };
    } catch (e) {
      console.warn('Cloud Auth lookup error:', e);
      return null;
    }
  }

  const CATEGORY_CATALOG = {
    'Fruits & Vegetables': {
      name_en: 'Fruits & Vegetables',
      name_ar: 'خضار وفواكه',
      image: 'assets/categories/fruits_vegetables.jpg',
      sort_order: 1
    },
    'Dairy & Cheese': {
      name_en: 'Dairy & Cheese',
      name_ar: 'ألبان وأجبان',
      image: 'assets/categories/dairy_cheese.jpg',
      sort_order: 2
    },
    'Bakery & Pastry': {
      name_en: 'Bakery & Pastry',
      name_ar: 'مخبوزات وحلويات',
      image: 'assets/categories/bakery_pastry.jpg',
      sort_order: 3
    },
    'Beverages & Coffee': {
      name_en: 'Beverages & Coffee',
      name_ar: 'مشروبات وقهوة',
      image: 'assets/categories/beverages_coffee.jpg',
      sort_order: 4
    },
    'Meats & Poultry': {
      name_en: 'Meats & Poultry',
      name_ar: 'لحوم ودواجن',
      image: 'assets/categories/meats_poultry.jpg',
      sort_order: 5
    },
    'Snacks & Sweets': {
      name_en: 'Snacks & Sweets',
      name_ar: 'سناكس وتسالي',
      image: 'assets/categories/snacks_sweets.jpg',
      sort_order: 6
    }
  };

  // Download items and sales from cloud to local IndexedDB
  async function pullTenantData(tenantId, slug) {
    if (!tenantId) tenantId = await getTenantId();
    if (!tenantId) return;

    try {
      // 1. Fetch Items
      const itemsRes = await fetch(`${SUPABASE_URL}/rest/v1/tenant_items?tenant_id=eq.${encodeURIComponent(tenantId)}&select=*`, {
        headers: getHeaders()
      });
      if (itemsRes.ok) {
        const cloudItems = await itemsRes.json();
        if (cloudItems && cloudItems.length > 0 && typeof DB !== 'undefined') {
          // Sync or create Categories in IndexedDB
          const existingCats = (await DB.getAll('categories')) || [];
          const catMapByName = new Map();
          existingCats.forEach(c => {
            if (c.name) catMapByName.set(c.name.toLowerCase().trim(), c);
            if (c.name_en) catMapByName.set(c.name_en.toLowerCase().trim(), c);
            if (c.name_ar) catMapByName.set(c.name_ar.toLowerCase().trim(), c);
          });

          // Ensure catalog categories exist with images
          for (const [catKey, catalogEntry] of Object.entries(CATEGORY_CATALOG)) {
            const lowerKey = catKey.toLowerCase().trim();
            const lowerEn = catalogEntry.name_en.toLowerCase().trim();
            const lowerAr = catalogEntry.name_ar.toLowerCase().trim();
            let matchedCat = catMapByName.get(lowerKey) || catMapByName.get(lowerEn) || catMapByName.get(lowerAr);

            if (!matchedCat) {
              const newCat = {
                name: catalogEntry.name_en,
                name_en: catalogEntry.name_en,
                name_ar: catalogEntry.name_ar,
                parent_id: null,
                sort_order: catalogEntry.sort_order,
                image: catalogEntry.image
              };
              const newId = await DB.add('categories', newCat);
              newCat.id = newId;
              catMapByName.set(lowerKey, newCat);
              catMapByName.set(lowerEn, newCat);
              catMapByName.set(lowerAr, newCat);
            } else {
              // Update category with image if missing
              if (!matchedCat.image || matchedCat.image !== catalogEntry.image) {
                matchedCat.image = catalogEntry.image;
                if (!matchedCat.name_ar) matchedCat.name_ar = catalogEntry.name_ar;
                if (!matchedCat.name_en) matchedCat.name_en = catalogEntry.name_en;
                await DB.update('categories', matchedCat);
              }
            }
          }

          // Process unique category names from cloudItems
          const cloudCatNames = [...new Set(cloudItems.map(ci => (ci.category || 'General').trim()))];
          for (const catName of cloudCatNames) {
            const lower = catName.toLowerCase().trim();
            if (!catMapByName.has(lower)) {
              const catalogEntry = CATEGORY_CATALOG[catName] || {};
              const newCat = {
                name: catalogEntry.name_en || catName,
                name_en: catalogEntry.name_en || catName,
                name_ar: catalogEntry.name_ar || catName,
                parent_id: null,
                sort_order: catalogEntry.sort_order || (existingCats.length + 1),
                image: catalogEntry.image || ''
              };
              const newId = await DB.add('categories', newCat);
              newCat.id = newId;
              catMapByName.set(lower, newCat);
            }
          }

          for (const ci of cloudItems) {
            const catName = (ci.category || 'General').trim();
            const matchedCat = catMapByName.get(catName.toLowerCase());
            const catId = matchedCat ? matchedCat.id : null;
            const isScale = (ci.unit === 'kg' || ci.unit === 'g');

            await DB.put('items', {
              id: ci.id,
              name: ci.name_en || ci.name_ar || 'Item',
              name_ar: ci.name_ar || '',
              name_en: ci.name_en || '',
              barcode: ci.barcode || '',
              item_code: ci.item_code || '',
              category: ci.category || 'General',
              category_id: catId,
              price: parseFloat(ci.selling_price) || 0,
              selling_price: parseFloat(ci.selling_price) || 0,
              cost: parseFloat(ci.cost_price) || 0,
              cost_price: parseFloat(ci.cost_price) || 0,
              stock: parseFloat(ci.stock_qty) || 0,
              stock_qty: parseFloat(ci.stock_qty) || 0,
              unit: ci.unit || 'pcs',
              is_scale: isScale
            });
          }

          // If POS or Categories screen is currently active, refresh category cards and grid
          try {
            if (typeof POS !== 'undefined' && document.getElementById('pos-items-grid')) {
              const cats = await DB.getAll('categories');
              const isAR = (window.i18n && typeof i18n.getLang === 'function') ? i18n.getLang() === 'ar' : false;
              if (document.getElementById('pos-items-grid') && typeof POS.showCategories === 'function') {
                POS.showCategories();
              }
            }
          } catch (uiErr) {}
        }
      }

      // 2. Fetch Sales
      const salesRes = await fetch(`${SUPABASE_URL}/rest/v1/tenant_sales?tenant_id=eq.${encodeURIComponent(tenantId)}&select=*&order=created_at.desc&limit=100`, {
        headers: getHeaders()
      });
      if (salesRes.ok) {
        const cloudSales = await salesRes.json();
        if (cloudSales && cloudSales.length > 0 && typeof DB !== 'undefined') {
          for (const cs of cloudSales) {
            await DB.put('sales', {
              id: cs.id,
              ref: cs.ref,
              customer_name: cs.customer_name,
              items: cs.items || [],
              subtotal: parseFloat(cs.subtotal) || 0,
              discount: parseFloat(cs.discount) || 0,
              total: parseFloat(cs.grand_total) || 0,
              payment_method: cs.payment_method || 'cash',
              created_at: cs.created_at
            });
          }
        }
      }
    } catch (e) {
      console.warn('Pull tenant cloud data error:', e);
    }
  }

  // Push local Item to Supabase
  async function pushItem(item) {
    try {
      const tenantId = await getTenantId();
      if (!tenantId) return;

      const payload = {
        tenant_id: tenantId,
        item_code: item.item_code || String(item.id || ''),
        barcode: item.barcode || '',
        name_en: item.name_en || item.name || '',
        name_ar: item.name_ar || item.name || '',
        category: item.category || 'General',
        selling_price: parseFloat(item.price) || 0,
        cost_price: parseFloat(item.cost) || 0,
        stock_qty: parseFloat(item.stock_qty ?? item.stock ?? 0) || 0,
        unit: item.unit || 'pcs'
      };

      await fetch(`${SUPABASE_URL}/rest/v1/tenant_items`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
    } catch (e) {
      console.warn('Push item error:', e);
    }
  }

  // Push local Sale to Supabase
  async function pushSale(sale) {
    try {
      const tenantId = await getTenantId();
      if (!tenantId) return;

      const payload = {
        tenant_id: tenantId,
        ref: sale.ref || ('INV-' + Date.now()),
        customer_name: sale.customer_name || 'Walk-in Customer',
        items: sale.items || [],
        subtotal: parseFloat(sale.subtotal || sale.total) || 0,
        discount: parseFloat(sale.discount) || 0,
        grand_total: parseFloat(sale.total || sale.grand_total) || 0,
        payment_method: sale.payment_method || 'cash'
      };

      await fetch(`${SUPABASE_URL}/rest/v1/tenant_sales`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
    } catch (e) {
      console.warn('Push sale error:', e);
    }
  }

  // Push all existing local items that might not be synced to Supabase yet
  async function syncAllLocalItems() {
    try {
      const tenantId = await getTenantId();
      if (!tenantId || typeof DB === 'undefined') return;

      const localItems = await DB.getAll('items');
      if (!localItems || !localItems.length) return;

      const res = await fetch(`${SUPABASE_URL}/rest/v1/tenant_items?tenant_id=eq.${encodeURIComponent(tenantId)}&select=barcode,item_code,name_en`, {
        headers: getHeaders()
      });
      const cloudList = res.ok ? await res.json() : [];
      const cloudCodes = new Set(cloudList.map(c => c.barcode || c.item_code || c.name_en));

      for (const it of localItems) {
        const key = it.barcode || it.item_code || it.name_en || it.name;
        if (!cloudCodes.has(key)) {
          await pushItem(it);
        }
      }
    } catch (e) {
      console.warn('syncAllLocalItems error:', e);
    }
  }

  return {
    getTenantId,
    cloudAuthenticate,
    pullTenantData,
    pushItem,
    pushSale,
    syncAllLocalItems
  };
})();

if (typeof window !== 'undefined') {
  window.CloudSync = CloudSync;
}
