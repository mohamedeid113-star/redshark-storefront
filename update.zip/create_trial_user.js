/**
 * Red Shark POS — Instant Cloud Trial User Creator & Manager
 * 
 * Allows creating cloud demo trial accounts for clients who don't have Gmail / Email,
 * without requiring email OTP verification.
 * 
 * Usage:
 *   node create_trial_user.js "<ShopName>" "<Username>" "<Password>" [days=7] [phone] [mode=retail|restaurant]
 *   node create_trial_user.js --list
 *   node create_trial_user.js --extend <username> <additionalDays>
 */

const SUPABASE_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";

const headers = {
  "apikey": SUPABASE_KEY,
  "Authorization": `Bearer ${SUPABASE_KEY}`,
  "Content-Type": "application/json",
  "Prefer": "return=representation"
};

async function listTrialUsers() {
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/tenants?select=id,shop_name,slug,owner_phone,owner_email,trial_expires_at,is_active,tenant_users(username,role)&order=created_at.desc&limit=25`, {
      headers
    });
    if (!res.ok) throw new Error(await res.text());
    const tenants = await res.json();
    
    console.log('\n===============================================================');
    console.log('       📋 Active Cloud Trial Tenants & Users');
    console.log('===============================================================');
    const now = new Date();
    tenants.forEach((t, i) => {
      const exp = t.trial_expires_at ? new Date(t.trial_expires_at) : null;
      const isExpired = exp ? exp < now : false;
      const daysLeft = exp ? Math.ceil((exp - now) / (1000 * 60 * 60 * 24)) : 0;
      const userList = (t.tenant_users || []).map(u => u.username).join(', ') || 'no user';

      console.log(`${i + 1}. [${t.shop_name}] (Username: ${userList})`);
      console.log(`   📱 Phone: ${t.owner_phone || '-'} | ✉️ ${t.owner_email || '-'}`);
      console.log(`   ⏳ Status: ${isExpired ? '❌ EXPIRED' : `✅ ACTIVE (${daysLeft} days left, until ${exp.toISOString().split('T')[0]})`}`);
      console.log('---------------------------------------------------------------');
    });
  } catch (err) {
    console.error('Failed to list trial users:', err.message);
  }
}

async function extendTrial(username, days) {
  if (!username || !days) {
    console.log('Usage: node create_trial_user.js --extend <username> <additionalDays>');
    return;
  }
  const addDays = parseInt(days, 10);
  if (isNaN(addDays) || addDays <= 0) {
    console.log('Error: additionalDays must be a positive integer.');
    return;
  }

  try {
    const userRes = await fetch(`${SUPABASE_URL}/rest/v1/tenant_users?username=eq.${encodeURIComponent(username.trim())}&select=*,tenants(*)`, {
      headers
    });
    const users = await userRes.json();
    if (!users || users.length === 0) {
      console.log(`❌ No user found with username: "${username}"`);
      return;
    }
    const tenant = users[0].tenants;
    if (!tenant) {
      console.log(`❌ No tenant linked to username: "${username}"`);
      return;
    }

    const currentExpiry = tenant.trial_expires_at ? new Date(tenant.trial_expires_at) : new Date();
    const baseTime = currentExpiry > new Date() ? currentExpiry : new Date();
    const newExpiry = new Date(baseTime.getTime() + addDays * 24 * 60 * 60 * 1000).toISOString();

    const updateRes = await fetch(`${SUPABASE_URL}/rest/v1/tenants?id=eq.${tenant.id}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ trial_expires_at: newExpiry, is_active: true })
    });

    if (updateRes.ok) {
      console.log(`\n===============================================================`);
      console.log(`✅ Trial Extended Successfully for "${username}"!`);
      console.log(`   Shop Name: ${tenant.shop_name}`);
      console.log(`   Added    : +${addDays} Days`);
      console.log(`   New Expiry: ${newExpiry.split('T')[0]}`);
      console.log(`===============================================================\n`);
    } else {
      console.error('Update failed:', await updateRes.text());
    }
  } catch (err) {
    console.error('Failed to extend trial:', err.message);
  }
}

async function createTrialUser(shopName, username, password, days = 7, phone = '', mode = 'retail') {
  if (!shopName || !username || !password) {
    console.log('\n❌ Missing required parameters.');
    console.log('Usage:');
    console.log('  node create_trial_user.js "<ShopName>" "<Username>" "<Password>" [days] [phone] [mode]\n');
    console.log('Example:');
    console.log('  node create_trial_user.js "City Supermarket" "citymarket" "123456" 7 "70123456" "retail"');
    console.log('  node create_trial_user.js --list');
    console.log('  node create_trial_user.js --extend citymarket 14\n');
    return;
  }

  const cleanShop = shopName.trim();
  const cleanUser = username.trim().toLowerCase();
  const cleanPass = password.trim();
  const trialDays = parseInt(days, 10) || 7;
  const cleanPhone = (phone || '').trim();
  const bType = (mode && mode.toLowerCase() === 'restaurant') ? 'restaurant' : 'retail';

  console.log(`\n⏳ Creating trial account for "${cleanShop}" (${cleanUser})...`);

  // Check if username already exists
  try {
    const existRes = await fetch(`${SUPABASE_URL}/rest/v1/tenant_users?username=eq.${encodeURIComponent(cleanUser)}&select=id`, {
      headers
    });
    const existing = await existRes.json();
    if (existing && existing.length > 0) {
      console.log(`\n❌ Error: The username "${cleanUser}" is already taken!`);
      console.log(`👉 Please choose another username (e.g. ${cleanUser}2 or ${cleanUser}pos).\n`);
      return;
    }
  } catch (err) {}

  const now = new Date();
  const trialExpiry = new Date(now.getTime() + trialDays * 24 * 60 * 60 * 1000).toISOString();
  const slug = cleanUser.replace(/[^a-z0-9]/g, '_') + '_' + Math.floor(1000 + Math.random() * 9000);
  const fallbackEmail = `${cleanUser}@trial.redsharkpos.com`;

  // 1. Create Tenant
  try {
    const tenantRes = await fetch(`${SUPABASE_URL}/rest/v1/tenants`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        shop_name: cleanShop,
        slug: slug,
        owner_phone: cleanPhone || null,
        owner_email: fallbackEmail,
        currency: 'USD',
        business_type: bType,
        trial_expires_at: trialExpiry,
        is_active: true
      })
    });

    if (!tenantRes.ok) {
      console.error('Failed to create tenant:', await tenantRes.text());
      return;
    }

    const tenantData = await tenantRes.json();
    const tenant = tenantData[0];
    const tenantId = tenant.id;

    // 2. Create User
    const userRes = await fetch(`${SUPABASE_URL}/rest/v1/tenant_users`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        tenant_id: tenantId,
        username: cleanUser,
        password_hash: cleanPass,
        full_name: cleanShop,
        role: 'demo'
      })
    });

    if (!userRes.ok) {
      console.error('Failed to create tenant user:', await userRes.text());
      return;
    }

    console.log('\n===============================================================');
    console.log('  🎉 TRIAL ACCOUNT CREATED SUCCESSFULLY!');
    console.log('===============================================================');
    console.log(`  🏪 Business Name : ${cleanShop}`);
    console.log(`  👤 Username      : ${cleanUser}`);
    console.log(`  🔑 Password      : ${cleanPass}`);
    console.log(`  ⏳ Trial Duration: ${trialDays} Days (Valid until: ${trialExpiry.split('T')[0]})`);
    console.log(`  🏢 Business Type : ${bType.toUpperCase()}`);
    if (cleanPhone) console.log(`  📱 Phone Number  : ${cleanPhone}`);
    console.log('===============================================================');
    console.log('\n📲 Ready-to-Send WhatsApp / SMS Message to Client:');
    console.log('---------------------------------------------------------------');
    console.log(`مرحباً بك في Red Shark POS! 🦈\nتم تفعيل نسختك التجريبية بنجاح لمدة ${trialDays} أيام:\n\n🌐 رابط تسجيل الدخول: https://demo.redsharkpos.com/login.html\n👤 اسم المستخدم: ${cleanUser}\n🔑 كلمة المرور: ${cleanPass}\n\nيمكنك تسجيل الدخول مباشرة من الهاتف أو الكمبيوتر والبدء في تجربة النظام.`);
    console.log('---------------------------------------------------------------\n');

  } catch (err) {
    console.error('Trial account creation error:', err.message);
  }
}

// CLI Arg Parsing
const args = process.argv.slice(2);
if (args.length === 0) {
  createTrialUser();
} else if (args[0] === '--list' || args[0] === '-l') {
  listTrialUsers();
} else if (args[0] === '--extend' || args[0] === '-e') {
  extendTrial(args[1], args[2]);
} else {
  const [shopName, username, password, days, phone, mode] = args;
  createTrialUser(shopName, username, password, days, phone, mode);
}
