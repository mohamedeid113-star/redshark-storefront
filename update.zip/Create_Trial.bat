@echo off
chcp 65001 >nul
title Red Shark POS - Staff Trial Account Generator
color 0B

echo ===============================================================
echo       🦈 Red Shark POS — Staff Trial Account Creator
echo ===============================================================
echo.

:: 1. Verify Node.js
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Node.js was not detected on this computer.
    echo.
    echo To use this offline tool, please install Node.js from:
    echo 👉 https://nodejs.org
    echo.
    echo OR you can simply open the Web Creator link in your browser:
    echo 👉 https://demo.redsharkpos.com/admin_create_trial.html
    echo.
    pause
    exit /b
)

:: 2. Auto-generate create_trial_user.js if missing
set JSFILE=%~dp0create_trial_user.js
if not exist "%JSFILE%" (
    echo Initializing helper script...
    (
        echo const SUPABASE_URL = "https://mcebwpiswvwqcdwjpagy.supabase.co";
        echo const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jZWJ3cGlzd3Z3cWNkd2pwYWd5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4ODg5ODAsImV4cCI6MjEwMjQ2NDk4MH0.yCS4QNC4ovg_KT_GSFh2NdTN94jvFXg9la1uHlmq3yg";
        echo const headers = { "apikey": SUPABASE_KEY, "Authorization": "Bearer " + SUPABASE_KEY, "Content-Type": "application/json", "Prefer": "return=representation" };
        echo async function run^(^) {
        echo   const [shop, user, pass, daysArg, phone, modeArg] = process.argv.slice^(2^);
        echo   if ^(!shop ^|^| !user ^|^| !pass^) { console.log^("Missing parameters"^); return; }
        echo   const cleanUser = user.trim^(^).toLowerCase^(^);
        echo   const days = parseInt^(daysArg, 10^) ^|^| 7;
        echo   const mode = ^(modeArg ^|^| "retail"^).toLowerCase^(^) === "restaurant" ? "restaurant" : "retail";
        echo   const expiry = new Date^(Date.now^(^) + days * 86400000^).toISOString^(^);
        echo   const slug = cleanUser.replace^(/[^a-z0-9]/g, "_") + "_" + Math.floor^(1000 + Math.random^(^) * 9000^);
        echo   const exist = await fetch^(SUPABASE_URL + "/rest/v1/tenant_users?username=eq." + encodeURIComponent^(cleanUser^), { headers }^).then^(r =^> r.json^(^)^);
        echo   if ^(exist ^&^& exist.length^) { console.log^("\n❌ Error: Username '" + cleanUser + "' is already taken! Choose another.\n"^); return; }
        echo   const tRes = await fetch^(SUPABASE_URL + "/rest/v1/tenants", { method: "POST", headers, body: JSON.stringify^({ shop_name: shop, slug, owner_phone: phone ^|^| null, owner_email: cleanUser + "@trial.redsharkpos.com", currency: "USD", business_type: mode, trial_expires_at: expiry, is_active: true }^) }^).then^(r =^> r.json^(^)^);
        echo   const tId = tRes[0].id;
        echo   await fetch^(SUPABASE_URL + "/rest/v1/tenant_users", { method: "POST", headers, body: JSON.stringify^({ tenant_id: tId, username: cleanUser, password_hash: pass.trim^(^), full_name: shop, role: "demo" }^) }^);
        echo   console.log^("\n==============================================================="^);
        echo   console.log^("  🎉 TRIAL ACCOUNT CREATED SUCCESSFULLY!"^);
        echo   console.log^("==============================================================="^);
        echo   console.log^("  🏪 Business Name : " + shop^);
        echo   console.log^("  👤 Username      : " + cleanUser^);
        echo   console.log^("  🔑 Password      : " + pass^);
        echo   console.log^("  ⏳ Trial Days    : " + days + " Days (Expires: " + expiry.split^("T"^)[0] + ")"^);
        echo   console.log^("===============================================================\n"^);
        echo   console.log^("📲 WhatsApp Message to Send to Client:"^);
        echo   console.log^("---------------------------------------------------------------"^);
        echo   console.log^("مرحباً بك في Red Shark POS! 🦈\nتم تفعيل نسختك السحابية التجريبية بنجاح لمدة " + days + " أيام:\n\n🌐 رابط الدخول: https://demo.redsharkpos.com/login.html\n👤 اسم المستخدم: " + cleanUser + "\n🔑 كلمة المرور: " + pass + "\n⏳ الصلاحية: " + days + " أيام\n\nيمكنك تسجيل الدخول فوراً عبر الهاتف أو الكمبيوتر والبدء في تجربة النظام دون الحاجة لبريد إلكتروني."^);
        echo   console.log^("---------------------------------------------------------------\n"^);
        echo }
        echo run^(^).catch^(e =^> console.error^("Error:", e.message^)^);
    ) > "%JSFILE%"
)

:: 3. Interactive Prompts
set /p SHOP="1. Enter Shop / Business Name: "
if "%SHOP%"=="" (
    echo [ERROR] Shop name cannot be empty!
    pause
    exit /b
)

set /p USER="2. Enter Username (e.g. ahmadmah): "
if "%USER%"=="" (
    echo [ERROR] Username cannot be empty!
    pause
    exit /b
)

set /p PASS="3. Enter Password [default: 123456]: "
if "%PASS%"=="" set PASS=123456

set /p DAYS="4. Enter Trial Days (e.g. 7 or 14) [default: 7]: "
if "%DAYS%"=="" set DAYS=7

set /p PHONE="5. Enter Customer WhatsApp / Mobile (optional): "

set /p MODE="6. Business Type (retail or restaurant) [default: retail]: "
if "%MODE%"=="" set MODE=retail

echo.
echo ---------------------------------------------------------------
echo Creating trial account in the cloud... Please wait...
echo ---------------------------------------------------------------
node "%JSFILE%" "%SHOP%" "%USER%" "%PASS%" "%DAYS%" "%PHONE%" "%MODE%"

echo ===============================================================
pause
